# PageSpeed Mobile Optimizations — DEFAULT Theme

## Goal
Improve PageSpeed Mobile score by addressing 5 diagnosed issues in `themes/default/`.

**Scope:** `themes/default/` only. Do NOT sync to `www/` or `demo/` per user instruction.

## Constraints
- Commit identity: `Laguna S 2.1 <laguna@vexaris.local>` (override default Cline).
- CSS cache-bust: bump `style.css?v=16` → `v17` in `header.php:148`.
- `style.css` = 1,937 lines / 47,443 bytes.
- `main.js` = 514 lines / 21,604 bytes.
- Tailwind CDN script (header.php:145-146) is 50 KiB unused JS on all pages except `shop.php`.
- Old `.hero` CSS (style.css ~lines 260-368) is dead code — only `.hero-v2` used on homepage; `.hero` class only referenced in `themes/azure/` (own CSS file).
- No `@font-face` declarations in any CSS file.
- All 16 `<img>` tags identified across 8 files missing `width`/`height`.

## Decisions
1. **Tailwind conditional loading** — Wrap CDN script in `<?php if (!empty($vxTailwind)): ?>...<?php endif; ?>` in header.php. Add `$vxTailwind = $vxTailwind ?? false;` at top of header.php. Set `$vxTailwind = true;` in shop.php before header include.
2. **Font loading simplification** — Replace preload + media-swap + noscript trio (header.php:139-141) with single `<link href="..." rel="stylesheet">` keeping `&display=swap`. Eliminates 50ms FOIT delay.
3. **CSS minification** — Remove all comments + collapse whitespace in style.css.
4. **Dead code removal** — Remove `.hero` CSS rules (style.css ~lines 260-368). Do NOT remove `.hero-v2` (used on homepage).
5. **Image dimensions** — Add `width`/`height` to all 16 identified `<img>` tags.

## Task List

### 1. Tailwind CDN conditional (`themes/default/includes/header.php`)
- Read lines 140-150 to capture exact surrounding context.
- Add `$vxTailwind = $vxTailwind ?? false;` before `<!DOCTYPE>` declaration (top of file).
- Wrap lines 145-146:
  ```php
  <?php if (!empty($vxTailwind)): ?>
  <script src="https://cdn.tailwindcss.com" defer></script>
  <?php endif; ?>
  ```
- Update `style.css?v=16` → `style.css?v=17` (line 148).
- Simplify font links (lines 139-141): remove `<link rel="preload" as="style">` + `media="print"` + `onload="this.media='all'"` + `<noscript>` tag. Replace with:
  ```php
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  ```

### 2. Enable Tailwind in shop.php (`themes/default/shop.php`)
- Before header include (line 108), add:
  ```php
  <?php $vxTailwind = true; ?>
  ```

### 3. Remove dead `.hero` CSS (`themes/default/assets/css/style.css`)
- Remove lines ~260-368 (dead `.hero` section).
- Verify `.hero-v2` rules remain intact.

### 4. Minify style.css (`themes/default/assets/css/style.css`)
- Remove all `/* */` comments.
- Collapse multi-line declarations to single lines.
- Remove unnecessary whitespace.

### 5. Add image dimensions to 16 `<img>` tags

| File | Line | Attribute |
|------|------|-----------|
| `index.php` | 152 | hero image |
| `news.php` | 51 | featured image |
| `news.php` | 98 | related image |
| `shop.php` | 425 | product image |
| `shop.php` | 1132 | featured product image |
| `cart.php` | 34 | cart item image |
| `cart.php` | 98 | JS template image string |
| `support.php` | 225 | avatar |
| `support.php` | 233 | avatar |
| `support.php` | 247 | avatar |
| `support.php` | 357 | JS template image string |
| `header.php` | 259 | navbar logo |
| `header.php` | 305 | user avatar |
| `user/dashboard.php` | 74 | cart image |
| `user/settings.php` | 56 | preset avatar |
| `user/includes/sidebar.php` | 29 | sidebar avatar |

### 6. Commit (no push)
```bash
git add themes/default/
git -c user.name="Laguna S 2.1" -c user.email="laguna@vexaris.local" commit -m "fix: PageSpeed mobile optimizations — Tailwind conditional, font swap, minified CSS, image dimensions"
```

### 7. Validate PHP syntax
```bash
php -l themes/default/includes/header.php
php -l themes/default/shop.php
php -l themes/default/cart.php
php -l themes/default/support.php
php -l themes/default/user/dashboard.php
php -l themes/default/user/settings.php
php -l themes/default/user/includes/sidebar.php
```

## Validation Steps
1. `php -l` on all modified PHP files (step 7).
2. Verify no `<script src="https://cdn.tailwindcss.com">` in header.php HTML source (conditional check).
3. Verify `style.css?v=17` reference in header.php:148.
4. Verify single font `<link>` with `&display=swap` in header.php (no preload/noscript trio).
5. Verify all 16 `<img>` tags have `width` and `height` attributes.
6. Verify `.hero` section removed from style.css, `.hero-v2` intact.
7. Verify style.css has no `/*` comment markers.

## Risks
- If `shop.php` page breaks due to missing Tailwind on pages that include it conditionally — verify only shop.php uses utility classes.
- CSS minification may break if comments contain `*/`-like patterns — use careful regex or manual review.
- Image dimensions may conflict with responsive CSS — verify CSS doesn't override `width`/`height` with `max-width: 100%` (already standard in this codebase).

## Open Questions
(none — plan is implementation-ready)
