# Vexaris — Dijital Ürün Satış Platformu

Vexaris, e-kitap, e-pin, lisans anahtarı, yazılım eklentisi ve hazır paket gibi dijital ürünleri satıp anında teslim eden bir market. Müşteri ürünü alır, dosyası ve/veya kodu hesabına düşer, dilediğinde indirip kullanır; takılırsa destek talebi açar.

**Kime uygun?** Eklenti ve paket üreten ekipler, e-kitap/e-pin satıcıları, lisanslı dijital içerik üretenler.

---

## Ne Yapar?

Müşteri mağazayı gezer, ürünü sepete atar, kupon ve bakiyeyle öder; ödeme onaylanınca sistem ürünün dosyasını, lisans anahtarını veya e-pin kodunu otomatik oluşturup “Satın Aldıklarım”a ekler. Satıcı hiçbir şey elle göndermez. Destek, iade ve güncellemeler aynı panelden yürür.

---

## Site — Kullanıcının Gördüğü

- **Ana Sayfa** (`/`): Hero, öne çıkan ürünler, referanslar, SSS, duyurular.
- **Mağaza** (`/products`): Kategori ve arama, ürün listesi ve detay (görsel, açıklama, fiyat, indirim, stok, versiyon), sepete ekle / hemen al, kütüphaneye eklenen ürünler (`/products?tab=purchases`).
- **Duyurular** (`/news`): Güncellemeler ve haberler.
- **Destek** (`/support`): Giriş yapıp bilet açma, mesajlaşma.
- **Hesap** (`/login`, `/register`, `/forgot-password`, `/reset-password`, `/verify-email`): Kayıt, giriş, şifremi unuttum, e-posta doğrulama, “beni hatırla”.
- **Kullanıcı Paneli** (`/user/*`): Dashboard, Ürünlerim (lisans kopyala/indir), Taleplerim, Kod Kullan, Ayarlar (profil/şifre), Bağlı Hesaplar, Bakiye Yükle.
- **Yasal** (`/legal?p=privacy-policy|terms-of-service|cookie-policy|refund-policy`) ve özel sayfalar (`/custom-page?slug=`).

Tüm formlar tek merkezden (`action.php`) ve çerez onayı ile çalışır.

---

## Admin — Satıcının Yönettiği

` /admin` tek panel, sekmelerle:

- **Dashboard:** Satış ve kullanıcı özetleri.
- **Ürünler / Kategoriler:** Ürün ekle/düzenle/sil, görsel ve dosya yükle (`zip/rar/7z/jar`), kısa açıklama, kullanıcı notu, fiyat, indirim, stok (sınırsız veya tekil e-pin/lisans içerikleri `product_stocks`), kategori ve sıralama.
- **Satın Alımlar (Purchases):** Kimin ne aldığı, lisans anahtarı, indirme.
- **Kuponlar:** İndirim ve ürün hediye kuponları.
- **Duyurular & Blog & Referanslar & SSS:** Duyuru ekle, blog yazısı, müşteri yorumları (slider/grid), sıkça sorulan sorular.
- **Destek Talepleri & Kategori:** Gelen biletler ve kategorileri.
- **Özel Sayfalar:** İçerik editörüyle sayfa oluşturma detaylı analizlerine bakma.
- **Yasal Sayfalar:** Yasal Metinleri düzenleme.
- **Değerlendirmeler:** Ürün yorumlarısilme kaldırma düzenleme.
- **Kullanıcılar & Yetkiler:** Kullanıcı listesi, roller (admin, yönetici, moderatör, destek ekibi) ve kaynak bazlı izinler.
- **Ayarlar & Tema:** Site adı/logo, header menüsü, footer, renk ve tema seçimi (`default/azure/ember`).
- **Entegrasyonlar:** Ödeme (Shopier, PayTR, iyzico, Stripe, PayPal, BitPay, Cryptomus), sosyal giriş (Google, Discord, Microsoft, GitHub), canlı destek (Tawk.to, JivoChat, Crisp), güvenlik (Cloudflare Turnstile / reCAPTCHA), Discord webhook, mail SMTP.
- **Mail Şablonları & SEO & Lisanslar & Versiyonlar & Güncelleme & Discord Webhook:** Şablon, SEO başlık/açıklama, sürüm ve erteleme takibi.

---

## Nasıl Çalışır (Kullanıcı Gözünden)

1. Mağazada ürünü bul → sepete ekle → kupon uygula → bakiye veya kartla öde.
2. Ödeme tamam → lisans/e-pin/dosya otomatik hesabına tanımlanır.
3. “Ürünlerim”den indir veya anahtarı kopyala.
4. Sorun olursa Destek’ten bilet aç, yanıtı aynı yerden takip et.

Satıcı için: Ürünü ve stok içeriklerini (her satıra bir e-pin/anahtar) admin’den gir, gerisini sistem halleder.
Entegrasyonlar
- Google Auth
- Microsoft Auth
- Discord Auth
- Github Auth
- Cloudflare Turnstile
- Google ReCaptcha
- Shopier
- Paypal
- Strıpe
- Google analiysts
- Crisp chat
- Jivo Chat
- tawk.to chat
- BitPay
- Cryptomus
- iyzico
- paytr