<?php

// API responses must stay machine-readable even when display_errors is enabled.
// Errors are still written to the configured PHP error log.
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('html_errors', '0');
ob_start();
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);

defined('ROOT_PATH')  or define('ROOT_PATH',  __DIR__);

require_once __DIR__ . '/core/init.php';

require_once __DIR__ . '/actions/bootstrap-action.php';

$action = $_POST['action'] ?? ($_SERVER['REQUEST_METHOD'] === 'POST' ? ($_GET['action'] ?? '') : '');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    json_resp(false, __('bboot.bad_method'));
}

$db = nexus_db();
if (!$db) json_resp(false, __('auth.db_error'));


$csrfSafe = ['search','cart_panel_html'];

if (!in_array($action, $csrfSafe, true)) csrf_verify();



if (empty($action) && $_SERVER['REQUEST_METHOD'] === 'POST') {

    $safeLog = $_POST;

    foreach ($safeLog as $k => $v) {

        if (preg_match('/pass|token|secret|key|card|cvv|iban|api/i', (string)$k)) $safeLog[$k] = '[redacted]';

    }

    error_log('[NS] action.php: POST with empty $action. POST=' . json_encode($safeLog) . ' CL=' . ($_SERVER['CONTENT_LENGTH'] ?? 0) . ' pmax=' . ini_get('post_max_size') . ' umax=' . ini_get('upload_max_filesize'));

    json_resp(false, 'Form verisi alınamadı. Dosya boyutu çok büyük olabilir (limit: ' . ini_get('upload_max_filesize') . ').');

}

$nxMap = [
    'admin_category_search' => 'catalog',
    'admin_set_language' => 'system',
    'ai_chat' => 'system',
    'ai_tool_run' => 'system',
    'ai_write' => 'system',
    'admin_theme_save' => 'system',
    'announcement_delete' => 'catalog',
    'announcement_save' => 'catalog',
    'apply_coupon' => 'shop',
    'asset_upload' => 'catalog',
    'avatar_preset' => 'support',
    'avatar_upload' => 'support',
    'balance_add' => 'shop',
    'balance_topup' => 'shop',
    'buy_now' => 'shop',
    'cart_add' => 'shop',
    'cart_clear' => 'shop',
    'cart_panel_html' => 'shop',
    'cart_remove' => 'shop',
    'cart_state' => 'shop',
    'cart_update_qty' => 'shop',
    'category_delete' => 'catalog',
    'category_save' => 'catalog',
    'change_email' => 'support',
    'change_password' => 'support',
    'checkout' => 'shop',
    'comment_add' => 'shop',
    'comment_delete' => 'shop',
    'comment_update' => 'shop',
    'cookie_consent' => 'support',
    'custom_css_save' => 'system',
    'discord_save' => 'system',
    'discord_test' => 'system',
    'faq_delete' => 'catalog',
    'faq_reorder' => 'catalog',
    'faq_save' => 'catalog',
    'get_balance_status' => 'shop',
    'int_save' => 'system',
    'int_test' => 'system',
    'int_toggle' => 'system',
    'legal_page_save' => 'catalog',
    'mail_template_save' => 'system',
    'mail_test_send' => 'system',
    'manage_coupon' => 'shop',
    'mod_save' => 'system',
    'mod_sidebar' => 'system',
    'mod_toggle' => 'system',
    'oauth_unlink' => 'support',
    'page_leave' => 'support',
    'paytr_pay' => 'shop',
    'product_add' => 'catalog',
    'product_delete' => 'catalog',
    'product_edit' => 'catalog',
    'product_image_add' => 'catalog',
    'product_save' => 'catalog',
    'product_stock' => 'catalog',
    'product_stock_items' => 'catalog',
    'product_toggle_hidden' => 'catalog',
    'reference_save' => 'catalog',
    'reference_settings' => 'catalog',
    'review_delete' => 'shop',
    'review_update' => 'shop',
    'role_delete' => 'system',
    'role_save' => 'system',
    'search' => 'catalog',
    'seo_reset' => 'catalog',
    'seo_save' => 'catalog',
    'shopier_pay' => 'shop',
    'shopier_test' => 'shop',
    'slider_delete' => 'catalog',
    'slider_save' => 'catalog',
    'slider_toggle' => 'catalog',
    'stock_bulk_items' => 'catalog',
    'stock_bulk_off' => 'catalog',
    'theme_editor_save' => 'system',
    'ticket_admin_reply' => 'support',
    'ticket_category_delete' => 'support',
    'ticket_category_save' => 'support',
    'ticket_close' => 'support',
    'ticket_create' => 'support',
    'ticket_delete' => 'support',
    'ticket_poll' => 'support',
    'ticket_reply' => 'support',
    'track_category_view' => 'catalog',
    'update_auto' => 'system',
    'update_check' => 'system',
    'update_delay' => 'system',
    'update_download' => 'system',
    'update_progress' => 'system',
    'user_change_password' => 'support',
    'user_update_profile' => 'support',
    'version_delete' => 'catalog',
    'version_list' => 'catalog',
    'version_save' => 'catalog',
];

$nxGroup = $nxMap[$action] ?? null;

if ($nxGroup === null) json_resp(false, 'Bilinmeyen işlem.');

require ROOT_PATH . '/actions/' . $nxGroup . '-action.php';

json_resp(false, 'İşlem tamamlanamadı.');
