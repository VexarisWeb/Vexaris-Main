<?php
if (!defined('NEXUS_BOOT')) { http_response_code(403); exit; }

function image_from_mime(string $path, string $mime) {

    $map = ['image/jpeg'=>'imagecreatefromjpeg','image/png'=>'imagecreatefrompng','image/webp'=>'imagecreatefromwebp','image/gif'=>'imagecreatefromgif'];

    $fn = $map[$mime] ?? null;

    return $fn ? @$fn($path) : null;

}



function image_alpha_canvas(int $w, int $h) {

    $c = imagecreatetruecolor($w, $h);

    imagealphablending($c, false);

    imagesavealpha($c, true);

    $transparent = imagecolorallocatealpha($c, 0, 0, 0, 127);

    imagefill($c, 0, 0, $transparent);

    return $c;

}



function json_resp(bool $ok, string $msg, array $extra = []): void {
    $payload = json_encode(array_merge(['ok' => $ok, 'msg' => $msg], $extra));
    if (ob_get_level() > 0) ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo $payload === false ? '{"ok":false,"msg":"' . __('bboot.resp_fail') . '"}' : $payload;
    exit;
}


function redirect_back(string $msg = '', string $type = 'success'): void {

    $ref = $_SERVER['HTTP_REFERER'] ?? '/';

    $path = '/';
    $parsed = is_string($ref) ? parse_url($ref) : false;
    if (is_array($parsed)) {
        $refHost = strtolower(trim((string)($parsed['host'] ?? '')));
        $curHost = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
        if (isset($parsed['host'])) {
            if ($refHost !== '' && $refHost === $curHost) {
                $path = ($parsed['path'] ?? '/') ?: '/';
                if (isset($parsed['query']) && $parsed['query'] !== '') $path .= '?' . $parsed['query'];
            }
        } else {
            $rawPath = ($parsed['path'] ?? '/') ?: '/';
            if (strncmp($rawPath, '/', 1) === 0 && strncmp($rawPath, '//', 2) !== 0) {
                $path = $rawPath;
                if (isset($parsed['query']) && $parsed['query'] !== '') $path .= '?' . $parsed['query'];
            }
        }
    }
    $ref = $path;

    if ($msg) {

        $sep = str_contains($ref, '?') ? '&' : '?';

        $ref .= $sep . 'flash=' . urlencode("{$type}:{$msg}");

    }

    header('Location: ' . $ref, true, 302);

    exit;

}



function require_login(): void {

    if (!auth_check()) json_resp(false, __('bboot.login_required'));

}



function require_admin(): void {

    if (!auth_check() || !in_array((string)(auth_user()['role'] ?? ''), ['admin', 'superadmin'], true))

        json_resp(false, 'Yetkiniz yok.');

}



function require_resource(string $resource): void {

    if (!auth_check()) json_resp(false, __('bboot.login_required'));

    $role = auth_user()['role'] ?? 'user';

    if ($role === 'superadmin' || $role === 'admin') return;

    try {

        $db = nexus_db();

        $st = $db->prepare('SELECT COUNT(*) FROM permissions WHERE role=? AND resource=?');

        $st->execute([$role, $resource]);

        if ((int)$st->fetchColumn() === 0) json_resp(false, __('bboot.no_perm'));

    } catch (\PDOException $e) {

        json_resp(false, __('bboot.perm_fail'));

    }

}



use Shopier\Shopier as ShopierShopier;

use Shopier\Models\Buyer as ShopierBuyer;

use Shopier\Models\Address as ShopierAddress;

use Shopier\Enums\ProductType as ShopierProductType;

use Shopier\Enums\WebsiteIndex as ShopierWebsiteIndex;

use Shopier\Renderers\AutoSubmitFormRenderer as ShopierAutoSubmitFormRenderer;



require_once ROOT_PATH . '/core/paytr.php';

require_once ROOT_PATH . '/core/iyzico.php';

require_once ROOT_PATH . '/core/stripe.php';

require_once ROOT_PATH . '/core/paypal.php';

require_once ROOT_PATH . '/core/bitpay.php';

require_once ROOT_PATH . '/core/crypt.php';

require_once ROOT_PATH . '/core/paywant.php';

require_once ROOT_PATH . '/core/whop.php';

require_once ROOT_PATH . '/core/paddle.php';
require_once ROOT_PATH . '/core/lemonsqueezy.php';
require_once ROOT_PATH . '/core/dodopayments.php';

require_once ROOT_PATH . '/core/stock.php';
require_once ROOT_PATH . '/core/shopier.php';



function highlightSearch(string $q, string $text): string {

    return preg_replace('/('.preg_quote($q, '/').')/iu', '<strong class="search-hl">$1</strong>', e($text));

}



function _ua_delete_old_avatar(array $u): void {

    $av = $u['avatar'] ?? '';

    if ($av && strpos($av, '/uploads/avatars/') === 0) {

        $file = ROOT_PATH . $av;

        if (file_exists($file)) @unlink($file);

    }

}



function _ua_update_avatar(\PDO $db, int $userId, string $path): void {

    $db->prepare('UPDATE users SET avatar=? WHERE id=?')->execute([$path, $userId]);

    $_SESSION['user']['avatar'] = $path;

}



function _ua_upload_avatar(array $file, array $u): array {

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $map = [
            UPLOAD_ERR_INI_SIZE=>__('bboot.up_ini'),
            UPLOAD_ERR_FORM_SIZE=>__('bboot.up_form'),
            UPLOAD_ERR_PARTIAL=>__('bboot.up_partial'),
            UPLOAD_ERR_NO_FILE=>__('bboot.up_nofile'),
            UPLOAD_ERR_NO_TMP_DIR=>__('bboot.up_notmp'),
            UPLOAD_ERR_CANT_WRITE=>__('bboot.up_nowrite'),
            UPLOAD_ERR_EXTENSION=>__('bboot.up_ext'),
        ];
        $msg = $map[$file['error']] ?? __('bboot.up_err', ['e' => $file['error']]);
        return ['ok'=>false,'msg'=>$msg];
    }
    if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) return ['ok'=>false,'msg'=>__('bboot.file_invalid')];

    if ($file['size'] > 1_048_576) return ['ok'=>false,'msg'=>__('bboot.file_1mb')];

    $finfo = finfo_open(FILEINFO_MIME_TYPE);

    $mimeType = finfo_file($finfo, $file['tmp_name']);

    finfo_close($finfo);

    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];

    if (!$mimeType || !isset($allowed[$mimeType])) return ['ok'=>false,'msg'=>__('bboot.file_img_only')];

    $dir = ROOT_PATH . '/uploads/avatars/';

    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $filename = 'avatar_' . (int)$u['id'] . '_' . bin2hex(random_bytes(6)) . '.' . $allowed[$mimeType];

    $dest = $dir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) return ['ok'=>false,'msg'=>'Dosya kaydedilemedi.'];

    return ['ok'=>true,'path'=>'/uploads/avatars/'.$filename];

}



function remember_recent_page(\PDO $db, int $userId, string $pageKey, string $pageLabel, string $pageUrl, string $pageIcon = ''): void {

    if ($userId < 1 || $pageKey === '' || $pageLabel === '' || $pageUrl === '') return;

    try {

        $st = $db->prepare('INSERT INTO admin_recent_pages (user_id,page_key,page_label,page_url,page_icon,viewed_at) VALUES (?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE page_label=VALUES(page_label),page_url=VALUES(page_url),page_icon=VALUES(page_icon),viewed_at=NOW()');

        $st->execute([$userId, $pageKey, $pageLabel, $pageUrl, $pageIcon ?: null]);

        $ids = $db->prepare('SELECT id FROM admin_recent_pages WHERE user_id=? ORDER BY viewed_at DESC LIMIT 1000 OFFSET 5');

        $ids->execute([$userId]);

        $old = $ids->fetchAll(\PDO::FETCH_COLUMN);

        if ($old) {

            $ph = implode(',', array_fill(0, count($old), '?'));

            $db->prepare("DELETE FROM admin_recent_pages WHERE id IN ($ph)")->execute($old);

        }

    } catch (\PDOException $e) {

        error_log('[NS] remember_recent_page: '.$e->getMessage());

    }

}



function is_ajax(): bool {

    if (strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest') return true;

    return strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false;

}



function product_effective_price($price, $discountPercent): float {

    $d = min(90, max(0, (int)$discountPercent));

    return round((float)$price * (1 - $d / 100), 2);

}



function cart_effective_total(array $items): float {

    $total = 0.0;

    foreach ($items as $i) {

        $d = min(90, max(0, (int)($i['discount_percent'] ?? 0)));

        $total += (float)$i['price'] * (1 - $d / 100) * (int)$i['quantity'];

    }

    return round($total, 2);

}



function nx_safe_unlink_product_file($path): void {
    if (!is_string($path) || $path === '' || strpos($path, "\0") !== false) return;

    if (strncmp($path, '/uploads/products/', 18) !== 0 || strpos($path, '..') !== false) return;

    $base = realpath(ROOT_PATH . '/uploads/products');

    if ($base === false) return;

    $full = realpath(ROOT_PATH . $path);

    if ($full === false || !is_file($full)) return;

    if (strncmp($full, $base . DIRECTORY_SEPARATOR, strlen($base) + 1) !== 0) return;

    @unlink($full);

}



function coupon_discount_for_total(array $coupon, float $cartTotal): float {    $tp = $coupon['type'] ?? '';

    $val = (float)($coupon['value'] ?? 0);

    if ($tp === 'percent') return round($cartTotal * (min(100, max(0, $val)) / 100), 2);

    if ($tp === 'flat_tl') return min(fx_convert(max(0, $val), 'TRY', store_currency()), $cartTotal);

    if ($tp === 'flat_usd') return min(fx_convert(max(0, $val), 'USD', store_currency()), $cartTotal);

    if ($tp === 'flat_eur') return min(fx_convert(max(0, $val), 'EUR', store_currency()), $cartTotal);

    return 0.0;

}

function coupon_label(string $type, $val): string {
    $v = (float)$val;
    if ($type === 'percent') return str_replace('{v}', (string)$v, __('coupon.pct'));
    if ($type === 'flat_tl') return str_replace('{v}', (string)$v, __('coupon.flat_tl'));
    if ($type === 'flat_usd') return str_replace('{v}', (string)$v, __('coupon.flat_usd'));
    if ($type === 'flat_eur') return str_replace('{v}', (string)$v, __('coupon.flat_eur'));
    return __('coupon.generic');
}
function coupon_resolve_for_pay(PDO $db, $sessionCoupon, int $uid = 0): ?array {
    if (!is_array($sessionCoupon) || empty($sessionCoupon['id'])) return null;
    try {
        $cv = $db->prepare('SELECT id,code,type,reward_type,reward_value,is_active,used_count,max_uses,expires_at FROM coupons WHERE id=?');
        $cv->execute([(int)$sessionCoupon['id']]);
        $row = $cv->fetch();
    } catch (\Throwable $e) { return null; }
    if (!$row || empty($row['is_active'])) return null;
    if ((int)$row['used_count'] >= (int)$row['max_uses']) return null;
    if (!empty($row['expires_at']) && strtotime($row['expires_at']) < time()) return null;
    if (($row['reward_type'] ?? 'discount') !== 'discount') return null;
    if ($uid > 0) {
        try {
            $used = $db->prepare('SELECT id FROM coupon_usages WHERE user_id=? AND coupon_id=?');
            $used->execute([$uid, (int)$row['id']]);
            if ($used->fetch()) return null;
        } catch (\Throwable $e) { return null; }
    }
    return ['id' => (int)$row['id'], 'code' => (string)($row['code'] ?? ''), 'type' => (string)$row['type'], 'value' => (float)$row['reward_value']];
}

function ticket_store_image(array $file): array {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return ['ok' => true, 'path' => null];
    if (($file['error'] ?? 1) !== UPLOAD_ERR_OK) return ['ok' => false, 'msg' => __('bboot.file_fail')];
    if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) return ['ok' => false, 'msg' => __('bboot.file_invalid2')];
    if ((int)($file['size'] ?? 0) > 5242880) return ['ok' => false, 'msg' => __('bboot.img_5mb')];
    $fi = new finfo(FILEINFO_MIME_TYPE);
    $mime = $fi->file($file['tmp_name']);
    $map = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($map[$mime])) return ['ok' => false, 'msg' => __('bboot.img_types')];
    $ext = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));
    if (!in_array($ext, ['png', 'jpg', 'jpeg', 'webp'], true)) return ['ok' => false, 'msg' => __('bboot.img_types')];
    if (@getimagesize($file['tmp_name']) === false) return ['ok' => false, 'msg' => __('bboot.img_invalid')];
    $dir = ROOT_PATH . '/uploads/tickets/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $name = 't_' . bin2hex(random_bytes(12)) . '.' . $map[$mime];
    if (!move_uploaded_file($file['tmp_name'], $dir . $name)) return ['ok' => false, 'msg' => 'Dosya kaydedilemedi.'];
    return ['ok' => true, 'path' => '/uploads/tickets/' . $name];
}

function ticket_delete_images(\PDO $db, int $tid): void {
    try {
        $st = $db->prepare('SELECT image_url FROM ticket_replies WHERE ticket_id=? AND image_url IS NOT NULL');
        $st->execute([$tid]);
        $base = realpath(ROOT_PATH . '/uploads/tickets');
        if ($base === false) return;
        foreach ($st->fetchAll(\PDO::FETCH_COLUMN) as $rel) {
            if (!is_string($rel) || $rel === '' || strpos($rel, "\0") !== false) continue;
            if (strncmp($rel, '/uploads/tickets/', 17) !== 0 || strpos($rel, '..') !== false) continue;
            $full = realpath(ROOT_PATH . $rel);
            if ($full === false || !is_file($full)) continue;
            if (strncmp($full, $base . DIRECTORY_SEPARATOR, strlen($base) + 1) !== 0) continue;
            @unlink($full);
        }
    } catch (\Throwable $e) {}
}
