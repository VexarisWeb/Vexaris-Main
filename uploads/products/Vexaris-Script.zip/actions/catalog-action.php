<?php
if (!defined('NEXUS_BOOT')) { http_response_code(403); exit; }

switch ($action) {

    case 'category_save':

        require_resource('categories');

        $cId = (int)($_POST['id'] ?? 0);

        $cName = trim($_POST['name'] ?? '');

        $cIcon = trim($_POST['icon'] ?? '');

        $cDesc = trim(strip_tags($_POST['description'] ?? ''));

        $cSort = max(0, (int)($_POST['sort_order'] ?? 0));

        if (!$cName) redirect_back(__('bcat.cat_name_required'), 'error');

        $cSlug = preg_replace('/[^a-z0-9]+/', '-', strtolower($cName));

        $cSlug = trim($cSlug, '-');

        if (!$cSlug) redirect_back(__('bcat.cat_name_invalid'), 'error');

        try {

            if ($cId > 0) {

                $db->prepare('UPDATE categories SET name=?,slug=?,icon=?,description=?,sort_order=? WHERE id=?')->execute([$cName,$cSlug,$cIcon?:null,$cDesc?:null,$cSort,$cId]);

                audit_log($db, 'update', 'categories', $cId, $cName, '/admin/categories.php');

                redirect_back(__('bcat.cat_updated'));

            } else {

                $bs = $cSlug; $si = 1;

                $ch = $db->prepare('SELECT id FROM categories WHERE slug=? LIMIT 1');

                while ($si <= 200) { $ch->execute([$cSlug]); if (!$ch->fetch()) break; $cSlug = $bs . '-' . $si++; }

                if ($si > 200) redirect_back(__('bcat.save_fail'), 'error');

                $db->prepare('INSERT INTO categories (name,slug,icon,description,sort_order) VALUES (?,?,?,?,?)')->execute([$cName,$cSlug,$cIcon?:null,$cDesc?:null,$cSort]);

                audit_log($db, 'create', 'categories', (int)$db->lastInsertId(), $cName, '/admin/categories.php');

                redirect_back(__('bcat.cat_added'));

            }

        } catch (\PDOException $e) { error_log('[NS] category_save: '.$e->getMessage()); redirect_back(__('bcat.cat_save_fail'), 'error'); }
    case 'category_delete':

        require_resource('categories');

        $cId = (int)($_POST['id'] ?? 0);

        if (!$cId) redirect_back(__('err.invalid_id'), 'error');

        try {
            $catRow = $db->prepare('SELECT name FROM categories WHERE id=?');
            $catRow->execute([$cId]);
            $catName = $catRow->fetchColumn();
            if (!$catName) redirect_back(__('bcat.cat_not_found'), 'error');
            $cntSt = $db->prepare('SELECT COUNT(*) FROM products WHERE category=?');
            $cntSt->execute([$catName]);
            if ((int)$cntSt->fetchColumn() > 0) {
                $db->prepare('UPDATE products SET category=NULL WHERE category=?')->execute([$catName]);
            }
            $del = $db->prepare('DELETE FROM categories WHERE id=?');
            $del->execute([$cId]);
            if ($del->rowCount() === 0) redirect_back(__('bcat.cat_delete_fail'), 'error');
            audit_log($db, 'delete', 'categories', $cId, (string)$catName, '/admin/categories.php');
            redirect_back(__('bcat.cat_deleted'));
        } catch (\PDOException $e) { error_log('[NS] category_delete: '.$e->getMessage()); redirect_back(__('cart.remove_fail'), 'error'); }
    case 'slider_save':
        require_resource('slider');
        $sId = (int)($_POST['id'] ?? 0);
        $sContent = trim($_POST['content'] ?? '');
        $sBg = trim($_POST['bg_color'] ?? '#6366f1');
        $sMarquee = isset($_POST['marquee']) ? 1 : 0;
        $sActive = isset($_POST['is_active']) ? 1 : 0;
        $sLink = nx_safe_url(trim($_POST['link_url'] ?? ''));
        if ($sLink === '' && trim($_POST['link_url'] ?? '') !== '') {
            $sLinkRaw = trim($_POST['link_url'] ?? '');
            $sLinkT = (string)preg_replace('/[\x00-\x20]+/', '', $sLinkRaw);
            if (!preg_match('/^(javascript|vbscript|data):/i', $sLinkT)) $sLink = 'https://' . $sLinkRaw;
        }
        if (!preg_match('~^(https?://|mailto:|/|#)~i', $sLink)) $sLink = '';
        if (strlen($sLink) > 512) $sLink = substr($sLink, 0, 512);
        $sSpeed = (int)($_POST['speed'] ?? 20);
        if ($sSpeed < 5) $sSpeed = 5;
        if ($sSpeed > 60) $sSpeed = 60;
        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $sBg)) $sBg = '#6366f1';
        else $sBg = strtoupper($sBg);
        if (strip_tags($sContent) === '' || trim($sContent) === '') redirect_back(__('aslid.err_empty'), 'error');
        $sContent = nx_clean_html($sContent, 'basic');
        try {
            if ($sId > 0) {
                $db->prepare('UPDATE sliders SET content=?, bg_color=?, link_url=?, marquee=?, speed=?, is_active=?, updated_at=NOW() WHERE id=?')->execute([$sContent, $sBg, ($sLink !== '' ? $sLink : null), $sMarquee, $sSpeed, $sActive, $sId]);
                audit_log($db, 'update', 'slider', $sId, mb_substr(trim(strip_tags($sContent)), 0, 80), '/admin/slider.php');
                redirect_back(__('bcat.slider_updated'));
            } else {
                $max = $db->query('SELECT COALESCE(MAX(sort_order),0) FROM sliders')->fetchColumn();
                $db->prepare('INSERT INTO sliders (content,bg_color,link_url,marquee,speed,is_active,sort_order) VALUES (?,?,?,?,?,?,?)')->execute([$sContent, $sBg, ($sLink !== '' ? $sLink : null), $sMarquee, $sSpeed, $sActive, (int)$max+1]);
                audit_log($db, 'create', 'slider', (int)$db->lastInsertId(), mb_substr(trim(strip_tags($sContent)), 0, 80), '/admin/slider.php');
                redirect_back(__('bcat.slider_added'));
            }
        } catch (PDOException $e) { error_log('[NS] slider_save: '.$e->getMessage()); redirect_back(__('bcat.slider_save_fail'), 'error'); }
    case 'slider_delete':
        require_resource('slider');
        $sId = (int)($_POST['id'] ?? 0);
        if (!$sId) redirect_back(__('err.invalid_id'), 'error');
        try { $db->prepare('DELETE FROM sliders WHERE id=?')->execute([$sId]); audit_log($db, 'delete', 'slider', $sId, '#' . $sId, '/admin/slider.php'); redirect_back(__('bcat.slider_deleted')); }
        catch (PDOException $e) { error_log('[NS] slider_delete: '.$e->getMessage()); redirect_back(__('cart.remove_fail'), 'error'); }
    case 'slider_toggle':
        require_resource('slider');
        $sId = (int)($_POST['id'] ?? 0);
        if (!$sId) redirect_back(__('err.invalid_id'), 'error');
        try { $db->prepare('UPDATE sliders SET is_active=1-is_active, updated_at=NOW() WHERE id=?')->execute([$sId]); audit_log($db, 'update', 'slider', $sId, '#' . $sId, '/admin/slider.php'); redirect_back(__('bcat.slider_toggled')); }
        catch (PDOException $e) { error_log('[NS] slider_toggle: '.$e->getMessage()); redirect_back(__('shop.slider_fail'), 'error'); }
    case 'product_add':

        require_resource('products');

        $name  = trim($_POST['name'] ?? '');

        $desc  = nx_clean_html(trim($_POST['description'] ?? ''), 'rich');

        $priceRaw = $_POST['price'] ?? 0;
        if (!is_numeric($priceRaw)) redirect_back(__('bcat.price_invalid'), 'error');
        $price = (float)$priceRaw;

        $cat   = trim($_POST['category'] ?? '');

        $ver   = trim($_POST['version'] ?? '1.0.0');

        $pre   = strtoupper(trim($_POST['license_prefix'] ?? ''));

        $short = trim(strip_tags($_POST['short_description'] ?? ''));

        $dfile = trim($_POST['digital_file'] ?? '');

        if (!$name || $price < 0) redirect_back(__('bcat.product_price_required'), 'error');

        $planPLim = plan_product_limit();
        $planPCount = plan_product_count($db);
        if ($planPLim >= 0 && $planPCount >= $planPLim) redirect_back(__('plan.product_limit_reached', ['have' => $planPCount, 'limit' => $planPLim]), 'error');

        $slug = preg_replace('/[^a-z0-9]+/', '-', strtolower($name));

        $slug = trim($slug, '-'); $slugBase = $slug; $si = 1;

        while (true) { $chk = $db->prepare('SELECT id FROM products WHERE slug=?'); $chk->execute([$slug]); if (!$chk->fetch()) break; $slug = $slugBase . '-' . $si++; }

        $imgUrl = null;

        if (!empty($_FILES['cover_image']['tmp_name'])) {

            if ((int)($_FILES['cover_image']['size'] ?? 0) > 8388608) redirect_back(__('bcat.img_max_8mb'), 'error');

            if (!is_uploaded_file($_FILES['cover_image']['tmp_name'])) redirect_back(__('file.invalid'), 'error');

            $fi = new finfo(FILEINFO_MIME_TYPE); $mime = $fi->file($_FILES['cover_image']['tmp_name']);

            if (!in_array($mime, ['image/jpeg','image/png','image/webp','image/gif'], true)) redirect_back(__('bcat.img_format_invalid'), 'error');

            $dir = ROOT_PATH . '/uploads/products/covers/'; if (!is_dir($dir)) mkdir($dir, 0755, true);

            $sn = bin2hex(random_bytes(16)) . '.webp'; $dp = $dir . $sn;

            $src = image_from_mime($_FILES['cover_image']['tmp_name'], $mime);

            if ($src) { $sw=imagesx($src); $sh=imagesy($src); $r=max(1920/$sw,1080/$sh); $nw=(int)round($sw*$r); $nh=(int)round($sh*$r); $ox=(int)(($nw-1920)/2); $oy=(int)(($nh-1080)/2); $c=imagecreatetruecolor(1920,1080); $t=imagecreatetruecolor($nw,$nh); imagecopyresampled($t,$src,0,0,0,0,$nw,$nh,$sw,$sh); imagecopy($c,$t,0,0,$ox,$oy,1920,1080); imagewebp($c,$dp,85); imagedestroy($src); imagedestroy($t); imagedestroy($c); $imgUrl='/uploads/products/covers/'.$sn; }

        }

        $fp = null;

        if (!empty($_FILES['product_file']['tmp_name'])) {

            if ((int)($_FILES['product_file']['size'] ?? 0) > 33554432) redirect_back(__('bcat.file_max_32mb'), 'error');

            $ext = strtolower(pathinfo($_FILES['product_file']['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, ['zip','rar','7z','jar','tar','gz'], true)) redirect_back(__('bcat.file_type_invalid'), 'error');

            $ud = ROOT_PATH . '/uploads/products/'; if (!is_dir($ud)) mkdir($ud, 0755, true);

            $sn2 = bin2hex(random_bytes(16)) . '.' . $ext;

            if (move_uploaded_file($_FILES['product_file']['tmp_name'], $ud . $sn2)) $fp = '/uploads/products/' . $sn2;

        }

        $discountIns = (int)($_POST['discount_percent'] ?? 0);
        if ($discountIns < 0) $discountIns = 0;
        if ($discountIns > 90) $discountIns = 90;
        try { $db->prepare('INSERT INTO products (name,slug,short_description,description,price,discount_percent,image_url,digital_file,category,version,file_path,license_prefix,is_active,status,is_hidden,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,"active",0,NOW())')->execute([$name,$slug,$short?:null,$desc,$price,$discountIns,$imgUrl,$dfile?:null,$cat?:null,$ver,$fp,$pre?:null]); }

        catch (\PDOException $e) { error_log('[NS] product_add: '.$e->getMessage()); redirect_back(__('shop.product_add_fail'), 'error'); }

        audit_log($db, 'create', 'products', (int)$db->lastInsertId(), $name, '/admin/products.php');
        plan_product_bump($db, 1);
        redirect_back(__('bcat.product_added', ['v' => $name]));
    case 'product_edit':

        require_resource('products');

        $id    = (int)($_POST['id'] ?? 0);

        $name  = trim($_POST['name'] ?? '');

        $desc  = nx_clean_html(trim($_POST['description'] ?? ''), 'rich');

        $priceRaw = $_POST['price'] ?? 0;
        if (!is_numeric($priceRaw)) redirect_back(__('bcat.price_invalid'), 'error');
        $price = (float)$priceRaw;
        $discount = (int)($_POST['discount_percent'] ?? 0);
        if ($discount < 0) $discount = 0;
        if ($discount > 90) $discount = 90;

        $cat   = trim($_POST['category'] ?? '');

        $ver   = trim($_POST['version'] ?? '1.0.0');

        $pre   = strtoupper(trim($_POST['license_prefix'] ?? ''));

        $short = trim(strip_tags($_POST['short_description'] ?? ''));

        $dfile = trim($_POST['digital_file'] ?? '');

        $stat  = in_array($_POST['status'] ?? '', ['active','draft','hidden']) ? $_POST['status'] : 'draft';

        if (!$id || !$name) redirect_back(__('bcat.missing_info'), 'error');

        if ($price < 0) redirect_back(__('bcat.price_invalid'), 'error');

        $imgUrl = null;

        if (!empty($_FILES['cover_image']['tmp_name'])) {

            if ((int)($_FILES['cover_image']['size'] ?? 0) > 8388608) redirect_back(__('bcat.img_max_8mb'), 'error');

            if (!is_uploaded_file($_FILES['cover_image']['tmp_name'])) redirect_back(__('file.invalid'), 'error');

            $fi = new finfo(FILEINFO_MIME_TYPE); $mime = $fi->file($_FILES['cover_image']['tmp_name']);

            if (!in_array($mime, ['image/jpeg','image/png','image/webp','image/gif'], true)) redirect_back(__('bcat.img_format_invalid'), 'error');

            $dir = ROOT_PATH . '/uploads/products/covers/'; if (!is_dir($dir)) mkdir($dir, 0755, true);

            $sn = bin2hex(random_bytes(16)) . '.webp'; $dp = $dir . $sn;

            $src = image_from_mime($_FILES['cover_image']['tmp_name'], $mime);

            if ($src) { $sw=imagesx($src); $sh=imagesy($src); $r=max(1920/$sw,1080/$sh); $nw=(int)round($sw*$r); $nh=(int)round($sh*$r); $ox=(int)(($nw-1920)/2); $oy=(int)(($nh-1080)/2); $c=imagecreatetruecolor(1920,1080); $t=imagecreatetruecolor($nw,$nh); imagecopyresampled($t,$src,0,0,0,0,$nw,$nh,$sw,$sh); imagecopy($c,$t,0,0,$ox,$oy,1920,1080); imagewebp($c,$dp,85); imagedestroy($src); imagedestroy($t); imagedestroy($c); $imgUrl='/uploads/products/covers/'.$sn; }

        }

        $fp = null;

        if (!empty($_FILES['product_file']['tmp_name'])) {

            if ((int)($_FILES['product_file']['size'] ?? 0) > 33554432) redirect_back(__('bcat.file_max_32mb'), 'error');

            $ext = strtolower(pathinfo($_FILES['product_file']['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, ['zip','rar','7z','jar','tar','gz'], true)) redirect_back(__('bcat.file_type_invalid'), 'error');

            $oRow=$db->prepare('SELECT file_path FROM products WHERE id=?'); $oRow->execute([$id]); $oFile=$oRow->fetchColumn();

            nx_safe_unlink_product_file($oFile);

            $ud = ROOT_PATH . '/uploads/products/'; if (!is_dir($ud)) mkdir($ud, 0755, true);

            $sn2 = bin2hex(random_bytes(16)) . '.' . $ext;

            if (move_uploaded_file($_FILES['product_file']['tmp_name'], $ud . $sn2)) $fp = '/uploads/products/' . $sn2;

        }

        try {

            $fields = 'name=?,short_description=?,description=?,price=?,discount_percent=?,digital_file=?,category=?,version=?,license_prefix=?,status=?';

            $vals   = [$name,$short?:null,$desc,$price,$discount,$dfile?:null,$cat?:null,$ver,$pre?:null,$stat];

            if ($imgUrl) { $fields .= ',image_url=?'; $vals[] = $imgUrl; }

            if ($fp)     { $fields .= ',file_path=?';  $vals[] = $fp; }

            $vals[] = $id;

            $db->prepare("UPDATE products SET {$fields} WHERE id=?")->execute($vals);

        } catch (\PDOException $e) { error_log('[NS] product_edit: '.$e->getMessage()); redirect_back(__('shop.product_edit_fail'), 'error'); }

        audit_log($db, 'update', 'products', $id, $name, '/admin/products.php?edit=' . $id);
        redirect_back(__('bcat.product_updated', ['v' => $name]));
    case 'product_save':

        require_resource('products');

        $pId    = (int)($_POST['id'] ?? 0);

        $pName  = trim($_POST['name'] ?? '');

        $pDesc  = nx_clean_html(trim($_POST['description'] ?? ''), 'rich');

        $pPriceRaw = $_POST['price'] ?? 0;
        if (!is_numeric($pPriceRaw)) redirect_back(__('bcat.price_invalid'), 'error');
        $pPrice = (float)$pPriceRaw;
        $pDiscount = (int)($_POST['discount_percent'] ?? 0);
        if ($pDiscount < 0) $pDiscount = 0;
        if ($pDiscount > 90) $pDiscount = 90;

        $pCat   = trim($_POST['category'] ?? '');

        $pVer   = trim($_POST['version'] ?? '1.0.0');
        $cvVer = trim($_POST['cv_version'] ?? '');
        if ($cvVer !== '') $pVer = mb_substr($cvVer, 0, 20);

        $pPre   = strtoupper(trim($_POST['license_prefix'] ?? ''));

        $pShort = trim(strip_tags($_POST['short_description'] ?? ''));

        $pNotice = trim(strip_tags($_POST['user_notice'] ?? ''));

        $pDfile = trim($_POST['digital_file'] ?? '');

        $pStatus = in_array($_POST['status'] ?? '', ['active','draft','hidden']) ? $_POST['status'] : 'draft';

        if (!$pName || $pPrice < 0) redirect_back(__('bcat.product_price_required'), 'error');

        $pSlug = preg_replace('/[^a-z0-9]+/', '-', strtolower(substr($pName, 0, 80)));

        $pSlug = trim($pSlug, '-');

        if (!strlen($pSlug)) redirect_back(__('bcat.product_name_valid'), 'error');

        $base = $pSlug; $si = 1;

        while (true) { $chk = $db->prepare('SELECT id FROM products WHERE slug=? AND id!=?'); $chk->execute([$pSlug, $pId]); if (!$chk->fetch()) break; $pSlug = $base . '-' . $si++; }

        $pImgUrl = nx_safe_url(trim($_POST['image_url'] ?? ''));

        $pDlink  = nx_safe_url(trim($_POST['download_link'] ?? ''));

        $pImg = $pImgUrl !== '' ? $pImgUrl : null;

        if ($pId <= 0) {
            $planPLim2 = plan_product_limit();
            $planPCount2 = plan_product_count($db);
            if ($planPLim2 >= 0 && $planPCount2 >= $planPLim2) redirect_back(__('plan.product_limit_reached', ['have' => $planPCount2, 'limit' => $planPLim2]), 'error');
        }

        if (!empty($_FILES['cover_image']['tmp_name'])) {

            if ((int)($_FILES['cover_image']['size'] ?? 0) > 8388608) redirect_back(__('bcat.img_max_8mb'), 'error');

            if (!is_uploaded_file($_FILES['cover_image']['tmp_name'])) redirect_back(__('file.invalid'), 'error');

            $fi = new finfo(FILEINFO_MIME_TYPE); $mime = $fi->file($_FILES['cover_image']['tmp_name']);

            if (!in_array($mime, ['image/jpeg','image/png','image/webp','image/gif'], true)) redirect_back(__('bcat.img_format_invalid'), 'error');

            $dir = ROOT_PATH . '/uploads/products/covers/'; if (!is_dir($dir)) mkdir($dir, 0755, true);

            $sn = bin2hex(random_bytes(16)) . '.webp'; $dp = $dir . $sn;

            $src = image_from_mime($_FILES['cover_image']['tmp_name'], $mime);

            if ($src) { $sw=imagesx($src); $sh=imagesy($src); $r=max(1920/$sw,1080/$sh); $nw=(int)round($sw*$r); $nh=(int)round($sh*$r); $ox=(int)(($nw-1920)/2); $oy=(int)(($nh-1080)/2); $c=imagecreatetruecolor(1920,1080); $t=imagecreatetruecolor($nw,$nh); imagecopyresampled($t,$src,0,0,0,0,$nw,$nh,$sw,$sh); imagecopy($c,$t,0,0,$ox,$oy,1920,1080); imagewebp($c,$dp,85); imagedestroy($src); imagedestroy($t); imagedestroy($c); $pImg='/uploads/products/covers/'.$sn; }

        }

        $pFile = null;

        if (!empty($_FILES['product_file']['tmp_name'])) {

            if ($pId) { $oRow=$db->prepare('SELECT file_path FROM products WHERE id=?'); $oRow->execute([$pId]); $oFile=$oRow->fetchColumn(); nx_safe_unlink_product_file($oFile); }

            $ud = ROOT_PATH . '/uploads/products/'; if (!is_dir($ud)) mkdir($ud, 0755, true);

            if ((int)($_FILES['product_file']['size'] ?? 0) > 33554432) redirect_back(__('bcat.file_max_32mb'), 'error');

            $ext = strtolower(pathinfo($_FILES['product_file']['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, ['zip','rar','7z','jar','tar','gz'], true)) redirect_back(__('bcat.file_type_invalid'), 'error');

            $sn2 = bin2hex(random_bytes(16)) . '.' . $ext;

            if (move_uploaded_file($_FILES['product_file']['tmp_name'], $ud . $sn2)) $pFile = '/uploads/products/' . $sn2;

        }

        try {

            if ($pId > 0) {

                $fields = 'name=?,slug=?,short_description=?,user_notice=?,description=?,price=?,discount_percent=?,digital_file=?,category=?,version=?,license_prefix=?,status=?,image_url=?,download_link=?';

                $vals = [$pName, $pSlug, $pShort?:null, $pNotice?:null, $pDesc, $pPrice, $pDiscount, $pDfile?:null, $pCat?:null, $pVer, $pPre?:null, $pStatus, $pImg, $pDlink?:null];

                if ($pFile) { $fields .= ',file_path=?'; $vals[] = $pFile; }

                $vals[] = $pId;

                $db->prepare("UPDATE products SET {$fields} WHERE id=?")->execute($vals);

            } else {

                $db->prepare('INSERT INTO products (name,slug,short_description,user_notice,description,price,discount_percent,image_url,digital_file,download_link,category,version,file_path,license_prefix,is_active,status,is_hidden,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,0,NOW())')->execute([$pName,$pSlug,$pShort?:null,$pNotice?:null,$pDesc,$pPrice,$pDiscount,$pImg,$pDfile?:null,$pDlink?:null,$pCat?:null,$pVer,$pFile,$pPre?:null,$pStatus]);

                $pId = (int)$db->lastInsertId();
                plan_product_bump($db, 1);

            }

            if ($pStatus === 'active') {
                $cvSum = trim($_POST['cv_summary'] ?? '');
                $cvBody = nx_clean_html(trim($_POST['cv_body'] ?? ''), 'rich');
                $cvNotify = (($_POST['cv_notify'] ?? '1') === '1') ? 1 : 0;
                if ($cvVer !== '' || $cvSum !== '' || $cvBody !== '') {
                    if ($cvSum === '' && $cvBody !== '') {
                        $cvSum = mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags($cvBody))), 0, 180);
                    }
                    try { $db->prepare('INSERT INTO product_versions (product_id,version,summary,changelog,has_file) VALUES (?,?,?,?,?)')->execute([$pId, $pVer, mb_substr($cvSum,0,255), $cvBody, $cvNotify]); } catch (PDOException $e) {}
                }
            }

            $msg = $pStatus === 'active' ? __('bcat.product_published') : ($pStatus === 'hidden' ? __('bcat.product_hidden') : __('bcat.draft_saved'));

            $pRedirect = $pStatus === 'active' ? '/admin/products.php?flash='.urlencode('success:'.$msg) : '/admin/product-editor.php?id='.$pId.'&flash='.urlencode('success:'.$msg);

            audit_log($db, 'update', 'products', $pId, $pName, '/admin/products.php?edit=' . $pId);
            header('Location: '.$pRedirect, true, 302); exit;

        } catch (\PDOException $e) { error_log('[NS] product_save: '.$e->getMessage()); redirect_back(__('shop.product_add_fail'), 'error'); }
    case 'version_list':
        require_resource('products');
        $vPid = (int)($_POST['product_id'] ?? 0);
        if (!$vPid) json_resp(false, __('shop.invalid_product'));
        try {
            $vp = $db->prepare('SELECT id,name,version FROM products WHERE id=?');
            $vp->execute([$vPid]);
            $prod = $vp->fetch();
            if (!$prod) json_resp(false, __('shop.product_missing'));
            $vl = $db->prepare('SELECT * FROM product_versions WHERE product_id=? ORDER BY id DESC');
            $vl->execute([$vPid]);
            json_resp(true, '', ['product' => $prod, 'versions' => $vl->fetchAll()]);
        } catch (PDOException $e) { error_log('[NS] version_list: '.$e->getMessage()); json_resp(false, __('shop.list_fail')); }
    case 'version_save':
        require_resource('products');
        $vId = (int)($_POST['id'] ?? 0);
        $vPid = (int)($_POST['product_id'] ?? 0);
        $vVer = mb_substr(trim($_POST['version'] ?? ''), 0, 20);
        $vSum = mb_substr(trim($_POST['summary'] ?? ''), 0, 255);
        $vLog = nx_clean_html(trim($_POST['changelog'] ?? ''), 'rich');
        $vFile = (($_POST['has_file'] ?? '1') === '1') ? 1 : 0;
        if (!$vPid) json_resp(false, __('shop.invalid_product'));
        if ($vVer === '' && $vSum === '' && $vLog === '') json_resp(false, __('version.need_text'));
        if ($vSum === '' && $vLog !== '') $vSum = mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags($vLog))), 0, 180);
        try {
            $chk = $db->prepare('SELECT id FROM products WHERE id=?');
            $chk->execute([$vPid]);
            if (!$chk->fetch()) json_resp(false, __('shop.product_missing'));
            if ($vId > 0) {
                $db->prepare('UPDATE product_versions SET version=?, summary=?, changelog=?, has_file=?, updated_at=NOW() WHERE id=? AND product_id=?')->execute([$vVer, $vSum, $vLog, $vFile, $vId, $vPid]);
            } else {
                $db->prepare('INSERT INTO product_versions (product_id,version,summary,changelog,has_file) VALUES (?,?,?,?,?)')->execute([$vPid, $vVer, $vSum, $vLog, $vFile]);
                $vId = (int)$db->lastInsertId();
            }
            $mx = $db->prepare('SELECT MAX(id) FROM product_versions WHERE product_id=?');
            $mx->execute([$vPid]);
            if ((int)$mx->fetchColumn() === $vId && $vVer !== '') {
                $db->prepare('UPDATE products SET version=? WHERE id=?')->execute([$vVer, $vPid]);
            }
            audit_log($db, 'update', 'versions', $vId, ($vVer !== '' ? $vVer . ' ' : '') . '#' . $vPid, '/admin/products.php?edit=' . $vPid);
            json_resp(true, __('version.saved'));
        } catch (PDOException $e) { error_log('[NS] version_save: '.$e->getMessage()); json_resp(false, __('bcat.save_fail')); }
    case 'version_delete':
        require_resource('products');
        $vId = (int)($_POST['id'] ?? 0);
        if (!$vId) json_resp(false, __('err.invalid_id'));
        try {
            $vr = $db->prepare('SELECT product_id FROM product_versions WHERE id=?');
            $vr->execute([$vId]);
            $vPid = (int)($vr->fetchColumn() ?? 0);
            if (!$vPid) json_resp(false, __('shop.not_found'));
            $mx = $db->prepare('SELECT MAX(id) FROM product_versions WHERE product_id=?');
            $mx->execute([$vPid]);
            $wasLatest = ((int)$mx->fetchColumn() === $vId);
            $db->prepare('DELETE FROM product_versions WHERE id=?')->execute([$vId]);
            if ($wasLatest) {
                $nl = $db->prepare('SELECT version FROM product_versions WHERE product_id=? ORDER BY id DESC LIMIT 1');
                $nl->execute([$vPid]);
                $nv = $nl->fetchColumn();
                if ($nv !== false && $nv !== '') $db->prepare('UPDATE products SET version=? WHERE id=?')->execute([$nv, $vPid]);
            }
            audit_log($db, 'delete', 'versions', $vId, '#' . $vPid, '/admin/products.php?edit=' . $vPid);
            json_resp(true, __('version.deleted'));
        } catch (PDOException $e) { error_log('[NS] version_delete: '.$e->getMessage()); json_resp(false, __('cart.remove_fail')); }
    case 'product_delete':

        require_resource('products');

        $id = (int)($_POST['id'] ?? 0);

        if (!$id) redirect_back(__('err.invalid_id'), 'error');

        try {

            $delChk = $db->prepare('SELECT id,file_path,image_url FROM products WHERE id=?');

            $delChk->execute([$id]);

            $delRow = $delChk->fetch();

            if (!$delRow) redirect_back(__('shop.product_missing'), 'error');

            try {
                $gDel = $db->prepare('SELECT image_url FROM product_images WHERE product_id=?');
                $gDel->execute([$id]);
                foreach ($gDel->fetchAll(PDO::FETCH_COLUMN) as $gUrl) nx_safe_unlink_product_file($gUrl);
            } catch (\Throwable $e) {}

            nx_safe_unlink_product_file($delRow['file_path'] ?? null);

            nx_safe_unlink_product_file($delRow['image_url'] ?? null);

            $pDelName = '';
            try { $nmSt = $db->prepare('SELECT name FROM products WHERE id=?'); $nmSt->execute([$id]); $pDelName = (string)($nmSt->fetchColumn() ?: ''); } catch (\Throwable $e) {}
            $db->prepare('DELETE FROM products WHERE id=?')->execute([$id]);

            plan_product_bump($db, -1);
            audit_log($db, 'delete', 'products', $id, $pDelName !== '' ? $pDelName : '#' . $id, '/admin/products.php');
            redirect_back(__('bcat.product_deleted'));

        } catch (\PDOException $e) { error_log('[NS] product_delete: '.$e->getMessage()); redirect_back(__('bcat.product_delete_fail'), 'error'); }
    case 'product_toggle_hidden':

        require_resource('products');

        $id = (int)($_POST['id'] ?? 0);

        if (!$id) redirect_back(__('err.invalid_id'), 'error');

        try {

            $hidChk = $db->prepare('SELECT id FROM products WHERE id=?');

            $hidChk->execute([$id]);

            if (!$hidChk->fetch()) redirect_back(__('shop.product_missing'), 'error');

            $db->prepare('UPDATE products SET is_hidden=IF(is_hidden=1,0,1) WHERE id=?')->execute([$id]);

            audit_log($db, 'update', 'products', $id, '#' . $id, '/admin/products.php?edit=' . $id);
            redirect_back(__('bcat.visibility_toggled'));

        } catch (\PDOException $e) { error_log('[NS] product_toggle_hidden: '.$e->getMessage()); redirect_back(__('shop.slider_fail'), 'error'); }
    case 'product_stock':

        require_resource('products');

        require_once ROOT_PATH . '/core/stock.php';
require_once ROOT_PATH . '/core/shopier.php';

        $pid = (int)($_POST['id'] ?? 0);

        $op  = $_POST['op'] ?? '';

        $qty = (int)($_POST['qty'] ?? 1);

        if (!$pid || $qty < 1) json_resp(false, __('err.invalid_request'));

        $chk = $db->prepare('SELECT id FROM products WHERE id=?');

        $chk->execute([$pid]);

        if (!$chk->fetch()) json_resp(false, __('shop.product_missing'));

        if ($op === 'unlimited') {

            $db->prepare('UPDATE products SET stock_type="unlimited" WHERE id=?')->execute([$pid]);

            audit_log($db, 'update', 'stock', $pid, '#' . $pid, '/admin/products.php?edit=' . $pid);
            json_resp(true, __('stock.unlimited_ok'), ['stock_type' => 'unlimited', 'available' => -1]);

        } elseif ($op === 'limited_keep') {

            $db->prepare('UPDATE products SET stock_type="limited", stock=GREATEST((SELECT COUNT(*) FROM product_stocks WHERE product_id=? AND used=0),0) WHERE id=?')->execute([$pid,$pid]);

            $av = stock_items_available($db,$pid);

            audit_log($db, 'update', 'stock', $pid, '#' . $pid, '/admin/products.php?edit=' . $pid);
            json_resp(true, __('stock.limited_ok'), ['stock_type' => 'limited', 'available' => $av]);

        } elseif ($op === 'set') {

            $db->prepare('UPDATE products SET stock_type="limited" WHERE id=?')->execute([$pid]);

            $db->prepare('UPDATE product_stocks SET used=1, used_at=NOW() WHERE product_id=? AND id IN (SELECT id FROM (SELECT id FROM product_stocks WHERE product_id=? AND used=0 ORDER BY id ASC LIMIT ?) z)')->execute([$pid,$pid, (int)max(0, stock_items_available($db,$pid)-$qty)]);

            $db->prepare('UPDATE products SET stock=GREATEST((SELECT COUNT(*) FROM product_stocks WHERE product_id=? AND used=0),0) WHERE id=?')->execute([$pid,$pid]);

            $av = stock_items_available($db,$pid);

            audit_log($db, 'update', 'stock', $pid, '#' . $pid, '/admin/products.php?edit=' . $pid);
            json_resp(true, __('bcat.stock_set', ['v' => $av]), ['stock_type' => 'limited', 'available' => $av]);

        } elseif ($op === 'delete') {

            $recordId = (int)($_POST['record_id'] ?? $_POST['qty'] ?? 0);

            $ownStock = $db->prepare('SELECT product_id FROM product_stocks WHERE id=?');

            $ownStock->execute([$recordId]);

            $ownRow = $ownStock->fetch();

            if (!$ownRow || (int)$ownRow['product_id'] !== $pid) json_resp(false, __('stock.missing'));

            stock_item_delete($db, $recordId);

            $av = stock_items_available($db,$pid);

            audit_log($db, 'delete', 'stock', $pid, '#' . $pid, '/admin/products.php?edit=' . $pid);
            json_resp(true, __('stock.deleted'), ['available' => $av, 'total' => (int)(stock_info($db,$pid)['total_stock'] ?? 0)]);

        }

        json_resp(false, __('err.unknown_action'));
    case 'product_stock_items':

        require_resource('products');

        require_once ROOT_PATH . '/core/stock.php';
require_once ROOT_PATH . '/core/shopier.php';

        $pid = (int)($_POST['id'] ?? 0);

        $op  = $_POST['op'] ?? '';

        if (!$pid) json_resp(false, __('err.invalid_request'));

        $chk = $db->prepare('SELECT id FROM products WHERE id=?');

        $chk->execute([$pid]);

        if (!$chk->fetch()) json_resp(false, __('shop.product_missing'));

        if ($op === 'add') {

            $contents = preg_split('/\r\n|\r|\n/', trim((string)($_POST['contents'] ?? '')));

            $added = stock_item_add($db, $pid, $contents);

            $db->prepare('UPDATE products SET stock_type="limited", stock=GREATEST((SELECT COUNT(*) FROM product_stocks WHERE product_id=? AND used=0),0) WHERE id=?')->execute([$pid,$pid]);

            audit_log($db, 'create', 'stock', $pid, '#' . $pid, '/admin/products.php?edit=' . $pid);
            json_resp(true, __('bcat.stock_added', ['v' => $added]), ['available' => stock_items_available($db,$pid), 'total' => (int)(stock_info($db,$pid)['total_stock'] ?? 0)]);

        } elseif ($op === 'update') {

            $rid = (int)($_POST['record_id'] ?? 0);

            $content = trim((string)($_POST['content'] ?? ''));

            if (!$rid) json_resp(false, __('err.invalid_record'));

            $db->prepare('UPDATE product_stocks SET content=? WHERE id=? AND product_id=?')->execute([$content,$rid,$pid]);

            audit_log($db, 'update', 'stock', $pid, '#' . $pid, '/admin/products.php?edit=' . $pid);
            json_resp(true, __('stock.content_ok'));

        }

        json_resp(false, __('err.unknown_action'));
    case 'stock_bulk_items':

        require_resource('products');

        require_once ROOT_PATH . '/core/stock.php';
require_once ROOT_PATH . '/core/shopier.php';

        $rawIds = $_POST['product_ids'] ?? [];

        if (is_string($rawIds)) $rawIds = explode(',', $rawIds);

        $ids = array_values(array_filter(array_map('intval', $rawIds)));

        if (!$ids) json_resp(false, __('shop.no_product'));

        $contents = array_values(array_filter(array_map(function($c){ return trim((string)$c); }, preg_split('/\r\n|\r|\n/', trim((string)($_POST['contents'] ?? '')))), function($c){ return $c !== ''; }));

        if (!$contents) json_resp(false, __('aprod.contents_required'));

        $done = 0; $total = 0;

        $bchk = $db->prepare('SELECT id FROM products WHERE id=?');

        foreach ($ids as $bid) {

            $bchk->execute([$bid]);

            if (!$bchk->fetch()) continue;

            $n = stock_item_add($db, $bid, $contents);

            $db->prepare('UPDATE products SET stock_type="limited", stock=GREATEST((SELECT COUNT(*) FROM product_stocks WHERE product_id=? AND used=0),0) WHERE id=?')->execute([$bid,$bid]);

            $done++; $total += $n;

        }

        audit_log($db, 'create', 'stock', 0, $done . 'x' . $total, '/admin/products.php');
        json_resp(true, __('bcat.bulk_stock_added', ['done' => $done, 'total' => $total]));
    case 'stock_bulk_off':

        require_resource('products');

        $rawIds = $_POST['product_ids'] ?? [];

        if (is_string($rawIds)) $rawIds = explode(',', $rawIds);

        $ids = array_values(array_filter(array_map('intval', $rawIds)));

        if (!$ids) json_resp(false, __('shop.no_product'));

        $done = 0;

        $bchk = $db->prepare('SELECT id FROM products WHERE id=?');

        $bup  = $db->prepare('UPDATE products SET stock_type="unlimited" WHERE id=?');

        foreach ($ids as $bid) {

            $bchk->execute([$bid]);

            if (!$bchk->fetch()) continue;

            $bup->execute([$bid]);

            $done++;

        }

        audit_log($db, 'update', 'stock', 0, $done . 'x', '/admin/products.php');
        json_resp(true, __('bcat.bulk_unlimited', ['v' => $done]));



    
    case 'reference_save':

        require_resource('references');

        if (!feature_active('references')) redirect_back(__('bcat.refs_off'), 'error');

        $opRef = $_POST['op'] ?? '';

        $refGo = function(string $msg, string $type = 'success', ?int $id = null, bool $new = false): void {

            $qs = [];

            if ($new) $qs[] = 'new=1';

            if ($id) $qs[] = 'edit='.$id;

            if ($msg) $qs[] = 'flash='.urlencode("{$type}:{$msg}");

            header('Location: /admin/references.php'.($qs ? '?'.implode('&', $qs) : ''), true, 302);

            exit;

        };

        if (in_array($opRef, ['add', 'edit'], true)) {

            $refId     = (int)($_POST['id'] ?? 0);

            $refName   = trim($_POST['name'] ?? '');

            $refTitle  = trim($_POST['title'] ?? '');

            $refPhoto  = nx_safe_url(trim($_POST['photo_url'] ?? ''));

            $refRating = (int)($_POST['rating'] ?? 5);

            if ($refRating < 1) $refRating = 1;

            if ($refRating > 5) $refRating = 5;

            $refMsg    = trim($_POST['message'] ?? '');

            $refSort   = (int)($_POST['sort_order'] ?? 0);

            $refActive = isset($_POST['is_active']) && $_POST['is_active'] === '1' ? 1 : 0;

            if ($refName === '') $refGo(__('bcat.name_required'), 'error', $refId ?: null, !$refId);

            if ($opRef === 'add') {

                $db->prepare('INSERT INTO `references` (name,title,photo_url,rating,message,sort_order,is_active) VALUES (?,?,?,?,?,?,?)')

                   ->execute([$refName,$refTitle,$refPhoto,$refRating,$refMsg,$refSort,$refActive]);

                audit_log($db, 'create', 'references', (int)$db->lastInsertId(), $refName, '/admin/references.php');
                $refGo(__('bcat.ref_added'));

            } else {

                if (!$refId) $refGo(__('err.invalid_id'), 'error');

                $db->prepare('UPDATE `references` SET name=?,title=?,photo_url=?,rating=?,message=?,sort_order=?,is_active=? WHERE id=?')

                   ->execute([$refName,$refTitle,$refPhoto,$refRating,$refMsg,$refSort,$refActive,$refId]);

                audit_log($db, 'update', 'references', $refId, $refName, '/admin/references.php');
                $refGo(__('bcat.ref_updated'), 'success', $refId);

            }

        }

        if ($opRef === 'delete') {

            $refId = (int)($_POST['id'] ?? 0);

            if (!$refId) $refGo(__('err.invalid_id'), 'error');

            $db->prepare('DELETE FROM `references` WHERE id=?')->execute([$refId]);

            audit_log($db, 'delete', 'references', $refId, '#' . $refId, '/admin/references.php');
            $refGo(__('bcat.ref_deleted'));

        }

        if ($opRef === 'toggle_active') {

            $refId = (int)($_POST['id'] ?? 0);

            if (!$refId) $refGo(__('err.invalid_id'), 'error');

            $db->prepare('UPDATE `references` SET is_active=IF(is_active=1,0,1) WHERE id=?')->execute([$refId]);

            audit_log($db, 'update', 'references', $refId, '#' . $refId, '/admin/references.php');
            $refGo(__('bcat.ref_toggled'));

        }

        $refGo(__('err.unknown_action'), 'error');
    case 'reference_settings':

        require_resource('references');

        if (!feature_active('references')) redirect_back(__('bcat.refs_off'), 'error');

        $refMode = $_POST['mode'] ?? 'grid';

        if (!in_array($refMode, ['grid', 'slider'], true)) $refMode = 'grid';

        $refAuto = ($_POST['autoplay'] ?? '0') === '1' ? '1' : '0';

        $db->prepare("UPDATE settings SET `value`=? WHERE `key`='references_mode'")->execute([$refMode]);

        $db->prepare("UPDATE settings SET `value`=? WHERE `key`='references_autoplay'")->execute([$refAuto]);

        header('Location: /admin/references.php?flash='.urlencode('success:'.__('bcat.ref_view_updated')), true, 302);

        exit;
    case 'announcement_save':

        require_resource('announcements');

        if (!feature_active('announcements')) redirect_back(__('bcat.ann_off'), 'error');

        $annId    = (int)($_POST['id'] ?? 0);

        $annTitle = trim($_POST['title'] ?? '');

        $annBody  = nx_clean_html(trim($_POST['content'] ?? ''), 'rich');

        $annImg   = nx_safe_url(trim($_POST['image_url'] ?? ''));

        $annStatus = in_array($_POST['status'] ?? '', ['published','hidden','draft']) ? $_POST['status'] : 'draft';

        if (!$annTitle || !$annBody) redirect_back(__('bcat.ann_title_body_required'), 'error');

        $annSlug = preg_replace('/[^a-z0-9]+/', '-', strtolower(substr($annTitle, 0, 80)));

        $annSlug = trim($annSlug, '-'); $base = $annSlug; $si = 1;

        if (!strlen($annSlug)) redirect_back(__('bcat.title_valid'), 'error');

        while (true) { $sc=$db->prepare('SELECT id FROM announcements WHERE slug=? AND id!=?'); $sc->execute([$annSlug,$annId]); if (!$sc->fetch()) break; $annSlug=$base.'-'.$si++; }

        $isFetch = ($_POST['is_fetch'] ?? '') === '1';

        try {

            if ($annId > 0) {

                $f = 'title=?,slug=?,content=?,status=?'; $v = [$annTitle,$annSlug,$annBody,$annStatus];

                if ($annImg) { $f .= ',image_url=?'; $v[] = $annImg; }

                $v[] = $annId;

                $db->prepare("UPDATE announcements SET {$f} WHERE id=?")->execute($v);

                $msg = $annStatus === 'published' ? __('bcat.ann_published') : ($annStatus === 'hidden' ? __('bcat.ann_hidden') : __('bcat.draft_saved'));

                $redirect = $annStatus === 'published' ? '/admin/announcements.php?flash='.urlencode('success:'.$msg) : '/admin/announcement-editor.php?id='.$annId.'&flash='.urlencode('success:'.$msg);

                audit_log($db, 'update', 'announcements', $annId, $annTitle, '/admin/announcements.php');
                if ($isFetch) json_resp(true, $msg, ['redirect'=>$redirect]);

                header('Location: '.$redirect, true, 302); exit;

            } else {

                $db->prepare('INSERT INTO announcements (title,slug,content,image_url,status,created_at) VALUES (?,?,?,?,?,NOW())')->execute([$annTitle,$annSlug,$annBody,$annImg,$annStatus]);

                $newId = (int)$db->lastInsertId();

                $msg = $annStatus === 'published' ? __('bcat.ann_published') : ($annStatus === 'hidden' ? __('bcat.ann_hidden') : __('bcat.draft_saved'));

                $redirect = $annStatus === 'published' ? '/admin/announcements.php?flash='.urlencode('success:'.$msg) : '/admin/announcement-editor.php?id='.$newId.'&flash='.urlencode('success:'.$msg);

                audit_log($db, 'create', 'announcements', $newId, $annTitle, '/admin/announcements.php');
                if ($isFetch) json_resp(true, $msg, ['redirect'=>$redirect]);

                header('Location: '.$redirect, true, 302); exit;

            }

        } catch (\PDOException $e) { error_log('[NS] announcement_save: '.$e->getMessage()); redirect_back(__('bcat.ann_save_fail'), 'error'); }
    case 'asset_upload':

        $assetCtxMap = ['categories'=>'categories','products'=>'products','announcements'=>'announcements','references'=>'references','ticket_categories'=>'ticket_categories','settings'=>'settings','roles'=>'permissions'];
        $assetCtx = $_POST['ctx'] ?? '';
        if (!isset($assetCtxMap[$assetCtx])) json_resp(false, __('err.invalid_request'));
        require_resource($assetCtxMap[$assetCtx]);

        $assetType = $_POST['asset_type'] ?? '';

        if (!in_array($assetType, ['logo','favicon','cover','caticon','roleicon'], true)) json_resp(false, __('err.invalid_type'));

        if (empty($_FILES['file']['tmp_name'])) json_resp(false, __('err.no_file'));

        if ((int)($_FILES['file']['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) json_resp(false, __('file.upload_fail'));

        if ((int)($_FILES['file']['size'] ?? 0) > 8388608) json_resp(false, __('bcat.file_max_8mb'));

        if (!is_uploaded_file($_FILES['file']['tmp_name'])) json_resp(false, __('file.invalid'));

        $fi = new finfo(FILEINFO_MIME_TYPE); $mime = $fi->file($_FILES['file']['tmp_name']);

        if (!in_array($mime, ['image/jpeg','image/png','image/webp','image/gif'], true)) json_resp(false, __('file.bad_image'));

        $ad = ROOT_PATH . '/uploads/logo/'; if (!is_dir($ad)) mkdir($ad, 0755, true);

        $sn = bin2hex(random_bytes(16)) . '.webp'; $fp = $ad . $sn; $src = image_from_mime($_FILES['file']['tmp_name'], $mime);

        if (!$src) json_resp(false, __('file.process_fail'));

        imagesavealpha($src, true);

        if ($assetType === 'cover') {

            $sw = imagesx($src); $sh = imagesy($src);

            $mw = 1920; $mh = 1080;

            $r = min($mw/$sw, $mh/$sh, 1);

            $nw = (int)round($sw*$r); $nh = (int)round($sh*$r);

            $c = image_alpha_canvas($nw, $nh);

            imagecopyresampled($c, $src, 0, 0, 0, 0, $nw, $nh, $sw, $sh);

            imagewebp($c, $fp, 85); imagedestroy($c);

        } elseif ($assetType === 'favicon') {

            $sw = imagesx($src); $sh = imagesy($src); $s = min(64, $sw, $sh);

            $c = image_alpha_canvas(64, 64);

            imagecopyresampled($c, $src, 0, 0, (int)(($sw-$s)/2), (int)(($sh-$s)/2), 64, 64, $s, $s);

            imagewebp($c, $fp, 90); imagedestroy($c);

        } elseif ($assetType === 'caticon' || $assetType === 'roleicon') {

            $sw = imagesx($src); $sh = imagesy($src); $s = min($sw, $sh);

            $c = image_alpha_canvas(64, 64);

            imagecopyresampled($c, $src, 0, 0, (int)(($sw-$s)/2), (int)(($sh-$s)/2), 64, 64, $s, $s);

            imagewebp($c, $fp, 90); imagedestroy($c);

        } else {

            $sw = imagesx($src); $sh = imagesy($src);

            $mw = 300; $mh = 80; $r = min($mw/$sw, $mh/$sh, 1);

            $nw = (int)round($sw*$r); $nh = (int)round($sh*$r);

            $c = image_alpha_canvas($nw, $nh);

            imagecopyresampled($c, $src, 0, 0, 0, 0, $nw, $nh, $sw, $sh);

            imagewebp($c, $fp, 90); imagedestroy($c);

        }

        imagedestroy($src);

        json_resp(true, __('file.uploaded'), ['url'=>'/uploads/logo/'.$sn]);
    case 'announcement_delete':

        require_resource('announcements');

        if (!feature_active('announcements')) redirect_back(__('bcat.ann_off'), 'error');

        $annId = (int)($_POST['id'] ?? 0);

        if (!$annId) redirect_back(__('err.invalid_id'), 'error');

        try { $db->prepare('DELETE FROM announcements WHERE id=?')->execute([$annId]); }

        catch (\PDOException $e) { error_log('[NS] announcement_delete: '.$e->getMessage()); redirect_back(__('cart.remove_fail'), 'error'); }

        audit_log($db, 'delete', 'announcements', $annId, '#' . $annId, '/admin/announcements.php');
        redirect_back(__('bcat.ann_deleted'));
    case 'faq_save':
        require_resource('products');
        $faqId = (int)($_POST['id'] ?? 0);
        $q = trim($_POST['question'] ?? '');
        $a = nx_clean_html(trim($_POST['answer'] ?? ''), 'rich');
        if ($q === '' || $a === '') json_resp(false, __('bcat.faq_required'));
        try {
            if ($faqId > 0) {
                $db->prepare("UPDATE faqs SET question=?, answer=? WHERE id=?")->execute([$q,$a,$faqId]);
                $newId = $faqId;
            } else {
                $max = (int)$db->query("SELECT COALESCE(MAX(sort_order),0) FROM faqs")->fetchColumn();
                $db->prepare("INSERT INTO faqs (question,answer,sort_order) VALUES (?,?,?)")->execute([$q,$a,$max+1]);
                $newId = (int)$db->lastInsertId();
            }
        } catch (\PDOException $e) { error_log('[faq_save] '.$e->getMessage()); json_resp(false, __('bcat.save_fail')); }
        audit_log($db, $faqId > 0 ? 'update' : 'create', 'products', 0, mb_substr($q, 0, 80), '/admin/faqs.php');
        json_resp(true, __('bcat.faq_saved'), ['id' => $newId ?? 0]);
    case 'faq_delete':
        require_resource('products');
        $faqId = (int)($_POST['id'] ?? 0);
        if (!$faqId) redirect_back(__('err.invalid_id'), 'error');
        try { $db->prepare("DELETE FROM faqs WHERE id=?")->execute([$faqId]); } catch (\PDOException $e) { error_log('[faq_delete] '.$e->getMessage()); redirect_back(__('cart.remove_fail'), 'error'); }
        audit_log($db, 'delete', 'products', 0, '#' . $faqId, '/admin/faqs.php');
        if (is_ajax()) json_resp(true, __('bcat.deleted')); else redirect_back(__('bcat.deleted'));
    case 'faq_reorder':
        require_resource('products');
        $ids = array_slice(array_filter(array_map('intval', explode(',', $_POST['ids'] ?? ''))), 0, 500);
        try { foreach ($ids as $i=>$id) $db->prepare("UPDATE faqs SET sort_order=? WHERE id=?")->execute([$i,$id]); } catch (\PDOException $e) {}
        if (is_ajax()) json_resp(true, __('msg.sorted')); else redirect_back(__('msg.sorted'));
    case 'product_image_add':

        require_resource('products');

        $pid = (int)($_POST['product_id'] ?? 0);

        if (!$pid || empty($_FILES['gallery_image']['tmp_name'])) redirect_back(__('err.invalid_request'), 'error');

        if ((int)($_FILES['gallery_image']['size'] ?? 0) > 8388608) redirect_back(__('bcat.img_max_8mb'), 'error');

        if (!is_uploaded_file($_FILES['gallery_image']['tmp_name'])) redirect_back(__('file.invalid'), 'error');

        $gChk = $db->prepare('SELECT id FROM products WHERE id=?');

        $gChk->execute([$pid]);

        if (!$gChk->fetch()) redirect_back(__('shop.product_missing'), 'error');

        $fi = new finfo(FILEINFO_MIME_TYPE); $mime = $fi->file($_FILES['gallery_image']['tmp_name']);

        if (!in_array($mime, ['image/jpeg','image/png','image/webp','image/gif'], true)) redirect_back(__('file.bad_image'), 'error');

        $gDir = ROOT_PATH . '/uploads/products/gallery/'; if (!is_dir($gDir)) mkdir($gDir, 0755, true);

        $sn = bin2hex(random_bytes(16)) . '.webp'; $dp = $gDir . $sn;

        $src = image_from_mime($_FILES['gallery_image']['tmp_name'], $mime);

        if (!$src) redirect_back(__('file.process_fail'), 'error');

        if ($src) { $sw=imagesx($src); $sh=imagesy($src); $r=max(1280/$sw,720/$sh); $nw=(int)round($sw*$r); $nh=(int)round($sh*$r); $ox=(int)(($nw-1280)/2); $oy=(int)(($nh-720)/2); $c=imagecreatetruecolor(1280,720); $t=imagecreatetruecolor($nw,$nh); imagecopyresampled($t,$src,0,0,0,0,$nw,$nh,$sw,$sh); imagecopy($c,$t,0,0,$ox,$oy,1280,720); imagewebp($c,$dp,85); imagedestroy($src); imagedestroy($t); imagedestroy($c);

            try { $db->prepare('INSERT INTO product_images (product_id,image_url) VALUES (?,?)')->execute([$pid,'/uploads/products/gallery/'.$sn]); }

            catch (\PDOException $e) { error_log('[NS] product_image_add: '.$e->getMessage()); redirect_back(__('bcat.img_save_fail'), 'error'); }

        }

        audit_log($db, 'create', 'products', $pid, '#' . $pid, '/admin/products.php?edit=' . $pid);
        redirect_back(__('bcat.img_added'));
    case 'legal_page_save':

        require_resource('legal');

        $slug = trim($_POST['slug'] ?? '');

        $content = nx_clean_html(trim($_POST['content'] ?? ''), 'rich');

        $allowedSlugs = ['cookie-policy','privacy-policy','terms-of-service','refund-policy'];

        if (!in_array($slug, $allowedSlugs, true)) json_resp(false, __('err.invalid_page'));

        try {

            $ck = $db->prepare('SELECT id FROM legal_pages WHERE slug=?');

            $ck->execute([$slug]);

            if ($ck->fetch()) {

                $db->prepare('UPDATE legal_pages SET content=? WHERE slug=?')->execute([$content, $slug]);

            } else {

                $titleMap = ['cookie-policy'=>__('legal.cookies'),'privacy-policy'=>__('legal.privacy'),'terms-of-service'=>__('legal.terms'),'refund-policy'=>__('legal.refund')];

                $title = $titleMap[$slug] ?? $slug;

                $db->prepare('INSERT INTO legal_pages (slug,title,content) VALUES (?,?,?)')->execute([$slug, $title, $content]);

            }

            audit_log($db, 'update', 'legal', 0, $slug, '/admin/legal.php');
            json_resp(true, __('apage.ok_saved'));

        } catch (\PDOException $e) { error_log('[NS] legal_page_save: '.$e->getMessage()); json_resp(false, __('bcat.save_fail')); }
    case 'seo_save':
    case 'seo_reset':

        if (!feature_active('seo')) json_resp(false, __('err.feature_off'));

        if (!auth_check()) json_resp(false, __('auth.login_required'));

        $seoRole = auth_user()['role'] ?? 'user';

        $seoCan = in_array($seoRole, ['admin', 'superadmin'], true);

        if (!$seoCan) {

            try {

                $st = $db->prepare('SELECT COUNT(*) FROM permissions WHERE role=? AND resource=?');

                $st->execute([$seoRole, 'seo']);

                $seoCan = (int)$st->fetchColumn() > 0;

            } catch (\PDOException $e) { $seoCan = false; }

        }

        if (!$seoCan) json_resp(false, __('err.no_perm'));

        $seoKey  = trim($_POST['seo_key'] ?? '');

        $seoType = $_POST['type'] ?? 'system';

        $seoPageId = (int)($_POST['page_id'] ?? 0);

        if (!preg_match('/^[a-z0-9_\-]+$/', $seoKey) || mb_strlen($seoKey) > 60) json_resp(false, __('err.invalid_key'));

        $seoTitle = $action === 'seo_reset' ? '' : trim(mb_substr((string)($_POST['title'] ?? ''), 0, 100, 'UTF-8'));

        $seoDesc  = $action === 'seo_reset' ? '' : trim(mb_substr((string)($_POST['description'] ?? ''), 0, 200, 'UTF-8'));

        try {

            if ($seoType === 'page' && $seoPageId > 0) {

                require_resource('custom_pages');

                if ($action === 'seo_reset') {

                    $up = $db->prepare('UPDATE custom_pages SET meta_description=NULL WHERE id=?');

                    $up->execute([$seoPageId]);

                } else {

                    $up = $db->prepare('UPDATE custom_pages SET title=?, meta_description=? WHERE id=?');

                    $up->execute([$seoTitle !== '' ? $seoTitle : null, $seoDesc !== '' ? $seoDesc : null, $seoPageId]);

                }

                json_resp(true, $action === 'seo_reset' ? __('bcat.seo_reset') : __('bcat.seo_saved'));

            }

            $upsert = $db->prepare('INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');

            $upsert->execute(['seo_' . $seoKey . '_title', $seoTitle]);

            $upsert->execute(['seo_' . $seoKey . '_description', $seoDesc]);

            audit_log($db, 'update', 'seo', 0, $seoKey, '/admin/seo.php');
            json_resp(true, $action === 'seo_reset' ? __('bcat.seo_reset') : __('bcat.seo_saved'));

        } catch (\PDOException $e) { error_log('[NS] seo_save: '.$e->getMessage()); json_resp(false, __('shop.save_fail')); }
    case 'admin_category_search':

        if (!auth_check()) json_resp(false, __('auth.login_required'));

        $role = auth_user()['role'] ?? 'user';

        $canSee = function(string $resource) use ($db, $role): bool {

            if ($role === 'superadmin' || $role === 'admin') return true;

            try {

                $st = $db->prepare('SELECT COUNT(*) FROM permissions WHERE role=? AND resource=?');

                $st->execute([$role, $resource]);

                return (int)$st->fetchColumn() > 0;

            } catch (\PDOException $e) { return false; }

        };

        $staticPages = [

            ['key'=>'dashboard',     'label'=>__('amenu.dashboard'),        'url'=>'/admin/dashboard.php',            'icon'=>'fa-house',         'resource'=>'dashboard'],
            ['key'=>'stats',         'label'=>__('amenu.stats'),   'url'=>'/admin/stats.php',                'icon'=>'fa-chart-line',    'resource'=>'stats'],
            ['key'=>'users',         'label'=>__('amenu.users'),    'url'=>'/admin/users.php',                'icon'=>'fa-users',         'resource'=>'users'],

            ['key'=>'users-balance', 'label'=>__('amenu.users_balance'), 'url'=>'/admin/users.php?tab=balance',    'icon'=>'fa-credit-card',   'resource'=>'users'],

            ['key'=>'permissions',   'label'=>__('amenu.permissions'),         'url'=>'/admin/permissions.php',          'icon'=>'fa-shield-halved', 'resource'=>'permissions'],

            ['key'=>'products',      'label'=>__('amenu.products'),         'url'=>'/admin/products.php',              'icon'=>'fa-box-open',      'resource'=>'products'],

            ['key'=>'purchases',     'label'=>__('amenu.purchases'),'url'=>'/admin/purchases.php',    'icon'=>'fa-bag-shopping',   'resource'=>'purchases'],

            ['key'=>'reviews',       'label'=>__('amenu.reviews'),'url'=>'/admin/reviews.php',              'icon'=>'fa-star',           'resource'=>'reviews'],

            ['key'=>'slider',        'label'=>__('amenu.slider'),          'url'=>'/admin/slider.php',                'icon'=>'fa-images',         'resource'=>'slider'],

            ['key'=>'audit-logs',    'label'=>__('amenu.audit_logs'),     'url'=>'/admin/audit-logs.php',             'icon'=>'fa-clock-rotate-left','resource'=>'audit-logs'],

            ['key'=>'categories',    'label'=>__('amenu.categories'),     'url'=>'/admin/categories.php',            'icon'=>'fa-tags',          'resource'=>'categories'],

            ['key'=>'licenses',      'label'=>__('amenu.licenses'),       'url'=>'/admin/licenses.php',              'icon'=>'fa-key',           'resource'=>'licenses'],

            ['key'=>'legal',         'label'=>__('amenu.legal'),  'url'=>'/admin/legal.php',                 'icon'=>'fa-gavel',         'resource'=>'legal'],

            ['key'=>'custom-pages',  'label'=>__('amenu.custom_pages'),   'url'=>'/admin/custom-pages.php',          'icon'=>'fa-file-lines',    'resource'=>'custom_pages'],

            ['key'=>'seo',           'label'=>__('amenu.seo'),    'url'=>'/admin/seo.php',                   'icon'=>'fa-magnifying-glass-chart','resource'=>'seo'],

            ['key'=>'coupons',       'label'=>__('amenu.coupons'),        'url'=>'/admin/coupons.php',               'icon'=>'fa-ticket',        'resource'=>'coupons'],

            ['key'=>'coupons-usage', 'label'=>__('amenu.coupons_usage'), 'url'=>'/admin/coupons.php?tab=usages',    'icon'=>'fa-list-check',    'resource'=>'coupons'],

            ['key'=>'references',   'label'=>__('amenu.references'),      'url'=>'/admin/references.php',             'icon'=>'fa-quote-right',   'resource'=>'references'],

            ['key'=>'themes',        'label'=>__('amenu.themes'),         'url'=>'/admin/themes.php',                'icon'=>'fa-swatchbook',    'resource'=>'themes'],

            ['key'=>'header-editor', 'label'=>__('amenu.header_editor'),   'url'=>'/admin/header-editor.php',         'icon'=>'fa-bars',          'resource'=>'themes'],

            ['key'=>'footer-editor', 'label'=>__('amenu.footer_editor'),   'url'=>'/admin/footer-editor.php',         'icon'=>'fa-bars-staggered','resource'=>'themes'],

            ['key'=>'announcements', 'label'=>__('amenu.announcements'),       'url'=>'/admin/announcements.php',         'icon'=>'fa-bullhorn',      'resource'=>'announcements'],

            ['key'=>'support',       'label'=>__('amenu.group_support'),          'url'=>'/admin/support.php',               'icon'=>'fa-headset',       'resource'=>'support'],

            ['key'=>'ticket-categories','label'=>__('amenu.ticket_categories'),'url'=>'/admin/ticket-categories.php','icon'=>'fa-tags',          'resource'=>'ticket_categories'],

            ['key'=>'settings-site', 'label'=>__('amenu.settings_site'),   'url'=>'/admin/settings.php?tab=site',     'icon'=>'fa-sliders',       'resource'=>'settings'],

            ['key'=>'settings-social','label'=>__('amenu.settings_social'), 'url'=>'/admin/settings.php?tab=social',   'icon'=>'fa-share-nodes',   'resource'=>'settings'],

            ['key'=>'mail-settings','label'=>__('amenu.mail_settings'),'url'=>'/admin/mail-settings.php',        'icon'=>'fa-envelope',      'resource'=>'settings'],

            ['key'=>'mail-templates','label'=>__('amenu.mail_templates'), 'url'=>'/admin/mail-templates.php',         'icon'=>'fa-envelope-open-text','resource'=>'settings'],

            ['key'=>'integrations',  'label'=>__('amenu.integrations'),  'url'=>'/admin/integrations.php',          'icon'=>'fa-plug',          'resource'=>'integrations'],

            ['key'=>'modules',       'label'=>__('amenu.modules'),        'url'=>'/admin/modules.php',               'icon'=>'fa-puzzle-piece',   'resource'=>'modules'],

            ['key'=>'faqs',          'label'=>__('amenu.faqs'),             'url'=>'/admin/faqs.php',                  'icon'=>'fa-circle-question','resource'=>'products'],

            ['key'=>'update',        'label'=>__('amenu.update'),      'url'=>'/admin/update.php',                'icon'=>'fa-download',       'resource'=>'permissions'],

            ['key'=>'discord-webhook','label'=>__('amenu.discord_webhook'),'url'=>'/admin/discord-webhook.php',        'icon'=>'fa-brands fa-discord','resource'=>'integrations'],

        ];



        /* ── Tüm entegrasyonlar otomatik aranabilir olsun ── */

        $integrationPages = [

            ['key'=>'int-turnstile',  'label'=>'Cloudflare Turnstile','url'=>'/admin/integrations.php?open=cf_captcha', 'icon'=>'fa-cloud',          'resource'=>'integrations'],

            ['key'=>'int-recaptcha',  'label'=>'Google reCAPTCHA',    'url'=>'/admin/integrations.php?open=recaptcha',   'icon'=>'fa-shield-halved',   'resource'=>'integrations'],

            ['key'=>'int-google',     'label'=>__('aint.login_google'),    'url'=>'/admin/integrations.php?open=google_auth', 'icon'=>'fa-google',          'resource'=>'integrations'],

            ['key'=>'int-discord',    'label'=>__('aint.login_discord'),   'url'=>'/admin/integrations.php?open=discord_auth','icon'=>'fa-brands fa-discord','resource'=>'integrations'],

            ['key'=>'int-microsoft',  'label'=>__('aint.login_microsoft'), 'url'=>'/admin/integrations.php?open=microsoft_auth','icon'=>'fa-brands fa-microsoft','resource'=>'integrations'],

            ['key'=>'int-github',     'label'=>__('aint.login_github'),    'url'=>'/admin/integrations.php?open=github_auth', 'icon'=>'fa-brands fa-github','resource'=>'integrations'],

            ['key'=>'int-shopier',    'label'=>'Shopier',             'url'=>'/admin/integrations.php?open=shopier',     'icon'=>'fa-store',           'resource'=>'integrations'],

            ['key'=>'int-paytr',      'label'=>'PayTR',               'url'=>'/admin/integrations.php?open=paytr',       'icon'=>'fa-credit-card',     'resource'=>'integrations'],

            ['key'=>'int-iyzico',     'label'=>'iyzico',              'url'=>'/admin/integrations.php?open=iyzico',      'icon'=>'fa-credit-card',     'resource'=>'integrations'],

            ['key'=>'int-stripe',     'label'=>'Stripe',              'url'=>'/admin/integrations.php?open=stripe',      'icon'=>'fa-cc-stripe',       'resource'=>'integrations'],

            ['key'=>'int-paypal',     'label'=>'PayPal',              'url'=>'/admin/integrations.php?open=paypal',      'icon'=>'fa-brands fa-paypal','resource'=>'integrations'],

            ['key'=>'int-bitpay',     'label'=>'BitPay',              'url'=>'/admin/integrations.php?open=bitpay',      'icon'=>'fa-brands fa-btc',   'resource'=>'integrations'],

            ['key'=>'int-crypt',      'label'=>__('aint.label_crypt'),  'url'=>'/admin/integrations.php?open=crypt',       'icon'=>'fa-brands fa-bitcoin','resource'=>'integrations'],

            ['key'=>'int-paywant',    'label'=>'Paywant',             'url'=>'/admin/integrations.php?open=paywant',     'icon'=>'fa-solid fa-wallet',  'resource'=>'integrations'],

            ['key'=>'int-whop',       'label'=>'Whop',                'url'=>'/admin/integrations.php?open=whop',        'icon'=>'fa-solid fa-w',       'resource'=>'integrations'],

            ['key'=>'int-paddle',     'label'=>'Paddle',              'url'=>'/admin/integrations.php?open=paddle',      'icon'=>'fa-solid fa-p',       'resource'=>'integrations'],
            ['key'=>'int-lemonsqueezy', 'label'=>'Lemon Squeezy',      'url'=>'/admin/integrations.php?open=lemonsqueezy', 'icon'=>'fa-solid fa-lemon',   'resource'=>'integrations'],
            ['key'=>'int-dodopayments', 'label'=>'DodoPayments',        'url'=>'/admin/integrations.php?open=dodopayments', 'icon'=>'fa-solid fa-d',    'resource'=>'integrations'],

            ['key'=>'int-tawkto',     'label'=>'Tawk.to',             'url'=>'/admin/integrations.php?open=tawkto',      'icon'=>'fa-comments',        'resource'=>'integrations'],

            ['key'=>'int-jivochat',   'label'=>'JivoChat',            'url'=>'/admin/integrations.php?open=jivochat',    'icon'=>'fa-comment-dots',    'resource'=>'integrations'],

            ['key'=>'int-crisp',      'label'=>'Crisp',               'url'=>'/admin/integrations.php?open=crisp',       'icon'=>'fa-comment-sms',     'resource'=>'integrations'],

            ['key'=>'int-analytics',  'label'=>__('aint.label_analytics'),    'url'=>'/admin/integrations.php?open=analytics',   'icon'=>'fa-chart-line',      'resource'=>'integrations'],

        ];

        $staticPages = array_merge($staticPages, $integrationPages);

        $staticPages = array_values(array_filter($staticPages, function($p) use ($canSee) { return $canSee($p['resource']); }));
        $pageIndex = [];
        foreach ($staticPages as $sp) $pageIndex[$sp['key']] = $sp;

        $q = trim($_POST['q'] ?? '');

        try {

            if (strlen($q) < 2) {

                $uid = (int)(auth_user()['id'] ?? 0);

                $s = $db->prepare('SELECT page_key,page_label,page_url,page_icon FROM admin_recent_pages WHERE user_id=? ORDER BY viewed_at DESC LIMIT 5');

                $s->execute([$uid]);

                $ordered = [];

                foreach ($s->fetchAll() as $r) {

                    $rk = (string)$r['page_key'];

                    $rl = (string)$r['page_label'];

                    $ru = (string)$r['page_url'];

                    $ri = (string)($r['page_icon'] ?: 'fa-file');

                    if (isset($pageIndex[$rk])) {

                        $rl = (string)$pageIndex[$rk]['label'];

                        $ru = (string)$pageIndex[$rk]['url'];

                        $ri = (string)$pageIndex[$rk]['icon'];

                    }

                    $ordered[] = [

                        'id' => $rk,

                        'name' => $rl,

                        'description' => null,

                        'type' => 'page',

                        'type_name' => __('asearch.type_page'),

                        'type_icon' => $ri,

                        'link' => $ru,

                        'highlight' => e($rl),

                    ];

                }

                if ($canSee('categories')) {

                    $cs = $db->query('SELECT id,name,description FROM categories ORDER BY created_at DESC LIMIT 4');

                    foreach ($cs->fetchAll() as $cr) {

                        $ordered[] = [

                            'id' => 'category-'.$cr['id'],

                            'name' => $cr['name'],

                            'description' => $cr['description'],

                            'type' => 'category',

                            'type_name' => __('asearch.type_category'),

                            'type_icon' => 'fa-tags',

                            'link' => '/admin/categories.php?edit='.$cr['id'],

                            'highlight' => e($cr['name']),

                        ];

                    }

                }

                $seen = [];

                foreach ($ordered as $o) $seen[$o['id']] = true;

                foreach ($staticPages as $sp) {

                    if (isset($seen[$sp['key']])) continue;

                    $seen[$sp['key']] = true;

                    $ordered[] = [

                        'id' => $sp['key'],

                        'name' => $sp['label'],

                        'description' => null,

                        'type' => 'page',

                        'type_name' => __('asearch.type_page'),

                        'type_icon' => $sp['icon'],

                        'link' => $sp['url'],

                        'highlight' => e($sp['label']),

                    ];

                }

                json_resp(true, __('shop.suggest'), ['results'=>$ordered]);

            }

            $results = [];

            $qLower = mb_strtolower($q, 'UTF-8');

            foreach ($staticPages as $p) {

                if (mb_strpos(mb_strtolower($p['label'], 'UTF-8'), $qLower) !== false) {

                    $results[] = [

                        'id' => $p['key'], 'name' => $p['label'], 'description' => null,

                        'type' => 'page', 'type_name' => __('asearch.type_page'), 'type_icon' => $p['icon'],

                        'link' => $p['url'], 'highlight' => highlightSearch($q, $p['label']),

                    ];

                }

            }

            if ($canSee('categories')) {

                $es = addcslashes($q, '%_'); $lk = '%'.$es.'%';

                $s = $db->prepare('SELECT id,name,description FROM categories WHERE name LIKE ? OR description LIKE ? LIMIT 8');

                $s->execute([$lk,$lk]);

                foreach ($s->fetchAll() as $r) {

                    $results[] = [

                        'id' => 'category-'.$r['id'], 'name' => $r['name'], 'description' => $r['description'],

                        'type' => 'category', 'type_name' => __('asearch.type_category'), 'type_icon' => 'fa-tags',

                        'link' => '/admin/categories.php?edit='.$r['id'], 'highlight' => highlightSearch($q, $r['name']),

                    ];

                }

                $s = $db->prepare('SELECT s.id,s.name,s.description FROM subcategories s WHERE s.name LIKE ? OR s.description LIKE ? LIMIT 8');

                $s->execute([$lk,$lk]);

                foreach ($s->fetchAll() as $r) {

                    $results[] = [

                        'id' => 'subcategory-'.$r['id'], 'name' => $r['name'], 'description' => $r['description'],

                        'type' => 'subcategory', 'type_name' => __('asearch.type_subcategory'), 'type_icon' => 'fa-sitemap',

                        'link' => '/admin/categories.php', 'highlight' => highlightSearch($q, $r['name']),

                    ];

                }

            }

            if ($canSee('users')) {

                $es2 = addcslashes($q, '%_'); $lk = '%'.$es2.'%';

                $s = $db->prepare('SELECT id,username,email FROM users WHERE username LIKE ? OR email LIKE ? LIMIT 8');

                $s->execute([$lk,$lk]);

                foreach ($s->fetchAll() as $r) {

                    $results[] = [

                        'id' => 'user-'.$r['id'], 'name' => $r['username'], 'description' => $r['email'],

                        'type' => 'user', 'type_name' => __('apurch.user'), 'type_icon' => 'fa-user',

                        'link' => '/admin/users.php?q='.urlencode($r['username']), 'highlight' => highlightSearch($q, $r['username']),

                    ];

                }

            }

            if ($canSee('products')) {

                $es3 = addcslashes($q, '%_'); $lk = '%'.$es3.'%';

                $s = $db->prepare('SELECT id,name,short_description FROM products WHERE name LIKE ? OR short_description LIKE ? LIMIT 8');

                $s->execute([$lk,$lk]);

                foreach ($s->fetchAll() as $r) {

                    $results[] = [

                        'id' => 'product-'.$r['id'], 'name' => $r['name'], 'description' => $r['short_description'],

                        'type' => 'product', 'type_name' => __('apurch.product'), 'type_icon' => 'fa-box-open',

                        'link' => '/admin/product-editor.php?id='.$r['id'], 'highlight' => highlightSearch($q, $r['name']),

                    ];

                }

            }

            if ($canSee('announcements')) {

                $es4 = addcslashes($q, '%_'); $lk = '%'.$es4.'%';

                $s = $db->prepare('SELECT id,title,content FROM announcements WHERE title LIKE ? OR content LIKE ? LIMIT 8');

                $s->execute([$lk,$lk]);

                foreach ($s->fetchAll() as $r) {

                    $desc = $r['content'] ? mb_substr(strip_tags($r['content']), 0, 100, 'UTF-8') : null;

                    $results[] = [

                        'id' => 'announcement-'.$r['id'], 'name' => $r['title'], 'description' => $desc,

                        'type' => 'announcement', 'type_name' => __('asearch.type_announcement'), 'type_icon' => 'fa-bullhorn',

                        'link' => '/admin/announcement-editor.php?id='.$r['id'], 'highlight' => highlightSearch($q, $r['title']),

                    ];

                }

            }

            json_resp(true, __('bcat.results_found', ['n' => count($results)]), ['results'=>$results, 'q'=>$q]);

        } catch (\PDOException $e) { error_log('[NS] admin_category_search: '.$e->getMessage()); json_resp(false, __('shop.search_error')); }
    case 'track_category_view':

        if (!auth_check()) json_resp(false, __('auth.login_required'));

        $pageKey = trim($_POST['page_key'] ?? '');

        $pageLabel = trim($_POST['page_label'] ?? '');

        $pageUrl = trim($_POST['page_url'] ?? '');

        $pageIcon = trim($_POST['page_icon'] ?? '');

        if ($pageKey === '' || $pageLabel === '' || $pageUrl === '') json_resp(false, __('err.invalid_data'));

        if (strlen($pageKey) > 80 || strlen($pageLabel) > 120 || strlen($pageUrl) > 255 || strlen($pageIcon) > 60) json_resp(false, __('err.invalid_data'));

        if ($pageUrl[0] !== '/' || strncmp($pageUrl, '//', 2) === 0 || strpos($pageUrl, '\\') !== false || preg_match('/\s/', $pageUrl)) json_resp(false, __('err.invalid_data'));

        $uid = (int)(auth_user()['id'] ?? 0);

        remember_recent_page($db, $uid, $pageKey, $pageLabel, $pageUrl, $pageIcon);

        json_resp(true, '');
    case 'search':

        $q = trim($_POST['q'] ?? '');

        if (strlen($q) < 2) json_resp(false, __('bcat.search_min'));

        $results = [];

        $es = addcslashes($q, '%_');

        $lk = '%'.$es.'%';

        try {

            $s = $db->prepare("SELECT id,name,short_description AS description,slug,'product' AS type FROM products WHERE is_active=1 AND status='active' AND is_hidden=0 AND (name LIKE ? OR short_description LIKE ?) LIMIT 5");

            $s->execute([$lk,$lk]); $results = array_merge($results, $s->fetchAll());

            $s = $db->prepare("SELECT id,name,description,'category' AS type FROM categories WHERE name LIKE ? OR description LIKE ? LIMIT 5");

            $s->execute([$lk,$lk]); $results = array_merge($results, $s->fetchAll());

            $s = $db->prepare("SELECT id,title AS name,content AS description,'announcement' AS type FROM announcements WHERE status='published' AND (title LIKE ? OR content LIKE ?) LIMIT 5");

            $s->execute([$lk,$lk]); $results = array_merge($results, $s->fetchAll());

            $s = $db->prepare("SELECT id,title AS name,content AS description,slug,'page' AS type FROM legal_pages WHERE title LIKE ? OR slug LIKE ? LIMIT 5");

            $s->execute([$lk,$lk]); $results = array_merge($results, $s->fetchAll());

            $typeNames = ['product'=>__('apurch.product'),'category'=>__('support.category'),'announcement'=>__('news.announcement'),'page'=>__('apage.col_page')];

            $typeIcons = ['product'=>'fa-cube','category'=>'fa-tags','announcement'=>'fa-bullhorn','page'=>'fa-file-lines'];

            $typeLinks = ['product'=>'/product/','category'=>'/products?category=','announcement'=>'/news#','page'=>'/legal?p='];

            foreach ($results as &$r) {

                $r['type_name'] = $typeNames[$r['type']] ?? $r['type'];

                $r['type_icon'] = $typeIcons[$r['type']] ?? 'fa-circle';

                $r['link'] = $typeLinks[$r['type']] ?? '#';

                if ($r['type'] === 'product') $r['link'] .= urlencode($r['slug'] ?? '');

                elseif ($r['type'] === 'category') $r['link'] .= urlencode($r['name'] ?? '');

                elseif ($r['type'] === 'announcement') $r['link'] .= $r['id'];

                elseif ($r['type'] === 'page') $r['link'] .= urlencode($r['slug'] ?? '');

                $r['highlight'] = highlightSearch($q, $r['name'] ?? '');

            }

            unset($r);

            json_resp(true, __('bcat.results_found', ['n' => count($results)]), ['results'=>$results, 'q'=>$q]);

        } catch (\PDOException $e) { error_log('[NS] search: '.$e->getMessage()); json_resp(false, __('shop.search_error')); }



    // ─── Entegrasyon Kaydet ───

    default:

        json_resp(false, __('err.unknown_action'));

}
