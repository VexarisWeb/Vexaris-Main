<?php
if (!defined('NEXUS_BOOT')) { http_response_code(403); exit; }

switch ($action) {

    case 'cart_add':

        require_login();

        $uid = (int)auth_user()['id'];

        $pid = (int)($_POST['product_id'] ?? 0);

        $qty = min(999, max(1, (int)($_POST['quantity'] ?? 1)));

        if (!$pid) json_resp(false, __('shop.invalid_product'));

        try {

            $p = $db->prepare('SELECT id,price,discount_percent FROM products WHERE id=? AND is_hidden=0 AND status="active"');

            $p->execute([$pid]);

            $prod = $p->fetch();

            if (!$prod) json_resp(false, __('shop.product_missing'));

            $b = $db->prepare('SELECT id FROM sales WHERE user_id=? AND product_id=?');

            $b->execute([$uid, $pid]);

            if ($b->fetch()) json_resp(false, __('shop.already_owned'));

            $isFree = product_effective_price($prod['price'], $prod['discount_percent'] ?? 0) <= 0;

            if ($isFree) {

                $db->prepare('INSERT INTO cart (user_id,product_id,quantity) VALUES (?,?,1) ON DUPLICATE KEY UPDATE quantity=1')->execute([$uid,$pid]);

            } else {

                $db->prepare('INSERT INTO cart (user_id,product_id,quantity) VALUES (?,?,?) ON DUPLICATE KEY UPDATE quantity=quantity+VALUES(quantity)')->execute([$uid,$pid,$qty]);

            }

            $cs = $db->prepare('SELECT SUM(quantity) FROM cart WHERE user_id=?');

            $cs->execute([$uid]);

            json_resp(true, 'Sepete eklendi.', ['cart_count' => (int)($cs->fetchColumn() ?? 0)]);

        } catch (\Throwable $e) {

            error_log('[NS] cart_add: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());

            json_resp(false, __('cart.add_fail'));

        }
    case 'cart_remove':

        require_login();

        $uid = (int)auth_user()['id'];

        $pid = (int)($_POST['product_id'] ?? 0);

        if (!$pid) json_resp(false, __('shop.invalid_product'));

        try {

            $db->prepare('DELETE FROM cart WHERE user_id=? AND product_id=?')->execute([$uid,$pid]);

            json_resp(true, __('cart.removed'));

        } catch (\Throwable $e) {

            error_log('[NS] cart_remove: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());

            json_resp(false, __('shop.delete_fail'));

        }
    case 'cart_update_qty':

        require_login();

        $uid = (int)auth_user()['id'];

        $pid = (int)($_POST['product_id'] ?? 0);

        $qty = min(999, max(0, (int)($_POST['quantity'] ?? 1)));

        if (!$pid) json_resp(false, __('shop.invalid_product'));

        try {

            $fp = $db->prepare('SELECT price,discount_percent FROM products WHERE id=?');

            $fp->execute([$pid]);

            $frow = $fp->fetch();

            $freeLock = $frow && product_effective_price($frow['price'], $frow['discount_percent'] ?? 0) <= 0;

            if ($qty < 1) {

                $db->prepare('DELETE FROM cart WHERE user_id=? AND product_id=?')->execute([$uid,$pid]);

            } else {

                if ($freeLock) $qty = 1;

                $db->prepare('UPDATE cart SET quantity=? WHERE user_id=? AND product_id=?')->execute([$qty,$uid,$pid]);

            }

            $cs = $db->prepare('SELECT SUM(c.quantity) FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"');

            $cs->execute([$uid]);

            $total = $db->prepare('SELECT SUM(p.price*(1-LEAST(COALESCE(p.discount_percent,0),90)/100.0)*c.quantity) FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"');

            $total->execute([$uid]);

            $cc = (int)($cs->fetchColumn()??0); $ct = (float)($total->fetchColumn()??0);

            json_resp(true, ($freeLock && $qty > 0) ? __('cart.free_limit_toast') : __('bshop.qty_updated'), ['cart_count'=>$cc, 'cart_total'=>$ct, 'empty'=>!$cc]);

        } catch (\Throwable $e) {

            error_log('[NS] cart_update_qty: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());

            json_resp(false, __('shop.update_fail'));

        }
    case 'cart_panel_html':

        require_login();

        $uid = (int)auth_user()['id'];

        try {

            $itemsSt = $db->prepare('SELECT c.product_id,c.quantity,p.name,p.price,p.discount_percent,p.image_url FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active" ORDER BY c.added_at DESC');

            $itemsSt->execute([$uid]);

            $panelItems = $itemsSt->fetchAll();

            $panelTotal = cart_effective_total($panelItems);

            $panelCount = (int)array_sum(array_map(fn($i) => $i['quantity'], $panelItems));

            ob_start();

            include ROOT_PATH . '/themes/default/includes/cart-panel.php';

            $panelHtml = ob_get_clean();

            json_resp(true, '', ['html' => $panelHtml, 'cart_count' => $panelCount, 'cart_total' => $panelTotal]);

        } catch (\Throwable $e) {

            error_log('[NS] cart_panel_html: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());

            json_resp(false, __('panel.load_fail'));

        }
    case 'cart_state':

        require_login();

        $uid = (int)auth_user()['id'];

        try {

            $cst = $db->prepare('SELECT c.product_id,c.quantity,p.name,p.price,p.discount_percent,p.image_url FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active" ORDER BY c.added_at DESC');

            $cst->execute([$uid]);

            if ($cst->columnCount() === 0) json_resp(false, __('cart.load_fail'));

            $stateItems = $cst->fetchAll();

            $stateSub = cart_effective_total($stateItems);

            if (function_exists('apply_filters')) $stateSub = (float)apply_filters('checkout_total', $stateSub, $stateItems);

            $stateSub = round($stateSub, 2);

            $stateDisc = 0.0; $stateCoupon = null;

            $stateAp = coupon_resolve_for_pay($db, $_SESSION['applied_coupon'] ?? null, $uid);

            if ($stateAp) {

                    $stateDisc = coupon_discount_for_total($stateAp, $stateSub);

                    $ctp = $stateAp['type'] ?? ''; $cval = (float)($stateAp['value'] ?? 0);

                    $clabel = coupon_label($ctp, $cval);

                    $stateCoupon = ['code' => (string)($stateAp['code'] ?? ''), 'label' => $clabel];

            }

            $stateOut = [];

            foreach ($stateItems as $sIt) $stateOut[] = ['product_id' => (int)$sIt['product_id'], 'name' => (string)$sIt['name'], 'price' => (float)$sIt['price'], 'image_url' => (string)($sIt['image_url'] ?? ''), 'quantity' => (int)$sIt['quantity'], 'is_free' => product_effective_price($sIt['price'], $sIt['discount_percent'] ?? 0) <= 0, 'line_total' => round(product_effective_price($sIt['price'], $sIt['discount_percent'] ?? 0) * (int)$sIt['quantity'], 2)];

            $stateCount = (int)array_sum(array_map(fn($i) => (int)$i['quantity'], $stateItems));

            $stateTotal = max(0, round($stateSub - $stateDisc, 2));

            $stateBalStmt = $db->prepare('SELECT balance FROM users WHERE id=?');

            $stateBalStmt->execute([$uid]);

            $stateBal = (float)($stateBalStmt->fetchColumn() ?? 0);

            $stateLow = ($stateTotal > 0 && $stateBal < $stateTotal);

            json_resp(true, '', ['items' => $stateOut, 'count' => $stateCount, 'subtotal' => $stateSub, 'discount' => round($stateDisc, 2), 'total' => $stateTotal, 'coupon' => $stateCoupon, 'empty' => !$stateCount, 'balance' => round($stateBal, 2), 'low_balance' => $stateLow]);

        } catch (\Throwable $e) {

            error_log('[NS] cart_state: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());

            json_resp(false, __('cart.load_fail'));

        }
    case 'cart_clear':

        require_login();

        $uid = (int)auth_user()['id'];

        try {

            $db->prepare('DELETE FROM cart WHERE user_id=?')->execute([$uid]);

            json_resp(true, 'Sepet temizlendi.');

        } catch (\Throwable $e) {

            error_log('[NS] cart_clear: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());

            json_resp(false, __('cart.clear_fail'));

        }
    case 'checkout':

        require_login();

        $uid = (int)auth_user()['id'];

        $items = $db->prepare('SELECT c.product_id,c.quantity,p.price,p.discount_percent,p.name,p.license_prefix FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"');

        $items->execute([$uid]);

        $cartItems = $items->fetchAll();

        if (empty($cartItems)) json_resp(false, __('cart.empty_short'));

        $ownSt = $db->prepare('SELECT product_id FROM sales WHERE user_id=?');

        $ownSt->execute([$uid]);

        $ownedIds = array_map('intval', $ownSt->fetchAll(PDO::FETCH_COLUMN));

        if (!empty($ownedIds)) {

            $db->prepare('DELETE FROM cart WHERE user_id=? AND product_id IN (' . implode(',', array_fill(0, count($ownedIds), '?')) . ')')->execute(array_merge([$uid], $ownedIds));

            $cartItems = array_values(array_filter($cartItems, fn($ci) => !in_array((int)$ci['product_id'], $ownedIds, true)));

        }

        foreach ($cartItems as &$ci) {

            if (product_effective_price($ci['price'], $ci['discount_percent'] ?? 0) <= 0) $ci['quantity'] = 1;

        }

        unset($ci);

        if (empty($cartItems)) json_resp(false, __('cart.empty_short'));

        $total = cart_effective_total($cartItems);

        if (function_exists('apply_filters')) $total = (float)apply_filters('checkout_total', $total, $cartItems);

        $appliedCoupon = coupon_resolve_for_pay($db, $_SESSION['applied_coupon'] ?? null, $uid);

        if ($appliedCoupon) {

            $preCouponTotal = $total;

            $total = max(0, $total - coupon_discount_for_total($appliedCoupon, $total));

            $couponEffective = ($preCouponTotal > 0 && $total < $preCouponTotal);

        }

        if ($total > 0 && !plan_payments_allowed($db)) json_resp(false, __('plan.payments_paused'));

        if (function_exists('do_action')) do_action('checkout_before', $uid, $cartItems, $total);

        foreach ($cartItems as $stockItem) {

            if (!stock_available($db, (int)$stockItem['product_id'], (int)$stockItem['quantity']))

                json_resp(false, __('bshop.out_of_stock', ['name' => $stockItem['name']]));

        }

        $balRow = $db->prepare('SELECT balance FROM users WHERE id=?');

        $balRow->execute([$uid]);

        $curBalance = (float)($balRow->fetchColumn() ?? 0);

        $gatewayReadyC = gateways_cart_ready($db);

        if ($total > 0 && $curBalance < $total) {

            if (!$gatewayReadyC) json_resp(false, __('cart.low_nogateway', ['need' => sprintf('%.2f', round($total, 2)), 'have' => sprintf('%.2f', round($curBalance, 2))]), ['low_balance' => false, 'redirect' => '']);

            json_resp(false, __('topup.redirecting'), ['low_balance' => false, 'redirect' => '/shop/payment']);

        }

        $db->beginTransaction();

        try {

            $uRow = $db->prepare('SELECT balance FROM users WHERE id=? FOR UPDATE');

            $uRow->execute([$uid]);

            $balance = (float)($uRow->fetch()['balance'] ?? 0);

            if ($balance < $total) {
                $db->rollBack();
                if (!$gatewayReadyC) json_resp(false, __('cart.low_nogateway', ['need' => sprintf('%.2f', round($total, 2)), 'have' => sprintf('%.2f', round($balance, 2))]), ['low_balance' => false, 'redirect' => '']);
                json_resp(false, __('topup.redirecting'), ['low_balance' => false, 'redirect' => '/shop/payment']);
            }

            foreach ($cartItems as $item) {

                if (!stock_available_locked($db, (int)$item['product_id'], (int)$item['quantity'])) {

                    $db->rollBack();

                    json_resp(false, __('bshop.out_of_stock', ['name' => $item['name']]));

                }

            }

            $ownRe = $db->prepare('SELECT product_id FROM sales WHERE user_id=?');

            $ownRe->execute([$uid]);

            $ownedNow = array_map('intval', $ownRe->fetchAll(PDO::FETCH_COLUMN));

            foreach ($cartItems as $ci) {

                if (in_array((int)$ci['product_id'], $ownedNow, true)) {

                    $db->rollBack();

                    json_resp(false, __('shop.race_bought'));

                }

            }

            $db->prepare('UPDATE users SET balance=balance-? WHERE id=?')->execute([$total,$uid]);

            $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,-?,?,"' . __('bshop.log_cart') . '",NOW())')->execute([$uid,$total,$appliedCoupon?'coupon':'purchase']);

            require_once ROOT_PATH . '/core/purchase.php';

            $doneCheckout = purchase_consume_cart($db, $uid, $cartItems, (float)$total);

            $db->prepare('DELETE FROM cart WHERE user_id=?')->execute([$uid]);

            if ($appliedCoupon && ($couponEffective ?? false)) {

                require_once ROOT_PATH . '/core/coupons.php';

                $cLock = $db->prepare('SELECT id FROM coupons WHERE id=? AND is_active=1 AND used_count<max_uses AND (expires_at IS NULL OR expires_at > NOW()) FOR UPDATE');

                $cLock->execute([(int)$appliedCoupon['id']]);

                if (!$cLock->fetch()) { $db->rollBack(); json_resp(false, __('coupon.limit')); }

                $uUsed = $db->prepare('SELECT id FROM coupon_usages WHERE user_id=? AND coupon_id=?');

                $uUsed->execute([$uid, (int)$appliedCoupon['id']]);

                if ($uUsed->fetch()) { $db->rollBack(); json_resp(false, __('msg.coupon_used')); }

                if (!coupon_consume($db, (int)$appliedCoupon['id'], $uid)) { $db->rollBack(); json_resp(false, __('msg.coupon_fail')); }

            }

            unset($_SESSION['applied_coupon']);

            $_SESSION['user']['balance'] = $balance - $total;

            $db->commit();

            require_once ROOT_PATH . '/core/discord.php';

            discord_notify($db, 'purchase', __('bsupp.purchase_title'), __('bsupp.purchase_body'), [

                __('bsupp.f_user') => auth_user()['username'],

                __('bsupp.f_products')   => implode(', ', array_map(fn($i) => $i['name'], $cartItems)),

                __('bsupp.f_amount')     => $total > 0 ? '₺' . number_format($total, 2, ',', '.') : __('home.free'),

            ], '5793549');

            json_resp(true, __('shop.bought', ['t' => sprintf('%.2f', $total)]), ['new_balance' => round($balance - $total, 2)]);

        } catch (\Exception $e) {

            $db->rollBack();

            error_log('[NS] checkout: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());

            json_resp(false, __('op.error'));

        }
    case 'buy_now':

        require_login();

        $uid = (int)auth_user()['id'];

        $pid = (int)($_POST['product_id'] ?? 0);

        if (!$pid) json_resp(false, __('shop.invalid_product'));

        $pr = $db->prepare('SELECT id,name,price,discount_percent,image_url,is_hidden,status,license_prefix FROM products WHERE id=?');

        $pr->execute([$pid]);

        $prod = $pr->fetch();

        if (!$prod || $prod['is_hidden'] || $prod['status'] !== 'active') json_resp(false, __('shop.product_missing'));

        $prod['price'] = round((float)$prod['price'] * (1 - min(90, max(0, (int)$prod['discount_percent'])) / 100), 2);

        $own = $db->prepare('SELECT id FROM sales WHERE user_id=? AND product_id=?');

        $own->execute([$uid,$pid]);

        if ($own->fetch()) json_resp(false, __('shop.already_owned'));

        if (!stock_available($db, $pid, 1)) json_resp(false, __('shop.out_of_stock'));

        $buyItemSingle = [['product_id'=>$pid,'quantity'=>1,'name'=>$prod['name'],'price'=>$prod['price']]];
        if (function_exists('apply_filters')) $prod['price'] = (float)apply_filters('checkout_total', (float)$prod['price'], $buyItemSingle);

        $buyCoupon = coupon_resolve_for_pay($db, $_SESSION['applied_coupon'] ?? null, $uid);
        $buyCouponId = 0;
        if ($buyCoupon && (float)$prod['price'] > 0) {
                $buyPriceB = max(0, (float)$prod['price'] - coupon_discount_for_total($buyCoupon, (float)$prod['price']));
                if ($buyPriceB < (float)$prod['price']) { $prod['price'] = $buyPriceB; $buyCouponId = (int)$buyCoupon['id']; }
        }

        if ((float)$prod['price'] > 0 && !plan_payments_allowed($db)) json_resp(false, __('plan.payments_paused'));

        if ((float)$prod['price'] <= 0) {
            require_once ROOT_PATH . '/core/purchase.php';
            require_once ROOT_PATH . '/core/coupons.php';
            $db->beginTransaction();
            try {
                if ($buyCouponId > 0) {
                    $cLockF = $db->prepare('SELECT id FROM coupons WHERE id=? AND is_active=1 AND used_count<max_uses AND (expires_at IS NULL OR expires_at > NOW()) FOR UPDATE');
                    $cLockF->execute([$buyCouponId]);
                    if (!$cLockF->fetch()) { $db->rollBack(); json_resp(false, __('coupon.limit')); }
                    $uUsedF = $db->prepare('SELECT id FROM coupon_usages WHERE user_id=? AND coupon_id=?');
                    $uUsedF->execute([$uid, $buyCouponId]);
                    if ($uUsedF->fetch() || !coupon_consume($db, $buyCouponId, $uid)) { $db->rollBack(); json_resp(false, __('msg.coupon_fail')); }
                    unset($_SESSION['applied_coupon']);
                }
                $one = [['product_id'=>$pid,'quantity'=>1,'name'=>$prod['name'],'price'=>0,'license_prefix'=>$prod['license_prefix']]];
                purchase_consume_cart($db, $uid, $one);
                $db->prepare('DELETE FROM cart WHERE user_id=? AND product_id=?')->execute([$uid,$pid]);
                $db->commit();
                json_resp(true, __('free.granted'), ['free'=>true,'product_id'=>$pid]);
            } catch (Throwable $eFree) {
                if ($db->inTransaction()) $db->rollBack();
                error_log('[NS] free buy_now: '.$eFree->getMessage());
                json_resp(false, __('free.fail'));
            }
        }




        /* Bakiye oncelikli: yetiyorsa bakiyeden dus, yetmiyorsa odeme sayfasina yonlendir.
           method secimi (secili gateway) modal picker uzerinden gelir; bos ise kart akisi calisir. */

        $readyB = gateway_ready_list($db);

        $methodB = trim((string)($_POST['method'] ?? ''));

        if ($methodB !== '' && !in_array($methodB, $readyB, true)) $methodB = '';

        if ($methodB !== '') {

            $db->prepare('INSERT INTO cart (user_id,product_id,quantity) VALUES (?,?,1) ON DUPLICATE KEY UPDATE quantity=1')->execute([$uid,$pid]);

            $goB = gateway_method_url($methodB);

            if ($methodB === 'shopier' || $methodB === 'paytr' || $goB === '') $goB = '/shop/payment';

            json_resp(true, __('topup.redirecting'), ['redirect' => $goB]);

        }



        $db->beginTransaction();

        try {

            $uRow = $db->prepare('SELECT balance FROM users WHERE id=? FOR UPDATE');

            $uRow->execute([$uid]);

            $balance = (float)($uRow->fetch()['balance'] ?? 0);

            $ownLock = $db->prepare('SELECT id FROM sales WHERE user_id=? AND product_id=? LIMIT 1');

            $ownLock->execute([$uid,$pid]);

            if ($ownLock->fetch()) { $db->rollBack(); json_resp(false, __('shop.already_owned')); }

            if ($balance < $prod['price']) {
                $db->rollBack();
                if (!gateways_cart_ready($db)) json_resp(false, __('cart.low_nogateway_buy', ['need' => sprintf('%.2f', $prod['price']), 'have' => sprintf('%.2f', $balance)]));
                $db->prepare('INSERT INTO cart (user_id,product_id,quantity) VALUES (?,?,1) ON DUPLICATE KEY UPDATE quantity=1')->execute([$uid,$pid]);
                json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/payment']);
            }

            if (!stock_available_locked($db, $pid, 1)) {
                $db->rollBack();
                json_resp(false, __('shop.out_of_stock'));
            }

            if ($buyCouponId > 0) {
                require_once ROOT_PATH . '/core/coupons.php';
                $cLockB = $db->prepare('SELECT id FROM coupons WHERE id=? AND is_active=1 AND used_count<max_uses AND (expires_at IS NULL OR expires_at > NOW()) FOR UPDATE');
                $cLockB->execute([$buyCouponId]);
                if (!$cLockB->fetch()) { $db->rollBack(); json_resp(false, __('coupon.limit')); }
                $uUsedB = $db->prepare('SELECT id FROM coupon_usages WHERE user_id=? AND coupon_id=?');
                $uUsedB->execute([$uid, $buyCouponId]);
                if ($uUsedB->fetch()) { $db->rollBack(); json_resp(false, __('msg.coupon_used')); }
                if (!coupon_consume($db, $buyCouponId, $uid)) { $db->rollBack(); json_resp(false, __('msg.coupon_fail')); }
                unset($_SESSION['applied_coupon']);
            }

            $db->prepare('UPDATE users SET balance=balance-? WHERE id=?')->execute([$prod['price'],$uid]);

            $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,-?,?,"' . __('bshop.log_buy') . '",NOW())')->execute([$uid,$prod['price'],'purchase']);

            $saleCurB = function_exists('store_currency') ? store_currency() : 'TRY';
            $db->prepare('INSERT INTO sales (user_id,product_id,price_paid,currency,purchased_at) VALUES (?,?,?,?,NOW())')->execute([$uid,$pid,$prod['price'],$saleCurB]);

            $sid = (int)$db->lastInsertId();

            try { $db->prepare('INSERT INTO orders (user_id,product_id,price,status,created_at) VALUES (?,?,?,"completed",NOW())')->execute([$uid,$pid,$prod['price']]); } catch(\Exception $e) {}

            $lic = stock_consume($db, $pid, 1, $uid);
            if ($lic === null && !stock_is_unlimited($db, $pid)) {
                $db->rollBack();
                json_resp(false, __('shop.out_of_stock'));
            }

            if ($lic !== null) $db->prepare('UPDATE sales SET license_key=? WHERE id=?')->execute([$lic, $sid]);

            $db->prepare('DELETE FROM cart WHERE user_id=? AND product_id=?')->execute([$uid,$pid]);

            $_SESSION['user']['balance'] = $balance - $prod['price'];

            $db->commit();

            require_once ROOT_PATH . '/core/discord.php';

            discord_notify($db, 'purchase', __('bsupp.purchase_title'), __('bsupp.purchase_body'), [

                __('bsupp.f_user') => auth_user()['username'],

                __('bsupp.f_product')      => $prod['name'],

                __('bsupp.f_amount')     => $prod['price'] > 0 ? '₺' . number_format($prod['price'], 2, ',', '.') : __('home.free'),

            ], '5793549');

            json_resp(true, __('shop.bought', ['t' => sprintf('%.2f', $prod['price'])]), ['new_balance' => round($balance - $prod['price'], 2)]);

        } catch (\Exception $e) {

            $db->rollBack();

            error_log('[NS] buy_now: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());

            json_resp(false, __('op.error'));

        }
    case 'comment_add':

        require_login();

        if (!feature_active('reviews')) json_resp(false, __('err.feature_off'));

        $uid  = (int)auth_user()['id'];

        $pid  = (int)($_POST['product_id'] ?? 0);

        $text = trim($_POST['comment_text'] ?? '');

        if (!$pid || strlen($text) < 3) json_resp(false, __('msg.review_min'));

        $pck = $db->prepare('SELECT id FROM products WHERE id=? AND is_hidden=0');

        $pck->execute([$pid]);

        if (!$pck->fetch()) json_resp(false, __('shop.product_missing'));

        $own = $db->prepare('SELECT id FROM sales WHERE user_id=? AND product_id=?');

        $own->execute([$uid,$pid]);

        if (!$own->fetch()) json_resp(false, __('review.must_own'));

        $dup = $db->prepare('SELECT id FROM comments WHERE product_id=? AND user_id=?');

        $dup->execute([$pid,$uid]);

        if ($dup->fetch()) json_resp(false, __('review.already'));

        $rating = min(5, max(0, (int)($_POST['rating'] ?? 0)));

        $db->prepare('INSERT INTO comments (product_id,user_id,comment_text,rating,created_at) VALUES (?,?,?,?,NOW())')->execute([$pid,$uid,$text,$rating]);

        if (defined('ROOT_PATH')) {

            require_once ROOT_PATH . '/core/discord.php';

            $pInfo = $db->prepare('SELECT name,slug FROM products WHERE id=?');

            $pInfo->execute([$pid]);

            $pr = $pInfo->fetch();

            discord_notify($db, 'review', __('bsupp.review_title'), __('bsupp.review_body'), [

                __('bsupp.f_product')        => ($pr['name'] ?? '#' . $pid),

                __('bsupp.f_rating')        => str_repeat('⭐', $rating),

                __('bsupp.f_author')       => auth_user()['username'],

                __('bsupp.f_review') => mb_substr($text, 0, 700),

            ], '16268780');

        }

        audit_log($db, 'create', 'reviews', $pid, mb_substr($text, 0, 80), '/products?product=' . $pid);
        json_resp(true, 'Yorum eklendi.', ['id' => (int)$db->lastInsertId(), 'html' => simple_markdown($text), 'username' => auth_user()['username'], 'rating' => $rating]);
    case 'comment_update':

        require_login();

        if (!feature_active('reviews')) json_resp(false, __('err.feature_off'));

        $uid  = (int)auth_user()['id'];

        $cId  = (int)($_POST['comment_id'] ?? 0);

        $text = trim($_POST['comment_text'] ?? '');

        $rating = min(5, max(0, (int)($_POST['rating'] ?? 0)));

        if (!$cId || strlen($text) < 3) json_resp(false, __('msg.review_min'));

        $row = $db->prepare('SELECT user_id FROM comments WHERE id=?');

        $row->execute([$cId]);

        if ((int)$row->fetchColumn() !== $uid) json_resp(false, __('review.no_perm_edit'));

        $db->prepare('UPDATE comments SET comment_text=?, rating=? WHERE id=? AND user_id=?')->execute([$text,$rating,$cId,$uid]);

        audit_log($db, 'update', 'reviews', $cId, mb_substr($text, 0, 80), '/admin/reviews.php');
        json_resp(true, __('review.updated'), ['html' => simple_markdown($text), 'rating' => $rating]);
    case 'comment_delete':

        require_login();

        if (!feature_active('reviews')) json_resp(false, __('err.feature_off'));

        $uid = (int)auth_user()['id'];

        $cId = (int)($_POST['comment_id'] ?? 0);

        if (!$cId) json_resp(false, __('review.invalid'));

        $row = $db->prepare('SELECT user_id FROM comments WHERE id=?');

        $row->execute([$cId]);

        if ((int)$row->fetchColumn() !== $uid) json_resp(false, __('review.no_perm_del'));

        $db->prepare('DELETE FROM comments WHERE id=? AND user_id=?')->execute([$cId,$uid]);

        audit_log($db, 'delete', 'reviews', $cId, '#' . $cId, '/admin/reviews.php');
        json_resp(true, __('review.deleted'));
    case 'review_update':

        require_resource('reviews');

        if (!feature_active('reviews')) redirect_back(__('review.off'), 'error');

        $rId   = (int)($_POST['id'] ?? 0);

        $rText = trim($_POST['comment_text'] ?? '');

        $rRate = min(5, max(0, (int)($_POST['rating'] ?? 0)));

        if (!$rId || strlen($rText) < 3) redirect_back(__('review.min_admin'), 'error');

        try { $db->prepare('UPDATE comments SET comment_text=?, rating=? WHERE id=?')->execute([$rText,$rRate,$rId]); audit_log($db, 'update', 'reviews', $rId, '#' . $rId, '/admin/reviews.php'); redirect_back(__('review.updated_admin')); }

        catch (\PDOException $e) { error_log('[NS] review_update: '.$e->getMessage()); redirect_back(__('review.update_fail'), 'error'); }
    case 'review_delete':

        require_resource('reviews');

        if (!feature_active('reviews')) redirect_back(__('review.off'), 'error');

        $rId = (int)($_POST['id'] ?? 0);

        if (!$rId) redirect_back(__('err.invalid_id'), 'error');

        try { $db->prepare('DELETE FROM comments WHERE id=?')->execute([$rId]); audit_log($db, 'delete', 'reviews', $rId, '#' . $rId, '/admin/reviews.php'); redirect_back(__('review.deleted_admin')); }

        catch (\PDOException $e) { error_log('[NS] review_delete: '.$e->getMessage()); redirect_back('Silinemedi.', 'error'); }
    case 'balance_add':

        require_resource('users');

        $uid    = (int)($_POST['user_id'] ?? 0);

        $amount = (float)($_POST['amount'] ?? 0);

        if (!$uid || $amount <= 0 || $amount > 1000000) redirect_back(__('err.invalid_value'), 'error');

        $uChk = $db->prepare('SELECT id FROM users WHERE id=?');

        $uChk->execute([$uid]);

        if (!$uChk->fetch()) redirect_back(__('err.user_missing2'), 'error');

        $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$amount,$uid]);

        $desc = trim($_POST['description'] ?? __('bshop.admin_added'));

        $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,?,NOW())')->execute([$uid,$amount,'admin',$desc]);

        audit_log($db, 'create', 'balance', $uid, '#' . $uid, '/admin/users.php?tab=balance');
        redirect_back(__('bshop.balance_added', ['n' => sprintf('%.2f', $amount)]));
    case 'apply_coupon':

        require_login();

        if (!feature_active('coupons')) json_resp(false, __('coupon.off'));

        $uid  = (int)auth_user()['id'];

        $code = strtoupper(trim($_POST['code'] ?? ''));

        if (!$code) json_resp(false, 'Kupon kodu giriniz.');

        $cw = $_SESSION['coupon_try'] ?? null;
        if (!is_array($cw) || ($cw['ts'] ?? 0) < time() - 600) $cw = ['n' => 0, 'ts' => time()];
        if ($cw['n'] >= 10) json_resp(false, __('auth.rate_limited'));
        $_SESSION['coupon_try'] = $cw;

        $cStmt = $db->prepare('SELECT * FROM coupons WHERE code=? LIMIT 1');

        $cStmt->execute([$code]);

        $coupon = $cStmt->fetch();

        if (!$coupon) {
            $cw['n']++;
            $_SESSION['coupon_try'] = $cw;
            json_resp(false, __('coupon.invalid_code'));
        }

        if (!$coupon['is_active'])                            json_resp(false, __('coupon.inactive'));

        if ($coupon['expires_at'] && strtotime($coupon['expires_at']) < time()) json_resp(false, __('coupon.expired'));

        if ($coupon['used_count'] >= $coupon['max_uses'])     json_resp(false, __('coupon.limit'));

        $usd = $db->prepare('SELECT id FROM coupon_usages WHERE user_id=? AND coupon_id=?');

        $usd->execute([$uid,$coupon['id']]);

        if ($usd->fetch()) json_resp(false, __('msg.coupon_used'));

        unset($_SESSION['coupon_try']);

        $rt = $coupon['reward_type'];

        if ($rt === 'discount') {

            $cs2 = $db->prepare('SELECT SUM(p.price*(1-LEAST(COALESCE(p.discount_percent,0),90)/100.0)*c.quantity) FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"');

            $cs2->execute([$uid]);

            $ct = (float)($cs2->fetchColumn() ?? 0);

            if ($ct <= 0) {
                $cntChk = $db->prepare('SELECT COUNT(*) FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"');
                $cntChk->execute([$uid]);
                if ((int)$cntChk->fetchColumn() === 0) json_resp(false, __('cart.empty_short'));
                json_resp(false, __('coupon.free_no'));
            }

            $tp = $coupon['type']; $val = (float)$coupon['reward_value'];

            $disc = coupon_discount_for_total(['type'=>$tp,'value'=>$val], $ct);

            if ($tp === 'percent') { $label = coupon_label($tp, $val); }

            elseif ($tp === 'flat_tl') { $label = coupon_label($tp, $val); }

            elseif ($tp === 'flat_usd') { $label = coupon_label($tp, $val); }

            elseif ($tp === 'flat_eur') { $label = coupon_label($tp, $val); }

            else { $disc = 0; $label = coupon_label('', 0); }

            $_SESSION['applied_coupon'] = ['id'=>$coupon['id'],'code'=>$coupon['code'],'discount'=>$disc,'type'=>$tp,'value'=>$val];

            json_resp(true, __('coupon.applied'), ['original_total'=>$ct,'discount'=>$disc,'new_total'=>max(0,$ct-$disc),'label'=>$label]);

        }

        $rawPids = trim((string)($coupon['grant_product_ids'] ?? ''));

        $pids = [];

        if ($rawPids !== '') {

            $decoded = json_decode($rawPids, true);

            if (is_array($decoded)) {

                foreach ($decoded as $v) { $v = (int)$v; if ($v > 0 && !in_array($v, $pids, true)) $pids[] = $v; }

            } elseif (is_numeric($rawPids)) {

                $pids[] = (int)$rawPids;

            }

        }

        if (empty($pids)) $pids = [(int)$coupon['reward_value']];

        $pids = array_values(array_filter($pids, fn($v) => $v > 0));

        if (empty($pids)) json_resp(false, __('coupon.no_products'));

        $granted = [];

        foreach ($pids as $gpId) {

            $gpck = $db->prepare('SELECT id,name,user_notice,stock_type,stock FROM products WHERE id=?');

            $gpck->execute([$gpId]);

            $gp = $gpck->fetch();

            if (!$gp) continue;

            if (($gp['stock_type'] ?? 'unlimited') === 'limited' && stock_items_available($db, (int)$gpId) < 1) continue;

            $granted[] = ['id' => $gpId, 'name' => $gp['name'], 'notice' => trim((string)($gp['user_notice'] ?? ''))];

        }

        if (empty($granted)) json_resp(false, __('coupon.no_products'));

        if ($rt === 'product_grant') {

            $newPids = [];

            foreach ($granted as $g) {

                $ow = $db->prepare('SELECT id FROM sales WHERE user_id=? AND product_id=?');

                $ow->execute([$uid, $g['id']]);

                if (!$ow->fetch()) $newPids[] = $g;

            }

            if (empty($newPids)) json_resp(false, __('shop.owns_all'));

            $db->beginTransaction();

            try {

                $cLock = $db->prepare('SELECT used_count,max_uses,is_active,expires_at FROM coupons WHERE id=? FOR UPDATE');

                $cLock->execute([$coupon['id']]);

                $cRow = $cLock->fetch();

                if (!$cRow || empty($cRow['is_active']) || (!empty($cRow['expires_at']) && strtotime($cRow['expires_at']) < time()) || $cRow['used_count'] >= $cRow['max_uses']) { $db->rollBack(); json_resp(false, __('coupon.limit')); }

                $uUsedG = $db->prepare('SELECT id FROM coupon_usages WHERE user_id=? AND coupon_id=?');

                $uUsedG->execute([$uid, $coupon['id']]);

                if ($uUsedG->fetch()) { $db->rollBack(); json_resp(false, __('msg.coupon_used')); }

                $newPids = [];

                foreach ($granted as $g) {

                    $ow2 = $db->prepare('SELECT id FROM sales WHERE user_id=? AND product_id=?');

                    $ow2->execute([$uid, $g['id']]);

                    if (!$ow2->fetch()) $newPids[] = $g;

                }

                if (empty($newPids)) { $db->rollBack(); json_resp(false, __('shop.owns_all')); }

                foreach ($newPids as $g) {

                    $saleCurG = function_exists('store_currency') ? store_currency() : 'TRY';
                    $db->prepare('INSERT INTO sales (user_id,product_id,price_paid,currency,purchased_at) VALUES (?,?,0,?,NOW())')->execute([$uid, $g['id'], $saleCurG]);

                    $sid = (int)$db->lastInsertId();

                    $lic = stock_consume($db, (int)$g['id'], 1, $uid);

                    if ($lic !== null) $db->prepare('UPDATE sales SET license_key=? WHERE id=?')->execute([$lic, $sid]);

                    $grantedResult[] = ['product_name' => $g['name'], 'license_key' => $lic ?? '', 'notice' => $g['notice'] ?? ''];

                }

                $upC = $db->prepare('UPDATE coupons SET used_count=used_count+1 WHERE id=? AND used_count<max_uses');

                $upC->execute([$coupon['id']]);

                if ($upC->rowCount() === 0) { $db->rollBack(); json_resp(false, __('coupon.limit')); }

                $db->prepare('INSERT IGNORE INTO coupon_usages (user_id,coupon_id) VALUES (?,?)')->execute([$uid, $coupon['id']]);

                $db->commit();

            } catch (\Exception $e) { $db->rollBack(); json_resp(false, __('shop.grant_fail')); }

            require_once ROOT_PATH . '/core/discord.php';

            discord_notify($db, 'coupon', __('bsupp.coupon_title'), __('bsupp.coupon_body_product'), [

                __('bsupp.f_coupon')     => $coupon['code'],

                __('bsupp.f_user') => auth_user()['username'],

                __('bsupp.f_products')   => implode(', ', array_map(fn($g) => $g['name'], $newPids)),

            ], '5793549');

            json_resp(true, __('msg.granted'), ['products' => $grantedResult ?? [], 'granted_count' => count($grantedResult ?? [])]);

        }

        if ($rt === 'license_grant') {

            $cuChk = $db->prepare('SELECT id FROM coupon_usages WHERE user_id=? AND coupon_id=?');

            $cuChk->execute([$uid, $coupon['id']]);

            if ($cuChk->fetch()) json_resp(false, __('msg.coupon_used'));

            $newLicPids = [];

            foreach ($granted as $g) {

                $owL = $db->prepare('SELECT id FROM sales WHERE user_id=? AND product_id=?');

                $owL->execute([$uid, $g['id']]);

                if (!$owL->fetch()) $newLicPids[] = $g;

            }

            if (empty($newLicPids)) json_resp(false, __('shop.owns_all'));

            foreach ($newLicPids as $gL) {

                if (!stock_available($db, (int)$gL['id'], 1)) json_resp(false, __('bshop.out_of_stock', ['name' => $gL['name']]));

            }

            $granted = $newLicPids;

        }

        $db->beginTransaction();

        try {

            $cLock2 = $db->prepare('SELECT used_count,max_uses,is_active,expires_at FROM coupons WHERE id=? FOR UPDATE');

            $cLock2->execute([$coupon['id']]);

            $cRow2 = $cLock2->fetch();

            if (!$cRow2 || empty($cRow2['is_active']) || (!empty($cRow2['expires_at']) && strtotime($cRow2['expires_at']) < time()) || $cRow2['used_count'] >= $cRow2['max_uses']) { $db->rollBack(); json_resp(false, __('coupon.limit')); }

            $uUsedG2 = $db->prepare('SELECT id FROM coupon_usages WHERE user_id=? AND coupon_id=?');

            $uUsedG2->execute([$uid, $coupon['id']]);

            if ($uUsedG2->fetch()) { $db->rollBack(); json_resp(false, __('msg.coupon_used')); }

            $grantedResult2 = [];

            foreach ($granted as $g) {

                $insL = $db->prepare('INSERT INTO licenses (product_id,user_id,license_key,status,created_at) VALUES (?,?,?,"active",NOW())');

                $lk2 = '';

                for ($try = 0; $try < 5; $try++) {

                    $lkTry = strtoupper(implode('-', str_split(bin2hex(random_bytes(8)), 4)));

                    try {

                        $insL->execute([$g['id'], $uid, $lkTry]);

                        $lk2 = $lkTry;

                        break;

                    } catch (\PDOException $e) {

                        if ($insL->errorCode() !== '23000') throw $e;

                    }

                }

                if ($lk2 === '') { $db->rollBack(); json_resp(false, __('msg.license_fail')); }

                stock_consume($db, (int)$g['id'], 1, $uid);

                $grantedResult2[] = ['product_name' => $g['name'], 'license_key' => $lk2, 'notice' => $g['notice'] ?? ''];

            }

            $upC2 = $db->prepare('UPDATE coupons SET used_count=used_count+1 WHERE id=? AND used_count<max_uses');

            $upC2->execute([$coupon['id']]);

            if ($upC2->rowCount() === 0) { $db->rollBack(); json_resp(false, __('coupon.limit')); }

            $db->prepare('INSERT IGNORE INTO coupon_usages (user_id,coupon_id) VALUES (?,?)')->execute([$uid, $coupon['id']]);

            $db->commit();

        } catch (\Exception $e) { $db->rollBack(); json_resp(false, __('msg.license_fail')); }

        require_once ROOT_PATH . '/core/discord.php';

        discord_notify($db, 'coupon', __('bsupp.coupon_title'), __('bsupp.coupon_body_license'), [

            __('bsupp.f_coupon')     => $coupon['code'],

            __('bsupp.f_user') => auth_user()['username'],

            __('bsupp.f_products')   => implode(', ', array_map(fn($g) => $g['name'], $granted)),

        ], '5793549');

        json_resp(true, __('msg.licenses_granted'), ['products' => $grantedResult2, 'granted_count' => count($grantedResult2)]);
    case 'manage_coupon':

        require_resource('coupons');

        if (!feature_active('coupons')) redirect_back(__('coupon.off'), 'error');

        $op = $_POST['op'] ?? '';

        if ($op === 'add') {

            $code = strtoupper(trim($_POST['code'] ?? ''));

            $type = $_POST['type'] ?? 'percent';

            if (!in_array($type, ['percent','flat_tl','flat_usd','flat_eur'], true)) redirect_back(__('coupon.bad_type'), 'error');

            $rt   = $_POST['reward_type'] ?? 'discount';

            if (!in_array($rt, ['discount','product_grant','license_grant'], true)) redirect_back(__('coupon.bad_reward'), 'error');

            $rv   = (float)($_POST['reward_value'] ?? 0);

            if ($rt === 'discount' && $type === 'percent' && ($rv <= 0 || $rv > 100)) redirect_back(__('coupon.pct_range'), 'error');

            if ($rt === 'discount' && $type !== 'percent' && $rv <= 0) redirect_back(__('coupon.positive'), 'error');

            $mu   = max(1,(int)($_POST['max_uses'] ?? 1));

            $ea   = trim($_POST['expires_at'] ?? '');

            if ($ea !== '' && strtotime($ea) === false) redirect_back(__('err.bad_date'), 'error');

            $gIdsJson = null;

            if ($rt !== 'discount') {

                $pidList = [];

                foreach (explode(',', trim($_POST['grant_product_ids'] ?? '')) as $raw) {

                    $raw = (int)$raw;

                    if ($raw > 0 && !in_array($raw, $pidList, true)) $pidList[] = $raw;

                }

                if (empty($pidList)) redirect_back(__('coupon.need_product'), 'error');

                $gChk = $db->prepare('SELECT id FROM products WHERE id=?');

                foreach ($pidList as $gPid) {

                    $gChk->execute([$gPid]);

                    if (!$gChk->fetch()) redirect_back(__('coupon.bad_product'), 'error');

                }

                $rv = $pidList[0];

                $gIdsJson = json_encode($pidList, JSON_UNESCAPED_UNICODE);

            }

            if (!$code || $rv < 0) redirect_back(__('coupon.code_value'), 'error');

            try { $db->prepare('INSERT INTO coupons (code,type,reward_type,reward_value,grant_product_ids,max_uses,is_active,expires_at) VALUES (?,?,?,?,?,?,1,?)')->execute([$code,$type,$rt,$rv,$gIdsJson,$mu,$ea?:null]); audit_log($db, 'create', 'coupons', (int)$db->lastInsertId(), $code, '/admin/coupons.php'); redirect_back(__("bshop.coupon_created", ["code" => $code])); }

            catch(\PDOException $e) { redirect_back('Bu kupon kodu zaten mevcut.', 'error'); }

        }

        if ($op === 'delete') {

            $id = (int)($_POST['id'] ?? 0);

            if (!$id) redirect_back(__('err.invalid_id'), 'error');

            $db->prepare('DELETE FROM coupons WHERE id=?')->execute([$id]);

            try { $db->prepare('DELETE FROM coupon_usages WHERE coupon_id=?')->execute([$id]); } catch (\Throwable $e) {}

            audit_log($db, 'delete', 'coupons', $id, '#' . $id, '/admin/coupons.php');
            redirect_back('Kupon silindi.');

        }

        if ($op === 'toggle_active') {

            $id = (int)($_POST['id'] ?? 0);

            if (!$id) redirect_back(__('err.invalid_id'), 'error');

            $db->prepare('UPDATE coupons SET is_active=IF(is_active=1,0,1) WHERE id=?')->execute([$id]);

            audit_log($db, 'update', 'coupons', $id, '#' . $id, '/admin/coupons.php');
            redirect_back(__('coupon.status_ok'));

        }

        redirect_back(__('err.unknown_action'), 'error');
    case 'balance_topup':

        require_login();

        $uidT = (int)auth_user()['id'];

        $amountT = (float)($_POST['amount'] ?? 0);

        $minT = topup_min_amount();

        $amountT = is_finite($amountT) ? round($amountT, 2) : 0;

        if ($amountT < $minT) json_resp(false, __('topup.min_error', ['m' => fmt_money($minT)]));

        if (!plan_payments_allowed($db)) json_resp(false, __('plan.payments_paused'));

        $maxT = max(100000, $minT * 10);
        if ($amountT > $maxT) $amountT = $maxT;

        $cfgRawT = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_%'")->fetchAll();

        $cfgT = []; foreach ($cfgRawT as $r) $cfgT[$r['key']] = $r['value'];

        $shopierReadyT = (($cfgT['payment_shopier_active'] ?? '0') === '1' && !empty($cfgT['payment_shopier_pat'] ?? '') && !empty($cfgT['payment_shopier_shop_slug'] ?? '') && !empty($cfgT['payment_shopier_osb_username'] ?? '') && !empty($cfgT['payment_shopier_osb_password'] ?? ''));

        $paytrReadyT = paytr_is_ready($db);

        $iyzicoReadyT = iyzico_is_ready($db);

        $stripeReadyT = stripe_is_ready($db);

        $paypalReadyT = paypal_is_ready($db);

        $bitpayReadyT = bitpay_is_ready($db);

        $cryptReadyT = crypt_is_ready($db);

        $paywantReadyT = paywant_is_ready($db);

        $whopReadyT = whop_is_ready($db);
        $paddleReadyT = function_exists('paddle_is_ready') ? paddle_is_ready($db) : false;
        $lemonReadyT = function_exists('lemonsqueezy_is_ready') ? lemonsqueezy_is_ready($db) : false;
        $dodoReadyT = function_exists('dodopayments_is_ready') ? dodopayments_is_ready($db) : false;

        if (!$shopierReadyT && !$paytrReadyT && !$iyzicoReadyT && !$stripeReadyT && !$paypalReadyT && !$bitpayReadyT && !$cryptReadyT && !$paywantReadyT && !$whopReadyT && !$paddleReadyT && !$lemonReadyT && !$dodoReadyT)

            json_resp(false, __('shop.no_method'));

        $meT = auth_user();

        $readyT = [];

        if ($shopierReadyT) $readyT[] = 'shopier';

        if ($paytrReadyT)   $readyT[] = 'paytr';

        if ($iyzicoReadyT)  $readyT[] = 'iyzico';

        if ($stripeReadyT)  $readyT[] = 'stripe';

        if ($paypalReadyT)  $readyT[] = 'paypal';

        if ($bitpayReadyT)  $readyT[] = 'bitpay';

        if ($cryptReadyT)   $readyT[] = 'crypt';

        if ($paywantReadyT) $readyT[] = 'paywant';

        if ($whopReadyT) $readyT[] = 'whop';
        if ($paddleReadyT) $readyT[] = 'paddle';
        if ($lemonReadyT) $readyT[] = 'lemonsqueezy';
        if ($dodoReadyT) $readyT[] = 'dodopayments';

        $methodT = trim((string)($_POST['method'] ?? ''));

        if (strncmp($methodT, 'mod:', 4) === 0) {
            $gwCode = substr($methodT, 4);
            $gw = function_exists('modules_gateway_find') ? modules_gateway_find($gwCode, $db) : null;
            if (!$gw) json_resp(false, __('pay.no_method'));
            json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/module-pay?gateway=' . urlencode($gwCode) . '&topup=' . $amountT]);
        }

        if (!in_array($methodT, $readyT, true)) $methodT = $readyT[0];

        if ($methodT === 'iyzico') {

            json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/iyzico-pay?topup=' . $amountT]);

        }

        if ($methodT === 'stripe') {

            json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/stripe-pay?topup=' . $amountT]);

        }

        if ($methodT === 'paypal') {

            json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/paypal-pay?topup=' . $amountT]);

        }

        if ($methodT === 'bitpay') {

            json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/bitpay-pay?topup=' . $amountT]);

        }

        if ($methodT === 'crypt') {

            json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/crypt-pay?topup=' . $amountT]);

        }

        if ($methodT === 'paywant') {

            json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/paywant-pay?topup=' . $amountT]);

        }

        if ($methodT === 'whop') {

            json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/whop-pay?topup=' . $amountT]);

        }

        if ($methodT === 'paddle') {

            json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/paddle-pay?topup=' . $amountT]);

        }

        if ($methodT === 'lemonsqueezy') {

            json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/lemonsqueezy-pay?topup=' . $amountT]);

        }

        if ($methodT === 'dodopayments') {

            json_resp(true, __('topup.redirecting'), ['redirect' => '/shop/dodopayments-pay?topup=' . $amountT]);

        }

        $orderIdT = 'TOPUP-' . $uidT . '-' . time() . '-' . bin2hex(random_bytes(4));

        $payMethodT = $methodT;

        try {

            $db->prepare('INSERT INTO payment_intents (user_id,order_id,total_amount,currency,status,payment_method) VALUES (?,?,?,?,"pending",?)')

               ->execute([$uidT, $orderIdT, $amountT, store_currency(), $payMethodT]);

        } catch (\PDOException $e) {

            error_log('[NS] balance_topup: '.$e->getMessage());

            json_resp(false, __('op.start_fail'));

        }

        if ($methodT === 'shopier') {
            $chCurT = function_exists('shopier_currency') ? shopier_currency($db) : 'TRY';
            $chTotalT = $chCurT === store_currency() ? $amountT : fx_convert($amountT, store_currency(), $chCurT);
            $db->prepare('UPDATE payment_intents SET total_amount=?, currency=? WHERE order_id=?')->execute([$chTotalT, $chCurT, $orderIdT]);
            try {
                $resultT = shopier_create_checkout($db, (float)$chTotalT, $orderIdT, gateway_topup_title($db, (float)$chTotalT), shopier_payment_image($db));
                $db->prepare('UPDATE payment_intents SET payment_id=?, shopier_product_id=? WHERE order_id=?')->execute([$resultT['product_id'], $resultT['product_id'], $orderIdT]);
                json_resp(true, __('topup.redirecting'), ['html' => $resultT['checkout_html']]);
            } catch (Throwable $eT) {
                error_log('[NS] balance_topup shopier: '.$eT->getMessage());
                $db->prepare('UPDATE payment_intents SET status="failed" WHERE order_id=?')->execute([$orderIdT]);
                json_resp(false, __('bshop.shopier_fail'));
            }
        } else {

            $chCurT = function_exists('paytr_normalize_currency') ? paytr_normalize_currency((string)($db->query("SELECT `value` FROM settings WHERE `key`='payment_paytr_currency' LIMIT 1")->fetchColumn() ?? 'TRY')) : 'TRY';
            $chTotalT = ($chCurT === store_currency() || ($chCurT === 'TL' && store_currency() === 'TRY')) ? $amountT : fx_convert($amountT, store_currency(), $chCurT);
            $db->prepare('UPDATE payment_intents SET total_amount=?, currency=? WHERE order_id=?')->execute([$chTotalT, $chCurT, $orderIdT]);
            $basketT = [[__('panel.tx_topup'), number_format($chTotalT, 2, '.', ''), 1]];

            try {

                $paytrUrlT = paytr_create_payment($db, $orderIdT, $meT['email'], $meT['username'], '8501234567', $chTotalT, $basketT);

                json_resp(true, __('topup.redirecting'), ['redirect' => $paytrUrlT]);

            } catch (\Exception $eT) {

                error_log('[NS] balance_topup paytr: ' . $eT->getMessage());

                json_resp(false, __('pay.page_fail'));

            }

        }
    case 'shopier_pay':
        require_login();
        $uidS = (int)auth_user()['id'];
        $cartS = $db->prepare('SELECT c.product_id,c.quantity,p.price,p.discount_percent,p.name,p.license_prefix FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"');
        $cartS->execute([$uidS]);
        $itemsS = $cartS->fetchAll();
        if (empty($itemsS)) { header('Location: /products?flash='.urlencode('error:'.__('cart.empty_short')), true, 302); exit; }
        require_once ROOT_PATH . '/core/purchase.php';
        $itemsS = purchase_filter_owned($db, $uidS, $itemsS);
        if (empty($itemsS)) { header('Location: /products?flash='.urlencode('error:'.__('bshop.already_owned')), true, 302); exit; }
        $cfgS = shopier_cfg($db);
        if (($cfgS['payment_shopier_active'] ?? '0') !== '1' || empty($cfgS['payment_shopier_pat'] ?? '') || empty($cfgS['payment_shopier_shop_slug'] ?? '') || empty($cfgS['payment_shopier_osb_username'] ?? '') || empty($cfgS['payment_shopier_osb_password'] ?? '')) {
            header('Location: /shop/payment?flash='.urlencode('error:'.__('bshop.shopier_cfg')), true, 302); exit;
        }
        $totalS = cart_effective_total($itemsS);
        if (function_exists('apply_filters')) $totalS = (float)apply_filters('checkout_total', $totalS, $itemsS);
        $appliedCouponS = coupon_resolve_for_pay($db, $_SESSION['applied_coupon'] ?? null, $uidS);
        if ($appliedCouponS) {
            $totalS = max(0, $totalS - coupon_discount_for_total($appliedCouponS, $totalS));
        }
        if ($totalS <= 0) {
            header('Location: /products?flash=' . urlencode('error:'.__('bshop.free_no_pay')), true, 302);
            exit;
        }
        if (!plan_payments_allowed($db)) { header('Location: /shop/payment?flash='.urlencode('error:'.__('plan.payments_paused')), true, 302); exit; }
        $orderIdS = 'SP-' . $uidS . '-' . time() . '-' . bin2hex(random_bytes(4));
        require_once ROOT_PATH . '/core/purchase.php';
        $snapS = purchase_snapshot_build($itemsS, $appliedCouponS);
        $chCurS = function_exists('shopier_currency') ? shopier_currency($db) : 'TRY';
        $chTotalS = $chCurS === store_currency() ? $totalS : fx_convert($totalS, store_currency(), $chCurS);
        try {
            $db->prepare('INSERT INTO payment_intents (user_id,order_id,total_amount,currency,items_snapshot,status,payment_method) VALUES (?,?,?,?,? ,"pending","shopier")')
               ->execute([$uidS, $orderIdS, $chTotalS, $chCurS, $snapS]);
            $meS = auth_user();
            $imgS = $db->prepare('SELECT p.image_url FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? ORDER BY c.added_at ASC LIMIT 1');
            $imgS->execute([$uidS]);
            $resultS = shopier_create_checkout($db, (float)$chTotalS, $orderIdS, __('bshop.order_no', ['store' => store_name($db), 'n' => $orderIdS]), $imgS->fetchColumn() ?: null);
            $db->prepare('UPDATE payment_intents SET payment_id=?, shopier_product_id=? WHERE order_id=?')->execute([$resultS['product_id'], $resultS['product_id'], $orderIdS]);
            echo $resultS['checkout_html'];
            exit;
        } catch (\Throwable $eS) {
            error_log('[NS] shopier_pay: '.$eS->getMessage().' in '.$eS->getFile().':'.$eS->getLine());
            $db->prepare('UPDATE payment_intents SET status="failed" WHERE order_id=?')->execute([$orderIdS]);
            header('Location: /shop/payment?flash='.urlencode('error:'.__('bshop.shopier_fail')), true, 302); exit;
        }
    case 'paytr_pay':

        require_login();

        $uidP = (int)auth_user()['id'];

        $cartP = $db->prepare('SELECT c.product_id,c.quantity,p.name,p.price,p.discount_percent,p.license_prefix FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"');

        $cartP->execute([$uidP]);

        $itemsP = $cartP->fetchAll();

        if (empty($itemsP)) { header('Location: /products?flash='.urlencode('error:'.__('cart.empty_short')), true, 302); exit; }

        require_once ROOT_PATH . '/core/purchase.php';

        $itemsP = purchase_filter_owned($db, $uidP, $itemsP);

        if (empty($itemsP)) { header('Location: /products?flash='.urlencode('error:'.__('bshop.already_owned')), true, 302); exit; }

        if (!paytr_is_ready($db)) {

            header('Location: /shop/payment?flash='.urlencode('error:'.__('bshop.paytr_off')), true, 302); exit;

        }

        $totalP = cart_effective_total($itemsP);

        if (function_exists('apply_filters')) $totalP = (float)apply_filters('checkout_total', $totalP, $itemsP);

        $appliedCouponP = coupon_resolve_for_pay($db, $_SESSION['applied_coupon'] ?? null, $uidP);

        if ($appliedCouponP) {

            $totalP = max(0, $totalP - coupon_discount_for_total($appliedCouponP, $totalP));

        }

        if ($totalP <= 0) {
            header('Location: /products?flash=' . urlencode('error:'.__('bshop.free_no_pay')), true, 302);
            exit;
        }

        if (!plan_payments_allowed($db)) { header('Location: /shop/payment?flash='.urlencode('error:'.__('plan.payments_paused')), true, 302); exit; }
        $orderIdP = 'SP-' . $uidP . '-' . time() . '-' . bin2hex(random_bytes(4));

        require_once ROOT_PATH . '/core/purchase.php';

        $snapP = purchase_snapshot_build($itemsP, $appliedCouponP);
        $chCurP = function_exists('paytr_normalize_currency') ? paytr_normalize_currency((string)($db->query("SELECT `value` FROM settings WHERE `key`='payment_paytr_currency' LIMIT 1")->fetchColumn() ?? 'TRY')) : 'TRY';
        $chTotalP = ($chCurP === store_currency() || ($chCurP === 'TL' && store_currency() === 'TRY')) ? $totalP : fx_convert($totalP, store_currency(), $chCurP);

        try {

            $db->prepare('INSERT INTO payment_intents (user_id,order_id,total_amount,currency,items_snapshot,status,payment_method) VALUES (?,?,?,?,?,"pending","paytr")')

               ->execute([$uidP, $orderIdP, $chTotalP, $chCurP, $snapP]);

        } catch (\PDOException $e) {

            error_log('[NS] paytr_pay: '.$e->getMessage());

            header('Location: /shop/payment?flash='.urlencode('error:'.__('bshop.pay_fail')), true, 302); exit;

        }

        $meP = auth_user();

        $basketP = [];

        foreach ($itemsP as $itP) $basketP[] = [$itP['name'], number_format(fx_convert(product_effective_price($itP['price'], $itP['discount_percent'] ?? 0), store_currency(), $chCurP), 2, '.', ''), (int)$itP['quantity']];

        try {

            $paytrUrlP = paytr_create_payment($db, $orderIdP, $meP['email'], $meP['username'], '8501234567', $chTotalP, $basketP);

            header('Location: ' . $paytrUrlP, true, 302);

            exit;

        } catch (\Exception $eP) {

            error_log('[NS] paytr_pay token: ' . $eP->getMessage());

            header('Location: /shop/payment?flash='.urlencode('error:'.__('bshop.pay_page_fail')), true, 302); exit;

        }
    case 'shopier_test':
        require_admin();
        try {
            require_once ROOT_PATH . '/core/shopier.php';
            shopier_test_connection($db);
            json_resp(true, __('bsys.shopier_ok'));
        } catch (Throwable $e) {
            error_log('[NS] shopier_test: '.$e->getMessage());
            json_resp(false, __('bsys.shopier_fail'));
        }

    // ─── Discord Webhook Test ───
    case 'get_balance_status':
        require_login();
        $uidGbs = (int)auth_user()['id'];
        try {
            $stGbs = $db->prepare(
                "SELECT status FROM payment_intents
                 WHERE user_id=? AND order_id LIKE 'TOPUP-%'
                 ORDER BY created_at DESC LIMIT 1"
            );
            $stGbs->execute([$uidGbs]);
            $rowGbs = $stGbs->fetch();
            if ($rowGbs && $rowGbs['status'] === 'completed') {
                $balGbs = $db->prepare('SELECT balance FROM users WHERE id=?');
                $balGbs->execute([$uidGbs]);
                $newBal = (float)($balGbs->fetchColumn() ?? 0);
                json_resp(true, __('pay.approved'), ['paid' => true, 'balance' => $newBal]);
            }
            json_resp(true, 'Bekleniyor.', ['paid' => false]);
        } catch (\Throwable $eGbs) {
            error_log('[NS] get_balance_status: '.$eGbs->getMessage().' in '.$eGbs->getFile().':'.$eGbs->getLine());
            json_resp(false, 'Durum kontrol edilemedi.');
        }

    default:

        json_resp(false, __('err.unknown_action'));

}
