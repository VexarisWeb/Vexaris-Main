<?php
if (!defined('NEXUS_BOOT')) { http_response_code(403); exit; }

switch ($action) {

    case 'cookie_consent':

        require_login();

        $cpref = $_POST['pref'] ?? 'all';

        $cpref = in_array($cpref, ['all','essential'], true) ? $cpref : 'all';

        try {

            $db->prepare('UPDATE users SET cookie_consent=1, cookie_pref=? WHERE id=?')->execute([$cpref, (int)auth_user()['id']]);

            json_resp(true, 'ok');

        } catch (\PDOException $e) { json_resp(false, 'hata'); }
    case 'ticket_category_save':

        require_resource('ticket_categories');

        $id   = (int)($_POST['id'] ?? 0);

        $name = trim($_POST['name'] ?? '');

        if (!$name) redirect_back(__('err.category_required'), 'error');

        $icon = trim($_POST['icon'] ?? '');

        $sort = max(0, (int)($_POST['sort_order'] ?? 0));

        try {

            if ($id) {

                $db->prepare('UPDATE ticket_categories SET name=?,icon=?,sort_order=? WHERE id=?')->execute([$name,$icon,$sort,$id]);

                audit_log($db, 'update', 'ticket_categories', $id, $name, '/admin/ticket-categories.php');

            } else {

                $db->prepare('INSERT INTO ticket_categories (name,icon,sort_order) VALUES (?,?,?)')->execute([$name,$icon,$sort]);

                audit_log($db, 'create', 'ticket_categories', (int)$db->lastInsertId(), $name, '/admin/ticket-categories.php');

            }

            redirect_back('Kategori kaydedildi.');

        } catch (\PDOException $e) { error_log('[NS] ticket_category_save: '.$e->getMessage()); redirect_back('Kaydedilemedi.', 'error'); }
    case 'ticket_category_delete':

        require_resource('ticket_categories');

        $id = (int)($_POST['id'] ?? 0);

        if (!$id) redirect_back(__('err.invalid_id'), 'error');

        try {

            $db->prepare('DELETE FROM ticket_categories WHERE id=?')->execute([$id]);

            audit_log($db, 'delete', 'ticket_categories', $id, '#' . $id, '/admin/ticket-categories.php');
            redirect_back('Kategori silindi.');

        } catch (\PDOException $e) { error_log('[NS] ticket_category_delete: '.$e->getMessage()); redirect_back('Silinemedi.', 'error'); }
    case 'ticket_create':

        require_login();

        if (!feature_active('tickets')) redirect_back(__('err.feature_off'), 'error');

        if (!verify_captcha()) redirect_back(__('err.captcha'), 'error');

        $uid     = (int)auth_user()['id'];

        $title   = mb_substr(trim($_POST['title'] ?? ''), 0, 255);

        $cat     = mb_substr(trim($_POST['category'] ?? 'Genel'), 0, 60);

        if (mb_strtolower($cat) === 'havale talebi') redirect_back(__('err.invalid_category'), 'error');

        $message = trim(strip_tags(trim($_POST['message'] ?? '')));

        if (strlen($title) < 3 || strlen($message) < 10) redirect_back(__('err.title_message_short'), 'error');

        try {

            $db->beginTransaction();

            $tc = $db->prepare("SELECT COUNT(*) FROM tickets WHERE user_id=? AND status!='closed' AND category!='Havale Talebi' FOR UPDATE");

            $tc->execute([$uid]);

            if ((int)$tc->fetchColumn() >= 1) { $db->rollBack(); redirect_back(__('err.ticket_open_exists'), 'error'); }

            $db->prepare('INSERT INTO tickets (user_id,title,category,message,status,created_at,updated_at) VALUES (?,?,?,?,"open",NOW(),NOW())')->execute([$uid,$title,$cat,$message]);

            $newTid = (int)$db->lastInsertId();

            $db->commit();

            require_once ROOT_PATH . '/core/discord.php';

            discord_notify($db, 'ticket', __('bsupp.ticket_new'), __('bsupp.ticket_new_body'), [

                __('bsupp.field_user') => auth_user()['username'],

                __('bsupp.field_title') => $title,

                'Kategori'  => $cat,

            ], '16268780');

            audit_log($db, 'create', 'support', $newTid, $title, '/admin/tickets.php');
            header('Location: /support?id='.$newTid.'&flash='.urlencode('success:'.__('msg.ticket_created'))); exit;

        } catch (\PDOException $e) { error_log('[NS] ticket_create: '.$e->getMessage()); redirect_back(__('err.ticket_create_fail'), 'error'); }
    case 'ticket_reply':

        require_login();

        if (!feature_active('tickets')) redirect_back(__('err.feature_off'), 'error');

        $uid = (int)auth_user()['id'];

        $tid = (int)($_POST['ticket_id'] ?? 0);

        $rawMsg = $_POST['message'] ?? '';

        $msg = mb_substr(trim(strip_tags($rawMsg)), 0, 500);

        $imgUp = ticket_store_image($_FILES['image'] ?? []);

        $wantsJson = (($_POST['is_fetch'] ?? '') === '1') || (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false);

        if (!$tid || ($msg === '' && empty($imgUp['path']))) {
            if ($wantsJson) json_resp(false, __('err.empty_message'));
            redirect_back(__('err.invalid_request'), 'error');
        }

        if (!$imgUp['ok']) {
            if ($wantsJson) json_resp(false, $imgUp['msg']);
            redirect_back($imgUp['msg'], 'error');
        }

        try {

            $tc=$db->prepare('SELECT id,status FROM tickets WHERE id=? AND user_id=?'); $tc->execute([$tid,$uid]); $tr=$tc->fetch();

            if (!$tr) {
                if ($wantsJson) json_resp(false, __('err.ticket_missing'));
                redirect_back(__('err.ticket_missing'), 'error');
            }

            if ($tr['status'] === 'closed') {
                if ($wantsJson) json_resp(false, __('err.ticket_closed'));
                redirect_back(__('err.ticket_closed'), 'error');
            }

            $db->prepare('INSERT INTO ticket_replies (ticket_id,user_id,is_admin,message,image_url,created_at) VALUES (?,?,0,?,?,NOW())')->execute([$tid,$uid,$msg,$imgUp['path']]);

            $rid = (int)$db->lastInsertId();
            audit_log($db, 'update', 'support', $tid, '#' . $tid, '/admin/tickets.php');

            $db->prepare('UPDATE tickets SET status="open",updated_at=NOW() WHERE id=? AND user_id=?')->execute([$tid,$uid]);

            require_once ROOT_PATH . '/core/discord.php';

            $tDisc = [__('bsupp.field_user') => auth_user()['username'], __('bsupp.field_ticket') => '#'.$tid];

            if ($wantsJson) {
                if (ob_get_level() > 0) ob_clean();
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['ok' => true, 'msg' => __('bsupp.msg_sent'), 'id' => $rid, 'message' => $msg, 'image' => $imgUp['path'], 'created' => date('d.m.Y H:i')]);
                session_write_close();
                if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();
                discord_notify($db, 'ticket_reply', __('bsupp.ticket_reply'), __('bsupp.ticket_reply_body'), $tDisc, '16268780');
                exit;
            }

            discord_notify($db, 'ticket_reply', __('bsupp.ticket_reply'), __('bsupp.ticket_reply_body'), $tDisc, '16268780');

            header('Location: /support?id='.$tid.'&flash='.urlencode('success:'.__('bsupp.msg_sent'))); exit;

        } catch (\PDOException $e) { error_log('[NS] ticket_reply: '.$e->getMessage()); redirect_back(__('err.reply_fail'), 'error'); }
    case 'ticket_poll':

        require_login();

        $uid = (int)auth_user()['id'];

        $tid = (int)($_POST['ticket_id'] ?? 0);

        $after = (int)($_POST['after_id'] ?? 0);

        if (!$tid) json_resp(false, __('err.invalid_request'));

        try {

            $own = $db->prepare('SELECT id,status FROM tickets WHERE id=? AND user_id=?');

            $own->execute([$tid,$uid]);

            $trow = $own->fetch();

            $adminMode = false;

            if (!$trow) {

                $role = auth_user()['role'] ?? 'user';

                $can = in_array($role, ['admin', 'superadmin'], true);

                if (!$can) {

                    $ps = $db->prepare('SELECT COUNT(*) FROM permissions WHERE role=? AND resource=?');

                    $ps->execute([$role,'support']);

                    $can = (int)$ps->fetchColumn() > 0;

                }

                if (!$can) json_resp(false, 'Yetkiniz yok.');

                $chk = $db->prepare('SELECT id,status FROM tickets WHERE id=?');

                $chk->execute([$tid]);

                $trow = $chk->fetch();

                if (!$trow) json_resp(false, __('err.ticket_missing'));

                $adminMode = true;

            }

            $markAdmin = $adminMode ? 0 : 1;

            $viewing = (($_POST['viewing'] ?? '') === '1');

            if ($viewing) $db->prepare('UPDATE ticket_replies SET is_seen=1 WHERE ticket_id=? AND is_admin=?')->execute([$tid,$markAdmin]);

            $ownFlag = $adminMode ? 1 : 0;

            $rs = $db->prepare('SELECT r.id,r.message,r.image_url,r.is_admin,r.created_at,r.is_seen,u.username,u.avatar FROM ticket_replies r LEFT JOIN users u ON u.id=r.user_id WHERE r.ticket_id=? AND r.id>? ORDER BY r.id ASC LIMIT 50');

            $rs->execute([$tid,$after]);

            $rows = $rs->fetchAll();

            $out = [];

            foreach ($rows as $rw) {

                $out[] = ['id' => (int)$rw['id'], 'message' => (string)$rw['message'], 'image' => (string)($rw['image_url'] ?? ''), 'admin' => (int)$rw['is_admin'], 'username' => (string)($rw['username'] ?? ''), 'avatar' => (string)($rw['avatar'] ?? ''), 'created' => date('d.m.Y H:i', strtotime($rw['created_at'])), 'seen' => (int)$rw['is_seen']];

            }

            $ss = $db->prepare('SELECT id FROM ticket_replies WHERE ticket_id=? AND is_admin=? AND is_seen=1 ORDER BY id DESC LIMIT 50');

            $ss->execute([$tid,$ownFlag]);

            $seenIds = array_map('intval', $ss->fetchAll(PDO::FETCH_COLUMN));

            json_resp(true, '', ['replies' => $out, 'seen_ids' => $seenIds, 'closed' => ($trow['status'] === 'closed')]);

        } catch (\PDOException $e) { error_log('[NS] ticket_poll: '.$e->getMessage()); json_resp(false, __('err.load_fail')); }
    case 'ticket_close':

        require_login();

        $uid = (int)auth_user()['id'];

        $tid = (int)($_POST['ticket_id'] ?? 0);

        if (!$tid) redirect_back(__('err.invalid_id'), 'error');

        try {

            $closed = $db->prepare('UPDATE tickets SET status="closed" WHERE id=? AND user_id=?');
            $closed->execute([$tid,$uid]);
            if ($closed->rowCount() === 0) redirect_back(__('err.ticket_missing'), 'error');

            audit_log($db, 'update', 'support', $tid, '#' . $tid, '/admin/tickets.php');
            header('Location: /support?id='.$tid.'&flash='.urlencode('success:'.__('msg.ticket_closed_ok'))); exit;

        } catch (\PDOException $e) { error_log('[NS] ticket_close: '.$e->getMessage()); redirect_back(__('err.op_fail'), 'error'); }
    case 'ticket_admin_reply':

        require_resource('support');

        $uid = (int)auth_user()['id'];

        $tid = (int)($_POST['ticket_id'] ?? 0);

        $rawMsg = $_POST['reply_message'] ?? '';

        $msg = mb_substr(trim(strip_tags($rawMsg)), 0, 500);

        $imgUp = ticket_store_image($_FILES['image'] ?? []);

        $wantsJson = (($_POST['is_fetch'] ?? '') === '1') || (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false);

        if (!$tid || ($msg === '' && empty($imgUp['path']))) {
            if ($wantsJson) json_resp(false, __('err.empty_message'));
            redirect_back(__('err.invalid_request'), 'error');
        }

        if (!$imgUp['ok']) {
            if ($wantsJson) json_resp(false, $imgUp['msg']);
            redirect_back($imgUp['msg'], 'error');
        }

        try {

            $tChk = $db->prepare('SELECT id FROM tickets WHERE id=?');

            $tChk->execute([$tid]);

            if (!$tChk->fetch()) {
                if ($wantsJson) json_resp(false, __('err.ticket_missing'));
                redirect_back(__('err.ticket_missing'), 'error');
            }

            $db->prepare('INSERT INTO ticket_replies (ticket_id,user_id,is_admin,message,image_url,created_at) VALUES (?,?,1,?,?,NOW())')->execute([$tid,$uid,$msg,$imgUp['path']]);

            $arid = (int)$db->lastInsertId();

            $db->prepare('UPDATE tickets SET status="replied",updated_at=NOW() WHERE id=?')->execute([$tid]);

            audit_log($db, 'update', 'support', $tid, '#' . $tid, '/admin/tickets.php');
            if ($wantsJson) {
                if (ob_get_level() > 0) ob_clean();
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['ok' => true, 'msg' => __('bsupp.reply_sent'), 'id' => $arid, 'message' => $msg, 'image' => $imgUp['path'], 'created' => date('d.m.Y H:i')]);
                session_write_close();
                if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();
                exit;
            }

            header('Location: /admin/support.php?id='.$tid.'&flash='.urlencode('success:'.__('bsupp.reply_sent'))); exit;

        } catch (\PDOException $e) { error_log('[NS] ticket_admin_reply: '.$e->getMessage()); redirect_back(__('err.reply_fail'), 'error'); }
    case 'ticket_delete':

        require_admin();

        $tid = (int)($_POST['ticket_id'] ?? 0);

        if (!$tid) redirect_back(__('err.invalid_id'), 'error');

        try {

            ticket_delete_images($db, $tid);

            $db->prepare('DELETE FROM tickets WHERE id=?')->execute([$tid]);

            audit_log($db, 'delete', 'support', $tid, '#' . $tid, '/admin/support.php');
            header('Location: /admin/support.php?flash='.urlencode('success:'.__('bsupp.ticket_deleted'))); exit;

        } catch (\PDOException $e) { error_log('[NS] ticket_delete: '.$e->getMessage()); redirect_back('Silinemedi.', 'error'); }
    case 'avatar_preset':

        require_login();

        $presets = [

            'https://minotar.net/avatar/user.png',

            'https://minotar.net/avatar/mustafa8907.png',

            'https://minotar.net/avatar/MHF_Alex.png',

        ];

        $chosen = $_POST['preset_url'] ?? '';

        if (!in_array($chosen, $presets, true)) redirect_back(__('err.invalid_choice'), 'error');

        $au = auth_user();

        _ua_delete_old_avatar($au);

        _ua_update_avatar($db, (int)$au['id'], $chosen);

        header('Location: /user/settings?flash=' . urlencode('success:'.__('bsupp.avatar_updated')), true, 302);

        exit;
    case 'avatar_upload':

        require_login();

        if (!isset($_FILES['avatar_file'])) redirect_back(__('err.no_file'), 'error');

        $au = auth_user();

        $result = _ua_upload_avatar($_FILES['avatar_file'], $au);

        if (!$result['ok']) redirect_back($result['msg'], 'error');

        _ua_delete_old_avatar($au);

        _ua_update_avatar($db, (int)$au['id'], $result['path']);

        header('Location: /user/settings?flash=' . urlencode('success:'.__('bsupp.avatar_uploaded')), true, 302);

        exit;
    case 'user_change_password':
    case 'change_password':

        require_login();

        $uid = (int)auth_user()['id'];

        $cur = $_POST['current_password'] ?? '';

        $new = $_POST['new_password'] ?? '';

        $conf = $_POST['confirm_password'] ?? ($_POST['new_password_confirm'] ?? '');

        $stmt = $db->prepare('SELECT password FROM users WHERE id=?');

        $stmt->execute([$uid]);

        $row = $stmt->fetch();

        if (!$row || !password_verify($cur, $row['password'])) redirect_back(__('err.wrong_password'), 'error');

        if (strlen($new) < 8) redirect_back(__('err.password_min'), 'error');

        if ($new !== $conf) redirect_back(__('err.password_mismatch'), 'error');

        $db->prepare('UPDATE users SET password=? WHERE id=?')->execute([password_hash($new, PASSWORD_BCRYPT), $uid]);

        $newVer = auth_bump_session_version($db, $uid);

        session_regenerate_id(true);

        $_SESSION['user']['session_version'] = $newVer;

        audit_log($db, 'update', 'users', $uid, '#' . $uid, '/admin/users.php');
        header('Location: /user/settings?flash=' . urlencode('success:'.__('bsupp.pass_updated')), true, 302);

        exit;
    case 'change_email':

        require_login();

        $uid = (int)auth_user()['id'];

        $curPw = (string)($_POST['current_password'] ?? '');

        $pwStmt = $db->prepare('SELECT password FROM users WHERE id=?');

        $pwStmt->execute([$uid]);

        $pwRow = $pwStmt->fetch();

        if (!$pwRow || !password_verify($curPw, $pwRow['password'])) redirect_back(__('err.verify_password'), 'error');

        $newEmail = trim(strtolower($_POST['new_email'] ?? ''));

        if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) redirect_back(__('err.invalid_email'), 'error');

        $stmt = $db->prepare('SELECT id FROM users WHERE email=? AND id!=?');

        $stmt->execute([$newEmail, $uid]);

        if ($stmt->fetch()) redirect_back(__('err.email_taken'), 'error');

        $db->prepare('UPDATE users SET email=? WHERE id=?')->execute([$newEmail, $uid]);

        $_SESSION['user']['email'] = $newEmail;

        audit_log($db, 'update', 'users', $uid, '#' . $uid, '/admin/users.php');
        header('Location: /user/settings?flash=' . urlencode('success:'.__('bsupp.mail_updated')), true, 302);

        exit;
    case 'oauth_unlink':

        require_login();

        $slug = $_POST['slug'] ?? '';

        $allowedSlugs = ['google_auth','discord_auth','microsoft_auth','github_auth'];

        $colMap = ['google_auth'=>'oauth_google_id','discord_auth'=>'oauth_discord_id','microsoft_auth'=>'oauth_microsoft_id','github_auth'=>'oauth_github_id'];

        if (!in_array($slug, $allowedSlugs)) { header('Location: /user/connections?flash=' . urlencode('error:'.__('bsupp.conn_invalid'))); exit; }

        $user = auth_user();

        try {

            $db = nexus_db();

            $db->prepare("UPDATE users SET {$colMap[$slug]}=NULL WHERE id=?")->execute([$user['id']]);

            header('Location: /user/connections?flash=' . urlencode('success:'.__('bsupp.conn_removed')));

            exit;

        } catch (\Throwable $e) { error_log('[NS] oauth_unlink: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); header('Location: /user/connections?flash=' . urlencode('error:'.__('bsupp.conn_remove_fail'))); exit; }
    case 'page_leave':

        $vid = (int)($_POST['view_id'] ?? 0);

        $dur = min(86400, max(0, (int)($_POST['duration'] ?? 0)));

        if ($vid > 0) {

            try {

                $nxKey = session_id() ?: md5(($_SERVER['REMOTE_ADDR'] ?? '') . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? ''));

                $db->prepare('UPDATE custom_page_views SET duration_sec=?, left_at=NOW() WHERE id=? AND session_key=?')->execute([$dur, $vid, $nxKey]);

            } catch (\PDOException $e) {

                error_log('[NS] page_leave: ' . $e->getMessage());

            }

        }

        json_resp(true, '');

    case 'user_update_profile':

        require_login();

        $uid = (int)auth_user()['id'];

        $newUsername = trim($_POST['username'] ?? '');

        $newEmail2 = trim(strtolower($_POST['email'] ?? ''));

        if (strlen($newUsername) < 3 || strlen($newUsername) > 32) redirect_back(__('err.username_length'), 'error');

        if (!preg_match('/^[a-zA-Z0-9_]+$/', $newUsername)) redirect_back(__('err.username_chars'), 'error');

        if (!filter_var($newEmail2, FILTER_VALIDATE_EMAIL)) redirect_back(__('err.invalid_email'), 'error');

        $curU = $db->prepare('SELECT username,email FROM users WHERE id=?');

        $curU->execute([$uid]);

        $curRow = $curU->fetch();

        if (!$curRow) redirect_back(__('err.user_missing'), 'error');

        if ($newEmail2 !== strtolower((string)$curRow['email'])) {

            $pwChk = $db->prepare('SELECT password FROM users WHERE id=?');

            $pwChk->execute([$uid]);

            $pwR = $pwChk->fetch();

            if (!$pwR || !password_verify((string)($_POST['current_password'] ?? ''), $pwR['password'])) redirect_back(__('err.email_change_verify'), 'error');

        }

        $dup = $db->prepare('SELECT id FROM users WHERE (username=? OR email=?) AND id!=? LIMIT 1');

        $dup->execute([$newUsername, $newEmail2, $uid]);

        if ($dup->fetch()) redirect_back(__('err.username_taken'), 'error');

        try {

            $db->prepare('UPDATE users SET username=?, email=? WHERE id=?')->execute([$newUsername, $newEmail2, $uid]);

            $_SESSION['user']['username'] = $newUsername;

            $_SESSION['user']['email'] = $newEmail2;

            header('Location: /user/settings?flash=' . urlencode('success:'.__('bsupp.profile_updated')), true, 302);

            exit;

        } catch (\PDOException $e) { error_log('[NS] user_update_profile: '.$e->getMessage()); redirect_back(__('err.profile_fail'), 'error'); }

    default:

        json_resp(false, __('err.unknown_action'));

}
