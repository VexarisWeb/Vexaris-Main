<?php
if (!defined('NEXUS_BOOT')) { http_response_code(403); exit; }

switch ($action) {

    case 'admin_theme_save':

        require_resource('themes');

        $raw = file_get_contents('php://input');

        $data = json_decode($raw, true);

        if (!is_array($data) && !empty($_POST)) $data = $_POST;

        if ($data && isset($data['mode'], $data['accent'], $data['preset'])) {

            $thMode = in_array($data['mode'], ['dark','light'], true) ? $data['mode'] : 'dark';

            $thAccent = preg_match('/^#[0-9a-fA-F]{6}$/', (string)$data['accent']) ? (string)$data['accent'] : '#10b981';

            $thPreset = preg_replace('/[^a-z0-9_]/', '', strtolower((string)$data['preset']));


            try {

                $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('admin_theme',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)")

                   ->execute([json_encode(['mode'=>$thMode,'accent'=>$thAccent,'preset'=>$thPreset])]);

                json_resp(true, __('bsys.theme_saved'));

            } catch (\PDOException $e) {

                error_log('[NS] admin_theme_save: '.$e->getMessage());

                json_resp(false, __('err.db'));

            }

        } else {

            json_resp(false, __('err.invalid_data'));

        }
    case 'admin_set_language':

        require_resource('settings');

        $nl = strtolower(trim($_POST['lang'] ?? ''));

        if ($nl !== 'tr' && $nl !== 'en') redirect_back(__('bsys.invalid_lang'), 'error');

        $_SESSION['admin_lang'] = $nl;

        $sec = function_exists('request_is_https') ? request_is_https() : (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

        setcookie('vx_admin_lang', $nl, ['expires' => time() + 31536000, 'path' => '/', 'httponly' => false, 'samesite' => 'Lax', 'secure' => $sec]);

        redirect_back(__('bsys.admin_lang_updated'), 'success');
    case 'update_check':

        require_admin();

        if (!update_gate()) json_resp(false, __('bsys.update_gate_off'));

        $res = update_check_remote($db, update_domain());

        if ($res === null) json_resp(false, __('bsys.update_unreachable'));

        update_store($db, [

            'ts'          => $res['ts'],

            'version'     => $res['version'],

            'description' => $res['description'],

            'file_size'   => $res['file_size'],

            'file_name'   => $res['file_name'],

            'available'   => $res['available'],

        ]);

        if (!$res['available']) json_resp(true, __('bsys.update_none'), ['available' => false]);

        json_resp(true, __('bsys.update_found'), [

            'available'   => true,

            'version'     => $res['version'],

            'description' => $res['description'],

            'file_size'   => $res['file_size'],

            'current'     => vexaris_current_version($db),

        ]);
    case 'update_delay':

        require_admin();

        if (!update_gate()) json_resp(false, __('bsys.update_gate_off'));

        if (!update_available($db)) json_resp(false, __('bsys.update_nothing'));

        $d = update_delay_apply($db);

        json_resp(true, __('bsys.update_delayed', ['count' => $d['count']]), ['count' => $d['count'], 'until' => $d['until']]);
    case 'update_download':

        require_admin();

        if (!update_gate()) json_resp(false, __('bsys.update_gate_off'));

        if (!update_available($db)) json_resp(false, __('bsys.update_nothing'));

        $v = update_state($db)['version'];

        $r = update_download_and_install($db, $v);

        if (!empty($r['ok'])) audit_log($db, 'update', 'settings', 0, (string)$v, '/admin/update.php');
        json_resp((bool)($r['ok'] ?? false), (string)($r['msg'] ?? __('err.op_fail')), $r);
    case 'update_progress':

        require_admin();

        if (!update_gate()) json_resp(false, __('bsys.update_gate_off'));

        json_resp(true, '', ['progress' => update_progress_get($db), 'current' => vexaris_current_version($db)]);
    case 'update_auto':

        require_admin();

        if (!update_gate()) json_resp(false, __('bsys.update_gate_off'));

        $on = ($_POST['enabled'] ?? '') === '1';

        update_auto_enable($db, $on);

        audit_log($db, 'update', 'settings', 0, 'auto_update', '/admin/update.php');
        json_resp(true, $on ? __('bsys.auto_on') : __('bsys.auto_off'), ['enabled' => $on]);
    case 'int_save':

        require_admin();

        $slug = $_POST['slug'] ?? '';

        $allowedSlugs = ['cf_captcha','recaptcha','google_auth','discord_auth','microsoft_auth','github_auth','tawkto','jivochat','crisp','analytics','shopier','paytr','iyzico','stripe','paypal','bitpay','crypt','paywant','whop','paddle','lemonsqueezy','dodopayments'];

        if (!in_array($slug, $allowedSlugs, true)) json_resp(false, __('bsys.invalid_integration'));

        $fields = [

            'cf_captcha'   => ['site_key','secret_key'],

            'recaptcha'    => ['site_key','secret_key'],

            'google_auth'  => ['client_id','client_secret'],

            'discord_auth' => ['client_id','client_secret'],

            'microsoft_auth'=>['client_id','client_secret'],

            'github_auth'  => ['client_id','client_secret'],

            'tawkto'       => ['widget_code'],

            'jivochat'     => ['widget_code'],

            'crisp'        => ['widget_code'],

            'analytics'    => ['analytics_code'],

            'shopier'      => ['pat','shop_slug','osb_username','osb_password','title','currency','priority','fee'],

            'paytr'        => ['merchant_id','merchant_key','merchant_salt','title','currency','test_mode','priority','fee'],

            'iyzico'       => ['api_key','secret_key','title','currency','test_mode','priority','fee'],

            'stripe'       => ['api_key','webhook_secret','title','currency','test_mode','priority','fee'],

            'paypal'       => ['client_id','secret','webhook_id','title','currency','test_mode','priority','fee'],

            'bitpay'       => ['token','title','currency','test_mode','priority','fee'],

            'crypt'        => ['merchant_id','api_key','title','currency','priority','fee'],

            'paywant'      => ['api_key','api_secret','title','priority','fee'],

            'whop'         => ['api_key','account_id','product_id','webhook_secret','title','currency','test_mode','priority','fee'],
            'paddle'       => ['api_key','webhook_secret','title','currency','test_mode','priority','fee'],
            'lemonsqueezy' => ['api_key','signing_secret','store_id','variant_id','title','currency','test_mode','priority','fee'],
            'dodopayments' => ['api_key','webhook_secret','product_id','title','currency','test_mode','priority','fee'],

        ];

        try {

            $db = nexus_db();

            foreach ($fields[$slug] as $f) {

                $prefix = in_array($slug, ['shopier','paytr','iyzico','stripe','paypal','bitpay','crypt','paywant','whop','paddle','lemonsqueezy','dodopayments'], true) ? 'payment_' : 'int_';

                $k = $prefix.$slug.'_'.$f;

                $v = trim($_POST[$slug.'_'.$f] ?? '');

                $st = $db->prepare("SELECT `key` FROM settings WHERE `key`=? LIMIT 1");

                $st->execute([$k]);

                if ($st->fetch()) {

                    $db->prepare("UPDATE settings SET `value`=? WHERE `key`=?")->execute([$v,$k]);

                } else {

                    $db->prepare("INSERT INTO settings (`key`,`value`) VALUES (?,?)")->execute([$k,$v]);

                }

            }

            audit_log($db, 'update', 'integrations', 0, $slug, '/admin/integrations.php');
            json_resp(true, __('bsys.settings_saved'));

        } catch (\Throwable $e) { error_log('[NS] int_save: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); json_resp(false, __('bsys.save_error')); }



    // ─── Entegrasyon Toggle ───
    case 'int_toggle':

        require_admin();

        $slug = $_POST['slug'] ?? '';

        $state = $_POST['state'] ?? '0';

        if ($state !== '0' && $state !== '1') json_resp(false, __('bsys.invalid_state'));

        $allowedSlugs = ['cf_captcha','recaptcha','google_auth','discord_auth','microsoft_auth','github_auth','tawkto','jivochat','crisp','analytics','shopier','paytr','iyzico','stripe','paypal','bitpay','crypt','paywant','whop','paddle','lemonsqueezy','dodopayments'];

        if (!in_array($slug, $allowedSlugs, true)) json_resp(false, __('bsys.invalid_integration'));

        try {

            $db = nexus_db();

            $k = in_array($slug, ['shopier','paytr','iyzico','stripe','paypal','bitpay','crypt','paywant','whop','paddle','lemonsqueezy','dodopayments'], true) ? 'payment_'.$slug.'_active' : 'int_'.$slug.'_enabled';

            $st = $db->prepare("SELECT `key` FROM settings WHERE `key`=? LIMIT 1");

            $st->execute([$k]);

            if ($st->fetch()) {

                $db->prepare("UPDATE settings SET `value`=? WHERE `key`=?")->execute([$state,$k]);

            } else {

                $db->prepare("INSERT INTO settings (`key`,`value`) VALUES (?,?)")->execute([$k,$state]);

            }

            if ($state === '1' && in_array($slug, ['cf_captcha','recaptcha'], true)) {

                $other = ($slug === 'cf_captcha') ? 'recaptcha' : 'cf_captcha';

                $ok = 'int_'.$other.'_enabled';

                $st = $db->prepare("SELECT `key` FROM settings WHERE `key`=? LIMIT 1");

                $st->execute([$ok]);

                if ($st->fetch()) {

                    $db->prepare("UPDATE settings SET `value`='0' WHERE `key`=?")->execute([$ok]);

                } else {

                    $db->prepare("INSERT INTO settings (`key`,`value`) VALUES (?, '0')")->execute([$ok]);

                }

            }

            if ($state === '1' && in_array($slug, ['tawkto','jivochat','crisp'], true)) {

                foreach (['tawkto','jivochat','crisp'] as $otherChat) {

                    if ($otherChat === $slug) continue;

                    $ok = 'int_'.$otherChat.'_enabled';

                    $st = $db->prepare("SELECT `key` FROM settings WHERE `key`=? LIMIT 1");

                    $st->execute([$ok]);

                    if ($st->fetch()) {

                        $db->prepare("UPDATE settings SET `value`='0' WHERE `key`=?")->execute([$ok]);

                    } else {

                        $db->prepare("INSERT INTO settings (`key`,`value`) VALUES (?, '0')")->execute([$ok]);

                    }

                }

            }

            audit_log($db, 'update', 'integrations', 0, $slug, '/admin/integrations.php');
            json_resp(true, $state==='1' ? __('bsys.int_enabled') : __('bsys.int_disabled'));

        } catch (\Throwable $e) { error_log('[NS] int_toggle: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); json_resp(false, __('bsys.toggle_error')); }



    // ─── Entegrasyon Test ───
    case 'int_test':

        require_admin();

        $slug = $_POST['slug'] ?? '';

        $allowedSlugs = ['cf_captcha','recaptcha','tawkto','jivochat','crisp','paytr','shopier','iyzico','stripe','paypal','bitpay','crypt','paywant','whop','paddle','lemonsqueezy','dodopayments'];

        if (!in_array($slug, $allowedSlugs)) json_resp(false, __('bsys.int_no_test'));

        try {

            $db = nexus_db();

            if ($slug === 'shopier') {
                try {
                    require_once ROOT_PATH . '/core/shopier.php';
                    $cfgSH = shopier_cfg($db);
                    if (empty($cfgSH['payment_shopier_pat'] ?? '') || empty($cfgSH['payment_shopier_shop_slug'] ?? '')) json_resp(false, __('bsys.shopier_missing'));
                    shopier_test_connection($db);
                    json_resp(true, __('bsys.shopier_ok'));
                } catch (Throwable $eSH) {
                    error_log('[NS] shopier int_test: '.$eSH->getMessage());
                    json_resp(false, __('bsys.shopier_fail'));
                }
            }

            if ($slug === 'stripe') {

                $cfgST = stripe_settings($db);

                $secretST = trim((string)($cfgST['payment_stripe_api_key'] ?? ''));

                if ($secretST === '' || strncmp($secretST, 'sk_', 3) !== 0) json_resp(false, __('bsys.stripe_secret_missing'));

                try {

                    require_once ROOT_PATH . '/vendor/autoload.php';

                    $clientST = new \Stripe\StripeClient($secretST);

                    $balanceST = $clientST->balance->retrieve();

                    json_resp(true, __('bsys.stripe_ok', ['amount' => ($balanceST->pending[0]->amount ?? 0), 'currency' => ($balanceST->pending[0]->currency ?? ''), 'mode' => (stripe_is_test_mode($db) ? __('bsys.mode_test') : __('bsys.mode_live'))]));

                } catch (\Throwable $eST) {

                    json_resp(false, __('bsys.stripe_resp', ['e' => $eST->getMessage()]));

                }

            }

            if ($slug === 'cf_captcha' || $slug === 'recaptcha') {

                $st = $db->prepare("SELECT `value` FROM settings WHERE `key`=? LIMIT 1");

                $st->execute(['int_'.$slug.'_secret_key']);

                $secretKey = $st->fetchColumn() ?: '';

                if (empty($secretKey)) json_resp(false, __('bsys.secret_missing'));

            }

            if ($slug === 'cf_captcha') {

                $ch = curl_init('https://challenges.cloudflare.com/turnstile/v0/siteverify');

                curl_setopt_array($ch, [CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>http_build_query(['secret'=>$secretKey,'response'=>'test']), CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>10]);

                $rawCf = curl_exec($ch);

                curl_close($ch);

                if ($rawCf === false || json_decode($rawCf, true) === null) json_resp(false, __('bsys.cf_noresp'));

                json_resp(true, __('bsys.cf_ok'));

            } elseif ($slug === 'recaptcha') {

                $ch = curl_init('https://www.google.com/recaptcha/api/siteverify');

                curl_setopt_array($ch, [CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>http_build_query(['secret'=>$secretKey,'response'=>'test']), CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>10]);

                $rawRc = curl_exec($ch);

                curl_close($ch);

                if ($rawRc === false || json_decode($rawRc, true) === null) json_resp(false, __('bsys.rc_noresp'));

                json_resp(true, __('bsys.rc_ok'));

            } elseif ($slug === 'tawkto') {

                $st2 = $db->prepare("SELECT `value` FROM settings WHERE `key`=? LIMIT 1");

                $st2->execute(['int_tawkto_widget_code']);

                $widgetCode = $st2->fetchColumn() ?: '';

                if (empty($widgetCode)) json_resp(false, __('bsys.tawk_missing'));

                if (!preg_match('#(?:https?:)?//embed\.tawk\.to/([A-Za-z0-9_]+)/([A-Za-z0-9_]+)#', $widgetCode, $m)) json_resp(false, __('bsys.tawk_invalid'));

                $ch = curl_init('https://embed.tawk.to/' . $m[1] . '/' . $m[2]);

                curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>12, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_SSL_VERIFYPEER=>true]);

                $bodyT = curl_exec($ch);

                $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);

                $curlErr = curl_error($ch);

                curl_close($ch);

                if ($bodyT === false) json_resp(false, __('bsys.tawk_noresp') . ($curlErr ? __('bsys.err_suffix', ['e' => $curlErr]) : ''));

                if ($httpCode >= 200 && $httpCode < 400) json_resp(true, __('bsys.tawk_ok', ['code' => $httpCode]));

                json_resp(false, __('bsys.tawk_http_fail', ['code' => $httpCode, 'detail' => ($curlErr ? __('bsys.err_inline', ['e' => $curlErr]) : '')]));

            } elseif ($slug === 'jivochat') {

                $stJ = $db->prepare("SELECT `value` FROM settings WHERE `key`=? LIMIT 1");

                $stJ->execute(['int_jivochat_widget_code']);

                $jvCode = $stJ->fetchColumn() ?: '';

                if (empty($jvCode)) json_resp(false, __('bsys.jivo_missing'));

                if (!preg_match('#code\.jivosite\.com/widget/([A-Za-z0-9]+)#', $jvCode, $mJ)) json_resp(false, __('bsys.jivo_invalid'));

                $chJ = curl_init('https://code.jivosite.com/widget/' . $mJ[1]);

                curl_setopt_array($chJ, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>12, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_SSL_VERIFYPEER=>true]);

                $bodyJ = curl_exec($chJ);

                $httpCodeJ = (int)curl_getinfo($chJ, CURLINFO_HTTP_CODE);

                $curlErrJ = curl_error($chJ);

                curl_close($chJ);

                if ($bodyJ === false) json_resp(false, __('bsys.jivo_noresp') . ($curlErrJ ? __('bsys.err_suffix', ['e' => $curlErrJ]) : ''));

                if ($httpCodeJ >= 200 && $httpCodeJ < 400) json_resp(true, __('bsys.jivo_ok', ['code' => $httpCodeJ]));

                json_resp(false, __('bsys.jivo_http_fail', ['code' => $httpCodeJ, 'detail' => ($curlErrJ ? __('bsys.err_inline', ['e' => $curlErrJ]) : '')]));

            } elseif ($slug === 'paywant') {

                try {

                    require_once ROOT_PATH . '/core/paywant.php';

                    if (!paywant_is_ready($db)) json_resp(false, __('bsys.paywant_missing'));

                    paywant_test_connection($db);

                    json_resp(true, __('bsys.paywant_ok'));

                } catch (\Throwable $ePW) {

                    error_log('[NS] paywant int_test: '.$ePW->getMessage());

                    json_resp(false, __('bsys.paywant_fail', ['e' => $ePW->getMessage()]));

                }

            } elseif ($slug === 'paytr') {

                try {

                    require_once ROOT_PATH . '/core/paytr.php';

                    if (!paytr_is_ready($db)) json_resp(false, __('bsys.paytr_missing'));

                    $cfgT = paytr_settings($db);

                    $probeOid = 'TEST-' . time() . '-' . bin2hex(random_bytes(4));

                    $probeBasket = base64_encode(json_encode([['Test', '1.00', 1]], JSON_UNESCAPED_UNICODE));

                    $probeAmt = 100;

                    $probeHash = paytr_hash(trim((string)$cfgT['payment_paytr_merchant_key']), trim((string)$cfgT['payment_paytr_merchant_salt']), trim((string)$cfgT['payment_paytr_merchant_id']) . '127.0.0.1' . $probeOid . 'test@example.com' . $probeAmt . $probeBasket . '0' . '0' . 'TL' . '1');

                    $probeResp = paytr_http_post('https://www.paytr.com/odeme/api/get-token', [
                        'merchant_id' => trim((string)$cfgT['payment_paytr_merchant_id']),
                        'user_ip' => (string)($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'),
                        'merchant_oid' => $probeOid,
                        'email' => 'test@example.com',
                        'payment_amount' => $probeAmt,
                        'paytr_token' => $probeHash,
                        'user_basket' => $probeBasket,
                        'debug_on' => 1,
                        'no_installment' => 0,
                        'max_installment' => 0,
                        'user_name' => 'Test',
                        'user_address' => 'Test',
                        'user_phone' => '8501234567',
                        'merchant_ok_url' => 'https://example.com/ok',
                        'merchant_fail_url' => 'https://example.com/fail',
                        'timeout_limit' => '30',
                        'currency' => 'TL',
                        'test_mode' => 1,
                    ]);

                    $probeData = json_decode($probeResp, true);

                    if (is_array($probeData) && ($probeData['status'] ?? '') === 'success' && !empty($probeData['token'])) json_resp(true, __('bsys.paytr_ok'));

                    $reason = is_array($probeData) ? (string)($probeData['reason'] ?? 'bilinmiyor') : substr($probeResp, 0, 120);

                    if (stripos($reason, 'merchant') !== false || stripos($reason, 'magaza') !== false || stripos($reason, 'token') !== false) json_resp(false, __('bsys.paytr_bad', ['reason' => mb_substr($reason, 0, 160)]));

                    json_resp(false, __('bsys.paytr_resp', ['reason' => mb_substr($reason, 0, 160)]));

                } catch (\Throwable $ePT) {

                    error_log('[NS] paytr int_test: '.$ePT->getMessage());

                    json_resp(false, __('bsys.paytr_fail', ['e' => $ePT->getMessage()]));

                }

            } elseif ($slug === 'iyzico') {

                try {

                    require_once ROOT_PATH . '/core/iyzico.php';

                    if (!iyzico_is_ready($db)) json_resp(false, __('bsys.iyzico_missing'));

                    $probe = iyzico_create_payment($db, 'TEST-' . time() . '-' . bin2hex(random_bytes(4)), 'test@example.com', 'Test Kullanıcı', 1.0, [['Test', '1.00', 1]]);

                    if (($probe['token'] ?? '') === '') json_resp(false, __('bsys.iyzico_token_fail'));

                    json_resp(true, __('bsys.iyzico_ok', ['sb' => (iyzico_is_test_mode($db) ? ', sandbox' : '')]));

                } catch (\Throwable $eIy) {

                    error_log('[NS] iyzico int_test: '.$eIy->getMessage());

                    json_resp(false, __('bsys.iyzico_fail', ['e' => $eIy->getMessage()]));

                }

            } elseif ($slug === 'paypal') {

                try {

                    require_once ROOT_PATH . '/core/paypal.php';

                    if (!paypal_is_ready($db)) json_resp(false, __('bsys.paypal_missing'));

                    paypal_test_connection($db);

                    json_resp(true, __('bsys.paypal_ok', ['mode' => (paypal_is_test_mode($db) ? ' (sandbox)' : __('bsys.mode_live_paren'))]));

                } catch (\Throwable $ePp) {

                    error_log('[NS] paypal int_test: '.$ePp->getMessage());

                    json_resp(false, __('bsys.paypal_fail', ['e' => $ePp->getMessage()]));

                }

            } elseif ($slug === 'crypt') {

                try {

                    require_once ROOT_PATH . '/core/crypt.php';

                    if (!crypt_is_ready($db)) json_resp(false, __('bsys.crypt_missing'));

                    crypt_test_connection($db);

                    json_resp(true, __('bsys.crypt_ok'));

                } catch (\Throwable $eCr) {

                    error_log('[NS] crypt int_test: '.$eCr->getMessage());

                    json_resp(false, __('bsys.crypt_fail', ['e' => $eCr->getMessage()]));

                }

            } elseif ($slug === 'bitpay') {

                try {

                    require_once ROOT_PATH . '/core/bitpay.php';

                    if (!bitpay_is_ready($db)) json_resp(false, __('bsys.bitpay_missing'));

                    bitpay_test_connection($db);

                    json_resp(true, __('bsys.bitpay_ok', ['mode' => (bitpay_is_test_mode($db) ? ' (testnet)' : __('bsys.mode_live_paren'))]));

                } catch (\Throwable $eBp) {

                    error_log('[NS] bitpay int_test: '.$eBp->getMessage());

                    json_resp(false, __('bsys.bitpay_fail', ['e' => $eBp->getMessage()]));

                }

            } elseif ($slug === 'whop') {

                try {

                    require_once ROOT_PATH . '/core/whop.php';

                    if (!whop_is_ready($db)) json_resp(false, __('bsys.whop_missing'));

                    whop_test_connection($db);

                    json_resp(true, __('bsys.whop_ok', ['sb' => (whop_test_mode($db) ? ', sandbox' : '')]));

                } catch (\Throwable $eW) {

                    error_log('[NS] whop int_test: '.$eW->getMessage());

                    json_resp(false, __('bsys.whop_fail', ['e' => $eW->getMessage()]));

                }

            } elseif ($slug === 'dodopayments') {
                try {
                    require_once ROOT_PATH . '/core/dodopayments.php';
                    if (!dodopayments_is_ready($db)) json_resp(false, __('bsys.dodopayments_missing'));
                    dodopayments_test_connection($db);
                    json_resp(true, __('bsys.dodopayments_ok', ['sandbox' => (dodopayments_test_mode($db) ? ' (sandbox)' : '')]));
                } catch (\Throwable $eD) {
                    error_log('[NS] dodopayments int_test: '.$eD->getMessage());
                    json_resp(false, __('bsys.dodopayments_fail', ['e' => $eD->getMessage()]));
                }
            } elseif ($slug === 'lemonsqueezy') {
                try {
                    require_once ROOT_PATH . '/core/lemonsqueezy.php';
                    if (!lemonsqueezy_is_ready($db)) json_resp(false, __('bsys.lemonsqueezy_missing'));
                    lemonsqueezy_test_connection($db);
                    json_resp(true, __('bsys.lemonsqueezy_ok', ['sandbox' => (lemonsqueezy_test_mode($db) ? ' (sandbox)' : '')]));
                } catch (\Throwable $eL) {
                    error_log('[NS] lemonsqueezy int_test: '.$eL->getMessage());
                    json_resp(false, __('bsys.lemonsqueezy_fail', ['e' => $eL->getMessage()]));
                }
            } elseif ($slug === 'paddle') {

                try {

                    require_once ROOT_PATH . '/core/paddle.php';

                    if (!paddle_is_ready($db)) json_resp(false, __('bsys.paddle_missing'));

                    paddle_test_connection($db);

                    json_resp(true, __('bsys.paddle_ok', ['sandbox' => (paddle_test_mode($db) ? ' (sandbox)' : '')]));

                } catch (\Throwable $eP) {

                    error_log('[NS] paddle int_test: '.$eP->getMessage());

                    json_resp(false, __('bsys.paddle_fail', ['e' => $eP->getMessage()]));

                }

            } elseif ($slug === 'crisp') {

                $stC = $db->prepare("SELECT `value` FROM settings WHERE `key`=? LIMIT 1");

                $stC->execute(['int_crisp_widget_code']);

                $crCode = $stC->fetchColumn() ?: '';

                if (empty($crCode)) json_resp(false, __('bsys.crisp_missing'));

                if (!preg_match('#(?:https?:)?//client\.crisp\.chat/l\.js#', $crCode)) json_resp(false, __('bsys.crisp_invalid'));

                if (!preg_match('#CRISP_WEBSITE_ID\s*=\s*["\']([A-Za-z0-9-]+)["\']#', $crCode, $mC)) json_resp(false, __('bsys.crisp_nowsid'));

                $chC = curl_init('https://client.crisp.chat/l.js');

                curl_setopt_array($chC, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>12, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_SSL_VERIFYPEER=>true]);

                $bodyC = curl_exec($chC);

                $httpCodeC = (int)curl_getinfo($chC, CURLINFO_HTTP_CODE);

                $curlErrC = curl_error($chC);

                curl_close($chC);

                if ($bodyC === false) json_resp(false, __('bsys.crisp_noresp') . ($curlErrC ? __('bsys.err_suffix', ['e' => $curlErrC]) : ''));

                if ($httpCodeC >= 200 && $httpCodeC < 400) json_resp(true, __('bsys.crisp_ok', ['code' => $httpCodeC]));

                json_resp(false, __('bsys.crisp_http_fail', ['code' => $httpCodeC, 'detail' => ($curlErrC ? __('bsys.err_inline', ['e' => $curlErrC]) : '')]));

            }

            json_resp(false, __('bsys.test_inconclusive'));

        } catch (\Throwable $e) { error_log('[NS] int_test: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); json_resp(false, __('bsys.test_error')); }
    case 'mod_save':

        require_resource('modules');

        $slug = trim($_POST['slug'] ?? '');

        if (!module_slug_valid($slug)) json_resp(false, __('bsys.invalid_module'));

        $manifest = module_manifest($slug);

        if ($manifest === null) json_resp(false, __('bsys.module_missing'));

        try {

            $db = nexus_db();

            $values = [];

            foreach ($manifest['fields'] as $f) {

                $values[$f['key']] = $_POST[$slug.'_'.$f['key']] ?? '';

            }

            if (!modules_save_settings($db, $slug, $values)) json_resp(false, __('bsys.mod_settings_fail'));

            audit_log($db, 'update', 'modules', 0, $slug, '/admin/modules.php');
            json_resp(true, __('bsys.mod_settings_saved'));

        } catch (\Throwable $e) { error_log('[NS] mod_save: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); json_resp(false, __('bsys.save_error')); }
    case 'mod_toggle':

        require_resource('modules');

        $slug = trim($_POST['slug'] ?? '');

        $state = $_POST['state'] ?? '0';

        if (!module_slug_valid($slug)) json_resp(false, __('bsys.invalid_module'));

        if ($state !== '0' && $state !== '1') json_resp(false, __('bsys.invalid_state'));

        if (module_manifest($slug) === null) json_resp(false, __('bsys.module_missing'));

        if ($state === '1' && function_exists('plan_module_allowed') && !plan_module_allowed($slug, module_manifest($slug))) json_resp(false, __('plan.module_locked'));

        try {

            $db = nexus_db();

            if (!modules_set_enabled($db, $slug, $state === '1')) json_resp(false, __('bsys.mod_state_fail'));

            audit_log($db, 'update', 'modules', 0, $slug, '/admin/modules.php');
            json_resp(true, $state === '1' ? __('bsys.mod_enabled') : __('bsys.mod_disabled'));

        } catch (\Throwable $e) { error_log('[NS] mod_toggle: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); json_resp(false, __('bsys.op_error')); }
    case 'mod_sidebar':

        require_resource('modules');

        $slug = trim($_POST['slug'] ?? '');

        $state = $_POST['state'] ?? '1';

        if (!module_slug_valid($slug)) json_resp(false, __('bsys.invalid_module'));

        if ($state !== '0' && $state !== '1') json_resp(false, __('bsys.invalid_state'));

        if (module_manifest($slug) === null) json_resp(false, __('bsys.module_missing'));

        try {

            $db = nexus_db();

            if (!modules_set_sidebar($db, $slug, $state === '1')) json_resp(false, __('bsys.scope_fail'));

            audit_log($db, 'update', 'modules', 0, $slug, '/admin/modules.php');
            json_resp(true, $state === '1' ? __('bsys.mod_show') : __('bsys.mod_hide'));

        } catch (\Throwable $e) { error_log('[NS] mod_sidebar: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); json_resp(false, __('bsys.op_error')); }



    // ─── Discord Webhook Kaydet ───
    case 'discord_save':

        require_admin();

        $url = trim($_POST['url'] ?? '');

        if ($url !== '' && !preg_match('#^https://(discord|discordapp)\.com/api/webhooks/#i', $url))

            json_resp(false, __('bsys.discord_url_invalid'));

        $events = ['register','order','topup','review','ticket','ticket_reply','coupon','purchase'];

        try {

            $db = nexus_db();

            $upsert = function($k, $v) use ($db) {

                $st = $db->prepare("SELECT `key` FROM settings WHERE `key`=? LIMIT 1");

                $st->execute([$k]);

                if ($st->fetch()) $db->prepare("UPDATE settings SET `value`=? WHERE `key`=?")->execute([$v,$k]);

                else $db->prepare("INSERT INTO settings (`key`,`value`) VALUES (?,?)")->execute([$k,$v]);

            };

            $upsert('int_discord_webhook_url', $url);

            foreach ($events as $ev) {

                $state = ($_POST[$ev] ?? '0') === '1' ? '1' : '0';

                $upsert('int_discord_'.$ev, $state);

            }

            audit_log($db, 'update', 'discord-webhook', 0, 'webhook', '/admin/discord-webhook.php');
            json_resp(true, __('bsys.discord_saved'));

        } catch (\Throwable $e) { error_log('[NS] discord_save: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); json_resp(false, __('bsys.save_error')); }



    // ─── Discord Test Mesajı ───
    case 'discord_test':

        require_admin();

        $url = trim($_POST['url'] ?? '');

        if ($url === '') json_resp(false, __('bsys.webhook_empty'));

        if (!preg_match('#^https://(discord|discordapp)\.com/api/webhooks/#i', $url)) json_resp(false, __('bsys.discord_url_invalid2'));

        try {

            require_once ROOT_PATH . '/core/discord.php';

            $ok = discord_send_test($url);

            if ($ok) json_resp(true, __('bsys.discord_test_ok'));

            else json_resp(false, __('bsys.discord_send_fail') . ' ' . (discord_last_error() ?: __('bsys.discord_check')));

        } catch (\Throwable $e) { error_log('[NS] discord_test: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); json_resp(false, __('bsys.test_error')); }



    // ─── Test E-postası Gönder ───
    case 'mail_test_send':

        require_resource('settings');

        $user = auth_user();

        $to = $user['email'] ?? '';

        if (!$to) json_resp(false, __('bsys.mail_noaddr'));

        try {

            $cfg = mail_get_settings($db);

            if (empty($cfg['mail_smtp_host'] ?? '') || empty($cfg['mail_smtp_user'] ?? ''))

                json_resp(false, __('bsys.mail_smtp_missing'));

            $ok = mail_send($to, 'account_activation', [

                'user_name'         => $user['username'] ?? 'Admin',

                'verification_link' => mail_base_url() . '/verify?email=' . urlencode($to),

            ], true);

            json_resp($ok, $ok ? __('bsys.mail_test_ok', ['to' => $to]) : __('bsys.mail_send_fail'));

        } catch (\Throwable $e) { error_log('[NS] mail_test_send: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); json_resp(false, __('bsys.mail_test_fail')); }
    case 'mail_template_save':

        require_resource('settings');

        $slug = $_POST['slug'] ?? '';

        $subject = trim($_POST['subject'] ?? '');

        $headerTitle = trim($_POST['header_title'] ?? '');

        $body = $_POST['body_html'] ?? '';

        $accent = trim($_POST['accent_color'] ?? '');

        $logo = trim($_POST['logo_url'] ?? '');

        $allowedSlugs = ['password_reset','account_activation'];

        if (!in_array($slug, $allowedSlugs)) json_resp(false, __('bsys.tpl_invalid'));

        if ($subject === '' || $body === '') json_resp(false, __('bsys.tpl_empty'));

        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $accent)) $accent = '#4f46e5';

        if ($logo !== '' && !filter_var($logo, FILTER_VALIDATE_URL)) json_resp(false, __('bsys.tpl_logo_invalid'));

        try {

            $db->prepare('UPDATE mail_templates SET subject=?, header_title=?, body_html=?, accent_color=?, logo_url=? WHERE slug=?')

               ->execute([$subject, $headerTitle, $body, $accent, $logo !== '' ? $logo : null, $slug]);

            audit_log($db, 'update', 'settings', 0, $slug, '/admin/mail-templates.php');
            json_resp(true, __('bsys.tpl_saved'));

        } catch (\Throwable $e) { error_log('[NS] mail_template_save: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); json_resp(false, __('bsys.save_error')); }
    case 'theme_editor_save':

        require_resource('themes');

        $tTheme = preg_replace('/[^a-z0-9_\-]/', '', strtolower(trim($_POST['theme'] ?? '')));

        if ($tTheme === '' || !is_dir(ROOT_PATH . '/themes/' . $tTheme)) redirect_back(__('bsys.theme_invalid'), 'error');

        $tSchema = theme_editor_schema($tTheme);

        if (count($tSchema) === 0) redirect_back(__('bsys.theme_no_fields'), 'error');

        if (!empty($_POST['reset_theme'])) {
            theme_settings_reset($db, $tTheme);
            redirect_back(__('bsys.theme_reset'), 'success');
        }

        $tValues = [];

        foreach ($tSchema as $tSec) {

            foreach ($tSec['fields'] as $tF) {

                $tKey = $tF['key'];

                if (($tF['type'] ?? 'text') === 'image') {

                    $upKey = 'timg_' . $tKey;

                    if (!empty($_FILES[$upKey]) && (int)($_FILES[$upKey]['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {

                        $upPath = theme_image_upload($_FILES[$upKey], $tTheme);

                        if ($upPath === '') redirect_back(__('bsys.theme_img_fail'), 'error');

                        try {
                            $oldImg = theme_settings_map($tTheme)[$tKey] ?? '';
                            if (is_string($oldImg) && strncmp($oldImg, '/uploads/theme/', 15) === 0 && strpos($oldImg, '..') === false && file_exists(ROOT_PATH . $oldImg)) @unlink(ROOT_PATH . $oldImg);
                        } catch (\Throwable $eOld) {}

                        $tValues[$tKey] = $upPath;

                    } elseif (array_key_exists('t_' . $tKey, $_POST)) {

                        $tValues[$tKey] = (string)$_POST['t_' . $tKey];

                    }

                } elseif (array_key_exists('t_' . $tKey, $_POST)) {

                    $tValues[$tKey] = (string)$_POST['t_' . $tKey];

                }

            }

        }

        if (theme_setting_save($db, $tTheme, $tValues)) { audit_log($db, 'update', 'themes', 0, $tTheme, '/admin/themes.php'); redirect_back(__('bsys.theme_saved2'), 'success'); }

        redirect_back(__('bsys.theme_save_fail'), 'error');

    case 'custom_css_save':

        require_resource('themes');

        $cssRaw = (string)($_POST['custom_css'] ?? '');
        $cssRaw = str_replace(["\r\n", "\r"], "\n", $cssRaw);
        if (strlen($cssRaw) > 65535) redirect_back(__('bsys.css_too_big'), 'error');
        $cssRaw = (string)preg_replace('#</style[^>]*>#i', '', $cssRaw);
        $cssRaw = trim($cssRaw);

        try {
            $cssChk = $db->prepare("SELECT `key` FROM settings WHERE `key`='custom_css' LIMIT 1");
            $cssChk->execute();
            if ($cssChk->fetch()) $db->prepare("UPDATE settings SET `value`=? WHERE `key`='custom_css'")->execute([$cssRaw]);
            else $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('custom_css',?)")->execute([$cssRaw]);
            audit_log($db, 'update', 'themes', 0, 'custom_css', '/admin/custom-css.php');
            redirect_back(__('bsys.css_saved'), 'success');
        } catch (\PDOException $e) { error_log('[NS] custom_css_save: '.$e->getMessage()); redirect_back(__('bsys.css_fail'), 'error'); }

    case 'role_save':

        require_resource('permissions');

        if (!in_array((string)(auth_user()['role'] ?? ''), ['admin', 'superadmin'], true)) redirect_back(__('aperm.only_admin'), 'error');

        $roleOrig = trim($_POST['orig'] ?? '');

        $roleIsNew = ($roleOrig === '');

        if ($roleIsNew) {

            if (function_exists('plan_current') && !in_array((plan_current()['slug'] ?? 'free'), ['professional', 'enterprise'], true)) redirect_back(__('plan.role_crud_locked'), 'error');

            $roleSlug = strtolower(trim($_POST['slug'] ?? ''));

            if (!role_slug_valid($roleSlug)) redirect_back(__('aperm.role_invalid'), 'error');

            if ($roleSlug === 'superadmin' && (string)(auth_user()['role'] ?? '') !== 'superadmin') redirect_back(__('aperm.only_admin'), 'error');

            if (role_get($db, $roleSlug) !== null) redirect_back(__('aperm.role_exists'), 'error');

        } else {

            $roleSlug = $roleOrig;

            if (role_get($db, $roleSlug) === null) redirect_back(__('aperm.invalid_role'), 'error');

        }

        $roleRow = role_get($db, $roleSlug);

        $isSuperRole = ($roleSlug === 'superadmin');

        if ($isSuperRole && (string)(auth_user()['role'] ?? '') !== 'superadmin') redirect_back(__('aperm.only_admin'), 'error');

        $roleSystem = $roleRow && (int)($roleRow['is_system'] ?? 0) === 1;

        $roleNameTr = mb_substr(trim($_POST['name_tr'] ?? ''), 0, 60);

        $roleNameEn = mb_substr(trim($_POST['name_en'] ?? ''), 0, 60);

        if ($roleNameTr === '') redirect_back(__('aperm.role_invalid'), 'error');

        if ($roleNameEn === '') $roleNameEn = $roleNameTr;

        $roleColor = role_color_safe($_POST['color'] ?? '');

        $roleIcon = trim((string)($_POST['icon'] ?? ''));

        if (mb_strlen($roleIcon) > 512) $roleIcon = '';

        if ($roleIcon !== '' && !preg_match('/^fa-[a-z0-9 \-]+$/i', $roleIcon) && !preg_match('#^/uploads/[A-Za-z0-9_\-./]+\.(webp|png|jpe?g|gif|svg)$#i', $roleIcon)) redirect_back(__('aperm.role_bad_icon'), 'error');

        if ($roleIcon === '') $roleIcon = 'fa-solid fa-user';

        $roleRank = max(0, min(99, (int)($_POST['rank'] ?? 0)));

        try {

            if ($roleIsNew) {

                $db->prepare('INSERT INTO roles (slug,name_tr,name_en,color,icon,rank,is_system) VALUES (?,?,?,?,?,?,0)')->execute([$roleSlug,$roleNameTr,$roleNameEn,$roleColor,$roleIcon,$roleRank]);

                $db->prepare('INSERT IGNORE INTO permissions (role,resource) VALUES (?,?)')->execute([$roleSlug,'dashboard']);

                audit_log($db, 'create', 'roles', 0, $roleSlug, '/admin/permissions.php?role=' . urlencode($roleSlug));
                redirect_back(__('aperm.role_created'), 'success');

            }

            if ($roleSystem) {

                $db->prepare('UPDATE roles SET name_tr=?,name_en=?,color=?,icon=? WHERE slug=?')->execute([$roleNameTr,$roleNameEn,$roleColor,$roleIcon,$roleSlug]);

            } else {

                $db->prepare('UPDATE roles SET name_tr=?,name_en=?,color=?,icon=?,rank=? WHERE slug=?')->execute([$roleNameTr,$roleNameEn,$roleColor,$roleIcon,$roleRank,$roleSlug]);

            }

            audit_log($db, 'update', 'roles', 0, $roleSlug, '/admin/permissions.php?role=' . urlencode($roleSlug));
            redirect_back(__('aperm.role_updated'), 'success');

        } catch (\PDOException $e) { error_log('[NS] role_save: '.$e->getMessage()); redirect_back(__('bsys.save_error'), 'error'); }
    case 'role_delete':

        require_resource('permissions');

        if (!in_array((string)(auth_user()['role'] ?? ''), ['admin', 'superadmin'], true)) redirect_back(__('aperm.only_admin'), 'error');

        if (function_exists('plan_current') && !in_array((plan_current()['slug'] ?? 'free'), ['professional', 'enterprise'], true)) redirect_back(__('plan.role_crud_locked'), 'error');

        $delSlug = trim($_POST['slug'] ?? '');

        $delRow = role_get($db, $delSlug);

        if ($delRow === null) redirect_back(__('aperm.invalid_role'), 'error');

        if ($delSlug === 'admin' || (int)($delRow['is_system'] ?? 0) === 1) redirect_back(__('aperm.admin_locked'), 'error');

        $delCount = roles_user_count($db, $delSlug);

        if ($delCount > 0) redirect_back(__('aperm.role_has_users', ['n' => $delCount]), 'error');

        try {

            $db->prepare('DELETE FROM permissions WHERE role=?')->execute([$delSlug]);

            $db->prepare('DELETE FROM roles WHERE slug=?')->execute([$delSlug]);

            audit_log($db, 'delete', 'roles', 0, $delSlug, '/admin/permissions.php');
            redirect_back(__('aperm.role_deleted'), 'success');

        } catch (\PDOException $e) { error_log('[NS] role_delete: '.$e->getMessage()); redirect_back(__('bsys.save_error'), 'error'); }
    case 'ai_chat':

        require_resource('ai_assistant');

        $aiBlock = function_exists('plan_ai_check') ? plan_ai_check($db) : null;
        if ($aiBlock !== null) json_resp(false, $aiBlock, ['quota' => true]);

        $msg = trim((string)($_POST['message'] ?? ''));
        if ($msg === '') json_resp(false, __('vai.empty'));
        if (mb_strlen($msg) > 2000) $msg = mb_substr($msg, 0, 2000);
        $model = trim((string)($_POST['model'] ?? ''));
        $effort = trim((string)($_POST['effort'] ?? ''));
        $past = [];
        if (isset($_POST['history'])) {
            $decH = json_decode((string)$_POST['history'], true);
            if (is_array($decH)) $past = array_slice($decH, -10);
        }
        $upFiles = [];
        if (!empty($_FILES['files'])) {
            $fArr = $_FILES['files'];
            $n = is_array($fArr['tmp_name'] ?? null) ? count($fArr['tmp_name']) : 0;
            $fi = new finfo(FILEINFO_MIME_TYPE);
            for ($i = 0; $i < min($n, 3); $i++) {
                if (($fArr['error'][$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;
                if ((int)($fArr['size'][$i] ?? 0) > 4194304) continue;
                $tmp = (string)($fArr['tmp_name'][$i] ?? '');
                if ($tmp === '' || !is_uploaded_file($tmp)) continue;
                $mime = (string)$fi->file($tmp);
                if (!in_array($mime, ['image/png', 'image/jpeg', 'image/webp', 'text/plain', 'application/pdf'], true)) continue;
                $upFiles[] = ['tmp' => $tmp, 'mime' => $mime, 'name' => mb_substr((string)($fArr['name'][$i] ?? 'dosya'), 0, 120)];
            }
        }
        if (function_exists('ai_relay_chat')) {
            $rel = ai_relay_chat($db, $msg, $model, $effort, $upFiles, '', $past);
            if (!empty($rel['ok']) && empty($rel['needs_confirm'])) {
                audit_log($db, 'update', 'ai_assistant', 0, mb_substr($msg, 0, 80), '/admin/dashboard.php');
                json_resp(true, '', ['reply' => (string)($rel['reply'] ?? ''), 'model' => $model, 'effort' => $effort, 'quota' => $rel['quota'] ?? [], 'credits' => (int)($rel['credits'] ?? 0), 'provider' => $rel['provider'] ?? '', 'via' => 'saas', 'tool_data' => $rel['tool_data'] ?? [], 'vision_dropped' => !empty($rel['vision_dropped'])]);
            }
            if (!empty($rel['needs_confirm'])) {
                $ptools = $rel['tools'] ?? null;
                if (!is_array($ptools)) $ptools = [['tool' => $rel['tool'] ?? '', 'args' => $rel['args'] ?? [], 'confirm_msg' => $rel['confirm_msg'] ?? '']];
                json_resp(true, '', ['needs_confirm' => true, 'tools' => $ptools, 'tool' => $ptools[0]['tool'] ?? '', 'args' => $ptools[0]['args'] ?? [], 'confirm_msg' => $ptools[0]['confirm_msg'] ?? '', 'model' => $model, 'effort' => $effort, 'quota' => $rel['quota'] ?? []]);
            }
            if (!empty($rel['quota'])) {
                json_resp(false, (string)($rel['msg'] ?? ''), ['quota' => true]);
            }
        }
        $out = ai_demo_reply($db, $msg);
        json_resp(true, '', ['reply' => (string)($out['reply'] ?? ''), 'model' => $model, 'effort' => $effort, 'via' => 'local']);
    case 'ai_tool_run':

        require_resource('ai_assistant');

        $tool = trim((string)($_POST['tool'] ?? ''));
        $rawArgs = $_POST['args'] ?? [];
        if (is_string($rawArgs)) {
            $dec = json_decode($rawArgs, true);
            $rawArgs = is_array($dec) ? $dec : [];
        }
        if (!is_array($rawArgs)) $rawArgs = [];
        $res = ai_tool_run($db, $tool, $rawArgs);
        json_resp(!empty($res['ok']), (string)($res['msg'] ?? ''), $res);
    case 'ai_write':

        $wctx = trim((string)($_POST['context'] ?? 'product_desc'));
        if (!in_array($wctx, ['product_desc', 'announcement', 'seo'], true)) $wctx = 'product_desc';
        require_resource($wctx === 'seo' ? 'seo' : ($wctx === 'announcement' ? 'announcements' : 'products'));
        $aiBlockW = function_exists('plan_ai_check') ? plan_ai_check($db) : null;
        if ($aiBlockW !== null) json_resp(false, $aiBlockW, ['quota' => true]);
        $wprompt = mb_substr(trim((string)($_POST['prompt'] ?? '')), 0, 1000);
        $wdata = [];
        foreach (['name', 'price', 'label', 'url'] as $wk) {
            if (isset($_POST[$wk])) $wdata[$wk] = mb_substr(trim((string)$_POST[$wk]), 0, 200);
        }
        $wsys = ai_writer_prompt($db, $wctx);
        $wmsg = $wprompt !== '' ? $wprompt : 'İçerik üret.';
        if (!empty($wdata)) {
            $bits = [];
            foreach ($wdata as $bk => $bv) { if ($bv !== '') $bits[] = $bk . ': ' . $bv; }
            if ($bits) $wmsg .= "\nBağlam: " . implode(' | ', $bits);
        }
        if (function_exists('ai_relay_chat')) {
            $rel = ai_relay_chat($db, $wmsg, 'Vexaris-Auto', '', [], $wsys, [], 'write');
            if (!empty($rel['ok']) && trim((string)($rel['reply'] ?? '')) !== '') {
                audit_log($db, 'update', $wctx === 'seo' ? 'seo' : ($wctx === 'announcement' ? 'announcements' : 'products'), 0, mb_substr($wmsg, 0, 80), '');
                json_resp(true, '', ['reply' => (string)$rel['reply'], 'via' => 'saas']);
            }
        }
        json_resp(true, '', ['reply' => ai_demo_write($db, $wctx, $wprompt, $wdata), 'via' => 'local']);
    default:

        json_resp(false, __('err.unknown_action'));

}
