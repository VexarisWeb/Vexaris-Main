<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';

if (!has_permission('products')) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => __('err.no_perm')]);
    exit;
}

$pid = (int)($_GET['id'] ?? 0);
if (!$pid) { header('Content-Type: application/json'); echo json_encode(['success' => false, 'error' => __('astock.invalid')]); exit; }

$pr = $adminDb->prepare('SELECT id, name, stock_type FROM products WHERE id=?');
$pr->execute([$pid]);
$prod = $pr->fetch();
if (!$prod) { header('Content-Type: application/json'); echo json_encode(['success' => false, 'error' => __('shop.product_missing')]); exit; }

$si = $adminDb->prepare('SELECT id, content, used, used_by_user, used_at FROM product_stocks WHERE product_id=? ORDER BY id ASC');
$si->execute([$pid]);
$items = $si->fetchAll();

header('Content-Type: application/json');
echo json_encode([
    'success'    => true,
    'stock_type' => $prod['stock_type'],
    'available'  => count(array_filter($items, fn($r) => !$r['used'])),
    'total'      => count($items),
    'items'      => $items,
]);
