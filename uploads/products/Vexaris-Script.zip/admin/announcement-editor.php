<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('aann.title');
$activePage = 'announcements';

$editId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$editAnn = null;
if ($editId) {
    $ea = $adminDb->prepare('SELECT * FROM announcements WHERE id=?');
    $ea->execute([$editId]);
    $editAnn = $ea->fetch() ?: null;
}

$extraHead = '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
<script src="https://cdn.tailwindcss.com"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
html,body{height:100%;background:var(--bg);color:var(--text);font-family:"Plus Jakarta Sans",sans-serif;}
.ed-wrap{border-radius:0!important;border-left:none!important;border-right:none!important;flex:1;display:flex;flex-direction:column;}
.ed-tb{border-radius:0!important;}
.ed-body{flex:1!important;min-height:0!important;}
.editor-shell{display:flex;flex-direction:column;height:calc(100vh - 52px);}
.editor-title{padding:16px 24px;border-bottom:1px solid var(--border);}
.editor-title input{width:100%;background:transparent;border:none;outline:none;color:var(--text);font-size:28px;font-weight:900;font-family:inherit;padding:4px 0;}
.editor-title input::placeholder{color:var(--dim);}
.editor-body{flex:1;display:flex;flex-direction:column;overflow:hidden;}
.editor-footer{position:sticky;bottom:0;background:var(--bg-card);border-top:1px solid var(--border);padding:12px 24px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;}
.editor-footer .left{display:flex;align-items:center;gap:10px;font-size:12px;color:var(--muted);}
.editor-footer .right{display:flex;align-items:center;gap:8px;}
.btn-ed{border:none;border-radius:10px;padding:10px 20px;font-size:13px;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;gap:7px;transition:transform .05s,box-shadow .05s;font-family:inherit;}
.btn-ed:active{transform:translateY(2px);}
.btn-ed-draft{background:var(--bg-surface);color:var(--muted);border:1px solid var(--border);}
.btn-ed-draft:hover{background:var(--bg-hover);}
.btn-ed-publish{background:linear-gradient(180deg,#fbc853,#f7b131);color:#4c3716;border:1px solid #d39522;box-shadow:0 3px 0 #a26e13;}
.btn-ed-publish:hover{filter:brightness(1.08);}
.btn-ed-hide{background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2);}
.btn-ed-hide:hover{background:rgba(239,68,68,.2);}
</style>';
require_once __DIR__ . '/../core/editor.php';
include __DIR__ . '/includes/layout.php';
?>
<style>
@keyframes imgModalIn{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}
</style>

<div style="max-width:100%;padding:0;">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 24px;border-bottom:1px solid var(--border);background:var(--bg-card);">
        <a href="/admin/announcements.php" style="display:flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;font-weight:700;text-decoration:none;">
            <i class="fa-solid fa-arrow-left"></i> <?= __('aann.back') ?>
        </a>
        <?php if ($editAnn): ?>
        <span style="font-size:12px;color:var(--muted);background:var(--bg-surface);padding:4px 12px;border-radius:6px;">
            <i class="fa-regular fa-pen-to-square"></i> <?= __('apedit.editing') ?> <?= e($editAnn['title']) ?>
            <span style="color:<?= $editAnn['status']==='published'?'#4ade80':($editAnn['status']==='hidden'?'#f87171':'#94a3b8') ?>;margin-left:6px;">
                (<?= $editAnn['status']==='published'?__('apedit.status_live'):($editAnn['status']==='hidden'?__('adash.status_hidden'):__('adash.status_draft')) ?>)
            </span>
        </span>
        <?php endif; ?>
    </div>

    <form method="POST" enctype="multipart/form-data" id="annEditorForm" class="editor-shell">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="announcement_save">
        <input type="hidden" name="status" id="announcementStatus" value="<?= $editAnn['status'] ?? 'draft' ?>">
        <?php if ($editAnn): ?>
        <input type="hidden" name="id" value="<?= $editId ?>">
        <?php endif; ?>

        <div class="editor-title">
            <input type="text" name="title" id="annTitle" required maxlength="255" placeholder="<?= __('aann.title_ph') ?>"
                   value="<?= e($editAnn['title'] ?? '') ?>" autofocus>
        </div>

        <div class="editor-topbar" style="display:flex;justify-content:flex-end;padding:8px 4px 0;">
            <button type="button" onclick="annAiWrite()" style="display:inline-flex;align-items:center;gap:6px;background:linear-gradient(135deg,var(--accent),#7c3aed);color:#fff;border:none;border-radius:8px;padding:6px 14px;font-size:12px;font-weight:900;cursor:pointer;font-family:inherit;"><i class="fa-solid fa-wand-magic-sparkles"></i> AI</button>
        </div>
        <div class="editor-body" id="annDescWrap">
            <?php render_editor('annEditorContent', $editAnn['content'] ?? '', '100%', 'content'); ?>
        </div>

        <div class="editor-footer">
            <div class="left">
                <button type="button" onclick="openAnnImageModal()" style="background:none;border:none;color:var(--muted);cursor:pointer;display:flex;align-items:center;gap:6px;font-size:12px;font-family:inherit;font-weight:600;">
                    <i class="fa-solid fa-camera"></i> <span id="annImageLabel"><?= __('aann.cover') ?></span>
                </button>
                <input type="hidden" name="image_url" id="annImageUrl" value="<?= e($editAnn['image_url'] ?? '') ?>">
                <?php if (!empty($editAnn['image_url'])): ?>
                <span style="display:flex;align-items:center;gap:4px;color:#4ade80;">
                    <i class="fa-solid fa-check-circle"></i> <?= __('aann.has_image') ?>
                </span>
                <?php endif; ?>
            </div>
            <div class="right">
                <button type="button" data-status="draft" class="btn-ed btn-ed-draft ann-submit">
                    <i class="fa-regular fa-floppy-disk"></i> <?= __('msg.save') ?>
                </button>
                <button type="button" data-status="hidden" class="btn-ed btn-ed-hide ann-submit">
                    <i class="fa-solid fa-eye-slash"></i> <?= __('apedit.hide_btn') ?>
                </button>
                <button type="button" data-status="published" class="btn-ed btn-ed-publish ann-submit">
                    <i class="fa-solid fa-bullhorn"></i> <?= __('apedit.publish_btn') ?>
                </button>
            </div>
        </div>
    </form>
</div>

<!-- ══ Kapak Görseli Modalı ══ -->
<div id="annImageModal" class="hidden" style="display:none;position:fixed;inset:0;z-index:999;flex:initial;align-items:center;justify-content:center;padding:16px;">
    <div style="position:absolute;inset:0;background:rgba(0,0,0,.6);backdrop-filter:blur(4px);" onclick="closeAnnImageModal()"></div>
    <div style="position:relative;background:var(--bg-card);border:1px solid var(--border);border-radius:16px;width:100%;max-width:480px;box-shadow:0 24px 64px rgba(0,0,0,.5);animation:imgModalIn .25s ease;">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--border);">
            <h3 style="font-size:15px;font-weight:900;display:flex;align-items:center;gap:8px;"><i class="fa-solid fa-image" style="color:var(--accent);"></i> <?= __('aann.cover') ?></h3>
            <button onclick="closeAnnImageModal()" style="background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div style="display:flex;border-bottom:1px solid var(--border);">
            <button type="button" class="aim-tab" data-tab="upload" onclick="switchAimTab('upload')" style="flex:1;padding:12px;text-align:center;font-size:13px;font-weight:700;background:rgba(var(--accent-rgb,99,102,241),.12);color:var(--accent);border-bottom:2px solid var(--accent);border:none;cursor:pointer;font-family:inherit;"><i class="fa-solid fa-cloud-arrow-up"></i> <?= __('apedit.tab_file') ?></button>
            <button type="button" class="aim-tab" data-tab="link" onclick="switchAimTab('link')" style="flex:1;padding:12px;text-align:center;font-size:13px;font-weight:700;color:var(--muted);border:none;cursor:pointer;background:transparent;font-family:inherit;"><i class="fa-solid fa-link"></i> <?= __('asett.link_tab') ?></button>
        </div>
        <div id="aimTabUpload" style="padding:20px;">
            <div id="aimDropZone" style="background:var(--bg-surface);border:2px dashed var(--border);border-radius:12px;padding:28px;text-align:center;cursor:pointer;transition:border-color .2s;"
                 onclick="document.getElementById('aimFileInput').click()"
                 ondragover="this.style.borderColor='var(--accent)';this.style.background='rgba(var(--accent-rgb,99,102,241),.06)';return false;"
                 ondragleave="this.style.borderColor='var(--border)';this.style.background='var(--bg-surface)';"
                 ondrop="handleAimDrop(event)">
                <input type="file" id="aimFileInput" accept="image/jpeg,image/png,image/webp,image/gif" style="display:none;" onchange="handleAimFile(this.files[0])">
                <div id="aimDropContent">
                    <i class="fa-solid fa-cloud-arrow-up" style="font-size:32px;color:var(--dim);display:block;margin-bottom:10px;"></i>
                    <p style="font-size:13px;color:var(--muted);font-weight:600;margin-bottom:4px;"><?= __('apedit.drop_title') ?></p>
                    <p style="font-size:11px;color:var(--dim);"><?= __('apedit.drop_hint') ?></p>
                </div>
                <div id="aimPreviewArea" style="display:none;">
                    <img id="aimPreviewImg" style="max-height:120px;max-width:100%;object-fit:contain;border-radius:8px;margin:0 auto;">
                </div>
            </div>
            <div id="aimStatus" class="hidden" style="margin-top:10px;padding:8px 12px;border-radius:8px;font-size:12px;font-weight:700;display:none;"></div>
            <button type="button" id="aimUploadBtn" onclick="submitAimUpload()" class="btn-ed btn-ed-publish" style="width:100%;justify-content:center;margin-top:12px;display:none;">
                <i class="fa-solid fa-upload"></i> <?= __('panel.upload') ?>
            </button>
        </div>
        <div id="aimTabLink" style="padding:20px;display:none;">
            <label style="display:block;font-size:12px;font-weight:700;color:#64748b;margin-bottom:6px;"><?= __('apedit.image_url') ?></label>
            <div style="display:flex;gap:8px;">
                <input type="url" id="aimLinkInput" placeholder="https://ornek.com/resim.webp"
                       style="flex:1;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                <button type="button" onclick="applyAimLink()" class="btn-ed btn-ed-publish" style="padding:10px 18px;">
                    <i class="fa-solid fa-check"></i> <?= __('aann.apply') ?>
                </button>
            </div>
            <div id="aimLinkPreview" class="hidden" style="margin-top:10px;display:none;">
                <img id="aimLinkPreviewImg" style="max-height:100px;max-width:100%;object-fit:contain;border-radius:6px;margin:0 auto;">
            </div>
        </div>
    </div>
</div>

<script>
var _aimSelectedFile = null;
function openAnnImageModal() {
    document.getElementById('annImageModal').style.display = 'flex';
    document.getElementById('annImageModal').classList.remove('hidden');
    _aimSelectedFile = null;
    document.getElementById('aimFileInput').value = '';
    document.getElementById('aimDropContent').style.display = 'block';
    document.getElementById('aimPreviewArea').style.display = 'none';
    document.getElementById('aimUploadBtn').style.display = 'none';
    document.getElementById('aimStatus').style.display = 'none';
    document.getElementById('aimStatus').classList.add('hidden');
    document.getElementById('aimLinkInput').value = '';
    document.getElementById('aimLinkPreview').style.display = 'none';
    document.getElementById('aimLinkPreview').classList.add('hidden');
    switchAimTab('upload');
}
function closeAnnImageModal() { document.getElementById('annImageModal').style.display = 'none'; document.getElementById('annImageModal').classList.add('hidden'); }
function switchAimTab(tab) {
    document.querySelectorAll('.aim-tab').forEach(function(t){
        if(t.dataset.tab===tab){t.style.background='rgba(var(--accent-rgb),.12)';t.style.color='#a5b4fc';t.style.borderBottom='2px solid var(--accent)';}
        else{t.style.background='transparent';t.style.color='#64748b';t.style.borderBottom='';}
    });
    document.getElementById('aimTabUpload').style.display=tab==='upload'?'block':'none';
    document.getElementById('aimTabLink').style.display=tab==='link'?'block':'none';
}
function handleAimDrop(e){e.preventDefault();document.getElementById('aimDropZone').style.borderColor='rgba(255,255,255,.1)';document.getElementById('aimDropZone').style.background='#0f1422';if(e.dataTransfer.files[0])handleAimFile(e.dataTransfer.files[0]);}
function handleAimFile(file){
    if(!file.type.match(/image\/(jpeg|png|webp|gif)/))return void showAimStatus(<?= json_encode(__('apedit.bad_format')) ?>,false);
    if(file.size>4194304)return void showAimStatus(<?= json_encode(__('apedit.too_big')) ?>,false);
    _aimSelectedFile=file;document.getElementById('aimDropContent').style.display='none';document.getElementById('aimPreviewArea').style.display='block';document.getElementById('aimUploadBtn').style.display='flex';
    var r=new FileReader();r.onload=function(e){document.getElementById('aimPreviewImg').src=e.target.result;};r.readAsDataURL(file);document.getElementById('aimStatus').style.display='none';
}
function showAimStatus(msg,ok){
    var el=document.getElementById('aimStatus');el.style.display='flex';el.className='mt-3 text-sm font-semibold rounded-lg px-3 py-2 flex items-center gap-2'+(ok?' bg-green-900/30 border border-green-700 text-green-300':' bg-red-900/30 border border-red-700 text-red-300');
    el.innerHTML='<i class="fa-solid fa-'+(ok?'circle-check':'circle-xmark')+'"></i> '+msg;
}
async function submitAimUpload(){
    if(!_aimSelectedFile)return;
    var btn=document.getElementById('aimUploadBtn');btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> '+<?= json_encode(__('aprod.loading')) ?>;
    var fd=new FormData();fd.append('action','asset_upload');fd.append('ctx','announcements');fd.append('asset_type','cover');fd.append('file',_aimSelectedFile);
    try{
        var r=await fetch('/action.php',{method:'POST',body:fd});var d=await r.json();
        if(d.ok){showAimStatus(<?= json_encode(__('apedit.uploaded_ok')) ?>,true);applyAimUrl(d.url);}
        else{showAimStatus(d.msg||<?= json_encode(__('apedit.upload_fail')) ?>,false);btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-upload"></i> '+<?= json_encode(__('panel.upload')) ?>;}
    }catch(e){showAimStatus(<?= json_encode(__('aprod.req_fail_short')) ?>,false);btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-upload"></i> '+<?= json_encode(__('panel.upload')) ?>;}
}
function applyAimUrl(url){
    document.getElementById('annImageUrl').value=url;document.getElementById('annImageLabel').textContent=<?= json_encode(__('aann.selected')) ?>;
    document.getElementById('annImageLabel').style.color='#4ade80';closeAnnImageModal();
}
function applyAimLink(){
    var url=document.getElementById('aimLinkInput').value.trim();if(!url)return void showAimStatus(<?= json_encode(__('apedit.url_required')) ?>,false);
    var preview=document.getElementById('aimLinkPreview');var img=document.getElementById('aimLinkPreviewImg');
    img.src=url;preview.style.display='block';preview.classList.remove('hidden');
    img.onload=function(){showAimStatus(<?= json_encode(__('aref.link_ok')) ?>,true);applyAimUrl(url);};
    img.onerror=function(){showAimStatus(<?= json_encode(__('apedit.link_bad')) ?>,false);};
}

/* ── beforeunload + annSubmit ── */
var _annDirty = false;
var _annTitleInput = document.getElementById('annTitle');
var _annEditorBody = document.getElementById('edBody-annEditorContent');
if (_annTitleInput) _annTitleInput.addEventListener('input', function(){ _annDirty = true; });
if (_annEditorBody) {
    var _annObs = new MutationObserver(function(){ _annDirty = true; });
    _annObs.observe(_annEditorBody, {childList:true,subtree:true,characterData:true});
}
window.addEventListener('beforeunload', function(e) {
    if (_annDirty) { e.preventDefault(); e.returnValue = ''; }
});
function annAiWrite(){
    var t = document.getElementById('annTitle');
    vxwOpen({
        context: 'announcement',
        title: 'AI Duyuru',
        approve: 'İçeriğe Ekle',
        embed: 'annDescWrap',
        data: {name: t ? t.value : ''},
        onApprove: function(html){
            var body = document.getElementById('edBody-annEditorContent');
            if (body) { body.innerHTML = (body.innerHTML.trim() !== '' ? body.innerHTML + '<p></p>' : '') + html; body.focus(); }
        }
    });
}
function annSubmit(status) {
    var body = document.getElementById('edBody-annEditorContent');
    var ta = document.getElementById('annEditorContent');
    if (body && ta) ta.value = body.innerHTML;
    document.getElementById('announcementStatus').value = status;
    var fd = new FormData(document.getElementById('annEditorForm'));
    fd.append('is_fetch', '1');
    _annDirty = false;
    fetch('/action.php', {method:'POST', body:fd}).then(function(r){ return r.json(); }).then(function(d){
        if (d.ok) {
            window.location.href = d.redirect || '/admin/announcements.php';
        } else {
            alert(d.msg || <?= json_encode(__('msg.error_generic')) ?>);
        }
    }).catch(function(){ alert(<?= json_encode(__('aprod.req_fail_short')) ?>); });
}
document.querySelectorAll('.ann-submit').forEach(function(btn){
    btn.addEventListener('click', function(e){
        e.preventDefault();
        annSubmit(btn.getAttribute('data-status'));
    });
});
</script>

<?php include __DIR__ . '/includes/ai-writer.php'; ?>
<?php include __DIR__ . '/includes/layout-end.php'; ?>
