<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.announcements');
$activePage = 'announcements';

$flash = $_GET['flash'] ?? '';
[$flashType, $flashText] = $flash ? explode(':', urldecode($flash), 2) + ['',''] : ['', ''];

$announcements = $adminDb->query('SELECT * FROM announcements ORDER BY created_at DESC')->fetchAll();

include __DIR__ . '/includes/layout.php';
?>

<?php if ($flashText): ?>
<div style="padding:12px 18px;border-radius:12px;font-size:14px;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:8px;
     background:<?= $flashType === 'success' ? 'rgba(34,197,94,.1)' : 'rgba(239,68,68,.1)' ?>;
     border:1px solid <?= $flashType === 'success' ? 'rgba(34,197,94,.3)' : 'rgba(239,68,68,.3)' ?>;
     color:<?= $flashType === 'success' ? '#4ade80' : '#f87171' ?>;">
    <i class="fa-solid fa-<?= $flashType === 'success' ? 'circle-check' : 'circle-xmark' ?>"></i>
    <?= e($flashText) ?>
</div>
<?php endif; ?>

<div class="admin-card" style="margin-bottom:0;">
    <div class="admin-card-header">
        <span class="admin-card-title">
            <i class="fa-solid fa-bullhorn" style="color:#fbc853;margin-right:8px;"></i>
            <?= __('aanns.all') ?> <span style="color:var(--muted);font-weight:500;">(<?= count($announcements) ?>)</span>
        </span>
        <a href="/admin/announcement-editor.php" class="btn-admin btn-primary-admin" style="font-size:12px;padding:7px 16px;">
            <i class="fa-solid fa-plus"></i> <?= __('aanns.add') ?>
        </a>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th><?= __('aanns.th_image') ?></th>
                <th><?= __('aanns.th_title') ?></th>
                <th><?= __('adash.th_status') ?></th>
                <th><?= __('apurch.col_date') ?></th>
                <th style="text-align:right;"><?= __('adash.th_action') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($announcements as $ann): ?>
        <tr class="animate-row">
            <td style="width:60px;">
                <?php if (!empty($ann['image_url'])): ?>
                <img src="<?= e($ann['image_url']) ?>" style="width:52px;height:33px;object-fit:cover;border-radius:6px;" alt="">
                <?php else: ?>
                <div style="width:52px;height:33px;background:var(--bg-surface);border-radius:6px;display:flex;align-items:center;justify-content:center;color:var(--dim);">
                    <i class="fa-solid fa-image"></i>
                </div>
                <?php endif; ?>
            </td>
            <td style="font-weight:700;"><?= e($ann['title']) ?></td>
            <td>
                <?php $st = $ann['status'] ?? 'draft'; ?>
                <span style="font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;display:inline-block;
                    <?= $st==='published'?'background:rgba(34,197,94,.1);color:#4ade80;':($st==='hidden'?'background:rgba(239,68,68,.1);color:#f87171;':'background:rgba(255,255,255,.05);color:#94a3b8;') ?>">
                    <?= $st==='published'?__('apedit.status_live'):($st==='hidden'?__('adash.status_hidden'):__('adash.status_draft')) ?>
                </span>
            </td>
            <td style="color:var(--muted);font-size:12px;"><?= date('d.m.Y', strtotime($ann['created_at'])) ?></td>
            <td>
                <div style="display:flex;gap:6px;justify-content:flex-end;">
                    <a href="/admin/announcement-editor.php?id=<?= $ann['id'] ?>" class="btn-admin btn-ghost-admin" style="padding:6px 12px;font-size:12px;">
                        <i class="fa-solid fa-pen"></i>
                    </a>
                    <form method="POST" action="/action.php" onsubmit="return confirm(<?= json_encode(__('aanns.delete_confirm')) ?>);" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="announcement_delete">
                        <input type="hidden" name="id" value="<?= $ann['id'] ?>">
                        <button type="submit" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;padding:6px 12px;font-size:12px;border:1px solid rgba(239,68,68,.2);">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($announcements)): ?>
        <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:32px;"><?= __('aanns.empty') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

</div>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
