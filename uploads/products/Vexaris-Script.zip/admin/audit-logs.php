<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.audit_logs');
$activePage = 'audit-logs';

$q = mb_substr(trim($_GET['q'] ?? ''), 0, 100, 'UTF-8');
$fRes = trim($_GET['res'] ?? '');
$fAct = trim($_GET['act'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;

$resOptions = ['products','purchases','categories','licenses','reviews','coupons','slider','announcements','references','seo','custom_pages','legal','themes','users','permissions','roles','settings','integrations','modules','support','ticket_categories','discord-webhook','stats','versions','stock','sales','balance'];
if ($fRes !== '' && !in_array($fRes, $resOptions, true)) $fRes = '';
if ($fAct !== '' && !in_array($fAct, ['create','update','delete'], true)) $fAct = '';

$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(username LIKE ? OR label LIKE ?)';
    $like = '%' . str_replace(['\\','%','_'], ['\\\\','\\%','\\_'], $q) . '%';
    $params[] = $like;
    $params[] = $like;
}
if ($fRes !== '') { $where[] = 'resource = ?'; $params[] = $fRes; }
if ($fAct !== '') { $where[] = '`action` = ?'; $params[] = $fAct; }
$sqlWhere = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$total = 0;
$logs = [];
try {
    $cStmt = $adminDb->prepare("SELECT COUNT(*) FROM audit_logs $sqlWhere");
    $cStmt->execute($params);
    $total = (int)$cStmt->fetchColumn();
    $pages = max(1, (int)ceil($total / $perPage));
    if ($page > $pages) $page = $pages;
    $offset = ($page - 1) * $perPage;
    $lStmt = $adminDb->prepare("SELECT id,user_id,username,user_role,`action`,resource,resource_id,label,url,ip,created_at FROM audit_logs $sqlWhere ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $lStmt->execute($params);
    $logs = $lStmt->fetchAll();
} catch (\PDOException $e) {
    error_log('[Vexaris] audit-logs list: ' . $e->getMessage());
}

function alog_res_label(string $res): string {
    $k = 'alog.res_' . $res;
    $v = __($k);
    return $v === $k ? ucfirst(str_replace(['-','_'], ' ', $res)) : $v;
}

$qsBase = 'q=' . urlencode($q) . '&res=' . urlencode($fRes) . '&act=' . urlencode($fAct);

include __DIR__ . '/includes/layout.php';
?>
<style>
.alog-filters{display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;align-items:center;}
.alog-search{position:relative;flex:1;min-width:180px;}
.alog-search i{position:absolute;left:12px;top:50%;transform:translateY(-50%);font-size:12px;color:var(--muted);}
.alog-search input{width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:9px 14px 9px 34px;color:var(--text);font-size:13px;outline:none;}
.alog-filters select{background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:9px 12px;color:var(--text);font-size:12px;font-weight:600;outline:none;font-family:inherit;max-width:100%;}
.alog-pager{display:flex;align-items:center;justify-content:center;gap:12px;margin-top:16px;font-size:12px;font-weight:800;color:var(--muted);}
@media(max-width:768px){
  .alog-filters .btn-admin{flex:1;justify-content:center;}
  .alog-search{flex:1 1 100%;}
  .alog-filters select{flex:1;}
}
</style>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title">
            <i class="fa-solid fa-clock-rotate-left" style="color:var(--accent);margin-right:8px;"></i>
            <?= __('alog.title') ?> <span style="color:var(--muted);font-weight:500;">(<?= number_format($total) ?>)</span>
        </span>
    </div>

    <form method="GET" class="alog-filters">
        <div class="alog-search">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" name="q" value="<?= e($q) ?>" placeholder="<?= __('alog.search_ph') ?>">
        </div>
        <select name="res">
            <option value=""><?= __('alog.f_resource') ?>: <?= __('alog.all') ?></option>
            <?php foreach ($resOptions as $ro): ?>
            <option value="<?= $ro ?>" <?= $fRes===$ro?'selected':'' ?>><?= alog_res_label($ro) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="act">
            <option value=""><?= __('alog.f_action') ?>: <?= __('alog.all') ?></option>
            <option value="create" <?= $fAct==='create'?'selected':'' ?>><?= __('alog.act_create') ?></option>
            <option value="update" <?= $fAct==='update'?'selected':'' ?>><?= __('alog.act_update') ?></option>
            <option value="delete" <?= $fAct==='delete'?'selected':'' ?>><?= __('alog.act_delete') ?></option>
        </select>
        <button type="submit" class="btn-admin btn-primary-admin"><i class="fa-solid fa-filter"></i> <?= __('alog.filter') ?></button>
        <?php if ($q !== '' || $fRes !== '' || $fAct !== ''): ?>
        <a href="/admin/audit-logs.php" class="btn-admin btn-ghost-admin"><i class="fa-solid fa-xmark"></i> <?= __('alog.clear') ?></a>
        <?php endif; ?>
    </form>

    <?php if (empty($logs)): ?>
    <div style="text-align:center;padding:48px 20px;color:var(--muted);">
        <i class="fa-solid fa-clock-rotate-left" style="font-size:40px;color:var(--dim);margin-bottom:12px;display:block;"></i>
        <p style="font-size:13px;font-weight:600;"><?= __('alog.empty') ?></p>
    </div>
    <?php else: ?>
    <table class="admin-table">
        <thead>
            <tr>
                <th style="width:44px;"></th>
                <th><?= __('alog.col_event') ?></th>
                <th><?= __('alog.col_user') ?></th>
                <th><?= __('alog.col_time') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($logs as $i => $l):
            [$actIcon, $actColor] = audit_action_meta((string)$l['action']);
            $resIcon = audit_resource_icon((string)$l['resource']);
            $actKey = 'alog.act_' . $l['action'];
            $actLabel = __($actKey) === $actKey ? $l['action'] : __($actKey);
        ?>
        <tr class="animate-row">
            <td>
                <span style="display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:10px;background:<?= $actColor ?>1f;border:1px solid <?= $actColor ?>55;color:<?= $actColor ?>;font-size:15px;flex-shrink:0;">
                    <i class="<?= $resIcon ?>"></i>
                </span>
            </td>
            <td style="min-width:0;">
                <div style="font-weight:700;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;">
                    <?php if (!empty($l['url'])): ?>
                    <a href="<?= e($l['url']) ?>" style="color:var(--text);"><?= e($l['label']) ?></a>
                    <?php else: ?>
                    <?= e($l['label']) ?>
                    <?php endif; ?>
                </div>
                <div style="font-size:11px;color:var(--muted);font-weight:600;margin-top:2px;white-space:nowrap;">
                    <i class="<?= $actIcon ?>" style="color:<?= $actColor ?>;margin-right:4px;"></i><?= e($actLabel) ?> · <?= e(alog_res_label((string)$l['resource'])) ?>
                </div>
            </td>
            <td style="white-space:nowrap;">
                <div style="font-weight:700;font-size:12px;"><?= e($l['username'] !== '' ? $l['username'] : ('ID #' . (int)$l['user_id'])) ?></div>
                <div style="margin-top:3px;"><?= role_badge($adminDb, (string)$l['user_role']) ?></div>
            </td>
            <td style="color:var(--muted);font-size:11.5px;white-space:nowrap;"><?= date('d.m.Y H:i', strtotime($l['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (($pages ?? 1) > 1): ?>
    <div class="alog-pager">
        <?php if ($page > 1): ?>
        <a href="/admin/audit-logs.php?<?= $qsBase ?>&page=<?= $page - 1 ?>" class="btn-admin btn-ghost-admin"><i class="fa-solid fa-chevron-left"></i></a>
        <?php endif; ?>
        <span><?= $page ?> / <?= (int)$pages ?></span>
        <?php if ($page < $pages): ?>
        <a href="/admin/audit-logs.php?<?= $qsBase ?>&page=<?= $page + 1 ?>" class="btn-admin btn-ghost-admin"><i class="fa-solid fa-chevron-right"></i></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
