<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('acoup.title');
$activePage = 'coupons';

$flash = $_GET['flash'] ?? '';
[$flashType,$flashText] = $flash ? explode(':',urldecode($flash),2) + ['',''] : ['',''];

$tab = $_GET['tab'] ?? 'coupons';

$couponUsages = [];
if ($tab === 'usages') {
    $cuStmt = $adminDb->query(
        'SELECT cu.*,c.code AS coupon_code,u.username,u.email
         FROM coupon_usages cu
         JOIN coupons c ON c.id=cu.coupon_id
         JOIN users u ON u.id=cu.user_id
         ORDER BY cu.used_at DESC LIMIT 200'
    );
    $couponUsages = $cuStmt->fetchAll();
}

$coupons = $adminDb->query('SELECT * FROM coupons ORDER BY created_at DESC')->fetchAll();
$products = $adminDb->query('SELECT id,name,image_url FROM products WHERE status="active" ORDER BY name')->fetchAll();

include __DIR__ . '/includes/layout.php';
?>

<style>
.toggle-switch{position:relative;display:inline-block;width:42px;height:22px;}
.toggle-switch input{opacity:0;width:0;height:0;}
.toggle-slider{position:absolute;cursor:pointer;inset:0;background:#374151;border-radius:22px;transition:.2s;}
.toggle-slider:before{position:absolute;content:"";height:16px;width:16px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.2s;}
.toggle-switch input:checked+.toggle-slider{background:var(--accent);}
.toggle-switch input:checked+.toggle-slider:before{transform:translateX(20px);}

.coupon-form-section{display:none;}
.coupon-form-section.open{display:block;}
</style>

<?php if ($flashText): ?>
<div style="background:<?= $flashType==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;border:1px solid <?= $flashType==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;border-radius:12px;padding:12px 18px;font-size:13px;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:8px;color:<?= $flashType==='success'?'#4ade80':'#f87171' ?>;">
    <i class="fa-solid fa-<?= $flashType==='success'?'circle-check':'circle-xmark' ?>"></i>
    <?= e($flashText) ?>
</div>
<?php endif; ?>

<?php if ($tab === 'coupons'): ?>

<!-- ─── ÖZET KARTLARI ─── -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:24px;">
    <?php
    $totalCoupons  = count($coupons);
    $activeCoupons = count(array_filter($coupons, fn($c) => $c['is_active']));
    $totalUses     = array_sum(array_column($coupons, 'used_count'));
    $expiredCoupons = count(array_filter($coupons, fn($c) => $c['expires_at'] && strtotime($c['expires_at']) < time()));
    $summs = [
        [__('acoup.total'), $totalCoupons, 'fa-tag', '#818cf8'],
        [__('adash.status_active'),        $activeCoupons, 'fa-check-circle', '#4ade80'],
        [__('acoup.used_count'),  $totalUses, 'fa-users', '#fbc853'],
        [__('acoup.expired_count'),$expiredCoupons, 'fa-clock', '#f87171'],
    ];
    foreach ($summs as [$label,$val,$icon,$clr]):
    ?>
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:18px 20px;">
        <div style="display:flex;align-items:center;gap:12px;">
            <div style="width:40px;height:40px;border-radius:10px;background:<?= $clr ?>15;display:flex;align-items:center;justify-content:center;font-size:16px;color:<?= $clr ?>;">
                <i class="fa-solid <?= $icon ?>"></i>
            </div>
            <div>
                <p style="font-size:22px;font-weight:900;line-height:1;"><?= $val ?></p>
                <p style="font-size:11px;color:var(--muted);font-weight:600;margin-top:3px;"><?= $label ?></p>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- ─── YENİ KUPON BUTONU ─── -->
<button onclick="toggleForm()" id="toggleFormBtn" style="display:flex;align-items:center;justify-content:center;gap:8px;width:100%;padding:16px;border-radius:14px;border:2px dashed var(--border);background:transparent;color:var(--muted);font-family:inherit;font-size:14px;font-weight:700;cursor:pointer;transition:border-color .2s,color .2s;margin-bottom:24px;">
    <i class="fa-solid fa-plus" style="font-size:18px;"></i>
    <span id="toggleFormBtnText"><?= __('acoup.new_create') ?></span>
</button>

<!-- ─── OLUŞTURMA FORMU (tam ekran) ─── -->
<div class="coupon-form-section" id="couponFormSection">
    <div style="background:var(--bg-card);border:1px solid var(--accent);border-radius:16px;padding:28px;margin-bottom:24px;box-shadow:0 0 0 3px rgba(var(--accent-rgb),.08);">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;">
            <div>
                <h2 style="font-size:18px;font-weight:900;display:flex;align-items:center;gap:10px;">
                    <span style="width:36px;height:36px;border-radius:10px;background:rgba(var(--accent-rgb),.12);display:flex;align-items:center;justify-content:center;font-size:14px;color:#818cf8;">
                        <i class="fa-solid fa-wand-magic-sparkles"></i>
                    </span>
                    <?= __('acoup.new_create') ?>
                </h2>
                <p style="font-size:12px;color:var(--muted);margin-top:4px;margin-left:46px;"><?= __('acoup.form_sub') ?></p>
            </div>
            <button type="button" onclick="toggleForm()" style="width:32px;height:32px;border-radius:8px;border:1px solid var(--border);background:var(--bg-surface);color:var(--muted);cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <form method="POST" action="/action.php">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="manage_coupon">
            <input type="hidden" name="op" value="add">

            <!-- 1. satır: Kod + Max Kullanım -->
            <div style="display:grid;grid-template-columns:2fr 1fr;gap:14px;margin-bottom:16px;">
                <div>
                    <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('acoup.code_label') ?> <span style="color:#ef4444;">*</span></label>
                    <div style="position:relative;">
                        <input type="text" name="code" id="couponCodeInput" required maxlength="50"
                               placeholder="<?= __('acoup.code_ph') ?>"
                               style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:11px 14px;padding-right:96px;color:var(--text);font-size:14px;outline:none;font-weight:700;letter-spacing:.08em;text-transform:uppercase;font-family:monospace;">
                        <button type="button" onclick="randomCouponCode()" title="<?= __('acoup.random_title') ?>"
                                style="position:absolute;right:8px;top:50%;transform:translateY(-50%);background:rgba(var(--accent-rgb),.12);color:#a5b4fc;border:1px solid rgba(var(--accent-rgb),.3);border-radius:7px;padding:5px 9px;cursor:pointer;font-size:11px;font-weight:700;font-family:inherit;display:flex;align-items:center;gap:5px;">
                            <i class="fa-solid fa-shuffle"></i> <?= __('acoup.random_btn') ?>
                        </button>
                    </div>
                </div>
                <div>
                    <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('acoup.max_uses') ?></label>
                    <input type="number" name="max_uses" value="1" min="1" required
                           style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:11px 14px;color:var(--text);font-size:14px;outline:none;">
                </div>
            </div>

            <!-- 2. satır: Ödül Türü -->
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:8px;"><?= __('acoup.reward_type') ?></label>
                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;">
                    <label class="reward-option" data-target="discountFields" style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;border:2px solid var(--border);cursor:pointer;transition:border-color .2s,background .2s;background:var(--bg-surface);" onclick="selectReward(this,'discount')">
                        <input type="radio" name="reward_type" value="discount" checked style="accent-color:var(--accent);">
                        <div>
                            <span style="font-size:13px;font-weight:700;"><?= __('acoup.reward_discount') ?></span>
                            <p style="font-size:10px;color:var(--muted);"><?= __('acoup.reward_discount_desc') ?></p>
                        </div>
                    </label>
                    <label class="reward-option" data-target="productGrantFields" style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;border:2px solid var(--border);cursor:pointer;transition:border-color .2s,background .2s;background:var(--bg-surface);" onclick="selectReward(this,'product_grant')">
                        <input type="radio" name="reward_type" value="product_grant" style="accent-color:var(--accent);">
                        <div>
                            <span style="font-size:13px;font-weight:700;"><?= __('acoup.reward_product') ?></span>
                            <p style="font-size:10px;color:var(--muted);"><?= __('acoup.reward_product_desc') ?></p>
                        </div>
                    </label>
                    <label class="reward-option" data-target="productGrantFields" style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;border:2px solid var(--border);cursor:pointer;transition:border-color .2s,background .2s;background:var(--bg-surface);" onclick="selectReward(this,'license_grant')">
                        <input type="radio" name="reward_type" value="license_grant" style="accent-color:var(--accent);">
                        <div>
                            <span style="font-size:13px;font-weight:700;"><?= __('acoup.reward_license') ?></span>
                            <p style="font-size:10px;color:var(--muted);"><?= __('acoup.reward_license_desc') ?></p>
                        </div>
                    </label>
                </div>
            </div>

            <!-- 3. satır: İndirim Türü (sadece discount seçiliyken) -->
            <div id="discountFields" style="margin-bottom:16px;">
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:8px;"><?= __('acoup.discount_label') ?></label>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                    <select name="type" id="discountTypeSelect"
                            style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:11px 14px;color:var(--text);font-size:14px;outline:none;">
                        <option value="percent"><?= __('acoup.opt_percent') ?></option>
                        <option value="flat_tl"><?= __('acoup.opt_tl') ?></option>
                        <option value="flat_usd"><?= __('acoup.opt_usd') ?></option>
                        <option value="flat_eur"><?= __('acoup.opt_eur') ?></option>
                    </select>
                    <div style="position:relative;">
                        <span id="discountPrefix" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);font-size:14px;font-weight:700;color:var(--muted);pointer-events:none;">%</span>
                        <input type="number" name="reward_value" id="discountValue" required step="0.01" min="0"
                               placeholder="20"
                               style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:11px 14px;padding-left:30px;color:var(--text);font-size:14px;outline:none;">
                    </div>
                </div>
            </div>

            <!-- 4. satır: Ürün seçici (grant için) -->
            <div id="productGrantFields" style="display:none;margin-bottom:16px;">
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:8px;"><?= __('amenu.products') ?> <span style="color:var(--dim);font-weight:400;"><?= __('acoup.multi_hint') ?></span></label>
                <button type="button" onclick="openGrantPicker()" style="width:100%;display:flex;align-items:center;justify-content:center;gap:8px;background:var(--bg-surface);border:1px dashed var(--border);border-radius:10px;padding:13px;color:var(--muted);font-size:13px;font-weight:700;cursor:pointer;transition:border-color .2s,color .2s;">
                    <i class="fa-solid fa-box-open"></i> <?= __('acoup.pick_products') ?>
                </button>
                <input type="hidden" name="grant_product_ids" id="grantProductIds" value="">
                <div id="grantSelectedChips" style="display:flex;flex-wrap:wrap;gap:8px;margin-top:10px;"></div>
            </div>

            <div id="grantPickerModal" onclick="if(event.target===this)closeGrantPicker()" style="display:none;position:fixed;inset:0;z-index:1300;background:rgba(0,0,0,.7);align-items:center;justify-content:center;padding:20px;">
                <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:16px;width:100%;max-width:760px;max-height:82vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.5);">
                    <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 22px;border-bottom:1px solid var(--border);">
                        <span style="font-size:15px;font-weight:800;"><i class="fa-solid fa-box-open" style="color:var(--accent);margin-right:8px;"></i><?= __('aprod.pick_products') ?> <span id="grantCountSpan" style="color:var(--accent);"></span></span>
                        <button type="button" onclick="closeGrantPicker()" style="width:32px;height:32px;border-radius:8px;border:1px solid var(--border);background:var(--bg-surface);color:var(--muted);cursor:pointer;font-size:14px;"><i class="fa-solid fa-xmark"></i></button>
                    </div>
                    <div style="padding:14px 22px;border-bottom:1px solid var(--border);">
                        <input type="text" id="grantPickerSearch" oninput="applyGrantFilter()" placeholder="<?= __('aprod.search_ph') ?>" autocomplete="off"
                               style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    </div>
                    <div id="grantPickerGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;padding:18px 22px;overflow-y:auto;"></div>
                    <div style="display:flex;justify-content:flex-end;gap:10px;padding:16px 22px;border-top:1px solid var(--border);">
                        <button type="button" onclick="closeGrantPicker()" class="btn-admin btn-ghost-admin" style="padding:10px 16px;"><?= __('support.cancel') ?></button>
                        <button type="button" onclick="closeGrantPicker()" class="btn-admin btn-primary-admin" style="padding:10px 16px;"><?= __('aprod.confirm') ?></button>
                    </div>
                </div>
            </div>

            <!-- 5. satır: Bitiş Tarihi -->
            <div style="margin-bottom:20px;">
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('acoup.expiry_label') ?> <span style="color:var(--dim);font-weight:400;"><?= __('acoup.optional') ?></span></label>
                <input type="datetime-local" name="expires_at"
                       style="width:100%;max-width:300px;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:11px 14px;color:var(--text);font-size:14px;outline:none;">
            </div>

            <!-- Submit -->
            <div style="display:flex;gap:10px;">
                <button type="submit" class="btn-admin btn-primary-admin" style="flex:1;justify-content:center;padding:13px;font-size:14px;">
                    <i class="fa-solid fa-wand-magic-sparkles"></i> <?= __('acoup.create_btn') ?>
                </button>
                <button type="button" onclick="toggleForm()" class="btn-admin btn-ghost-admin" style="padding:13px 20px;font-size:14px;">
                    <?= __('support.cancel') ?>
                </button>
            </div>
        </form>
    </div>
</div>

<?php endif; ?>

<?php if ($tab === 'usages'): ?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title">
            <i class="fa-solid fa-list-check" style="color:#fbc853;margin-right:8px;"></i>
            <?= __('acoup.usage_title') ?> <span style="color:var(--muted);font-weight:500;">(<?= count($couponUsages) ?>)</span>
        </span>
    </div>
    <div style="overflow-x:auto;">
    <table class="admin-table">
        <thead>
            <tr>
                <th>#</th>
                <th><?= __('panel.tx_coupon') ?></th>
                <th><?= __('apurch.user') ?></th>
                <th><?= __('auth.email') ?></th>
                <th><?= __('apurch.col_date') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($couponUsages as $i => $cu): ?>
        <tr>
            <td style="color:var(--muted);font-size:11px;"><?= $i+1 ?></td>
            <td><code style="background:rgba(var(--accent-rgb),.1);color:#a5b4fc;padding:3px 10px;border-radius:5px;font-size:12px;font-weight:700;"><?= e($cu['coupon_code']) ?></code></td>
            <td style="font-weight:600;font-size:13px;"><?= e($cu['username']) ?></td>
            <td style="color:var(--muted);font-size:12px;"><?= e($cu['email']) ?></td>
            <td style="font-size:12px;color:var(--muted);"><?= date('d.m.Y H:i', strtotime($cu['used_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($couponUsages)): ?>
        <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:32px;"><?= __('acoup.usage_empty') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

<?php else: ?>

    <?php if (empty($coupons)): ?>
    <div style="text-align:center;padding:60px 20px;color:var(--muted);">
        <i class="fa-solid fa-tag" style="font-size:44px;color:var(--dim);display:block;margin-bottom:14px;"></i>
        <p style="font-size:15px;font-weight:600;"><?= __('acoup.empty_title') ?></p>
        <p style="font-size:13px;color:var(--dim);margin-top:6px;"><?= __('acoup.empty_hint') ?></p>
    </div>
    <?php else: ?>
    <div style="overflow-x:auto;">
    <table class="admin-table">
        <thead>
            <tr>
                <th><?= __('panel.code') ?></th>
                <th><?= __('acoup.col_type') ?></th>
                <th><?= __('acoup.col_value') ?></th>
                <th><?= __('acoup.col_usage') ?></th>
                <th><?= __('acoup.col_expiry') ?></th>
                <th><?= __('adash.th_status') ?></th>
                <th style="text-align:right;"><?= __('adash.th_action') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($coupons as $c):
            $isExpired = $c['expires_at'] && strtotime($c['expires_at']) < time();
            $isFull    = $c['used_count'] >= $c['max_uses'];
            $dimmed    = (!$c['is_active'] || $isExpired) ? 'style="opacity:.4;"' : '';

            $tLabel = '';
            if ($c['reward_type'] === 'discount') {
                $typeMap = ['percent'=>'%','flat_tl'=>'₺','flat_usd'=>'$','flat_eur'=>'€'];
                $sym = $typeMap[$c['type']] ?? '';
                $tLabel = '<span style="font-weight:800;">'.$sym.number_format($c['reward_value'], $c['type']==='percent'?0:2).'</span> ' . __('acoup.discount_suffix');
            } elseif ($c['reward_type'] === 'product_grant' || $c['reward_type'] === 'license_grant') {
                $gIds = [];
                $raw = trim((string)($c['grant_product_ids'] ?? ''));
                if ($raw !== '') {
                    $decoded = json_decode($raw, true);
                    if (is_array($decoded)) foreach ($decoded as $v) { $v = (int)$v; if ($v > 0) $gIds[] = $v; }
                    elseif (is_numeric($raw)) $gIds[] = (int)$raw;
                }
                if (empty($gIds)) $gIds = [(int)$c['reward_value']];
                $names = [];
                foreach ($gIds as $gid) {
                    if ($gid <= 0) continue;
                    $pn = $adminDb->prepare('SELECT name FROM products WHERE id=?');
                    $pn->execute([$gid]);
                    $nm = $pn->fetchColumn();
                    $names[] = $nm ?: __('acoup.deleted');
                }
                $emoji = $c['reward_type'] === 'product_grant' ? '🎁' : '🔑';
                $tLabel = $emoji.' <span style="font-weight:700;">'.htmlspecialchars(implode(', ', $names) ?: __('acoup.deleted')).'</span>';
            }

            $rLabel = ['discount'=>__('acoup.reward_discount'),'product_grant'=>__('acoup.type_product'),'license_grant'=>__('acoup.type_license')][$c['reward_type']] ?? e($c['reward_type']);
        ?>
        <tr <?= $dimmed ?>>
            <td>
                <code style="background:rgba(var(--accent-rgb),.1);color:#a5b4fc;padding:4px 12px;border-radius:6px;font-size:13px;font-weight:800;letter-spacing:.05em;">
                    <?= e($c['code']) ?>
                </code>
            </td>
            <td style="font-size:13px;font-weight:600;"><?= $rLabel ?></td>
            <td style="font-size:13px;"><?= $tLabel ?></td>
            <td>
                <div style="display:flex;align-items:center;gap:8px;">
                    <span style="font-size:14px;font-weight:700;"><?= $c['used_count'] ?>/<?= $c['max_uses'] ?></span>
                    <div style="background:var(--bg-surface);border-radius:999px;height:5px;width:60px;overflow:hidden;">
                        <div style="height:100%;width:<?= $c['max_uses']>0?min(100,round($c['used_count']/$c['max_uses']*100)):0 ?>%;background:<?= $isFull?'#ef4444':'var(--accent)' ?>;border-radius:999px;"></div>
                    </div>
                </div>
            </td>
            <td style="font-size:13px;color:var(--muted);">
                <?php if ($c['expires_at']): ?>
                <span style="<?= $isExpired?'color:#f87171;font-weight:700;':'' ?>">
                    <?= $isExpired?'<i class="fa-solid fa-triangle-exclamation" style="margin-right:4px;"></i>':'' ?>
                    <?= date('d.m.Y', strtotime($c['expires_at'])) ?>
                </span>
                <?php else: ?>
                <span style="color:var(--dim);"><?= __('acoup.unlimited') ?></span>
                <?php endif; ?>
            </td>
            <td>
                <form method="POST" action="/action.php" style="margin:0;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="manage_coupon">
                    <input type="hidden" name="op" value="toggle_active">
                    <input type="hidden" name="id" value="<?= $c['id'] ?>">
                    <label class="toggle-switch" style="margin-bottom:0;">
                        <input type="checkbox" onchange="this.form.submit()" <?= $c['is_active']?'checked':'' ?>>
                        <span class="toggle-slider"></span>
                    </label>
                </form>
            </td>
            <td style="text-align:right;">
                <form method="POST" action="/action.php" onsubmit="return confirm('<?= __('acoup.delete_confirm') ?>');" style="margin:0;display:inline;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="manage_coupon">
                    <input type="hidden" name="op" value="delete">
                    <input type="hidden" name="id" value="<?= $c['id'] ?>">
                    <button type="submit"
                            style="background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2);border-radius:8px;padding:7px 10px;cursor:pointer;font-size:13px;">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>

<script>
/* Form aç/kapa */
function toggleForm() {
    const section = document.getElementById('couponFormSection');
    const btn = document.getElementById('toggleFormBtn');
    const btnText = document.getElementById('toggleFormBtnText');
    section.classList.toggle('open');
    if (section.classList.contains('open')) {
        btn.style.borderColor = 'var(--accent)';
        btn.style.color = '#a5b4fc';
        btnText.textContent = <?= json_encode(__('acoup.hide_form')) ?>;
    } else {
        btn.style.borderColor = 'var(--border)';
        btn.style.color = 'var(--muted)';
        btnText.textContent = <?= json_encode(__('acoup.new_create')) ?>;
    }
}

/* Ödül türü seçimi */
function selectReward(el, val) {
    document.querySelectorAll('.reward-option').forEach(o => {
        o.style.borderColor = 'var(--border)';
        o.style.background = 'var(--bg-surface)';
    });
    el.style.borderColor = 'var(--accent)';
    el.style.background = 'rgba(var(--accent-rgb),.06)';
    el.querySelector('input[type="radio"]').checked = true;

    const discount = document.getElementById('discountFields');
    const grant = document.getElementById('productGrantFields');
    discount.style.display = val === 'discount' ? '' : 'none';
    grant.style.display = (val === 'product_grant' || val === 'license_grant') ? '' : 'none';

    const discountInput = document.getElementById('discountValue');
    if (discountInput) discountInput.required = (val === 'discount');
}

/* Rastgele kupon kodu üret */
function randomCouponCode() {
    var chars = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
    var parts = [];
    for (var i = 0; i < 4; i++) {
        var s = '';
        for (var j = 0; j < 4; j++) s += chars.charAt(Math.floor(Math.random() * chars.length));
        parts.push(s);
    }
    document.getElementById('couponCodeInput').value = parts.join('-');
}

/* İndirim türü değişince prefix güncelle */
document.getElementById('discountTypeSelect')?.addEventListener('change', function() {
    const prefix = document.getElementById('discountPrefix');
    const input = document.getElementById('discountValue');
    const map = {percent:'%', flat_tl:'₺', flat_usd:'$', flat_eur:'€'};
    prefix.textContent = map[this.value] || '%';
    input.placeholder = this.value === 'percent' ? '20' : '50.00';
    input.step = this.value === 'percent' ? '1' : '0.01';
});

var grantProducts = <?= json_encode(array_map(fn($p) => ['id'=>(int)$p['id'],'name'=>$p['name'],'image'=>$p['image_url']], $products), JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var grantSelected = [];
var grantModal = document.getElementById('grantPickerModal');
var grantGrid = document.getElementById('grantPickerGrid');
var grantHidden = document.getElementById('grantProductIds');
var grantChips = document.getElementById('grantSelectedChips');
var grantCountSpan = document.getElementById('grantCountSpan');

function renderGrantGrid() {
    var q = (document.getElementById('grantPickerSearch').value || '').toLowerCase().trim();
    var h = '';
    for (var i = 0; i < grantProducts.length; i++) {
        var p = grantProducts[i];
        if (q && p.name.toLowerCase().indexOf(q) === -1) continue;
        var sel = grantSelected.indexOf(p.id) !== -1;
        h += '<div data-id="' + p.id + '" data-name="' + p.name.replace(/&/g,'&amp;').replace(/"/g,'&quot;') + '" onclick="toggleGrant(this)" style="' + (sel ? 'border-color:var(--accent);box-shadow:0 0 0 2px rgba(var(--accent-rgb),.25);' : 'border-color:var(--border);') + 'border:2px solid;border-radius:12px;overflow:hidden;cursor:pointer;background:var(--bg-surface);transition:.15s;">';
        h += '<div style="height:78px;background:var(--bg-surface);display:flex;align-items:center;justify-content:center;overflow:hidden;">';
        if (p.image) h += '<img src="' + p.image.replace(/"/g,'&quot;') + '" style="width:100%;height:100%;object-fit:cover;">';
        else h += '<i class="fa-solid fa-box-open" style="font-size:22px;color:var(--dim);"></i>';
        h += '</div>';
        h += '<div style="padding:8px 10px;display:flex;align-items:center;gap:8px;"><input type="checkbox" data-cb="1" ' + (sel?'checked':'') + ' style="accent-color:var(--accent);pointer-events:none;margin:0;"><span style="font-size:12px;font-weight:700;line-height:1.2;">' + p.name.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;') + '</span></div>';
        h += '</div>';
    }
    grantGrid.innerHTML = h || '<div style="grid-column:1/-1;text-align:center;color:var(--muted);padding:30px;">' + <?= json_encode(__('aprod.not_found')) ?> + '</div>';
}
function applyGrantFilter() { renderGrantGrid(); }
function toggleGrant(el) {
    var id = parseInt(el.getAttribute('data-id'), 10);
    var ix = grantSelected.indexOf(id);
    if (ix === -1) grantSelected.push(id); else grantSelected.splice(ix, 1);
    renderGrantGrid();
    renderGrantChips();
}
function renderGrantChips() {
    var h = '';
    for (var i = 0; i < grantSelected.length; i++) {
        var idx = -1;
        for (var j = 0; j < grantProducts.length; j++) if (grantProducts[j].id === grantSelected[i]) { idx = j; break; }
        if (idx === -1) continue;
        var p = grantProducts[idx];
        h += '<span style="display:inline-flex;align-items:center;gap:6px;background:rgba(var(--accent-rgb),.12);border:1px solid rgba(var(--accent-rgb),.3);color:#a5b4fc;border-radius:8px;padding:5px 10px;font-size:12px;font-weight:700;">';
        if (p.image) h += '<img src="' + p.image.replace(/"/g,'&quot;') + '" style="width:18px;height:18px;border-radius:4px;object-fit:cover;">';
        else h += '<i class="fa-solid fa-box-open" style="font-size:12px;"></i>';
        h += p.name.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
        h += '<button type="button" onclick="event.stopPropagation();removeGrant(' + p.id + ')" style="background:none;border:none;color:#f87171;cursor:pointer;font-size:12px;padding:0;line-height:1;"><i class="fa-solid fa-xmark"></i></button>';
        h += '</span>';
    }
    grantChips.innerHTML = h;
    grantHidden.value = grantSelected.join(',');
    grantCountSpan.textContent = '(' + grantSelected.length + ')';
}
function removeGrant(id) {
    var ix = grantSelected.indexOf(id);
    if (ix !== -1) grantSelected.splice(ix, 1);
    renderGrantGrid();
    renderGrantChips();
}
function openGrantPicker() {
    renderGrantGrid();
    renderGrantChips();
    grantModal.style.display = 'flex';
    document.getElementById('grantPickerSearch').value = '';
    setTimeout(function(){ document.getElementById('grantPickerSearch').focus(); }, 60);
}
function closeGrantPicker() { grantModal.style.display = 'none'; }

if (window.location.hash === '#create') {
    toggleForm();
}
</script>

<?php endif; ?>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
