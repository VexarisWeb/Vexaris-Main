<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.custom_css');
$activePage = 'custom-css';

$flash = $_GET['flash'] ?? '';
[$flashType, $flashText] = $flash ? explode(':', urldecode($flash), 2) + ['',''] : ['',''];

$customCss = '';
try {
    $st = $adminDb->prepare("SELECT `value` FROM settings WHERE `key`='custom_css' LIMIT 1");
    $st->execute();
    $customCss = (string)($st->fetchColumn() ?? '');
} catch (Throwable $e) { $customCss = ''; }

include __DIR__ . '/includes/layout.php';
?>

<?php if ($flashText): ?>
<div style="padding:12px 18px;border-radius:12px;font-size:13px;font-weight:700;margin-bottom:18px;display:flex;align-items:center;gap:8px;background:<?= $flashType==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;border:1px solid <?= $flashType==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;color:<?= $flashType==='success'?'#4ade80':'#f87171' ?>;">
    <i class="fa-solid fa-<?= $flashType==='success'?'circle-check':'circle-xmark' ?>"></i> <?= e($flashText) ?>
</div>
<?php endif; ?>

<div class="admin-card" style="margin-bottom:0;">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-code" style="color:var(--accent);margin-right:8px;"></i> <?= __('amenu.custom_css') ?></span>
        <span id="vxCssCount" style="font-size:11px;color:var(--muted);font-weight:700;"><?= strlen($customCss) ?> / 65535</span>
    </div>
    <form method="POST" action="/action.php">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="custom_css_save">
        <label style="font-size:11px;font-weight:800;color:var(--muted);display:block;margin-bottom:6px;letter-spacing:.3px;text-transform:uppercase;">Site Geneli CSS</label>
        <textarea name="custom_css" id="vxCustomCss" rows="18" spellcheck="false" maxlength="65535" placeholder="<?= __('acss.ph') ?>" style="width:100%;min-height:320px;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:12px 14px;color:var(--text);font-size:13px;line-height:1.7;outline:none;box-sizing:border-box;font-family:ui-monospace,Consolas,monospace;resize:vertical;white-space:pre-wrap;overflow-wrap:anywhere;" onfocus="this.style.borderColor='var(--accent)'" onblur="this.style.borderColor='var(--border)'"><?= e($customCss) ?></textarea>
        <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap;">
            <button type="submit" class="btn-admin btn-primary-admin" style="padding:11px 26px;font-size:13px;">
                <i class="fa-solid fa-floppy-disk"></i> <?= __('acss.save_publish') ?>
            </button>
            <button type="button" class="btn-admin btn-ghost-admin" style="padding:11px 20px;font-size:13px;" onclick="if(confirm(<?= json_encode(__('acss.delete_confirm')) ?>)){document.getElementById('vxCustomCss').value='';document.getElementById('vxCustomCss').form.submit();}">
                <i class="fa-solid fa-trash"></i> <?= __('acss.clear') ?>
            </button>
        </div>
        <div style="margin-top:12px;background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.18);border-radius:10px;padding:10px 12px;font-size:11px;color:var(--muted);line-height:1.6;">
            <i class="fa-solid fa-eye" style="color:var(--accent);"></i> <?= __('acss.desc') ?>
        </div>
    </form>
</div>

<script>
(function(){
    var ta = document.getElementById('vxCustomCss');
    var out = document.getElementById('vxCssCount');
    if (!ta || !out) return;
    var initial = ta.value;
    function upd(){ out.textContent = ta.value.length + ' / 65535'; }
    ta.addEventListener('input', upd);
    ta.addEventListener('keydown', function(e){
        if (e.key === 'Tab') {
            e.preventDefault();
            var s = ta.selectionStart, en = ta.selectionEnd;
            ta.value = ta.value.slice(0, s) + '  ' + ta.value.slice(en);
            ta.selectionStart = ta.selectionEnd = s + 2;
            upd();
        }
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
            e.preventDefault();
            try { localStorage.removeItem('vx_css_draft'); } catch (err) {}
            ta.form.submit();
        }
    });
    try {
        var draft = localStorage.getItem('vx_css_draft');
        if (draft !== null && draft !== initial && draft !== '') {
            ta.value = draft;
            if (window.showToast) showToast(<?= json_encode(__('acss.draft_restored')) ?>, true);
        }
        var saveT = null;
        ta.addEventListener('input', function(){
            clearTimeout(saveT);
            saveT = setTimeout(function(){
                try {
                    if (ta.value !== initial) localStorage.setItem('vx_css_draft', ta.value);
                    else localStorage.removeItem('vx_css_draft');
                } catch (err) {}
            }, 1500);
        });
        ta.form.addEventListener('submit', function(){
            try { localStorage.removeItem('vx_css_draft'); } catch (err) {}
        });
        window.addEventListener('beforeunload', function(e){
            if (ta.value !== initial) {
                e.preventDefault();
                e.returnValue = <?= json_encode(__('acss.unsaved')) ?>;
            }
        });
    } catch (err) {}
    upd();
})();
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
