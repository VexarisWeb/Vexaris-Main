<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.custom_pages');
$activePage = 'custom-pages';

$db   = $adminDb;
$msg  = '';
$flash = $_GET['flash'] ?? '';
if ($flash) {
    $flashParts = array_pad(explode(':', $flash, 2), 2, '');
    if ($flashParts[0] === 'error') $msg = ['type' => 'error', 'text' => $flashParts[1]];
    else $msg = ['type' => 'success', 'text' => $flashParts[1]];
}

function custom_page_slug_valid(string $slug): bool {
    return (bool)preg_match('/^[a-z0-9][a-z0-9\-]{0,138}$/', $slug);
}

function custom_page_file_path(string $slug): string {
    return ROOT_PATH . '/pages/' . $slug . '.php';
}

function custom_page_path_allowed(string $slug): bool {
    if (!custom_page_slug_valid($slug)) return false;
    $base = realpath(ROOT_PATH . '/pages');
    if ($base === false) return false;
    $path = custom_page_file_path($slug);
    $dir  = realpath(dirname($path));
    if ($dir === false) return false;
    return strncmp($dir . DIRECTORY_SEPARATOR, $base . DIRECTORY_SEPARATOR, strlen($base) + 1) === 0;
}

function custom_page_write_file(string $slug): bool {
    if (!custom_page_path_allowed($slug)) return false;
    $dir = ROOT_PATH . '/pages';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) return false;
    $stub = "<?php\nrequire dirname(__DIR__) . '/core/init.php';\n\$GLOBALS['custom_page_slug'] = " . var_export($slug, true) . ";\ntheme_load('custom-page');\n";
    return @file_put_contents(custom_page_file_path($slug), $stub) !== false;
}

function custom_page_delete_file(string $slug): void {
    if (!custom_page_path_allowed($slug)) return;
    $f = custom_page_file_path($slug);
    if (is_file($f)) @unlink($f);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['save_custom_page'])) {
        $id      = (int)($_POST['page_id'] ?? 0);
        $title   = trim($_POST['title'] ?? '');
        $meta    = trim($_POST['meta_description'] ?? '');
        $pageType = (($_POST['page_type'] ?? 'blog') === 'html') ? 'html' : 'blog';
        if ($pageType === 'html') {
            $content = trim($_POST['content_html'] ?? '');
            if (strlen($content) > 1000000) $content = substr($content, 0, 1000000);
        } else {
            $content = nx_clean_html($_POST['content'] ?? '', 'rich');
        }
        $status  = (($_POST['status'] ?? 'published') === 'draft') ? 'draft' : 'published';
        $slug    = strtolower(trim($_POST['slug'] ?? ''));
        if ($title === '') {
            header('Location: /admin/custom-pages.php?view=' . ($id > 0 ? 'edit&edit=' . $id : 'new') . '&flash=' . urlencode('error:' . __('apage.err_title_required')));
            exit;
        }
        if ($slug === '') {
            $slug = preg_replace('/[^a-z0-9]+/', '-', strtolower($title));
            $slug = trim($slug, '-');
        }
        if ($slug === '') $slug = 'sayfa';
        if (!custom_page_slug_valid($slug) || !custom_page_path_allowed($slug)) {
            header('Location: /admin/custom-pages.php?view=' . ($id > 0 ? 'edit&edit=' . $id : 'new') . '&flash=' . urlencode('error:' . __('apage.err_slug_taken')));
            exit;
        }
        $oldSlug = '';
        try {
            if ($id > 0) {
                $os = $db->prepare('SELECT slug FROM custom_pages WHERE id=?');
                $os->execute([$id]);
                $oldSlug = (string)$os->fetchColumn();
                $ck = $db->prepare('SELECT id FROM custom_pages WHERE slug=? AND id<>? LIMIT 1');
                $ck->execute([$slug, $id]);
                if ($ck->fetch()) {
                    header('Location: /admin/custom-pages.php?view=edit&edit=' . $id . '&flash=' . urlencode('error:' . __('apage.err_slug_taken')));
                    exit;
                }
                $db->prepare('UPDATE custom_pages SET title=?,slug=?,meta_description=?,content=?,status=?,page_type=? WHERE id=?')
                   ->execute([$title, $slug, $meta !== '' ? $meta : null, $content, $status, $pageType, $id]);
            } else {
                $baseSlug = $slug;
                $suffix   = 1;
                while (true) {
                    $ck = $db->prepare('SELECT id FROM custom_pages WHERE slug=? LIMIT 1');
                    $ck->execute([$slug]);
                    if (!$ck->fetch()) break;
                    $slug = $baseSlug . '-' . $suffix++;
                }
                $db->prepare('INSERT INTO custom_pages (slug,title,meta_description,content,status,page_type) VALUES (?,?,?,?,?,?)')
                   ->execute([$slug, $title, $meta !== '' ? $meta : null, $content, $status, $pageType]);
            }
            if ($id > 0) $savedId = $id;
            else {
                try { $savedId = (int)$db->lastInsertId(); } catch (\PDOException $e) { $savedId = 0; }
            }
            if (!custom_page_write_file($slug)) {
                error_log('[NS] custom_pages file write: ' . custom_page_file_path($slug));
                header('Location: /admin/custom-pages.php?flash=' . urlencode('error:' . __('apage.err_file_write')));
                exit;
            }
            audit_log($db, 'update', 'custom_pages', $savedId, $title, '/pages/' . $slug . '.php');
            if ($oldSlug !== '' && $oldSlug !== $slug) custom_page_delete_file($oldSlug);
            header('Location: /admin/custom-pages.php?flash=' . urlencode('success:' . __('apage.ok_saved')));
            exit;
        } catch (\PDOException $e) {
            error_log('[NS] custom_pages save: ' . $e->getMessage());
            header('Location: /admin/custom-pages.php?flash=' . urlencode('error:' . __('apage.err_save_fail')));
            exit;
        }
    }

    if (isset($_POST['delete_custom_page'])) {
        $id = (int)($_POST['page_id'] ?? 0);
        $delSlug = '';
        try {
            $ds = $db->prepare('SELECT slug FROM custom_pages WHERE id=?');
            $ds->execute([$id]);
            $delSlug = (string)$ds->fetchColumn();
            $db->prepare('DELETE FROM custom_pages WHERE id=?')->execute([$id]);
            if ($delSlug !== '') custom_page_delete_file($delSlug);
            audit_log($db, 'delete', 'custom_pages', $id, $delSlug !== '' ? $delSlug : '#' . $id, '/admin/custom-pages.php');
            header('Location: /admin/custom-pages.php?flash=' . urlencode('success:' . __('apage.ok_deleted')));
        } catch (\PDOException $e) {
            error_log('[NS] custom_pages delete: ' . $e->getMessage());
            header('Location: /admin/custom-pages.php?flash=' . urlencode('error:' . __('apage.err_delete_fail')));
        }
        exit;
    }
}

$editId   = (int)($_GET['edit'] ?? 0);
$statsId  = (int)($_GET['stats'] ?? 0);
if (isset($_GET['new'])) $view = 'new';
elseif ($editId > 0) $view = 'edit';
elseif ($statsId > 0) $view = 'stats';
else $view = 'list';

$pages = [];
try {
    $pages = $db->query('SELECT cp.*, (SELECT COUNT(DISTINCT v.ip) FROM custom_page_views v WHERE v.page_id=cp.id) AS view_count FROM custom_pages cp ORDER BY cp.updated_at DESC')->fetchAll();
} catch (\PDOException $e) {
    error_log('[NS] custom_pages list: ' . $e->getMessage());
}

$curPage = null;
if ($view === 'edit' && $editId > 0) {
    try {
        $st = $db->prepare('SELECT * FROM custom_pages WHERE id=? LIMIT 1');
        $st->execute([$editId]);
        $curPage = $st->fetch() ?: null;
    } catch (\PDOException $e) {
        error_log('[NS] custom_pages edit: ' . $e->getMessage());
    }
    if (!$curPage) $view = 'list';
}

$stats = null;
$daily = [];
$recent = [];
if ($view === 'stats' && $statsId > 0) {
    try {
        $st = $db->prepare('SELECT * FROM custom_pages WHERE id=? LIMIT 1');
        $st->execute([$statsId]);
        $stats = $st->fetch() ?: null;
        if ($stats) {
            $sv = $db->prepare('SELECT COUNT(DISTINCT ip) FROM custom_page_views WHERE page_id=?');
            $sv->execute([$statsId]);
            $stats['views'] = (int)$sv->fetchColumn();
            $stAll = $db->prepare('SELECT COUNT(*) FROM custom_page_views WHERE page_id=?');
            $stAll->execute([$statsId]);
            $stats['all_views'] = (int)$stAll->fetchColumn();
            $sa = $db->prepare('SELECT COALESCE(AVG(d),0) FROM (SELECT MAX(duration_sec) AS d FROM custom_page_views WHERE page_id=? AND duration_sec>0 GROUP BY ip) t');
            $sa->execute([$statsId]);
            $stats['avg_duration'] = round((float)$sa->fetchColumn(), 1);
            $sd = $db->prepare('SELECT DATE(entered_at) AS d, COUNT(DISTINCT ip) AS c FROM custom_page_views WHERE page_id=? AND entered_at >= DATE_SUB(CURDATE(), INTERVAL 13 DAY) GROUP BY DATE(entered_at) ORDER BY d ASC');
            $sd->execute([$statsId]);
            $daily = $sd->fetchAll();
            $sr = $db->prepare('SELECT ip, MAX(user_id) AS user_id, MAX(entered_at) AS entered_at, MAX(duration_sec) AS duration_sec FROM custom_page_views WHERE page_id=? GROUP BY ip ORDER BY entered_at DESC LIMIT 10');
            $sr->execute([$statsId]);
            $recent = $sr->fetchAll();
        }
    } catch (\PDOException $e) {
        error_log('[NS] custom_pages stats: ' . $e->getMessage());
    }
    if (!$stats) $view = 'list';
}

function fmt_duration(float $sec): string {
    if ($sec <= 0) return '—';
    if ($sec < 60) return rtrim(rtrim(number_format($sec, 1, ',', '.'), '0'), ',') . __('apage.sec_suffix');
    $m = floor($sec / 60);
    $s = round($sec - $m * 60);
    return $m . __('apage.min_suffix') . $s . __('apage.sec_suffix');
}

include __DIR__ . '/includes/layout.php';
?>
<style>.ed-wrap{border-radius:0!important;border-left:none!important;border-right:none!important;}</style>

<?php if ($msg): ?>
<div style="background:<?= $msg['type'] === 'error' ? 'rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#f87171;' : 'rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#4ade80;' ?>;padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid <?= $msg['type'] === 'error' ? 'fa-circle-xmark' : 'fa-circle-check' ?>"></i> <?= e($msg['text']) ?>
</div>
<?php endif; ?>

<?php if ($view === 'edit' || $view === 'new'): ?>

<?php
$isEdit = $view === 'edit' && $curPage;
$formTitle = $isEdit ? $curPage['title'] : '';
$formSlug  = $isEdit ? $curPage['slug'] : '';
$formMeta  = $isEdit ? ($curPage['meta_description'] ?? '') : '';
$formContent = $isEdit ? ($curPage['content'] ?? '') : '';
$formStatus  = $isEdit ? $curPage['status'] : 'published';
$formType    = $isEdit ? (($curPage['page_type'] ?? 'blog') === 'html' ? 'html' : 'blog') : 'blog';
?>
<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-file-pen" style="color:var(--accent);margin-right:8px;"></i><?= $isEdit ? __('apage.edit_page') : __('apage.new_create') ?></span>
        <a href="/admin/custom-pages.php" class="btn-admin btn-ghost-admin">
            <i class="fa-solid fa-arrow-left"></i> <?= __('apage.back_list') ?>
        </a>
    </div>

    <form method="POST" onsubmit="var tb=document.getElementById('pageEditor');var bd=document.getElementById('edBody-pageEditor');if(tb&&bd)tb.value=bd.innerHTML;">
        <?= csrf_field() ?>
        <input type="hidden" name="save_custom_page" value="1">
        <input type="hidden" name="page_id" value="<?= $isEdit ? (int)$curPage['id'] : 0 ?>">

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('apage.field_title') ?></label>
                <input type="text" name="title" id="cpTitle" maxlength="120" required
                       value="<?= e($formTitle) ?>"
                       placeholder="<?= __('apage.ph_title') ?>"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
            </div>
            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('apage.field_slug') ?></label>
                <input type="text" name="slug" id="cpSlug" maxlength="140"
                       value="<?= e($formSlug) ?>"
                       placeholder="<?= $isEdit ? '' : __('apage.ph_slug') ?>"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                <p style="font-size:11px;color:var(--muted);margin-top:5px;"><i class="fa-solid fa-info-circle"></i> <?= __('apage.address') ?>: <code>/pages/<?= e($formSlug !== '' ? $formSlug : 'slug') ?>.php</code></p>
            </div>
        </div>

        <div style="margin-top:18px;">
            <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('apage.field_meta') ?></label>
            <textarea name="meta_description" maxlength="300" rows="2"
                      placeholder="<?= __('apage.ph_meta') ?>"
                      style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;resize:vertical;font-family:inherit;"><?= e($formMeta) ?></textarea>
        </div>

        <div style="margin-top:18px;display:grid;grid-template-columns:1fr 1fr;gap:20px;">
            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('adash.th_status') ?></label>
                <select name="status" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <option value="published" <?= $formStatus === 'published' ? 'selected' : '' ?>><?= __('apedit.status_live') ?></option>
                    <option value="draft" <?= $formStatus === 'draft' ? 'selected' : '' ?>><?= __('adash.status_draft') ?></option>
                </select>
            </div>
            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('apage.field_type') ?></label>
                <select name="page_type" id="cpType" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <option value="blog" <?= $formType === 'blog' ? 'selected' : '' ?>><?= __('apage.type_blog') ?></option>
                    <option value="html" <?= $formType === 'html' ? 'selected' : '' ?>><?= __('apage.type_html') ?></option>
                </select>
                <p style="font-size:11px;color:var(--muted);margin-top:5px;"><i class="fa-solid fa-info-circle"></i> <?= __('apage.type_hint') ?></p>
            </div>
        </div>

        <?php require_once ROOT_PATH . '/core/editor.php'; ?>
        <div id="cpBlogWrap" style="border:1px solid var(--border);border-radius:10px;overflow:hidden;margin-top:18px;<?= $formType === 'html' ? 'display:none;' : '' ?>">
            <?php if ($formType !== 'html') render_editor('pageEditor', $formContent, '450px', 'content'); else render_editor('pageEditor', '', '450px', 'content'); ?>
        </div>
        <div id="cpHtmlWrap" style="margin-top:18px;<?= $formType === 'html' ? '' : 'display:none;' ?>">
            <textarea name="content_html" id="cpHtml" rows="22" spellcheck="false"
                      placeholder="<?= __('apage.html_ph') ?>"
                      style="width:100%;min-height:420px;background:#0b0f17;border:1px solid var(--border);border-radius:10px;padding:12px 14px;color:#e8eaf6;font-size:13px;line-height:1.7;outline:none;box-sizing:border-box;font-family:ui-monospace,Consolas,monospace;resize:vertical;white-space:pre;overflow-wrap:normal;overflow-x:auto;"><?= e($formType === 'html' ? $formContent : '') ?></textarea>
            <p style="font-size:11px;color:var(--muted);margin-top:6px;"><i class="fa-solid fa-triangle-exclamation" style="color:#facc15;"></i> <?= __('apage.html_hint') ?></p>
        </div>

        <div style="display:flex;gap:8px;margin-top:16px;">
            <button type="submit" class="btn-admin btn-primary-admin">
                <i class="fa-solid fa-floppy-disk"></i> <?= $isEdit ? __('msg.save') : __('apage.create_page') ?>
            </button>
            <?php if ($isEdit): ?>
            <a href="/pages/<?= urlencode($curPage['slug']) ?>.php" target="_blank" class="btn-admin btn-ghost-admin">
                <i class="fa-solid fa-eye"></i> <?= __('apage.preview') ?>
            </a>
            <a href="/admin/custom-pages.php?stats=<?= (int)$curPage['id'] ?>" class="btn-admin btn-ghost-admin">
                <i class="fa-solid fa-chart-column"></i> <?= __('apage.stats') ?>
            </a>
            <?php endif; ?>
        </div>
    </form>
</div>

<script>
(function(){
    var title = document.getElementById('cpTitle');
    var slug  = document.getElementById('cpSlug');
    if (title && slug && slug.value.trim() === '') {
        title.addEventListener('input', function(){
            var s = title.value.toLowerCase()
                .replace(/[^a-z0-9çğıöşü]+/gi, '-')
                .replace(/ç/g,'c').replace(/ğ/g,'g').replace(/ı/g,'i')
                .replace(/ö/g,'o').replace(/ş/g,'s').replace(/ü/g,'u')
                .replace(/^-+|-+$/g, '');
            slug.value = s;
        });
    }
    var type = document.getElementById('cpType');
    var blogWrap = document.getElementById('cpBlogWrap');
    var htmlWrap = document.getElementById('cpHtmlWrap');
    function blogHtml(){
        var bd = document.getElementById('edBody-pageEditor');
        return bd ? bd.innerHTML : '';
    }
    function setBlogHtml(h){
        var bd = document.getElementById('edBody-pageEditor');
        if (bd) bd.innerHTML = h;
    }
    function applyType(){
        var isHtml = type && type.value === 'html';
        var ta = document.getElementById('cpHtml');
        if (isHtml && ta && ta.value.trim() === '') {
            var h = blogHtml();
            if (h.replace(/<[^>]+>/g, '').trim() !== '') ta.value = h;
        }
        if (!isHtml) {
            var v = ta ? ta.value : '';
            if (v.trim() !== '' && blogHtml().replace(/<[^>]+>/g, '').trim() === '') setBlogHtml(v);
        }
        if (blogWrap) blogWrap.style.display = isHtml ? 'none' : '';
        if (htmlWrap) htmlWrap.style.display = isHtml ? '' : 'none';
    }
    if (type) type.addEventListener('change', applyType);
    applyType();
    var htmlTa = document.getElementById('cpHtml');
    if (htmlTa) htmlTa.addEventListener('keydown', function(e){
        if (e.key === 'Tab') {
            e.preventDefault();
            var s = htmlTa.selectionStart, en = htmlTa.selectionEnd;
            htmlTa.value = htmlTa.value.slice(0, s) + '  ' + htmlTa.value.slice(en);
            htmlTa.selectionStart = htmlTa.selectionEnd = s + 2;
        }
    });
})();
</script>

<?php elseif ($view === 'stats' && $stats): ?>

<?php
$maxDay = 1;
foreach ($daily as $dd) $maxDay = max($maxDay, (int)$dd['c']);
$daySeries = [];
for ($i = 13; $i >= 0; $i--) {
    $daySeries[date('Y-m-d', strtotime('-' . $i . ' days'))] = ['c' => 0];
}
foreach ($daily as $dd) {
    if (isset($daySeries[$dd['d']])) $daySeries[$dd['d']]['c'] = (int)$dd['c'];
}
$daily = [];
foreach ($daySeries as $dd => $cc) {
    $daily[] = ['d' => $dd, 'c' => $cc['c']];
}
$maxDay = 1;
foreach ($daily as $dd) $maxDay = max($maxDay, (int)$dd['c']);
?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-chart-column" style="color:#22d3ee;margin-right:8px;"></i><?= __('apage.stats') ?> — <?= e($stats['title']) ?></span>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <a href="/admin/custom-pages.php" class="btn-admin btn-ghost-admin">
                <i class="fa-solid fa-arrow-left"></i> <?= __('apage.back_list') ?>
            </a>
            <a href="/admin/custom-pages.php?edit=<?= (int)$stats['id'] ?>" class="btn-admin btn-ghost-admin">
                <i class="fa-solid fa-pen"></i> <?= __('apage.edit_page') ?>
            </a>
            <a href="/pages/<?= urlencode($stats['slug']) ?>.php" target="_blank" class="btn-admin btn-primary-admin">
                <i class="fa-solid fa-eye"></i> <?= __('apage.view') ?>
            </a>
        </div>
    </div>

    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:18px;">
        <span class="badge <?= ($stats['status'] ?? '') === 'published' ? 'badge-green' : 'badge-yellow' ?>"><i class="fa-solid fa-circle"></i> <?= ($stats['status'] ?? '') === 'published' ? __('apedit.status_live') : __('adash.status_draft') ?></span>
        <span class="badge badge-indigo"><i class="fa-solid <?= (($stats['page_type'] ?? 'blog') === 'html') ? 'fa-code' : 'fa-file-lines' ?>"></i> <?= (($stats['page_type'] ?? 'blog') === 'html') ? __('apage.type_html') : __('apage.type_blog') ?></span>
        <a href="/pages/<?= urlencode($stats['slug']) ?>.php" target="_blank" style="font-size:11px;color:var(--muted);"><i class="fa-solid fa-link"></i> <code>/pages/<?= e($stats['slug']) ?>.php</code></a>
        <span style="font-size:11px;color:var(--muted);"><?= __('page.updated') ?> <?= e($stats['updated_at'] ?? '') ?></span>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:20px;">
        <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;padding:18px;">
            <div style="font-size:11px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px;"><i class="fa-solid fa-eye" style="margin-right:5px;color:#22d3ee;"></i><?= __('apage.unique_visits') ?></div>
            <div style="font-size:26px;font-weight:900;"><?= number_format($stats['views']) ?></div>
            <div style="font-size:10px;color:var(--muted);margin-top:4px;"><?= __('apage.unique_hint') ?></div>
        </div>
        <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;padding:18px;">
            <div style="font-size:11px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px;"><i class="fa-solid fa-clock" style="margin-right:5px;color:#fbc853;"></i><?= __('apage.avg_duration') ?></div>
            <div style="font-size:26px;font-weight:900;"><?= e(fmt_duration((float)$stats['avg_duration'])) ?></div>
            <div style="font-size:10px;color:var(--muted);margin-top:4px;"><?= __('apage.per_ip') ?></div>
        </div>
        <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;padding:18px;">
            <div style="font-size:11px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px;"><i class="fa-solid fa-rotate" style="margin-right:5px;color:#818cf8;"></i><?= __('apage.all_loads') ?></div>
            <div style="font-size:26px;font-weight:900;"><?= number_format($stats['all_views']) ?></div>
            <div style="font-size:10px;color:var(--muted);margin-top:4px;"><?= __('apage.all_loads_hint') ?></div>
        </div>
    </div>

    <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;padding:18px;margin-bottom:20px;">
        <div style="font-size:12px;font-weight:800;margin-bottom:16px;"><i class="fa-solid fa-calendar-days" style="color:#22d3ee;margin-right:6px;"></i><?= __('apage.last14') ?></div>
        <?php if ($daily): ?>
        <div style="display:flex;align-items:flex-end;gap:6px;height:120px;">
            <?php foreach ($daily as $dd): ?>
            <?php $has = (int)$dd['c'] > 0; $h = $has ? max(10, round(((int)$dd['c']) / $maxDay * 100)) : 4; ?>
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;gap:6px;" title="<?= e($dd['d']) ?>: <?= (int)$dd['c'] ?> <?= __('apage.visits') ?>">
                <div style="width:100%;background:<?= $has ? 'linear-gradient(180deg,#22d3ee,#0891b2)' : 'rgba(255,255,255,.06)' ?>;border-radius:5px 5px 2px 2px;height:<?= $h ?>%;min-height:<?= $h ?>px;transition:opacity .2s;" onmouseover="this.style.opacity='.7'" onmouseout="this.style.opacity='1'"></div>
                <div style="font-size:9px;color:var(--muted);font-weight:600;"><?= htmlspecialchars(date('d/m', strtotime($dd['d']))) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <p style="font-size:12px;color:var(--muted);"><?= __('apage.last14_empty') ?></p>
        <?php endif; ?>
    </div>

    <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;padding:18px;">
        <div style="font-size:12px;font-weight:800;margin-bottom:12px;"><i class="fa-solid fa-list" style="color:#818cf8;margin-right:6px;"></i><?= __('apage.recent_visits') ?></div>
        <?php if ($recent): ?>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>IP</th>
                    <th><?= __('apage.col_visit') ?></th>
                    <th><?= __('apage.col_visitor') ?></th>
                    <th><?= __('apage.col_duration') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent as $rv): ?>
                <tr>
                    <td><?= e($rv['ip'] ?: '—') ?></td>
                    <td><?= e($rv['entered_at']) ?></td>
                    <td><?= $rv['user_id'] ? ('<span class="badge badge-indigo">' . __('apage.member_prefix') . ' #' . (int)$rv['user_id'] . '</span>') : '<span class="badge">' . __('apage.guest') . '</span>' ?></td>
                    <td><?= e(fmt_duration((float)$rv['duration_sec'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p style="font-size:12px;color:var(--muted);"><?= __('apage.no_records') ?></p>
        <?php endif; ?>
    </div>
</div>

<?php else: ?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-file-lines" style="color:var(--accent);margin-right:8px;"></i><?= __('amenu.custom_pages') ?></span>
        <a href="/admin/custom-pages.php?new=1" class="btn-admin btn-primary-admin">
            <i class="fa-solid fa-plus"></i> <?= __('apage.new_create') ?>
        </a>
    </div>

    <?php if ($pages): ?>
    <table class="admin-table">
        <thead>
            <tr>
                <th><?= __('apage.col_page') ?></th>
                <th><?= __('apage.field_type') ?></th>
                <th><?= __('adash.th_status') ?></th>
                <th><?= __('apage.col_unique') ?></th>
                <th><?= __('apage.col_updated') ?></th>
                <th><?= __('apage.col_actions') ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($pages as $pg): ?>
            <tr>
                <td>
                    <a href="/pages/<?= urlencode($pg['slug']) ?>.php" target="_blank" style="font-weight:800;color:var(--text);">
                        <i class="fa-solid fa-file-lines" style="color:var(--accent);margin-right:6px;"></i><?= e($pg['title']) ?>
                    </a>
                    <div style="font-size:10px;color:var(--muted);margin-top:2px;"><code>/pages/<?= e($pg['slug']) ?>.php</code></div>
                </td>
                <td>
                    <?php if (($pg['page_type'] ?? 'blog') === 'html'): ?>
                    <span class="badge badge-indigo"><i class="fa-solid fa-code"></i> <?= __('apage.type_html') ?></span>
                    <?php else: ?>
                    <span class="badge"><i class="fa-solid fa-file-lines"></i> <?= __('apage.type_blog') ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($pg['status'] === 'published'): ?>
                    <span class="badge badge-green"><i class="fa-solid fa-circle"></i> <?= __('apedit.status_live') ?></span>
                    <?php else: ?>
                    <span class="badge badge-yellow"><i class="fa-solid fa-circle"></i> <?= __('adash.status_draft') ?></span>
                    <?php endif; ?>
                </td>
                <td style="font-weight:800;"><?= number_format((int)$pg['view_count']) ?></td>
                <td style="font-size:11px;color:var(--muted);"><?= e($pg['updated_at']) ?></td>
                <td>
                    <div style="display:flex;gap:6px;">
                        <a href="/admin/custom-pages.php?stats=<?= (int)$pg['id'] ?>" class="btn-admin btn-ghost-admin" style="padding:6px 10px;font-size:11px;" title="<?= __('apage.stats') ?>">
                            <i class="fa-solid fa-chart-column"></i>
                        </a>
                        <a href="/admin/custom-pages.php?edit=<?= (int)$pg['id'] ?>" class="btn-admin btn-ghost-admin" style="padding:6px 10px;font-size:11px;" title="<?= __('product.edit') ?>">
                            <i class="fa-solid fa-pen"></i>
                        </a>
                        <form method="POST" style="display:inline;" onsubmit="return confirm(<?= json_encode(__('apage.delete_confirm')) ?>);">
                            <?= csrf_field() ?>
                            <input type="hidden" name="delete_custom_page" value="1">
                            <input type="hidden" name="page_id" value="<?= (int)$pg['id'] ?>">
                            <button type="submit" class="btn-admin" style="padding:6px 10px;font-size:11px;background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2);" title="<?= __('product.delete') ?>">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
    <div style="text-align:center;padding:60px 20px;">
        <div style="font-size:44px;margin-bottom:14px;"><i class="fa-solid fa-file-circle-plus" style="color:var(--dim);"></i></div>
        <p style="font-size:14px;font-weight:800;margin-bottom:6px;"><?= __('apage.empty_title') ?></p>
        <p style="font-size:12px;color:var(--muted);margin-bottom:20px;"><?= __('apage.empty_hint') ?></p>
        <a href="/admin/custom-pages.php?new=1" class="btn-admin btn-primary-admin">
            <i class="fa-solid fa-plus"></i> <?= __('apage.new_create') ?>
        </a>
    </div>
    <?php endif; ?>
</div>

<?php endif; ?>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
