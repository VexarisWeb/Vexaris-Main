<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.dashboard');
$activePage = 'dashboard';

$totalRevenue   = 0.00;
$totalSales     = 0;
$totalCustomers = 0;
$totalProducts  = 0;
$totalLicenses  = 0;
$totalTickets   = 0;
$totalCoupons   = 0;
$salesToday     = 0;
$customersToday = 0;
$revenueToday   = 0.00;
$revenueMonth   = 0.00;
$salesMonth     = 0;
$customersMonth = 0;
$revenueLastMonth   = 0.00;
$salesLastMonth     = 0;
$customersLastMonth = 0;
$recentSales    = [];
$topProducts    = [];
$recentUsers    = [];
$allProducts    = [];
$pendingTickets = 0;
$activeLicenses = 0;
$planCur = ['slug' => 'free', 'product_limit' => 7, 'revenue_limit_usd' => 100.0, 'revenue_reset' => 'never'];
$planPCount = 0;
$planPLim = 7;
$planRevSum = 0.0;
$planRevLim = 100.0;
$planRevState = 'ok';
$planStoreCur = 'TRY';
$planRevLimStore = 100.0;
$planFxStale = false;
$planProdFull = false;

function pctChange($cur, $prev): string {
    if ($prev <= 0) return $cur > 0 ? '+100' : '0';
    return (($cur - $prev) / $prev * 100 >= 0 ? '+' : '') . number_format(($cur - $prev) / $prev * 100, 1);
}

if ($adminDb) {
    $r = $adminDb->query('SELECT COALESCE(SUM(total_amount),0) FROM payment_intents WHERE status="completed"')->fetchColumn();
    $totalRevenue = (float)$r;
    $totalSales = (int)$adminDb->query('SELECT COUNT(*) FROM sales')->fetchColumn();
    $totalCustomers = (int)$adminDb->query('SELECT COUNT(*) FROM users WHERE role="user"')->fetchColumn();
    $totalProducts = (int)$adminDb->query('SELECT COUNT(*) FROM products')->fetchColumn();
    $totalLicenses = (int)$adminDb->query('SELECT COUNT(*) FROM licenses')->fetchColumn();
    $totalTickets = (int)$adminDb->query('SELECT COUNT(*) FROM tickets')->fetchColumn();
    $totalCoupons = (int)$adminDb->query('SELECT COUNT(*) FROM coupons')->fetchColumn();
    $pendingTickets = (int)$adminDb->query("SELECT COUNT(*) FROM tickets WHERE status='open'")->fetchColumn();
    $activeLicenses = (int)$adminDb->query("SELECT COUNT(*) FROM licenses WHERE status='active'")->fetchColumn();

    $salesToday = (int)$adminDb->query("SELECT COUNT(*) FROM sales WHERE DATE(purchased_at)=CURDATE()")->fetchColumn();
    $revenueToday = (float)$adminDb->query("SELECT COALESCE(SUM(total_amount),0) FROM payment_intents WHERE status='completed' AND DATE(updated_at)=CURDATE()")->fetchColumn();
    $customersToday = (int)$adminDb->query("SELECT COUNT(*) FROM users WHERE role='user' AND DATE(created_at)=CURDATE()")->fetchColumn();

    $revenueMonth = (float)$adminDb->query("SELECT COALESCE(SUM(total_amount),0) FROM payment_intents WHERE status='completed' AND MONTH(updated_at)=MONTH(CURDATE()) AND YEAR(updated_at)=YEAR(CURDATE())")->fetchColumn();
    $salesMonth = (int)$adminDb->query("SELECT COUNT(*) FROM sales WHERE MONTH(purchased_at)=MONTH(CURDATE()) AND YEAR(purchased_at)=YEAR(CURDATE())")->fetchColumn();
    $customersMonth = (int)$adminDb->query("SELECT COUNT(*) FROM users WHERE role='user' AND MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())")->fetchColumn();

    $revenueLastMonth = (float)$adminDb->query("SELECT COALESCE(SUM(total_amount),0) FROM payment_intents WHERE status='completed' AND MONTH(updated_at)=MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(updated_at)=YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))")->fetchColumn();
    $salesLastMonth = (int)$adminDb->query("SELECT COUNT(*) FROM sales WHERE MONTH(purchased_at)=MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(purchased_at)=YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))")->fetchColumn();
    $customersLastMonth = (int)$adminDb->query("SELECT COUNT(*) FROM users WHERE role='user' AND MONTH(created_at)=MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(created_at)=YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))")->fetchColumn();

    $recentSales = $adminDb->query(
        'SELECT s.id, s.price_paid, s.purchased_at, u.username, u.avatar, p.name AS product_name
         FROM sales s
         JOIN users u ON u.id = s.user_id
         JOIN products p ON p.id = s.product_id
         ORDER BY s.purchased_at DESC LIMIT 6'
    )->fetchAll();

    $topProducts = $adminDb->query(
        'SELECT p.id, p.name, p.category, p.status, COUNT(s.id) AS sale_count
         FROM products p LEFT JOIN sales s ON s.product_id=p.id
         GROUP BY p.id ORDER BY sale_count DESC, p.created_at DESC LIMIT 5'
    )->fetchAll();

    $recentUsers = $adminDb->query(
        'SELECT id, username, avatar, created_at FROM users WHERE role="user" ORDER BY created_at DESC LIMIT 4'
    )->fetchAll();

    $allProducts = $adminDb->query('SELECT id, name, category, status FROM products ORDER BY created_at DESC LIMIT 5')->fetchAll();

    $payNames = ['shopier'=>'Shopier','paytr'=>'PayTR','iyzico'=>'iyzico','stripe'=>'Stripe','paypal'=>'PayPal','bitpay'=>'BitPay','crypt'=>'Kripto','paywant'=>'Paywant','whop'=>'Whop','paddle'=>'Paddle','lemonsqueezy'=>'Lemon Squeezy','dodopayments'=>'DodoPayments'];
    $activePaySt = $adminDb->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_%_active'")->fetchAll();
    $activePays = [];
    foreach ($activePaySt as $row) {
        $slug = preg_replace('/^payment_(.+)_active$/','$1',$row['key']);
        if (($row['value'] ?? '0') === '1') $activePays[] = $payNames[$slug] ?? ucfirst($slug);
    }
    $activePayLabel = $activePays ? implode(' + ', $activePays) : __('adash.all_pays');

    $chartData = $adminDb->query(
        "SELECT DATE(updated_at) as day, COALESCE(SUM(total_amount),0) as rev, COUNT(*) as cnt
         FROM payment_intents WHERE status='completed' AND updated_at >= DATE_SUB(CURDATE(), INTERVAL 13 DAY)
         GROUP BY day ORDER BY day ASC"
    )->fetchAll();

    $planCur = function_exists('plan_current') ? plan_current() : ['slug' => 'free', 'product_limit' => 7, 'revenue_limit_usd' => 100.0, 'revenue_reset' => 'never'];
    $planPCount = function_exists('plan_product_count') ? plan_product_count($adminDb) : $totalProducts;
    $planPLim = (int)($planCur['product_limit'] ?? 7);
    $planRevSum = function_exists('plan_revenue_sum') ? plan_revenue_sum($adminDb) : 0.0;
    $planRevLim = (float)($planCur['revenue_limit_usd'] ?? 100.0);
    $planRevState = function_exists('plan_revenue_state') ? plan_revenue_state($adminDb) : 'ok';
    $planStoreCur = function_exists('store_currency') ? store_currency() : 'TRY';
    $planRevLimStore = $planRevLim >= 0 && function_exists('fx_convert') ? (float)fx_convert($planRevLim, 'USD', $planStoreCur) : $planRevLim;
    $planFxStale = function_exists('fx_is_stale') ? fx_is_stale() : false;
    $planProdFull = ($planPLim >= 0 && $planPCount >= $planPLim);
}

$chartLabels = [];
$chartRevenue = [];
$chartSales = [];
$today = new DateTime();
for ($i = 13; $i >= 0; $i--) {
    $d = (clone $today)->modify("-{$i} days")->format('Y-m-d');
    $chartLabels[] = tr_date('d M', (clone $today)->modify("-{$i} days")->getTimestamp());
    $foundRev = 0.0;
    $foundCnt = 0;
    foreach (($chartData ?? []) as $row) {
        if ($row['day'] === $d) {
            $foundRev = (float)$row['rev'];
            $foundCnt = (int)$row['cnt'];
            break;
        }
    }
    $chartRevenue[] = $foundRev;
    $chartSales[] = $foundCnt;
}

$revPct   = pctChange($revenueMonth, $revenueLastMonth);
$salesPct = pctChange($salesMonth, $salesLastMonth);
$custPct  = pctChange($customersMonth, $customersLastMonth);

$revTrendDir   = $revPct[0] === '+' ? 'up' : 'down';
$salesTrendDir = $salesPct[0] === '+' ? 'up' : 'down';
$custTrendDir  = $custPct[0] === '+' ? 'up' : 'down';

$currentMonth = tr_date('F Y');

$extraHead = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>';
include __DIR__ . '/includes/layout.php';
?>

<div class="stat-grid dash-kpis">

    <div class="stat-card"<?php if ($planRevState === 'locked' || $planProdFull): ?> style="border-color:rgba(239,68,68,.45);box-shadow:0 0 24px -12px rgba(239,68,68,.5);"<?php elseif ($planRevState === 'warning'): ?> style="border-color:rgba(250,204,21,.45);box-shadow:0 0 24px -12px rgba(250,204,21,.5);"<?php endif; ?>>
        <div class="stat-card-icon-bg" style="background:rgba(99,102,241,.12);color:#818cf8;">
            <i class="fa-solid fa-crown"></i>
        </div>
        <div class="stat-card-label"><?= __('plan.plan_label') ?> · <?= e(ucfirst((string)($planCur['slug'] ?? 'free'))) ?></div>
        <div class="stat-card-val"><?= $planPCount ?> / <?= $planPLim >= 0 ? $planPLim : '∞' ?></div>
        <div class="stat-card-sub"><?= e(fmt_money($planRevSum)) ?> / <?= $planRevLimStore >= 0 ? e(fmt_money($planRevLimStore)) : e(__('plan.unlimited')) ?><?php if ($planRevLim >= 0 && $planStoreCur !== 'USD'): ?> <span style="opacity:.65;">($<?= number_format($planRevLim, 2) ?>)</span><?php endif; ?><?php if ($planFxStale): ?> <i class="fa-solid fa-triangle-exclamation" style="color:#facc15;" title="FX"></i><?php endif; ?></div>
        <div class="stat-card-trend" style="color:<?= $planRevState === 'locked' || $planProdFull ? '#f87171' : ($planRevState === 'warning' ? '#facc15' : 'var(--muted)') ?>;"><?= $planRevState === 'locked' ? e(__('plan.state_locked')) : ($planRevState === 'warning' ? e(__('plan.state_warning', ['pct' => $planRevLim > 0 ? (int)round($planRevSum / $planRevLim * 100) : 0])) : e(__('plan.state_ok'))) ?></div>
        <div class="stat-card-period"><?= ($planCur['revenue_reset'] ?? 'monthly') === 'never' ? e(__('plan.reset_never')) : e($currentMonth) . ' · ' . e(__('plan.reset_monthly')) ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-card-icon-bg" style="background:rgba(34,197,94,.12);color:#22c55e;">
            <i class="fa-solid fa-credit-card"></i>
        </div>
        <div class="stat-card-label"><?= __('adash.revenue') ?></div>
        <div class="stat-card-val"><?= fmt_money($totalRevenue) ?></div>
        <div class="stat-card-sub">(<?= __('adash.today') ?>: <?= $revenueToday > 0 ? '+'.fmt_money($revenueToday) : fmt_money(0) ?>)</div>
        <div class="stat-card-trend <?= $revTrendDir ?>"><?= $revTrendDir === 'up' ? '↑' : '↓' ?> %<?= ltrim($revPct, '+') ?> <?= __('adash.this_month') ?></div>
        <div class="stat-card-period"><?= e($activePayLabel) ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-card-icon-bg" style="background:rgba(var(--accent-rgb),.12);color:#818cf8;">
            <i class="fa-solid fa-bag-shopping"></i>
        </div>
        <div class="stat-card-label"><?= __('adash.orders') ?></div>
        <div class="stat-card-val"><?= $totalSales ?></div>
        <div class="stat-card-sub">(<?= $salesToday ?> <?= __('adash.today') ?>, <?= $salesMonth ?> <?= __('adash.this_month') ?>)</div>
        <div class="stat-card-trend <?= $salesTrendDir ?>"><?= $salesTrendDir === 'up' ? '↑' : '↓' ?> %<?= ltrim($salesPct, '+') ?> <?= __('adash.vs_last') ?></div>
        <div class="stat-card-period"><?= $currentMonth ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-card-icon-bg" style="background:rgba(168,85,247,.12);color:#c084fc;">
            <i class="fa-solid fa-users"></i>
        </div>
        <div class="stat-card-label"><?= __('adash.customers') ?></div>
        <div class="stat-card-val"><?= $totalCustomers ?></div>
        <div class="stat-card-sub">(+<?= $customersToday ?> <?= __('adash.today') ?>, +<?= $customersMonth ?> <?= __('adash.this_month') ?>)</div>
        <div class="stat-card-trend <?= $custTrendDir ?>"><?= $custTrendDir === 'up' ? '↑' : '↓' ?> %<?= ltrim($custPct, '+') ?> <?= __('adash.vs_last') ?></div>
        <div class="stat-card-period"><?= $currentMonth ?></div>
    </div>

    <a href="/admin/licenses.php" class="stat-card" style="display:block;text-decoration:none;color:inherit;">
        <div class="stat-card-icon-bg" style="background:rgba(34,211,238,.12);color:#22d3ee;">
            <i class="fa-solid fa-key"></i>
        </div>
        <div class="stat-card-label"><?= __('amenu.licenses') ?></div>
        <div class="stat-card-val"><?= $totalLicenses ?></div>
        <div class="stat-card-sub">(<?= __('adash.active', ['n' => $activeLicenses]) ?>)</div>
        <div class="stat-card-trend" style="color:var(--muted);"><?= __('adash.active_rate', ['n' => $totalLicenses > 0 ? round($activeLicenses / $totalLicenses * 100) : 0]) ?></div>
        <div class="stat-card-period"><?= __('adash.total') ?></div>
    </a>

    <a href="/admin/support.php" class="stat-card" style="display:block;text-decoration:none;color:inherit;">
        <div class="stat-card-icon-bg" style="background:rgba(250,204,21,.12);color:#facc15;">
            <i class="fa-solid fa-headset"></i>
        </div>
        <div class="stat-card-label"><?= __('adash.tickets') ?></div>
        <div class="stat-card-val"><?= $totalTickets ?></div>
        <div class="stat-card-sub">(<?= __('adash.pending', ['n' => $pendingTickets]) ?>)</div>
        <div class="stat-card-trend" style="color:<?= $pendingTickets > 0 ? '#facc15' : 'var(--muted)' ?>;"><?= $pendingTickets > 0 ? __('adash.open_n', ['n' => $pendingTickets]) : __('adash.all_closed') ?></div>
        <div class="stat-card-period"><?= __('adash.total') ?></div>
    </a>

<?php if (function_exists('feature_active') && feature_active('coupons')): ?>
    <a href="/admin/coupons.php" class="stat-card" style="display:block;text-decoration:none;color:inherit;">
        <div class="stat-card-icon-bg" style="background:rgba(34,197,94,.12);color:#4ade80;">
            <i class="fa-solid fa-ticket"></i>
        </div>
        <div class="stat-card-label"><?= __('amenu.coupons') ?></div>
        <div class="stat-card-val"><?= $totalCoupons ?></div>
        <div class="stat-card-sub">(<?= __('adash.active', ['n' => (int)$adminDb->query("SELECT COUNT(*) FROM coupons WHERE is_active=1")->fetchColumn()]) ?>)</div>
        <div class="stat-card-trend" style="color:var(--muted);"><?= __('adash.used_n', ['n' => (int)$adminDb->query("SELECT COALESCE(SUM(used_count),0) FROM coupons")->fetchColumn()]) ?></div>
        <div class="stat-card-period"><?= __('adash.marketing') ?></div>
    </a>
<?php endif; ?>

</div>

<div style="font-size:12px;color:var(--muted);margin-bottom:16px;font-weight:600;">
    <i class="fa-solid fa-chart-line" style="margin-right:6px;"></i><?= __('adash.chart') ?>
</div>
<div class="dash-chart-card" style="background:var(--bg-card);border:1px solid var(--border);border-radius:16px;padding:20px;margin-bottom:24px;">
    <canvas id="revenueChart" height="100"></canvas>
</div>

<div style="display:grid;grid-template-columns:1fr 320px;gap:20px;align-items:flex-start;" id="dashboardGrid">

<div>
    <div class="admin-card">
        <div class="admin-card-header">
            <span class="admin-card-title"><?= __('adash.products') ?></span>
            <div style="display:flex;gap:8px;">
                <span style="font-size:11px;color:var(--muted);font-weight:600;"><?= __('adash.products_n', ['n' => $totalProducts]) ?></span>
                <a href="/admin/products.php" class="btn-admin btn-ghost-admin" style="font-size:11px;padding:6px 12px;"><?= __('adash.view_all') ?> <i class="fa-solid fa-arrow-right"></i></a>
            </div>
        </div>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th><?= __('adash.th_name') ?></th>
                    <th><?= __('adash.th_category') ?></th>
                    <th><?= __('adash.th_status') ?></th>
                    <th><?= __('adash.th_action') ?></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($allProducts as $i => $p): ?>
            <tr class="animate-row">
                <td style="color:var(--muted);font-size:11px;">#<?= $p['id'] ?></td>
                <td>
                    <div style="font-weight:700;font-size:12px;"><?= e($p['name']) ?></div>
                    <?php if ($p['category']): ?>
                    <div style="font-size:10px;color:var(--accent);font-weight:700;text-transform:uppercase;letter-spacing:.05em;margin-top:2px;"><?= e($p['category']) ?></div>
                    <?php endif; ?>
                </td>
                <td style="color:var(--muted);font-size:11px;"><?= e($p['category'] ?: '—') ?></td>
                <td>
                    <span style="font-size:11px;font-weight:700;color:<?= $p['status']==='active'?'#22c55e':($p['status']==='draft'?'#eab308':'#ef4444') ?>;">
                        <?= ['active'=>__('adash.status_active'),'draft'=>__('adash.status_draft'),'hidden'=>__('adash.status_hidden')][$p['status']] ?? e($p['status']) ?>
                    </span>
                </td>
                <td>
                    <a href="/admin/products.php?edit=<?= $p['id'] ?>" style="color:var(--muted);font-size:13px;transition:color .15s;" onmouseover="this.style.color='#a5b4fc'" onmouseout="this.style.color='var(--muted)'">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($allProducts)): ?>
            <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:24px;font-size:12px;"><?= __('adash.no_products') ?></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <span class="admin-card-title"><?= __('adash.top') ?></span>
            <span style="font-size:11px;color:var(--muted);"><?= $currentMonth ?></span>
        </div>
        <?php if (empty($topProducts) || $topProducts[0]['sale_count'] == 0): ?>
        <div style="background:rgba(239,68,68,.06);border:1px solid rgba(239,68,68,.15);border-radius:10px;padding:14px 18px;font-size:12px;color:#f87171;font-weight:600;">
            <?= __('adash.top_empty') ?>
        </div>
        <?php else: ?>
        <table class="admin-table">
            <thead><tr><th><?= __('adash.th_product') ?></th><th><?= __('adash.th_category') ?></th><th><?= __('adash.th_sales') ?></th></tr></thead>
            <tbody>
            <?php foreach ($topProducts as $tp): ?>
            <?php if ($tp['sale_count'] == 0) continue; ?>
            <tr class="animate-row">
                <td style="font-weight:700;font-size:12px;"><?= e($tp['name']) ?></td>
                <td style="font-size:10px;color:var(--accent);font-weight:700;text-transform:uppercase;"><?= e($tp['category'] ?: '—') ?></td>
                <td><span class="badge badge-green"><?= $tp['sale_count'] ?></span></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<div style="display:flex;flex-direction:column;gap:20px;">

    <div class="admin-card" style="margin-bottom:0;">
        <div class="admin-card-header">
            <span class="admin-card-title"><?= __('adash.recent') ?></span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;">
        <?php if (empty($recentSales)): ?>
        <p style="font-size:12px;color:var(--muted);text-align:center;padding:16px 0;"><?= __('adash.no_orders') ?></p>
        <?php else: foreach ($recentSales as $sale): ?>
        <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--bg-surface);border-radius:10px;">
            <div style="width:32px;height:32px;background:rgba(var(--accent-rgb),.15);border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <i class="fa-solid fa-bag-shopping" style="font-size:12px;color:#818cf8;"></i>
            </div>
            <div style="flex:1;min-width:0;">
                <div style="font-size:11px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e($sale['product_name']) ?></div>
                <div style="font-size:10px;color:var(--muted);"><?= e($sale['username']) ?></div>
            </div>
            <div style="text-align:right;flex-shrink:0;">
                <div style="font-size:11px;font-weight:800;color:#22c55e;"><?= fmt_money((float)$sale['price_paid']) ?></div>
                <div style="font-size:10px;color:var(--muted);"><?= date('d.m.Y', strtotime($sale['purchased_at'])) ?></div>
            </div>
        </div>
        <?php endforeach; endif; ?>
        </div>
    </div>

    <div class="admin-card" style="margin-bottom:0;">
        <div class="admin-card-header">
            <span class="admin-card-title"><?= __('adash.new_customers') ?></span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;">
        <?php if (empty($recentUsers)): ?>
        <p style="font-size:12px;color:var(--muted);text-align:center;padding:16px 0;"><?= __('adash.no_members') ?></p>
        <?php else: foreach ($recentUsers as $u): ?>
        <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;background:var(--bg-surface);border-radius:10px;">
            <img src="<?= e($u['avatar'] ?? 'https://minotar.net/avatar/user.png') ?>"
                 onerror="this.src='https://minotar.net/avatar/user.png'"
                 style="width:32px;height:32px;border-radius:50%;image-rendering:pixelated;border:1.5px solid var(--border);" alt="">
            <div style="flex:1;">
                <div style="font-size:12px;font-weight:800;"><?= e($u['username']) ?></div>
                <div style="font-size:10px;color:var(--muted);"><?= date('d.m.Y', strtotime($u['created_at'])) ?></div>
            </div>
        </div>
        <?php endforeach; endif; ?>
        </div>
    </div>

</div>
</div>

<?php
$chartLabelsJson = json_encode($chartLabels, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP);
$chartRevenueJson = json_encode($chartRevenue, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP);
$chartSalesJson = json_encode($chartSales, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP);
$extraScripts = <<<JS
<script>
(function(){
    const labels = {$chartLabelsJson};
    const revData = {$chartRevenueJson};
    const salesData = {$chartSalesJson};
    const ctx = document.getElementById('revenueChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: <?= json_encode(__('adash.chart_revenue')) ?>,
                    data: revData,
                    borderColor: '#22c55e',
                    backgroundColor: 'rgba(34,197,94,0.08)',
                    fill: true,
                    tension: 0.3,
                    pointRadius: 3,
                    pointBackgroundColor: '#22c55e',
                    borderWidth: 2,
                    yAxisID: 'y'
                },
                {
                    label: <?= json_encode(__('adash.chart_orders')) ?>,
                    data: salesData,
                    borderColor: '#818cf8',
                    backgroundColor: 'rgba(129,140,248,0.08)',
                    fill: true,
                    tension: 0.3,
                    pointRadius: 3,
                    pointBackgroundColor: '#818cf8',
                    borderWidth: 2,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: {
                    labels: { color: '#5a6070', font: { family: "'Plus Jakarta Sans',sans-serif", size: 11 }, usePointStyle: true, padding: 16 }
                },
                tooltip: {
                    backgroundColor: getComputedStyle(document.documentElement).getPropertyValue('--bg-card').trim() || '#16161f',
                    titleColor: getComputedStyle(document.documentElement).getPropertyValue('--text').trim() || '#e8eaf0',
                    bodyColor: getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#a5b4fc',
                    borderColor: getComputedStyle(document.documentElement).getPropertyValue('--border').trim() || 'rgba(255,255,255,0.06)',
                    borderWidth: 1,
                    padding: 12,
                    cornerRadius: 10,
                    titleFont: { size: 12, weight: '700' },
                    bodyFont: { size: 11 }
                }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(255,255,255,0.03)', tickColor: 'transparent' },
                    ticks: { color: '#5a6070', font: { size: 10, weight: '600' }, maxTicksLimit: 8 }
                },
                y: {
                    position: 'left',
                    grid: { color: 'rgba(255,255,255,0.03)' },
                    ticks: { color: '#5a6070', font: { size: 10 }, callback: function(v) { return window.nxFmt(v.toFixed(0)); } }
                },
                y1: {
                    position: 'right',
                    grid: { drawOnChartArea: false },
                    ticks: { color: '#5a6070', font: { size: 10 } }
                }
            }
        }
    });
})();
</script>
JS;
include __DIR__ . '/includes/layout-end.php';
?>
