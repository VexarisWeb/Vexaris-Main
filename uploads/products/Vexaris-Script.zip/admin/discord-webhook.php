<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = 'Discord Webhook';
$activePage = 'discord-webhook';

$settingsRaw = $adminDb->query("SELECT `key`,`value` FROM settings")->fetchAll();
$dwSettings = [];
foreach ($settingsRaw as $r) $dwSettings[$r['key']] = $r['value'];

$dwEvents = [
    'register'      => ['label' => __('adisc.ev_register_label'),                 'desc' => __('adisc.ev_register_desc'),                    'icon' => 'fa-user-plus',     'color' => '#5865F2'],
    'order'         => ['label' => __('adisc.ev_order_label'),               'desc' => __('adisc.ev_order_desc'),            'icon' => 'fa-cart-shopping', 'color' => '#57F287'],
    'topup'         => ['label' => __('adisc.ev_topup_label'),              'desc' => __('adisc.ev_topup_desc'),               'icon' => 'fa-coins',         'color' => '#FEE75C'],
    'review'        => ['label' => __('adisc.ev_review_label'), 'desc' => __('adisc.ev_review_desc'),     'icon' => 'fa-star',          'color' => '#F8B50B'],
    'purchase'      => ['label' => __('adisc.ev_purchase_label'),      'desc' => __('adisc.ev_purchase_desc'),                   'icon' => 'fa-bag-shopping',  'color' => '#ED4245'],
    'ticket'        => ['label' => __('adisc.ev_ticket_label'),         'desc' => __('adisc.ev_ticket_desc'),                   'icon' => 'fa-headset',       'color' => '#FEE75C'],
    'ticket_reply'  => ['label' => __('adisc.ev_ticket_reply_label'),    'desc' => __('adisc.ev_ticket_reply_desc'),           'icon' => 'fa-reply',         'color' => '#5865F2'],
    'coupon'        => ['label' => __('adisc.ev_coupon_label'),        'desc' => __('adisc.ev_coupon_desc'),          'icon' => 'fa-ticket',        'color' => '#57F287'],
];

include __DIR__ . '/includes/layout.php';
?>
<style>
.dw-card{background:var(--bg-card);border:1px solid var(--border);border-radius:16px;overflow:hidden;}
.dw-body{padding:24px;}
.dw-field{width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:12px 14px;color:var(--text);font-size:14px;font-family:ui-monospace,Consolas,monospace;outline:none;transition:border-color .2s,box-shadow .2s;}
.dw-field:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.18);}
.dw-event{display:flex;align-items:center;gap:14px;padding:16px 0;border-bottom:1px solid var(--border);}
.dw-event:last-child{border-bottom:none;}
.dw-event-icon{width:40px;height:40px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;}
.dw-switch{position:relative;width:46px;height:26px;flex-shrink:0;cursor:pointer;}
.dw-switch input{opacity:0;width:0;height:0;}
.dw-switch .track{position:absolute;inset:0;background:rgba(var(--accent-rgb),.18);border-radius:26px;transition:background .2s;}
.dw-switch .track::before{content:"";position:absolute;height:20px;width:20px;left:3px;top:3px;background:#fff;border-radius:50%;transition:transform .2s;box-shadow:0 1px 3px rgba(0,0,0,.35);}
.dw-switch input:checked + .track{background:var(--accent);}
.dw-switch input:checked + .track::before{transform:translateX(20px);}
.dw-msg{display:none;align-items:center;gap:8px;font-size:13px;font-weight:700;padding:11px 14px;border-radius:10px;margin-bottom:16px;}
.dw-msg.show{display:flex;}
.dw-msg.ok{background:rgba(34,197,94,.14);color:#4ade80;border:1px solid rgba(34,197,94,.3);}
.dw-msg.err{background:rgba(239,68,68,.14);color:#f87171;border:1px solid rgba(239,68,68,.3);}
.dw-toast{position:fixed;top:24px;right:24px;z-index:99999;padding:14px 22px;border-radius:12px;font-size:13px;font-weight:700;box-shadow:0 12px 40px rgba(0,0,0,.4);animation:dwToastIn .35s cubic-bezier(.34,1.56,.64,1);display:flex;align-items:center;gap:10px;max-width:400px;backdrop-filter:blur(12px);}
.dw-toast.ok{background:rgba(34,197,94,.18);border:1px solid rgba(34,197,94,.35);color:#4ade80;}
.dw-toast.err{background:rgba(239,68,68,.18);border:1px solid rgba(239,68,68,.35);color:#f87171;}
@keyframes dwToastIn{from{opacity:0;transform:translateY(-20px) scale(.95)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes dwToastOut{from{opacity:1;transform:translateY(0) scale(1)}to{opacity:0;transform:translateY(-20px) scale(.95)}}
</style>

<div style="padding:24px;">

  <div class="dw-card">
    <div class="dw-body">
      <h2 style="font-size:18px;font-weight:900;display:flex;align-items:center;gap:10px;margin-bottom:4px;">
        <span style="width:36px;height:36px;border-radius:10px;background:#5865F215;display:flex;align-items:center;justify-content:center;color:#5865F2;"><i class="fa-brands fa-discord"></i></span>
        Discord Webhook
      </h2>
      <p style="font-size:12px;color:var(--muted);margin-bottom:18px;"><?= __('adisc.subtitle') ?></p>

      <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:8px;">Webhook URL</label>
      <div style="display:flex;gap:10px;">
        <input type="text" id="dwUrl" class="dw-field" value="<?= e($dwSettings['int_discord_webhook_url'] ?? '') ?>" placeholder="https://discord.com/api/webhooks/...">
        <button type="button" class="btn-admin btn-ghost-admin" style="flex-shrink:0;padding:0 18px;justify-content:center;" onclick="testDiscord()"><i class="fa-solid fa-paper-plane"></i> <?= __('adisc.test_btn') ?></button>
      </div>
      <p style="font-size:11px;color:var(--muted);margin-top:8px;"><?= __('adisc.hint') ?></p>
    </div>
  </div>

  <div class="dw-card" style="margin-top:20px;">
    <div class="dw-body">
      <h3 style="font-size:15px;font-weight:800;margin-bottom:4px;"><i class="fa-solid fa-bell" style="color:var(--accent);margin-right:8px;"></i> <?= __('adisc.events_title') ?></h3>
      <p style="font-size:12px;color:var(--muted);margin-bottom:8px;"><?= __('adisc.events_hint') ?></p>

      <?php foreach ($dwEvents as $key => $ev): ?>
      <?php $enabled = ($dwSettings['int_discord_' . $key] ?? '0') === '1'; ?>
      <div class="dw-event">
        <div class="dw-event-icon" style="background:<?= $ev['color'] ?>18;color:<?= $ev['color'] ?>;"><i class="fa-solid <?= $ev['icon'] ?>"></i></div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:14px;font-weight:800;color:var(--text);"><?= $ev['label'] ?></div>
          <div style="font-size:12px;color:var(--muted);margin-top:2px;"><?= $ev['desc'] ?></div>
        </div>
        <label class="dw-switch" title="<?= $enabled ? __('asett.opt_on') : __('asett.opt_off') ?>">
          <input type="checkbox" data-ev="<?= $key ?>" <?= $enabled ? 'checked' : '' ?>>
          <span class="track"></span>
        </label>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:10px;padding:18px 24px;border-top:1px solid var(--border);">
      <a href="/admin/integrations.php" class="btn-admin btn-ghost-admin" style="padding:11px 18px;"><i class="fa-solid fa-arrow-left"></i> <?= __('amenu.integrations') ?></a>
      <button type="button" class="btn-admin btn-primary-admin" style="padding:11px 18px;" onclick="saveDiscord()"><i class="fa-solid fa-floppy-disk"></i> <?= __('aint.save') ?></button>
    </div>
  </div>
</div>

<script>
var dwBusy = false;
function dwMsg(type, text) {
    var existing = document.querySelector('.dw-toast');
    if (existing) existing.remove();
    var t = document.createElement('div');
    t.className = 'dw-toast ' + type;
    t.innerHTML = '<i class="fa-solid ' + (type === 'ok' ? 'fa-circle-check' : 'fa-circle-xmark') + '"></i> ' + text;
    document.body.appendChild(t);
    setTimeout(function(){ t.style.animation = 'dwToastOut .3s ease forwards'; setTimeout(function(){ t.remove(); }, 300); }, 3000);
}
function dwPost(fd) {
    dwBusy = true;
    return fetch('/action.php', { method: 'POST', body: fd })
        .then(function(r){ return r.text().then(function(t){ return { status: r.status, body: t }; }); })
        .then(function(rr){
            var d;
            try { d = JSON.parse(rr.body); }
            catch (e) { dwMsg('err', <?= json_encode(__('adisc.js_bad_json')) ?>.replace('{status}', rr.status).replace('{body}', rr.body.substring(0, 300))); return {}; }
            if (rr.status < 200 || rr.status >= 300) { dwMsg('err', d.msg || (<?= json_encode(__('adisc.js_http_err')) ?>.replace('{status}', rr.status))); return d; }
            dwMsg(d.ok ? 'ok' : 'err', d.msg || (d.ok ? <?= json_encode(__('adisc.js_ok')) ?> : <?= json_encode(__('topup.error')) ?>));
            return d;
        })
        .catch(function(){ dwMsg('err', <?= json_encode(__('adisc.js_conn_err')) ?>); return {}; })
        .finally(function(){ dwBusy = false; });
}
function saveDiscord() {
    if (dwBusy) return;
    var fd = new FormData();
    fd.append('action', 'discord_save');
    fd.append('url', document.getElementById('dwUrl').value);
    document.querySelectorAll('input[data-ev]').forEach(function(inp){ fd.append(inp.dataset.ev, inp.checked ? '1' : '0'); });
    dwPost(fd);
}
function testDiscord() {
    if (dwBusy) return;
    var fd = new FormData();
    fd.append('action', 'discord_test');
    fd.append('url', document.getElementById('dwUrl').value);
    dwPost(fd);
}
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>