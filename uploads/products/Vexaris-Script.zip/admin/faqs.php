<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';
require_once __DIR__ . '/../core/editor.php';
$pageTitle  = __('afaq.page_title');
$activePage = 'faqs';

$faqs = $adminDb->query('SELECT * FROM faqs ORDER BY sort_order ASC, id ASC')->fetchAll();
include __DIR__ . '/includes/layout.php';
?>
<script id="faqDataRaw" type="application/json"><?= json_encode($faqs, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP|JSON_UNESCAPED_UNICODE) ?></script>

<div id="faqEditorOuter" style="display:none;visibility:hidden;position:absolute;left:-9999px">
    <?php render_editor('faqAnswer', '', '320px', 'answer'); ?>
</div>

<script>
var faqData = [];
try { faqData = JSON.parse(document.getElementById('faqDataRaw').textContent); } catch(e) {}

function openFaqModal(id) {
    var isEdit = !!id;
    document.getElementById('faqModalTitle').textContent = isEdit ? <?= json_encode(__('afaq.modal_edit')) ?> : <?= json_encode(__('afaq.modal_add')) ?>;
    document.getElementById('faqId').value = isEdit ? id : '';
    var q = isEdit ? (faqData.find(function(x){ return x.id == id; }) || {}) : {};
    document.getElementById('faqQ').value = q.question || '';
    var ed = document.getElementById('edBody-faqAnswer');
    if (ed) ed.innerHTML = q.answer || '';

    var slot = document.getElementById('faqEditorSlot');
    var outer = document.getElementById('faqEditorOuter');
    var wrap = document.getElementById('edWrap-faqAnswer');
    if (slot && outer && wrap && !slot.contains(wrap)) {
        slot.appendChild(wrap);
    }

    var modal = document.getElementById('faqModal');
    modal.style.display = 'flex';
    modal.style.pointerEvents = 'auto';
    document.body.style.overflow = 'hidden';
    setTimeout(function(){ modal.scrollTop = 0; }, 10);
}

function closeFaqModal() {
    var outer = document.getElementById('faqEditorOuter');
    var wrap = document.getElementById('edWrap-faqAnswer');
    if (outer && wrap) outer.appendChild(wrap);

    document.getElementById('faqModal').style.display = 'none';
    document.getElementById('faqModal').style.pointerEvents = 'none';
    document.body.style.overflow = '';
}

function editFaq(id) { openFaqModal(id); }

function delFaq(id) {
    if (!confirm(<?= json_encode(__('afaq.confirm_delete')) ?>)) return;
    var fd = new FormData();
    fd.append('action', 'faq_delete');
        fd.append('id', id);
        fd.append('_csrf_token', '<?= csrf_token() ?>');
        fetch('/action.php', { method: 'POST', body: fd })
            .then(function(r) { return r.json(); })
            .then(function(d) {
            if (d.ok) {
                faqData = faqData.filter(function(x){ return x.id != id; });
                var row = document.querySelector('.faq-row[data-id="' + id + '"]');
                if (row) row.remove();
                updateFaqCount();
            } else {
                alert(d.msg || <?= json_encode(__('common.error_short')) ?>);
            }
        });
}

function updateFaqCount() {
    var cnt = document.querySelectorAll('.faq-row').length;
    var span = document.querySelector('.faq-count-badge');
    if (span) span.textContent = '(' + cnt + ')';
}
</script>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-circle-question" style="color:#38bdf8;margin-right:8px"></i> <?= e(__('home.faq_title')) ?> <span class="faq-count-badge" style="color:var(--muted);font-weight:500">(<?= count($faqs) ?>)</span></span>
        <button onclick="openFaqModal()" class="btn-admin btn-primary-admin" style="font-size:12px;padding:7px 16px"><i class="fa-solid fa-plus"></i> <?= e(__('afaq.modal_add')) ?></button>
    </div>
    <p style="font-size:12px;color:var(--muted);margin:8px 0 12px"><i class="fa-solid fa-arrows-up-down"></i> <?= e(__('afaq.hint')) ?></p>
    <div id="faqList" style="display:flex;flex-direction:column;gap:8px">
        <?php foreach ($faqs as $f): ?>
        <div class="faq-row" draggable="true" data-id="<?= (int)$f['id'] ?>" style="display:flex;align-items:center;gap:12px;background:var(--bg-card);border:1px solid var(--border);border-radius:10px;padding:12px 14px;cursor:grab">
            <i class="fa-solid fa-grip" style="color:var(--muted);cursor:grab"></i>
            <div style="flex:1;min-width:0">
                <div style="font-weight:700;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($f['question']) ?></div>
                <div style="font-size:12px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars(mb_substr(strip_tags($f['answer']),0,80)) ?></div>
            </div>
            <span style="font-size:11px;color:var(--muted)">#<?= $f['sort_order'] ?></span>
            <button onclick="editFaq(<?= (int)$f['id'] ?>)" class="btn-admin btn-sm"><i class="fa-solid fa-pen"></i></button>
            <button onclick="delFaq(<?= (int)$f['id'] ?>)" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;border-color:rgba(239,68,68,.2)"><i class="fa-solid fa-trash"></i></button>
        </div>
        <?php endforeach; ?>
        <?php if (!$faqs): ?><div style="text-align:center;color:var(--muted);padding:24px"><?= e(__('afaq.empty')) ?></div><?php endif; ?>
    </div>
</div>

<div id="faqModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:9999;align-items:flex-start;justify-content:center;padding:40px 16px 60px;overflow-y:auto;pointer-events:none">
    <div style="background:#1e1e2e;border:1px solid var(--border);border-radius:16px;width:100%;max-width:860px;margin:auto;flex-shrink:0;box-shadow:0 24px 64px rgba(0,0,0,.6)">
        <div style="padding:20px 26px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;background:#1e1e2e;z-index:1;border-radius:16px 16px 0 0">
            <span id="faqModalTitle" style="font-weight:800;font-size:16px"><?= e(__('afaq.modal_add')) ?></span>
            <button onclick="closeFaqModal()" style="background:none;border:none;color:var(--muted);font-size:22px;cursor:pointer;line-height:1;padding:2px 6px;border-radius:6px;transition:color .15s" onmouseenter="this.style.color='var(--text)'" onmouseleave="this.style.color='var(--muted)'"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form id="faqForm" style="padding:26px;display:flex;flex-direction:column;gap:16px">
            <input type="hidden" name="action" value="faq_save">
            <input type="hidden" name="id" id="faqId" value="">
            <?= csrf_field() ?>
            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px"><?= e(__('afaq.label_question')) ?></label>
                <input type="text" name="question" id="faqQ" required maxlength="255" placeholder="<?= e(__('afaq.ph_question')) ?>" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:8px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;transition:border-color .15s" onfocus="this.style.borderColor='var(--accent)'" onblur="this.style.borderColor='var(--border)'">
            </div>
            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px"><?= e(__('afaq.label_answer')) ?></label>
                <div id="faqEditorSlot" style="min-height:340px"></div>
                <textarea id="faqAnswerHidden" name="answer" style="display:none"></textarea>
            </div>
            <div id="faqFormMsg" style="display:none;font-size:12px;font-weight:700;padding:9px 14px;border-radius:8px;margin-top:2px"></div>
            <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:4px;padding-top:14px;border-top:1px solid var(--border)">
                <button type="button" onclick="closeFaqModal()" class="btn-admin"><?= e(__('support.cancel')) ?></button>
                <button type="submit" id="faqSaveBtn" class="btn-admin btn-primary-admin"><i class="fa-solid fa-floppy-disk"></i> <?= e(__('msg.save')) ?></button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('faqModal').addEventListener('click', function(e) { if (e.target.id === 'faqModal') closeFaqModal(); });

document.getElementById('faqForm').addEventListener('submit', function(e) {
    e.preventDefault();
    var ta = document.getElementById('faqAnswerHidden');
    var ed = document.getElementById('edBody-faqAnswer');
    if (ta && ed) ta.value = ed.innerHTML;

    var q = document.getElementById('faqQ').value.trim();
    var a = ta ? ta.value.trim() : '';
    if (!q) { showFaqMsg(<?= json_encode(__('afaq.err_q_required')) ?>, 'error'); return; }
    if (!a || a === '<br>') { showFaqMsg(<?= json_encode(__('afaq.err_a_required')) ?>, 'error'); return; }

    var btn = document.getElementById('faqSaveBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> ' + <?= json_encode(__('aseo.saving')) ?>;

    var fd = new FormData(this);
    fetch('/action.php', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> <?= e(__('msg.save')) ?>';
            if (d.ok) {
                closeFaqModal();
                location.reload();
            } else {
                showFaqMsg(d.msg || <?= json_encode(__('msg.error_generic')) ?>, 'error');
            }
        })
        .catch(function() {
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> <?= e(__('msg.save')) ?>';
            showFaqMsg(<?= json_encode(__('afaq.err_conn_retry')) ?>, 'error');
        });
});

function showFaqMsg(msg, type) {
    var el = document.getElementById('faqFormMsg');
    el.textContent = msg;
    el.style.display = 'block';
    if (type === 'error') {
        el.style.background = 'rgba(239,68,68,.12)';
        el.style.color = '#f87171';
        el.style.border = '1px solid rgba(239,68,68,.25)';
    } else {
        el.style.background = 'rgba(34,197,94,.12)';
        el.style.color = '#4ade80';
        el.style.border = '1px solid rgba(34,197,94,.25)';
    }
    setTimeout(function(){ el.style.display = 'none'; }, 4000);
}

var faqList = document.getElementById('faqList');
var dragEl = null;
if (faqList) {
    faqList.querySelectorAll('.faq-row').forEach(function(row) {
        row.addEventListener('dragstart', function() { dragEl = row; row.style.opacity = '.5'; });
        row.addEventListener('dragend', function() { row.style.opacity = '1'; dragEl = null; });
        row.addEventListener('dragover', function(e) {
            e.preventDefault();
            if (!dragEl) return;
            var after = faqDragAfter(e.clientY);
            if (after == null) faqList.appendChild(dragEl); else faqList.insertBefore(dragEl, after);
        });
    });
    faqList.addEventListener('drop', function() {
        var ids = [].slice.call(faqList.querySelectorAll('.faq-row')).map(function(r) { return r.dataset.id; });
        var fd = new FormData();
        fd.append('action', 'faq_reorder');
        fd.append('ids', ids.join(','));
        fd.append('_csrf_token', '<?= csrf_token() ?>');
        fetch('/action.php', { method: 'POST', body: fd });
    });
}
function faqDragAfter(y) {
    var found = null;
    [].slice.call(faqList ? faqList.querySelectorAll('.faq-row') : []).forEach(function(c) {
        if (c.style.opacity === '.5') return;
        var b = c.getBoundingClientRect();
        if (y < b.top + b.height / 2 && !found) found = c;
    });
    return found;
}
</script>
<?php include __DIR__ . '/includes/layout-end.php'; ?>
