<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = 'Footer Editor';
$activePage = 'footer-editor';

$msg = '';

$settingsRaw = $adminDb->query("SELECT `key`,`value` FROM settings")->fetchAll();
$settings = [];
foreach ($settingsRaw as $r) $settings[$r['key']] = $r['value'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (isset($_POST['save_footer_links'])) {
        $fjson = trim($_POST['footer_links_json'] ?? '{}');
        $farr = json_decode($fjson, true);
        if (!is_array($farr)) $farr = [];
        $fclean = [];
        foreach (['platform','account','legal'] as $fg) {
            $fgd = (isset($farr[$fg]) && is_array($farr[$fg])) ? $farr[$fg] : [];
            $ftitle = trim((string)($fgd['title'] ?? ''));
            if (strlen($ftitle) > 60) $ftitle = mb_substr($ftitle, 0, 60);
            $flinks = [];
            if (isset($fgd['links']) && is_array($fgd['links'])) {
                foreach (array_slice($fgd['links'], 0, 12) as $fit) {
                    if (!is_array($fit)) continue;
                    $flb = trim((string)($fit['label'] ?? ''));
                    $furl = trim((string)($fit['url'] ?? ''));
                    $fico = trim((string)($fit['icon'] ?? ''));
                    if (strlen($flb) > 60) $flb = mb_substr($flb, 0, 60);
                    if (strlen($furl) > 255) $furl = substr($furl, 0, 255);
                    if (strlen($fico) > 80) $fico = substr($fico, 0, 80);
                    if ($flb === '' || $furl === '') continue;
                    $ft = (string)preg_replace('/[\x00-\x20]+/', '', $furl);
                    if (preg_match('/^(javascript|vbscript|data):/i', $ft)) continue;
                    $flinks[] = ['label'=>$flb,'url'=>$furl,'icon'=>$fico];
                }
            }
            $fclean[$fg] = ['title'=>$ftitle,'links'=>$flinks];
        }
        $ftoSave = json_encode($fclean, JSON_UNESCAPED_UNICODE);
        $exists = $adminDb->prepare("SELECT `key` FROM settings WHERE `key`='footer_links' LIMIT 1");
        $exists->execute();
        if ($exists->fetch()) $adminDb->prepare("UPDATE settings SET `value`=? WHERE `key`='footer_links'")->execute([$ftoSave]);
        else $adminDb->prepare("INSERT INTO settings (`key`,`value`) VALUES ('footer_links',?)")->execute([$ftoSave]);
        $settings['footer_links'] = $ftoSave;
        audit_log($adminDb, 'update', 'settings', 0, 'footer_links', '/admin/footer-editor.php');
        $msg = ['type'=>'success','text'=>__('afoot.saved_ok')];
    }
}

include __DIR__ . '/includes/layout.php';
?>

<?php if ($msg): ?>
<div style="background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#4ade80;
     padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;
     margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid fa-circle-check"></i> <?= e($msg['text']) ?>
</div>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-bars-staggered" style="color:#a78bfa;margin-right:8px;"></i><?= __('afoot.title') ?></span>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px;margin-top:12px;">
        <?php
        $ftPre = ['platform'=>'Platform','account'=>'Hesap','legal'=>'Yasal'];
        try {
            $ftDec = json_decode($settings['footer_links'] ?? '', true);
            if (is_array($ftDec)) foreach (['platform','account','legal'] as $fk) {
                if (isset($ftDec[$fk]['title']) && trim((string)$ftDec[$fk]['title']) !== '') $ftPre[$fk] = $ftDec[$fk]['title'];
            }
        } catch (Throwable $e) {}
        foreach ($ftPre as $fgKey => $fgLabel): ?>
        <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:12px;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
                <input type="text" id="ftTitle-<?= $fgKey ?>" maxlength="60" value="<?= e($fgLabel) ?>" style="flex:1;min-width:0;background:transparent;border:1px solid var(--border);border-radius:7px;padding:7px 10px;color:var(--text);font-weight:800;font-size:13px;">
                <button type="button" onclick="ftAddLink('<?= $fgKey ?>')" title="<?= __('afoot.add_link_title') ?>" style="width:30px;height:30px;background:rgba(var(--accent-rgb),.15);border:1px solid rgba(var(--accent-rgb),.3);border-radius:7px;color:#a5b4fc;cursor:pointer;flex-shrink:0;"><i class="fa-solid fa-plus"></i></button>
            </div>
            <div id="ftList-<?= $fgKey ?>" style="display:flex;flex-direction:column;gap:8px;"></div>
        </div>
        <?php endforeach; ?>
    </div>
    <form method="POST" id="ftLinksForm" style="margin-top:12px">
        <?= csrf_field() ?>
        <input type="hidden" name="save_footer_links" value="1">
        <input type="hidden" name="footer_links_json" id="ftLinksJson">
        <button type="submit" class="btn-admin btn-primary-admin"><i class="fa-solid fa-floppy-disk"></i> <?= __('afoot.save_btn') ?></button>
    </form>
    <p style="font-size:11px;color:var(--muted);margin-top:8px"><i class="fa-solid fa-circle-info"></i> <?= __('afoot.hint_empty') ?></p>
    <p style="font-size:11px;color:var(--muted);margin-top:4px"><i class="fa-solid fa-lock"></i> <?= __('afoot.hint_powered') ?></p>
</div>
<script>
(function(){
    var ftDefault = {
        platform: {title:'Platform', links:[
            {label:'Ana Sayfa', url:'/', icon:'fa-solid fa-house'},
            {label:'Ürünler', url:'/products', icon:'fa-solid fa-box-open'},
            {label:'Duyurular', url:'/news', icon:'fa-solid fa-newspaper'},
            {label:'Destek', url:'/support', icon:'fa-solid fa-headset'}
        ]},
        account: {title:'Hesap', links:[
            {label:'Giriş Yap', url:'/login', icon:'fa-solid fa-right-to-bracket'},
            {label:'Kayıt Ol', url:'/register', icon:'fa-solid fa-user-plus'},
            {label:'Panelim', url:'/user/dashboard', icon:'fa-solid fa-gauge'},
            {label:'Ürünlerim', url:'/user/my-products', icon:'fa-solid fa-cubes'}
        ]},
        legal: {title:'Yasal', links:[
            {label:'Gizlilik Politikası', url:'/legal?p=privacy-policy', icon:'fa-solid fa-file-shield'},
            {label:'Kullanım Şartları', url:'/legal?p=terms-of-service', icon:'fa-solid fa-file-contract'},
            {label:'İade Politikası', url:'/legal?p=refund-policy', icon:'fa-solid fa-rotate'},
            {label:'Çerez Politikası', url:'/legal?p=cookie-policy', icon:'fa-solid fa-cookie'}
        ]}
    };
    var ftData = null;
    try {
        ftData = JSON.parse(<?= json_encode($settings['footer_links'] ?? '', JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT) ?>);
        if (typeof ftData === 'string') ftData = JSON.parse(ftData === '' ? 'null' : ftData);
        if (!ftData || typeof ftData !== 'object') ftData = null;
    } catch(e) { ftData = null; }
    if (!ftData) ftData = JSON.parse(JSON.stringify(ftDefault));
    ['platform','account','legal'].forEach(function(g){
        if (!ftData[g] || typeof ftData[g] !== 'object') ftData[g] = {title:'', links:[]};
        if (!Array.isArray(ftData[g].links)) ftData[g].links = [];
        var ti = document.getElementById('ftTitle-' + g);
        if (ti && !ti.value && ftData[g].title) ti.value = ftData[g].title;
        else if (ti && ti.value && !ftData[g].title) ftData[g].title = ti.value;
    });
    function ftEsc(s){ return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
    function ftRender(g){
        var list = document.getElementById('ftList-' + g);
        if (!list) return;
        list.innerHTML = '';
        if (ftData[g].links.length === 0) {
            list.innerHTML = '<div style="font-size:11px;color:var(--muted);padding:6px 2px;">' + <?= json_encode(__('afoot.empty_col')) ?> + '</div>';
        }
        ftData[g].links.forEach(function(it, idx){
            var row = document.createElement('div');
            row.style.cssText = 'display:flex;gap:6px;align-items:center;background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:8px;padding:6px 8px;';
            var ico = (it.icon || 'fa-solid fa-link').replace(/"/g, '');
            row.innerHTML = '<span style="width:28px;height:28px;display:flex;align-items:center;justify-content:center;color:var(--accent);flex-shrink:0;"><i class="' + ftEsc(ico) + '"></i></span>'
                + '<input type="text" placeholder="<?= __('afoot.ph_label') ?>" value="' + ftEsc(it.label || '') + '" data-g="' + g + '" data-idx="' + idx + '" data-k="label" style="flex:1;min-width:0;background:transparent;border:1px solid var(--border);border-radius:6px;padding:6px 8px;color:var(--text);font-size:12px;">'
                + '<input type="text" placeholder="<?= __('afoot.ph_url') ?>" value="' + ftEsc(it.url || '') + '" data-g="' + g + '" data-idx="' + idx + '" data-k="url" style="flex:2;min-width:0;background:transparent;border:1px solid var(--border);border-radius:6px;padding:6px 8px;color:var(--text);font-size:12px;">'
                + '<input type="text" placeholder="fa-solid fa-..." value="' + ftEsc(it.icon || '') + '" data-g="' + g + '" data-idx="' + idx + '" data-k="icon" title="<?= __('afoot.icon_title') ?>" style="flex:1;min-width:0;background:transparent;border:1px solid var(--border);border-radius:6px;padding:6px 8px;color:var(--text);font-size:12px;">'
                + '<button type="button" onclick="ftRemoveLink(\'' + g + '\',' + idx + ')" style="background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2);border-radius:6px;width:26px;height:26px;cursor:pointer;flex-shrink:0;"><i class="fa-solid fa-trash" style="font-size:11px;"></i></button>';
            list.appendChild(row);
        });
        list.querySelectorAll('input').forEach(function(inp){
            inp.addEventListener('input', function(e){
                var gg = e.target.getAttribute('data-g'), ii = parseInt(e.target.getAttribute('data-idx'), 10), kk = e.target.getAttribute('data-k');
                if (ftData[gg] && ftData[gg].links[ii]) { ftData[gg].links[ii][kk] = e.target.value; }
            });
            if (inp.getAttribute('data-k') === 'icon') {
                inp.addEventListener('input', function(){
                    var ic = inp.closest('div').querySelector('span i');
                    if (ic) ic.className = (inp.value.trim() || 'fa-solid fa-link').replace(/"/g, '');
                });
            }
        });
    }
    window.ftAddLink = function(g){
        if (!ftData[g]) ftData[g] = {title:'', links:[]};
        if (ftData[g].links.length >= 12) { alert(<?= json_encode(__('afoot.max_links')) ?>); return; }
        ftData[g].links.push({label:'Yeni Link', url:'/', icon:'fa-solid fa-link'});
        ftRender(g);
    };
    window.ftRemoveLink = function(g, i){
        if (ftData[g] && ftData[g].links[i] !== undefined) ftData[g].links.splice(i, 1);
        ftRender(g);
    };
    ['platform','account','legal'].forEach(function(g){
        ftRender(g);
        var ti = document.getElementById('ftTitle-' + g);
        if (ti) ti.addEventListener('input', function(){ if (ftData[g]) ftData[g].title = ti.value; });
    });
    document.getElementById('ftLinksForm').addEventListener('submit', function(){
        ['platform','account','legal'].forEach(function(g){
            var ti = document.getElementById('ftTitle-' + g);
            if (ti && ftData[g]) ftData[g].title = ti.value;
        });
        document.getElementById('ftLinksJson').value = JSON.stringify(ftData);
    });
})();
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
