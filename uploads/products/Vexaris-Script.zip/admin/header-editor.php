<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = 'Header Editor';
$activePage = 'header-editor';

$msg = '';

$settingsRaw = $adminDb->query("SELECT `key`,`value` FROM settings")->fetchAll();
$settings = [];
foreach ($settingsRaw as $r) $settings[$r['key']] = $r['value'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (isset($_POST['save_header_links'])) {
        $json = trim($_POST['header_links_json'] ?? '[]');
        $arr = json_decode($json, true);
        if (!is_array($arr)) $arr = [];
        $clean = [];
        foreach (array_slice($arr, 0, 25) as $it) {
            if (!is_array($it)) continue;
            $lb = trim((string)($it['label'] ?? ''));
            $url = trim((string)($it['url'] ?? ''));
            $ico = trim((string)($it['icon'] ?? ''));
            if (strlen($lb) > 60) $lb = mb_substr($lb, 0, 60);
            if (strlen($url) > 255) $url = substr($url, 0, 255);
            if (strlen($ico) > 80) $ico = substr($ico, 0, 80);
            if ($lb === '' || $url === '') continue;
            $t = (string)preg_replace('/[\x00-\x20]+/', '', $url);
            if (preg_match('/^(javascript|vbscript|data):/i', $t)) continue;
            $clean[] = ['label'=>$lb,'url'=>$url,'icon'=>$ico];
        }
        $toSave = json_encode($clean, JSON_UNESCAPED_UNICODE);
        $exists = $adminDb->prepare("SELECT `key` FROM settings WHERE `key`='header_links' LIMIT 1");
        $exists->execute();
        if ($exists->fetch()) $adminDb->prepare("UPDATE settings SET `value`=? WHERE `key`='header_links'")->execute([$toSave]);
        else $adminDb->prepare("INSERT INTO settings (`key`,`value`) VALUES ('header_links',?)")->execute([$toSave]);
        $settings['header_links'] = $toSave;
        audit_log($adminDb, 'update', 'settings', 0, 'header_links', '/admin/header-editor.php');
        $msg = ['type'=>'success','text'=>__('ahead.saved')];
    }
}

include __DIR__ . '/includes/layout.php';
?>
<style>@media(max-width:640px){.he-icon-grid{grid-template-columns:repeat(3,1fr)!important;}}</style>

<?php if ($msg): ?>
<div style="background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#4ade80;
     padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;
     margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid fa-circle-check"></i> <?= e($msg['text']) ?>
</div>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-bars" style="color:#22d3ee;margin-right:8px;"></i><?= __('ahead.title') ?></span>
        <button type="button" onclick="addHeaderLink()" class="btn-admin" style="font-size:12px;padding:8px 14px;background:rgba(var(--accent-rgb),.15);border:1px solid rgba(var(--accent-rgb),.3);"><i class="fa-solid fa-plus"></i> <?= __('ahead.add_link') ?></button>
    </div>
    <div id="headerLinksList" style="display:flex;flex-direction:column;gap:8px;margin-top:12px"></div>
    <form method="POST" id="headerLinksForm" style="margin-top:12px">
        <?= csrf_field() ?>
        <input type="hidden" name="save_header_links" value="1">
        <input type="hidden" name="header_links_json" id="headerLinksJson">
        <button type="submit" class="btn-admin btn-primary-admin"><i class="fa-solid fa-floppy-disk"></i> <?= __('ahead.save') ?></button>
    </form>
    <p style="font-size:11px;color:var(--muted);margin-top:8px"><?= __('ahead.hint') ?></p>
</div>
<div id="headerIconPicker" class="hidden" style="position:fixed;inset:0;z-index:1002;background:rgba(0,0,0,.8);display:none;align-items:center;justify-content:center;padding:16px;">
    <div style="background:#1e1e2f;border:1px solid var(--border);border-radius:12px;width:100%;max-width:560px;max-height:80vh;overflow:hidden;display:flex;flex-direction:column">
        <div style="padding:14px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:12px">
            <span style="font-weight:800"><i class="fa-solid fa-icons" style="color:var(--accent);margin-right:8px"></i><?= __('acat.icon_pick') ?></span>
            <button type="button" onclick="closeHeaderIconPicker()" style="background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:8px;padding:6px 10px;color:var(--text);cursor:pointer"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div style="padding:12px 16px;border-bottom:1px solid var(--border)"><input type="text" id="headerIconSearch" placeholder="<?= __('ahead.icon_search') ?>" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:8px;padding:8px 12px;color:var(--text)" oninput="filterHeaderIcons(this.value)"></div>
        <div id="headerIconGrid" class="he-icon-grid" style="padding:12px 16px;overflow-y:auto;display:grid;grid-template-columns:repeat(6,1fr);gap:8px"></div>

    </div>
</div>
<script>
(function(){
    const faIcons = ["fa-house","fa-store","fa-newspaper","fa-headset","fa-user","fa-right-to-bracket","fa-right-from-bracket","fa-gauge","fa-box","fa-tag","fa-tags","fa-gift","fa-star","fa-heart","fa-cart-shopping","fa-bag-shopping","fa-credit-card","fa-coins","fa-gamepad","fa-cube","fa-puzzle-piece","fa-layer-group","fa-shield-halved","fa-lock","fa-key","fa-envelope","fa-phone","fa-circle-info","fa-question","fa-life-ring","fa-book","fa-file-lines","fa-pen","fa-gear","fa-wrench","fa-rocket","fa-fire","fa-bolt","fa-crown","fa-gem","fa-trophy","fa-medal","fa-award","fa-bell","fa-comments","fa-users","fa-user-group","fa-headset","fa-circle-question"];
    let headerIconTarget = null;
    window.openHeaderIconPicker = function(idx){ headerIconTarget=idx; document.getElementById('headerIconPicker').style.display='flex'; renderHeaderIcons(''); document.getElementById('headerIconSearch').value=''; document.getElementById('headerIconSearch').focus(); };
    window.closeHeaderIconPicker = function(){ document.getElementById('headerIconPicker').style.display='none'; headerIconTarget=null; };
    window.filterHeaderIcons = function(q){ renderHeaderIcons(q); };
    function renderHeaderIcons(q){
        const grid=document.getElementById('headerIconGrid'); if(!grid) return;
        const qq=(q||'').toLowerCase();
        const list=qq?faIcons.filter(i=>i.toLowerCase().includes(qq)):faIcons;
        grid.innerHTML=list.map(cls=>'<button type="button" onclick="selectHeaderIcon(\''+cls+'\')" style="background:var(--bg-surface);border:1px solid var(--border);border-radius:8px;padding:10px;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer;color:var(--text)"><i class="fa-solid '+cls+'" style="font-size:18px"></i><span style="font-size:10px;opacity:.7">'+cls.replace('fa-','')+'</span></button>').join('') || '<div style="grid-column:1/-1;text-align:center;color:var(--muted);padding:20px">' + <?= json_encode(__('ahead.empty')) ?> + '</div>';
    }
    window.selectHeaderIcon=function(cls){
        if(headerIconTarget!==null && links[headerIconTarget]){ links[headerIconTarget].icon='fa-solid '+cls; renderHeaderLinks(); }
        closeHeaderIconPicker();
    };
    let links = [];
    const linksSaved = <?= array_key_exists('header_links', $settings) ? 'true' : 'false' ?>;
    try{ links = JSON.parse(<?= json_encode($settings['header_links'] ?? '[]', JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT) ?>); if(typeof links === 'string') links = JSON.parse(links === '' ? 'null' : links); if(!Array.isArray(links)) links=[]; }catch(e){ links=[]; }
    if(!linksSaved && links.length===0){
        links = [
            {label:'Ana Sayfa', url:'/', icon:'fa-solid fa-house'},
            {label:'Mağaza', url:'/products', icon:'fa-solid fa-store'},
            {label:'Duyurular', url:'/news', icon:'fa-solid fa-newspaper'},
            {label:'Destek', url:'/support', icon:'fa-solid fa-headset'}
        ];
    }
    const list = document.getElementById('headerLinksList');
    function renderHeaderLinks(){
        list.innerHTML='';
        links.forEach((it, idx)=>{
            const ico = it.icon || 'fa-solid fa-link';
            const row=document.createElement('div');
            row.style.cssText='display:flex;gap:8px;align-items:center;flex-wrap:wrap;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:8px 10px';
            row.innerHTML='<button type="button" onclick="openHeaderIconPicker('+idx+')" style="width:36px;height:36px;background:var(--bg-surface);border:1px solid var(--border);border-radius:7px;display:flex;align-items:center;justify-content:center;color:var(--accent);flex-shrink:0"><i class="'+ico.replace(/"/g,'&quot;')+'"></i></button>'
                         +'<input type="text" placeholder="' + <?= json_encode(__('ahead.tag_label')) ?> + '" value="'+(it.label||'').replace(/"/g,'&quot;')+'" data-idx="'+idx+'" data-k="label" style="flex:1 1 150px;min-width:0;background:transparent;border:1px solid var(--border);border-radius:7px;padding:7px 10px;color:var(--text)">'
                         +'<input type="text" placeholder="/sayfa veya https://..." value="'+(it.url||'').replace(/"/g,'&quot;')+'" data-idx="'+idx+'" data-k="url" style="flex:2 1 220px;min-width:0;background:transparent;border:1px solid var(--border);border-radius:7px;padding:7px 10px;color:var(--text)">'
                         +'<span style="display:flex;flex-direction:column;gap:2px;flex-shrink:0;">'
                         +'<button type="button" onclick="moveHeaderLink('+idx+',-1)" style="background:var(--bg-surface);border:1px solid var(--border);border-radius:6px;color:var(--muted);cursor:pointer;font-size:10px;padding:2px 7px;line-height:1;" aria-label="↑">▲</button>'
                         +'<button type="button" onclick="moveHeaderLink('+idx+',1)" style="background:var(--bg-surface);border:1px solid var(--border);border-radius:6px;color:var(--muted);cursor:pointer;font-size:10px;padding:2px 7px;line-height:1;" aria-label="↓">▼</button>'
                         +'</span>'
                         +'<button type="button" onclick="removeHeaderLink('+idx+')" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;border-color:rgba(239,68,68,.2);"><i class="fa-solid fa-trash"></i></button>';
            list.appendChild(row);
        });
        list.querySelectorAll('input').forEach(inp=>inp.addEventListener('input',e=>{ const i=parseInt(e.target.dataset.idx), k=e.target.dataset.k; links[i][k]=e.target.value; }));
    }
    function render(){ renderHeaderLinks(); }
    window.addHeaderLink=function(){ links.push({label:'Yeni Link',url:'/',icon:'fa-solid fa-link'}); renderHeaderLinks(); };
    window.removeHeaderLink=function(i){ links.splice(i,1); render(); };
    window.moveHeaderLink=function(i,dir){ var j=i+dir; if(j<0||j>=links.length) return; var t=links[i]; links[i]=links[j]; links[j]=t; renderHeaderLinks(); };
    document.getElementById('headerLinksForm').addEventListener('submit',e=>{
        document.getElementById('headerLinksJson').value = JSON.stringify(links);
    });
    render();
})();
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
