<?php
if (!defined('NEXUS_BOOT')) { http_response_code(403); exit; }
if (!function_exists('has_permission') || !has_permission('ai_assistant')) return;
?>
<button id="vxAiBtn" aria-label="<?= e(__('vai.title')) ?>">
  <i class="fa-solid fa-sparkles"></i>
</button>
<div id="vxAiPanel">
  <div class="vxai-head">
    <button class="vxai-x" id="vxaiHistBtn" aria-label="<?= e(__('vai.history')) ?>"><i class="fa-solid fa-bars"></i></button>
    <span class="vxai-title"><i class="fa-solid fa-sparkles"></i> <?= e(__('vai.title')) ?></span>
    <label class="vxai-auto"><input type="checkbox" id="vxaiAuto"> <?= e(__('vai.auto_mode')) ?></label>
    <button class="vxai-x" id="vxaiClose" aria-label="×"><i class="fa-solid fa-xmark"></i></button>
  </div>
  <div class="vxai-chat" id="vxaiChat"></div>
  <div class="vxai-barwrap">
    <div class="vxai-chips" id="vxaiChips"></div>
    <div class="vxai-bar" id="vxaiBar">
      <textarea class="vxai-input" id="vxaiInput" rows="1" placeholder="<?= e(__('vai.ask_ph')) ?>"></textarea>
      <div class="vxai-toolbar">
        <div class="vxai-tleft">
          <span class="vxai-anchor">
            <span class="vxai-menu" id="vxaiAddMenu">
              <span class="vxai-mh">Kaynak</span>
              <span class="vxai-mi" id="vxaiUploadMi"><i class="fa-solid fa-paperclip"></i> <?= e(__('vai.upload')) ?></span>
              <span class="vxai-mi" id="vxaiHelpMi"><i class="fa-solid fa-terminal"></i> /help</span>
            </span>
            <button class="vxai-btn" id="vxaiAddBtn" title="+">+</button>
          </span>
          <span class="vxai-anchor">
            <span class="vxai-menu" id="vxaiModelMenu"><span class="vxai-mi sel">Vexaris-Auto</span></span>
            <button class="vxai-btn" id="vxaiModelBtn"><span id="vxaiModelCur">Vexaris-Auto</span> <i class="fa-solid fa-chevron-down" style="font-size:10px;"></i></button>
          </span>
          <span class="vxai-anchor">
            <span class="vxai-menu" id="vxaiEffortMenu" style="min-width:130px;"></span>
            <button class="vxai-btn" id="vxaiEffortBtn"><i class="fa-solid fa-wand-magic-sparkles" style="color:var(--accent);"></i> <span id="vxaiEffortCur">High</span></button>
          </span>
        </div>
        <div class="vxai-tleft">
          <button class="vxai-btn" id="vxaiMicBtn" title="<?= e(__('vai.mic')) ?>"><i class="fa-solid fa-microphone"></i></button>
          <button class="vxai-send" id="vxaiSendBtn" title="<?= e(__('vai.send')) ?>"><i class="fa-solid fa-arrow-up" id="vxaiSendIc"></i></button>
        </div>
      </div>
    </div>
  </div>
  <div class="vxai-drawer" id="vxaiDrawer">
    <div class="vxai-sheet" role="dialog" aria-modal="true">
      <div class="vxai-sheet-head">
        <span><?= e(__('vai.history')) ?></span>
        <span style="display:flex;gap:8px;">
          <button class="vxai-x" id="vxaiNewChat" title="<?= e(__('vai.new_chat')) ?>"><i class="fa-solid fa-plus"></i></button>
          <button class="vxai-x" id="vxaiDrawerClose"><i class="fa-solid fa-xmark"></i></button>
        </span>
      </div>
      <div class="vxai-sheet-list" id="vxaiHistList"></div>
      <div class="vxai-sheet-foot" id="vxaiQuotaFoot"></div>
    </div>
  </div>
</div>
<input type="file" id="vxaiFile" accept=".png,.jpg,.jpeg,.webp,.txt,.pdf" multiple style="display:none;">
<style>
#vxAiBtn{position:fixed;bottom:24px;right:84px;z-index:9998;width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,var(--accent),#7c3aed);color:#fff;border:none;box-shadow:0 6px 24px rgba(var(--accent-rgb,99,102,241),.45);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:20px;transition:transform .25s cubic-bezier(.34,1.56,.64,1);font-family:inherit;}
#vxAiBtn:hover{transform:scale(1.1) rotate(8deg);}
#vxAiPanel{position:fixed;bottom:144px;right:24px;z-index:9999;width:400px;max-width:calc(100vw - 32px);height:560px;max-height:calc(100dvh - 170px);background:var(--bg-card);border:1px solid var(--border);border-radius:20px;box-shadow:0 30px 70px rgba(0,0,0,.55);display:none;flex-direction:column;overflow:hidden;transform-origin:bottom right;}
#vxAiPanel.open{display:flex;animation:vxaiPop .3s cubic-bezier(.34,1.56,.64,1);}
@keyframes vxaiPop{from{opacity:0;transform:translateY(16px) scale(.96);}to{opacity:1;transform:none;}}
.vxai-head{display:flex;align-items:center;gap:8px;padding:12px 14px;border-bottom:1px solid var(--border);}
.vxai-title{font-size:14px;font-weight:800;display:flex;align-items:center;gap:8px;flex:1;}
.vxai-title i{color:var(--accent);}
.vxai-auto{font-size:11px;font-weight:700;color:var(--muted);display:flex;align-items:center;gap:5px;cursor:pointer;white-space:nowrap;}
.vxai-auto input{accent-color:var(--accent);}
.vxai-x{background:var(--bg-surface);border:1px solid var(--border);color:var(--muted);width:30px;height:30px;border-radius:9px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.vxai-chat{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:10px;min-height:0;}
.vxai-msg{background:var(--bg-surface);border:1px solid var(--border);padding:10px 13px;border-radius:12px;font-size:13px;line-height:1.55;animation:vxaiFade .25s ease;overflow-wrap:anywhere;color:var(--text);}
.vxai-msg.user{align-self:flex-end;background:rgba(var(--accent-rgb,99,102,241),.14);border-color:rgba(var(--accent-rgb,99,102,241),.3);max-width:88%;}
.vxai-msg.ai{align-self:flex-start;max-width:94%;}
.vxai-msg.thinking{font-weight:800;background:linear-gradient(90deg,var(--muted),var(--accent),var(--muted));background-size:200% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:vxaiShimmer 1.6s linear infinite;}
@keyframes vxaiShimmer{from{background-position:200% 0;}to{background-position:-200% 0;}}
.vxai-msg h1,.vxai-msg h2,.vxai-msg h3{font-size:13px;font-weight:800;margin:6px 0 4px;color:var(--text);}
.vxai-msg ul,.vxai-msg ol{margin:4px 0 4px 18px;color:var(--text);}
.vxai-msg p{color:var(--text);}
.vxai-msg code{background:rgba(125,125,150,.18);padding:1px 6px;border-radius:6px;font-size:12px;font-family:ui-monospace,monospace;color:var(--text);}
.vxai-msg pre{background:#101018;border:1px solid var(--border);padding:10px;border-radius:9px;overflow-x:auto;margin:6px 0;color:#e8eaf0;}
.vxai-msg pre code{background:none;padding:0;color:inherit;}
.vxai-msg a{color:var(--accent);}
.vxai-msg table{width:100%;border-collapse:collapse;margin:8px 0;font-size:12px;}
.vxai-msg th,.vxai-msg td{border:1px solid var(--border);padding:6px 9px;text-align:left;color:var(--text);}
.vxai-msg th{background:rgba(var(--accent-rgb,99,102,241),.12);font-weight:800;}
.vxai-msg blockquote{border-left:3px solid var(--accent);margin:8px 0;padding:6px 12px;color:var(--muted);background:rgba(255,255,255,.03);border-radius:0 8px 8px 0;}
.vxai-msg hr{border:none;border-top:1px solid var(--border);margin:10px 0;}
.vxai-msg del{color:var(--muted);}
.vxai-tools{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;}
.vxai-tools:empty{display:none;}
.vxai-tool{background:rgba(var(--accent-rgb,99,102,241),.12);border:1px solid rgba(var(--accent-rgb,99,102,241),.4);color:var(--text);border-radius:8px;padding:3px 9px;font-size:11px;font-weight:700;}
.vxai-tooldata{width:100%;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:8px;padding:4px 9px;font-size:11px;margin-top:4px;}
.vxai-tooldata summary{cursor:pointer;font-weight:800;color:var(--text);}
.vxai-tooldata div{color:var(--muted);margin-top:4px;overflow-wrap:anywhere;}
.vxai-vision-warn{font-size:11px;color:#fbbf24;background:rgba(251,191,36,.08);border:1px solid rgba(251,191,36,.25);border-radius:8px;padding:5px 9px;margin-top:8px;}
.vxai-mfoot{display:flex;align-items:center;gap:4px;margin-top:8px;padding-top:6px;border-top:1px dashed var(--border);}
.vxai-mfoot .cr{font-size:10.5px;color:var(--muted);font-weight:700;margin-right:auto;}
.vxai-mfoot button{background:none;border:none;color:var(--muted);cursor:pointer;font-size:12px;padding:3px 6px;border-radius:6px;}
.vxai-mfoot button:hover{color:var(--accent);background:rgba(255,255,255,.06);}
@keyframes vxaiFade{from{opacity:0;transform:translateY(8px);}to{opacity:1;transform:none;}}
.vxai-confirm{border:1px dashed var(--accent);border-radius:12px;padding:10px 12px;font-size:12px;background:rgba(var(--accent-rgb,99,102,241),.07);color:var(--text);}
.vxai-confirm b{display:block;margin-bottom:8px;}
.vxai-confirm .row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
.vxai-confirm button{background:var(--accent);color:#fff;border:none;border-radius:8px;padding:7px 14px;font-size:12px;font-weight:800;cursor:pointer;font-family:inherit;}
.vxai-confirm label{font-size:11px;color:var(--muted);display:flex;gap:4px;align-items:center;cursor:pointer;}
.vxai-barwrap{padding:10px 12px 12px;border-top:1px solid var(--border);}
.vxai-chips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:6px;}
.vxai-chips:empty{display:none;}
.vxai-chip{background:rgba(255,255,255,.07);border:1px solid var(--border);border-radius:8px;padding:3px 8px;font-size:11px;display:flex;align-items:center;gap:6px;color:var(--text);}
.vxai-chip button{background:none;border:none;color:var(--muted);cursor:pointer;font-size:11px;}
.vxai-bar{background:var(--bg-surface);border:1px solid var(--border);border-radius:16px;padding:10px 10px 8px 14px;display:flex;flex-direction:column;gap:6px;}
.vxai-bar:focus-within{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb,99,102,241),.15);}
.vxai-input{width:100%;background:transparent;border:none;outline:none;color:var(--text);font-family:inherit;font-size:14px;line-height:1.45;resize:none;max-height:120px;min-height:22px;}
.vxai-toolbar{display:flex;align-items:center;justify-content:space-between;gap:4px;}
.vxai-tleft{display:flex;align-items:center;gap:2px;min-width:0;}
.vxai-anchor{position:relative;display:inline-flex;}
.vxai-btn{background:transparent;border:none;color:var(--muted);font-family:inherit;font-size:12px;font-weight:600;display:inline-flex;align-items:center;gap:5px;padding:5px 7px;border-radius:8px;cursor:pointer;white-space:nowrap;}
.vxai-btn:hover,.vxai-btn.open{background:rgba(255,255,255,.07);color:var(--text);}
.vxai-send{width:32px;height:32px;border-radius:10px;background:var(--bg-hover);color:var(--muted);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer;flex-shrink:0;}
.vxai-send.active{background:var(--accent);color:#fff;}
.vxai-send.busy{background:#3f3f46;color:#f87171;}
.vxai-menu{position:absolute;bottom:calc(100% + 8px);left:0;background:var(--bg-card);border:1px solid var(--border);border-radius:13px;padding:6px;min-width:190px;box-shadow:0 16px 36px rgba(0,0,0,.5);opacity:0;transform:translateY(8px) scale(.97);pointer-events:none;transition:opacity .2s,transform .2s;z-index:20;}
.vxai-menu.show{opacity:1;transform:none;pointer-events:auto;}
.vxai-mh{font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.5px;color:var(--dim);padding:5px 8px 3px;display:block;}
.vxai-mi{display:flex;align-items:center;gap:9px;padding:7px 10px;border-radius:8px;cursor:pointer;font-size:13px;color:var(--text);}
.vxai-mi:hover{background:rgba(255,255,255,.07);}
.vxai-mi.sel{color:var(--accent);font-weight:800;}
#vxaiMicBtn.live{color:#ef4444;animation:vxaiPulse 1.2s infinite;}
@keyframes vxaiPulse{0%,100%{transform:scale(1);}50%{transform:scale(1.15);}}
.vxai-drawer{position:absolute;inset:0;z-index:30;background:rgba(0,0,0,.55);display:none;align-items:stretch;justify-content:flex-start;}
.vxai-drawer.open{display:flex;animation:vxaiFade .2s ease;}
.vxai-sheet{width:270px;max-width:80%;background:var(--bg-card);border-right:1px solid var(--border);display:flex;flex-direction:column;animation:vxaiSlide .25s cubic-bezier(.34,1.3,.64,1);}
@keyframes vxaiSlide{from{transform:translateX(-30px);opacity:0;}to{transform:none;opacity:1;}}
.vxai-sheet-head{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid var(--border);font-size:13px;font-weight:800;}
.vxai-sheet-list{flex:1;overflow-y:auto;padding:8px;display:flex;flex-direction:column;gap:6px;}
.vxai-hist{background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:9px 11px;cursor:pointer;font-size:12px;}
.vxai-hist:hover{border-color:var(--accent);}
.vxai-hist.on{border-color:var(--accent);}
.vxai-hist b{display:block;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text);}
.vxai-hist span{font-size:10.5px;color:var(--muted);}
.vxai-hist button{background:none;border:none;color:var(--muted);cursor:pointer;float:right;font-size:11px;}
.vxai-sheet-foot{padding:12px 14px;border-top:1px solid var(--border);font-size:12px;font-weight:800;color:var(--muted);display:flex;align-items:center;gap:6px;}
.vxai-sheet-foot i{color:var(--accent);}
@media(max-width:480px){#vxAiBtn{bottom:16px;right:72px;}#vxAiPanel{bottom:134px;right:16px;height:72dvh;}#vxAiPanel .vxai-toolbar{flex-wrap:wrap;}.vxai-chat{padding:10px;}.vxai-msg{font-size:12.5px;}.vxai-sheet{width:240px;}}
</style>
<script>
(function(){
var $ = function(id){ return document.getElementById(id); };
var btn = $('vxAiBtn'), panel = $('vxAiPanel'), chat = $('vxaiChat'), input = $('vxaiInput'), sendBtn = $('vxaiSendBtn'), sendIc = $('vxaiSendIc');
if (!btn || !panel) return;
var busy = false, files = [], effort = 'High';
var lastQuota = null, curId = null;
var sessions = [];
try { sessions = JSON.parse(localStorage.getItem('vxai_chats') || '[]'); } catch (e) { sessions = []; }
var allowList = [];
try { allowList = JSON.parse(localStorage.getItem('vxai_allow') || '[]'); } catch (e) { allowList = []; }
var autoMode = false;
try { autoMode = localStorage.getItem('vxai_auto') === '1'; } catch (e) {}
var autoBox = $('vxaiAuto');
if (autoBox) { autoBox.checked = autoMode; autoBox.addEventListener('change', function(){ autoMode = autoBox.checked; try { localStorage.setItem('vxai_auto', autoMode ? '1' : '0'); } catch (e) {} }); }
function csrf(){ var m = document.querySelector('meta[name="csrf-token"]'); return m ? m.getAttribute('content') : ''; }
function saveSessions(){ try { localStorage.setItem('vxai_chats', JSON.stringify(sessions.slice(0, 20))); } catch (e) {} }
var pendingNew = null;
function cur(){
  if (pendingNew && pendingNew.id === curId) return pendingNew;
  for (var i = 0; i < sessions.length; i++) if (sessions[i].id === curId) return sessions[i];
  return null;
}
function newSession(){
  curId = 'c' + Date.now().toString(36);
  pendingNew = {id: curId, title: '', ts: Date.now(), messages: []};
  renderHist();
  return pendingNew;
}
if (!cur() && sessions.length) curId = sessions[0].id;
btn.addEventListener('click', function(){
  panel.classList.toggle('open');
  if (panel.classList.contains('open')) {
    if (!cur()) newSession();
    paint();
    setTimeout(function(){ input.focus(); }, 120);
  }
});
$('vxaiClose').addEventListener('click', function(){ panel.classList.remove('open'); try { speechSynthesis.cancel(); } catch (e) {} });
document.addEventListener('keydown', function(e){ if (e.key === 'Escape' && !document.querySelector('.vxai-drawer.open')) panel.classList.remove('open'); });
function mdInline(s){
  return s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/~~(.+?)~~/g, '<del>$1</del>')
    .replace(/`([^`\n]+)`/g, '<code>$1</code>')
    .replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
}
function md(s){
  var h = String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  h = h.replace(/```(tool|ask|json|think|thinking)[\s\S]*?```/g, '');
  h = h.replace(/<tool-call>[\s\S]*?<\/tool-call>/g, '');
  var pres = [];
  h = h.replace(/```([\s\S]*?)```/g, function(m, c){ pres.push('<pre><code>' + c.replace(/^\n+|\n+$/g, '') + '</code></pre>'); return '\u0000PRE' + (pres.length - 1) + '\u0000'; });
  h = h.replace(/^### (.+)$/gm, '<h3>$1</h3>').replace(/^## (.+)$/gm, '<h2>$1</h2>').replace(/^# (.+)$/gm, '<h1>$1</h1>');
  h = h.replace(/^&gt; ?(.*)$/gm, '<blockquote>$1</blockquote>');
  h = h.replace(/^(\*\*\*|---|___)\s*$/gm, '<hr>');
  var lines = h.split('\n'), out = '', inUl = false, inOl = false, i = 0;
  function closeLists(){ if (inUl) { out += '</ul>'; inUl = false; } if (inOl) { out += '</ol>'; inOl = false; } }
  while (i < lines.length) {
    var t = lines[i].trim();
    var tm = t.match(/^\|(.+)\|$/);
    if (tm && i + 1 < lines.length && /^\|[\s:\-|]+\|$/.test(lines[i + 1].trim())) {
      closeLists();
      var heads = tm[1].split('|').map(function(c){ return c.trim(); });
      out += '<table><thead><tr>' + heads.map(function(c){ return '<th>' + c + '</th>'; }).join('') + '</tr></thead><tbody>';
      i += 2;
      while (i < lines.length && /^\|(.+)\|$/.test(lines[i].trim())) {
        var cells = lines[i].trim().slice(1, -1).split('|').map(function(c){ return c.trim(); });
        out += '<tr>' + cells.map(function(c){ return '<td>' + c + '</td>'; }).join('') + '</tr>';
        i++;
      }
      out += '</tbody></table>';
      continue;
    }
    if (/^[-*] /.test(t)) { if (inOl) { out += '</ol>'; inOl = false; } if (!inUl) { out += '<ul>'; inUl = true; } out += '<li>' + t.slice(2) + '</li>'; i++; continue; }
    if (/^\d+\. /.test(t)) { if (inUl) { out += '</ul>'; inUl = false; } if (!inOl) { out += '<ol>'; inOl = true; } out += '<li>' + t.replace(/^\d+\. /, '') + '</li>'; i++; continue; }
    closeLists();
    if (t !== '') out += (/^<(h[123]|blockquote|hr|table|pre|ul|ol)/.test(t)) ? t : '<p>' + t + '</p>';
    i++;
  }
  closeLists();
  out = mdInline(out);
  out = out.replace(/\u0000PRE(\d+)\u0000/g, function(m, n){ return pres[parseInt(n, 10)] || ''; });
  return out;
}
function stripTags(s){ var d = document.createElement('div'); d.innerHTML = s; return d.textContent || ''; }
function pushMsg(role, html, credits, extra){
  var s = cur() || newSession();
  if (sessions.indexOf(s) === -1) { sessions.unshift(s); if (pendingNew && pendingNew.id === s.id) pendingNew = null; }
  var m = {role: role, html: html, credits: credits || 0, ts: Date.now()};
  if (extra && extra.tools) m.tools = extra.tools;
  if (extra && extra.tool_data) m.tool_data = extra.tool_data;
  s.messages.push(m);
  if (s.messages.length === 1 && role === 'user') s.title = stripTags(html).slice(0, 42) || 'Sohbet';
  saveSessions();
  renderHist();
}
function bubble(role, html, credits){
  var d = document.createElement('div');
  d.className = 'vxai-msg ' + role;
  d.innerHTML = '<div class="vxai-body">' + html + '</div>';
  if (role === 'ai') {
    var tools = document.createElement('div');
    tools.className = 'vxai-tools';
    d.appendChild(tools);
    var foot = document.createElement('div');
    foot.className = 'vxai-mfoot';
    var cr = document.createElement('span');
    cr.className = 'cr';
    if (credits) cr.textContent = '⚡' + credits + ' ' + <?= json_encode(__('vai.credits')) ?>;
    foot.appendChild(cr);
    var cp = document.createElement('button');
    cp.innerHTML = '<i class="fa-regular fa-copy"></i>';
    cp.title = <?= json_encode(__('vai.copy')) ?>;
    cp.addEventListener('click', function(){
      var t = stripTags(d.querySelector('.vxai-body').innerHTML);
      if (navigator.clipboard) navigator.clipboard.writeText(t).then(function(){ cp.innerHTML = '<i class="fa-solid fa-check"></i>'; setTimeout(function(){ cp.innerHTML = '<i class="fa-regular fa-copy"></i>'; }, 1200); });
      else { var ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch (e) {} ta.remove(); }
    });
    foot.appendChild(cp);
    var sp = document.createElement('button');
    sp.innerHTML = '<i class="fa-solid fa-volume-high"></i>';
    sp.title = <?= json_encode(__('vai.speak')) ?>;
    sp.addEventListener('click', function(){ speak(stripTags(d.querySelector('.vxai-body').innerHTML)); });
    foot.appendChild(sp);
    d.appendChild(foot);
    d._toolsBox = tools;
  }
  chat.appendChild(d);
  chat.scrollTop = chat.scrollHeight;
  return d;
}
function paint(){
  chat.innerHTML = '';
  var s = cur();
  if (!s) return;
  s.messages.forEach(function(m){
    if (m.role === 'confirm') return;
    var d = bubble(m.role, m.html, m.credits);
    if (m.role === 'ai' && m.tools && m.tools.length && d._toolsBox) {
      m.tools.forEach(function(t){
        var chip = document.createElement('span');
        chip.className = 'vxai-tool';
        chip.textContent = '🔧 ' + t;
        d._toolsBox.appendChild(chip);
      });
    }
    if (m.role === 'ai' && m.tool_data && m.tool_data.length) showToolData(d, m.tool_data);
  });
}
function showToolData(d, rows){
  if (!d._toolsBox) return;
  rows.forEach(function(r){
    var det = document.createElement('details');
    det.className = 'vxai-tooldata';
    var sm = document.createElement('summary');
    sm.textContent = (r.ok ? '✓ ' : '✗ ') + (r.name || 'tool');
    det.appendChild(sm);
    var pv = document.createElement('div');
    pv.textContent = r.summary || '';
    det.appendChild(pv);
    d._toolsBox.appendChild(det);
  });
}
function showTools(d, names){
  if (!names || !names.length || !d._toolsBox) return;
  names.forEach(function(t){
    var chip = document.createElement('span');
    chip.className = 'vxai-tool';
    chip.textContent = '🔧 ' + t;
    d._toolsBox.appendChild(chip);
  });
  var s = cur();
  if (s && s.messages.length) {
    var last = s.messages[s.messages.length - 1];
    if (last.role === 'ai') last.tools = names;
  }
  saveSessions();
}
function speak(text){
  try {
    speechSynthesis.cancel();
    var u = new SpeechSynthesisUtterance(String(text).replace(/[#*`>\-]/g, '').slice(0, 500));
    u.lang = 'tr-TR';
    speechSynthesis.speak(u);
  } catch (e) {}
}
function setBusy(b){
  busy = b;
  sendBtn.className = 'vxai-send' + (b ? ' busy' : (input.value.trim() ? ' active' : ''));
  sendIc.className = b ? 'fa-solid fa-square' : 'fa-solid fa-arrow-up';
}
input.addEventListener('input', function(){
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 120) + 'px';
  if (!busy) sendBtn.className = 'vxai-send' + (input.value.trim() ? ' active' : '');
});
input.addEventListener('keydown', function(e){
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSend(); }
});
function post(action, fd){
  fd.append('action', action);
  return fetch('/action.php', {method: 'POST', headers: {'X-CSRF-Token': csrf(), 'X-Requested-With': 'XMLHttpRequest'}, body: fd});
}
function histForServer(){
  var s = cur();
  if (!s) return [];
  return s.messages.slice(-10).filter(function(m){ return m.role !== 'confirm'; }).map(function(m){ return {role: m.role, content: stripTags(m.html).slice(0, 1200)}; });
}
function doSend(){
  try { speechSynthesis.cancel(); } catch (e) {}
  if (busy) return;
  var text = input.value.trim();
  if (!text && !files.length) return;
  var disp = '';
  var previews = [];
  files.forEach(function(f){
    try {
      if (f.file && f.file.type && f.file.type.indexOf('image/') === 0 && window.URL) previews.push(URL.createObjectURL(f.file));
    } catch (e) {}
  });
  previews.forEach(function(u){
    disp += '<img src="' + u + '" style="max-width:100%;max-height:140px;border-radius:10px;margin-bottom:6px;display:block;" alt="">';
  });
  disp += text ? String(text).replace(/&/g,'&amp;').replace(/</g,'&lt;') : '';
  if (files.length) disp += '<br><small>📎 ' + files.map(function(f){ return f.name.replace(/</g,'&lt;'); }).join(', ') + '</small>';
  bubble('user', disp);
  input.value = ''; input.style.height = 'auto';
  var up = files.slice(0, 3);
  files = []; renderChips();
  setBusy(true);
  var thinking = bubble('ai', <?= json_encode(__('vai.thinking')) ?>);
  thinking.classList.add('thinking');
  var fd = new FormData();
  fd.append('message', text);
  fd.append('effort', effort);
  fd.append('history', JSON.stringify(histForServer()));
  up.forEach(function(f){ fd.append('files[]', f.file, f.name); });
  post('ai_chat', fd).then(function(r){ return r.json(); }).then(function(d){
    thinking.remove();
    setBusy(false);
    if (d && d.ok && d.needs_confirm) {
      var items = (d.tools && d.tools.length) ? d.tools : [{tool: d.tool, args: d.args || {}, confirm_msg: d.confirm_msg}];
      var allAllowed = items.every(function(it){ return autoMode || allowList.indexOf(it.tool) !== -1; });
      if (allAllowed) {
        (function next(i){
          if (i >= items.length) { bubble('ai', '✓'); return; }
          approveTool(items[i].tool, items[i].args || {}, true, function(){ next(i + 1); });
        })(0);
        return;
      }
      askConfirmList(items);
      if (d.quota) setQuota(d.quota);
      return;
    }
    if (d && d.ok) {
      var tools = d.tool_calls && d.tool_calls.map ? d.tool_calls.map(function(t){ return t.name || t; }) : [];
      var rhtml = md(d.reply || '');
      pushMsg('ai', rhtml, d.credits || 0);
      var b = bubble('ai', rhtml);
      showTools(b, tools);
      if (d.vision_dropped) {
        var vw = document.createElement('div');
        vw.className = 'vxai-vision-warn';
        vw.textContent = '⚠ ' + <?= json_encode(__('vai.no_vision')) ?>;
        b.appendChild(vw);
      }
      if (d.tool_data && d.tool_data.length) showToolData(b, d.tool_data);
      if (d.quota) setQuota(d.quota);
      var s = cur();
      if (s && s.messages.length === 2 && !s.title) { s.title = stripTags(disp).slice(0, 42); saveSessions(); renderHist(); }
      return;
    }
    pushMsg('ai', String((d && d.msg) || <?= json_encode(__('vai.conn_fail')) ?>));
    bubble('ai', String((d && d.msg) || <?= json_encode(__('vai.conn_fail')) ?>).replace(/</g, '&lt;'));
  }).catch(function(){
    thinking.remove();
    setBusy(false);
    bubble('ai', <?= json_encode(__('vai.conn_fail')) ?>);
  });
}
sendBtn.addEventListener('click', doSend);
function renderChips(){
  var w = $('vxaiChips');
  w.innerHTML = '';
  files.forEach(function(f, i){
    var c = document.createElement('span');
    c.className = 'vxai-chip';
    c.innerHTML = '📎 ' + String(f.name).replace(/</g,'&lt;') + ' ';
    var x = document.createElement('button');
    x.textContent = '✕';
    x.addEventListener('click', function(){ files.splice(i, 1); renderChips(); });
    c.appendChild(x);
    w.appendChild(c);
  });
  if (!busy) sendBtn.className = 'vxai-send' + ((input.value.trim() || files.length) ? ' active' : '');
}
function toggleMenu(id, ev){
  if (ev) ev.stopPropagation();
  var m = $(id);
  var was = m.classList.contains('show');
  document.querySelectorAll('.vxai-menu').forEach(function(x){ x.classList.remove('show'); });
  if (!was) m.classList.add('show');
}
document.addEventListener('click', function(e){
  if (e.target.closest && (e.target.closest('#vxAiPanel') || e.target.closest('#vxAiBtn'))) { document.querySelectorAll('.vxai-menu').forEach(function(x){ x.classList.remove('show'); }); return; }
  panel.classList.remove('open');
  document.querySelectorAll('.vxai-menu').forEach(function(x){ x.classList.remove('show'); });
});
$('vxaiAddBtn').addEventListener('click', function(e){ toggleMenu('vxaiAddMenu', e); });
$('vxaiModelBtn').addEventListener('click', function(e){ toggleMenu('vxaiModelMenu', e); });
$('vxaiEffortBtn').addEventListener('click', function(e){ toggleMenu('vxaiEffortMenu', e); });
(function(){
  var em = $('vxaiEffortMenu');
  ['Low', 'Medium', 'High', 'Max'].forEach(function(o){
    var s = document.createElement('span');
    s.className = 'vxai-mi' + (o === effort ? ' sel' : '');
    s.textContent = o;
    s.addEventListener('click', function(){
      effort = o;
      $('vxaiEffortCur').textContent = o;
      em.querySelectorAll('.vxai-mi').forEach(function(x){ x.classList.remove('sel'); });
      s.classList.add('sel');
      em.classList.remove('show');
    });
    em.appendChild(s);
  });
})();
$('vxaiHelpMi').addEventListener('click', function(){ input.value = '/help '; input.focus(); $('vxaiAddMenu').classList.remove('show'); });
$('vxaiUploadMi').addEventListener('click', function(){ $('vxaiAddMenu').classList.remove('show'); $('vxaiFile').click(); });
$('vxaiFile').addEventListener('change', function(){
  var list = this.files ? Array.prototype.slice.call(this.files, 0, 3) : [];
  this.value = '';
  list.forEach(function(f){
    if (files.length >= 3) return;
    files.push({name: f.name, file: f});
  });
  renderChips();
  if (!busy) sendBtn.className = 'vxai-send' + ((input.value.trim() || files.length) ? ' active' : '');
});
var rec = null;
$('vxaiMicBtn').addEventListener('click', function(){
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return;
  if (rec) { try { rec.stop(); } catch (e) {} rec = null; $('vxaiMicBtn').classList.remove('live'); return; }
  rec = new SR();
  rec.lang = 'tr-TR';
  rec.onresult = function(e){
    var t = e.results[0][0].transcript;
    input.value = (input.value ? input.value + ' ' : '') + t;
    input.dispatchEvent(new Event('input'));
  };
  rec.onend = function(){ rec = null; $('vxaiMicBtn').classList.remove('live'); input.focus(); };
  try { rec.start(); $('vxaiMicBtn').classList.add('live'); } catch (e) { rec = null; }
});
function askConfirm(name, args, msg){
  askConfirmList([{tool: name, args: args, confirm_msg: msg}]);
}
function askConfirmList(items){
  var d = document.createElement('div');
  d.className = 'vxai-msg ai';
  var rows = items.map(function(it){ return '• `' + String(it.tool || '?').replace(/</g, '&lt;') + '`'; }).join('<br>');
  d.innerHTML = '<div class="vxai-confirm"><b>' + <?= json_encode(__('vai.confirm_title')) ?> + ' (' + items.length + ')</b><div>' + rows + '</div><div class="row" style="margin-top:8px;"><button>' + <?= json_encode(__('vai.confirm_run')) ?> + '</button><label><input type="checkbox"> ' + <?= json_encode(__('vai.always_allow')) ?> + '</label></div></div>';
  chat.appendChild(d);
  chat.scrollTop = chat.scrollHeight;
  pushMsg('confirm', items.map(function(it){ return it.tool; }).join(','));
  d.querySelector('button').addEventListener('click', function(){
    var al = d.querySelector('input[type="checkbox"]');
    if (al && al.checked) {
      items.forEach(function(it){
        if (allowList.indexOf(it.tool) === -1) allowList.push(it.tool);
      });
      try { localStorage.setItem('vxai_allow', JSON.stringify(allowList)); } catch (e) {}
    }
    d.remove();
    (function next(i){
      if (i >= items.length) return;
      approveTool(items[i].tool, items[i].args || {}, false, function(){ next(i + 1); });
    })(0);
  });
}
function approveTool(name, args, silent, done){
  var a2 = {};
  for (var k in args) a2[k] = args[k];
  a2.confirm = true;
  var fd = new FormData();
  fd.append('tool', name);
  fd.append('args', JSON.stringify(a2));
  post('ai_tool_run', fd).then(function(r){ return r.json(); }).then(function(d2){
    if (d2 && d2.ok) {
      var label = String(d2.label || name).replace(/</g, '&lt;');
      var link = String(d2.url || '');
      var htm = '✓ ' + label;
      if (/^\/admin\//.test(link)) htm += ' <a href="' + link.replace(/"/g, '') + '">→</a>';
      pushMsg('ai', htm);
      var b = bubble('ai', htm);
      showTools(b, [name]);
    } else if (d2) {
      pushMsg('ai', String(d2.msg || ''));
      bubble('ai', String(d2.msg || '').replace(/</g, '&lt;'));
    }
    if (done) done();
  }).catch(function(){ bubble('ai', <?= json_encode(__('vai.conn_fail')) ?>); if (done) done(); });
}
window.vxaiRunTool = function(name, args, opts){
  opts = opts || {};
  args = args || {};
  if (autoMode || allowList.indexOf(name) !== -1) args.confirm = true;
  var fd = new FormData();
  fd.append('tool', name);
  fd.append('args', JSON.stringify(args));
  post('ai_tool_run', fd).then(function(r){ return r.json(); }).then(function(d){
    if (d && d.needs_confirm) { askConfirm(name, args, d.msg); return; }
    if (opts.done) opts.done(d);
  }).catch(function(){});
};
function renderHist(){
  var w = $('vxaiHistList');
  w.innerHTML = '';
  if (!sessions.length) { w.innerHTML = '<div style="font-size:12px;color:var(--muted);padding:8px;">' + <?= json_encode(__('vai.no_history')) ?> + '</div>'; return; }
  sessions.forEach(function(s){
    var d = document.createElement('div');
    d.className = 'vxai-hist' + (s.id === curId ? ' on' : '');
    var x = document.createElement('button');
    x.textContent = '✕';
    x.addEventListener('click', function(ev){
      ev.stopPropagation();
      sessions = sessions.filter(function(z){ return z.id !== s.id; });
      if (curId === s.id) curId = sessions.length ? sessions[0].id : null;
      saveSessions();
      renderHist();
      paint();
    });
    d.appendChild(x);
    var b = document.createElement('b');
    b.textContent = s.title || 'Sohbet';
    d.appendChild(b);
    var sp = document.createElement('span');
    try { sp.textContent = new Date(s.ts).toLocaleDateString(); } catch (e) { sp.textContent = ''; }
    d.appendChild(sp);
    d.addEventListener('click', function(){
      curId = s.id;
      saveSessions();
      renderHist();
      paint();
      $('vxaiDrawer').classList.remove('open');
    });
    w.appendChild(d);
  });
}
$('vxaiHistBtn').addEventListener('click', function(){
  renderHist();
  $('vxaiDrawer').classList.add('open');
});
$('vxaiDrawerClose').addEventListener('click', function(){ $('vxaiDrawer').classList.remove('open'); });
$('vxaiDrawer').addEventListener('click', function(e){ if (e.target === this) this.classList.remove('open'); });
$('vxaiNewChat').addEventListener('click', function(){ newSession(); paint(); $('vxaiDrawer').classList.remove('open'); input.focus(); });
function setQuota(q){
  lastQuota = q;
  var el = $('vxaiQuotaFoot');
  if (!q) { el.innerHTML = ''; return; }
  var left = (q.left !== undefined) ? q.left : '?';
  var lim = (q.limit !== undefined) ? q.limit : '?';
  el.innerHTML = '<i class="fa-solid fa-bolt"></i> ' + <?= json_encode(__('vai.quota_left')) ?> + ': <b>' + left + ' / ' + lim + '</b>';
}
renderHist();
})();
</script>
