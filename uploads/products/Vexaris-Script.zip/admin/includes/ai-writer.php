<?php
if (!defined('NEXUS_BOOT')) { http_response_code(403); exit; }
?>
<div id="vxwOverlay" onclick="if(event.target===this)vxwClose()">
  <div class="vxw-box" role="dialog" aria-modal="true">
    <div class="vxw-head">
      <span class="vxw-title"><i class="fa-solid fa-wand-magic-sparkles"></i> <span id="vxwTitle">AI Yazar</span></span>
      <button class="vxw-x" onclick="vxwClose()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="vxw-promptrow">
      <textarea id="vxwPrompt" rows="2"></textarea>
      <button class="vxw-send" id="vxwSend"><i class="fa-solid fa-arrow-up"></i></button>
    </div>
    <div class="vxw-think" id="vxwThink"><span></span><span></span><span></span><span class="vxw-thinktxt">Düşünüyor</span></div>
    <div class="vxw-asks" id="vxwAsks"></div>
    <div class="vxw-out" id="vxwOut"></div>
    <div class="vxw-foot">
      <button class="vxw-ghost" id="vxwRegen" style="display:none;"><i class="fa-solid fa-rotate"></i></button>
      <button class="vxw-approve" id="vxwApprove" style="display:none;"><i class="fa-solid fa-check"></i> <span id="vxwApproveTx">Onayla</span></button>
    </div>
  </div>
</div>
<style>
#vxwOverlay{position:fixed;inset:0;z-index:100002;background:rgba(0,0,0,.72);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);display:none;align-items:center;justify-content:center;padding:16px;overflow-y:auto;}
#vxwOverlay.open{display:flex;}
#vxwOverlay.as-embed{position:static;background:none;backdrop-filter:none;-webkit-backdrop-filter:none;padding:0;overflow:visible;}
#vxwOverlay.as-embed.open{display:block;}
#vxwOverlay.as-embed .vxw-box{max-width:none;animation:vxwFade .25s ease;}
.vxw-out>*{animation:vxwFade .3s ease;}
.vxw-box{width:100%;max-width:620px;max-height:92dvh;display:flex;flex-direction:column;background:var(--bg-card);border:1px solid rgba(var(--accent-rgb,99,102,241),.35);border-radius:22px;box-shadow:0 30px 90px rgba(0,0,0,.6),0 0 40px rgba(var(--accent-rgb,99,102,241),.12);overflow:hidden;animation:vxwPop .32s cubic-bezier(.34,1.56,.64,1);}
@keyframes vxwPop{from{opacity:0;transform:translateY(20px) scale(.96);}to{opacity:1;transform:none;}}
.vxw-head{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid var(--border);background:linear-gradient(135deg,rgba(var(--accent-rgb,99,102,241),.14),transparent);}
.vxw-title{font-size:14px;font-weight:900;display:flex;align-items:center;gap:8px;}
.vxw-title i{color:var(--accent);animation:vxwShine 2.4s ease-in-out infinite;}
@keyframes vxwShine{0%,100%{opacity:1;transform:scale(1);}50%{opacity:.6;transform:scale(1.15);}}
.vxw-x{background:var(--bg-surface);border:1px solid var(--border);color:var(--muted);width:30px;height:30px;border-radius:9px;cursor:pointer;display:flex;align-items:center;justify-content:center;}
.vxw-promptrow{display:flex;gap:8px;padding:12px 14px 6px;align-items:flex-end;}
.vxw-promptrow textarea{flex:1;min-width:0;background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;padding:9px 12px;color:var(--text);font-family:inherit;font-size:13px;resize:none;outline:none;min-height:38px;max-height:110px;}
.vxw-promptrow textarea:focus{border-color:var(--accent);}
.vxw-send{width:38px;height:38px;flex-shrink:0;border-radius:12px;border:none;background:var(--accent);color:#fff;cursor:pointer;font-size:15px;display:flex;align-items:center;justify-content:center;}
.vxw-send:disabled{opacity:.5;cursor:wait;}
.vxw-think{display:none;gap:6px;justify-content:center;padding:14px;}
.vxw-think.on{display:flex;}
.vxw-think span{width:9px;height:9px;border-radius:50%;background:var(--accent);animation:vxwB 1s infinite;}
.vxw-think span:nth-child(2){animation-delay:.15s;}
.vxw-think span:nth-child(3){animation-delay:.3s;}
@keyframes vxwB{0%,100%{opacity:.3;transform:translateY(0);}50%{opacity:1;transform:translateY(-5px);}}
.vxw-thinktxt{font-size:12px;font-weight:800;background:linear-gradient(90deg,var(--muted),var(--accent),var(--muted));background-size:200% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:vxwShimmer 1.6s linear infinite;margin-left:8px;}
@keyframes vxwShimmer{from{background-position:200% 0;}to{background-position:-200% 0;}}
.vxw-asks{display:flex;flex-wrap:wrap;gap:8px;padding:0 14px;}
.vxw-asks:empty{display:none;}
.vxw-asks.has{padding:10px 14px 0;}
.vxw-ask{background:rgba(var(--accent-rgb,99,102,241),.1);border:1px solid rgba(var(--accent-rgb,99,102,241),.35);border-radius:12px;padding:10px 12px;font-size:12.5px;width:100%;}
.vxw-ask b{display:block;margin-bottom:6px;}
.vxw-ask button{background:var(--bg-surface);border:1px solid var(--border);color:var(--text);border-radius:8px;padding:5px 10px;font-size:12px;font-family:inherit;cursor:pointer;margin:0 6px 4px 0;}
.vxw-ask button:hover{border-color:var(--accent);}
.vxw-out{padding:12px 18px;overflow-y:auto;max-height:44dvh;font-size:13.5px;line-height:1.65;min-height:0;}
.vxw-out:empty{display:none;}
.vxw-out h2{font-size:16px;font-weight:900;margin:8px 0 4px;}
.vxw-out h3{font-size:14px;font-weight:800;margin:8px 0 4px;}
.vxw-out ul,.vxw-out ol{margin:4px 0 4px 20px;}
.vxw-out code{background:rgba(255,255,255,.08);padding:1px 6px;border-radius:6px;font-size:12px;}
.vxw-out pre{background:rgba(0,0,0,.35);padding:10px;border-radius:9px;overflow-x:auto;}
.vxw-out a{color:var(--accent);}
.vxw-foot{display:flex;gap:8px;justify-content:flex-end;padding:12px 14px;border-top:1px solid var(--border);}
.vxw-foot:empty{display:none;}
.vxw-approve{background:linear-gradient(135deg,var(--accent),#7c3aed);color:#fff;border:none;border-radius:11px;padding:10px 22px;font-size:13px;font-weight:900;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:8px;}
.vxw-ghost{background:var(--bg-surface);border:1px solid var(--border);color:var(--muted);border-radius:11px;padding:10px 14px;cursor:pointer;font-family:inherit;}
@media(max-width:560px){.vxw-box{border-radius:18px;}#vxwOverlay{padding:10px;}.vxw-out{max-height:52dvh;}}
</style>
<script>
var _vxw = {context: 'product_desc', mode: 'html', data: {}, lastReply: '', lastSeo: null};
var _vxwPlace = null, _vxwTarget = null;
function vxwCsrf(){ var m = document.querySelector('meta[name="csrf-token"]'); return m ? m.getAttribute('content') : ''; }
function vxwOpen(opts){
  opts = opts || {};
  _vxw.context = opts.context || 'product_desc';
  _vxw.mode = opts.mode || 'html';
  _vxw.data = opts.data || {};
  _vxw.onApprove = opts.onApprove || null;
  _vxw.lastReply = '';
  _vxw.lastSeo = null;
  document.getElementById('vxwTitle').textContent = opts.title || 'AI Yazar';
  document.getElementById('vxwPrompt').placeholder = opts.hint || '';
  document.getElementById('vxwPrompt').value = '';
  document.getElementById('vxwApproveTx').textContent = opts.approve || 'Onayla';
  document.getElementById('vxwOut').innerHTML = '';
  document.getElementById('vxwAsks').innerHTML = '';
  document.getElementById('vxwAsks').className = 'vxw-asks';
  document.getElementById('vxwApprove').style.display = 'none';
  document.getElementById('vxwRegen').style.display = 'none';
  var ov = document.getElementById('vxwOverlay');
  var emb = opts.embed ? document.getElementById(opts.embed) : null;
  if (emb) {
    if (!_vxwPlace || _vxwPlace.parentNode !== emb.parentNode) { _vxwPlace = document.createComment('vxw'); emb.parentNode.insertBefore(_vxwPlace, emb); }
    _vxwTarget = emb;
    emb.style.display = 'none';
    ov.classList.add('as-embed');
    if (_vxwPlace.parentNode) _vxwPlace.parentNode.insertBefore(ov, _vxwPlace.nextSibling);
  } else {
    ov.classList.remove('as-embed');
  }
  ov.classList.add('open');
  setTimeout(function(){ document.getElementById('vxwPrompt').focus(); }, 120);
}
function vxwClose(){
  var ov = document.getElementById('vxwOverlay');
  ov.classList.remove('open');
  ov.classList.remove('as-embed');
  if (_vxwTarget) { _vxwTarget.style.display = ''; _vxwTarget = null; }
}
function vxwMd(src){
  var h = String(src == null ? '' : src).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  h = h.replace(/```(tool|think|thinking|json)[\s\S]*?```/g, '');
  h = h.replace(/<tool-call>[\s\S]*?<\/tool-call>/g, '');
  h = h.replace(/^### (.+)$/gm, '<h3>$1</h3>').replace(/^## (.+)$/gm, '<h2>$1</h2>').replace(/^# (.+)$/gm, '<h2>$1</h2>');
  h = h.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/`([^`\n]+)`/g, '<code>$1</code>');
  h = h.replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  var lines = h.split('\n'), out = '', inUl = false, inOl = false;
  lines.forEach(function(ln){
    var t = ln.trim();
    if (/^[-*] /.test(t)) { if (!inUl) { out += '<ul>'; inUl = true; } out += '<li>' + t.slice(2) + '</li>'; return; }
    if (/^\d+\. /.test(t)) { if (!inOl) { out += '<ol>'; inOl = true; } out += '<li>' + t.replace(/^\d+\. /, '') + '</li>'; return; }
    if (inUl) { out += '</ul>'; inUl = false; }
    if (inOl) { out += '</ol>'; inOl = false; }
    if (t !== '') out += '<p>' + t + '</p>';
  });
  if (inUl) out += '</ul>';
  if (inOl) out += '</ol>';
  return out;
}
function vxwAskParse(src){
  var m = String(src || '').match(/```ask\s*(\{[\s\S]*?\})\s*```/);
  if (!m) return null;
  try {
    var d = JSON.parse(m[1]);
    if (d && Array.isArray(d.questions) && d.questions.length) return d.questions.slice(0, 4);
  } catch (e) {}
  return null;
}
function vxwSeoParse(src){
  var m = String(src || '').match(/```json\s*(\{[\s\S]*?\})\s*```/);
  if (!m) return null;
  try {
    var d = JSON.parse(m[1]);
    if (d && (d.title || d.desc)) return {title: String(d.title || '').slice(0, 100), desc: String(d.desc || '').slice(0, 200)};
  } catch (e) {}
  return null;
}
function vxwRender(reply){
  _vxw.lastReply = reply;
  var asks = vxwAskParse(reply);
  var box = document.getElementById('vxwAsks');
  box.innerHTML = '';
  if (asks) {
    box.className = 'vxw-asks has';
    asks.forEach(function(q){
      var d = document.createElement('div');
      d.className = 'vxw-ask';
      var b = document.createElement('b');
      b.textContent = q.q || '';
      d.appendChild(b);
      (q.options || []).forEach(function(o){
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = o;
        btn.addEventListener('click', function(){
          var p = document.getElementById('vxwPrompt');
          p.value = (p.value ? p.value + ' ' : '') + o;
          p.focus();
        });
        d.appendChild(btn);
      });
      box.appendChild(d);
    });
  } else {
    box.className = 'vxw-asks';
  }
  if (_vxw.mode === 'seo') {
    var sj = vxwSeoParse(reply);
    _vxw.lastSeo = sj;
    document.getElementById('vxwOut').innerHTML = sj ? ('<p><strong>' + sj.title.replace(/</g, '&lt;') + '</strong></p><p>' + sj.desc.replace(/</g, '&lt;') + '</p>') : vxwMd(reply);
  } else {
    document.getElementById('vxwOut').innerHTML = vxwMd(reply);
  }
  var ok = _vxw.mode === 'seo' ? !!_vxw.lastSeo : document.getElementById('vxwOut').textContent.trim() !== '';
  document.getElementById('vxwApprove').style.display = ok ? '' : 'none';
  document.getElementById('vxwRegen').style.display = '';
}
function vxwSend(regen){
  var p = document.getElementById('vxwPrompt');
  var text = regen ? (p.getAttribute('data-last') || '') : p.value.trim();
  if (!text) { p.focus(); return; }
  p.setAttribute('data-last', text);
  if (!regen) p.value = '';
  document.getElementById('vxwThink').classList.add('on');
  document.getElementById('vxwSend').disabled = true;
  document.getElementById('vxwApprove').style.display = 'none';
  var fd = new FormData();
  fd.append('action', 'ai_write');
  fd.append('context', _vxw.context);
  fd.append('prompt', text);
  Object.keys(_vxw.data).forEach(function(k){ fd.append(k, _vxw.data[k]); });
  fetch('/action.php', {method: 'POST', headers: {'X-CSRF-Token': vxwCsrf(), 'X-Requested-With': 'XMLHttpRequest'}, body: fd}).then(function(r){ return r.json(); }).then(function(d){
    document.getElementById('vxwThink').classList.remove('on');
    document.getElementById('vxwSend').disabled = false;
    if (d && d.ok) vxwRender(d.reply || '');
    else document.getElementById('vxwOut').innerHTML = '<p>' + String((d && d.msg) || 'Hata').replace(/</g, '&lt;') + '</p>';
  }).catch(function(){
    document.getElementById('vxwThink').classList.remove('on');
    document.getElementById('vxwSend').disabled = false;
  });
}
document.getElementById('vxwSend').addEventListener('click', function(){ vxwSend(false); });
document.getElementById('vxwRegen').addEventListener('click', function(){ vxwSend(true); });
document.getElementById('vxwPrompt').addEventListener('keydown', function(e){
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); vxwSend(false); }
});
document.getElementById('vxwApprove').addEventListener('click', function(){
  if (typeof _vxw.onApprove !== 'function') { vxwClose(); return; }
  if (_vxw.mode === 'seo') _vxw.onApprove(_vxw.lastSeo);
  else _vxw.onApprove(document.getElementById('vxwOut').innerHTML);
  vxwClose();
});
document.addEventListener('keydown', function(e){ if (e.key === 'Escape') vxwClose(); });
</script>
