<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__, 2));

require_once ROOT_PATH . '/core/init.php';

if (function_exists('feature_active') && !feature_active('admin_panel')) {
    http_response_code(404);
    echo "<!DOCTYPE html><html lang='" . lang_active() . "'><head><meta charset='UTF-8'><title>404</title></head>"
       . "<body style='margin:0;font-family:sans-serif;background:#0b0f17;color:#e2e8f0;height:100vh;display:flex;align-items:center;justify-content:center;'>"
       . "<div style='text-align:center;'><h1 style='font-size:3rem;margin:0;color:#64748b;'>404</h1>"
       . "<p style='color:#94a3b8;'>" . __('err.e404_title') . "</p></div></body></html>";
    exit;
}
license_gate_require('admin_panel');

if (!auth_check()) {
    header('Location: /login', true, 302);
    exit;
}

$_db = nexus_db();
if ($_db) {
    try {
        $stmt = $_db->prepare('SELECT role FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$_SESSION['user']['id']]);
        $freshRow = $stmt->fetch();
        if ($freshRow) {
            $_SESSION['user']['role'] = $freshRow['role'];
        }
    } catch (Exception $e) {}
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
}

$adminUser = $_SESSION['user'];
$adminDb   = nexus_db();

function has_permission(string $resource): bool {
    global $adminDb, $adminUser;
    $role = $adminUser['role'] ?? 'user';
    if ($role === 'superadmin' || $role === 'admin') return true;
    try {
        $st = $adminDb->prepare('SELECT COUNT(*) FROM permissions WHERE role = ? AND resource = ?');
        $st->execute([$role, $resource]);
        return (int)$st->fetchColumn() > 0;
    } catch (Exception $e) {
        return false;
    }
}

function has_any_permission(): bool {
    global $adminDb, $adminUser;
    $role = $adminUser['role'] ?? 'user';
    if ($role === 'superadmin' || $role === 'admin') return true;
    try {
        $st = $adminDb->prepare('SELECT COUNT(*) FROM permissions WHERE role = ?');
        $st->execute([$role]);
        return (int)$st->fetchColumn() > 0;
    } catch (Exception $e) {
        return false;
    }
}

$rawPage = basename($_SERVER['PHP_SELF'], '.php');
$pageResource = $rawPage;
$resourceMap = [
    'header-editor'        => 'themes',
    'footer-editor'        => 'themes',
    'module'               => 'modules',
    'product-editor'     => 'products',
    'announcement-editor'=> 'announcements',
    'tickets'            => 'support',
    'ticket-categories'  => 'ticket_categories',
    'custom-pages'       => 'custom_pages',
    'custom-css'         => 'themes',
    'faqs'               => 'products',
    'reviews'            => 'reviews',
    'purchases'          => 'purchases',
    'mail-settings'      => 'settings',
    'mail-templates'     => 'settings',
    'update'             => 'settings',
    'slider'             => 'slider',
    'guard'              => 'dashboard',
    'layout'             => 'dashboard',
    'layout-end'         => 'dashboard',
];
$pageResource = $resourceMap[$pageResource] ?? $pageResource;

$featureMap = [
    'seo'                  => 'seo',
    'announcements'        => 'announcements',
    'announcement-editor'  => 'announcements',
    'coupons'              => 'coupons',
    'custom-pages'         => 'custom_pages',
    'references'           => 'references',
    'reviews'              => 'reviews',
    'discord-webhook'      => 'discord_integration',
    'update'               => 'updates',
];
$lf = $featureMap[$rawPage] ?? null;
if ($lf !== null && function_exists('feature_active') && !feature_active($lf)) {
    http_response_code(404);
    echo "<!DOCTYPE html><html lang='" . lang_active() . "'><head><meta charset='UTF-8'><title>404</title></head>"
       . "<body style='margin:0;font-family:sans-serif;background:#0b0f17;color:#e2e8f0;height:100vh;display:flex;align-items:center;justify-content:center;'>"
       . "<div style='text-align:center;'><h1 style='font-size:3rem;margin:0;color:#64748b;'>404</h1>"
       . "<p style='color:#94a3b8;'>" . __('err.e404_title') . "</p></div></body></html>";
    exit;
}
if ($lf !== null) license_gate_require($lf);

if (in_array($pageResource, ['dashboard']) && has_any_permission()) return;

if (!has_permission($pageResource)) {
    header('Location: /admin/dashboard.php', true, 302);
    exit;
}
