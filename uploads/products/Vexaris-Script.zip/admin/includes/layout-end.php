<?php defined('NEXUS_BOOT') or die('Direct access denied.'); ?>
  </div>
</div>
</div>

<div style="text-align:center;padding:14px 24px;font-size:11px;color:var(--dim);border-top:1px solid var(--border);">
  <?php
  $vxVer = '1.0.0';
  if (isset($adminDb) && $adminDb && function_exists('vexaris_current_version')) {
      try { $vxVer = vexaris_current_version($adminDb); } catch (\Throwable $e) {}
  }
  ?>
  <?= e(__('asearch.version')) ?> v<?= e($vxVer) ?>
</div>

<button id="themePaletteBtn" style="position:fixed;bottom:24px;right:24px;z-index:9998;width:48px;height:48px;border-radius:14px;background:var(--accent);color:#fff;border:none;box-shadow:0 6px 24px rgba(var(--accent-rgb,99,102,241),.35);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:20px;transition:transform .25s cubic-bezier(.34,1.56,.64,1),box-shadow .2s;font-family:inherit;"
        onmouseenter="this.style.transform='scale(1.1)'" onmouseleave="this.style.transform='scale(1)'" onclick="openThemePalette()">
  <i class="fa-solid fa-palette"></i>
</button>
<?php include __DIR__ . '/ai-assistant.php'; ?>

<div id="themePaletteModal" style="position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9999;"
     onclick="if(event.target===this)closeThemePalette()">
  <div class="theme-modal theme-modal--slide">
    <div class="modal-header">
      <div class="modal-title-wrap">
        <div class="modal-title-icon">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="3"></circle>
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
          </svg>
        </div>
        <h2 class="modal-title"><?= e(__('asearch.theme_settings')) ?></h2>
      </div>
      <button class="close-btn" onclick="closeThemePalette()" aria-label="<?= e(__('modal.close')) ?>">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>

    <div class="section">
      <div class="section-title"><?= e(__('asearch.theme_mode')) ?></div>
      <div class="mode-switch">
        <button class="mode-btn" id="btn-light">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:18px;height:18px;flex-shrink:0;">
            <circle cx="12" cy="12" r="5"></circle>
            <line x1="12" y1="1" x2="12" y2="3"></line>
            <line x1="12" y1="21" x2="12" y2="23"></line>
            <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
            <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
            <line x1="1" y1="12" x2="3" y2="12"></line>
            <line x1="21" y1="12" x2="23" y2="12"></line>
            <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
            <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
          </svg>
          <?= e(__('asearch.light_theme')) ?>
        </button>
        <button class="mode-btn active" id="btn-dark">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:18px;height:18px;flex-shrink:0;">
            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
          </svg>
          <?= e(__('asearch.dark_theme')) ?>
        </button>
      </div>
    </div>

    <div class="section">
      <div class="section-title"><?= e(__('asearch.primary_color')) ?></div>
      <div class="color-grid">
        <div class="color-swatch" data-color="#4f46e5" style="background:#4f46e5;--swatch-color:#4f46e5;"></div>
        <div class="color-swatch" data-color="#3b82f6" style="background:#3b82f6;--swatch-color:#3b82f6;"></div>
        <div class="color-swatch" data-color="#0284c7" style="background:#0284c7;--swatch-color:#0284c7;"></div>
        <div class="color-swatch" data-color="#06b6d4" style="background:#06b6d4;--swatch-color:#06b6d4;"></div>
        <div class="color-swatch" data-color="#0d9488" style="background:#0d9488;--swatch-color:#0d9488;"></div>
        <div class="color-swatch active" data-color="#10b981" style="background:#10b981;--swatch-color:#10b981;"></div>
        <div class="color-swatch" data-color="#84cc16" style="background:#84cc16;--swatch-color:#84cc16;"></div>
        <div class="color-swatch" data-color="#eab308" style="background:#eab308;--swatch-color:#eab308;"></div>
        <div class="color-swatch" data-color="#f97316" style="background:#f97316;--swatch-color:#f97316;"></div>
        <div class="color-swatch" data-color="#ef4444" style="background:#ef4444;--swatch-color:#ef4444;"></div>
        <div class="color-swatch" data-color="#f43f5e" style="background:#f43f5e;--swatch-color:#f43f5e;"></div>
        <div class="color-swatch" data-color="#ec4899" style="background:#ec4899;--swatch-color:#ec4899;"></div>
        <div class="color-swatch" data-color="#d946ef" style="background:#d946ef;--swatch-color:#d946ef;"></div>
        <div class="color-swatch" data-color="#a855f7" style="background:#a855f7;--swatch-color:#a855f7;"></div>
        <div class="color-swatch" data-color="#8b5cf6" style="background:#8b5cf6;--swatch-color:#8b5cf6;"></div>
        <div class="color-swatch" data-color="#64748b" style="background:#64748b;--swatch-color:#64748b;"></div>
        <div class="color-swatch" data-color="#475569" style="background:#475569;--swatch-color:#475569;"></div>
        <div class="color-swatch" data-color="#334155" style="background:#334155;--swatch-color:#334155;"></div>
      </div>
    </div>

    <div class="section">
      <div class="section-title"><?= e(__('asearch.presets')) ?></div>
      <div class="preset-grid">
        <div class="preset-card active" data-theme="dark" data-accent="#10b981" data-name="gece_mavisi">
          <div class="preset-info">
            <span class="preset-name"><?= e(__('asearch.preset_night')) ?></span>
            <span class="preset-type"><?= e(__('asearch.dark_theme')) ?></span>
          </div>
          <div class="dots-preview">
            <div class="dot" style="background:#0f172a;"></div>
            <div class="dot" style="background:#38bdf8;"></div>
            <div class="dot" style="background:var(--accent);"></div>
          </div>
        </div>
        <div class="preset-card" data-theme="dark" data-accent="#f43f5e" data-name="siberpunk">
          <div class="preset-info">
            <span class="preset-name"><?= e(__('asearch.preset_cyber')) ?></span>
            <span class="preset-type"><?= e(__('asearch.dark_theme')) ?></span>
          </div>
          <div class="dots-preview">
            <div class="dot" style="background:#180828;"></div>
            <div class="dot" style="background:#f43f5e;"></div>
            <div class="dot" style="background:#22d3ee;"></div>
          </div>
        </div>
        <div class="preset-card" data-theme="light" data-accent="#0284c7" data-name="minimal">
          <div class="preset-info">
            <span class="preset-name"><?= e(__('asearch.preset_minimal')) ?></span>
            <span class="preset-type"><?= e(__('asearch.light_theme')) ?></span>
          </div>
          <div class="dots-preview">
            <div class="dot" style="background:#f8fafc;"></div>
            <div class="dot" style="background:#0284c7;"></div>
            <div class="dot" style="background:#64748b;"></div>
          </div>
        </div>
        <div class="preset-card" data-theme="light" data-accent="#f97316" data-name="sicak_isi">
          <div class="preset-info">
            <span class="preset-name"><?= e(__('asearch.preset_warm')) ?></span>
            <span class="preset-type"><?= e(__('asearch.light_theme')) ?></span>
          </div>
          <div class="dots-preview">
            <div class="dot" style="background:#fffbe8;"></div>
            <div class="dot" style="background:#f97316;"></div>
            <div class="dot" style="background:#eab308;"></div>
          </div>
        </div>
      </div>
    </div>

    <div class="modal-footer">
      <button class="reset-btn" id="themeResetBtn">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path>
          <path d="M3 3v5h5"></path>
        </svg>
        <?= e(__('asearch.reset')) ?>
      </button>
      <button class="save-btn" id="themeSaveBtn"><?= e(__('asearch.save_changes')) ?></button>
    </div>
  </div>
</div>

<style>
:root {
  --bg-dark: rgba(15,17,23,0.95);
  --card-bg: #181a20;
  --card-hover: #20242f;
  --border-color: rgba(255,255,255,0.08);
  --text-main: #f3f4f6;
  --text-muted: #808a9d;
  --body-bg: #07080b;
  --modal-shadow: 0 32px 64px -16px rgba(0,0,0,0.8), 0 0 0 1px rgba(255,255,255,0.05);
  --accent-color: #10b981;
  --accent-glow: rgba(16,185,129,0.3);
}

body.light-mode {
  --bg-dark: rgba(255,255,255,0.95);
  --card-bg: #f8fafc;
  --card-hover: #f1f5f9;
  --border-color: rgba(0,0,0,0.18);
  --text-main: #0f172a;
  --text-muted: #64748b;
  --body-bg: #e2e8f0;
  --modal-shadow: 0 32px 64px -16px rgba(0,0,0,0.1), 0 0 0 1px rgba(0,0,0,0.05);
}

body {
  transition: background-color 0.5s cubic-bezier(0.4, 0, 0.2, 1), color 0.5s ease;
}

#themePaletteModal {
  display:none;
  position:fixed;
  inset:0;
  background:rgba(0,0,0,.7);
  z-index:9999;
}
#themePaletteModal.open {
  display:flex;
  align-items:center;
  justify-content:flex-end;
}

.theme-modal {
  width:100%;
  max-width:440px;
  max-height:calc(100dvh - 40px);
  overflow-y:auto;
  background:var(--bg-dark);
  border:1px solid var(--border-color);
  border-radius:28px;
  padding:28px;
  box-shadow:var(--modal-shadow);
  backdrop-filter:blur(20px);
  position:relative;
  transition:background-color .5s ease, border-color .5s ease, box-shadow .5s ease;
}

.theme-modal--slide {
  margin-right:24px;
  transform:translateX(calc(100% + 24px));
  opacity:0;
  transition:transform .4s cubic-bezier(.34,1.56,.64,1), opacity .3s ease, background-color .5s ease, border-color .5s ease, box-shadow .5s ease;
}
#themePaletteModal.open .theme-modal--slide {
  transform:translateX(0);
  opacity:1;
}

.modal-header {
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-bottom:24px;
}

.modal-title-wrap {
  display:flex;
  align-items:center;
  gap:12px;
}

.modal-title-icon {
  width:38px;
  height:38px;
  border-radius:12px;
  background:linear-gradient(135deg,rgba(16,185,129,0.2),rgba(16,185,129,0.03));
  border:1px solid rgba(16,185,129,0.3);
  display:flex;
  align-items:center;
  justify-content:center;
  color:var(--accent-color);
}

.modal-title {
  font-size:20px;
  font-weight:800;
  letter-spacing:-0.4px;
  color:var(--text-main);
  transition:color .5s ease;
}

.close-btn {
  width:36px;
  height:36px;
  border-radius:12px;
  background:var(--card-bg);
  border:1px solid var(--border-color);
  color:var(--text-muted);
  display:flex;
  align-items:center;
  justify-content:center;
  cursor:pointer;
  transition:all .3s cubic-bezier(.34,1.56,.64,1), background-color .5s ease, border-color .5s ease;
}

.close-btn:hover {
  background:var(--card-hover);
  color:var(--text-main);
  transform:scale(1.08) rotate(90deg);
}

.section-title {
  font-size:11px;
  font-weight:800;
  text-transform:uppercase;
  letter-spacing:1.2px;
  color:var(--text-muted);
  margin-bottom:14px;
  display:flex;
  align-items:center;
  gap:8px;
  transition:color .5s ease;
}

.section-title::after {
  content:'';
  flex:1;
  height:1px;
  background:var(--border-color);
  transition:background-color .5s ease;
}

.section { margin-bottom:26px; }

.mode-switch {
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:8px;
  background:var(--card-bg);
  padding:6px;
  border-radius:16px;
  border:1px solid var(--border-color);
  transition:background-color .5s ease, border-color .5s ease;
}

.mode-btn {
  display:flex;
  align-items:center;
  justify-content:center;
  gap:8px;
  padding:12px;
  border-radius:11px;
  border:none;
  background:transparent;
  color:var(--text-muted);
  font-size:13px;
  font-weight:700;
  cursor:pointer;
  font-family:inherit;
  transition:all .3s cubic-bezier(.34,1.56,.64,1), background-color .4s ease, color .4s ease;
}

.mode-btn:hover { color:var(--text-main); }

.mode-btn.active {
  background:var(--bg-dark);
  color:var(--text-main);
  border:1px solid var(--border-color);
  transform:scale(1.02);
}

body:not(.light-mode) .mode-btn.active { box-shadow:0 4px 16px rgba(0,0,0,0.4); }
body.light-mode .mode-btn.active { box-shadow:0 4px 16px rgba(0,0,0,0.08); }

.mode-btn svg { width:18px;height:18px; transition:transform .3s ease; }
.mode-btn.active svg { transform:scale(1.1); }

.color-grid {
  display:grid;
  grid-template-columns:repeat(6,1fr);
  gap:10px;
}

.color-swatch {
  aspect-ratio:1;
  border-radius:10px;
  cursor:pointer;
  position:relative;
  transition:all .25s cubic-bezier(.34,1.56,.64,1);
  border:1px solid rgba(255,255,255,0.1);
  display:flex;
  align-items:center;
  justify-content:center;
}

body.light-mode .color-swatch { border-color:rgba(0,0,0,0.05); }

.color-swatch:hover {
  transform:translateY(-4px) scale(1.08);
  z-index:2;
  box-shadow:0 8px 16px rgba(0,0,0,0.4);
}

body.light-mode .color-swatch:hover { box-shadow:0 8px 16px rgba(0,0,0,0.15); }
.color-swatch:active { transform:scale(0.92); }

.color-swatch.active {
  transform:scale(1.05);
  border-color:#fff;
  box-shadow:0 0 18px var(--swatch-color,rgba(255,255,255,0.4));
  z-index:1;
}

body.light-mode .color-swatch.active { border-color:#0f172a; }

.color-swatch svg {
  width:16px;
  height:16px;
  color:#fff;
  opacity:0;
  transform:scale(0.5) rotate(-20deg);
  transition:all .3s cubic-bezier(.34,1.56,.64,1);
  filter:drop-shadow(0 1px 2px rgba(0,0,0,0.5));
}

.color-swatch.active svg {
  opacity:1;
  transform:scale(1) rotate(0deg);
}

.preset-grid {
  display:grid;
  grid-template-columns:repeat(2,1fr);
  gap:10px;
}

.preset-card {
  background:var(--card-bg);
  border:1px solid var(--border-color);
  border-radius:14px;
  padding:12px 14px;
  cursor:pointer;
  display:flex;
  align-items:center;
  justify-content:space-between;
  transition:all .25s cubic-bezier(.34,1.56,.64,1), background-color .5s ease, border-color .5s ease;
}

.preset-card:hover {
  background:var(--card-hover);
  transform:translateY(-2px);
}

.preset-card:active { transform:scale(0.97); }

.preset-card.active {
  border-color:var(--accent-color);
  background:rgba(16,185,129,0.08);
  box-shadow:0 0 16px var(--accent-glow);
}

.preset-info {
  display:flex;
  flex-direction:column;
  gap:2px;
}

.preset-name {
  font-size:12px;
  font-weight:700;
  color:var(--text-main);
  transition:color .5s ease;
}

.preset-type {
  font-size:10px;
  font-weight:600;
  color:var(--text-muted);
  transition:color .5s ease;
}

.dots-preview {
  display:flex;
  align-items:center;
  gap:4px;
  background:rgba(0,0,0,0.3);
  padding:6px 8px;
  border-radius:20px;
}

body.light-mode .dots-preview { background:rgba(0,0,0,0.05); }

.dot { width:8px;height:8px;border-radius:50%; }

.modal-footer {
  margin-top:20px;
  padding-top:16px;
  border-top:1px solid var(--border-color);
  display:flex;
  justify-content:space-between;
  align-items:center;
  transition:border-color .5s ease;
}

.reset-btn {
  background:transparent;
  border:none;
  color:var(--text-muted);
  font-size:12px;
  font-weight:700;
  cursor:pointer;
  display:flex;
  align-items:center;
  gap:6px;
  padding:8px 12px;
  border-radius:10px;
  font-family:inherit;
  transition:all .2s ease, color .5s ease;
}

.reset-btn:hover {
  color:#f87171;
  background:rgba(248,113,113,0.1);
}

.save-btn {
  background:var(--accent-color);
  color:#fff;
  border:none;
  padding:10px 22px;
  border-radius:12px;
  font-size:13px;
  font-weight:800;
  font-family:inherit;
  cursor:pointer;
  transition:all .25s cubic-bezier(.34,1.56,.64,1);
  box-shadow:0 4px 14px var(--accent-glow);
}

.save-btn:hover {
  transform:translateY(-2px) scale(1.03);
  filter:brightness(1.1);
}

.save-btn:active { transform:scale(0.96); }

/* Editor light mode */
body.light-mode .ed-wrap { background:#fff; border-color:#d1d5db; }
body.light-mode .ed-tb { background:#f3f4f6; border-color:#d1d5db; }
body.light-mode .ed-btn { color:#374151; }
body.light-mode .ed-btn:hover { background:#e5e7eb; }
body.light-mode .ed-body { color:#1f2937; }
body.light-mode .ed-body:empty:before { color:#9ca3af; }
body.light-mode .ed-drp { background:#fff; border-color:#d1d5db; }
body.light-mode .ed-modal-box { background:#fff; border-color:#d1d5db; }
body.light-mode .ed-modal-box h3 { color:#1f2937; border-color:#e5e7eb; }
body.light-mode .ed-mg label { color:#6b7280; }
body.light-mode .ed-mg input[type="text"] { background:#f9fafb; border-color:#d1d5db; color:#1f2937; }
body.light-mode .ed-btn-sep { background:#d1d5db; }
</style>

<script>
function toggleSub(id, el) {
    const sub = document.getElementById(id);
    const isOpen = sub.classList.contains('open');
    document.querySelectorAll('.admin-nav-submenu').forEach(s => s.classList.remove('open'));
    document.querySelectorAll('.admin-nav-item').forEach(i => i.classList.remove('expanded'));
    if (!isOpen) {
        sub.classList.add('open');
        el.classList.add('expanded');
    }
}

document.querySelectorAll('.admin-nav-submenu.open').forEach(sub => {
    const parentId = 'nav' + sub.id.replace('sub','');
    const parent = document.getElementById(parentId);
    if (parent) parent.classList.add('expanded');
});

const sidebar = document.getElementById('adminSidebar');

const mobileToggle = document.getElementById('mobileSidebarToggle');
const navOverlay = document.getElementById('adminNavOverlay');
function setMobileNav(open) {
    if (!sidebar) return;
    if (open) {
        sidebar.classList.add('open');
        if (navOverlay) navOverlay.classList.add('show');
        document.body.style.overflow = 'hidden';
    } else {
        sidebar.classList.remove('open');
        if (navOverlay) navOverlay.classList.remove('show');
        document.body.style.overflow = '';
    }
}
if (mobileToggle) {
    mobileToggle.addEventListener('click', function() {
        setMobileNav(!sidebar.classList.contains('open'));
        const icon = this.querySelector('i');
        if (icon) icon.className = sidebar.classList.contains('open') ? 'fa-solid fa-xmark' : 'fa-solid fa-bars';
    });
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 768 && sidebar.classList.contains('open') &&
            !sidebar.contains(e.target) && !mobileToggle.contains(e.target)) {
            setMobileNav(false);
            const icon = mobileToggle.querySelector('i');
            if (icon) icon.className = 'fa-solid fa-bars';
        }
    });
}
if (navOverlay) {
    navOverlay.addEventListener('click', function() {
        setMobileNav(false);
        const icon = mobileToggle ? mobileToggle.querySelector('i') : null;
        if (icon) icon.className = 'fa-solid fa-bars';
    });
}
window.addEventListener('resize', function() {
    if (window.innerWidth > 768) setMobileNav(false);
});
(function(){
    document.addEventListener('submit', function(e){
        var f = e.target;
        if (!f || f.tagName !== 'FORM' || e.defaultPrevented) return;
        var now = Date.now();
        var last = parseInt(f.dataset.vxSent || '0', 10) || 0;
        if (now - last < 1500) { e.preventDefault(); e.stopPropagation(); return; }
        f.dataset.vxSent = String(now);
    });
})();

(function(){
  var btn = document.getElementById('sidebarCollapseBtn');
  var bar = document.getElementById('adminSidebar');
  var grip = document.getElementById('sbResize');
  if (!bar) return;
  var collapsed = false, customW = 0;
  try {
    collapsed = localStorage.getItem('vx_sb') === '1';
    customW = parseInt(localStorage.getItem('vx_sb_w') || '0', 10) || 0;
  } catch (e) {}
  function applyW() {
    try { if (window.matchMedia && window.matchMedia('(max-width:768px)').matches) { document.documentElement.style.removeProperty('--sidebar-w'); return; } } catch (e) {}
    if (collapsed || !customW) document.documentElement.style.removeProperty('--sidebar-w');
    else document.documentElement.style.setProperty('--sidebar-w', Math.min(320, Math.max(200, customW)) + 'px');
  }
  function applyC() {
    document.body.classList.toggle('sb-collapsed', collapsed);
    applyW();
  }
  function resetSidebarDefault(e){
    if(e) { e.preventDefault(); e.stopPropagation(); }
    collapsed = false; customW = 0;
    try { localStorage.setItem('vx_sb','0'); localStorage.removeItem('vx_sb_w'); } catch(e2){}
    try { document.cookie = 'vx_sb=0;path=/;max-age=31536000;SameSite=Lax'; } catch(e3) {}
    applyC();
  }
  function initTips(){
    document.querySelectorAll('.admin-nav-item').forEach(function(el){
      if(!el.getAttribute('data-tip')){
        var sp = el.querySelector('span');
        var txt = sp ? sp.textContent.trim() : el.textContent.trim();
        if(txt) el.setAttribute('data-tip', txt);
      }
      var nxt = el.nextElementSibling;
      if(nxt && nxt.classList.contains('admin-nav-submenu')) el.classList.add('has-sub');
    });
    document.querySelectorAll('.admin-nav-subitem').forEach(function(el){
      if(!el.getAttribute('data-tip')){
        var t = el.textContent.trim();
        if(t) el.setAttribute('data-tip', t);
      }
    });
  }
  if (collapsed) document.body.classList.add('sb-collapsed');
  applyW();
  initTips();
  (function(){
    var tip = document.getElementById('adminNavTip');
    if (!tip) { tip = document.createElement('div'); tip.id = 'adminNavTip'; document.body.appendChild(tip); }
    var showT = null, hideT = null, tipVisible = false;
    function place(el){
      tip.textContent = el.getAttribute('data-tip') || '';
      tip.style.display = 'block';
      var r = el.getBoundingClientRect();
      var th = tip.offsetHeight;
      var x = r.right + 6;
      var y = r.top + (r.height / 2) - (th / 2);
      if (y < 8) y = 8;
      var maxY = window.innerHeight - th - 8;
      if (y > maxY) y = Math.max(8, maxY);
      tip.style.left = Math.round(x) + 'px';
      tip.style.top = Math.round(y) + 'px';
    }
    function show(el){
      if (!document.body.classList.contains('sb-collapsed')) return;
      if (el.classList.contains('has-sub')) return;
      if (showT) { clearTimeout(showT); showT = null; }
      document.body.classList.add('js-navtip');
      place(el);
      tipVisible = true;
    }
    function hide(){
      showT = null; hideT = null;
      tip.style.display = 'none';
      document.body.classList.remove('js-navtip');
      tipVisible = false;
    }
    function scheduleHide(){
      if (hideT) clearTimeout(hideT);
      hideT = setTimeout(hide, 2000);
    }
    document.querySelectorAll('.admin-nav-item[data-tip]').forEach(function(el){
      el.addEventListener('mouseenter', function(){
        if (hideT) { clearTimeout(hideT); hideT = null; }
        if (tipVisible) show(el);
        else if (!showT) showT = setTimeout(function(){ show(el); }, 120);
      });
      el.addEventListener('mouseleave', function(){
        if (showT) { clearTimeout(showT); showT = null; }
        if (tipVisible) scheduleHide();
      });
      el.addEventListener('click', function(){
        if (hideT) { clearTimeout(hideT); hideT = null; }
        hide();
      });
    });
    window.addEventListener('scroll', function(){
      if (hideT) { clearTimeout(hideT); hideT = null; }
      hide();
    }, true);
  })();
  if (btn) {
    function syncSbCookie() {
      try { document.cookie = 'vx_sb=' + (collapsed ? '1' : '0') + ';path=/;max-age=31536000;SameSite=Lax'; } catch (e2) {}
    }
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      collapsed = !collapsed;
      try { localStorage.setItem('vx_sb', collapsed ? '1' : '0'); } catch (e2) {}
      syncSbCookie();
      mobFlyClose();
      applyC();
    });
    btn.addEventListener('dblclick', resetSidebarDefault);
    btn.addEventListener('contextmenu', resetSidebarDefault);
  }
  if (bar) {
    bar.addEventListener('dblclick', function(e){
      if(e.target.closest('.admin-nav-item') || e.target.closest('.admin-nav-submenu') || e.target.closest('#sbResize')) return;
      resetSidebarDefault(e);
    });
    bar.addEventListener('contextmenu', function(e){
      if(window.innerWidth <= 768) return;
      resetSidebarDefault(e);
    });
  }
  if (grip) {
    grip.addEventListener('dblclick', resetSidebarDefault);
    grip.addEventListener('contextmenu', resetSidebarDefault);
  }
  function mobFlyClose(){
    document.querySelectorAll('.admin-nav-submenu.vx-fly').forEach(function(s){
      s.classList.remove('vx-fly'); s.style.top = ''; s.style.left = '';
    });
  }
  function mobFlyToggle(id, el) {
    var sub = document.getElementById(id);
    if (!sub) return;
    var was = sub.classList.contains('vx-fly');
    mobFlyClose();
    if (was) return;
    var r = el.getBoundingClientRect();
    var left = 84;
    if (bar) { try { left = bar.getBoundingClientRect().right + 8; } catch (e) {} }
    sub.classList.add('vx-fly');
    sub.style.left = Math.round(left) + 'px';
    var h = sub.offsetHeight || 200;
    var top = r.top - 8;
    var maxTop = window.innerHeight - h - 8;
    if (top > maxTop) top = Math.max(8, maxTop);
    if (top < 8) top = 8;
    sub.style.top = Math.round(top) + 'px';
  }
  document.addEventListener('click', function(e){
    if (window.innerWidth > 768 || !document.body.classList.contains('sb-collapsed')) return;
    if (e.target.closest && (e.target.closest('.admin-nav-submenu.vx-fly') || e.target.closest('.admin-nav-item.has-sub'))) return;
    mobFlyClose();
  });
  window.addEventListener('resize', function(){ mobFlyClose(); });
  var navEl = document.querySelector('.admin-nav');
  if (navEl) navEl.addEventListener('scroll', function(){ mobFlyClose(); }, true);
  var origToggle = window.toggleSub;
  window.toggleSub = function(id, el) {
    if (collapsed && window.innerWidth <= 768) {
      mobFlyToggle(id, el);
      return;
    }
    if (collapsed) {
      return;
    }
    if (typeof origToggle === 'function') origToggle(id, el);
  };
  /* collapsed flyout: butonun tam karsisinda fixed menu, bosluk koprusu + gecikmeli kapatma */
  (function(){
    var hideTimer = null;
    var side = document.getElementById('adminSidebar');
    function isFly(){ return document.body.classList.contains('sb-collapsed') && window.innerWidth > 768; }
    function flyClose(){
      if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
      document.querySelectorAll('.admin-nav-submenu.vx-fly').forEach(function(s){
        s.classList.remove('vx-fly'); s.style.top = ''; s.style.left = '';
      });
    }
    function flyOpen(item){
      if (!isFly()) return;
      var sub = item.nextElementSibling;
      if (!sub || !sub.classList.contains('admin-nav-submenu')) return;
      if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
      document.querySelectorAll('.admin-nav-submenu.vx-fly').forEach(function(s){
        if (s !== sub) { s.classList.remove('vx-fly'); s.style.top = ''; s.style.left = ''; }
      });
      var r = item.getBoundingClientRect();
      var left = r.right + 8;
      if (side) { try { left = side.getBoundingClientRect().right + 8; } catch (e) {} }
      sub.classList.add('vx-fly');
      sub.style.left = Math.round(left) + 'px';
      sub.style.top = '8px';
      var h = sub.offsetHeight || 200;
      var top = r.top - 8;
      var maxTop = window.innerHeight - h - 8;
      if (top > maxTop) top = Math.max(8, maxTop);
      if (top < 8) top = 8;
      sub.style.top = Math.round(top) + 'px';
    }
    function flyLater(){
      if (hideTimer) clearTimeout(hideTimer);
      hideTimer = setTimeout(flyClose, 220);
    }
    document.querySelectorAll('.admin-nav-item.has-sub').forEach(function(item){
      item.addEventListener('mouseenter', function(){ flyOpen(item); });
      item.addEventListener('mouseleave', function(){ flyLater(); });
      item.addEventListener('click', function(){ flyClose(); });
    });
    document.querySelectorAll('.admin-nav-submenu').forEach(function(sub){
      sub.addEventListener('mouseenter', function(){
        if (!isFly()) return;
        if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
      });
      sub.addEventListener('mouseleave', function(){ flyLater(); });
    });
    var nav = document.querySelector('.admin-nav');
    if (nav) nav.addEventListener('scroll', function(){ flyClose(); }, true);
    window.addEventListener('resize', function(){ flyClose(); });
    window.addEventListener('scroll', function(){ flyClose(); }, true);
    var cbtn = document.getElementById('sidebarCollapseBtn');
    if (cbtn) cbtn.addEventListener('click', function(){ flyClose(); });
  })();
  if (grip) {
    grip.addEventListener('mousedown', function(e) {
      if (collapsed || window.innerWidth <= 768) return;
      e.preventDefault();
      grip.classList.add('drag');
      var move = function(ev) {
        var w = Math.min(320, Math.max(200, ev.clientX));
        customW = w;
        document.documentElement.style.setProperty('--sidebar-w', w + 'px');
      };
      var up = function() {
        grip.classList.remove('drag');
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
        try { localStorage.setItem('vx_sb_w', String(customW)); } catch (e2) {}
      };
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
    });
  }
})();

document.querySelectorAll('.animate-row').forEach((el, i) => {
    el.style.animationDelay = (i * 0.05) + 's';
});

/* ── TEMA AYARLARI ── */
(function(){
    var currentTheme;
    const checkIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px;"><polyline points="20 6 9 17 4 12"></polyline></svg>';

    function rgbToHex(rgb) {
        var m = rgb.match(/^rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/i);
        if (!m) return '#10b981';
        return '#' + ((1<<24)+(parseInt(m[1])<<16)+(parseInt(m[2])<<8)+parseInt(m[3])).toString(16).slice(1);
    }

    var saveTimer = null;
    var saveSeq = 0;
    var pendingPayload = null;
    var pendingHeaders = null;
    function saveTheme(theme) {
        var t = document.querySelector('meta[name="csrf-token"]');
        var headers = {'Content-Type':'application/json'};
        if (t) headers['X-CSRF-Token'] = t.getAttribute('content');
        var payload = JSON.stringify(theme);
        var seq = ++saveSeq;
        pendingPayload = payload;
        pendingHeaders = headers;
        if (saveTimer) clearTimeout(saveTimer);
        return new Promise(function(resolve){
            saveTimer = setTimeout(function(){
                saveTimer = null;
                fetch('/action.php?action=admin_theme_save', {
                    method: 'POST',
                    headers: headers,
                    body: payload,
                    keepalive: true
                }).then(function(r){ return r.json(); }).then(function(d){
                    if (seq !== saveSeq) return resolve({ok:true, stale:true});
                    resolve(d);
                }).catch(function(){ if (seq === saveSeq) resolve({ok:false}); else resolve({ok:true, stale:true}); });
            }, 350);
        });
    }

    function loadTheme() {
        try {
            var raw = <?= json_encode($_adminTheme) ?>;
            currentTheme = JSON.parse(raw);
            if (!currentTheme.mode) currentTheme.mode = 'dark';
            if (!currentTheme.accent || currentTheme.accent === '#6366f1') currentTheme.accent = '#10b981';
            if (currentTheme.preset === undefined || currentTheme.preset === null) currentTheme.preset = '';
        } catch(e) {
            currentTheme = {mode:'dark',accent:'#10b981',preset:'gece_mavisi'};
        }

        var root = document.documentElement;
        root.style.setProperty('--accent-color', currentTheme.accent);
        root.style.setProperty('--accent-glow', hexToRgba(currentTheme.accent, 0.3));
        root.style.setProperty('--accent', currentTheme.accent);
        root.style.setProperty('--accent-rgb', hexToRgb(currentTheme.accent));
        root.style.setProperty('--accent-dark', adjustColor(currentTheme.accent, -20));

        if (currentTheme.mode === 'light') {
            document.body.classList.add('light-mode');
            root.style.setProperty('--bg', 'rgba(255,255,255,0.97)');
            root.style.setProperty('--bg-card', '#ffffff');
            root.style.setProperty('--bg-surface', '#eef2f7');
            root.style.setProperty('--bg-hover', '#e2e8f0');
            root.style.setProperty('--border', 'rgba(15,23,42,0.26)');
            root.style.setProperty('--border-focus', 'rgba(99,102,241,0.55)');
            root.style.setProperty('--text', '#0f172a');
            root.style.setProperty('--muted', '#475569');
            root.style.setProperty('--dim', '#94a3b8');
            document.getElementById('btn-light').classList.add('active');
            document.getElementById('btn-dark').classList.remove('active');
        } else {
            document.body.classList.remove('light-mode');
            root.style.setProperty('--bg', '#0a0a0f');
            root.style.setProperty('--bg-card', '#111118');
            root.style.setProperty('--bg-surface', '#16161f');
            root.style.setProperty('--bg-hover', '#1c1c28');
            root.style.setProperty('--border', 'rgba(255,255,255,0.06)');
            root.style.setProperty('--border-focus', 'rgba(99,102,241,0.45)');
            root.style.setProperty('--text', '#e8eaf0');
            root.style.setProperty('--muted', '#5a6070');
            root.style.setProperty('--dim', '#2a2d3a');
            document.getElementById('btn-dark').classList.add('active');
            document.getElementById('btn-light').classList.remove('active');
        }

        document.querySelectorAll('.preset-card').forEach(function(p){
            p.classList.toggle('active', p.getAttribute('data-name') === currentTheme.preset);
        });

        document.querySelectorAll('.color-swatch').forEach(function(s){
            s.classList.toggle('active', s.getAttribute('data-color') === currentTheme.accent);
        });
    }

    document.querySelectorAll('.color-swatch').forEach(function(swatch) {
      swatch.innerHTML = checkIcon;
      swatch.addEventListener('click', function() {
        document.querySelectorAll('.color-swatch').forEach(function(s) { s.classList.remove('active'); });
        this.classList.add('active');
        currentTheme.accent = this.getAttribute('data-color');
        currentTheme.preset = '';
        document.querySelectorAll('.preset-card').forEach(function(p) { p.classList.remove('active'); });
        applyTheme(currentTheme);
        saveTheme(currentTheme);
      });
    });

    function applyTheme(theme) {
        document.documentElement.classList.remove('theme-morph');
        void document.documentElement.offsetWidth;
        document.documentElement.classList.add('theme-morph');
        setTimeout(function(){ document.documentElement.classList.remove('theme-morph'); }, 380);
        var root = document.documentElement;
        root.style.setProperty('--accent-color', theme.accent);
        root.style.setProperty('--accent-glow', hexToRgba(theme.accent, 0.3));

        if (theme.mode === 'light') {
            document.body.classList.add('light-mode');
            root.style.setProperty('--bg', 'rgba(255,255,255,0.97)');
            root.style.setProperty('--bg-card', '#ffffff');
            root.style.setProperty('--bg-surface', '#eef2f7');
            root.style.setProperty('--bg-hover', '#e2e8f0');
            root.style.setProperty('--border', 'rgba(15,23,42,0.26)');
            root.style.setProperty('--border-focus', 'rgba(99,102,241,0.55)');
            root.style.setProperty('--text', '#0f172a');
            root.style.setProperty('--muted', '#475569');
            root.style.setProperty('--dim', '#94a3b8');
        } else {
            document.body.classList.remove('light-mode');
            root.style.setProperty('--bg', '#0a0a0f');
            root.style.setProperty('--bg-card', '#111118');
            root.style.setProperty('--bg-surface', '#16161f');
            root.style.setProperty('--bg-hover', '#1c1c28');
            root.style.setProperty('--border', 'rgba(255,255,255,0.06)');
            root.style.setProperty('--border-focus', 'rgba(99,102,241,0.45)');
            root.style.setProperty('--text', '#e8eaf0');
            root.style.setProperty('--muted', '#5a6070');
            root.style.setProperty('--dim', '#2a2d3a');
        }

        root.style.setProperty('--accent', theme.accent);
        root.style.setProperty('--accent-rgb', hexToRgb(theme.accent));
        root.style.setProperty('--accent-dark', adjustColor(theme.accent, -20));
    }

    function hexToRgb(hex) {
        var c = hex.replace('#','');
        return parseInt(c.substring(0,2),16)+','+parseInt(c.substring(2,4),16)+','+parseInt(c.substring(4,6),16);
    }
    function hexToRgba(hex, a) {
        return 'rgba('+hexToRgb(hex)+','+a+')';
    }

    function adjustColor(hex, amount) {
        var c = hex.replace('#','');
        var num = parseInt(c, 16);
        var r = Math.min(255, Math.max(0, ((num >> 16) & 255) + amount));
        var g = Math.min(255, Math.max(0, ((num >> 8) & 255) + amount));
        var b = Math.min(255, Math.max(0, (num & 255) + amount));
        return '#' + ((r << 16) | (g << 8) | b).toString(16).padStart(6,'0');
    }

    loadTheme();

    const btnLight = document.getElementById('btn-light');
    const btnDark = document.getElementById('btn-dark');

    btnLight.addEventListener('click', function() {
        document.body.classList.add('light-mode');
        btnDark.classList.remove('active');
        btnLight.classList.add('active');
        currentTheme.mode = 'light';
        applyTheme(currentTheme);
        saveTheme(currentTheme);
    });

    btnDark.addEventListener('click', function() {
        document.body.classList.remove('light-mode');
        btnLight.classList.remove('active');
        btnDark.classList.add('active');
        currentTheme.mode = 'dark';
        applyTheme(currentTheme);
        saveTheme(currentTheme);
    });

    document.querySelectorAll('.preset-card').forEach(function(card) {
        card.addEventListener('click', function() {
            document.querySelectorAll('.preset-card').forEach(function(c) { c.classList.remove('active'); });
            card.classList.add('active');
            currentTheme.mode = card.getAttribute('data-theme');
            currentTheme.accent = card.getAttribute('data-accent');
            currentTheme.preset = card.getAttribute('data-name');
            syncPresetMode(currentTheme.mode);
            applyTheme(currentTheme);
            saveTheme(currentTheme);
        });
    });

    function syncPresetMode(mode) {
        if (mode === 'light') {
            document.body.classList.add('light-mode');
            btnDark.classList.remove('active');
            btnLight.classList.add('active');
        } else {
            document.body.classList.remove('light-mode');
            btnLight.classList.remove('active');
            btnDark.classList.add('active');
        }
    }

    document.getElementById('themeSaveBtn').addEventListener('click', function() {
        var btn = this;
        var orig = btn.innerHTML;
        btn.innerHTML = <?= json_encode(__('aseo.saving')) ?>;
        saveTheme(currentTheme).then(function(d){
            if (d && d.ok) {
                btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" style="width:14px;height:14px;vertical-align:middle;margin-right:4px;"><polyline points="20 6 9 17 4 12"></polyline></svg> ' + <?= json_encode(__('asearch.saved')) ?>;
            } else {
                btn.innerHTML = <?= json_encode(__('asearch.save_fail')) ?>;
            }
            setTimeout(function(){ btn.innerHTML = orig; }, 1500);
        });
    });

    document.getElementById('themeResetBtn').addEventListener('click', function() {
        currentTheme = {mode:'dark',accent:'#10b981',preset:'gece_mavisi'};
        applyTheme(currentTheme);
        saveTheme(currentTheme);
        document.querySelectorAll('.color-swatch').forEach(function(s){
            s.classList.toggle('active', s.getAttribute('data-color') === currentTheme.accent);
        });
        document.querySelectorAll('.preset-card').forEach(function(p){
            p.classList.toggle('active', p.getAttribute('data-name') === currentTheme.preset);
        });
        document.getElementById('btn-dark').click();
    });

    window.addEventListener('pagehide', function(){
        if (saveTimer) {
            clearTimeout(saveTimer);
            saveTimer = null;
            try {
                fetch('/action.php?action=admin_theme_save', {
                    method: 'POST',
                    headers: pendingHeaders || {'Content-Type':'application/json'},
                    body: pendingPayload || '{}',
                    keepalive: true
                }).catch(function(){});
            } catch(e){}
            pendingPayload = null;
        }
    });

    window.openThemePalette = function() {
        document.getElementById('themePaletteModal').classList.add('open');
    };
    window.closeThemePalette = function() {
        document.getElementById('themePaletteModal').classList.remove('open');
    };
})();

</script>

<style>
#adminSearchOverlay{position:fixed;inset:0;width:100%;height:100%;background:rgba(var(--accent-rgb),.15);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);z-index:99999;display:flex;flex-direction:column;align-items:center;padding-top:18vh;opacity:0;pointer-events:none;transition:opacity .4s ease;}
#adminSearchOverlay.active{opacity:1;pointer-events:auto;}
#adminSearchOverlay .search-container{width:90%;max-width:640px;background:var(--bg-card);border:1px solid var(--border);border-radius:24px;padding:15px 25px;display:flex;align-items:center;gap:15px;box-shadow:0 30px 60px rgba(0,0,0,.5);transform:translateY(-40px) scale(.95);opacity:0;transition:all .5s cubic-bezier(.34,1.56,.64,1);position:relative;z-index:2;}
#adminSearchOverlay.active .search-container{transform:translateY(0) scale(1);opacity:1;}
#adminSearchOverlay .search-container:focus-within{border-color:var(--accent);box-shadow:0 30px 60px rgba(0,0,0,.5),0 0 0 4px rgba(var(--accent-rgb),.2);}
#adminSearchOverlay .search-icon-large{font-size:28px;color:var(--accent);flex-shrink:0;}
#adminSearchOverlay .search-input{flex:1;min-width:0;background:transparent;border:none;color:var(--text);font-size:22px;font-weight:600;padding:10px 0;outline:none;font-family:inherit;}
#adminSearchOverlay .search-input::placeholder{color:var(--dim);font-weight:500;}
#adminSearchOverlay .close-search-btn{background:var(--bg-surface);border:1px solid var(--border);color:var(--muted);width:44px;height:44px;border-radius:14px;font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .3s cubic-bezier(.34,1.56,.64,1);flex-shrink:0;}
#adminSearchOverlay .close-search-btn:hover{background:#ef4444;color:#fff;border-color:#ef4444;transform:rotate(90deg) scale(1.1);box-shadow:0 0 20px rgba(239,68,68,.4);}
#adminSearchOverlay .search-results{width:90%;max-width:640px;margin-top:6px;background:var(--bg-card);border:1px solid var(--border);border-radius:16px;overflow:hidden;box-shadow:0 20px 50px rgba(0,0,0,.4);transform:translateY(-20px) scale(.95);opacity:0;transition:all .35s cubic-bezier(.34,1.56,.64,1);max-height:50vh;overflow-y:auto;position:relative;z-index:1;}
#adminSearchOverlay .search-results.show{transform:translateY(0) scale(1);opacity:1;}
#adminSearchOverlay .sr-item{display:flex;align-items:center;gap:12px;padding:12px 20px;cursor:pointer;transition:background .15s;border-bottom:1px solid var(--border);}
#adminSearchOverlay .sr-item:last-child{border-bottom:none;}
#adminSearchOverlay .sr-item:hover{background:rgba(var(--accent-rgb),.08);}
#adminSearchOverlay .sr-item-icon{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:16px;background:rgba(var(--accent-rgb),.12);color:var(--accent);flex-shrink:0;}
#adminSearchOverlay .sr-item-info{flex:1;min-width:0;}
#adminSearchOverlay .sr-item-name{font-size:15px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
#adminSearchOverlay .sr-item-name em{font-style:normal;color:var(--accent);background:rgba(var(--accent-rgb),.15);padding:0 3px;border-radius:3px;}
#adminSearchOverlay .sr-item-sub{font-size:12px;color:var(--muted);margin-top:2px;}
#adminSearchOverlay .sr-item-badge{font-size:11px;padding:3px 9px;border-radius:20px;background:var(--bg-surface);color:var(--muted);flex-shrink:0;}
#adminSearchOverlay .sr-item.focused{background:rgba(var(--accent-rgb),.15);}
#adminSearchOverlay .sr-empty{padding:30px 20px;text-align:center;color:var(--dim);font-size:14px;}
#adminSearchOverlay .sr-recent-label{padding:10px 20px 4px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--dim);}
#adminSearchOverlay .sr-clear-recent{float:right;font-size:11px;color:var(--muted);cursor:pointer;text-transform:none;letter-spacing:0;}
#adminSearchOverlay .sr-clear-recent:hover{color:#ef4444;}
@media(max-width:768px){
  #adminSearchOverlay{padding-top:12vh;}
  #adminSearchOverlay .search-container{max-width:92%;padding:10px 16px;gap:10px;border-radius:20px;}
  #adminSearchOverlay .search-input{font-size:16px;}
  #adminSearchOverlay .search-icon-large{font-size:20px;}
  #adminSearchOverlay .close-search-btn{width:36px;height:36px;font-size:15px;border-radius:10px;}
  #adminSearchOverlay .search-results{max-width:92%;}
}
@media(max-width:768px){
  #themePaletteModal.open{align-items:flex-end;justify-content:center;}
  .theme-modal{max-width:calc(100vw - 24px);max-height:calc(100dvh - 24px);padding:22px;border-radius:22px;}
  .theme-modal--slide{margin:0 0 12px;transform:translateY(calc(100% + 12px));}
  #themePaletteModal.open .theme-modal--slide{transform:translateY(0);}
  .color-grid{grid-template-columns:repeat(6,1fr);gap:8px;}
  .preset-grid{grid-template-columns:1fr;}
  .modal-footer{flex-direction:column;}
  .modal-footer button{width:100%;justify-content:center;}
  #themePaletteBtn{bottom:16px !important;right:16px !important;width:44px !important;height:44px !important;font-size:18px !important;border-radius:12px !important;}
}
@media(max-width:480px){
  .color-grid{grid-template-columns:repeat(6,1fr);gap:6px;}
  .mode-btn{padding:10px;font-size:12px;}
  .preset-name{font-size:12px;}
}
</style>

<div id="adminSearchOverlay">
  <div class="search-container">
    <i class="fa-solid fa-magnifying-glass search-icon-large"></i>
    <input type="text" class="search-input" id="adminSearchOverlayInput" placeholder="<?= e(__('asearch.search_ph')) ?>" autocomplete="off">
    <button class="close-search-btn" id="adminSearchCloseBtn" aria-label="<?= e(__('modal.close')) ?>">
      <i class="fa-solid fa-xmark"></i>
    </button>
  </div>
  <div class="search-results" id="adminSearchResults"></div>
</div>

<script>
(function(){
  var btn=document.getElementById('adminSearchBtn');
  var overlay=document.getElementById('adminSearchOverlay');
  var input=document.getElementById('adminSearchOverlayInput');
  var closeBtn=document.getElementById('adminSearchCloseBtn');
  var results=document.getElementById('adminSearchResults');
  if(!btn||!overlay||!input||!results){ console.warn('adminSearch: overlay elementleri bulunamadı', {btn:!!btn,overlay:!!overlay,input:!!input,results:!!results}); return; }
  var searchTimer, currentFocus=-1, lastQ='';

  function openSearch(){overlay.classList.add('active');setTimeout(function(){input.focus();fetchRecent()},300);}
  function closeSearch(){overlay.classList.remove('active');input.value='';results.classList.remove('show');results.innerHTML='';lastQ='';currentFocus=-1;}

  function fetchRecent(){
    if(input.value.trim().length>0) return;
    var fd=new FormData();fd.append('action','admin_category_search');fd.append('q','');
    fetch('/action.php',{method:'POST',body:fd}).then(function(r){
      if(!r.ok) throw new Error('HTTP '+r.status);
      return r.text();
    }).then(function(txt){
      var d;
      try{ d=JSON.parse(txt); }
      catch(e){ console.error('adminSearch: JSON parse hatası, sunucu yanıtı:',txt); results.classList.remove('show');results.innerHTML='';return; }
      if(!d.ok){console.warn('adminSearch: sunucu ok=false, mesaj:',d.msg);results.classList.remove('show');results.innerHTML='';return;}
      var items=d.results;
      if(!items||items.length===0){results.classList.remove('show');results.innerHTML='';return;}
      var h='<div class="sr-recent-label">' + <?= json_encode(__('asearch.recent')) ?> + '</div>';
      for(var i=0;i<items.length;i++){
        h+='<div class="sr-item" data-link="'+items[i].link+'"><div class="sr-item-icon"><i class="fa-solid '+(items[i].type_icon||'fa-clock-rotate-left')+'"></i></div><div class="sr-item-info"><div class="sr-item-name">'+items[i].name+'</div><div class="sr-item-sub">'+(items[i].description||'')+'</div></div><span class="sr-item-badge">'+(items[i].type_name||'Sayfa')+'</span></div>';
      }
      results.innerHTML=h;results.classList.add('show');currentFocus=-1;
    })['catch'](function(err){ console.error('adminSearch: fetchRecent isteği başarısız:',err); });
  }

  function performSearch(){
    var q=input.value.trim();
    if(q.length<2){fetchRecent();return;}
    if(q===lastQ) return;
    lastQ=q;currentFocus=-1;
    var fd=new FormData();fd.append('action','admin_category_search');fd.append('q',q);
    fetch('/action.php',{method:'POST',body:fd}).then(function(r){
      if(!r.ok) throw new Error('HTTP '+r.status);
      return r.text();
    }).then(function(txt){
      var d;
      try{ d=JSON.parse(txt); }
      catch(e){ console.error('adminSearch: JSON parse hatası, sunucu yanıtı:',txt); results.innerHTML='<div class="sr-empty">' + <?= json_encode(__('asearch.server_error')) ?> + '</div>';results.classList.add('show');return; }
      if(!d.ok){results.classList.remove('show');results.innerHTML='<div class="sr-empty">'+d.msg+'</div>';results.classList.add('show');return;}
      var items=d.results;
      if(!items||items.length===0){results.innerHTML='<div class="sr-empty">' + <?= json_encode(__('asearch.no_results')) ?> + '</div>';results.classList.add('show');return;}
      var h='';
      for(var i=0;i<items.length;i++){
        var it=items[i];
        h+='<div class="sr-item" data-link="'+it.link+'"><div class="sr-item-icon"><i class="fa-solid '+it.type_icon+'"></i></div><div class="sr-item-info"><div class="sr-item-name">'+it.highlight+'</div><div class="sr-item-sub">'+(it.description||'')+'</div></div><span class="sr-item-badge">'+it.type_name+'</span></div>';
      }
      results.innerHTML=h;results.classList.add('show');
    })['catch'](function(err){ console.error('adminSearch: performSearch isteği başarısız:',err); });
  }

  function navigateItem(dir){
    var items=results.querySelectorAll('.sr-item');
    if(items.length===0) return;
    if(currentFocus>=0) items[currentFocus].classList.remove('focused');
    currentFocus+=dir;
    if(currentFocus<0) currentFocus=0;
    if(currentFocus>=items.length) currentFocus=items.length-1;
    items[currentFocus].classList.add('focused');
    items[currentFocus].scrollIntoView({block:'nearest'});
  }
  function selectFocused(){
    var items=results.querySelectorAll('.sr-item');
    if(currentFocus>=0&&currentFocus<items.length) items[currentFocus].click();
  }
  input.addEventListener('input',function(){clearTimeout(searchTimer);searchTimer=setTimeout(performSearch,250);});
  input.addEventListener('focus',function(){setTimeout(fetchRecent,100)});
  input.addEventListener('keydown',function(e){
    if(e.key==='ArrowDown'){e.preventDefault();navigateItem(1);}
    else if(e.key==='ArrowUp'){e.preventDefault();navigateItem(-1);}
    else if(e.key==='Enter'){e.preventDefault();selectFocused();}
  });
  results.addEventListener('click',function(e){
    var item=e.target.closest('.sr-item');
    if(!item) return;
    var link=item.getAttribute('data-link');
    if(!link) return;
    closeSearch();
    window.location.href=link;
  });
  btn.addEventListener('click',function(e){e.stopPropagation();openSearch()});
  closeBtn.addEventListener('click',closeSearch);
  overlay.addEventListener('click',function(e){if(e.target===overlay)closeSearch()});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&overlay.classList.contains('active'))closeSearch()});
})();
</script>

<script>
document.addEventListener('DOMContentLoaded', function(){
  var links=document.querySelectorAll('[data-track-key]');
  for(var i=0;i<links.length;i++){
    links[i].addEventListener('click',function(){
      var key=this.getAttribute('data-track-key');
      var label=this.getAttribute('data-track-label');
      var icon=this.getAttribute('data-track-icon')||'';
      var url=this.getAttribute('href');
      if(!key||!label||!url) return;
      var fd=new FormData();
      fd.append('action','track_category_view');
      fd.append('page_key',key);
      fd.append('page_label',label);
      fd.append('page_url',url);
      fd.append('page_icon',icon);
      var ctm=document.querySelector('meta[name="csrf-token"]');
      var cth={};
      if(ctm) cth['X-CSRF-Token']=ctm.getAttribute('content');
      fetch('/action.php',{method:'POST',headers:cth,body:fd,keepalive:true})
        .then(function(r){return r.json()})
        .then(function(d){ if(!d.ok) console.warn('track_category_view başarısız:',d.msg); })
        ['catch'](function(err){ console.warn('track_category_view hata:',err); });
    });
  }
});
</script>

<?php if (isset($extraScripts)) echo $extraScripts; ?>
</body>
</html>
