<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
$_adminSiteName = 'Vexaris';
$_adminTheme = '{"mode":"dark","accent":"#6366f1","preset":"varsayilan"}';
if (isset($adminDb) && $adminDb) {
    try {
        $_snSt = $adminDb->prepare("SELECT value FROM settings WHERE `key`='site_name' LIMIT 1");
        $_snSt->execute(); $_snV = $_snSt->fetchColumn();
        if ($_snV) $_adminSiteName = $_snV;
        $_atSt = $adminDb->prepare("SELECT value FROM settings WHERE `key`='admin_theme' LIMIT 1");
        $_atSt->execute(); $_atV = $_atSt->fetchColumn();
        if ($_atV) $_adminTheme = $_atV;
    } catch (\Exception $e) {}
}
$_adminThemeParsed = json_decode($_adminTheme, true) ?: ['mode'=>'dark'];
$_adminBodyClass = ($_adminThemeParsed['mode'] ?? 'dark') === 'light' ? 'light-mode' : '';

function _ns_admin_hex_rgb(string $hex): string {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    if (strlen($hex) !== 6) $hex = '10b981';
    return hexdec(substr($hex,0,2)).','.hexdec(substr($hex,2,2)).','.hexdec(substr($hex,4,2));
}
function _ns_admin_hex_adjust(string $hex, int $amount): string {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    if (strlen($hex) !== 6) $hex = '10b981';
    $r = min(255, max(0, hexdec(substr($hex,0,2)) + $amount));
    $g = min(255, max(0, hexdec(substr($hex,2,2)) + $amount));
    $b = min(255, max(0, hexdec(substr($hex,4,2)) + $amount));
    return sprintf('#%02x%02x%02x', $r, $g, $b);
}
$_adminMode    = ($_adminThemeParsed['mode'] ?? 'dark') === 'light' ? 'light' : 'dark';
$_adminAccent  = trim($_adminThemeParsed['accent'] ?? '');
if ($_adminAccent === '' || $_adminAccent === '#6366f1') $_adminAccent = '#10b981';
if ($_adminMode === 'light') {
    $_adminBg = 'rgba(255,255,255,0.97)'; $_adminBgCard = '#ffffff'; $_adminBgSurface = '#eef2f7'; $_adminBgHover = '#e2e8f0';
    $_adminBorder = 'rgba(15,23,42,0.26)'; $_adminBorderFocus = 'rgba(99,102,241,0.55)';
    $_adminText = '#0f172a'; $_adminMuted = '#475569'; $_adminDim = '#94a3b8';
} else {
    $_adminBg = '#0a0a0f'; $_adminBgCard = '#111118'; $_adminBgSurface = '#16161f'; $_adminBgHover = '#1c1c28';
    $_adminBorder = 'rgba(255,255,255,0.06)'; $_adminBorderFocus = 'rgba(99,102,241,0.45)';
    $_adminText = '#e8eaf0'; $_adminMuted = '#5a6070'; $_adminDim = '#2a2d3a';
}
$_adminAccentDark = _ns_admin_hex_adjust($_adminAccent, -20);
$_adminAccentRgb  = _ns_admin_hex_rgb($_adminAccent);
$_adminRoleNames = [
    'admin'        => __('nav.role_admin'),
    'yonetici'     => __('nav.role_manager'),
    'moderator'    => __('nav.role_mod'),
    'destek_ekibi' => __('nav.role_support'),
    'user'         => __('nav.role_member')
];
if (isset($adminDb) && $adminDb && function_exists('roles_all')) {
    try {
        foreach (roles_all($adminDb) as $_rslug => $_rrow) {
            $_adminRoleNames[$_rslug] = role_display($adminDb, $_rslug)['name'];
        }
    } catch (\Exception $e) {}
}
?>
<!DOCTYPE html>
<html lang="<?= lang_active() ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?= csrf_token() ?>">
<title><?= e($pageTitle ?? __('amenu.panel_title')) ?> — <?= e($_adminSiteName) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous">
<script src="https://cdn.tailwindcss.com"></script>
<script>try{var _sbw=parseInt(localStorage.getItem('vx_sb_w')||'0',10)||0;var _sbc=localStorage.getItem('vx_sb')==='1';if(!_sbc&&_sbw&&!window.matchMedia('(max-width:768px)').matches)document.documentElement.style.setProperty('--sidebar-w',Math.min(320,Math.max(200,_sbw))+'px');}catch(e){}</script>
<script>
window.NX_MONEY = <?= json_encode(fx_js_config(), JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
window.nxFmt = function(v){var m=window.NX_MONEY||{sym:'₺',pre:true,dec:',',thou:'.',sp:''};var n=parseFloat(v||0);if(!isFinite(n))n=0;var ng=n<0;n=Math.abs(n);var s=n.toFixed(2).split('.');s[0]=s[0].replace(/\B(?=(\d{3})+(?!\d))/g,m.thou);var t=s.join(m.dec);if(ng)t='-'+t;return m.pre?m.sym+t:t+m.sp+m.sym;};
(function(){
  var meta = document.querySelector('meta[name="csrf-token"]');
  if (!meta) return;
  var token = meta.getAttribute('content');
  var origFetch = window.fetch;
  window.fetch = function(url, opts){
    opts = opts || {};
    if ((opts.method || 'GET').toUpperCase() === 'POST') {
      var headers = new Headers(opts.headers || {});
      if (!headers.has('X-CSRF-Token')) headers.set('X-CSRF-Token', token);
      if (!headers.has('X-Requested-With')) headers.set('X-Requested-With', 'XMLHttpRequest');
      opts.headers = headers;
    }
    return origFetch.call(this, url, opts).then(function(r){
      try {
        var ct = (r.headers && r.headers.get('content-type')) || '';
        if (ct.indexOf('application/json') === -1) return r;
        return r.clone().json().then(function(d){
          if (d && d.ok === false && (d.code === 'csrf_fail' || (typeof d.msg === 'string' && (d.msg.indexOf('Güvenlik doğrulaması') !== -1 || d.msg.indexOf('Security verification') !== -1)))) {
            try {
              if (!sessionStorage.getItem('_vx_csrf_reload')) {
                sessionStorage.setItem('_vx_csrf_reload', '1');
                location.reload();
                return new Promise(function(){});
              }
            } catch(e){}
          } else {
            try { sessionStorage.removeItem('_vx_csrf_reload'); } catch(e){}
          }
          return r;
        }, function(){ return r; });
      } catch(e){ return r; }
    });
  };
})();
</script>
<?php if (isset($extraHead)) echo $extraHead; ?>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:<?= $_adminBg ?>;--bg-card:<?= $_adminBgCard ?>;--bg-surface:<?= $_adminBgSurface ?>;--bg-hover:<?= $_adminBgHover ?>;
  --border:<?= $_adminBorder ?>;--border-focus:<?= $_adminBorderFocus ?>;
  --text:<?= $_adminText ?>;--muted:<?= $_adminMuted ?>;--dim:<?= $_adminDim ?>;
  --accent:<?= $_adminAccent ?>;--accent-dark:<?= $_adminAccentDark ?>;--accent-rgb:<?= $_adminAccentRgb ?>;
  --accent-color:<?= $_adminAccent ?>;--accent-glow:rgba(<?= $_adminAccentRgb ?>,0.3);
  --green:#22c55e;--red:#ef4444;--yellow:#eab308;--cyan:#22d3ee;
  --sidebar-w:220px;
}
html,body{min-height:100vh;font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);-webkit-font-smoothing:antialiased;}
a{color:inherit;text-decoration:none;}
.admin-shell{display:flex;min-height:100vh;}

.admin-sidebar{
  width:var(--sidebar-w);flex-shrink:0;background:var(--bg-card);
  border-right:1px solid var(--border);display:flex;flex-direction:column;
  position:fixed;top:0;left:0;bottom:0;z-index:50;transition:transform .25s,width .25s ease;
}
.admin-sidebar-logo{
  display:flex;align-items:center;justify-content:space-between;
  padding:18px 18px 14px;border-bottom:1px solid var(--border);
}
.admin-sidebar-logo-name{
  font-size:17px;font-weight:900;letter-spacing:.04em;color:var(--accent);
}
.admin-sidebar-logo-icon{
  width:28px;height:28px;background:var(--bg-surface);border:1px solid var(--border);
  border-radius:8px;display:flex;align-items:center;justify-content:center;
  cursor:pointer;color:var(--muted);font-size:11px;transition:color .15s;
}
.admin-sidebar-logo-icon:hover{color:var(--text);}

.admin-user-card{
  display:flex;align-items:center;justify-content:space-between;
  padding:14px 18px;border-bottom:1px solid var(--border);
}
.admin-user-card-info{display:flex;align-items:center;gap:10px;}
.admin-user-card-avatar{
  width:38px;height:38px;border-radius:50%;object-fit:cover;
  border:2px solid rgba(var(--accent-rgb,99,102,241),.35);image-rendering:pixelated;
}
.admin-user-card-name{font-size:13px;font-weight:800;line-height:1.2;}
.admin-user-card-role{font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);}
.admin-user-card-logout{
  width:28px;height:28px;background:var(--bg-surface);border:1px solid var(--border);
  border-radius:8px;display:flex;align-items:center;justify-content:center;
  color:var(--muted);font-size:12px;transition:color .15s,border-color .15s;cursor:pointer;
}
.admin-user-card-logout:hover{color:#f87171;border-color:rgba(239,68,68,.3);}

.admin-nav{flex:1;padding:10px 10px;overflow-y:auto;display:flex;flex-direction:column;gap:2px;}
.nav-section-label{
  font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  color:var(--dim);padding:12px 10px 4px;
}
.admin-nav-item{
  display:flex;align-items:center;gap:0;
  padding:9px 12px;border-radius:10px;font-size:13px;font-weight:600;
  color:var(--muted);cursor:pointer;transition:background .15s,color .15s;
  user-select:none;text-decoration:none;
}
.admin-nav-item:hover{background:rgba(255,255,255,0.04);color:var(--text);}
.admin-nav-item.active{background:rgba(255,255,255,0.92);color:#0a0a0f;}
.admin-nav-item.active i{color:#0a0a0f;}
.admin-nav-item i.nav-icon{width:18px;text-align:center;font-size:13px;margin-right:10px;flex-shrink:0;}
.admin-nav-item span{flex:1;}
.admin-nav-item .nav-arrow{font-size:10px;transition:transform .2s;margin-left:4px;flex-shrink:0;}
.admin-nav-item.expanded .nav-arrow{transform:rotate(90deg);}
.admin-nav-submenu{
  display:none;padding:3px 0 3px 14px;
}
.admin-nav-submenu.open{display:block;}
.admin-nav-subitem{
  display:flex;align-items:center;gap:8px;
  padding:7px 12px;border-radius:8px;font-size:12px;font-weight:600;
  color:var(--muted);transition:background .12s,color .12s;
}
.admin-nav-subitem:hover{background:rgba(255,255,255,0.04);color:var(--text);}
.admin-nav-subitem.active{color:var(--accent);}
.admin-nav-subitem i{width:14px;font-size:11px;text-align:center;}

body.sb-collapsed{--sidebar-w:76px;}
body.sb-collapsed .admin-sidebar-logo-name,
body.sb-collapsed .admin-user-card-info div,
body.sb-collapsed .admin-nav-item span,
body.sb-collapsed .admin-nav-item .nav-arrow,
body.sb-collapsed .nav-section-label{display:none;}
body.sb-collapsed .admin-sidebar-logo{justify-content:center;padding:18px 0 14px;}
body.sb-collapsed .admin-user-card{justify-content:center;padding:14px 0;}
body.sb-collapsed .admin-user-card-avatar{width:34px;height:34px;}
body.sb-collapsed .admin-user-card-logout{display:none;}
body.sb-collapsed .admin-nav-item{justify-content:center;padding:11px 0;}
body.sb-collapsed .admin-nav-item i.nav-icon{margin-right:0;font-size:20px;transition:transform .2s;}
body.sb-collapsed .admin-nav-item:hover i.nav-icon{transform:scale(1.2);}
body.sb-collapsed .admin-nav-submenu{display:none;}
body.sb-collapsed #sidebarCollapseBtn i{transform:rotate(180deg);}
/* collapsed tooltip – tek sistem: JS ile #adminNavTip (CSS balon .admin-nav overflow tarafindan kesildigi icin kullanilmaz) */
body.sb-collapsed .admin-nav-item{position:relative;overflow:visible;}
body.sb-collapsed .admin-nav-item[data-tip]::after,
body.sb-collapsed .admin-nav-item[data-tip]::before{display:none !important;}
#adminNavTip{position:fixed;z-index:200;display:none;background:var(--bg-card);border:1px solid var(--border);color:var(--text);padding:7px 12px;border-radius:10px;font-size:12px;font-weight:700;white-space:nowrap;pointer-events:none;box-shadow:0 10px 28px rgba(0,0,0,.38);}
#adminNavTip::before{content:"";position:absolute;left:-4.5px;top:50%;width:8px;height:8px;transform:translateY(-50%) rotate(45deg);background:var(--bg-card);border-left:1px solid var(--border);border-bottom:1px solid var(--border);}
/* collapsed flyout: JS ile .vx-fly alan alt menuler (fixed; :hover+CSS kullanilmaz) */
body.sb-collapsed .admin-nav-submenu{display:none;}
body.sb-collapsed .admin-nav-submenu.vx-fly{display:flex;position:fixed;
  flex-direction:column;gap:2px;min-width:200px;max-width:260px;max-height:calc(100vh - 16px);overflow-y:auto;
  background:var(--bg-card);border:1px solid var(--border);border-radius:14px;
  padding:8px;box-shadow:0 16px 36px rgba(0,0,0,.42);z-index:200;}
body.sb-collapsed .admin-nav-submenu.vx-fly::before{content:"";position:absolute;left:-14px;top:0;bottom:0;width:14px;}
body.sb-collapsed .admin-nav-submenu{margin-top:0;}
#sidebarCollapseBtn i{transition:transform .25s;}
#sbResize{position:absolute;top:0;right:-5px;width:10px;height:100%;cursor:ew-resize;z-index:60;}
#sbResize::after{content:"";position:absolute;top:0;bottom:0;left:4px;width:2px;background:transparent;transition:background .2s;}
#sbResize:hover::after,#sbResize.drag::after{background:var(--accent);}
body.sb-collapsed #sbResize{display:none;}
@media(max-width:768px){#sbResize{display:none;}}
.admin-nav-item i.nav-icon{font-size:15px;}
.admin-nav-item{padding:11px 14px;font-size:13.5px;}
.admin-nav-subitem{font-size:12.5px;}
.admin-nav-subitem i{width:14px;font-size:12px;text-align:center;}

.admin-main{margin-left:var(--sidebar-w);flex:1;display:flex;flex-direction:column;min-height:100vh;min-width:0;transition:margin-left .25s ease;}
.admin-nav-item span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.admin-nav-subitem{min-width:0;}
.admin-user-card-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}

.admin-topbar{
  background:var(--bg-card);border-bottom:1px solid var(--border);
  padding:0 24px;height:56px;display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:40;
}
.admin-topbar-tabs{display:flex;gap:4px;background:var(--bg-surface);border-radius:10px;padding:3px;}
.admin-topbar-tab{
  display:flex;align-items:center;gap:6px;padding:6px 14px;border-radius:8px;
  font-size:12px;font-weight:700;color:var(--muted);cursor:pointer;transition:background .15s,color .15s;
  text-decoration:none;
}
.admin-topbar-tab:hover{color:var(--text);}
.admin-topbar-tab.active{background:var(--accent);color:#fff;}
.admin-topbar-tab.active i{color:#fff;}
.admin-topbar-right{display:flex;align-items:center;gap:12px;}
.admin-topbar-user{
  display:flex;align-items:center;gap:8px;padding:5px 10px 5px 6px;
  background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;
  cursor:pointer;font-size:12px;font-weight:700;transition:border-color .15s;
}
.admin-topbar-user:hover{border-color:var(--border-focus);}
.admin-topbar-user img{width:26px;height:26px;border-radius:50%;object-fit:cover;image-rendering:pixelated;}
.admin-topbar-user-sub{font-size:10px;font-weight:600;color:var(--muted);}

.admin-content{padding:24px;flex:1;}

.stat-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin-bottom:24px;}
.stat-card{
  background:var(--bg-card);border:1px solid var(--border);border-radius:16px;
  padding:20px 22px;transition:border-color .2s;position:relative;overflow:hidden;
}
.stat-card:hover{border-color:rgba(255,255,255,0.12);}
.stat-card-label{font-size:12px;font-weight:600;color:var(--muted);margin-bottom:8px;}
.stat-card-val{font-size:28px;font-weight:900;line-height:1;margin-bottom:4px;}
.stat-card-sub{font-size:11px;color:var(--accent);font-weight:600;margin-bottom:10px;}
.stat-card-trend{font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;}
.stat-card-trend.up{color:var(--green);}
.stat-card-trend.down{color:var(--red);}
.stat-card-period{font-size:11px;color:var(--muted);}
.stat-card-icon-bg{
  position:absolute;right:18px;top:18px;width:40px;height:40px;
  border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;
}
.stat-card-sparkline{margin-top:12px;height:32px;display:flex;align-items:flex-end;gap:3px;}
.sparkline-dot{width:8px;height:8px;border-radius:50%;border:2px solid;}

.admin-card{background:var(--bg-card);border:1px solid var(--border);border-radius:16px;padding:20px;margin-bottom:20px;}
.admin-card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;}
.admin-card-title{font-size:14px;font-weight:800;}

.admin-table{width:100%;border-collapse:collapse;display:block;overflow-x:auto;white-space:nowrap;}
.admin-table thead,.admin-table tbody{display:table;width:100%;}
.admin-table th{font-size:10px;font-weight:700;letter-spacing:.07em;text-transform:uppercase;color:var(--muted);padding:8px 14px;border-bottom:1px solid var(--border);text-align:left;}
.admin-table td{padding:11px 14px;border-bottom:1px solid var(--border);font-size:12px;font-weight:500;color:var(--text);}
.admin-table tr:last-child td{border-bottom:none;}
.admin-table tr{transition:background .12s;}
.admin-table tr:hover td{background:rgba(255,255,255,0.02);}

.badge{display:inline-flex;align-items:center;gap:4px;padding:3px 9px;border-radius:999px;font-size:10px;font-weight:700;}
.badge-green{background:rgba(34,197,94,.12);color:#4ade80;}
.badge-red{background:rgba(239,68,68,.1);color:#f87171;}
.badge-yellow{background:rgba(234,179,8,.12);color:#facc15;}
.badge-indigo{background:rgba(var(--accent-rgb,99,102,241),.12);color:var(--accent);}

.themes-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;}
.theme-card{background:var(--bg-card);border:2px solid var(--border);border-radius:16px;overflow:hidden;transition:border-color .2s,transform .2s;}
.theme-card:hover{transform:translateY(-3px);}
.theme-card.active-theme{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb,99,102,241),.12);}
.theme-card-preview{height:120px;background:linear-gradient(135deg,#131929,#1a2236);display:flex;align-items:center;justify-content:center;font-size:38px;color:var(--dim);position:relative;}
.theme-card-active-badge{position:absolute;top:8px;right:8px;background:var(--accent);color:#fff;font-size:9px;font-weight:800;padding:3px 9px;border-radius:999px;letter-spacing:.05em;text-transform:uppercase;}
.theme-card-body{padding:16px 18px;}
.theme-card-name{font-size:14px;font-weight:800;margin-bottom:3px;}
.theme-card-slug{font-size:11px;color:var(--muted);font-weight:600;margin-bottom:14px;}

.btn-admin{display:inline-flex;align-items:center;gap:7px;padding:9px 18px;border-radius:9px;font-family:'Plus Jakarta Sans',sans-serif;font-size:12px;font-weight:700;border:none;cursor:pointer;transition:background .2s,transform .1s;}
.btn-admin:active{transform:scale(.97);}
.btn-primary-admin{background:var(--accent);color:#fff;box-shadow:0 4px 12px rgba(var(--accent-rgb,99,102,241),.25);}
.btn-primary-admin:hover{background:var(--accent-dark);}
.btn-ghost-admin{background:var(--bg-surface);color:var(--muted);border:1px solid var(--border);}
.btn-ghost-admin:hover{color:var(--text);}
.btn-success-admin{background:var(--green);color:#fff;}
.btn-success-admin:hover{background:#16a34a;}

@keyframes fadeSlideUp{from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);}}
.animate-row{opacity:0;animation:fadeSlideUp .35s ease forwards;}

.admin-mobile-toggle{display:none;align-items:center;justify-content:center;width:36px;height:36px;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;color:var(--muted);font-size:16px;cursor:pointer;transition:color .15s,background .15s;}
.admin-mobile-toggle:hover{color:var(--text);background:var(--bg-hover);}
.admin-search-btn{display:flex;align-items:center;justify-content:center;width:36px;height:36px;background:linear-gradient(135deg,var(--accent),var(--accent-dark));border:none;border-radius:10px;color:#fff;font-size:15px;cursor:pointer;transition:transform .25s cubic-bezier(.34,1.56,.64,1),box-shadow .2s;flex-shrink:0;}
.admin-search-btn:hover{transform:scale(1.1);box-shadow:0 4px 16px rgba(var(--accent-rgb),.4);}
.admin-search-btn:active{transform:scale(.95);}

@media(max-width:768px){
  .admin-mobile-toggle{display:flex;}
  body.sb-collapsed .admin-sidebar{width:76px;}
  body.sb-collapsed .admin-sidebar .admin-nav-item span,
  body.sb-collapsed .admin-sidebar .admin-nav-item .nav-arrow,
  body.sb-collapsed .admin-sidebar .nav-section-label,
  body.sb-collapsed .admin-sidebar .admin-sidebar-logo-name,
  body.sb-collapsed .admin-sidebar .admin-user-card-info div,
  body.sb-collapsed .admin-sidebar .admin-user-card-logout{display:none;}
  body.sb-collapsed .admin-sidebar .admin-sidebar-logo,
  body.sb-collapsed .admin-sidebar .admin-user-card{justify-content:center;}
  body.sb-collapsed .admin-sidebar .admin-nav-item{justify-content:center;}
  body.sb-collapsed .admin-sidebar .admin-nav-item i.nav-icon{margin-right:0;font-size:20px;}
  body.sb-collapsed .sb-lang-wrap button span,
  body.sb-collapsed .sb-lang-wrap button i{display:none;}
  body.sb-collapsed .sb-lang-wrap button{justify-content:center;}
  body.sb-collapsed #sbLangMenu{min-width:180px;}
  .admin-sidebar{transform:translateX(-100%);}
  .admin-sidebar.open{transform:translateX(0);}
  .admin-main{margin-left:0;}
  .stat-grid{grid-template-columns:repeat(2,1fr);gap:12px;}
  .admin-topbar-tabs{display:none;}
  .admin-content{padding:16px;}
  .admin-topbar{padding:0 16px;}
  .admin-search-box{width:160px;}
  .admin-topbar-right{gap:6px;}
  .admin-topbar-right > .admin-topbar-user{display:none;}
  .admin-card{padding:14px;}
  .admin-card-header{flex-wrap:wrap;gap:8px;}
  .set-grid{grid-template-columns:1fr!important;gap:14px!important;}
  .set-grid > *{min-width:0;}
  #storeCurCards{grid-template-columns:repeat(3,1fr)!important;}
  .admin-table{display:block;overflow-x:auto;white-space:nowrap;-webkit-overflow-scrolling:touch;}
  .admin-table td, .admin-table th{padding:8px 10px;}
  .admin-table td:last-child{position:sticky;right:0;background:var(--bg-card);}
  .themes-grid{grid-template-columns:1fr;}
  #dashboardGrid{grid-template-columns:1fr!important;gap:16px;}
  .modal-inner-grid{grid-template-columns:1fr!important;}
  .ta-msgs{padding:12px!important;}
  .ticket-admin-left,.ticket-admin-right{padding:12px!important;}
  .admin-sidebar{width:min(280px,85vw);}
  [style*="grid-template-columns:repeat(5,1fr)"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:repeat(4,1fr)"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:repeat(2,1fr)"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:1fr 1fr"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:2fr 1fr"]{grid-template-columns:1fr!important;}
}

#adminNavOverlay{position:fixed;inset:0;background:rgba(0,0,0,.5);-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px);z-index:45;opacity:0;visibility:hidden;transition:opacity .25s ease,visibility .25s ease;}
#adminNavOverlay.show{opacity:1;visibility:visible;}

html.theme-morph, html.theme-morph *{transition:background-color .3s ease,border-color .3s ease,color .3s ease,box-shadow .3s ease !important;}

@media(max-width:480px){
  .admin-content{padding:12px;}
  .admin-card{padding:12px;}
  .stat-card{padding:14px;}
  .stat-card-val{font-size:20px;}
  .stat-card-icon{width:38px;height:38px;font-size:15px;}
  .stat-card-icon-bg{width:38px;height:38px;font-size:15px;}
  .admin-topbar{height:60px;}
  .btn-admin{width:100%;justify-content:center;}
  .admin-topbar-right a{font-size:11px;padding:5px 8px;}
  #primaryLangCards{grid-template-columns:1fr 1fr!important;}
  #storeCurCards{grid-template-columns:repeat(3,1fr)!important;gap:6px!important;}
  #storeCurCards button{padding:8px 4px!important;font-size:11px!important;}
  .set-grid .btn-admin{width:100%;justify-content:center;}
  #assetModal .relative{margin:0 8px;}
  .dash-chart-card{padding:14px!important;}
  .dash-chart-card canvas{max-height:240px;}
}
body.light-mode [style*="rgba(255,255,255,.06)"]{background-color:rgba(15,23,42,.05) !important;}
body.light-mode [style*="rgba(255,255,255,.08)"]{background-color:rgba(15,23,42,.06) !important;}
body.light-mode .icn-sel{background:rgba(15,23,42,.05);}
body.light-mode .seo-modal-close{background:rgba(15,23,42,.05);}
body.light-mode select option{background:#ffffff;color:#0f172a;}
select option{background:#111118;color:#e8eaf0;}
</style>
</head>
<body class="<?= $_adminBodyClass ?><?= (($_COOKIE['vx_sb'] ?? '0') === '1') ? ' sb-collapsed' : '' ?>">
<div class="admin-shell">

<aside class="admin-sidebar" id="adminSidebar">
  <div id="sbResize" title="<?= __('amenu.resize') ?>"></div>
  <div class="admin-sidebar-logo">
    <span class="admin-sidebar-logo-name"><?= e($_adminSiteName) ?></span>
    <div class="admin-sidebar-logo-icon" id="sidebarCollapseBtn"><i class="fa-solid fa-chevron-left"></i></div>
  </div>

  <div class="admin-user-card">
    <div class="admin-user-card-info">
      <img class="admin-user-card-avatar"
           src="<?= e($adminUser['avatar'] ?? 'https://minotar.net/avatar/user.png') ?>"
           onerror="this.src='https://minotar.net/avatar/user.png'" alt="avatar">
      <div>
        <div class="admin-user-card-name"><?= e($adminUser['username'] ?? 'Admin') ?></div>
        <div class="admin-user-card-role"><?= e($_adminRoleNames[$adminUser['role'] ?? 'user'] ?? __('nav.role_member')) ?></div>
      </div>
    </div>
    <form method="POST" action="/logout" style="margin:0;">
      <?= csrf_field() ?>
      <button type="submit" class="admin-user-card-logout" title="<?= __('amenu.logout_title') ?>" style="cursor:pointer;font:inherit;"><i class="fa-solid fa-arrow-right-from-bracket"></i></button>
    </form>
  </div>

  <nav class="admin-nav">
    <span class="nav-section-label"><?= __('amenu.general') ?></span>

    <?php if (has_permission('dashboard')): ?>
    <a href="/admin/dashboard.php" class="admin-nav-item <?= ($activePage??'')==='dashboard'?'active':'' ?>"
       data-track-key="dashboard" data-track-label="<?= __('amenu.dashboard') ?>" data-track-icon="fa-house">
      <i class="fa-solid fa-house nav-icon"></i><span><?= __('amenu.dashboard') ?></span>
    </a>
    <?php endif; ?>
    <?php if (has_permission('stats')): ?>
    <a href="/admin/stats.php" class="admin-nav-item <?= ($activePage??'')==='stats'?'active':'' ?>"
       data-track-key="stats" data-track-label="<?= __('amenu.stats') ?>" data-track-icon="fa-chart-line">
      <i class="fa-solid fa-chart-line nav-icon"></i><span><?= __('amenu.stats') ?></span>
    </a>
    <?php endif; ?>

    <div class="admin-nav-item <?= in_array($activePage??'',['users','permissions','purchases'])?'active':'' ?>"
         onclick="toggleSub('subUsers',this)" id="navUsers">
      <i class="fa-solid fa-users nav-icon"></i>
      <span><?= __('amenu.users') ?></span>
      <i class="fa-solid fa-chevron-right nav-arrow"></i>
    </div>
    <div class="admin-nav-submenu <?= in_array($activePage??'',['users','permissions','purchases'])?'open':'' ?>" id="subUsers">
      <?php if (has_permission('users')): ?>
      <a href="/admin/users.php" class="admin-nav-subitem <?= ($activePage??'')==='users'?'active':'' ?>"
         data-track-key="users" data-track-label="<?= __('amenu.users') ?>" data-track-icon="fa-user">
        <i class="fa-regular fa-user"></i> <?= __('amenu.users') ?>
      </a>
      <a href="/admin/users.php?tab=balance" class="admin-nav-subitem"
         data-track-key="users-balance" data-track-label="<?= __('amenu.users_balance') ?>" data-track-icon="fa-credit-card">
        <i class="fa-solid fa-credit-card"></i> <?= __('amenu.users_balance') ?>
      </a>
      <?php endif; ?>
      <?php if (has_permission('purchases')): ?>
      <a href="/admin/purchases.php" class="admin-nav-subitem <?= ($activePage??'')==='purchases'?'active':'' ?>"
         data-track-key="purchases" data-track-label="<?= __('amenu.purchases') ?>" data-track-icon="fa-bag-shopping">
        <i class="fa-solid fa-bag-shopping"></i> <?= __('amenu.purchases') ?>
      </a>
      <?php endif; ?>
      <?php if (has_permission('permissions') && function_exists('feature_active') && feature_active('roles_permissions') && (!function_exists('plan_current') || (plan_current()['slug'] ?? 'free') !== 'free')): ?>
      <a href="/admin/permissions.php" class="admin-nav-subitem <?= ($activePage??'')==='permissions'?'active':'' ?>"
         data-track-key="permissions" data-track-label="<?= __('amenu.permissions') ?>" data-track-icon="fa-shield-halved">
        <i class="fa-solid fa-shield-halved"></i> <?= __('amenu.permissions') ?>
      </a>
      <?php endif; ?>
    </div>

    <?php if (has_permission('products') || has_permission('purchases') || has_permission('categories') || has_permission('licenses') || has_permission('reviews') || has_permission('slider') || has_permission('audit-logs') || has_permission('legal') || (has_permission('announcements') && feature_active('announcements'))): ?>
     <div class="admin-nav-item <?= in_array($activePage??'',['products','licenses','categories','reviews','legal','slider','announcements','audit-logs'])?'active':'' ?>"
          onclick="toggleSub('subMagaza',this)" id="navMagaza">
       <i class="fa-solid fa-store nav-icon"></i>
       <span><?= __('amenu.group_store') ?></span>
       <i class="fa-solid fa-chevron-right nav-arrow"></i>
     </div>
     <div class="admin-nav-submenu <?= in_array($activePage??'',['products','licenses','categories','reviews','legal','slider','announcements','audit-logs'])?'open':'' ?>" id="subMagaza">
       <?php if (has_permission('products')): ?>
       <a href="/admin/products.php" class="admin-nav-subitem <?= ($activePage??'')==='products'?'active':'' ?>"
          data-track-key="products" data-track-label="<?= __('amenu.products') ?>" data-track-icon="fa-box-open">
         <i class="fa-solid fa-box-open"></i> <?= __('amenu.products') ?>
       </a>
       <?php endif; ?>
       <?php if (has_permission('categories')): ?>
       <a href="/admin/categories.php" class="admin-nav-subitem <?= ($activePage??'')==='categories'?'active':'' ?>"
          data-track-key="categories" data-track-label="<?= __('amenu.categories') ?>" data-track-icon="fa-tags">
         <i class="fa-solid fa-tags"></i> <?= __('amenu.categories') ?>
       </a>
       <?php endif; ?>
        <?php if (has_permission('reviews') && feature_active('reviews')): ?>
        <a href="/admin/reviews.php" class="admin-nav-subitem <?= ($activePage??'')==='reviews'?'active':'' ?>"
          data-track-key="reviews" data-track-label="<?= __('amenu.reviews') ?>" data-track-icon="fa-star">
         <i class="fa-solid fa-star"></i> <?= __('amenu.reviews') ?>
       </a>
       <?php endif; ?>
       <?php if (has_permission('licenses')): ?>
       <a href="/admin/licenses.php" class="admin-nav-subitem <?= ($activePage??'')==='licenses'?'active':'' ?>"
          data-track-key="licenses" data-track-label="<?= __('amenu.licenses') ?>" data-track-icon="fa-key">
         <i class="fa-solid fa-key"></i> <?= __('amenu.licenses') ?>
       </a>
       <?php endif; ?>
        <?php if (has_permission('slider')): ?>
         <a href="/admin/slider.php" class="admin-nav-subitem <?= ($activePage??'')==='slider'?'active':'' ?>"
           data-track-key="slider" data-track-label="<?= __('amenu.slider') ?>" data-track-icon="fa-images">
          <i class="fa-solid fa-images"></i> <?= __('amenu.slider') ?>
        </a>
        <?php endif; ?>
        <?php if (has_permission('announcements') && feature_active('announcements')): ?>
        <a href="/admin/announcements.php" class="admin-nav-subitem <?= ($activePage??'')==='announcements'?'active':'' ?>"
           data-track-key="announcements" data-track-label="<?= __('amenu.announcements') ?>" data-track-icon="fa-bullhorn">
          <i class="fa-solid fa-bullhorn"></i> <?= __('amenu.announcements') ?>
        </a>
        <?php endif; ?>
       <?php if (has_permission('audit-logs')): ?>
       <a href="/admin/audit-logs.php" class="admin-nav-subitem <?= ($activePage??'')==='audit-logs'?'active':'' ?>"
          data-track-key="audit-logs" data-track-label="<?= __('amenu.audit_logs') ?>" data-track-icon="fa-clock-rotate-left">
         <i class="fa-solid fa-clock-rotate-left"></i> <?= __('amenu.audit_logs') ?>
       </a>
       <?php endif; ?>
       <?php if (has_permission('legal')): ?>
       <a href="/admin/legal.php" class="admin-nav-subitem <?= ($activePage??'')==='legal'?'active':'' ?>"
          data-track-key="legal" data-track-label="<?= __('amenu.legal') ?>" data-track-icon="fa-gavel">
         <i class="fa-solid fa-gavel"></i> <?= __('amenu.legal') ?>
       </a>
       <?php endif; ?>
     </div>
    <?php endif; ?>

    <?php if ((has_permission('coupons') && feature_active('coupons')) || (has_permission('references') && feature_active('references')) || (has_permission('seo') && feature_active('seo')) || (has_permission('custom_pages') && feature_active('custom_pages'))): ?>
    <div class="admin-nav-item <?= in_array($activePage??'',['coupons','references','seo','custom-pages','faqs'])?'active':'' ?>"
         onclick="toggleSub('subPazarlama',this)" id="navPazarlama">
      <i class="fa-solid fa-chart-bar nav-icon"></i>
      <span><?= __('amenu.group_marketing') ?></span>
      <i class="fa-solid fa-chevron-right nav-arrow"></i>
    </div>
    <div class="admin-nav-submenu <?= in_array($activePage??'',['coupons','references','seo','custom-pages','faqs'])?'open':'' ?>" id="subPazarlama">
      <?php if (has_permission('coupons') && feature_active('coupons')): ?>
      <a href="/admin/coupons.php" class="admin-nav-subitem <?= ($activePage??'')==='coupons'?'active':'' ?>"
         data-track-key="coupons" data-track-label="<?= __('amenu.coupons') ?>" data-track-icon="fa-ticket">
        <i class="fa-solid fa-ticket"></i> <?= __('amenu.coupons') ?>
      </a>
      <a href="/admin/coupons.php?tab=usages" class="admin-nav-subitem"
         data-track-key="coupons-usage" data-track-label="<?= __('amenu.coupons_usage') ?>" data-track-icon="fa-list-check">
        <i class="fa-solid fa-list-check"></i> <?= __('amenu.coupons_usage') ?>
      </a>
      <?php endif; ?>
      <?php if (has_permission('references') && feature_active('references')): ?>
      <a href="/admin/references.php" class="admin-nav-subitem <?= ($activePage??'')==='references'?'active':'' ?>"
         data-track-key="references" data-track-label="<?= __('amenu.references') ?>" data-track-icon="fa-quote-right">
        <i class="fa-solid fa-quote-right"></i> <?= __('amenu.references') ?>
      </a>
      <?php endif; ?>
      <?php if (has_permission('seo') && feature_active('seo')): ?>
      <a href="/admin/seo.php" class="admin-nav-subitem <?= ($activePage??'')==='seo'?'active':'' ?>"
         data-track-key="seo" data-track-label="<?= __('amenu.seo') ?>" data-track-icon="fa-magnifying-glass-chart">
        <i class="fa-solid fa-magnifying-glass-chart"></i> <?= __('amenu.seo') ?>
      </a>
      <?php endif; ?>
      <?php if (has_permission('custom_pages') && feature_active('custom_pages')): ?>
      <a href="/admin/custom-pages.php" class="admin-nav-subitem <?= ($activePage??'')==='custom-pages'?'active':'' ?>"
         data-track-key="custom-pages" data-track-label="<?= __('amenu.custom_pages') ?>" data-track-icon="fa-file-lines">
        <i class="fa-solid fa-file-lines"></i> <?= __('amenu.custom_pages') ?>
      </a>
      <?php endif; ?>
      <?php if (has_permission('products')): ?>
      <a href="/admin/faqs.php" class="admin-nav-subitem <?= ($activePage??'')==='faqs'?'active':'' ?>"
         data-track-key="faqs" data-track-label="<?= __('amenu.faqs') ?>" data-track-icon="fa-circle-question">
        <i class="fa-solid fa-circle-question"></i> <?= __('amenu.faqs') ?>
      </a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if (has_permission('themes')): ?>
    <div class="admin-nav-item <?= in_array($activePage??'',['themes','custom-css','header-editor','footer-editor'])?'active':'' ?>"
         onclick="toggleSub('subGorunum',this)" id="navGorunum">
      <i class="fa-solid fa-palette nav-icon"></i>
      <span><?= __('amenu.group_appear') ?></span>
      <i class="fa-solid fa-chevron-right nav-arrow"></i>
    </div>
    <div class="admin-nav-submenu <?= in_array($activePage??'',['themes','custom-css','header-editor','footer-editor'])?'open':'' ?>" id="subGorunum">
      <a href="/admin/themes.php" class="admin-nav-subitem <?= ($activePage??'')==='themes'?'active':'' ?>"
         data-track-key="themes" data-track-label="<?= __('amenu.themes') ?>" data-track-icon="fa-swatchbook">
        <i class="fa-solid fa-swatchbook"></i> <?= __('amenu.themes') ?>
      </a>
      <a href="/admin/header-editor.php" class="admin-nav-subitem <?= ($activePage??'')==='header-editor'?'active':'' ?>"
         data-track-key="header-editor" data-track-label="<?= __('amenu.header_editor') ?>" data-track-icon="fa-bars">
        <i class="fa-solid fa-bars"></i> <?= __('amenu.header_editor') ?>
      </a>
      <a href="/admin/footer-editor.php" class="admin-nav-subitem <?= ($activePage??'')==='footer-editor'?'active':'' ?>"
         data-track-key="footer-editor" data-track-label="<?= __('amenu.footer_editor') ?>" data-track-icon="fa-bars-staggered">
        <i class="fa-solid fa-bars-staggered"></i> <?= __('amenu.footer_editor') ?>
      </a>
      <a href="/admin/custom-css.php" class="admin-nav-subitem <?= ($activePage??'')==='custom-css'?'active':'' ?>"
         data-track-key="custom-css" data-track-label="<?= __('amenu.custom_css') ?>" data-track-icon="fa-code">
        <i class="fa-solid fa-code"></i> <?= __('amenu.custom_css') ?>
      </a>
    </div>
    <?php endif; ?>

    <?php if (has_permission('support') || has_permission('ticket_categories')): ?>
    <div class="admin-nav-item <?= in_array($activePage??'',['support','ticket_categories'])?'active':'' ?>"
         onclick="toggleSub('subDestek',this)" id="navDestek">
      <i class="fa-solid fa-headset nav-icon"></i>
      <span><?= __('amenu.group_support') ?></span>
      <i class="fa-solid fa-chevron-right nav-arrow"></i>
    </div>
    <div class="admin-nav-submenu <?= in_array($activePage??'',['support','ticket_categories'])?'open':'' ?>" id="subDestek">
      <?php if (has_permission('support')): ?>
      <a href="/admin/support.php" class="admin-nav-subitem <?= ($activePage??'')==='support'?'active':'' ?>"
         data-track-key="support" data-track-label="<?= __('amenu.support') ?>" data-track-icon="fa-message">
        <i class="fa-solid fa-message"></i> <?= __('amenu.support') ?>
      </a>
      <?php endif; ?>
      <?php if (has_permission('ticket_categories')): ?>
      <a href="/admin/ticket-categories.php" class="admin-nav-subitem <?= ($activePage??'')==='ticket_categories'?'active':'' ?>"
         data-track-key="ticket-categories" data-track-label="<?= __('amenu.ticket_categories') ?>" data-track-icon="fa-tags">
        <i class="fa-solid fa-tags"></i> <?= __('amenu.ticket_categories') ?>
      </a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if (has_permission('settings') || has_permission('integrations') || has_permission('modules')): ?>
    <div class="admin-nav-item <?= in_array($activePage??'',['settings','integrations','modules','discord-webhook'])?'active':'' ?>"
         onclick="toggleSub('subAyarlar',this)" id="navAyarlar">
      <i class="fa-solid fa-gear nav-icon"></i>
      <span><?= __('amenu.group_settings') ?></span>
      <i class="fa-solid fa-chevron-right nav-arrow"></i>
    </div>
    <div class="admin-nav-submenu <?= in_array($activePage??'',['settings','integrations','modules'])?'open':'' ?>" id="subAyarlar">
      <?php if (has_permission('settings')): ?>
      <a href="/admin/settings.php?tab=site" class="admin-nav-subitem <?= ($tab??($_GET['tab']??'site'))==='site'?'active':'' ?>"
         data-track-key="settings-site" data-track-label="<?= __('amenu.settings_site') ?>" data-track-icon="fa-sliders">
        <i class="fa-solid fa-sliders"></i> <?= __('amenu.settings_site') ?>
      </a>
      <a href="/admin/settings.php?tab=social" class="admin-nav-subitem <?= ($tab??'')==='social'?'active':'' ?>"
         data-track-key="settings-social" data-track-label="<?= __('amenu.settings_social') ?>" data-track-icon="fa-share-nodes">
        <i class="fa-solid fa-share-nodes"></i> <?= __('amenu.settings_social') ?>
      </a>
      <a href="/admin/mail-settings.php" class="admin-nav-subitem <?= ($activePage??'')==='mail-settings'?'active':'' ?>"
         data-track-key="mail-settings" data-track-label="<?= __('amenu.mail_settings') ?>" data-track-icon="fa-envelope">
        <i class="fa-solid fa-envelope"></i> <?= __('amenu.mail_settings') ?>
      </a>
      <a href="/admin/mail-templates.php" class="admin-nav-subitem <?= ($activePage??'')==='mail-templates'?'active':'' ?>"
         data-track-key="mail-templates" data-track-label="<?= __('amenu.mail_templates') ?>" data-track-icon="fa-envelope-open-text">
        <i class="fa-solid fa-envelope-open-text"></i> <?= __('amenu.mail_templates') ?>
      </a>
      <?php endif; ?>
      <?php if (has_permission('integrations')): ?>
      <a href="/admin/integrations.php" class="admin-nav-subitem <?= ($activePage??'')==='integrations'?'active':'' ?>"
         data-track-key="integrations" data-track-label="<?= __('amenu.integrations') ?>" data-track-icon="fa-plug">
        <i class="fa-solid fa-plug"></i> <?= __('amenu.integrations') ?>
      </a>
      <?php endif; ?>
      <?php if (has_permission('modules')): ?>
      <a href="/admin/modules.php" class="admin-nav-subitem <?= ($activePage??'')==='modules'?'active':'' ?>"
         data-track-key="modules" data-track-label="<?= __('amenu.modules') ?>" data-track-icon="fa-puzzle-piece">
        <i class="fa-solid fa-puzzle-piece"></i> <?= __('amenu.modules') ?>
      </a>
      <?php endif; ?>
      <?php if (has_permission('integrations') && feature_active('discord_integration')): ?>
      <a href="/admin/discord-webhook.php" class="admin-nav-subitem <?= ($activePage??'')==='discord-webhook'?'active':'' ?>"
         data-track-key="discord-webhook" data-track-label="<?= __('amenu.discord_webhook') ?>" data-track-icon="fa-brands fa-discord">
        <i class="fa-brands fa-discord"></i> <?= __('amenu.discord_webhook') ?>
      </a>
      <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if (function_exists('do_action')) do_action('admin_menu'); ?>
  </nav>
  <?php $sbLang = function_exists('lang_active') ? lang_active() : 'tr'; if ($sbLang !== 'tr' && $sbLang !== 'en') $sbLang = 'tr'; ?>
  <div class="sb-lang-wrap" style="padding:10px;border-top:1px solid var(--border);position:relative;flex-shrink:0;">
    <button type="button" onclick="var m=document.getElementById('sbLangMenu');m.style.display=m.style.display==='block'?'none':'block';" style="width:100%;display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:9px;background:rgba(255,255,255,.03);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:12px;font-weight:800;cursor:pointer;" title="<?= __('amenu.admin_lang') ?>">
      <img src="/assets/images/flags/<?= $sbLang ?>.svg" alt="" style="width:22px;height:15px;border-radius:2px;object-fit:cover;">
      <span><?= strtoupper($sbLang) ?></span>
      <i class="fa-solid fa-chevron-up" style="margin-left:auto;font-size:10px;color:var(--muted);"></i>
    </button>
    <div id="sbLangMenu" style="display:none;position:absolute;left:10px;right:10px;bottom:calc(100% + 6px);background:var(--bg-card);border:1px solid var(--border);border-radius:10px;padding:6px;box-shadow:0 12px 32px rgba(0,0,0,.45);z-index:60;">
      <form method="POST" action="/action.php" style="margin:0;display:flex;flex-direction:column;gap:4px;">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="admin_set_language">
        <button type="submit" name="lang" value="tr" style="display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:7px;background:<?= $sbLang==='tr'?'rgba(255,255,255,.07)':'transparent' ?>;border:none;color:var(--text);font-family:inherit;font-size:12px;font-weight:700;cursor:pointer;text-align:left;">
          <img src="/assets/images/flags/tr.svg" alt="" style="width:22px;height:15px;border-radius:2px;object-fit:cover;"> <?= __('amenu.lang_tr') ?>
        </button>
        <button type="submit" name="lang" value="en" style="display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:7px;background:<?= $sbLang==='en'?'rgba(255,255,255,.07)':'transparent' ?>;border:none;color:var(--text);font-family:inherit;font-size:12px;font-weight:700;cursor:pointer;text-align:left;">
          <img src="/assets/images/flags/en.svg" alt="" style="width:22px;height:15px;border-radius:2px;object-fit:cover;"> English
        </button>
      </form>
    </div>
  </div>
</aside>

<div id="adminNavOverlay"></div>

<div class="admin-main">
  <header class="admin-topbar">
    <div style="display:flex;align-items:center;gap:12px;">
      <button id="mobileSidebarToggle" class="admin-mobile-toggle" aria-label="<?= __('amenu.menu') ?>">
        <i class="fa-solid fa-bars"></i>
      </button>
      <button id="adminSearchBtn" class="admin-search-btn" aria-label="<?= __('amenu.search') ?>">
        <i class="fa-solid fa-magnifying-glass"></i>
      </button>
    </div>
    <div class="admin-topbar-right">
      <a href="/" style="font-size:12px;color:var(--muted);font-weight:600;display:flex;align-items:center;gap:5px;padding:5px 10px;background:var(--bg-surface);border:1px solid var(--border);border-radius:8px;">
        <i class="fa-solid fa-arrow-up-right-from-square"></i> <?= __('amenu.view_site') ?>
      </a>
    </div>
  </header>
  <div class="admin-content">
<?php
$planBanner = null;
if (isset($adminDb) && $adminDb && function_exists('plan_revenue_state') && function_exists('plan_product_count') && function_exists('plan_product_limit')) {
    try {
        $pbState = plan_revenue_state($adminDb);
        $pbPLim = plan_product_limit();
        $pbPCount = plan_product_count($adminDb);
        $pbProdFull = ($pbPLim >= 0 && $pbPCount >= $pbPLim);
        if ($pbState === 'locked' || $pbProdFull) $planBanner = 'red';
        elseif ($pbState === 'warning') $planBanner = 'yellow';
        if ($planBanner) {
            $pbRevSum = function_exists('plan_revenue_sum') ? plan_revenue_sum($adminDb) : 0.0;
            $pbRevLim = plan_revenue_limit_usd();
            $pbStore = function_exists('store_currency') ? store_currency() : 'TRY';
            $pbLimStore = ($pbRevLim >= 0 && function_exists('fx_convert')) ? (float)fx_convert($pbRevLim, 'USD', $pbStore) : $pbRevLim;
        }
    } catch (\Throwable $e) { $planBanner = null; }
}
if ($planBanner):
    $pbRed = $planBanner === 'red';
?>
<div class="admin-plan-banner" style="border:1px solid <?= $pbRed ? 'rgba(239,68,68,.45)' : 'rgba(250,204,21,.45)' ?>;background:<?= $pbRed ? 'linear-gradient(135deg,rgba(239,68,68,.14),rgba(239,68,68,.03))' : 'linear-gradient(135deg,rgba(250,204,21,.14),rgba(250,204,21,.03))' ?>;border-radius:16px;padding:14px 18px;margin-bottom:20px;">
  <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
    <div style="width:38px;height:38px;border-radius:12px;display:grid;place-items:center;background:<?= $pbRed ? 'rgba(239,68,68,.15);color:#f87171' : 'rgba(250,204,21,.15);color:#facc15' ?>;"><i class="fa-solid <?= $pbRed ? 'fa-ban' : 'fa-triangle-exclamation' ?>"></i></div>
    <div style="flex:1;min-width:220px;">
      <?php if ($pbState === 'locked'): ?>
      <div style="font-weight:800;font-size:14px;"><?= e(__('plan.banner_locked_rev')) ?></div>
      <?php elseif ($pbState === 'warning'): ?>
      <div style="font-weight:800;font-size:14px;"><?= e(__('plan.banner_warn_rev', ['pct' => $pbRevLim > 0 ? (int)round($pbRevSum / $pbRevLim * 100) : 0, 'sum' => fmt_money($pbRevSum), 'limit' => $pbLimStore >= 0 ? fmt_money($pbLimStore) : __('plan.unlimited')])) ?></div>
      <?php endif; ?>
      <?php if ($pbProdFull): ?>
      <div style="font-size:13px;color:var(--text);margin-top:2px;"><?= e(__('plan.banner_products_full', ['have' => $pbPCount, 'limit' => $pbPLim])) ?></div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>
<?php
$updBanner = null;
if (function_exists('update_gate') && update_gate() && isset($adminDb) && $adminDb) {
    try {
        if (function_exists('update_available') && update_available($adminDb) && !update_delay_blocked($adminDb)) {
            $updSt = update_state($adminDb);
            $updBanner = [
                'version'     => $updSt['version'],
                'description' => $updSt['description'],
                'file_size'   => $updSt['file_size'],
                'current'     => vexaris_current_version($adminDb),
                'auto'        => update_auto_enabled($adminDb),
            ];
        }
    } catch (\Throwable $e) {}
}
if ($updBanner):
?>
<div class="admin-update-banner">
  <div class="admin-update-banner-inner">
    <div class="admin-update-icon"><i class="fa-solid fa-download"></i></div>
    <div class="admin-update-info">
      <div class="admin-update-title"><?= __('amenu.update_avail') ?> &mdash; v<?= e($updBanner['version']) ?></div>
      <div class="admin-update-desc">
        <?= __('amenu.installed') ?> v<?= e($updBanner['current']) ?> &middot; <?= __('amenu.size') ?> <?= e($updBanner['file_size']) ?><?php if ($updBanner['description'] !== ''): ?> &middot; <?= e($updBanner['description']) ?><?php endif; ?>
      </div>
    </div>
    <div class="admin-update-actions">
      <?php if ($updBanner['auto']): ?>
      <a href="/admin/update.php" class="admin-update-btn admin-update-btn-primary"><i class="fa-solid fa-wand-magic-sparkles"></i> <?= __('amenu.auto_install') ?></a>
      <?php else: ?>
      <a href="/admin/update.php" class="admin-update-btn admin-update-btn-primary"><i class="fa-solid fa-cloud-arrow-down"></i> <?= __('amenu.update') ?></a>
      <?php endif; ?>
      <button type="button" class="admin-update-btn admin-update-btn-ghost" onclick="vxUpdateDelay()"><i class="fa-solid fa-clock"></i> <?= __('amenu.later') ?></button>
    </div>
  </div>
</div>
<style>
@keyframes vxUpdPulse{0%,100%{box-shadow:0 0 0 0 rgba(var(--accent-rgb,99,102,241),.35)}50%{box-shadow:0 0 0 10px rgba(var(--accent-rgb,99,102,241),0)}}
@keyframes vxUpdFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-3px)}}
.admin-update-banner{position:relative;border:1px solid rgba(var(--accent-rgb,99,102,241),.4);background:linear-gradient(135deg,rgba(var(--accent-rgb,99,102,241),.14),rgba(var(--accent-rgb,99,102,241),.03));border-radius:16px;padding:14px 18px;margin-bottom:20px;overflow:hidden;animation:vxUpdPulse 2.5s ease-in-out infinite;}
.admin-update-banner::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--accent),transparent);animation:vxUpdPulse 2.5s ease-in-out infinite;}
.admin-update-banner-inner{display:flex;align-items:center;gap:14px;flex-wrap:wrap;}
.admin-update-icon{width:44px;height:44px;border-radius:12px;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;animation:vxUpdFloat 2s ease-in-out infinite;}
.admin-update-info{flex:1;min-width:200px;}
.admin-update-title{font-size:14px;font-weight:800;color:var(--text);}
.admin-update-desc{font-size:12px;color:var(--muted);margin-top:2px;}
.admin-update-actions{display:flex;gap:8px;flex-wrap:wrap;}
.admin-update-btn{display:inline-flex;align-items:center;gap:7px;padding:9px 16px;border-radius:10px;font-size:12px;font-weight:700;border:none;cursor:pointer;font-family:inherit;transition:transform .15s,background .2s;text-decoration:none;}
.admin-update-btn:active{transform:scale(.97);}
.admin-update-btn-primary{background:var(--accent);color:#fff;}
.admin-update-btn-primary:hover{background:var(--accent-dark);}
.admin-update-btn-ghost{background:var(--bg-surface);color:var(--muted);border:1px solid var(--border);}
.admin-update-btn-ghost:hover{color:var(--text);}
</style>
<script>
function vxUpdateDelay() {
  var fd = new FormData();
  fd.append('action', 'update_delay');
  fetch('/action.php', { method:'POST', body: fd, headers:{'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').getAttribute('content')} })
    .then(function(r){ return r.json(); })
    .then(function(d){
      if (d.ok) {
        var b = document.querySelector('.admin-update-banner');
        if (b) b.remove();
        alert(d.msg);
      } else {
        alert(d.msg || <?= json_encode(__('amenu.op_fail')) ?>);
      }
    })
    .catch(function(){ alert(<?= json_encode(__('amenu.conn_err')) ?>); });
}
</script>
<?php endif; ?>
