<?php
if (!defined('NEXUS_BOOT'))  define('NEXUS_BOOT', true);
if (!defined('ROOT_PATH'))   define('ROOT_PATH', dirname(__DIR__));

require_once ROOT_PATH . '/core/init.php';

if (function_exists('feature_active') && !feature_active('admin_panel')) {
    http_response_code(404);
    exit;
}
license_gate_require('admin_panel');

if (!auth_check()) {
    header('Location: /login', true, 302); exit;
}

$db = nexus_db();
if ($db) {
    try {
        $stmt = $db->prepare('SELECT role FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$_SESSION['user']['id']]);
        $row = $stmt->fetch();
        if ($row) {
            $_SESSION['user']['role'] = $row['role'];
        }
    } catch (Exception $e) {}
}

$role = $_SESSION['user']['role'] ?? 'user';
if (!in_array($role, ['admin', 'superadmin'], true)) {
    $hasPerm = false;
    if ($db) {
        try {
            $pSt = $db->prepare('SELECT COUNT(*) FROM permissions WHERE role=?');
            $pSt->execute([$role]);
            $hasPerm = (int)$pSt->fetchColumn() > 0;
        } catch (Exception $e) {}
    }
    if (!$hasPerm) {
        header('Location: /', true, 302); exit;
    }
}

header('Location: /admin/dashboard.php', true, 302);
exit;