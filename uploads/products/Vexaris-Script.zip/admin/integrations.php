<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.integrations');
$activePage = 'integrations';

$settingsRaw = $adminDb->query("SELECT `key`,`value` FROM settings")->fetchAll();
$settings = [];
foreach ($settingsRaw as $r) $settings[$r['key']] = $r['value'];

$integrations = [
    'cf_captcha' => [
        'label' => 'Cloudflare Turnstile',
        'desc' => __('aint.desc_cf'),
        'icon' => 'fa-cloudflare',
        'color' => '#f38020',
        'type' => 'captcha',
        'fields' => [
            ['key'=>'site_key','label'=>'Site Key','placeholder'=>'0x4AAAA...'],
            ['key'=>'secret_key','label'=>'Secret Key','placeholder'=>'0x4AAAA...'],
        ],
    ],
    'recaptcha' => [
        'label' => 'Google reCAPTCHA',
        'desc' => __('aint.desc_recaptcha'),
        'icon' => 'fa-google',
        'color' => '#4285f4',
        'type' => 'captcha',
        'fields' => [
            ['key'=>'site_key','label'=>'Site Key','placeholder'=>'6Lc...'],
            ['key'=>'secret_key','label'=>'Secret Key','placeholder'=>'6Lc...'],
        ],
    ],
    'google_auth' => [
        'label' => __('aint.login_google'),
        'desc' => __('aint.desc_google'),
        'icon' => 'fa-google',
        'color' => '#4285f4',
        'type' => 'auth',
        'fields' => [
            ['key'=>'client_id','label'=>'Client ID','placeholder'=>'123456789-xxxx.apps.googleusercontent.com'],
            ['key'=>'client_secret','label'=>'Client Secret','placeholder'=>'GOCSPX-...'],
        ],
    ],
    'discord_auth' => [
        'label' => __('aint.login_discord'),
        'desc' => __('aint.desc_discord'),
        'icon' => 'fa-discord',
        'color' => '#5865f2',
        'type' => 'auth',
        'fields' => [
            ['key'=>'client_id','label'=>'Client ID','placeholder'=>'123456789012345678'],
            ['key'=>'client_secret','label'=>'Client Secret','placeholder'=>'AbCdEf...'],
        ],
    ],
    'microsoft_auth' => [
        'label' => __('aint.login_microsoft'),
        'desc' => __('aint.desc_microsoft'),
        'icon' => 'fa-microsoft',
        'color' => '#00a4ef',
        'type' => 'auth',
        'fields' => [
            ['key'=>'client_id','label'=>'Client ID (Application ID)','placeholder'=>'00000000-0000-0000-0000-000000000000'],
            ['key'=>'client_secret','label'=>'Client Secret','placeholder'=>'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'],
        ],
    ],
    'github_auth' => [
        'label' => __('aint.login_github'),
        'desc' => __('aint.desc_github'),
        'icon' => 'fa-github',
        'color' => '#181717',
        'type' => 'auth',
        'fields' => [
            ['key'=>'client_id','label'=>'Client ID','placeholder'=>'Ov23li...'],
            ['key'=>'client_secret','label'=>'Client Secret','placeholder'=>'ghp_...'],
        ],
    ],
    'shopier' => [
        'label' => 'Shopier',
        'desc' => __('aint.desc_shopier'),
        'icon' => 'fa-credit-card',
        'iconPrefix' => 'fa-solid',
        'color' => '#F7931A',
        'img' => '/images/payments/shopier.png',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'pat','label'=>'Personal Access Token (PAT)','type'=>'password','placeholder'=>__('aint.ph_shopier_pat')],
            ['key'=>'shop_slug','label'=>__('aint.store_slug'),'placeholder'=>__('aint.ph_ex_shop')],
            ['key'=>'osb_username','label'=>__('aint.osb_user'),'placeholder'=>__('aint.ph_osb_user')],
            ['key'=>'osb_password','label'=>__('aint.osb_pass'),'type'=>'password','placeholder'=>__('aint.ph_osb_pass')],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'Shopier'],
            ['key'=>'currency','label'=>__('aint.currency'),'type'=>'select','options'=>['TRY','USD','EUR']],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'paytr' => [
        'label' => 'PayTR',
        'desc' => __('aint.desc_paytr'),
        'icon' => 'fa-credit-card',
        'iconPrefix' => 'fa-solid',
        'color' => '#2E7D32',
        'img' => '/images/payments/paytr.png',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'merchant_id','label'=>__('aint.store_no'),'placeholder'=>__('aint.ph_paytr_info')],
            ['key'=>'merchant_key','label'=>__('aint.store_key'),'placeholder'=>__('aint.ph_paytr_info')],
            ['key'=>'merchant_salt','label'=>__('aint.store_salt'),'placeholder'=>__('aint.ph_paytr_info')],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'PayTR'],
            ['key'=>'currency','label'=>__('aint.currency'),'type'=>'select','options'=>['TRY','USD','EUR']],
            ['key'=>'test_mode','label'=>__('aint.test_mode'),'type'=>'select','options'=>[['value'=>'0','label'=>__('aint.off_live')],['value'=>'1','label'=>__('aint.on_testcard')]]],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'iyzico' => [
        'label' => 'iyzico',
        'desc' => __('aint.desc_iyzico'),
        'icon' => 'fa-credit-card',
        'iconPrefix' => 'fa-solid',
        'color' => '#FF6B00',
        'img' => '/images/payments/iyzico.png',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'api_key','label'=>__('aint.api_key'),'placeholder'=>__('aint.ph_sandbox')],
            ['key'=>'secret_key','label'=>__('aint.secret_key'),'placeholder'=>__('aint.ph_sandbox')],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'iyzico'],
            ['key'=>'currency','label'=>__('aint.currency'),'type'=>'select','options'=>['TRY','USD','EUR']],
            ['key'=>'test_mode','label'=>__('aint.test_mode'),'type'=>'select','options'=>[['value'=>'0','label'=>__('aint.off_live')],['value'=>'1','label'=>__('aint.on_sandbox')]]],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'stripe' => [
        'label' => 'Stripe',
        'desc' => __('aint.desc_stripe'),
        'icon' => 'fa-credit-card',
        'iconPrefix' => 'fa-solid',
        'color' => '#635BFF',
        'img' => '/images/payments/stripe.png',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'api_key','label'=>__('aint.sk_key'),'placeholder'=>'Stripe Dashboard → Developers → API keys'],
            ['key'=>'webhook_secret','label'=>__('aint.whsec_key'),'placeholder'=>'Stripe Dashboard → Webhooks → Signing secret'],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'Stripe'],
            ['key'=>'currency','label'=>__('aint.currency'),'type'=>'select','options'=>['TRY','USD','EUR','GBP','JPY']],
            ['key'=>'test_mode','label'=>__('aint.test_mode'),'type'=>'select','options'=>[['value'=>'0','label'=>__('aint.off_live')],['value'=>'1','label'=>__('aint.on_testcard')]]],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'paypal' => [
        'label' => 'PayPal',
        'desc' => __('aint.desc_paypal'),
        'icon' => 'fa-paypal',
        'iconPrefix' => 'fa-brands',
        'color' => '#003087',
        'img' => '/images/payments/paypal.png',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'client_id','label'=>'Client ID','placeholder'=>__('aint.ph_paypal_app')],
            ['key'=>'secret','label'=>'Secret','placeholder'=>__('aint.ph_app_secret')],
            ['key'=>'webhook_id','label'=>'Webhook ID','placeholder'=>__('aint.ph_webhook_id')],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'PayPal'],
            ['key'=>'currency','label'=>__('aint.currency'),'type'=>'select','options'=>['USD','EUR','GBP','TRY']],
            ['key'=>'test_mode','label'=>__('aint.test_mode'),'type'=>'select','options'=>[['value'=>'0','label'=>__('aint.off_live')],['value'=>'1','label'=>__('aint.on_sandbox')]]],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'bitpay' => [
        'label' => 'BitPay',
        'desc' => __('aint.desc_bitpay'),
        'icon' => 'fa-brands fa-btc',
        'color' => '#0F6373',
        'img' => '/images/payments/bitpay.jpeg',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'token','label'=>'API Token','placeholder'=>'BitPay Dashboard → API Access → Payment Tokens (POS)'],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'BitPay'],
            ['key'=>'currency','label'=>__('aint.currency'),'type'=>'select','options'=>['TRY','USD','EUR','GBP']],
            ['key'=>'test_mode','label'=>__('aint.test_mode'),'type'=>'select','options'=>[['value'=>'0','label'=>__('aint.off_live')],['value'=>'1','label'=>__('aint.on_bitpay')]]],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'crypt' => [
        'label' => 'Cryptomus (Kripto)',
        'desc' => __('aint.desc_crypt'),
        'icon' => 'fa-brands fa-bitcoin',
        'color' => '#8B5CF6',
        'img' => '/images/payments/cryptomus.png',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'merchant_id','label'=>'Merchant ID','placeholder'=>'Cryptomus Dashboard → Merchant Settings → Merchant ID'],
            ['key'=>'api_key','label'=>__('aint.api_key'),'placeholder'=>__('aint.ph_crypt_api')],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'Kripto'],
            ['key'=>'currency','label'=>__('aint.currency'),'type'=>'select','options'=>['TRY','USD','EUR','GBP']],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'paywant' => [
        'label' => 'Paywant',
        'desc' => __('aint.desc_paywant'),
        'icon' => 'fa-wallet',
        'iconPrefix' => 'fa-solid',
        'color' => '#0d9d8f',
        'img' => '/images/payments/paywant.png',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'api_key','label'=>'API Key','placeholder'=>__('aint.ph_paywant_api')],
            ['key'=>'api_secret','label'=>'API Secret Key','placeholder'=>__('aint.ph_paywant_api')],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'Paywant'],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'whop' => [
        'label' => 'Whop',
        'desc' => __('aint.desc_whop'),
        'icon' => 'fa-w',
        'iconPrefix' => 'fa-solid',
        'color' => '#ff4d00',
        'img' => '/images/payments/whop.png',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'api_key','label'=>__('aint.api_key'),'placeholder'=>'Whop Dashboard → Settings → API keys'],
            ['key'=>'account_id','label'=>__('aint.account_id'),'placeholder'=>__('aint.ph_biz')],
            ['key'=>'product_id','label'=>__('aint.product_id'),'placeholder'=>__('aint.ph_prod')],
            ['key'=>'webhook_secret','label'=>__('aint.wh_secret'),'placeholder'=>__('aint.ph_ws')],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'Whop'],
            ['key'=>'currency','label'=>__('aint.currency'),'type'=>'select','options'=>['TRY','USD','EUR']],
            ['key'=>'test_mode','label'=>__('aint.test_mode'),'type'=>'select','options'=>[['value'=>'0','label'=>__('aint.off_live')],['value'=>'1','label'=>__('aint.on_sandboxapi')]]],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'dodopayments' => [
        'label' => 'DodoPayments',
        'desc' => __('aint.desc_dodopayments'),
        'icon' => 'fa-d',
        'iconPrefix' => 'fa-solid',
        'color' => '#6D5CFF',
        'img' => '/images/payments/Dodopayments.jpeg',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'api_key','label'=>__('aint.api_key'),'placeholder'=>'DodoPayments → Developer → API Keys → + New'],
            ['key'=>'webhook_secret','label'=>__('aint.wh_secret'),'placeholder'=>'Developer → Webhooks → Signing secret'],
            ['key'=>'product_id','label'=>__('aint.product_id'),'placeholder'=>'Products → View Details → pdt_...'],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'DodoPayments'],
            ['key'=>'currency','label'=>__('aint.currency'),'type'=>'select','options'=>['TRY','USD','EUR']],
            ['key'=>'test_mode','label'=>__('aint.test_mode'),'type'=>'select','options'=>[['value'=>'0','label'=>__('aint.off_live')],['value'=>'1','label'=>__('aint.on_sandboxapi')]]],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'lemonsqueezy' => [
        'label' => 'Lemon Squeezy',
        'desc' => __('aint.desc_lemonsqueezy'),
        'icon' => 'fa-lemon',
        'iconPrefix' => 'fa-solid',
        'color' => '#FFC233',
        'img' => '/images/payments/LemonSquezy.png',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'api_key','label'=>__('aint.api_key'),'placeholder'=>'Lemon Squeezy → Settings → API → + New API key'],
            ['key'=>'signing_secret','label'=>__('aint.wh_secret'),'placeholder'=>'Settings → Webhooks → Signing secret'],
            ['key'=>'store_id','label'=>__('aint.store_id'),'placeholder'=>__('aint.ph_store_id')],
            ['key'=>'variant_id','label'=>__('aint.variant_id'),'placeholder'=>__('aint.ph_variant_id')],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'Lemon Squeezy'],
            ['key'=>'currency','label'=>__('aint.currency'),'type'=>'select','options'=>['TRY','USD','EUR']],
            ['key'=>'test_mode','label'=>__('aint.test_mode'),'type'=>'select','options'=>[['value'=>'0','label'=>__('aint.off_live')],['value'=>'1','label'=>__('aint.on_sandboxapi')]]],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'paddle' => [
        'label' => 'Paddle',
        'desc' => __('aint.desc_paddle'),
        'icon' => 'fa-p',
        'iconPrefix' => 'fa-solid',
        'color' => '#FDDD35',
        'img' => '/images/payments/Paddle.jpeg',
        'type' => 'payment',
        'prefix' => 'payment_',
        'enabledKey' => 'active',
        'bigModal' => true,
        'showUrls' => true,
        'fields' => [
            ['key'=>'api_key','label'=>__('aint.api_key'),'placeholder'=>'Paddle Dashboard → Developer tools → Authentication'],
            ['key'=>'webhook_secret','label'=>__('aint.wh_secret'),'placeholder'=>'Notifications → Edit destination → Secret key'],
            ['key'=>'title','label'=>__('aint.title'),'placeholder'=>'Paddle'],
            ['key'=>'currency','label'=>__('aint.currency'),'type'=>'select','options'=>['TRY','USD','EUR']],
            ['key'=>'test_mode','label'=>__('aint.test_mode'),'type'=>'select','options'=>[['value'=>'0','label'=>__('aint.off_live')],['value'=>'1','label'=>__('aint.on_sandboxapi')]]],
            ['key'=>'priority','label'=>__('aint.priority'),'type'=>'number','placeholder'=>'0'],
            ['key'=>'fee','label'=>__('aint.fee'),'type'=>'number','placeholder'=>'0.00'],
        ],
    ],
    'tawkto' => [
        'label' => __('aint.label_tawkto'),
        'desc' => __('aint.desc_tawkto'),
        'icon' => 'fa-comments',
        'iconPrefix' => 'fa-solid',
        'color' => '#42b35a',
        'type' => 'chat',
        'fields' => [
            ['key'=>'widget_code','label'=>__('aint.widget_code'),'type'=>'textarea','placeholder'=>__('aint.ph_tawk')],
        ],
    ],
    'jivochat' => [
        'label' => __('aint.label_jivo'),
        'desc' => __('aint.desc_jivo'),
        'img' => '/images/chat/jivo.png',
        'color' => '#2563eb',
        'type' => 'chat',
        'fields' => [
            ['key'=>'widget_code','label'=>__('aint.widget_code'),'type'=>'textarea','placeholder'=>__('aint.ph_jivo')],
        ],
    ],
    'crisp' => [
        'label' => __('aint.label_crisp'),
        'desc' => __('aint.desc_crisp'),
        'img' => '/images/chat/crisp.png',
        'color' => '#3b82f6',
        'type' => 'chat',
        'fields' => [
            ['key'=>'widget_code','label'=>__('aint.widget_code'),'type'=>'textarea','placeholder'=>__('aint.ph_crisp')],
        ],
    ],
    'analytics' => [
        'label' => __('aint.label_analytics'),
        'desc' => __('aint.desc_analytics'),
        'icon' => 'fa-chart-line',
        'iconPrefix' => 'fa-solid',
        'color' => '#f59e0b',
        'img' => '/images/analytics.png',
        'type' => 'analytics',
        'fields' => [
            ['key'=>'analytics_code','label'=>__('aint.analytics_code'),'type'=>'textarea','placeholder'=>__('aint.ph_gtag')],
        ],
    ],
];

include __DIR__ . '/includes/layout.php';
?>
<style>
@keyframes fadeSlideUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
@keyframes intPop{from{opacity:0;transform:translateY(24px) scale(.92)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes intPopOut{from{opacity:1;transform:translateY(0) scale(1)}to{opacity:0;transform:translateY(24px) scale(.92)}}
@keyframes intFade{from{opacity:0}to{opacity:1}}
@keyframes intFadeOut{from{opacity:1}to{opacity:0}}
@keyframes toastIn{from{opacity:0;transform:translateY(-20px) scale(.95)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes toastOut{from{opacity:1;transform:translateY(0) scale(1)}to{opacity:0;transform:translateY(-20px) scale(.95)}}
.int-card{transition:all .35s cubic-bezier(.34,1.56,.64,1);border-color:var(--border);}
.int-card.int-active{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.12);}
.int-card:not(.int-active){filter:grayscale(.7);opacity:.6;}
.int-card:not(.int-active):hover{filter:grayscale(.4);opacity:.85;}
.int-card.int-unconfigured:not(.int-active){filter:grayscale(.9);opacity:.45;}
.int-card.int-unconfigured:not(.int-active):hover{filter:grayscale(.6);opacity:.7;}
.int-card:hover{border-color:#545454;}
.int-card.int-active:hover{border-color:var(--accent);}
.int-modal{position:fixed;inset:0;z-index:50;display:flex;align-items:center;justify-content:center;padding:16px;}
.int-modal-bg{position:absolute;inset:0;background:rgba(0,0,0,.6);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);}
.int-modal-box{position:relative;background:var(--bg-card);border:1px solid rgba(255,255,255,.1);border-radius:16px;width:100%;max-width:32rem;max-height:calc(100dvh - 32px);overflow-y:auto;box-shadow:0 25px 50px rgba(0,0,0,.5);}
.int-modal-box.int-modal-wide{max-width:48rem;}
@media(max-width:640px){.int-modal{padding:8px;align-items:flex-end;}.int-modal-box{border-radius:14px 14px 0 0;max-height:calc(100dvh - 16px);}}
.int-img{max-width:38px;max-height:26px;width:auto;height:auto;object-fit:contain;filter:grayscale(1) brightness(.65);transition:filter .35s ease,transform .35s ease;}
.int-card.int-active .int-img{filter:grayscale(0) brightness(1);transform:scale(1.05);}
.int-status-badge{background:rgba(100,116,139,.15);color:var(--muted);}
.int-card.int-active .int-status-badge{background:rgba(34,197,94,.15);color:#4ade80;}
.int-filter-btn{display:inline-flex;align-items:center;gap:6px;background:var(--bg-surface);border:1px solid var(--border);color:var(--muted);font-size:12px;font-weight:700;padding:7px 16px;border-radius:20px;cursor:pointer;transition:all .2s ease;font-family:inherit;}
.int-filter-btn:hover{border-color:#545454;color:var(--text);transform:translateY(-1px);}
.int-filter-btn:active{transform:scale(.94);}
.int-filter-btn.active{background:rgba(var(--accent-rgb),.15);border-color:var(--accent);color:var(--accent);animation:intPopBtn .35s cubic-bezier(.34,1.56,.64,1);}
#intSearch:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.12);}
#intSearchWrap:focus-within i{color:var(--accent);transform:scale(1.08);}
#intSearchClear:hover{background:#ef4444;border-color:#ef4444;color:#fff;}
.int-card{transition:all .35s cubic-bezier(.34,1.56,.64,1),opacity .2s ease,transform .2s ease,border-color .35s;}
.int-filter-hidden{display:none!important;}
.int-card.int-filter-enter{animation:intCardIn .4s cubic-bezier(.34,1.56,.64,1) backwards;}
.int-card.int-filter-leave{animation:intCardOut .25s ease forwards;}
.int-tb-in{animation:intSlideDown .5s cubic-bezier(.34,1.56,.64,1) backwards;}
#intSearchWrap{animation-delay:.03s;}
#intFilterLabel{animation-delay:.08s;}
#intFilterChips{animation-delay:.12s;}
.int-count-badge{display:inline-flex;align-items:center;justify-content:center;min-width:26px;height:26px;padding:0 10px;border-radius:20px;font-size:11px;font-weight:800;color:var(--accent);background:rgba(var(--accent-rgb),.12);border:1px solid var(--accent);flex-shrink:0;}
.int-empty-enter{animation:intSlideDown .35s ease;}
@keyframes intCardIn{from{opacity:0;transform:translateY(12px) scale(.95)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes intCardOut{from{opacity:1;transform:translateY(0) scale(1)}to{opacity:0;transform:translateY(-6px) scale(.94)}}
@keyframes intPopBtn{0%{transform:scale(1)}45%{transform:scale(1.14)}100%{transform:scale(1)}}
@keyframes intSlideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
.int-toast{position:fixed;top:24px;right:24px;z-index:99999;padding:14px 22px;border-radius:12px;font-size:13px;font-weight:700;box-shadow:0 12px 40px rgba(0,0,0,.4);animation:toastIn .35s cubic-bezier(.34,1.56,.64,1);display:flex;align-items:center;gap:10px;max-width:400px;backdrop-filter:blur(12px);}
.int-toast-success{background:rgba(34,197,94,.18);border:1px solid rgba(34,197,94,.35);color:#4ade80;}
.int-toast-error{background:rgba(239,68,68,.18);border:1px solid rgba(239,68,68,.35);color:#f87171;}
</style>

<div style="padding:20px;">

  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:8px;">
    <div>
      <h1 style="font-size:18px;font-weight:900;display:flex;align-items:center;gap:8px;color:var(--text);">
        <i class="fa-solid fa-plug" style="color:#22d3ee;"></i> <?= __('amenu.integrations') ?>
      </h1>
      <p style="font-size:12px;color:var(--dim);margin-top:2px;"><?= __('aint.subtitle') ?></p>
    </div>
  </div>

  <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap;">
    <div style="position:relative;flex:1;min-width:220px;" id="intSearchWrap" class="int-tb-in">
      <i class="fa-solid fa-magnifying-glass" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);font-size:13px;color:var(--muted);pointer-events:none;transition:color .2s,transform .2s;"></i>
      <input type="text" id="intSearch" placeholder="<?= __('aint.search_ph') ?>" autocomplete="off"
             style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 38px 10px 38px;color:var(--text);font-size:13px;outline:none;transition:border-color .2s,box-shadow .2s;">
      <button type="button" id="intSearchClear" title="<?= __('aint.clear') ?>"
              style="display:none;position:absolute;right:10px;top:50%;transform:translateY(-50%);width:22px;height:22px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid var(--border);color:var(--muted);cursor:pointer;align-items:center;justify-content:center;font-size:11px;transition:all .2s;">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>
    <span style="font-size:11px;color:var(--dim);font-weight:700;flex-shrink:0;" class="int-tb-in" id="intFilterLabel"><?= __('aint.filter_label') ?></span>
    <div style="display:flex;gap:8px;flex-wrap:wrap;" id="intFilterChips" class="int-tb-in">
      <button class="int-filter-btn active" data-filter="all"><?= __('shop.all') ?></button>
      <button class="int-filter-btn" data-filter="payment"><i class="fa-solid fa-credit-card"></i> <?= __('panel.tx_payment') ?></button>
      <button class="int-filter-btn" data-filter="chat"><i class="fa-solid fa-headset"></i> <?= __('nav.support') ?></button>
      <button class="int-filter-btn" data-filter="captcha"><i class="fa-solid fa-shield-halved"></i> <?= __('aint.f_security') ?></button>
      <button class="int-filter-btn" data-filter="auth"><i class="fa-solid fa-user-lock"></i> <?= __('aint.f_signin') ?></button>
      <button class="int-filter-btn" data-filter="analytics"><i class="fa-solid fa-chart-line"></i> <?= __('aint.f_analytics') ?></button>
    </div>
    <span class="int-count-badge" id="intResultCount">0</span>
  </div>

  <div id="intEmpty" style="display:none;text-align:center;padding:48px 20px;color:var(--muted);background:var(--bg-card);border:1px solid var(--border);border-radius:16px;">
    <i class="fa-solid fa-plug-circle-xmark" style="font-size:38px;color:var(--dim);margin-bottom:12px;display:block;"></i>
    <p style="font-size:14px;font-weight:700;color:var(--text);"><?= __('aint.empty_title') ?></p>
    <p style="font-size:12px;margin-top:4px;"><?= __('aint.empty_hint') ?></p>
  </div>

  <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:20px;" id="intGrid">

<?php foreach ($integrations as $slug => $int): ?>
<?php
$prefix = $int['prefix'] ?? 'int_';
$enabledKey = $int['enabledKey'] ?? 'enabled';
$enabled = $settings[$prefix.$slug.'_'.$enabledKey] ?? '0';
$configured = true;
foreach ($int['fields'] as $f) {
    $v = $settings[$prefix.$slug.'_'.$f['key']] ?? '';
    if (empty($v)) { $configured = false; break; }
}
?>

<div class="admin-card int-card <?= $enabled==='1'?'int-active':'' ?> <?= !$configured?'int-unconfigured':'' ?>"
     data-slug="<?= $slug ?>" data-category="<?= $int['type'] ?>"
     data-label="<?= htmlspecialchars($int['label'], ENT_QUOTES) ?>"
     data-desc="<?= htmlspecialchars($int['desc'], ENT_QUOTES) ?>"
     onclick="toggleInt('<?= $slug ?>')">
    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:14px;">
        <div style="display:flex;align-items:center;gap:12px;">
            <div class="int-icon-wrap" style="width:44px;height:44px;border-radius:12px;background:<?= $int['color'] ?>15;display:flex;align-items:center;justify-content:center;font-size:20px;color:<?= $int['color'] ?>;">
                <?php if (!empty($int['img'])): ?>
                <img src="<?= $int['img'] ?>" alt="<?= $int['label'] ?>" class="int-img">
                <?php else: ?>
                <i class="<?= $int['iconPrefix'] ?? 'fa-brands' ?> <?= $int['icon'] ?>"></i>
                <?php endif; ?>
            </div>
            <div>
                <span class="int-label" style="font-size:15px;font-weight:800;"><?= $int['label'] ?></span>
                <span style="display:block;font-size:11px;color:var(--muted);margin-top:2px;"><?= $int['desc'] ?></span>
            </div>
        </div>
        <div class="int-status-badge" style="flex-shrink:0;font-size:10px;font-weight:700;padding:3px 10px;border-radius:20px;transition:all .3s ease;">
            <?= $enabled==='1' ? __('adash.status_active') : __('aint.passive') ?>
        </div>
    </div>

    <div style="display:flex;gap:8px;margin-top:auto;">
        <button class="btn-admin btn-ghost-admin" style="flex:1;justify-content:center;font-size:12px;padding:8px;" onclick="event.stopPropagation();openIntModal('<?= $slug ?>')">
            <i class="fa-solid fa-sliders"></i> <?= __('aint.configure') ?>
        </button>
        <?php if ($int['type'] === 'captcha' || $int['type'] === 'chat' || $slug === 'paytr' || $slug === 'shopier' || $slug === 'iyzico' || $slug === 'stripe' || $slug === 'paypal' || $slug === 'bitpay' || $slug === 'crypt' || $slug === 'paywant' || $slug === 'whop' || $slug === 'paddle' || $slug === 'lemonsqueezy' || $slug === 'dodopayments'): ?>
        <button class="btn-admin btn-ghost-admin int-test-btn" data-test-slug="<?= $slug ?>" style="font-size:12px;padding:8px 12px;" onclick="event.stopPropagation();testInt('<?= $slug ?>')" title="<?= __('aint.test') ?>">
            <i class="fa-solid fa-vial"></i>
        </button>
        <?php endif; ?>
    </div>

    <?php if (!$configured): ?>
    <div style="position:absolute;top:14px;right:70px;background:rgba(251,191,36,.12);color:#fbbf24;font-size:10px;font-weight:700;padding:3px 8px;border-radius:6px;">
        <i class="fa-solid fa-triangle-exclamation"></i> <?= __('aint.unconfigured') ?>
    </div>
    <?php endif; ?>
</div>
<?php endforeach; ?>

</div>

<?php foreach ($integrations as $slug => $int): ?>
<?php $prefix = $int['prefix'] ?? 'int_'; $bigModal = !empty($int['bigModal']); ?>
<div id="intModal_<?= $slug ?>" class="int-modal" style="display:none;">
    <div class="int-modal-bg" onclick="closeIntModal('<?= $slug ?>')"></div>
    <div class="int-modal-box<?= $bigModal ? ' int-modal-wide' : '' ?>">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 24px;border-bottom:1px solid var(--border);">
            <h2 style="font-size:16px;font-weight:800;display:flex;align-items:center;gap:10px;">
                <span style="width:34px;height:34px;border-radius:10px;background:<?= $int['color'] ?>15;display:flex;align-items:center;justify-content:center;font-size:16px;color:<?= $int['color'] ?>;">
                    <?php if (!empty($int['img'])): ?>
                    <img src="<?= $int['img'] ?>" alt="<?= $int['label'] ?>" style="height:22px;width:auto;">
                    <?php else: ?>
                    <i class="<?= $int['iconPrefix'] ?? 'fa-brands' ?> <?= $int['icon'] ?>"></i>
                    <?php endif; ?>
                </span>
                <?= $int['label'] ?> <?= __('aint.configuration') ?>
            </h2>
            <button onclick="closeIntModal('<?= $slug ?>')" style="background:none;border:none;color:var(--muted);font-size:22px;cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form id="intForm_<?= $slug ?>" style="padding:24px;" onsubmit="return saveInt(event,'<?= $slug ?>')">
            <div style="display:grid;gap:18px;<?= $bigModal ? 'grid-template-columns:1fr 1fr;' : '' ?>">
                <?php foreach ($int['fields'] as $f): ?>
                <?php $fVal = $settings[$prefix.$slug.'_'.$f['key']] ?? ''; ?>
                <div>
                    <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= $f['label'] ?></label>
                    <?php if (($f['type'] ?? '') === 'textarea'): ?>
                    <textarea name="<?= $slug ?>_<?= $f['key'] ?>" class="int-field" rows="7"
                              placeholder="<?= $f['placeholder'] ?? '' ?>"
                              style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:12px;font-family:ui-monospace,Consolas,monospace;outline:none;resize:vertical;white-space:pre-wrap;word-break:break-all;"><?= e($fVal) ?></textarea>
                    <?php elseif (($f['type'] ?? '') === 'select'): ?>
                    <select name="<?= $slug ?>_<?= $f['key'] ?>" class="int-field"
                            style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                        <?php foreach ($f['options'] as $opt): ?>
                        <?php $optV = is_array($opt) ? ($opt['value'] ?? '') : $opt; ?>
                        <?php $optL = is_array($opt) ? ($opt['label'] ?? $optV) : $opt; ?>
                        <option value="<?= e($optV) ?>" <?= $fVal === $optV ? 'selected' : '' ?>><?= e($optL) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php else: ?>
                    <input type="<?= ($f['type'] ?? 'text') === 'number' ? 'number' : (($f['type'] ?? '') === 'password' ? 'password' : 'text') ?>" name="<?= $slug ?>_<?= $f['key'] ?>" class="int-field"
                           value="<?= e($fVal) ?>"
                           placeholder="<?= $f['placeholder'] ?? '' ?>"
                           step="<?= $f['step'] ?? '' ?>"
                           style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php if (!empty($int['showUrls'])): ?>
            <?php $intSiteBase = rtrim((function_exists('site_base_url') ? site_base_url($adminDb ?? null) : ''), '/'); if ($intSiteBase === '') $intSiteBase = 'https://localhost'; ?>
            <div style="margin-top:14px;padding:12px;background:rgba(247,147,26,.08);border-radius:10px;font-size:12px;color:var(--muted);">
                <div style="font-weight:800;color:var(--text);margin-bottom:8px;"><i class="fa-solid fa-link" style="color:#f7931a;margin-right:6px;"></i> <?= __('aint.url_title') ?></div>
                <div style="display:flex;flex-direction:column;gap:6px;">
                    <div><span style="color:#f7931a;font-weight:700;display:inline-block;min-width:115px;"><?= __('aint.ipn') ?>:</span> <code style="background:rgba(0,0,0,.3);padding:2px 6px;border-radius:4px;font-size:11px;"><?= e($intSiteBase) ?>/callback/<?= $slug ?></code></div>
                    <div><span style="color:#f7931a;font-weight:700;display:inline-block;min-width:115px;"><?= __('aint.success_url') ?></span> <code style="background:rgba(0,0,0,.3);padding:2px 6px;border-radius:4px;font-size:11px;"><?= e($intSiteBase) ?>/payment/success</code></div>
                    <div><span style="color:#f7931a;font-weight:700;display:inline-block;min-width:115px;"><?= __('aint.fail_url') ?></span> <code style="background:rgba(0,0,0,.3);padding:2px 6px;border-radius:4px;font-size:11px;"><?= e($intSiteBase) ?>/payment/cancel</code></div>
                    <?php if ($slug === 'paytr'): ?>
                    <div style="margin-top:6px;font-size:11px;color:var(--muted);"><i class="fa-solid fa-circle-info" style="color:#2E7D32;margin-right:4px;"></i> <?= __('aint.note_paytr') ?></div>
                    <?php endif; ?>
                    <?php if ($slug === 'iyzico'): ?>
                    <div style="margin-top:6px;font-size:11px;color:var(--muted);"><i class="fa-solid fa-circle-info" style="color:#FF6B00;margin-right:4px;"></i> <?= __('aint.note_iyzico') ?></div>
                    <?php endif; ?>
                    <?php if ($slug === 'stripe'): ?>
                    <div style="margin-top:6px;font-size:11px;color:var(--muted);"><i class="fa-solid fa-circle-info" style="color:#635BFF;margin-right:4px;"></i> <?= __('aint.note_stripe') ?></div>
                    <?php endif; ?>
                    <?php if ($slug === 'paypal'): ?>
                    <div style="margin-top:6px;font-size:11px;color:var(--muted);"><i class="fa-solid fa-circle-info" style="color:#003087;margin-right:4px;"></i> <?= __('aint.note_paypal') ?></div>
                    <?php endif; ?>
                    <?php if ($slug === 'crypt'): ?>
                    <div style="margin-top:6px;font-size:11px;color:var(--muted);"><i class="fa-solid fa-circle-info" style="color:#8B5CF6;margin-right:4px;"></i> <?= __('aint.note_crypt') ?></div>
                    <?php endif; ?>
                    <?php if ($slug === 'whop'): ?>
                    <div style="margin-top:6px;font-size:11px;color:var(--muted);"><i class="fa-solid fa-circle-info" style="color:#ff4d00;margin-right:4px;"></i> <?= __('aint.note_whop') ?></div>
                    <?php endif; ?>
                    <?php if ($slug === 'paddle'): ?>
                    <div style="margin-top:6px;font-size:11px;color:var(--muted);"><i class="fa-solid fa-circle-info" style="color:#FDDD35;margin-right:4px;"></i> <?= __('aint.note_paddle') ?></div>
                    <?php elseif ($slug === 'lemonsqueezy'): ?>
                    <div style="margin-top:6px;font-size:11px;color:var(--muted);"><i class="fa-solid fa-circle-info" style="color:#FFC233;margin-right:4px;"></i> <?= __('aint.note_lemonsqueezy') ?></div>
                    <?php elseif ($slug === 'dodopayments'): ?>
                    <div style="margin-top:6px;font-size:11px;color:var(--muted);"><i class="fa-solid fa-circle-info" style="color:#6D5CFF;margin-right:4px;"></i> <?= __('aint.note_dodopayments') ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
            <?php if ($int['type'] === 'auth'): ?>
            <div style="margin-top:14px;padding:12px;background:rgba(var(--accent-rgb),.08);border-radius:10px;font-size:12px;color:var(--muted);">
                <i class="fa-solid fa-circle-info" style="color:#818cf8;margin-right:6px;"></i>
                <?= __('aint.redirect_uri') ?> <code style="background:rgba(0,0,0,.3);padding:2px 6px;border-radius:4px;font-size:11px;"><?= e($intSiteBase) ?>/api/auth/<?= $slug ?></code>
            </div>
            <?php endif; ?>
            <div style="display:flex;gap:10px;margin-top:20px;padding-top:18px;border-top:1px solid var(--border);">
                <button type="submit" class="btn-admin btn-primary-admin" style="flex:1;justify-content:center;padding:11px;">
                    <i class="fa-solid fa-floppy-disk"></i> <?= __('aint.save') ?>
                </button>
                <button type="button" class="btn-admin btn-ghost-admin" style="padding:11px 18px;" onclick="closeIntModal('<?= $slug ?>')"><?= __('support.cancel') ?></button>
            </div>
        </form>
    </div>
</div>
<?php endforeach; ?>

</div>

<script>
function showToast(msg, type) {
    var existing = document.querySelector('.int-toast');
    if (existing) existing.remove();
    var t = document.createElement('div');
    t.className = 'int-toast int-toast-' + type;
    t.innerHTML = '<i class="fa-solid fa-' + (type==='success'?'circle-check':'circle-xmark') + '"></i> ';
    t.appendChild(document.createTextNode(msg));
    document.body.appendChild(t);
    setTimeout(function(){ t.style.animation = 'toastOut .3s ease forwards'; setTimeout(function(){ t.remove(); }, 300); }, 2500);
}
function openIntModal(slug) {
    var m = document.getElementById('intModal_' + slug);
    if (!m) return;
    m.style.display = 'flex';
    m.querySelectorAll('.int-modal-bg').forEach(function(b){ b.style.animation = 'intFade .3s ease'; });
    var box = m.querySelector('.int-modal-box');
    if (box) { box.style.animation = 'none'; box.offsetHeight; box.style.animation = 'intPop .35s cubic-bezier(.34,1.56,.64,1)'; }
}
function closeIntModal(slug) {
    var m = document.getElementById('intModal_' + slug);
    if (!m || m.style.display === 'none') return;
    m.querySelectorAll('.int-modal-bg').forEach(function(b){ b.style.animation = 'intFadeOut .25s ease forwards'; });
    var box = m.querySelector('.int-modal-box');
    if (box) { box.style.animation = 'none'; box.offsetHeight; box.style.animation = 'intPopOut .3s ease forwards'; }
    setTimeout(function(){ m.style.display = 'none'; }, 300);
}
function intParse(r) {
    return r.text().then(function(txt){
        var ct = (r.headers && r.headers.get('content-type')) || '';
        try { return { ok: true, data: JSON.parse(txt) }; }
        catch(e) {
            var hint = r.status === 0 || r.type === 'opaque' ? ' ' + <?= json_encode(__('aint.conn_lost')) ?> : ' (HTTP ' + r.status + ')';
            return { ok: false, data: null, msg: <?= json_encode(__('aint.json_invalid')) ?> + hint + ': ' + txt.substring(0, 200) };
        }
    });
}
var _intBusy = {};
function saveInt(e, slug) {
    e.preventDefault();
    if (_intBusy['save_' + slug]) return false;
    _intBusy['save_' + slug] = true;
    var form = document.getElementById('intForm_' + slug);
    var fd = new FormData();
    fd.set('action', 'int_save');
    fd.set('slug', slug);
    form.querySelectorAll('.int-field').forEach(function(inp) {
        fd.set(inp.name, inp.value);
    });
    fetch('/action.php', { method:'POST', body:fd })
        .then(intParse)
        .then(function(res){
            if (!res.ok) { showToast(res.msg, 'error'); return; }
            var d = res.data;
            if (d.ok) {
                closeIntModal(slug);
                showToast(<?= json_encode(__('aint.saved_ok')) ?>, 'success');
            } else {
                showToast(d.msg, 'error');
            }
        })
        .catch(function(err){ showToast(<?= json_encode(__('aint.conn_err')) ?> + ': ' + err.message, 'error'); })
        .finally(function(){ _intBusy['save_' + slug] = false; });
    return false;
}
function toggleInt(slug) {
    var card = document.querySelector('.int-card[data-slug="'+slug+'"]');
    if (!card) return;
    if (_intBusy['toggle_' + slug]) return;
    _intBusy['toggle_' + slug] = true;
    var isActive = card.classList.contains('int-active');
    var fd = new FormData();
    fd.set('action', 'int_toggle');
    fd.set('slug', slug);
    fd.set('state', isActive ? '0' : '1');
    fetch('/action.php', { method:'POST', body:fd })
        .then(intParse)
        .then(function(res){
            _intBusy['toggle_' + slug] = false;
            if (!res.ok) { showToast(res.msg, 'error'); return; }
            var d = res.data;
            if (d.ok) {
                card.classList.toggle('int-active');
                var badge = card.querySelector('.int-status-badge');
                if (badge) badge.textContent = isActive ? <?= json_encode(__('aint.passive')) ?> : <?= json_encode(__('adash.status_active')) ?>;
                if (!isActive && (slug === 'cf_captcha' || slug === 'recaptcha')) {
                    var otherSlug = (slug === 'cf_captcha') ? 'recaptcha' : 'cf_captcha';
                    var otherCard = document.querySelector('.int-card[data-slug="'+otherSlug+'"]');
                    if (otherCard && otherCard.classList.contains('int-active')) {
                        otherCard.classList.remove('int-active');
                        var ob = otherCard.querySelector('.int-status-badge');
                        if (ob) ob.textContent = <?= json_encode(__('aint.passive')) ?>;
                    }
                }
                if (!isActive && (slug === 'tawkto' || slug === 'jivochat' || slug === 'crisp')) {
                    ['tawkto','jivochat','crisp'].forEach(function(os){
                        if (os === slug) return;
                        var oc = document.querySelector('.int-card[data-slug="'+os+'"]');
                        if (oc && oc.classList.contains('int-active')) {
                            oc.classList.remove('int-active');
                            var obc = oc.querySelector('.int-status-badge');
                            if (obc) obc.textContent = <?= json_encode(__('aint.passive')) ?>;
                        }
                    });
                }
                showToast(isActive ? <?= json_encode(__('aint.int_disabled')) ?> : <?= json_encode(__('aint.int_enabled')) ?>, 'success');
            } else {
                showToast(d.msg, 'error');
            }
        })
        .catch(function(err){ _intBusy['toggle_' + slug] = false; showToast(<?= json_encode(__('aint.conn_err')) ?> + ': ' + err.message, 'error'); });
}
var _intTesting = false;
function testInt(slug) {
    if (_intTesting) return;
    _intTesting = true;
    var btn = document.querySelector('.int-test-btn[data-test-slug="'+slug+'"]');
    if (btn) { btn.disabled = true; btn.style.opacity = '.6'; btn.style.pointerEvents = 'none'; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>'; }
    var fd = new FormData();
    fd.set('action', 'int_test');
    fd.set('slug', slug);
    fetch('/action.php', { method:'POST', body:fd })
        .then(intParse)
        .then(function(res){
            if (!res.ok) { showToast(res.msg, 'error'); }
            else { var d = res.data; showToast(d.msg, d.ok ? 'success' : 'error'); }
        })
        .catch(function(err){ showToast(<?= json_encode(__('aint.conn_err')) ?> + ': ' + err.message, 'error'); })
        .finally(function(){
            _intTesting = false;
            document.querySelectorAll('.int-test-btn').forEach(function(b){
                b.disabled = false;
                b.style.opacity = '';
                b.style.pointerEvents = '';
                b.innerHTML = '<i class="fa-solid fa-vial"></i>';
            });
        });
}
var _intQuery = '';
var _intCat = 'all';
var _intLeaving = {};
function applyIntFilter() {
    var q = _intQuery.toLowerCase().trim();
    var visible = 0;
    var cards = document.querySelectorAll('#intGrid .int-card');
    cards.forEach(function(card) {
        var cat = card.getAttribute('data-category') || 'other';
        var label = (card.getAttribute('data-label') || '').toLowerCase();
        var desc = (card.getAttribute('data-desc') || '').toLowerCase();
        var slug = (card.getAttribute('data-slug') || '').toLowerCase();
        var okCat = (_intCat === 'all' || cat === _intCat);
        var okQ = !q || label.indexOf(q) !== -1 || desc.indexOf(q) !== -1 || slug.indexOf(q) !== -1;
        var show = okCat && okQ;
        var key = card.getAttribute('data-slug');
        if (show) {
            if (_intLeaving[key]) { delete _intLeaving[key]; }
            card.classList.remove('int-filter-leave');
            if (card.classList.contains('int-filter-hidden')) {
                card.classList.remove('int-filter-hidden');
                card.style.animation = '';
                void card.offsetWidth;
                card.classList.add('int-filter-enter');
                card.addEventListener('animationend', function onIn(e) {
                    if (e.animationName !== 'intCardIn') return;
                    card.classList.remove('int-filter-enter');
                    card.style.animation = '';
                    card.removeEventListener('animationend', onIn);
                });
            }
            visible++;
        } else {
            if (_intLeaving[key] || card.classList.contains('int-filter-hidden')) return;
            _intLeaving[key] = true;
            card.classList.remove('int-filter-enter');
            card.style.animation = '';
            void card.offsetWidth;
            card.classList.add('int-filter-leave');
            card.addEventListener('animationend', function onOut(e) {
                if (e.animationName !== 'intCardOut') return;
                card.classList.remove('int-filter-leave');
                card.style.animation = '';
                card.classList.add('int-filter-hidden');
                card.removeEventListener('animationend', onOut);
                delete _intLeaving[key];
            });
        }
    });
    var empty = document.getElementById('intEmpty');
    if (visible === 0 && empty.style.display !== 'block') {
        empty.style.display = 'block';
        empty.classList.add('int-empty-enter');
        setTimeout(function(){ empty.classList.remove('int-empty-enter'); }, 400);
    } else if (visible > 0 && empty.style.display === 'block') {
        empty.style.display = 'none';
    }
    var rc = document.getElementById('intResultCount');
    if (rc) {
        var n = String(visible);
        if (rc.textContent !== n) {
            rc.textContent = n;
            rc.style.animation = 'none';
            void rc.offsetWidth;
            rc.style.animation = 'intPopBtn .35s cubic-bezier(.34,1.56,.64,1)';
        }
    }
    var cb = document.getElementById('intSearchClear');
    if (cb) {
        var active = _intSearchEl && _intSearchEl.value.length > 0;
        cb.style.display = active ? 'flex' : 'none';
    }
}
var _intSearchEl = document.getElementById('intSearch');
if (_intSearchEl) {
    _intSearchEl.addEventListener('input', function() {
        _intQuery = this.value;
        applyIntFilter();
    });
}
var _intClearEl = document.getElementById('intSearchClear');
if (_intClearEl) {
    _intClearEl.addEventListener('click', function() {
        if (_intSearchEl) { _intSearchEl.value = ''; _intQuery = ''; _intSearchEl.focus(); applyIntFilter(); }
    });
}
document.querySelectorAll('.int-filter-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.int-filter-btn').forEach(function(b) { b.classList.remove('active'); });
        btn.classList.add('active');
        _intCat = btn.getAttribute('data-filter');
        applyIntFilter();
    });
});
var _intCardsInit = document.querySelectorAll('#intGrid .int-card');
_intCardsInit.forEach(function(card, i) {
    card.style.animation = 'intCardIn .45s cubic-bezier(.34,1.56,.64,1) ' + (i * 0.05) + 's backwards';
    card.addEventListener('animationend', function onInit(e) {
        if (e.animationName !== 'intCardIn') return;
        card.style.animation = '';
        card.removeEventListener('animationend', onInit);
    });
});
applyIntFilter();

var _openSlug = new URLSearchParams(window.location.search).get('open');
if (_openSlug) {
    setTimeout(function() {
        var card = document.querySelector('.int-card[data-slug="' + _openSlug + '"]');
        if (card) {
            card.scrollIntoView({ behavior: 'smooth', block: 'center' });
            card.style.boxShadow = '0 0 0 3px rgba(var(--accent-rgb),.55)';
            setTimeout(function(){ card.style.boxShadow = ''; }, 1600);
        }
        if (typeof openIntModal === 'function') openIntModal(_openSlug);
    }, 350);
}
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
