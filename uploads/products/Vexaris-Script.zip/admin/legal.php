<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('legal.index_title');
$activePage = 'legal';

$db = $adminDb;
$msg = '';
$editSlug = trim($_GET['edit'] ?? '');
$allowedSlugs = ['cookie-policy','privacy-policy','terms-of-service','refund-policy'];
$pageTitles = [
    'cookie-policy'    => [__('legal.cookies'),    'fa-solid fa-cookie-bite'],
    'privacy-policy'   => [__('legal.privacy'), 'fa-solid fa-shield-halved'],
    'terms-of-service' => [__('legal.terms'),   'fa-solid fa-file-contract'],
    'refund-policy'    => [__('legal.refund'),      'fa-solid fa-rotate-left'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_legal'])) {
    $slug = $_POST['slug'] ?? '';
    $content = nx_clean_html(trim($_POST['content'] ?? ''), 'rich');
    if (in_array($slug, $allowedSlugs, true)) {
        $ck = $db->prepare('SELECT id FROM legal_pages WHERE slug=?');
        $ck->execute([$slug]);
        if ($ck->fetch()) {
            $db->prepare('UPDATE legal_pages SET content=? WHERE slug=?')->execute([$content, $slug]);
        } else {
            $title = $pageTitles[$slug][0] ?? $slug;
            $db->prepare('INSERT INTO legal_pages (slug,title,content) VALUES (?,?,?)')->execute([$slug, $title, $content]);
        }
        $msg = ['type'=>'success','text'=>__('aleg.updated')];
    }
}

$slugPlaceholders = implode(',', array_fill(0, count($allowedSlugs), '?'));
$pagesStmt = $db->prepare('SELECT slug,title,content,updated_at FROM legal_pages WHERE slug IN (' . $slugPlaceholders . ')');
$pagesStmt->execute(array_values($allowedSlugs));
$pages = $pagesStmt->fetchAll();
$pageMap = [];
foreach ($pages as $p) $pageMap[$p['slug']] = $p;

include __DIR__ . '/includes/layout.php';
?>
<style>.ed-wrap{border-radius:0!important;border-left:none!important;border-right:none!important;}</style>

<?php if ($msg): ?>
<div style="background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#4ade80;padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid fa-circle-check"></i> <?= e($msg['text']) ?>
</div>
<?php endif; ?>

<?php if ($editSlug && in_array($editSlug, $allowedSlugs, true)): ?>
<?php
$cur = $pageMap[$editSlug] ?? null;
$icon = $pageTitles[$editSlug][1] ?? 'fa-solid fa-file';
$edRaw = $cur ? str_replace('{site_name}', e($pageTitles[$editSlug][0] ?? ''), (string)$cur['content']) : '';
$edContent = ($edRaw !== '' && strip_tags($edRaw) === $edRaw && function_exists('markdown_render')) ? markdown_render($edRaw) : $edRaw;
?>
<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="<?= $icon ?>" style="color:var(--accent);margin-right:8px;"></i><?= e($pageTitles[$editSlug][0] ?? $editSlug) ?></span>
        <a href="/admin/legal.php" class="btn-admin btn-ghost-admin">
            <i class="fa-solid fa-arrow-left"></i> <?= __('apage.back_list') ?>
        </a>
    </div>
    <form method="POST" onsubmit="if(document.getElementById('legalEditor')) document.getElementById('legalEditor').value=document.getElementById('edBody-legalEditor').innerHTML">
        <?= csrf_field() ?>
        <input type="hidden" name="save_legal" value="1">
        <input type="hidden" name="slug" value="<?= e($editSlug) ?>">

        <?php require_once ROOT_PATH . '/core/editor.php'; ?>
        <div style="border:1px solid var(--border);border-radius:10px;overflow:hidden;">
            <?php render_editor('legalEditor', $edContent, '400px', 'content'); ?>
        </div>

        <p style="font-size:11px;color:var(--muted);margin-top:8px;margin-bottom:16px;">
            <i class="fa-solid fa-info-circle"></i> <code>{site_name}</code> <?= __('aleg.site_name_note') ?>
            <span id="legalSaveStatus" style="float:right;font-weight:700;"></span>
        </p>

        <div style="display:flex;gap:8px;">
            <button type="submit" class="btn-admin btn-primary-admin" id="legalSaveBtn">
                <i class="fa-solid fa-floppy-disk"></i> <?= __('msg.save') ?>
            </button>
            <a href="/legal?p=<?= urlencode($editSlug) ?>" class="btn-admin btn-ghost-admin">
                <i class="fa-solid fa-eye"></i> <?= __('apage.preview') ?>
            </a>
        </div>
    </form>
</div>

<script>
var legalSaveTimer;
var legalSlug = '<?= e($editSlug) ?>';
var legalStatus = document.getElementById('legalSaveStatus');
var legalBody = document.getElementById('edBody-legalEditor');
var legalTextarea = document.getElementById('legalEditor');

function legalGetContent() {
    if (legalBody) {
        if (legalTextarea) legalTextarea.value = legalBody.innerHTML;
        return legalBody.innerHTML;
    }
    return legalTextarea ? legalTextarea.value : '';
}

function legalAutoSave() {
    legalGetContent();
    legalStatus.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Kaydediliyor...';
    var fd = new FormData();
    fd.append('save_legal','1');
    fd.append('slug', legalSlug);
    fd.append('content', legalTextarea ? legalTextarea.value : '');
    var lCsrf = document.querySelector('meta[name="csrf-token"]');
    fetch('/admin/legal.php?edit=' + encodeURIComponent(legalSlug), {
        method: 'POST', body: fd,
        headers: lCsrf ? {'X-CSRF-Token': lCsrf.getAttribute('content')} : {}
    }).then(function(){ 
        legalStatus.innerHTML = '<i class="fa-solid fa-check" style="color:#4ade80;"></i> Kaydedildi';
    }).catch(function(){
        legalStatus.innerHTML = '<i class="fa-solid fa-xmark" style="color:#f87171;"></i> Hata';
    });
}

if (legalBody) {
    legalBody.addEventListener('input', function(){
        clearTimeout(legalSaveTimer);
        legalStatus.innerHTML = '<i class="fa-solid fa-pen" style="color:#fbc853;"></i> ' + <?= json_encode(__('aleg.typing')) ?>;
        legalSaveTimer = setTimeout(legalAutoSave, 800);
    });
}

document.getElementById('legalSaveBtn').addEventListener('click', function(e){
    e.preventDefault();
    clearTimeout(legalSaveTimer);
    legalAutoSave();
});
</script>

<?php else: ?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-gavel" style="color:var(--accent);margin-right:8px;"></i><?= __('legal.index_title') ?></span>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;">
        <?php foreach ($allowedSlugs as $slug):
        $info = $pageTitles[$slug];
        $exists = isset($pageMap[$slug]);
        ?>
        <a href="/admin/legal.php?edit=<?= urlencode($slug) ?>" style="display:block;background:var(--bg-surface);border:1px solid var(--border);border-radius:14px;padding:22px 20px;text-decoration:none;transition:border-color .2s;color:inherit;" onmouseover="this.style.borderColor='rgba(var(--accent-rgb),.35)'" onmouseout="this.style.borderColor='var(--border)'">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(var(--accent-rgb),.12);display:flex;align-items:center;justify-content:center;font-size:18px;color:#818cf8;margin-bottom:14px;">
                <i class="<?= $info[1] ?>"></i>
            </div>
            <p style="font-size:14px;font-weight:800;margin-bottom:4px;"><?= e($info[0]) ?></p>
            <p style="font-size:11px;color:var(--muted);">
                <?= $exists ? '<i class="fa-regular fa-circle-check" style="color:#4ade80;"></i> ' . __('aleg.edited') : '<i class="fa-regular fa-pen-to-square"></i> ' . __('product.edit') ?>
            </p>
        </a>
        <?php endforeach; ?>
    </div>
</div>

<?php endif; ?>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
