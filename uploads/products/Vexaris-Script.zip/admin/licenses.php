<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.licenses');
$activePage = 'licenses';

$msg = '';

/* ── Lisans durum değiştir ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_license'])) {
    $lid     = (int)$_POST['toggle_license'];
    $newStatus = $_POST['new_status'] === 'active' ? 'active' : 'suspended';
    $adminDb->prepare('UPDATE licenses SET status = ? WHERE id = ?')->execute([$newStatus, $lid]);
    $msg = ['type'=>'success','text'=>__('alic.status_updated')];
}

/* ── Lisans sil ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_license'])) {
    $adminDb->prepare('DELETE FROM licenses WHERE id = ?')->execute([(int)$_POST['delete_license']]);
    $msg = ['type'=>'success','text'=>__('alic.deleted')];
}

/* ── Manuel lisans oluştur ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_license'])) {
    $productId = (int)$_POST['product_id'];
    $userId    = (int)$_POST['user_id'];
    if ($productId && $userId) {
        $pChk = $adminDb->prepare('SELECT id FROM products WHERE id=?');
        $pChk->execute([$productId]);
        $uChk = $adminDb->prepare('SELECT id FROM users WHERE id=?');
        $uChk->execute([$userId]);
        if (!$pChk->fetch() || !$uChk->fetch()) {
            $msg = ['type'=>'error','text'=>__('alic.user_or_product_missing')];
        } else {
        $key = strtoupper(implode('-', str_split(bin2hex(random_bytes(8)), 4)));
        $adminDb->prepare(
            'INSERT INTO licenses (product_id,user_id,license_key,status,created_at) VALUES (?,?,?,"active",NOW())'
        )->execute([$productId, $userId, $key]);
        $msg = ['type'=>'success','text'=>__('alic.created', ['key' => $key])];
        }
    }
}

/* ── Liste ── */
$licenses = $adminDb->query(
    'SELECT l.*,
            u.username, u.email,
            p.name AS product_name
     FROM licenses l
     LEFT JOIN users    u ON u.id = l.user_id
     LEFT JOIN products p ON p.id = l.product_id
     ORDER BY l.created_at DESC'
)->fetchAll();

$products = $adminDb->query('SELECT id,name FROM products ORDER BY name')->fetchAll();
$users    = $adminDb->query('SELECT id,username FROM users ORDER BY username')->fetchAll();

include __DIR__ . '/includes/layout.php';
?>

<?php if ($msg): ?>
<div style="background:<?= $msg['type']==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;
     border:1px solid <?= $msg['type']==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;
     color:<?= $msg['type']==='success'?'#4ade80':'#f87171' ?>;
     padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;
     margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid fa-circle-check"></i> <?= e($msg['text']) ?>
</div>
<?php endif; ?>

<!-- Manuel Lisans Oluştur -->
<div class="admin-card" style="margin-bottom:24px;">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-key" style="color:#fbc853;margin-right:8px;"></i><?= __('alic.manual_create') ?></span>
    </div>
    <form method="POST" style="display:flex;gap:14px;flex-wrap:wrap;align-items:flex-end;">
        <?= csrf_field() ?>
        <input type="hidden" name="create_license" value="1">
        <div>
            <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('apurch.product') ?></label>
            <select name="product_id" style="background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:9px 14px;color:var(--text);font-size:13px;outline:none;">
                <option value=""><?= __('apurch.select') ?></option>
                <?php foreach ($products as $p): ?>
                <option value="<?= $p['id'] ?>"><?= e($p['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('apurch.user') ?></label>
            <select name="user_id" style="background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:9px 14px;color:var(--text);font-size:13px;outline:none;">
                <option value=""><?= __('apurch.select') ?></option>
                <?php foreach ($users as $u): ?>
                <option value="<?= $u['id'] ?>"><?= e($u['username']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn-admin btn-primary-admin">
            <i class="fa-solid fa-plus"></i> <?= __('alic.create_btn') ?>
        </button>
    </form>
</div>

<!-- Lisans Listesi -->
<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title">
            <i class="fa-solid fa-list-check" style="color:var(--accent);margin-right:8px;"></i>
            <?= __('alic.all_licenses') ?> <span style="color:var(--muted);font-weight:500;">(<?= count($licenses) ?>)</span>
        </span>
    </div>
    <table class="admin-table">
        <thead><tr><th><?= __('apurch.col_key') ?></th><th><?= __('apurch.user') ?></th><th><?= __('apurch.product') ?></th><th><?= __('adash.th_status') ?></th><th><?= __('apurch.col_date') ?></th><th><?= __('adash.th_action') ?></th></tr></thead>
        <tbody>
        <?php foreach ($licenses as $l): ?>
        <tr class="animate-row">
            <td><code style="background:rgba(var(--accent-rgb),.1);color:#a5b4fc;padding:3px 8px;border-radius:6px;font-size:12px;"><?= e($l['license_key']) ?></code></td>
            <td style="font-weight:600;"><?= e($l['username'] ?? '—') ?></td>
            <td style="color:var(--muted);"><?= e($l['product_name'] ?? '—') ?></td>
            <td>
                <span class="badge <?= $l['status']==='active'?'badge-green':'badge-red' ?>">
                    <?= $l['status']==='active'?__('adash.status_active'):__('alic.suspended') ?>
                </span>
            </td>
            <td style="color:var(--muted);font-size:12px;"><?= date('d.m.Y', strtotime($l['created_at'])) ?></td>
            <td>
                <div style="display:flex;gap:6px;">
                    <form method="POST" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="toggle_license" value="<?= $l['id'] ?>">
                        <input type="hidden" name="new_status" value="<?= $l['status']==='active'?'suspended':'active' ?>">
                        <button type="submit" class="btn-admin btn-ghost-admin" style="padding:6px 10px;font-size:12px;">
                            <i class="fa-solid <?= $l['status']==='active'?'fa-ban':'fa-check' ?>"></i>
                        </button>
                    </form>
                    <form method="POST" onsubmit="return confirm(<?= json_encode(__('alic.delete_confirm')) ?>);" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="delete_license" value="<?= $l['id'] ?>">
                        <button type="submit" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;padding:6px 10px;font-size:12px;border:1px solid rgba(239,68,68,.2);">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($licenses)): ?>
        <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:32px;"><?= __('alic.empty') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
