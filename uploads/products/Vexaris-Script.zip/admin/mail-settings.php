<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.mail_settings');
$activePage = 'mail-settings';

$settingsRaw = $adminDb->query("SELECT `key`,`value` FROM settings")->fetchAll();
$mailSettings = [];
foreach ($settingsRaw as $r) $mailSettings[$r['key']] = $r['value'];

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_mail_settings'])) {
    csrf_verify();
    $allowed = ['mail_smtp_host','mail_smtp_port','mail_smtp_user','mail_smtp_encryption','mail_from_name','mail_from_email','mail_enabled'];
    $mailOk = true;
    foreach ($allowed as $k) {
        if (!isset($_POST[$k])) continue;
        $v = trim($_POST[$k]);
        if ($k === 'mail_from_email' && $v !== '' && !filter_var($v, FILTER_VALIDATE_EMAIL)) {
            $msg = ['type'=>'error','text'=>__('asmtp.err_invalid_from')];
            $mailOk = false;
            continue;
        }
        if ($k === 'mail_smtp_port' && $v !== '' && (!ctype_digit($v) || (int)$v < 1 || (int)$v > 65535)) {
            $msg = ['type'=>'error','text'=>__('asmtp.err_invalid_port')];
            $mailOk = false;
            continue;
        }
        $exists = $adminDb->prepare("SELECT `key` FROM settings WHERE `key`=? LIMIT 1");
        $exists->execute([$k]);
        if ($exists->fetch()) {
            $adminDb->prepare("UPDATE settings SET `value`=? WHERE `key`=?")->execute([$v,$k]);
        } else {
            $adminDb->prepare("INSERT INTO settings (`key`,`value`) VALUES (?,?)")->execute([$k,$v]);
        }
        $mailSettings[$k] = $v;
    }
    if (isset($_POST['mail_smtp_pass']) && trim($_POST['mail_smtp_pass']) !== '') {
        $enc = mail_encrypt_secret(trim($_POST['mail_smtp_pass']));
        $exists = $adminDb->prepare("SELECT `key` FROM settings WHERE `key`='mail_smtp_pass' LIMIT 1");
        $exists->execute();
        if ($exists->fetch()) {
            $adminDb->prepare("UPDATE settings SET `value`=? WHERE `key`='mail_smtp_pass'")->execute([$enc]);
        } else {
            $adminDb->prepare("INSERT INTO settings (`key`,`value`) VALUES ('mail_smtp_pass',?)")->execute([$enc]);
        }
    }
    $mailSettings['mail_smtp_pass'] = '';
    if ($mailOk) $msg = ['type'=>'success','text'=>__('asmtp.saved_ok')];
}

$siteName = $mailSettings['site_name'] ?? '';

include __DIR__ . '/includes/layout.php';
?>
<style>
.mf-field{width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:12px 14px;color:var(--text);font-size:13px;font-family:'Plus Jakarta Sans',sans-serif;outline:none;transition:border-color .2s,box-shadow .2s;}
.mf-field:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.18);}
.mf-label{display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;}
.mf-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;}
.mf-switch{position:relative;width:52px;height:28px;flex-shrink:0;cursor:pointer;}
.mf-switch input{opacity:0;width:0;height:0;}
.mf-switch .track{position:absolute;inset:0;background:rgba(var(--accent-rgb),.2);border-radius:28px;transition:background .2s;}
.mf-switch .track::before{content:"";position:absolute;height:22px;width:22px;left:3px;top:3px;background:#fff;border-radius:50%;transition:transform .2s;box-shadow:0 1px 3px rgba(0,0,0,.35);}
.mf-switch input:checked + .track{background:var(--accent);}
.mf-switch input:checked + .track::before{transform:translateX(24px);}
.mf-msg{display:flex;align-items:center;gap:8px;font-size:13px;font-weight:700;padding:12px 16px;border-radius:10px;margin-bottom:18px;}
.mf-msg.ok{background:rgba(34,197,94,.14);color:#4ade80;border:1px solid rgba(34,197,94,.3);}
.mf-msg.err{background:rgba(239,68,68,.14);color:#f87171;border:1px solid rgba(239,68,68,.3);}
.mf-hint{font-size:11px;color:var(--muted);margin-top:5px;}
</style>

<div style="padding:24px;">

<?php if ($msg): ?>
<div class="mf-msg <?= $msg['type']==='success'?'ok':'err' ?>">
    <i class="fa-solid <?= $msg['type']==='success'?'fa-circle-check':'fa-circle-exclamation' ?>"></i> <?= e($msg['text']) ?>
</div>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-envelope" style="color:var(--accent);margin-right:8px;"></i><?= __('amail.smtp_config') ?></span>
    </div>

    <form method="POST" style="display:flex;flex-direction:column;gap:18px;">
        <?= csrf_field() ?>
        <input type="hidden" name="save_mail_settings" value="1">

        <div class="mf-grid">
            <div>
                <label class="mf-label">SMTP Host</label>
                <input type="text" name="mail_smtp_host" maxlength="255" class="mf-field" placeholder="smtp.gmail.com"
                       value="<?= e($mailSettings['mail_smtp_host'] ?? '') ?>">
                <p class="mf-hint"><i class="fa-solid fa-circle-info"></i> <?= __('asmtp.hint_host') ?></p>
            </div>
            <div>
                <label class="mf-label">Port</label>
                <input type="number" name="mail_smtp_port" min="1" max="65535" class="mf-field"
                       value="<?= e($mailSettings['mail_smtp_port'] ?? '587') ?>">
                <p class="mf-hint"><i class="fa-solid fa-circle-info"></i> <?= __('asmtp.hint_port') ?></p>
            </div>
            <div>
                <label class="mf-label"><?= __('asmtp.lbl_user') ?></label>
                <input type="text" name="mail_smtp_user" maxlength="255" class="mf-field" placeholder="ornek@sitem.com"
                       value="<?= e($mailSettings['mail_smtp_user'] ?? '') ?>">
            </div>
            <div>
                <label class="mf-label"><?= __('asmtp.lbl_pass') ?></label>
                <input type="password" name="mail_smtp_pass" maxlength="255" class="mf-field" placeholder="••••••••" autocomplete="new-password">
                <p class="mf-hint"><i class="fa-solid fa-shield-halved"></i> <?= __('asmtp.hint_pass') ?></p>
            </div>
            <div>
                <label class="mf-label"><?= __('asmtp.lbl_enc') ?></label>
                <select name="mail_smtp_encryption" class="mf-field">
                    <option value="tls" <?= ($mailSettings['mail_smtp_encryption'] ?? 'tls')==='tls'?'selected':'' ?>><?= __('asmtp.opt_tls') ?></option>
                    <option value="ssl" <?= ($mailSettings['mail_smtp_encryption'] ?? '')==='ssl'?'selected':'' ?>>SSL</option>
                    <option value="none" <?= ($mailSettings['mail_smtp_encryption'] ?? '')==='none'?'selected':'' ?>><?= __('asmtp.opt_none') ?></option>
                </select>
            </div>
            <div>
                <label class="mf-label"><?= __('asmtp.lbl_from_name') ?></label>
                <input type="text" name="mail_from_name" maxlength="120" class="mf-field" placeholder="<?= e($siteName) ?>"
                       value="<?= e($mailSettings['mail_from_name'] ?? '') ?>">
            </div>
            <div>
                <label class="mf-label"><?= __('asmtp.lbl_from_email') ?></label>
                <input type="email" name="mail_from_email" maxlength="255" class="mf-field" placeholder="noreply@sitem.com"
                       value="<?= e($mailSettings['mail_from_email'] ?? '') ?>">
            </div>
            <div style="display:flex;align-items:center;gap:12px;padding-top:18px;">
                <label class="mf-switch">
                    <input type="hidden" name="mail_enabled" value="0">
                    <input type="checkbox" name="mail_enabled" value="1" <?= ($mailSettings['mail_enabled'] ?? '0')==='1'?'checked':'' ?> onchange="toggleMailActive(this)">
                    <span class="track"></span>
                </label>
                <span style="font-size:13px;font-weight:700;"><?= __('adash.status_active') ?></span>
                <span id="mailEnabledHint" style="font-size:11px;color:var(--muted);"></span>
            </div>
        </div>

        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
            <button type="submit" class="btn-admin btn-primary-admin">
                <i class="fa-solid fa-floppy-disk"></i> <?= __('aint.save') ?>
            </button>
            <button type="button" class="btn-admin btn-ghost-admin" id="mailTestBtn">
                <i class="fa-solid fa-paper-plane"></i> <?= __('asmtp.btn_test') ?>
            </button>
            <span id="mailTestMsg" style="font-size:12px;font-weight:700;"></span>
        </div>
    </form>
</div>

</div>

<script>
function toggleMailActive(el){
  var h=document.getElementById('mailEnabledHint');
  h.textContent = el.checked ? <?= json_encode(__('asmtp.js_on')) ?> : <?= json_encode(__('asmtp.js_off')) ?>;
}
document.addEventListener('DOMContentLoaded',function(){
  var btn=document.getElementById('mailTestBtn');
  var msg=document.getElementById('mailTestMsg');
  if(btn){
    btn.addEventListener('click',function(){
      btn.disabled=true;
      var old=btn.innerHTML;
      btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> ' + <?= json_encode(__('asmtp.js_sending')) ?>;
      msg.textContent='';msg.style.color='';
      var fd=new FormData();
      fd.append('action','mail_test_send');
      fd.append('_csrf_token',document.querySelector('meta[name="csrf-token"]').content);
      fetch('/action.php',{method:'POST',body:fd})
        .then(function(r){return r.json()})
        .then(function(d){
          msg.textContent=d.msg;
          msg.style.color=d.ok?'#4ade80':'#f87171';
        })
        ['catch'](function(err){ msg.textContent=<?= json_encode(__('asmtp.js_req_err')) ?>+err; msg.style.color='#f87171'; })
        ['finally'](function(){ btn.disabled=false; btn.innerHTML=old; });
    });
  }
  toggleMailActive(document.querySelector('input[name="mail_enabled"][value="1"]'));
});
</script>
<?php include __DIR__ . '/includes/layout-end.php'; ?>