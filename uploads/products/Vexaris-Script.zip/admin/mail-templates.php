<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.mail_templates');
$activePage = 'mail-templates';

$settingsRaw = $adminDb->query("SELECT `key`,`value` FROM settings")->fetchAll();
$mailSettings = [];
foreach ($settingsRaw as $r) $mailSettings[$r['key']] = $r['value'];
$siteName = $mailSettings['site_name'] ?? '';
$siteLogo = trim($mailSettings['site_logo'] ?? '');

$editSlug = $_GET['slug'] ?? ($_COOKIE['mail_tpl_slug'] ?? 'password_reset');
$editSlug = in_array($editSlug, ['password_reset', 'account_activation'], true) ? $editSlug : 'password_reset';

$templates = [];
try {
    $tplSt = $adminDb->query("SELECT id, slug, subject, header_title, body_html, accent_color, logo_url, updated_at FROM mail_templates ORDER BY id ASC");
    $templates = $tplSt->fetchAll();
} catch (\PDOException $e) { error_log('[NS] mail-templates list: '.$e->getMessage()); }

$editTpl = null;
foreach ($templates as $t) if ($t['slug'] === $editSlug) $editTpl = $t;

if ($editTpl === null) {
    try {
        $st = $adminDb->prepare("SELECT id, slug, subject, header_title, body_html, accent_color, logo_url, updated_at FROM mail_templates WHERE slug=? LIMIT 1");
        $st->execute([$editSlug]);
        $editTpl = $st->fetch();
    } catch (\PDOException $e) { error_log('[NS] mail-templates fetch: '.$e->getMessage()); }
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_mail_template'])) {
    csrf_verify();
    $slug = $_POST['delete_mail_template'] ?? '';
    if (in_array($slug, ['password_reset','account_activation'], true) && function_exists('mail_template_defaults')) {
        $def = mail_template_defaults($slug);
        if ($def) {
            try {
                $adminDb->prepare('UPDATE mail_templates SET subject=?, header_title=?, body_html=?, accent_color=?, logo_url=NULL WHERE slug=?')
                        ->execute([$def['subject'], $def['header_title'], $def['body_html'], $def['accent_color'], $slug]);
                $msg = ['type'=>'success','text'=>__('amail.reset_done')];
            } catch (\PDOException $e) { error_log('[NS] mail-template reset: '.$e->getMessage()); $msg = ['type'=>'err','text'=>__('amail.reset_fail')]; }
        }
    }
}

$bodyHtml  = $editTpl['body_html'] ?? '';
$bodyInner = $bodyHtml;
$shellPre  = '';
$shellPost = '';
if (strpos($bodyHtml, '<!--NEXUS_BODY_START-->') !== false && strpos($bodyHtml, '<!--NEXUS_BODY_END-->') !== false) {
    $pre       = explode('<!--NEXUS_BODY_START-->', $bodyHtml, 2);
    $shellPre  = $pre[0];
    $rest      = explode('<!--NEXUS_BODY_END-->', $pre[1], 2);
    $bodyInner = $rest[0];
    $shellPost = $rest[1];
}

include __DIR__ . '/includes/layout.php';
?>
<style>
.mt-wrap{display:grid;grid-template-columns:300px 1fr;gap:22px;align-items:start;}
.mt-side{display:flex;flex-direction:column;gap:10px;position:sticky;top:72px;}
.mt-tpl-row{display:grid;grid-template-columns:1fr;gap:10px;}
.mt-tpl-card{display:flex;align-items:center;gap:13px;padding:16px 18px;border-radius:16px;border:1px solid var(--border);background:var(--bg-card);text-decoration:none;position:relative;overflow:hidden;transition:all .2s;min-width:0;}
.mt-tpl-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:var(--accent);opacity:.55;transition:opacity .2s;}
.mt-tpl-card:hover{border-color:rgba(var(--accent-rgb),.5);transform:translateY(-2px);box-shadow:0 8px 18px rgba(0,0,0,.08);}
.mt-tpl-card.active{border-color:var(--accent);background:rgba(var(--accent-rgb),.08);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.14);}
.mt-tpl-card.active::before{opacity:1;}
.mt-tpl-ico{width:42px;height:42px;border-radius:12px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:16px;color:var(--accent);background:rgba(var(--accent-rgb),.12);}
.mt-tpl-body{min-width:0;flex:1;display:flex;flex-direction:column;gap:3px;}
.mt-tpl-name{font-size:13px;font-weight:800;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.mt-tpl-sub{font-size:11px;color:var(--muted);font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.mt-tpl-chev{color:var(--muted);opacity:.45;font-size:13px;flex-shrink:0;transition:all .2s;}
.mt-tpl-card:hover .mt-tpl-chev{opacity:1;transform:translateX(3px);color:var(--accent);}
.mt-tpl-badge{position:absolute;top:10px;right:10px;display:none;align-items:center;gap:4px;background:var(--accent);color:#fff;font-size:9px;font-weight:800;padding:3px 9px;border-radius:999px;letter-spacing:.05em;text-transform:uppercase;box-shadow:0 3px 10px rgba(var(--accent-rgb),.4);}
.mt-tpl-card.active .mt-tpl-badge{display:inline-flex;}
.mt-tip{font-size:11px;color:var(--muted);line-height:1.5;}
.mt-field{width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:11px 14px;color:var(--text);font-size:13px;font-family:'Plus Jakarta Sans',sans-serif;outline:none;transition:border-color .2s,box-shadow .2s;}
.mt-field:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.18);}
.mt-label{display:block;font-size:11px;font-weight:800;letter-spacing:.05em;text-transform:uppercase;color:var(--muted);margin-bottom:7px;}
.mt-grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.mt-sw-grid{display:flex;flex-wrap:wrap;gap:8px;align-items:center;}
.mt-sw{width:30px;height:30px;border-radius:9px;cursor:pointer;border:2px solid transparent;transition:transform .15s,box-shadow .15s;flex-shrink:0;}
.mt-sw:hover{transform:scale(1.12);}
.mt-sw.active{border-color:var(--text);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.25);transform:scale(1.08);}
.mt-color-input{width:44px;height:44px;border:1px solid var(--border);border-radius:10px;background:var(--bg-surface);cursor:pointer;padding:3px;}
.mt-hex{font-family:ui-monospace,Consolas,monospace;font-size:12px;color:var(--muted);background:var(--bg-surface);border:1px solid var(--border);border-radius:8px;padding:8px 10px;width:86px;text-align:center;outline:none;}
.mt-hex:focus{border-color:var(--accent);}
.mt-logo-prev{max-height:46px;max-width:220px;display:block;border-radius:8px;background:var(--bg-surface);padding:6px;border:1px solid var(--border);object-fit:contain;}
.mt-msg{display:flex;align-items:center;gap:8px;font-size:13px;font-weight:700;padding:12px 16px;border-radius:10px;margin-bottom:18px;}
.mt-msg.ok{background:rgba(34,197,94,.14);color:#4ade80;border:1px solid rgba(34,197,94,.3);}
.mt-msg.err{background:rgba(239,68,68,.14);color:#f87171;border:1px solid rgba(239,68,68,.3);}
.mt-preview-frame{width:100%;border:1px solid var(--border);border-radius:12px;background:#f1f5f9;min-height:520px;}
.mt-ed-toolbar{display:flex;flex-wrap:wrap;gap:4px;align-items:center;background:var(--bg-surface);border:1px solid var(--border);border-bottom:none;border-radius:12px 12px 0 0;padding:8px;position:sticky;top:56px;z-index:20;}
.mt-ed-btn{width:32px;height:32px;border:none;background:transparent;color:var(--muted);border-radius:8px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;font-size:14px;transition:background .15s,color .15s;flex-shrink:0;}
.mt-ed-btn:hover{background:rgba(var(--accent-rgb),.12);color:var(--text);}
.mt-ed-btn.active{background:var(--accent);color:#fff;}
.mt-ed-sep{width:1px;height:20px;background:var(--border);margin:0 5px;}
.mt-ed-area{background:#fff;border:1px solid var(--border);border-radius:0 0 12px 12px;min-height:340px;padding:20px 24px;outline:none;color:#1f2937;font-size:15px;line-height:1.65;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;overflow-y:auto;max-height:520px;}
.mt-ed-area:empty:before{content:<?= json_encode(__('amail.body_ph')) ?>;color:#9ca3af;pointer-events:none;}
.mt-ed-area h2{font-size:18px;color:#111827;font-weight:600;margin:0 0 12px;}
.mt-ed-area p{margin:0 0 16px;color:#4b5563;}
.mt-ed-area a{color:var(--accent);text-decoration:underline;}
.mt-ed-area strong{font-weight:700;}
.mt-ed-area blockquote{border-left:4px solid var(--accent);background:#f8fafc;margin:0 0 16px;padding:10px 16px;color:#6b7280;font-style:italic;}
.mt-ed-area ul,.mt-ed-area ol{margin:0 0 16px;padding-left:22px;}
.mt-var{display:inline-block;background:rgba(var(--accent-rgb),.14);color:var(--accent);border:1px solid rgba(var(--accent-rgb),.35);border-radius:5px;padding:1px 6px;font-family:ui-monospace,Consolas,monospace;font-size:12px;line-height:1.5;}
.mt-chip-row{display:flex;flex-wrap:wrap;gap:6px;align-items:center;}
.mt-chip{display:inline-flex;align-items:center;gap:6px;font-family:ui-monospace,Consolas,monospace;font-size:11px;background:var(--bg-surface);border:1px dashed var(--border-focus);color:var(--accent);border-radius:7px;padding:5px 10px;cursor:pointer;transition:all .15s;}
.mt-chip:hover{background:rgba(var(--accent-rgb),.12);border-style:solid;}
.mt-empty{text-align:center;padding:30px 20px;color:var(--muted);font-size:14px;}
.mt-actions{position:sticky;bottom:14px;z-index:30;display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:18px;padding:12px 16px;background:var(--bg-card);border:1px solid var(--border);border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,.12);}
@media(max-width:900px){.mt-wrap{grid-template-columns:1fr;}.mt-side{position:static;}.mt-grid2{grid-template-columns:1fr;}.mt-ed-toolbar{position:static;}}
@media(max-width:600px){.mt-actions{bottom:8px;padding:10px 12px;}}
</style>

<div style="padding:24px;">

<?php if ($msg): ?>
<div class="mt-msg <?= $msg['type']==='success'?'ok':'err' ?>">
    <i class="fa-solid <?= $msg['type']==='success'?'fa-circle-check':'fa-circle-exclamation' ?>"></i> <?= e($msg['text']) ?>
</div>
<?php endif; ?>

<div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-envelope-open-text" style="color:var(--accent);margin-right:8px;"></i><?= __('amenu.mail_templates') ?></span>
        <span class="mt-tip"><i class="fa-solid fa-circle-info"></i> <?= __('amail.feed_hint') ?> <code>{user_name}</code> <code>{reset_link}</code> <code>{verification_link}</code> <code>{site_name}</code> <code>{accent_color}</code> <code>{logo}</code> <code>{header_title}</code></span>
    </div>
</div>

<div class="mt-wrap">

    <div class="mt-side">
        <div class="mt-tpl-row">
            <?php foreach ($templates as $t): ?>
            <a href="/admin/mail-templates.php?slug=<?= e($t['slug']) ?>" class="mt-tpl-card <?= $t['slug']===$editSlug?'active':'' ?>" title="<?= e($t['slug']) ?>">
                <span class="mt-tpl-ico"><i class="fa-solid <?= $t['slug']==='password_reset' ? 'fa-lock' : 'fa-user-check' ?>"></i></span>
                <span class="mt-tpl-body">
                    <span class="mt-tpl-name"><?= e($t['header_title'] !== '' ? $t['header_title'] : $t['subject']) ?></span>
                    <span class="mt-tpl-sub"><i class="fa-regular fa-clock"></i> <?= e($t['updated_at']) ?></span>
                </span>
                <span class="mt-tpl-chev"><i class="fa-solid fa-angle-right"></i></span>
                <?php if ($t['slug']===$editSlug): ?><span class="mt-tpl-badge"><i class="fa-solid fa-check"></i> Aktif</span><?php endif; ?>
            </a>
            <?php endforeach; ?>
        </div>

        <div class="admin-card" style="margin-top:14px;padding:14px;">
            <div class="mt-tip" style="display:flex;flex-direction:column;gap:6px;">
                <span><i class="fa-solid fa-image" style="color:var(--accent);margin-right:6px;"></i><?= __('amail.site_logo') ?></span>
                <?php if ($siteLogo !== ''): ?>
                    <img class="mt-logo-prev" src="<?= e($siteLogo) ?>" alt="<?= __('amail.logo_alt') ?>" onerror="this.style.display='none'">
                    <span style="color:var(--dim);word-break:break-all;"><?= e($siteLogo) ?></span>
                <?php else: ?>
                    <span style="color:var(--dim);"><i class="fa-regular fa-circle-xmark"></i> <?= __('amail.no_logo_a') ?> <a href="/admin/settings.php?tab=site" style="color:var(--accent);font-weight:700;"><?= __('amenu.settings_site') ?></a><?= __('amail.no_logo_b') ?></span>
                <?php endif; ?>
                <a href="/admin/mail-settings.php" style="color:var(--accent);font-weight:700;font-size:11px;"><i class="fa-solid fa-gear"></i> <?= __('amail.smtp_config') ?></a>
            </div>
        </div>
    </div>

    <div>
    <?php if ($editTpl): ?>

        <div class="admin-card" style="margin-bottom:16px;">
            <div class="admin-card-header">
                <span class="admin-card-title"><i class="fa-solid fa-sliders" style="color:var(--accent);margin-right:8px;"></i><?= __('amail.basic_info') ?></span>
            </div>
            <div class="mt-grid2">
                <div>
                    <label class="mt-label"><?= __('amail.subject_label') ?></label>
                    <input type="text" name="subject" maxlength="255" class="mt-field" id="mtSubject" value="<?= e($editTpl['subject']) ?>">
                </div>
                <div>
                    <label class="mt-label"><?= __('amail.header_label') ?></label>
                    <input type="text" name="header_title" maxlength="160" class="mt-field" id="mtHeaderTitle"
                           placeholder="<?= __('amail.header_ph') ?>" value="<?= e($editTpl['header_title'] ?? '') ?>">
                </div>
            </div>
        </div>

        <div class="admin-card" style="margin-bottom:16px;">
            <div class="admin-card-header">
                <span class="admin-card-title"><i class="fa-solid fa-palette" style="color:var(--accent);margin-right:8px;"></i><?= __('amail.color_logo') ?></span>
            </div>
            <div class="mt-grid2">
                <div>
                    <label class="mt-label"><?= __('amail.accent_label') ?></label>
                    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                        <input type="color" id="mtAccent" class="mt-color-input" value="<?= e($editTpl['accent_color'] ?: '#4f46e5') ?>">
                        <div class="mt-sw-grid">
                            <?php foreach (['#4f46e5','var(--accent)','#3b82f6','#2563eb','#0ea5e9','#0284c7','#06b6d4','#0d9488','#14b8a6','#10b981','#22c55e','#84cc16','#eab308','#f59e0b','#f97316','#ef4444','#dc2626','#f43f5e','#ec4899','#a855f7','#8b5cf6','#d946ef','#64748b','#475569'] as $sw): ?>
                            <span class="mt-sw <?= ($editTpl['accent_color'] ?: '#4f46e5') === $sw ? 'active' : '' ?>" data-color="<?= $sw ?>" style="background:<?= $sw ?>;"></span>
                            <?php endforeach; ?>
                        </div>
                        <input type="text" class="mt-hex" id="mtAccentHex" maxlength="7" value="<?= e($editTpl['accent_color'] ?: '#4f46e5') ?>">
                    </div>
                    <p class="mt-tip" style="margin-top:8px;"><i class="fa-solid fa-circle-info"></i> <?= __('amail.accent_hint_a') ?> <code>{accent_color}</code> <?= __('amail.accent_hint_b') ?></p>
                </div>
                <div>
                    <label class="mt-label"><?= __('amail.logo_label') ?></label>
                    <input type="url" name="logo_url" id="mtLogoUrl" maxlength="255" class="mt-field"
                           placeholder="https://site.com/logo.png" value="<?= e($editTpl['logo_url'] ?? '') ?>">
                    <p class="mt-tip" style="margin-top:8px;">
                        <i class="fa-solid fa-circle-info"></i>
                        <?= __('amail.logo_empty_a') ?> <a href="/admin/settings.php?tab=site" style="color:var(--accent);font-weight:700;"><?= __('amenu.settings_site') ?></a><?= __('amail.logo_empty_b') ?>
                        <?php if ($siteLogo !== ''): ?> <?= __('amail.active_logo') ?> <code style="word-break:break-all;"><?= e($siteLogo) ?></code><?php endif; ?>
                    </p>
                </div>
            </div>
        </div>

        <div class="admin-card" style="margin-bottom:16px;">
            <div class="admin-card-header">
                <span class="admin-card-title"><i class="fa-solid fa-pen-to-square" style="color:var(--accent);margin-right:8px;"></i><?= __('amail.editor') ?></span>
                <span class="mt-tip" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                    <?= __('amail.add_var') ?>
                    <?php foreach (['{user_name}','{reset_link}','{verification_link}','{site_name}','{accent_color}'] as $pv): ?>
                    <span class="mt-chip" data-var="<?= e($pv) ?>"><?= e($pv) ?></span>
                    <?php endforeach; ?>
                </span>
            </div>

            <div class="mt-ed-toolbar">
                <button type="button" class="mt-ed-btn" data-cmd="bold" title="<?= __('amail.t_bold') ?>"><i class="fa-solid fa-bold"></i></button>
                <button type="button" class="mt-ed-btn" data-cmd="italic" title="<?= __('amail.t_italic') ?>"><i class="fa-solid fa-italic"></i></button>
                <button type="button" class="mt-ed-btn" data-cmd="underline" title="<?= __('amail.t_underline') ?>"><i class="fa-solid fa-underline"></i></button>
                <span class="mt-ed-sep"></span>
                <button type="button" class="mt-ed-btn" data-cmd="formatBlock" data-tag="h2" title="<?= __('amail.t_heading') ?>"><i class="fa-solid fa-heading"></i></button>
                <button type="button" class="mt-ed-btn" data-cmd="formatBlock" data-tag="p" title="<?= __('amail.t_paragraph') ?>"><i class="fa-solid fa-paragraph"></i></button>
                <button type="button" class="mt-ed-btn" data-cmd="formatBlock" data-tag="blockquote" title="<?= __('amail.t_quote') ?>"><i class="fa-solid fa-quote-left"></i></button>
                <span class="mt-ed-sep"></span>
                <button type="button" class="mt-ed-btn" data-cmd="insertUnorderedList" title="<?= __('amail.t_bullets') ?>"><i class="fa-solid fa-list-ul"></i></button>
                <button type="button" class="mt-ed-btn" data-cmd="insertOrderedList" title="<?= __('amail.t_numbered') ?>"><i class="fa-solid fa-list-ol"></i></button>
                <button type="button" class="mt-ed-btn" data-cmd="justifyLeft" title="<?= __('amail.t_left') ?>"><i class="fa-solid fa-align-left"></i></button>
                <button type="button" class="mt-ed-btn" data-cmd="justifyCenter" title="<?= __('amail.t_center') ?>"><i class="fa-solid fa-align-center"></i></button>
                <button type="button" class="mt-ed-btn" data-cmd="justifyRight" title="<?= __('amail.t_right') ?>"><i class="fa-solid fa-align-right"></i></button>
                <span class="mt-ed-sep"></span>
                <button type="button" class="mt-ed-btn" id="mtLinkBtn" title="<?= __('amail.t_link') ?>"><i class="fa-solid fa-link"></i></button>
                <button type="button" class="mt-ed-btn" id="mtCtaBtn" title="<?= __('amail.t_cta') ?>"><i class="fa-solid fa-rectangle-ad"></i></button>
                <span class="mt-ed-sep"></span>
                <button type="button" class="mt-ed-btn" data-cmd="removeFormat" title="<?= __('amail.t_clear') ?>"><i class="fa-solid fa-eraser"></i></button>
                <button type="button" class="mt-ed-btn" data-cmd="undo" title="<?= __('amail.t_undo') ?>"><i class="fa-solid fa-rotate-left"></i></button>
                <button type="button" class="mt-ed-btn" data-cmd="redo" title="<?= __('amail.t_redo') ?>"><i class="fa-solid fa-rotate-right"></i></button>
            </div>
            <div class="mt-ed-area" id="mtEd" contenteditable="true"></div>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <span class="admin-card-title"><i class="fa-solid fa-eye" style="color:var(--accent);margin-right:8px;"></i><?= __('amail.preview') ?></span>
                <span class="mt-tip"><i class="fa-solid fa-user"></i> <?= __('amail.sample_label') ?> "<?= __('amail.sample_user') ?>"</span>
            </div>
            <iframe id="mtPreview" class="mt-preview-frame" srcdoc=""></iframe>
        </div>

        <div class="mt-actions">
            <button type="button" id="mtSaveBtn" class="btn-admin btn-primary-admin">
                <i class="fa-solid fa-floppy-disk"></i> <?= __('msg.save') ?>
            </button>
            <form method="POST" action="/admin/mail-templates.php?slug=<?= e($editSlug) ?>" style="margin:0;" onsubmit="return confirm(<?= json_encode(__('amail.confirm_reset')) ?>);">
                <?= csrf_field() ?>
                <input type="hidden" name="delete_mail_template" value="<?= e($editTpl['slug']) ?>">
                <button type="submit" class="btn-admin btn-ghost-admin">
                    <i class="fa-solid fa-rotate-left"></i> <?= __('amail.reset_btn') ?>
                </button>
            </form>
            <span id="mtSaveMsg" style="font-size:12px;font-weight:700;"></span>
        </div>

    <?php else: ?>
        <div class="mt-msg err"><i class="fa-solid fa-triangle-exclamation"></i> <?= __('amail.not_found') ?></div>
    <?php endif; ?>
    </div>

<script>
(function(){
var editSlug    = <?= json_encode($editSlug, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var shellPre    = <?= json_encode($shellPre, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var shellPost   = <?= json_encode($shellPost, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var bodyInitial = <?= json_encode($bodyInner, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var siteName    = <?= json_encode($siteName, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var siteLogo    = <?= json_encode($siteLogo, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var csrfToken   = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

var ed       = document.getElementById('mtEd');
var preview  = document.getElementById('mtPreview');
var saveBtn  = document.getElementById('mtSaveBtn');
var saveMsg  = document.getElementById('mtSaveMsg');
var accent   = document.getElementById('mtAccent');
var hexInp   = document.getElementById('mtAccentHex');
var subject  = document.getElementById('mtSubject');
var headerT  = document.getElementById('mtHeaderTitle');
var logoUrl  = document.getElementById('mtLogoUrl');
if(!ed||!preview) return;

ed.innerHTML = bodyInitial;

function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function getBody(){ return ed.innerHTML; }
function getLogoHtml(){
  var u=(logoUrl?logoUrl.value.trim():'');
  if(u==='') u=siteLogo;
  if(u==='') return '';
  return '<img src="'+esc(u)+'" alt="'+esc(siteName||'Logo')+'" style="display:block;max-width:160px;max-height:64px;height:auto;border:0;outline:none;text-decoration:none;margin-bottom:16px;">';
}
function buildFull(){
  var start='<!--NEXUS_BODY_START-->', end='<!--NEXUS_BODY_END-->';
  var inner=getBody();
  return shellPre + start + inner + end + shellPost;
}
function sampleVars(){
  var link = (editSlug==='password_reset') ? 'https://'+location.host+'/reset?token=ornek' : 'https://'+location.host+'/verify?token=ornek';
  return {
    '{user_name}': <?= json_encode(__('amail.sample_user')) ?>,
    '{reset_link}': link,
    '{verification_link}': link
  };
}
function refreshPreview(){
  var full=buildFull();
  var map={
    '{accent_color}': accent.value,
    '{header_title}': headerT.value||'',
    '{logo}': getLogoHtml(),
    '{site_name}': siteName,
    '{year}': String(new Date().getFullYear())
  };
  Object.assign(map, sampleVars());
  for(var k in map){ full=full.split(k).join(map[k]); }
  preview.srcdoc = full;
}

['input','change','keyup','mouseup'].forEach(function(ev){
  ed.addEventListener(ev, refreshPreview);
});
accent.addEventListener('input', function(){ hexInp.value=accent.value; refreshPreview(); syncSwatches(); });
hexInp.addEventListener('input', function(){
  if(/^#[0-9a-fA-F]{6}$/.test(hexInp.value.trim())){ accent.value=hexInp.value.trim().toLowerCase(); syncSwatches(); refreshPreview(); }
});
if(subject) subject.addEventListener('input', refreshPreview);
if(headerT) headerT.addEventListener('input', refreshPreview);
if(logoUrl) logoUrl.addEventListener('input', refreshPreview);

function syncSwatches(){
  var c=(accent.value||'').toLowerCase();
  document.querySelectorAll('.mt-sw').forEach(function(sw){
    sw.classList.toggle('active', sw.getAttribute('data-color').toLowerCase()===c);
  });
}
document.querySelectorAll('.mt-sw').forEach(function(sw){
  sw.addEventListener('click', function(){
    accent.value=sw.getAttribute('data-color');
    hexInp.value=accent.value;
    syncSwatches(); refreshPreview();
  });
});

document.querySelectorAll('.mt-ed-btn[data-cmd]').forEach(function(b){
  b.addEventListener('mousedown', function(e){ e.preventDefault(); });
  b.addEventListener('click', function(){
    var cmd=b.getAttribute('data-cmd'), tag=b.getAttribute('data-tag');
    ed.focus();
    if(cmd==='formatBlock') document.execCommand('formatBlock', false, '<'+tag+'>');
    else document.execCommand(cmd, false, null);
    refreshPreview();
  });
});

var linkBtn=document.getElementById('mtLinkBtn');
if(linkBtn) linkBtn.addEventListener('click', function(){
  var url=prompt(<?= json_encode(__('amail.link_prompt')) ?>, 'https://');
  if(!url) return;
  ed.focus();
  document.execCommand('createLink', false, url);
  refreshPreview();
});

var ctaBtn=document.getElementById('mtCtaBtn');
if(ctaBtn) ctaBtn.addEventListener('click', function(){
  var linkPh = (editSlug==='password_reset') ? '{reset_link}' : '{verification_link}';
  var label=prompt(<?= json_encode(__('amail.btn_prompt')) ?>, (editSlug==='password_reset')?'Şifremi Sıfırla':'Hesabımı Doğrula');
  if(label===null) return;
  var html='<div style="text-align:center;margin:0 0 24px;"><a href="'+linkPh+'" target="_blank" style="display:inline-block;padding:13px 32px;font-size:15px;color:#ffffff;text-decoration:none;font-weight:600;border-radius:6px;background-color:'+accent.value+';background-color:{accent_color};">'+esc(label)+'</a></div>';
  ed.focus();
  document.execCommand('insertHTML', false, html);
  refreshPreview();
});

document.querySelectorAll('.mt-chip').forEach(function(ch){
  ch.addEventListener('click', function(){
    var v=ch.getAttribute('data-var');
    ed.focus();
    document.execCommand('insertText', false, v);
    refreshPreview();
  });
});

function showMsg(ok, text){
  saveMsg.innerHTML = ok
    ? '<span style="color:#4ade80;"><i class="fa-solid fa-circle-check"></i> '+esc(text)+'</span>'
    : '<span style="color:#f87171;"><i class="fa-solid fa-circle-exclamation"></i> '+esc(text)+'</span>';
}
saveBtn.addEventListener('click', function(){
  var fd=new FormData();
  fd.append('action','mail_template_save');
  fd.append('_csrf_token', csrfToken);
  fd.append('slug', editSlug);
  fd.append('subject', subject?subject.value:'');
  fd.append('header_title', headerT?headerT.value:'');
  fd.append('accent_color', accent.value);
  fd.append('logo_url', logoUrl?logoUrl.value.trim():'');
  fd.append('body_html', buildFull());
  saveBtn.disabled=true;
  saveMsg.innerHTML='<span style="color:var(--muted);"><i class="fa-solid fa-spinner fa-spin"></i> Kaydediliyor...</span>';
  fetch('/action.php', {method:'POST', body:fd})
    .then(function(r){ return r.json(); })
    .then(function(d){
      showMsg(!!d.ok, d.msg||(d.ok?<?= json_encode(__('amail.saved')) ?>:<?= json_encode(__('amail.err_short')) ?>));
      if(d.ok) setTimeout(function(){ location.reload(); }, 800);
    })
    .catch(function(){ showMsg(false, <?= json_encode(__('amail.server_err')) ?>); })
    .finally(function(){ saveBtn.disabled=false; });
});

refreshPreview();
})();
</script>
<?php include __DIR__ . '/includes/layout-end.php'; ?>
