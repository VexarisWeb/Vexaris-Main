<?php
require_once __DIR__ . '/includes/guard.php';
function module_404(): void {
    http_response_code(404);
    echo "<!DOCTYPE html><html lang='" . lang_active() . "'><head><meta charset='UTF-8'><title>404</title></head>"
       . "<body style='margin:0;font-family:sans-serif;background:#0b0f17;color:#e2e8f0;height:100vh;display:flex;align-items:center;justify-content:center;'>"
       . "<div style='text-align:center;'><h1 style='font-size:3rem;margin:0;color:#64748b;'>404</h1>"
       . "<p style='color:#94a3b8;'>" . __('amod.not_found') . "</p></div></body></html>";
    exit;
}
$modSlug = trim($_GET['module'] ?? '');
if (!function_exists('module_slug_valid') || !module_slug_valid($modSlug)) module_404();
$modManifest = module_manifest($modSlug);
if ($modManifest === null) module_404();
$modAdminFile = ROOT_PATH . '/modules/' . $modSlug . '/admin.php';
if (empty($modManifest['admin_page']) || !is_file($modAdminFile)) module_404();
if (!module_enabled($modSlug, $adminDb)) module_404();
if (function_exists('plan_module_allowed') && !plan_module_allowed($modSlug, $modManifest)) module_404();
$pageTitle = $modManifest['name'];
$activePage = 'module_' . $modSlug;
$allModules = modules_all($adminDb);
$module = $allModules[$modSlug] ?? array_merge($modManifest, ['enabled' => '1', 'settings' => []]);
include __DIR__ . '/includes/layout.php';
include $modAdminFile;
include __DIR__ . '/includes/layout-end.php';
