<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.modules');
$activePage = 'modules';

$modules = function_exists('modules_all') ? modules_all($adminDb) : [];
$modTypes = [];
foreach ($modules as $m) {
    $t = $m['type'] ?? 'other';
    if ($t === '') $t = 'other';
    $modTypes[$t] = true;
}
$modTypeLabels = [
    'payment' => __('panel.tx_payment'),
    'shipping' => __('amod.type_shipping'),
    'marketing' => __('amenu.group_marketing'),
    'notification' => __('amod.type_notification'),
    'security' => __('aint.f_security'),
    'analytics' => __('aint.f_analytics'),
    'other' => __('amod.type_other'),
];
include __DIR__ . '/includes/layout.php';
?>
<style>
@keyframes fadeSlideUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
@keyframes modPop{from{opacity:0;transform:translateY(24px) scale(.92)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes modPopOut{from{opacity:1;transform:translateY(0) scale(1)}to{opacity:0;transform:translateY(24px) scale(.92)}}
@keyframes modFade{from{opacity:0}to{opacity:1}}
@keyframes modFadeOut{from{opacity:1}to{opacity:0}}
@keyframes toastIn{from{opacity:0;transform:translateY(-20px) scale(.95)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes toastOut{from{opacity:1;transform:translateY(0) scale(1)}to{opacity:0;transform:translateY(-20px) scale(.95)}}
.mod-card{transition:all .35s cubic-bezier(.34,1.56,.64,1);border-color:var(--border);}
.mod-card.mod-active{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.12);}
.mod-card:not(.mod-active){filter:grayscale(.7);opacity:.6;}
.mod-card:not(.mod-active):hover{filter:grayscale(.4);opacity:.85;}
.mod-card.mod-unconfigured:not(.mod-active){filter:grayscale(.9);opacity:.45;}
.mod-card.mod-unconfigured:not(.mod-active):hover{filter:grayscale(.6);opacity:.7;}
.mod-card:hover{border-color:#545454;}
.mod-card.mod-active:hover{border-color:var(--accent);}
.mod-status-badge{background:rgba(100,116,139,.15);color:var(--muted);}
.mod-card.mod-active .mod-status-badge{background:rgba(34,197,94,.15);color:#4ade80;}
.mod-filter-btn{display:inline-flex;align-items:center;gap:6px;background:var(--bg-surface);border:1px solid var(--border);color:var(--muted);font-size:12px;font-weight:700;padding:7px 16px;border-radius:20px;cursor:pointer;transition:all .2s ease;font-family:inherit;}
.mod-filter-btn:hover{border-color:#545454;color:var(--text);transform:translateY(-1px);}
.mod-filter-btn:active{transform:scale(.94);}
.mod-filter-btn.active{background:rgba(var(--accent-rgb),.15);border-color:var(--accent);color:var(--accent);animation:modPopBtn .35s cubic-bezier(.34,1.56,.64,1);}
#modSearch:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.12);}
#modSearchWrap:focus-within i{color:var(--accent);transform:scale(1.08);}
#modSearchClear:hover{background:#ef4444;border-color:#ef4444;color:#fff;}
.mod-card{transition:all .35s cubic-bezier(.34,1.56,.64,1),opacity .2s ease,transform .2s ease,border-color .35s;}
.mod-filter-hidden{display:none!important;}
.mod-card.mod-filter-enter{animation:modCardIn .4s cubic-bezier(.34,1.56,.64,1) backwards;}
.mod-card.mod-filter-leave{animation:modCardOut .25s ease forwards;}
.mod-tb-in{animation:modSlideDown .5s cubic-bezier(.34,1.56,.64,1) backwards;}
#modSearchWrap{animation-delay:.03s;}
#modFilterLabel{animation-delay:.08s;}
#modFilterChips{animation-delay:.12s;}
.mod-count-badge{display:inline-flex;align-items:center;justify-content:center;min-width:26px;height:26px;padding:0 10px;border-radius:20px;font-size:11px;font-weight:800;color:var(--accent);background:rgba(var(--accent-rgb),.12);border:1px solid var(--accent);flex-shrink:0;}
.mod-empty-enter{animation:modSlideDown .35s ease;}
@keyframes modCardIn{from{opacity:0;transform:translateY(12px) scale(.95)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes modCardOut{from{opacity:1;transform:translateY(0) scale(1)}to{opacity:0;transform:translateY(-6px) scale(.94)}}
@keyframes modPopBtn{0%{transform:scale(1)}45%{transform:scale(1.14)}100%{transform:scale(1)}}
@keyframes modSlideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
.mod-toast{position:fixed;top:24px;right:24px;z-index:99999;padding:14px 22px;border-radius:12px;font-size:13px;font-weight:700;box-shadow:0 12px 40px rgba(0,0,0,.4);animation:toastIn .35s cubic-bezier(.34,1.56,.64,1);display:flex;align-items:center;gap:10px;max-width:400px;backdrop-filter:blur(12px);}
.mod-toast-success{background:rgba(34,197,94,.18);border:1px solid rgba(34,197,94,.35);color:#4ade80;}
.mod-toast-error{background:rgba(239,68,68,.18);border:1px solid rgba(239,68,68,.35);color:#f87171;}
</style>

<div style="padding:20px;">

  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:8px;">
    <div>
      <h1 style="font-size:18px;font-weight:900;display:flex;align-items:center;gap:8px;color:var(--text);">
        <i class="fa-solid fa-puzzle-piece" style="color:#8b5cf6;"></i> <?= __('amenu.modules') ?>
      </h1>
      <p style="font-size:12px;color:var(--dim);margin-top:2px;"><?= __('amod.subtitle') ?></p>
    </div>
  </div>

  <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap;">
    <div style="position:relative;flex:1;min-width:220px;" id="modSearchWrap" class="mod-tb-in">
      <i class="fa-solid fa-magnifying-glass" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);font-size:13px;color:var(--muted);pointer-events:none;transition:color .2s,transform .2s;"></i>
      <input type="text" id="modSearch" placeholder="<?= __('amod.search_ph') ?>" autocomplete="off"
             style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 38px 10px 38px;color:var(--text);font-size:13px;outline:none;transition:border-color .2s,box-shadow .2s;">
      <button type="button" id="modSearchClear" title="<?= __('aint.clear') ?>"
              style="display:none;position:absolute;right:10px;top:50%;transform:translateY(-50%);width:22px;height:22px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid var(--border);color:var(--muted);cursor:pointer;align-items:center;justify-content:center;font-size:11px;transition:all .2s;">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>
    <span style="font-size:11px;color:var(--dim);font-weight:700;flex-shrink:0;" class="mod-tb-in" id="modFilterLabel"><?= __('aint.filter_label') ?></span>
    <div style="display:flex;gap:8px;flex-wrap:wrap;" id="modFilterChips" class="mod-tb-in">
      <button class="mod-filter-btn active" data-filter="all"><?= __('shop.all') ?></button>
      <?php foreach (array_keys($modTypes) as $t): ?>
      <button class="mod-filter-btn" data-filter="<?= e($t) ?>"><?= e($modTypeLabels[$t] ?? ucfirst($t)) ?></button>
      <?php endforeach; ?>
    </div>
    <span class="mod-count-badge" id="modResultCount">0</span>
  </div>

  <?php if (empty($modules)): ?>
  <div style="text-align:center;padding:48px 20px;color:var(--muted);background:var(--bg-card);border:1px solid var(--border);border-radius:16px;">
    <i class="fa-solid fa-puzzle-piece" style="font-size:38px;color:var(--dim);margin-bottom:12px;display:block;"></i>
    <p style="font-size:14px;font-weight:700;color:var(--text);"><?= __('amod.empty_title') ?></p>
    <p style="font-size:12px;margin-top:4px;"><?= __('amod.empty_hint_a') ?> <code style="background:rgba(0,0,0,.3);padding:2px 6px;border-radius:4px;">/modules</code> <?= __('amod.empty_hint_b') ?> <code style="background:rgba(0,0,0,.3);padding:2px 6px;border-radius:4px;">/modules/modul-gelistirme-kurallari.md</code> <?= __('amod.empty_hint_c') ?></p>
  </div>
  <?php endif; ?>

  <div id="modEmpty" style="display:none;text-align:center;padding:48px 20px;color:var(--muted);background:var(--bg-card);border:1px solid var(--border);border-radius:16px;">
    <i class="fa-solid fa-puzzle-piece" style="font-size:38px;color:var(--dim);margin-bottom:12px;display:block;"></i>
    <p style="font-size:14px;font-weight:700;color:var(--text);"><?= __('amod.no_match') ?></p>
    <p style="font-size:12px;margin-top:4px;"><?= __('aint.empty_hint') ?></p>
  </div>

  <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:20px;" id="modGrid">

<?php foreach ($modules as $slug => $mod): ?>
<?php
$enabled = ($mod['enabled'] ?? '0') === '1' ? '1' : '0';
$configured = true;
foreach ($mod['fields'] as $f) {
    $v = $mod['settings'][$f['key']] ?? '';
    if ($v === '' || $v === null) { $configured = false; break; }
}
$hasFields = count($mod['fields']) > 0;
$modName = function_exists('module_text') ? module_text($slug, '_name', (string)($mod['name'] ?? $slug)) : (string)($mod['name'] ?? $slug);
$modDesc = function_exists('module_text') ? module_text($slug, '_description', (string)($mod['description'] ?? '')) : (string)($mod['description'] ?? '');
$modPlanLocked = function_exists('plan_module_allowed') && !plan_module_allowed($slug, $mod);
?>

<div class="admin-card mod-card <?= $enabled==='1'?'mod-active':'' ?> <?= !$configured && $hasFields?'mod-unconfigured':'' ?>"
     data-slug="<?= e($slug) ?>" data-category="<?= e($mod['type'] ?? 'other') ?>"
     data-label="<?= e($modName) ?>"
     data-desc="<?= e($modDesc) ?>"<?= $modPlanLocked ? '' : ' onclick="toggleMod(\'' . e($slug) . '\')"' ?>>
    <?php if ($modPlanLocked): ?>
    <div style="display:flex;align-items:center;gap:8px;font-size:11px;font-weight:800;border-radius:10px;padding:8px 12px;margin-bottom:12px;background:rgba(250,204,21,.1);border:1px solid rgba(250,204,21,.35);color:#facc15;">
        <i class="fa-solid fa-lock"></i> <?= e(__('plan.module_locked')) ?>
    </div>
    <?php endif; ?>
    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:14px;">
        <div style="display:flex;align-items:center;gap:12px;">
            <div class="mod-icon-wrap" style="width:44px;height:44px;border-radius:12px;background:<?= e($mod['color']) ?>15;display:flex;align-items:center;justify-content:center;font-size:20px;color:<?= e($mod['color']) ?>;">
                <i class="<?= e($mod['iconPrefix'] ?? 'fa-solid') ?> <?= e($mod['icon'] ?? 'fa-puzzle-piece') ?>"></i>
            </div>
            <div>
                <span class="mod-label" style="font-size:15px;font-weight:800;"><?= e($modName) ?></span>
                <span style="display:block;font-size:11px;color:var(--muted);margin-top:2px;"><?= e($modDesc) ?></span>
                <span style="display:block;font-size:10px;color:var(--dim);margin-top:3px;">v<?= e($mod['version'] ?? '1.0.0') ?><?= $mod['author'] !== '' ? ' · ' . e($mod['author']) : '' ?></span>
            </div>
        </div>
        <div class="mod-status-badge" style="flex-shrink:0;font-size:10px;font-weight:700;padding:3px 10px;border-radius:20px;transition:all .3s ease;">
            <?= $enabled==='1' ? __('adash.status_active') : __('aint.passive') ?>
        </div>
    </div>

    <div style="display:flex;gap:8px;margin-top:auto;">
        <?php if ($hasFields): ?>
        <button class="btn-admin btn-ghost-admin" style="flex:1;justify-content:center;font-size:12px;padding:8px;" onclick="event.stopPropagation();openModModal('<?= e($slug) ?>')">
            <i class="fa-solid fa-sliders"></i> <?= __('aint.configure') ?>
        </button>
        <?php else: ?>
        <span style="flex:1;text-align:center;font-size:11px;color:var(--dim);padding:8px;"><?= __('amod.no_config') ?></span>
        <?php endif; ?>
        <?php if (!empty($mod['admin_page'])): ?>
        <a href="/admin/module.php?module=<?= e($slug) ?>" class="btn-admin btn-ghost-admin" style="font-size:12px;padding:8px 12px;text-decoration:none;" onclick="event.stopPropagation();" title="<?= __('amod.full_page') ?>">
            <i class="fa-solid fa-arrow-up-right-from-square"></i>
        </a>
        <button class="btn-admin btn-ghost-admin" style="font-size:12px;padding:8px 12px;" onclick="event.stopPropagation();toggleModSidebar('<?= e($slug) ?>')" title="<?= ($mod['sidebar'] ?? '1') === '1' ? __('amod.sidebar_hide') : __('amod.sidebar_show') ?>">
            <i class="fa-solid <?= ($mod['sidebar'] ?? '1') === '1' ? 'fa-eye' : 'fa-eye-slash' ?>"></i>
        </button>
        <?php endif; ?>
    </div>

    <?php if (!$configured && $hasFields): ?>
    <div style="position:absolute;top:14px;right:70px;background:rgba(251,191,36,.12);color:#fbbf24;font-size:10px;font-weight:700;padding:3px 8px;border-radius:6px;">
        <i class="fa-solid fa-triangle-exclamation"></i> <?= __('aint.unconfigured') ?>
    </div>
    <?php endif; ?>
</div>
<?php endforeach; ?>

</div>

<?php foreach ($modules as $slug => $mod): ?>
<?php if (count($mod['fields']) === 0) continue; ?>
<div id="modModal_<?= e($slug) ?>" class="mod-modal fixed inset-0 z-50 flex items-center justify-center p-4" style="display:none;">
    <div class="mod-modal-bg absolute inset-0 bg-black/60 backdrop-blur-sm" onclick="closeModModal('<?= e($slug) ?>')"></div>
    <div class="mod-modal-box relative bg-[var(--bg-card)] border border-white/10 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 24px;border-bottom:1px solid var(--border);">
            <h2 style="font-size:16px;font-weight:800;display:flex;align-items:center;gap:10px;">
                <span style="width:34px;height:34px;border-radius:10px;background:<?= e($mod['color']) ?>15;display:flex;align-items:center;justify-content:center;font-size:16px;color:<?= e($mod['color']) ?>;">
                    <i class="<?= e($mod['iconPrefix'] ?? 'fa-solid') ?> <?= e($mod['icon'] ?? 'fa-puzzle-piece') ?>"></i>
                </span>
                <?= e($modName) ?> <?= __('aint.configuration') ?>
            </h2>
            <button onclick="closeModModal('<?= e($slug) ?>')" style="background:none;border:none;color:var(--muted);font-size:22px;cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form id="modForm_<?= e($slug) ?>" style="padding:24px;" onsubmit="return saveMod(event,'<?= e($slug) ?>')">
            <div style="display:grid;gap:18px;">
                <?php foreach ($mod['fields'] as $f): ?>
                <?php $fVal = $mod['settings'][$f['key']] ?? '';
                $fLabel = function_exists('module_text') ? module_text($slug, '_field_' . $f['key'] . '_label', (string)($f['label'] ?? $f['key'])) : (string)($f['label'] ?? $f['key']);
                $fPh = function_exists('module_text') ? module_text($slug, '_field_' . $f['key'] . '_placeholder', (string)($f['placeholder'] ?? '')) : (string)($f['placeholder'] ?? ''); ?>
                <div>
                    <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= e($fLabel) ?></label>
                    <?php if (($f['type'] ?? '') === 'textarea'): ?>
                    <textarea name="<?= e($slug) ?>_<?= e($f['key']) ?>" class="mod-field" rows="5"
                              placeholder="<?= e($fPh) ?>"
                              style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:12px;font-family:ui-monospace,Consolas,monospace;outline:none;resize:vertical;white-space:pre-wrap;word-break:break-all;"><?= e($fVal) ?></textarea>
                    <?php elseif (($f['type'] ?? '') === 'select'): ?>
                    <select name="<?= e($slug) ?>_<?= e($f['key']) ?>" class="mod-field"
                            style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                        <?php foreach ($f['options'] as $opt): ?>
                        <option value="<?= e($opt['value']) ?>" <?= $fVal === $opt['value'] ? 'selected' : '' ?>><?= e(function_exists('module_optkey') ? module_text($slug, module_optkey((string)$f['key'], (string)$opt['value']), (string)($opt['label'] ?? $opt['value'])) : (string)($opt['label'] ?? $opt['value'])) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php else: ?>
                    <input type="<?= ($f['type'] ?? 'text') === 'number' ? 'number' : 'text' ?>" name="<?= e($slug) ?>_<?= e($f['key']) ?>" class="mod-field"
                           value="<?= e($fVal) ?>"
                           placeholder="<?= e($fPh) ?>"
                           step="<?= e($f['step'] ?? '') ?>"
                           style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <div style="display:flex;gap:10px;margin-top:20px;padding-top:18px;border-top:1px solid var(--border);">
                <button type="submit" class="btn-admin btn-primary-admin" style="flex:1;justify-content:center;padding:11px;">
                    <i class="fa-solid fa-floppy-disk"></i> <?= __('aint.save') ?>
                </button>
                <button type="button" class="btn-admin btn-ghost-admin" style="padding:11px 18px;" onclick="closeModModal('<?= e($slug) ?>')"><?= __('support.cancel') ?></button>
            </div>
        </form>
    </div>
</div>
<?php endforeach; ?>

</div>

<script>
function showModToast(msg, type) {
    var existing = document.querySelector('.mod-toast');
    if (existing) existing.remove();
    var t = document.createElement('div');
    t.className = 'mod-toast mod-toast-' + type;
    t.innerHTML = '<i class="fa-solid fa-' + (type==='success'?'circle-check':'circle-xmark') + '"></i> ' + msg;
    document.body.appendChild(t);
    setTimeout(function(){ t.style.animation = 'toastOut .3s ease forwards'; setTimeout(function(){ t.remove(); }, 300); }, 2500);
}
function openModModal(slug) {
    var m = document.getElementById('modModal_' + slug);
    if (!m) return;
    m.style.display = 'flex';
    m.querySelectorAll('.mod-modal-bg').forEach(function(b){ b.style.animation = 'modFade .3s ease'; });
    var box = m.querySelector('.mod-modal-box');
    if (box) { box.style.animation = 'none'; box.offsetHeight; box.style.animation = 'modPop .35s cubic-bezier(.34,1.56,.64,1)'; }
}
function closeModModal(slug) {
    var m = document.getElementById('modModal_' + slug);
    if (!m || m.style.display === 'none') return;
    m.querySelectorAll('.mod-modal-bg').forEach(function(b){ b.style.animation = 'modFadeOut .25s ease forwards'; });
    var box = m.querySelector('.mod-modal-box');
    if (box) { box.style.animation = 'none'; box.offsetHeight; box.style.animation = 'modPopOut .3s ease forwards'; }
    setTimeout(function(){ m.style.display = 'none'; }, 300);
}
function saveMod(e, slug) {
    e.preventDefault();
    var form = document.getElementById('modForm_' + slug);
    var fd = new FormData();
    fd.set('action', 'mod_save');
    fd.set('slug', slug);
    form.querySelectorAll('.mod-field').forEach(function(inp) {
        fd.set(inp.name, inp.value);
    });
    fetch('/action.php', { method:'POST', body:fd })
        .then(function(r){ return r.text(); })
        .then(function(txt){
            try { var d = JSON.parse(txt); }
            catch(e) { showModToast(<?= json_encode(__('aint.json_invalid')) ?> + ': ' + txt.substring(0,200), 'error'); return; }
            if (d.ok) {
                closeModModal(slug);
                showModToast(<?= json_encode(__('aint.saved_ok')) ?>, 'success');
            } else {
                showModToast(d.msg, 'error');
            }
        })
        .catch(function(err){ showModToast(<?= json_encode(__('aint.conn_err')) ?> + ': ' + err.message, 'error'); });
    return false;
}
function toggleMod(slug) {    var card = document.querySelector('.mod-card[data-slug="'+slug+'"]');
    if (!card) return;
    var isActive = card.classList.contains('mod-active');
    var fd = new FormData();
    fd.set('action', 'mod_toggle');
    fd.set('slug', slug);
    fd.set('state', isActive ? '0' : '1');
    fetch('/action.php', { method:'POST', body:fd })
        .then(function(r){ return r.text(); })
        .then(function(txt){
            try { var d = JSON.parse(txt); }
            catch(e) { showModToast(<?= json_encode(__('aint.json_invalid')) ?> + ': ' + txt.substring(0,200), 'error'); return; }
            if (d.ok) {
                card.classList.toggle('mod-active');
                var badge = card.querySelector('.mod-status-badge');
                if (badge) badge.textContent = isActive ? <?= json_encode(__('aint.passive')) ?> : <?= json_encode(__('adash.status_active')) ?>;
                showModToast(isActive ? <?= json_encode(__('amod.disabled')) ?> : <?= json_encode(__('amod.enabled')) ?>, 'success');
            } else {
                showModToast(d.msg, 'error');
            }
        })
        .catch(function(err){ showModToast(<?= json_encode(__('aint.conn_err')) ?> + ': ' + err.message, 'error'); });
}
function toggleModSidebar(slug) {
    var card = document.querySelector('.mod-card[data-slug="'+slug+'"]');
    if (!card) return;
    var btn = event.currentTarget;
    var icon = btn ? btn.querySelector('i') : null;
    var shown = icon ? icon.classList.contains('fa-eye') : true;
    var fd = new FormData();
    fd.set('action', 'mod_sidebar');
    fd.set('slug', slug);
    fd.set('state', shown ? '0' : '1');
    fetch('/action.php', { method:'POST', body:fd })
        .then(function(r){ return r.text(); })
        .then(function(txt){
            try { var d = JSON.parse(txt); }
            catch(e) { showModToast(<?= json_encode(__('aint.json_invalid')) ?> + ': ' + txt.substring(0,200), 'error'); return; }
            if (d.ok) {
                if (icon) { icon.classList.toggle('fa-eye'); icon.classList.toggle('fa-eye-slash'); }
                if (btn) btn.title = shown ? <?= json_encode(__('amod.sidebar_show')) ?> : <?= json_encode(__('amod.sidebar_hide')) ?>;
                showModToast(d.msg, 'success');
            } else {
                showModToast(d.msg, 'error');
            }
        })
        .catch(function(err){ showModToast(<?= json_encode(__('aint.conn_err')) ?> + ': ' + err.message, 'error'); });
}
var _modQuery = '';
var _modCat = 'all';
var _modLeaving = {};
function applyModFilter() {
    var q = _modQuery.toLowerCase().trim();
    var visible = 0;
    var cards = document.querySelectorAll('#modGrid .mod-card');
    cards.forEach(function(card) {
        var cat = card.getAttribute('data-category') || 'other';
        var label = (card.getAttribute('data-label') || '').toLowerCase();
        var desc = (card.getAttribute('data-desc') || '').toLowerCase();
        var slug = (card.getAttribute('data-slug') || '').toLowerCase();
        var okCat = (_modCat === 'all' || cat === _modCat);
        var okQ = !q || label.indexOf(q) !== -1 || desc.indexOf(q) !== -1 || slug.indexOf(q) !== -1;
        var show = okCat && okQ;
        var key = card.getAttribute('data-slug');
        if (show) {
            if (_modLeaving[key]) { delete _modLeaving[key]; }
            card.classList.remove('mod-filter-leave');
            if (card.classList.contains('mod-filter-hidden')) {
                card.classList.remove('mod-filter-hidden');
                card.style.animation = '';
                void card.offsetWidth;
                card.classList.add('mod-filter-enter');
                card.addEventListener('animationend', function onIn(e) {
                    if (e.animationName !== 'modCardIn') return;
                    card.classList.remove('mod-filter-enter');
                    card.style.animation = '';
                    card.removeEventListener('animationend', onIn);
                });
            }
            visible++;
        } else {
            if (_modLeaving[key] || card.classList.contains('mod-filter-hidden')) return;
            _modLeaving[key] = true;
            card.classList.remove('mod-filter-enter');
            card.style.animation = '';
            void card.offsetWidth;
            card.classList.add('mod-filter-leave');
            card.addEventListener('animationend', function onOut(e) {
                if (e.animationName !== 'modCardOut') return;
                card.classList.remove('mod-filter-leave');
                card.style.animation = '';
                card.classList.add('mod-filter-hidden');
                card.removeEventListener('animationend', onOut);
                delete _modLeaving[key];
            });
        }
    });
    var empty = document.getElementById('modEmpty');
    if (visible === 0 && empty.style.display !== 'block') {
        empty.style.display = 'block';
        empty.classList.add('mod-empty-enter');
        setTimeout(function(){ empty.classList.remove('mod-empty-enter'); }, 400);
    } else if (visible > 0 && empty.style.display === 'block') {
        empty.style.display = 'none';
    }
    var rc = document.getElementById('modResultCount');
    if (rc) {
        var n = String(visible);
        if (rc.textContent !== n) {
            rc.textContent = n;
            rc.style.animation = 'none';
            void rc.offsetWidth;
            rc.style.animation = 'modPopBtn .35s cubic-bezier(.34,1.56,.64,1)';
        }
    }
    var cb = document.getElementById('modSearchClear');
    if (cb) {
        var active = _modSearchEl && _modSearchEl.value.length > 0;
        cb.style.display = active ? 'flex' : 'none';
    }
}
var _modSearchEl = document.getElementById('modSearch');
if (_modSearchEl) {
    _modSearchEl.addEventListener('input', function() {
        _modQuery = this.value;
        applyModFilter();
    });
}
var _modClearEl = document.getElementById('modSearchClear');
if (_modClearEl) {
    _modClearEl.addEventListener('click', function() {
        if (_modSearchEl) { _modSearchEl.value = ''; _modQuery = ''; _modSearchEl.focus(); applyModFilter(); }
    });
}
document.querySelectorAll('.mod-filter-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.mod-filter-btn').forEach(function(b) { b.classList.remove('active'); });
        btn.classList.add('active');
        _modCat = btn.getAttribute('data-filter');
        applyModFilter();
    });
});
var _modCardsInit = document.querySelectorAll('#modGrid .mod-card');
_modCardsInit.forEach(function(card, i) {
    card.style.animation = 'modCardIn .45s cubic-bezier(.34,1.56,.64,1) ' + (i * 0.05) + 's backwards';
    card.addEventListener('animationend', function onInit(e) {
        if (e.animationName !== 'modCardIn') return;
        card.style.animation = '';
        card.removeEventListener('animationend', onInit);
    });
});
applyModFilter();

var _modOpenSlug = new URLSearchParams(window.location.search).get('open');
if (_modOpenSlug) {
    setTimeout(function() {
        var card = document.querySelector('.mod-card[data-slug="' + _modOpenSlug + '"]');
        if (card) {
            card.scrollIntoView({ behavior: 'smooth', block: 'center' });
            card.style.boxShadow = '0 0 0 3px rgba(var(--accent-rgb),.55)';
            setTimeout(function(){ card.style.boxShadow = ''; }, 1600);
        }
        if (typeof openModModal === 'function') openModModal(_modOpenSlug);
    }, 350);
}
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
