<?php
require_once __DIR__ . '/includes/guard.php';
if (function_exists('feature_active') && !feature_active('roles_permissions')) {
    http_response_code(404);
    echo "<!DOCTYPE html><html lang='tr'><head><meta charset='UTF-8'><title>404</title></head>"
       . "<body style='margin:0;font-family:sans-serif;background:#0b0f17;color:#e2e8f0;height:100vh;display:flex;align-items:center;justify-content:center;'>"
       . "<div style='text-align:center;'><h1 style='font-size:3rem;margin:0;color:#64748b;'>404</h1>"
       . "<p style='color:#94a3b8;'>" . __('err.e404_title') . "</p></div></body></html>";
    exit;
}
$pageTitle  = __('amenu.permissions');
$activePage = 'permissions';
if (function_exists('plan_current') && (plan_current()['slug'] ?? 'free') === 'free') {
    http_response_code(404);
    echo "<!DOCTYPE html><html lang='tr'><head><meta charset='UTF-8'><title>404</title></head>"
       . "<body style='margin:0;font-family:sans-serif;background:#0b0f17;color:#e2e8f0;height:100vh;display:flex;align-items:center;justify-content:center;'>"
       . "<div style='text-align:center;'><h1 style='font-size:3rem;margin:0;color:#64748b;'>404</h1>"
       . "<p style='color:#94a3b8;'>" . __('err.e404_title') . "</p></div></body></html>";
    exit;
}

$msg = '';

function nx_all_resources(): array {
    return ['dashboard','users','permissions','settings','integrations','modules','stats','ai_assistant','products','purchases','categories','licenses','reviews','coupons','slider','audit-logs','announcements','references','seo','custom_pages','legal','themes','support','ticket_categories','discord-webhook'];
}

function nx_resource_groups(): array {
    return [
        'grp_manage' => [
            'dashboard'   => __('amenu.dashboard'),
            'users'       => __('amenu.users'),
            'permissions' => __('amenu.permissions'),
            'settings'    => __('amenu.group_settings'),
            'integrations'=> __('amenu.integrations'),
            'modules'     => __('amenu.modules'),
            'stats'       => __('amenu.stats'),
            'ai_assistant'=> __('amenu.ai_assistant'),
        ],
        'grp_shop' => [
            'products'   => __('amenu.products'),
            'purchases'  => __('amenu.purchases'),
            'categories' => __('amenu.categories'),
            'licenses'   => __('amenu.licenses'),
            'reviews'    => __('amenu.reviews'),
            'coupons'    => __('amenu.coupons'),
            'slider'     => __('amenu.slider'),
            'audit-logs' => __('amenu.audit_logs'),
        ],
        'grp_content' => [
            'announcements' => __('amenu.announcements'),
            'references'    => __('amenu.references'),
            'seo'           => __('amenu.seo'),
            'custom_pages'  => __('amenu.custom_pages'),
            'legal'         => __('amenu.legal'),
            'themes'        => __('amenu.themes'),
        ],
        'grp_support' => [
            'support'           => __('common.support'),
            'ticket_categories' => __('amenu.ticket_categories'),
            'discord-webhook'   => __('amenu.discord_webhook'),
        ],
    ];
}

$roles = roles_all($adminDb);
if (empty($roles)) {
    $roles = [
        'admin' => ['slug'=>'admin','name_tr'=>'Admin','name_en'=>'Admin','color'=>'#f43f5e','icon'=>'fa-solid fa-crown','rank'=>100,'is_system'=>1],
        'user' => ['slug'=>'user','name_tr'=>'Üye','name_en'=>'Member','color'=>'#4ade80','icon'=>'fa-solid fa-user','rank'=>0,'is_system'=>1],
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_permissions'])) {
    $myRole = $adminUser['role'] ?? 'user';
    if (!in_array($myRole, ['admin', 'superadmin'], true)) {
        $msg = ['type'=>'error','text'=>__('aperm.only_admin')];
    } else {
        $role = trim($_POST['role'] ?? '');
        if (!isset($roles[$role])) {
            $msg = ['type'=>'error','text'=>__('aperm.invalid_role')];
        } elseif ($role === 'superadmin') {
            $msg = ['type'=>'error','text'=>__('aperm.admin_locked')];
        } elseif ($role === 'admin' && $myRole !== 'superadmin') {
            $msg = ['type'=>'error','text'=>__('aperm.only_admin')];
        } else {
            try {
                $resources = $_POST['resources'] ?? [];
                if (!is_array($resources)) $resources = [];
                $oldPerms = [];
                try {
                    $oldSt = $adminDb->prepare('SELECT resource FROM permissions WHERE role = ?');
                    $oldSt->execute([$role]);
                    $oldPerms = $oldSt->fetchAll(\PDO::FETCH_COLUMN);
                } catch (\PDOException $e) {}
                $adminDb->prepare('DELETE FROM permissions WHERE role = ?')->execute([$role]);
                $ins = $adminDb->prepare('INSERT IGNORE INTO permissions (role,resource) VALUES (?,?)');
                $newPerms = [];
                foreach ($resources as $res) {
                    $res = trim((string)$res);
                    if (!in_array($res, nx_all_resources(), true)) continue;
                    $ins->execute([$role, $res]);
                    $newPerms[] = $res;
                }
                $revoked = array_values(array_diff($oldPerms, $newPerms));
                if (!empty($revoked)) {
                    $upd = $adminDb->prepare('UPDATE users SET session_version=session_version+1 WHERE role=?');
                    $upd->execute([$role]);
                    try {
                        $delT = $adminDb->prepare('DELETE FROM remember_tokens WHERE user_id IN (SELECT id FROM users WHERE role=?)');
                        $delT->execute([$role]);
                    } catch (\PDOException $e) {}
                }
                audit_log($adminDb, 'update', 'permissions', 0, $role, '/admin/permissions.php?role=' . urlencode($role));
                $msg = ['type'=>'success','text'=> e(role_display($adminDb, $role)['name']) . __('aperm.updated_suffix')];
            } catch (\PDOException $e) {
                error_log('[Vexaris] permissions save: ' . $e->getMessage());
                $msg = ['type'=>'error','text'=>__('bsys.save_error')];
            }
        }
    }
}

$flash = $_GET['flash'] ?? '';
if ($flash !== '' && $msg === '') {
    $parts = explode(':', urldecode($flash), 2) + ['',''];
    if (($parts[1] ?? '') !== '') $msg = ['type' => $parts[0] === 'success' ? 'success' : 'error', 'text' => $parts[1]];
}

$permData = [];
try {
    foreach ($adminDb->query('SELECT role,resource FROM permissions')->fetchAll() as $row) {
        $permData[$row['role']][] = $row['resource'];
    }
} catch (\PDOException $e) {}
$roleCounts = [];
try {
    foreach ($adminDb->query('SELECT role,COUNT(*) AS c FROM users GROUP BY role')->fetchAll() as $row) {
        $roleCounts[$row['role']] = (int)$row['c'];
    }
} catch (\PDOException $e) {}

$wantedRole = trim($_GET['role'] ?? '');
if (!isset($roles[$wantedRole])) $wantedRole = '';
$activeRole = $wantedRole;
if ($activeRole === '' && isset($roles['yonetici'])) $activeRole = 'yonetici';
if ($activeRole === '') {
    foreach ($roles as $slug => $r) {
        if ($slug !== 'admin' && $slug !== 'superadmin') { $activeRole = $slug; break; }
    }
}
if ($activeRole === '') $activeRole = array_key_first($roles);

$roleIcons = ['fa-solid fa-crown','fa-solid fa-user-tie','fa-solid fa-user-shield','fa-solid fa-user-gear','fa-solid fa-shield-halved','fa-solid fa-headset','fa-solid fa-user','fa-solid fa-users','fa-solid fa-star','fa-solid fa-gem','fa-solid fa-medal','fa-solid fa-award','fa-solid fa-trophy','fa-solid fa-key','fa-solid fa-lock','fa-solid fa-bolt','fa-solid fa-rocket','fa-solid fa-eye','fa-solid fa-flag','fa-solid fa-wrench','fa-solid fa-hammer','fa-solid fa-gear','fa-solid fa-sliders','fa-solid fa-chart-line','fa-solid fa-coins','fa-solid fa-ticket','fa-solid fa-tag','fa-solid fa-box','fa-solid fa-cube','fa-solid fa-bell','fa-solid fa-envelope','fa-solid fa-comments','fa-solid fa-life-ring','fa-solid fa-handshake','fa-solid fa-briefcase','fa-solid fa-clipboard-check','fa-solid fa-filter','fa-solid fa-magnifying-glass','fa-solid fa-pen','fa-solid fa-trash','fa-solid fa-ban','fa-solid fa-circle-check','fa-solid fa-heart','fa-solid fa-thumbs-up','fa-solid fa-lightbulb','fa-solid fa-book','fa-solid fa-graduation-cap','fa-solid fa-palette','fa-solid fa-camera','fa-solid fa-music','fa-solid fa-gamepad','fa-solid fa-robot','fa-solid fa-ghost','fa-solid fa-dragon','fa-solid fa-paw','fa-solid fa-leaf','fa-solid fa-fire','fa-solid fa-snowflake','fa-solid fa-moon','fa-solid fa-sun','fa-solid fa-anchor','fa-solid fa-compass','fa-solid fa-map','fa-solid fa-globe','fa-solid fa-wifi','fa-solid fa-server','fa-solid fa-database','fa-solid fa-code','fa-solid fa-terminal'];

include __DIR__ . '/includes/layout.php';
?>
<style>
@keyframes fadeSlideUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
.perm-tabs{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;}
.perm-tab{display:inline-flex;align-items:center;gap:8px;padding:8px 14px 8px 8px;border-radius:12px;border:1px solid var(--border);background:var(--bg-surface);color:var(--muted);font-size:12px;font-weight:700;cursor:pointer;transition:all .15s;font-family:inherit;max-width:100%;}
.perm-tab:hover{color:var(--text);border-color:rgba(255,255,255,.12);}
.perm-tab.active{background:rgba(var(--accent-rgb),.1);color:var(--text);border-color:var(--accent);}
.perm-tab-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.perm-tab-count{font-size:10px;font-weight:800;background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:99px;padding:1px 8px;color:var(--muted);flex-shrink:0;}
.perm-tab-lock{font-size:10px;color:var(--muted);flex-shrink:0;}
.perm-panel{animation:fadeSlideUp .2s ease;}
.perm-rolebar{display:flex;gap:12px;align-items:center;margin-bottom:8px;flex-wrap:wrap;}
.perm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px;}
.perm-check{display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;cursor:pointer;transition:border-color .15s;font-size:12px;font-weight:600;user-select:none;min-width:0;}
.perm-check span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.role-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.role-icn{display:flex;align-items:center;justify-content:center;height:52px;border-radius:10px;background:var(--bg-surface);border:1px solid var(--border);font-size:20px;color:var(--muted);cursor:pointer;transition:all .15s;}
.role-icn:hover{color:var(--text);border-color:var(--accent);}
.role-icn.active{color:#fff;background:var(--accent);border-color:var(--accent);}
@media(max-width:768px){
  .perm-tabs{flex-wrap:nowrap;overflow-x:auto;padding-bottom:8px;margin-bottom:14px;-webkit-overflow-scrolling:touch;}
  .perm-tab{flex-shrink:0;}
  .perm-grid{grid-template-columns:repeat(auto-fill,minmax(140px,1fr));}
  .role-form-grid{grid-template-columns:1fr;}
  .perm-rolebar .btn-admin{font-size:11px;padding:8px 12px;}
}
@media(max-width:480px){
  .perm-grid{grid-template-columns:1fr 1fr;}
  .perm-check{padding:8px 10px;font-size:11px;}
  #roleIconGrid{grid-template-columns:repeat(auto-fill,minmax(46px,1fr));}
}
</style>

<?php if ($msg): ?>
<div style="background:<?= ($msg['type'] ?? '')==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;
     border:1px solid <?= ($msg['type'] ?? '')==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;
     color:<?= ($msg['type'] ?? '')==='success'?'#4ade80':'#f87171' ?>;
     padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;
     margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid <?= ($msg['type'] ?? '')==='success'?'fa-circle-check':'fa-circle-xmark' ?>"></i>
    <?= e($msg['text']) ?>
</div>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title">
            <i class="fa-solid fa-shield-halved" style="color:var(--accent);margin-right:8px;"></i>
            <?= __('aperm.title') ?>
        </span>
        <button onclick="openRoleModal('')" class="btn-admin btn-primary-admin">
            <i class="fa-solid fa-plus"></i> <?= __('aperm.role_new') ?>
        </button>
    </div>

    <div class="perm-tabs">
        <?php foreach ($roles as $slug => $r):
            $d = role_display($adminDb, $slug);
            $cnt = $roleCounts[$slug] ?? 0;
        ?>
        <button class="perm-tab <?= $slug===$activeRole?'active':'' ?>" data-role="<?= e($slug) ?>">
            <span style="display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:7px;background:<?= $d['color'] ?>1f;border:1px solid <?= $d['color'] ?>55;color:<?= $d['color'] ?>;font-size:12px;flex-shrink:0;">
                <?= cat_icon_html($d['icon'], 'width:14px;height:14px;object-fit:cover;border-radius:3px;') ?: '<i class="fa-solid fa-user"></i>' ?>
            </span>
            <span class="perm-tab-name"><?= e($d['name']) ?></span>
            <span class="perm-tab-count"><?= (int)$cnt ?></span>
            <?php if ((int)($r['is_system'] ?? 0) === 1): ?><i class="fa-solid fa-lock perm-tab-lock" title="<?= __('aperm.role_system') ?>"></i><?php endif; ?>
        </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ($roles as $slug => $r):
        $d = role_display($adminDb, $slug);
        $cnt = $roleCounts[$slug] ?? 0;
        $isAdmin = ($slug === 'admin' || $slug === 'superadmin');
        $isSystem = ((int)($r['is_system'] ?? 0) === 1);
    ?>
    <div class="perm-panel" data-role="<?= e($slug) ?>" style="display:<?= $slug===$activeRole?'block':'none' ?>;">
        <div class="perm-rolebar">
            <span style="display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:12px;background:<?= $d['color'] ?>1f;border:1px solid <?= $d['color'] ?>55;color:<?= $d['color'] ?>;font-size:18px;flex-shrink:0;">
                <?= cat_icon_html($d['icon'], 'width:24px;height:24px;object-fit:cover;border-radius:6px;') ?: '<i class="fa-solid fa-user"></i>' ?>
            </span>
            <div style="flex:1;min-width:0;">
                <div style="font-size:14px;font-weight:800;display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                    <?= e($d['name']) ?>
                    <?php if ($isSystem): ?><span class="badge badge-indigo"><i class="fa-solid fa-lock"></i> <?= __('aperm.role_system') ?></span><?php endif; ?>
                </div>
                <div style="font-size:11px;color:var(--muted);font-weight:600;"><?= e($slug) ?> · <?= (int)$cnt ?> <?= __('aperm.role_users') ?> · <?= __('aperm.role_rank') ?>: <?= (int)$d['rank'] ?></div>
            </div>
            <?php if (!$isAdmin): ?>
            <div style="display:flex;gap:8px;flex-shrink:0;">
                <button onclick='openRoleModal(<?= json_encode($slug, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>)' class="btn-admin btn-ghost-admin" style="font-size:12px;">
                    <i class="fa-solid fa-pen"></i> <?= __('aperm.role_edit') ?>
                </button>
                <?php if (!$isSystem): ?>
                <form method="POST" action="/action.php" onsubmit="return confirm(<?= json_encode(__('aperm.role_delete_confirm')) ?>);" style="margin:0;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="role_delete">
                    <input type="hidden" name="slug" value="<?= e($slug) ?>">
                    <button type="submit" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2);font-size:12px;">
                        <i class="fa-solid fa-trash"></i> <?= __('aperm.role_delete') ?>
                    </button>
                </form>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php if ($isAdmin): ?>
        <div style="background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.15);border-radius:12px;padding:16px;text-align:center;color:var(--muted);font-size:13px;font-weight:600;">
            <i class="fa-solid fa-lock" style="color:var(--accent);margin-right:6px;"></i>
            <?= __('aperm.admin_note') ?>
        </div>
        <?php else: ?>
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="role" value="<?= e($slug) ?>">
            <?php foreach (nx_resource_groups() as $gkey => $res): ?>
            <div style="font-size:11px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);margin:16px 0 8px;"><?= __('aperm.' . $gkey) ?></div>
            <div class="perm-grid">
                <?php foreach ($res as $key => $label): ?>
                <label class="perm-check">
                    <input type="checkbox" name="resources[]" value="<?= $key ?>"
                           <?= in_array($key, $permData[$slug] ?? [])?'checked':'' ?>
                           style="width:16px;height:16px;accent-color:var(--accent);flex-shrink:0;">
                    <span><?= $label ?></span>
                </label>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
            <button type="submit" name="save_permissions" class="btn-admin btn-primary-admin" style="margin-top:20px;">
                <i class="fa-solid fa-floppy-disk"></i> <?= __('aperm.save') ?>
            </button>
        </form>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>

<div id="roleModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:1000;align-items:center;justify-content:center;padding:16px;" onclick="if(event.target===this)closeRoleModal()">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;padding:24px;width:520px;max-width:100%;max-height:calc(100dvh - 32px);overflow-y:auto;animation:fadeSlideUp .25s ease;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
            <div style="font-size:15px;font-weight:800;" id="roleModalTitle"><?= __('aperm.role_new') ?></div>
            <button onclick="closeRoleModal()" style="background:none;border:none;color:var(--muted);font-size:18px;cursor:pointer;">&times;</button>
        </div>
        <form method="POST" action="/action.php">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="role_save">
            <input type="hidden" name="orig" id="roleOrig" value="">
            <div style="margin-bottom:14px;" id="roleSlugWrap">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aperm.role_slug') ?></label>
                <input type="text" name="slug" id="roleSlug" maxlength="30" placeholder="editor"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                <p style="font-size:11px;color:var(--muted);margin-top:5px;"><?= __('aperm.role_slug_hint') ?></p>
            </div>
            <div class="role-form-grid">
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aperm.role_name_tr') ?></label>
                    <input type="text" name="name_tr" id="roleNameTr" required maxlength="60"
                           style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                </div>
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aperm.role_name_en') ?></label>
                    <input type="text" name="name_en" id="roleNameEn" maxlength="60"
                           style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                </div>
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aperm.role_color') ?></label>
                    <div style="display:flex;gap:8px;align-items:center;">
                        <input type="color" name="color" id="roleColor" value="#818cf8"
                               style="width:44px;height:38px;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:4px;cursor:pointer;flex-shrink:0;">
                        <input type="text" id="roleColorHex" value="#818cf8" maxlength="7"
                               style="flex:1;min-width:0;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;font-family:monospace;">
                    </div>
                </div>
                <div id="roleRankWrap">
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aperm.role_rank') ?></label>
                    <input type="number" name="rank" id="roleRank" min="0" max="99" value="5"
                           style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <p style="font-size:11px;color:var(--muted);margin-top:5px;"><?= __('aperm.role_rank_hint') ?></p>
                </div>
            </div>
            <div style="margin:14px 0;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aperm.role_icon') ?></label>
                <div style="display:flex;gap:8px;align-items:center;margin-bottom:6px;">
                    <input type="text" name="icon" id="roleIconInput" maxlength="512" placeholder="fa-solid fa-star"
                           style="flex:1;min-width:0;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <span id="roleIconPreview" style="display:inline-flex;align-items:center;justify-content:center;width:38px;height:38px;border-radius:10px;background:var(--bg-surface);border:1px solid var(--border);font-size:18px;color:var(--accent);flex-shrink:0;overflow:hidden;"></span>
                </div>
                <p style="font-size:11px;color:var(--muted);margin:0 0 8px;"><?= __('aperm.role_icon_hint') ?></p>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    <button type="button" onclick="toggleRoleIconPicker()" class="btn-admin btn-ghost-admin" style="font-size:12px;">
                        <i class="fa-solid fa-icons"></i> <?= __('aperm.role_icon_pick') ?>
                    </button>
                    <label class="btn-admin btn-ghost-admin" style="font-size:12px;cursor:pointer;">
                        <i class="fa-solid fa-upload"></i> <?= __('aperm.role_icon_upload') ?>
                        <input type="file" id="roleIconFile" accept="image/png,image/jpeg,image/webp,image/gif" style="display:none;" onchange="uploadRoleIcon(this)">
                    </label>
                </div>
                <div id="roleIconStatus" style="font-size:12px;font-weight:700;margin-top:6px;"></div>
            </div>
            <div style="display:flex;gap:10px;">
                <button type="submit" class="btn-admin btn-primary-admin" style="flex:1;"><?= __('aperm.role_save') ?></button>
                <button type="button" onclick="closeRoleModal()" class="btn-admin btn-ghost-admin" style="flex:1;"><?= __('aperm.role_cancel') ?></button>
            </div>
        </form>
    </div>
</div>

<div id="roleIconPickerModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:1001;align-items:center;justify-content:center;padding:16px;" onclick="if(event.target===this)toggleRoleIconPicker(true)">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:560px;max-width:100%;max-height:calc(100dvh - 32px);display:flex;flex-direction:column;overflow:hidden;animation:fadeSlideUp .25s ease;">
        <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;gap:10px;align-items:center;">
            <input type="text" id="roleIconSearch" placeholder="<?= __('aperm.role_icon_search') ?>"
                   style="flex:1;min-width:0;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:9px 14px;color:var(--text);font-size:13px;outline:none;">
            <button onclick="toggleRoleIconPicker(true)" style="background:none;border:none;color:var(--muted);font-size:18px;cursor:pointer;flex-shrink:0;">&times;</button>
        </div>
        <div id="roleIconGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(52px,1fr));gap:8px;padding:18px;overflow-y:auto;"></div>
    </div>
</div>

<script>
var _roleData = <?= json_encode($roles, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var _roleIcons = <?= json_encode($roleIcons, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
(function(){
    var tabs = document.querySelectorAll('.perm-tab');
    var panels = document.querySelectorAll('.perm-panel');
    tabs.forEach(function(tab){
        tab.addEventListener('click', function(){
            var role = this.getAttribute('data-role');
            tabs.forEach(function(t){ t.classList.remove('active'); });
            this.classList.add('active');
            panels.forEach(function(p){ p.style.display = p.getAttribute('data-role') === role ? 'block' : 'none'; });
        });
    });
    var rc = document.getElementById('roleColor');
    var rh = document.getElementById('roleColorHex');
    if (rc && rh) {
        rc.addEventListener('input', function(){ rh.value = rc.value; });
        rh.addEventListener('input', function(){ if (/^#[0-9a-fA-F]{6}$/.test(rh.value)) rc.value = rh.value; });
    }
    var ri = document.getElementById('roleIconInput');
    if (ri) ri.addEventListener('input', function(){ roleIconPreview(); });
    var rs = document.getElementById('roleIconSearch');
    if (rs) rs.addEventListener('input', function(){ renderRoleIcons(this.value); });
})();
function roleIconIsUrl(v){ return /^(https?:\/\/|\/|data:image\/)/i.test((v||'').trim()); }
function roleIconPreview(){
    var inp = document.getElementById('roleIconInput');
    var pre = document.getElementById('roleIconPreview');
    if (!inp || !pre) return;
    var v = inp.value.trim();
    if (!v) { pre.innerHTML = ''; return; }
    var safe = v.replace(/"/g, '');
    pre.innerHTML = roleIconIsUrl(v) ? '<img src="'+safe+'" style="width:100%;height:100%;object-fit:cover;" alt="">' : '<i class="'+safe+'"></i>';
}
function renderRoleIcons(query){
    var grid = document.getElementById('roleIconGrid');
    if (!grid) return;
    var q = (query || '').toLowerCase().trim();
    var cur = document.getElementById('roleIconInput').value.trim();
    var html = '';
    _roleIcons.forEach(function(c){
        if (q && c.toLowerCase().indexOf(q) === -1) return;
        html += '<div class="role-icn' + (cur === c ? ' active' : '') + '" data-class="' + c + '" onclick="pickRoleIcon(this)"><i class="' + c + '"></i></div>';
    });
    grid.innerHTML = html || '<p style="grid-column:1/-1;text-align:center;color:var(--muted);font-size:12px;padding:16px;">—</p>';
}
function toggleRoleIconPicker(forceClose){
    var m = document.getElementById('roleIconPickerModal');
    if (!m) return;
    var open = m.style.display === 'flex';
    if (open || forceClose === true) { m.style.display = 'none'; return; }
    renderRoleIcons('');
    var s = document.getElementById('roleIconSearch');
    if (s) { s.value = ''; setTimeout(function(){ s.focus(); }, 50); }
    m.style.display = 'flex';
}
function pickRoleIcon(el){
    document.getElementById('roleIconInput').value = el.getAttribute('data-class');
    roleIconPreview();
    toggleRoleIconPicker(true);
}
function uploadRoleIcon(fileInput){
    var f = fileInput.files ? fileInput.files[0] : null;
    fileInput.value = '';
    var st = document.getElementById('roleIconStatus');
    function msg(t, ok){ if (st) { st.textContent = t; st.style.color = ok ? '#4ade80' : '#f87171'; } }
    if (!f) return;
    if (!/image\/(png|jpeg|webp|gif)/.test(f.type || '')) { msg(<?= json_encode(__('aperm.role_bad_image')) ?>, false); return; }
    if (f.size > 8388608) { msg(<?= json_encode(__('aperm.role_bad_image')) ?>, false); return; }
    msg('...', true);
    var fd = new FormData();
    fd.append('action', 'asset_upload'); fd.append('ctx', 'roles'); fd.append('asset_type', 'roleicon'); fd.append('file', f);
    fetch('/action.php', {method:'POST', body:fd}).then(function(r){ return r.json(); }).then(function(d){
        if (d && d.ok && d.url) {
            document.getElementById('roleIconInput').value = d.url;
            roleIconPreview();
            msg(d.msg || 'OK', true);
        } else { msg((d && d.msg) || 'ERR', false); }
    }).catch(function(){ msg('ERR', false); });
}
function openRoleModal(slug){
    var r = (slug && _roleData[slug]) ? _roleData[slug] : null;
    document.getElementById('roleOrig').value = r ? slug : '';
    document.getElementById('roleSlug').value = r ? slug : '';
    document.getElementById('roleSlugWrap').style.display = r ? 'none' : 'block';
    document.getElementById('roleNameTr').value = r ? (r.name_tr || '') : '';
    document.getElementById('roleNameEn').value = r ? (r.name_en || '') : '';
    document.getElementById('roleColor').value = (r && /^#[0-9a-fA-F]{6}$/.test(r.color || '')) ? r.color : '#818cf8';
    document.getElementById('roleColorHex').value = document.getElementById('roleColor').value;
    document.getElementById('roleIconInput').value = r ? (r.icon || '') : '';
    roleIconPreview();
    var sys = r && parseInt(r.is_system || 0, 10) === 1;
    document.getElementById('roleRank').value = r ? (r.rank || 0) : 5;
    document.getElementById('roleRank').disabled = !!sys;
    document.getElementById('roleModalTitle').textContent = r ? <?= json_encode(__('aperm.role_edit')) ?> : <?= json_encode(__('aperm.role_new')) ?>;
    document.getElementById('roleIconStatus').textContent = '';
    document.getElementById('roleModal').style.display = 'flex';
}
function closeRoleModal(){
    document.getElementById('roleModal').style.display = 'none';
}
</script>
<?php include __DIR__ . '/includes/layout-end.php'; ?>
