<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('apedit.title');
$activePage = 'products';

$editId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$editProduct = null;
if ($editId) {
    $ep = $adminDb->prepare('SELECT * FROM products WHERE id=?');
    $ep->execute([$editId]);
    $editProduct = $ep->fetch() ?: null;
}

$categories = [];
try { $categories = $adminDb->query('SELECT name FROM categories ORDER BY sort_order ASC, name ASC')->fetchAll(PDO::FETCH_COLUMN); } catch (Exception $e) {}

$descForEditor = $editProduct['description'] ?? '';
$currentImage = $editProduct['image_url'] ?? '';

ob_start();
?>
<style>
.pe-shell{display:flex;flex-direction:column;min-height:calc(100vh - 104px);}
.pe-top{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:0 4px 18px;flex-wrap:wrap;}
.pe-back{display:inline-flex;align-items:center;gap:7px;color:var(--muted);font-size:13px;font-weight:700;text-decoration:none;padding:8px 13px;border-radius:10px;background:var(--bg-surface);border:1px solid var(--border);transition:color .15s,border-color .15s,transform .15s;font-family:inherit;}
.pe-back:hover{color:var(--text);border-color:var(--accent);transform:translateX(-2px);}
.pe-editinfo{font-size:12px;color:var(--muted);background:var(--bg-surface);border:1px solid var(--border);padding:7px 14px;border-radius:10px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:60%;}
.pe-editinfo b{color:var(--text);font-weight:800;}
.pe-editinfo .st{font-weight:800;margin-left:6px;}
.pe-stepper{display:flex;align-items:flex-start;padding:6px 4px 2px;position:relative;user-select:none;}
.pe-track{position:absolute;top:24px;left:16.66%;right:16.66%;height:3px;background:var(--border);border-radius:3px;overflow:hidden;}
.pe-track-fill{height:100%;width:0%;background:var(--accent);border-radius:3px;transition:width .45s cubic-bezier(.4,0,.2,1);}
.pe-step{flex:1;display:flex;flex-direction:column;align-items:center;gap:8px;cursor:pointer;position:relative;z-index:1;background:transparent;border:none;font-family:inherit;padding:0;outline:none;}
.pe-dot{width:46px;height:46px;border-radius:50%;background:var(--bg-surface);border:3px solid var(--border);color:var(--muted);display:flex;align-items:center;justify-content:center;font-size:17px;transition:all .3s cubic-bezier(.34,1.56,.64,1);}
.pe-step.active .pe-dot{border-color:var(--accent);color:var(--accent);box-shadow:0 0 0 5px rgba(var(--accent-rgb,99,102,241),.12),0 6px 18px rgba(var(--accent-rgb,99,102,241),.25);transform:translateY(-2px);}
.pe-step.done .pe-dot{background:var(--accent);border-color:var(--accent);color:#fff;}
.pe-step-name{font-size:11px;font-weight:700;color:var(--muted);letter-spacing:.2px;transition:color .2s;}
.pe-step.active .pe-step-name,.pe-step.done .pe-step-name{color:var(--text);}
.pe-panel{display:none;}
.pe-panel.active{display:block;animation:peFade .35s ease;}
@keyframes peFade{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
.pe-card{background:var(--bg-card);border:1px solid var(--border);border-radius:18px;padding:22px 24px;margin-top:16px;box-shadow:0 8px 30px rgba(0,0,0,.22);}
.pe-card h3{font-size:15px;font-weight:900;margin-bottom:4px;display:flex;align-items:center;gap:8px;}
.pe-card h3 i{color:var(--accent);}
.pe-card .sub{font-size:12px;color:var(--muted);margin-bottom:18px;}
.pe-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.pe-grid .full{grid-column:1/-1;}
.pe-label{display:flex;align-items:center;gap:6px;font-size:11px;font-weight:800;color:var(--muted);margin-bottom:7px;letter-spacing:.3px;text-transform:uppercase;}
.pe-label i{color:var(--accent);font-size:12px;}
.pe-label .req{color:#f87171;}
.pe-ai-btn{margin-left:auto;display:inline-flex;align-items:center;gap:6px;background:linear-gradient(135deg,var(--accent),#7c3aed);color:#fff;border:none;border-radius:8px;padding:5px 12px;font-size:11px;font-weight:900;cursor:pointer;font-family:inherit;}
.pe-ai-btn i{color:#fff;font-size:11px;}
.pe-input{width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:11px;padding:11px 14px;color:var(--text);font-size:14px;outline:none;font-family:inherit;transition:background-color .2s ease,border-color .2s ease,box-shadow .2s ease,color .2s ease;}
.pe-input:focus{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent);}
.pe-input::placeholder{color:var(--dim);}
.pe-sel-wrap{position:relative;}
.pe-select{width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:11px;padding:11px 38px 11px 14px;color:var(--text);font-size:14px;outline:none;font-family:inherit;appearance:none;-webkit-appearance:none;cursor:pointer;transition:background-color .2s ease,border-color .2s ease,box-shadow .2s ease,color .2s ease;}
.pe-select:focus{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent);}
.pe-select option{background:var(--bg-surface);color:var(--text);}
.pe-sel-wrap .pe-chev{position:absolute;right:14px;top:50%;transform:translateY(-50%);font-size:11px;color:var(--muted);pointer-events:none;}
.pe-footer{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:22px;flex-wrap:wrap;position:sticky;bottom:0;background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:14px 18px;z-index:50;box-shadow:0 -8px 30px rgba(0,0,0,.25);}
.pe-btn{border:none;border-radius:11px;padding:11px 20px;font-size:13px;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;gap:7px;transition:transform .05s,box-shadow .05s,filter .15s;font-family:inherit;}
.pe-btn:active{transform:translateY(2px);}
.pe-btn-next{background:var(--accent);color:#fff;box-shadow:0 4px 0 var(--accent-dark),0 8px 18px rgba(var(--accent-rgb,99,102,241),.25);}
.pe-btn-next:hover{filter:brightness(1.08);}
.pe-btn-prev{background:var(--bg-surface);color:var(--muted);border:1px solid var(--border);}
.pe-btn-prev:hover{color:var(--text);border-color:var(--accent);}
.pe-stock-ops{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.pe-stock-ops .pe-btn{padding:9px 16px;box-shadow:none;}
.pe-btn-stock-add{background:rgba(16,185,129,.12);color:#34d399;border:1px solid rgba(16,185,129,.28);}
.pe-btn-stock-add:hover{background:rgba(16,185,129,.22);}
.pe-btn-stock-sub{background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.24);}
.pe-btn-stock-sub:hover{background:rgba(239,68,68,.2);}
.pe-stock-op-fb{font-size:12px;font-weight:700;color:#34d399;}
.pe-stock-op-fb.err{color:#f87171;}
.pe-stock-op-fb.ok{color:#34d399;}
.pe-actions{display:none;}
.pe-actions.show{display:flex;gap:8px;flex-wrap:wrap;}
.pe-navs{display:flex;gap:8px;flex-wrap:wrap;}
.pe-hint{font-size:11px;color:var(--dim);margin-top:5px;display:flex;align-items:center;gap:5px;}
.pe-cover-btn{display:flex;align-items:center;gap:10px;width:100%;background:var(--bg-surface);border:1px dashed var(--border);border-radius:12px;padding:12px 14px;cursor:pointer;font-family:inherit;color:var(--text);text-align:left;transition:background-color .2s ease,border-color .2s ease,color .2s ease;}
.pe-cover-btn:hover{border-color:var(--accent);background:rgba(var(--accent-rgb,99,102,241),.04);}
.pe-cover-thumb{width:74px;height:44px;border-radius:8px;object-fit:cover;flex-shrink:0;border:1px solid var(--border);}
.pe-cover-ph{width:74px;height:44px;border-radius:8px;flex-shrink:0;background:var(--bg-surface);display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:16px;border:1px solid var(--border);}
.pe-cover-txt{flex:1;min-width:0;}
.pe-cover-txt .t{font-size:13px;font-weight:800;}
.pe-cover-txt .s{font-size:11px;color:var(--muted);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.pe-cover-btn i.fa-chevron-right{color:var(--muted);font-size:11px;flex-shrink:0;}
.pe-acc{border:1px solid var(--border);border-radius:13px;overflow:hidden;background:var(--bg-card);}
.pe-acc-head{width:100%;display:flex;align-items:center;gap:10px;background:var(--bg-surface);border:none;padding:13px 16px;cursor:pointer;font-family:inherit;color:var(--text);font-size:13px;font-weight:800;text-align:left;transition:background .15s;}
.pe-acc-head:hover{background:var(--bg-hover);}
.pe-acc-head .chev{margin-left:auto;font-size:11px;color:var(--muted);transition:transform .25s;}
.pe-acc.open .pe-acc-head .chev{transform:rotate(180deg);}
.pe-acc-body{display:none;padding:16px;border-top:1px solid var(--border);}
.pe-acc.open .pe-acc-body{display:block;animation:peFade .25s ease;}
.pe-tabs{display:flex;gap:0;margin-bottom:14px;border-bottom:1px solid var(--border);}
.pe-tab{padding:8px 16px;font-size:12px;font-weight:800;color:var(--muted);cursor:pointer;border:none;background:none;font-family:inherit;border-bottom:2px solid transparent;transition:color .15s,border-color .15s;}
.pe-tab:hover{color:var(--text);}
.pe-tab.active{color:var(--accent);border-bottom-color:var(--accent);}
.pe-pane{display:none;}
.pe-pane.active{display:block;}
.pe-file-label{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:800;color:var(--muted);margin-bottom:7px;text-transform:uppercase;letter-spacing:.3px;}
.pe-file-label i{color:var(--accent);}
.pe-file-input{width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:11px;padding:9px 12px;color:var(--text);font-size:12px;outline:none;font-family:inherit;cursor:pointer;}
.pe-file-input::-webkit-file-upload-button{background:var(--bg-surface);border:1px solid var(--border);color:var(--text);border-radius:7px;padding:6px 12px;font-size:12px;font-weight:700;cursor:pointer;margin-right:10px;font-family:inherit;}
.pe-status{display:flex;align-items:center;gap:5px;font-size:11px;font-weight:700;margin-top:6px;}
.pe-status.ok{color:#4ade80;}
.pe-status.bad{color:#f87171;}
.pe-modal{display:none;position:fixed;inset:0;z-index:9999;align-items:center;justify-content:center;padding:16px;}
.pe-modal.show{display:flex;}
.pe-modal-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.65);backdrop-filter:blur(4px);}
.pe-modal-box{position:relative;background:var(--bg-card);border:1px solid var(--border);border-radius:18px;width:100%;max-width:500px;box-shadow:0 24px 64px rgba(0,0,0,.5);animation:peModalIn .25s ease;max-height:90vh;overflow-y:auto;}
@keyframes peModalIn{from{opacity:0;transform:translateY(12px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}
.pe-modal-head{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--border);}
.pe-modal-head h3{font-size:15px;font-weight:900;display:flex;align-items:center;gap:8px;}
.pe-modal-head h3 i{color:var(--accent);}
.pe-modal-head button{background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer;font-family:inherit;}
.pe-mtabs{display:flex;border-bottom:1px solid var(--border);}
.pe-mtab{flex:1;padding:12px;text-align:center;font-size:13px;font-weight:800;background:transparent;border:none;cursor:pointer;font-family:inherit;color:var(--muted);border-bottom:2px solid transparent;transition:color .15s,border-color .15s;}
.pe-mtab.active{color:var(--accent);border-bottom-color:var(--accent);background:rgba(var(--accent-rgb,99,102,241),.06);}
.pe-mpane{padding:20px;}
.pe-drop{background:var(--bg-surface);border:2px dashed var(--border);border-radius:13px;padding:30px;text-align:center;cursor:pointer;transition:border-color .2s ease,background-color .2s ease;}
.pe-drop.over{border-color:var(--accent);background:rgba(var(--accent-rgb,99,102,241),.05);}
.pe-drop i.fa-cloud-arrow-up{font-size:32px;color:var(--dim);display:block;margin-bottom:10px;}
.pe-drop p{font-size:13px;color:var(--muted);font-weight:700;margin-bottom:4px;}
.pe-drop small{font-size:11px;color:var(--dim);}
.pe-preview-area{display:none;}
.pe-preview-area img{max-height:130px;max-width:100%;object-fit:contain;border-radius:9px;margin:0 auto;display:block;border:1px solid var(--border);}
.pe-msg{margin-top:10px;padding:9px 12px;border-radius:9px;font-size:12px;font-weight:700;display:none;}
.pe-msg.show{display:flex;align-items:center;gap:6px;}
.pe-msg.ok{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#4ade80;}
.pe-msg.bad{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#f87171;}
.pe-upload-btn{display:none!important;width:100%;justify-content:center;margin-top:12px;}
.pe-upload-btn.show{display:inline-flex!important;}
.pe-link-row{display:flex;gap:8px;}
.pe-link-row input{flex:1;background:var(--bg-surface);border:1px solid var(--border);border-radius:11px;padding:11px 14px;color:var(--text);font-size:13px;outline:none;font-family:inherit;transition:background-color .2s ease,border-color .2s ease,color .2s ease;}
.pe-link-row input:focus{border-color:var(--accent);}
.ed-wrap{border-radius:12px;}
.ed-tb{border-radius:12px 12px 0 0;}
.pe-error{border-color:rgba(239,68,68,.6)!important;}
@media(max-width:720px){
  .pe-grid{grid-template-columns:1fr;}
  .pe-dot{width:40px;height:40px;font-size:15px;}
  .pe-track{top:21px;}
  .pe-card{padding:16px;}
  .pe-footer{padding:12px;}
  .pe-top{padding-bottom:14px;}
  .pe-editinfo{max-width:100%;}
  .pe-step-name{font-size:10px;}
}
@media(max-width:560px){
  .pe-card{padding:14px;border-radius:14px;}
  .pe-card h3{font-size:14px;}
  .pe-drop{padding:18px 12px;}
  .pe-drop i.fa-cloud-arrow-up{font-size:24px;}
  .pe-drop p{font-size:12px;}
  .pe-preview-area img{max-height:96px;}
  .pe-cover-btn{padding:10px;gap:8px;}
  .pe-cover-thumb,.pe-cover-ph{width:56px;height:34px;}
  .pe-cover-txt .t{font-size:12px;}
  .pe-file-input{font-size:11px;padding:8px 10px;}
  .pe-link-row{flex-direction:column;}
  .pe-link-row .btn-admin{justify-content:center;}
  .pe-mpane{padding:14px;}
  .pe-tabs{overflow-x:auto;}
  .pe-tab{white-space:nowrap;}
  .pe-mtab{font-size:12px;padding:10px 6px;}
  .pe-modal{padding:10px;}
  .pe-modal-box{border-radius:14px;}
  .pe-footer{flex-direction:column;align-items:stretch;}
  .pe-actions.show{width:100%;}
  .pe-actions.show .btn-admin{flex:1;justify-content:center;padding:12px;}
  .pe-navs{width:100%;}
  .pe-navs .pe-btn{flex:1;justify-content:center;}
  .pe-acc-head{font-size:12px;padding:11px 12px;}
}
</style>
<?php
$extraHead = ob_get_clean();
require_once __DIR__ . '/../core/editor.php';
include __DIR__ . '/includes/layout.php';
?>
<style>@media(max-width:640px){#peCvGrid{grid-template-columns:1fr!important;}}</style>

<div class="pe-shell">
    <div class="pe-top">
        <a href="/admin/products.php" class="pe-back">
            <i class="fa-solid fa-arrow-left"></i> <?= __('apedit.back') ?>
        </a>
        <?php if ($editProduct): ?>
        <span class="pe-editinfo">
            <i class="fa-regular fa-pen-to-square" style="margin-right:5px;"></i> <?= __('apedit.editing') ?> <b><?= e($editProduct['name']) ?></b>
            <span class="st" style="color:<?= $editProduct['status']==='active'?'#4ade80':($editProduct['status']==='hidden'?'#f87171':'#94a3b8') ?>;">
                (<?= $editProduct['status']==='active'?__('apedit.status_live'):($editProduct['status']==='hidden'?__('adash.status_hidden'):__('adash.status_draft')) ?>)
            </span>
        </span>
        <?php else: ?>
        <span class="pe-editinfo">
            <i class="fa-solid fa-plus" style="color:var(--accent);margin-right:5px;"></i> <?= __('apedit.new_product') ?>
        </span>
        <?php endif; ?>
    </div>

    <form method="POST" action="/action.php" enctype="multipart/form-data" id="productEditorForm">
        <input type="hidden" name="action" value="product_save">
        <?= csrf_field() ?>
        <input type="hidden" name="status" id="productStatus" value="<?= $editProduct['status'] ?? 'draft' ?>">
        <input type="hidden" name="cv_version" id="peCvVersionHidden" value="">
        <input type="hidden" name="cv_summary" id="peCvSummaryHidden" value="">
        <input type="hidden" name="cv_notify" id="peCvNotifyHidden" value="1">
        <input type="hidden" name="image_url" id="peImageUrl" value="<?= e($currentImage) ?>">
        <?php if ($editProduct): ?>
        <input type="hidden" name="id" value="<?= $editId ?>">
        <?php endif; ?>

        <div class="pe-stepper">
            <div class="pe-track"><div class="pe-track-fill" id="peTrackFill"></div></div>
            <button type="button" class="pe-step active" data-step="1" onclick="peGo(1)">
                <div class="pe-dot" id="peDot1"><i class="fa-solid fa-cube"></i></div>
                <span class="pe-step-name" id="peName1"><?= __('apedit.step1') ?></span>
            </button>
            <button type="button" class="pe-step" data-step="2" onclick="peGo(2)">
                <div class="pe-dot" id="peDot2"><i class="fa-solid fa-tags"></i></div>
                <span class="pe-step-name" id="peName2"><?= __('apedit.step2') ?></span>
            </button>
            <button type="button" class="pe-step" data-step="3" onclick="peGo(3)">
                <div class="pe-dot" id="peDot3"><i class="fa-solid fa-box-open"></i></div>
                <span class="pe-step-name" id="peName3"><?= __('apedit.step3') ?></span>
            </button>
        </div>

        <div id="pePanel1" class="pe-panel active">
            <div class="pe-card">
                <h3><i class="fa-solid fa-cube"></i> <?= __('apedit.step1') ?></h3>
                <div class="sub"><?= __('apedit.basic_sub') ?></div>
                <div class="pe-grid">
                    <div class="full">
                        <label class="pe-label"><i class="fa-solid fa-heading"></i><?= __('apedit.name_label') ?> <span class="req">*</span></label>
                        <input type="text" name="name" id="peName" required maxlength="120" class="pe-input" placeholder="<?= __('apedit.name_ph') ?>" value="<?= e($editProduct['name'] ?? '') ?>" autofocus>
                    </div>
                    <div class="full">
                        <label class="pe-label"><i class="fa-solid fa-quote-right"></i><?= __('aprod.short_label') ?></label>
                        <input type="text" name="short_description" maxlength="300" class="pe-input" placeholder="<?= __('apedit.short_ph') ?>" value="<?= e($editProduct['short_description'] ?? '') ?>">
                    </div>
                    <div class="full">
                        <label class="pe-label"><i class="fa-solid fa-layer-group"></i><?= __('adash.th_category') ?></label>
                        <div class="pe-sel-wrap">
                            <select name="category" id="peCategory" class="pe-select">
                                <option value=""><?= __('aprod.not_selected') ?></option>
                                <?php foreach ($categories as $cn): ?>
                                <option value="<?= e($cn) ?>" <?= ($editProduct['category']??'')===$cn?'selected':'' ?>><?= e($cn) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <i class="fa-solid fa-chevron-down pe-chev"></i>
                        </div>
                    </div>
                    <div>
                        <label class="pe-label"><i class="fa-solid fa-code-branch"></i><?= __('aprod.version_label') ?></label>
                        <input type="text" name="version" id="peVersionInput" maxlength="20" class="pe-input" placeholder="1.0.0" value="<?= e($editProduct['version'] ?? '1.0.0') ?>">
                    </div>
                    <div>
                        <label class="pe-label"><i class="fa-solid fa-key"></i><?= __('aprod.prefix_label') ?></label>
                        <input type="text" name="license_prefix" maxlength="20" class="pe-input" style="text-transform:uppercase;" placeholder="<?= __('apedit.prefix_ph') ?>" value="<?= e($editProduct['license_prefix'] ?? '') ?>">
                    </div>
                </div>
            </div>
        </div>

        <div id="pePanel2" class="pe-panel">
            <div class="pe-card">
                <h3><i class="fa-solid fa-tags"></i> <?= __('apedit.step2') ?></h3>
                <div class="sub"><?= __('apedit.details_sub') ?></div>
                <div class="pe-grid">
                    <div>
                        <label class="pe-label"><i class="fa-solid fa-turkish-lira-sign"></i><?= __('aprod.price_plain') ?> <span class="req">*</span></label>
                        <input type="number" name="price" id="pePrice" step="0.01" min="0" class="pe-input" placeholder="0.00" value="<?= $editProduct ? number_format((float)$editProduct['price'],2,'.','') : '0' ?>">
                        <div id="peNetPrice" style="font-size:11px;color:var(--muted);margin-top:5px;display:none"></div>
                    </div>
                    <div>
                        <label class="pe-label"><i class="fa-solid fa-percent"></i><?= __('apedit.discount') ?></label>
                        <input type="number" name="discount_percent" id="peDiscount" min="0" max="90" step="1" class="pe-input" placeholder="0" value="<?= (int)($editProduct['discount_percent'] ?? 0) ?>">
                    </div>
                    <div>
                        <label class="pe-label"><i class="fa-solid fa-toggle-on"></i><?= __('adash.th_status') ?></label>
                        <div class="pe-sel-wrap">
                            <select name="pe_status_view" id="peStatusView" class="pe-select">
                                <option value="active" <?= ($editProduct['status']??'draft')==='active'?'selected':'' ?>><?= __('apedit.status_active_opt') ?></option>
                                <option value="draft" <?= ($editProduct['status']??'draft')==='draft'?'selected':'' ?>><?= __('adash.status_draft') ?></option>
                                <option value="hidden" <?= ($editProduct['status']??'draft')==='hidden'?'selected':'' ?>><?= __('adash.status_hidden') ?></option>
                            </select>
                            <i class="fa-solid fa-chevron-down pe-chev"></i>
                        </div>
                    </div>
                    <div class="full">
                        <label class="pe-label"><i class="fa-solid fa-circle-info"></i><?= __('panel.buyer_note') ?> <span class="hint-note"><?= __('apedit.optional') ?></span></label>
                        <textarea name="user_notice" rows="3" class="pe-input" maxlength="1000" style="resize:vertical;min-height:84px;" placeholder="<?= __('apedit.notice_ph') ?>"><?= e($editProduct['user_notice'] ?? '') ?></textarea>
                        <p class="pe-hint"><i class="fa-solid fa-circle-info"></i> <?= __('apedit.notice_hint') ?></p>
                    </div>
                </div>
            </div>

        </div>

        <div id="pePanel3" class="pe-panel">
            <div class="pe-card">
                <h3><i class="fa-solid fa-box-open"></i> <?= __('apedit.step3') ?></h3>
                <div class="sub"><?= __('apedit.media_sub') ?></div>
                <div class="pe-grid">
                    <div class="full">
                        <label class="pe-label"><i class="fa-solid fa-image"></i><?= __('apedit.cover_label') ?></label>
                        <button type="button" class="pe-cover-btn" onclick="peOpenImageModal()">
                            <span class="pe-cover-ph" id="peCoverPh"><i class="fa-solid fa-image"></i></span>
                            <img src="" alt="" class="pe-cover-thumb" id="peCoverThumb" style="display:none;">
                            <span class="pe-cover-txt">
                                <span class="t" id="peCoverLabel"><?= __('apedit.cover_upload') ?></span>
                                <span class="s" id="peCoverSub"><?= __('apedit.cover_hint') ?></span>
                            </span>
                            <i class="fa-solid fa-chevron-right"></i>
                        </button>
                    </div>
                    <div class="full">
                        <label class="pe-label"><i class="fa-solid fa-pen-to-square"></i><?= __('aprod.detail_desc_label') ?>
                            <button type="button" class="pe-ai-btn" onclick="peAiDesc()"><i class="fa-solid fa-wand-magic-sparkles"></i> AI</button>
                        </label>
                        <div id="peDescWrap">
                        <?php render_editor('peDescription', $descForEditor, '280px', 'description'); ?>
                        </div>
                    </div>
                    <div class="full">
                        <label class="pe-label"><i class="fa-solid fa-file-arrow-down"></i><?= __('apedit.delivery_title') ?></label>
                        <div class="pe-acc" id="peAcc">
                            <button type="button" class="pe-acc-head" onclick="peToggleAcc()">
                                <i class="fa-solid fa-file-arrow-down" style="color:var(--accent);"></i>
                                <?= __('apedit.acc_title') ?>
                                <i class="fa-solid fa-chevron-down chev"></i>
                            </button>
                            <div class="pe-acc-body">
                                <div class="pe-tabs">
                                    <button type="button" class="pe-tab active" onclick="peTab(this,'pePaneFile')"><i class="fa-solid fa-file"></i> <?= __('apedit.tab_file') ?></button>
                                    <button type="button" class="pe-tab" onclick="peTab(this,'pePaneLink')"><i class="fa-solid fa-link"></i> <?= __('apedit.tab_link') ?></button>
                                </div>
                                <div id="pePaneFile" class="pe-pane active">
                                    <label class="pe-file-label"><i class="fa-solid fa-file"></i><?= __('apedit.file_label') ?></label>
                                    <input type="hidden" name="MAX_FILE_SIZE" value="33554432">
                                    <input type="file" name="product_file" id="peProductFile" class="pe-file-input" data-max-size="33554432">
                                    <?php if (!empty($editProduct['file_path'])): ?>
                                    <div class="pe-status ok"><i class="fa-solid fa-circle-check"></i> <?= __('apedit.current') ?> <?= e(basename($editProduct['file_path'])) ?></div>
                                    <?php endif; ?>
                                </div>
                                <div id="pePaneLink" class="pe-pane">
                                    <label class="pe-file-label"><i class="fa-solid fa-link"></i><?= __('apedit.tab_link') ?></label>
                                    <input type="url" name="download_link" id="peDownloadLink" class="pe-input" placeholder="https://" value="<?= e($editProduct['download_link'] ?? '') ?>">
                                    <p class="pe-hint"><i class="fa-solid fa-circle-info"></i> <?= __('apedit.link_hint') ?></p>
                                </div>
                                <div style="margin-top:14px;padding-top:14px;border-top:1px solid var(--border);">
                                    <label class="pe-file-label"><i class="fa-solid fa-file-lines"></i><?= __('apedit.delivery_text') ?></label>
                                    <textarea name="digital_file" id="peDigitalFile" rows="3" class="pe-input" style="resize:vertical;font-family:monospace;font-size:12px;" placeholder="<?= __('apedit.delivery_ph') ?>"><?= e($editProduct['digital_file'] ?? '') ?></textarea>
                                    <p class="pe-hint"><i class="fa-solid fa-circle-info"></i> <?= __('apedit.delivery_hint') ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="pe-footer">
            <button type="button" class="pe-btn pe-btn-prev" id="pePrevBtn" onclick="peGo(_peStep - 1)" style="display:none;">
                <i class="fa-solid fa-arrow-left"></i> <?= __('aprod.back') ?>
            </button>
            <div class="pe-actions" id="peActions">
                <button type="button" onclick="peOpenPublish()" class="btn-admin btn-primary-admin" style="flex:1;justify-content:center;padding:12px 20px;"><i class="fa-solid fa-rocket"></i> <?= __('apedit.publish_btn') ?></button>
            </div>
            <div class="pe-navs">
                <button type="button" class="pe-btn pe-btn-next" id="peNextBtn" onclick="peGo(_peStep + 1)"><?= __('aprod.continue') ?> <i class="fa-solid fa-arrow-right"></i></button>
            </div>
        </div>
    </form>
</div>

<div id="pePublishModal" class="pe-modal">
    <div class="pe-modal-backdrop" onclick="peClosePublish()"></div>
    <div class="pe-modal-box" style="max-width:680px;width:min(680px,calc(100vw - 32px));">
        <div class="pe-modal-head">
            <h3><i class="fa-solid fa-rocket"></i> <?= __('apedit.publish_title') ?></h3>
            <button type="button" onclick="peClosePublish()"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div style="padding:20px;">
            <div style="display:grid;grid-template-columns:180px 1fr;gap:12px;margin-bottom:14px;" id="peCvGrid">
                <div>
                    <label class="pe-label"><i class="fa-solid fa-code-branch"></i><?= __('apedit.version_label') ?> <span style="color:var(--dim);font-weight:500;text-transform:none;"><?= __('apedit.optional') ?></span></label>
                    <input type="text" id="peCvVersion" maxlength="20" class="pe-input" placeholder="1.0.1">
                </div>
                <div>
                    <label class="pe-label"><i class="fa-solid fa-bolt"></i><?= __('apedit.short_note') ?></label>
                    <input type="text" id="peCvSummary" maxlength="255" class="pe-input" placeholder="<?= __('apedit.cv_summary_ph') ?>">
                </div>
            </div>
            <div style="margin-bottom:14px;">
                <label class="pe-label"><i class="fa-solid fa-pen-to-square"></i><?= __('aprod.detail_desc_label') ?></label>
                <?php render_editor('peCvBody', '', '220px', 'cv_body'); ?>
            </div>
            <label style="display:flex;align-items:flex-start;gap:8px;cursor:pointer;font-size:12px;font-weight:600;color:var(--text);background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 12px;">
                <input type="checkbox" id="peCvNotify" checked style="width:16px;height:16px;accent-color:var(--accent);margin-top:1px;flex-shrink:0;">
                <span><?= __('apedit.cv_notify_main') ?> <span style="color:var(--muted);font-weight:500;"><?= __('apedit.cv_notify_hint') ?></span></span>
            </label>
        </div>
        <div style="display:flex;gap:8px;padding:14px 20px;border-top:1px solid var(--border);flex-wrap:wrap;">
            <button type="button" onclick="peClosePublish()" class="btn-admin btn-ghost-admin" style="flex:1;justify-content:center;min-width:110px;"><?= __('buy.cancel') ?></button>
            <button type="button" onclick="peConfirmPublish()" class="btn-admin btn-primary-admin" style="flex:1;justify-content:center;min-width:130px;"><i class="fa-solid fa-rocket"></i> <?= __('apedit.publish_btn') ?></button>
        </div>
    </div>
</div>

<div id="peImageModal" class="pe-modal">
    <div class="pe-modal-backdrop" onclick="peCloseImageModal()"></div>
    <div class="pe-modal-box">
        <div class="pe-modal-head">
            <h3><i class="fa-solid fa-image"></i> <?= __('apedit.cover_label') ?></h3>
            <button type="button" onclick="peCloseImageModal()"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="pe-mtabs">
            <button type="button" class="pe-mtab active" data-ptab="upload" onclick="peSwitchMtab('upload')"><i class="fa-solid fa-cloud-arrow-up"></i> <?= __('apedit.tab_file') ?></button>
            <button type="button" class="pe-mtab" data-ptab="link" onclick="peSwitchMtab('link')"><i class="fa-solid fa-link"></i> Link</button>
        </div>
        <div id="peMtabUpload" class="pe-mpane">
            <div class="pe-drop" id="peDropZone">
                <input type="file" id="peFileInput" accept="image/jpeg,image/png,image/webp,image/gif" style="display:none;" onchange="peHandleFile(this.files[0])">
                <div id="peDropContent">
                    <i class="fa-solid fa-cloud-arrow-up"></i>
                    <p><?= __('apedit.drop_title') ?></p>
                    <small><?= __('apedit.drop_hint') ?></small>
                </div>
                <div class="pe-preview-area" id="pePreviewArea">
                    <img id="pePreviewImg" alt="">
                </div>
            </div>
            <div class="pe-msg" id="peMsg"></div>
            <button type="button" class="btn-admin btn-primary-admin pe-upload-btn" id="peUploadBtn" onclick="peSubmitUpload()">
                <i class="fa-solid fa-upload"></i> <?= __('panel.upload') ?>
            </button>
        </div>
        <div id="peMtabLink" class="pe-mpane" style="display:none;">
            <label class="pe-file-label"><i class="fa-solid fa-link"></i><?= __('apedit.image_url') ?></label>
            <div class="pe-link-row">
                <input type="url" id="peLinkInput" placeholder="https://ornek.com/resim.webp">
                <button type="button" class="btn-admin btn-primary-admin" onclick="peApplyLink()" style="padding:11px 18px;"><i class="fa-solid fa-check"></i> <?= __('cart.coupon_apply') ?></button>
            </div>
            <div class="pe-status ok" id="peLinkOk" style="display:none;"><i class="fa-solid fa-circle-check"></i> <?= __('apedit.link_ok') ?></div>
            <div class="pe-status bad" id="peLinkBad" style="display:none;"><i class="fa-solid fa-circle-xmark"></i> <?= __('apedit.link_bad') ?></div>
        </div>
    </div>
</div>

<script>
var _peStep = 1;
var _peSelectedFile = null;
var _peDirty = false;
var _peIcons = ['fa-solid fa-cube','fa-solid fa-tags','fa-solid fa-box-open'];

function peCalcNet(){
    var pEl=document.getElementById('pePrice'), dEl=document.getElementById('peDiscount'), nEl=document.getElementById('peNetPrice');
    if(!pEl||!dEl||!nEl) return;
    var p=parseFloat(pEl.value), d=parseInt(dEl.value,10);
    if(isNaN(p)||p<=0){ nEl.style.display='none'; return; }
    if(isNaN(d)||d<=0){ nEl.style.display='none'; return; }
    if(d>90) d=90;
    var net=p*(1-d/100);
    nEl.textContent=<?= json_encode(__('aprod.net')) ?>+': '+window.nxFmt(net.toFixed(2))+' (−%'+d+')';
    nEl.style.display='block';
}
document.addEventListener('DOMContentLoaded',function(){
    var pEl=document.getElementById('pePrice'), dEl=document.getElementById('peDiscount');
    if(pEl&&dEl){ pEl.addEventListener('input',peCalcNet); dEl.addEventListener('input',peCalcNet); peCalcNet(); }
});
function peGo(step) {
    if (step === 2 && _peStep === 1) {
        var nameEl = document.getElementById('peName');
        if (!nameEl.value.trim()) { peFlash(nameEl, <?= json_encode(__('apedit.name_required')) ?>); return; }
    }
    if (step === 3 && _peStep === 2) {
        var priceEl = document.getElementById('pePrice');
        var pv = parseFloat(priceEl.value);
        if (isNaN(pv) || pv < 0) { peFlash(priceEl, <?= json_encode(__('apedit.price_invalid')) ?>); return; }
    }
    if (step < 1 || step > 3) return;
    _peStep = step;
    for (var i = 1; i <= 3; i++) {
        var panel = document.getElementById('pePanel' + i);
        var dot = document.getElementById('peDot' + i);
        var stepEl = document.querySelector('.pe-step[data-step="' + i + '"]');
        var icon = dot.querySelector('i');
        if (i < step) {
            panel.classList.remove('active');
            stepEl.classList.remove('active');
            stepEl.classList.add('done');
            icon.className = 'fa-solid fa-check';
        } else if (i === step) {
            panel.classList.add('active');
            stepEl.classList.remove('done');
            stepEl.classList.add('active');
            icon.className = _peIcons[i - 1];
        } else {
            panel.classList.remove('active');
            stepEl.classList.remove('active', 'done');
            icon.className = _peIcons[i - 1];
        }
    }
    document.getElementById('peTrackFill').style.width = ((step - 1) / 2 * 100) + '%';
    document.getElementById('pePrevBtn').style.display = step === 1 ? 'none' : '';
    document.getElementById('peNextBtn').style.display = step === 3 ? 'none' : '';
    document.getElementById('peActions').classList.toggle('show', step === 3);
    document.querySelector('.pe-shell').scrollIntoView({behavior:'smooth', block:'start'});
}

document.addEventListener('keydown', function(e){
    if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'BUTTON') {
        var nextBtn = document.getElementById('peNextBtn');
        if (nextBtn && nextBtn.style.display !== 'none') {
            e.preventDefault();
            peGo(_peStep + 1);
        }
    }
});

function peFlash(el, msg) {
    el.classList.add('pe-error');
    el.focus();
    alert(msg);
    setTimeout(function(){ el.classList.remove('pe-error'); }, 2000);
}

function peSetStatus(status) {
    document.getElementById('productStatus').value = status;
}

document.getElementById('peStatusView').addEventListener('change', function(){
    document.getElementById('productStatus').value = this.value;
    _peDirty = true;
});

function peTab(tab, paneId) {
    var acc = tab.closest('.pe-acc');
    acc.querySelectorAll('.pe-tab').forEach(function(t){ t.classList.remove('active'); });
    acc.querySelectorAll('.pe-pane').forEach(function(p){ p.classList.remove('active'); });
    tab.classList.add('active');
    document.getElementById(paneId).classList.add('active');
}

function peToggleAcc() {
    document.getElementById('peAcc').classList.toggle('open');
}

function peOpenImageModal() {
    document.getElementById('peImageModal').classList.add('show');
    _peSelectedFile = null;
    document.getElementById('peFileInput').value = '';
    document.getElementById('peDropContent').style.display = 'block';
    document.getElementById('pePreviewArea').style.display = 'none';
    document.getElementById('peUploadBtn').classList.remove('show');
    document.getElementById('peMsg').classList.remove('show');
    document.getElementById('peLinkInput').value = '';
    document.getElementById('peLinkOk').style.display = 'none';
    document.getElementById('peLinkBad').style.display = 'none';
    peSwitchMtab('upload');
}

function peCloseImageModal() {
    document.getElementById('peImageModal').classList.remove('show');
}

document.addEventListener('keydown', function(e){
    if (e.key === 'Escape') { peCloseImageModal(); peClosePublish(); }
});

function peSwitchMtab(tab) {
    document.querySelectorAll('.pe-mtab').forEach(function(b){
        b.classList.toggle('active', b.getAttribute('data-ptab') === tab);
    });
    document.getElementById('peMtabUpload').style.display = tab === 'upload' ? 'block' : 'none';
    document.getElementById('peMtabLink').style.display = tab === 'link' ? 'block' : 'none';
}

var _peDrop = document.getElementById('peDropZone');
['dragenter','dragover'].forEach(function(ev){
    _peDrop.addEventListener(ev, function(e){ e.preventDefault(); e.stopPropagation(); _peDrop.classList.add('over'); }, false);
});
['dragleave','drop'].forEach(function(ev){
    _peDrop.addEventListener(ev, function(e){ e.preventDefault(); e.stopPropagation(); _peDrop.classList.remove('over'); }, false);
});
_peDrop.addEventListener('drop', function(e){ if (e.dataTransfer.files[0]) peHandleFile(e.dataTransfer.files[0]); }, false);
_peDrop.addEventListener('click', function(){ document.getElementById('peFileInput').click(); }, false);

function peHandleFile(file) {
    if (!file.type.match(/image\/(jpeg|png|webp|gif)/)) return peShowMsg(<?= json_encode(__('apedit.bad_format')) ?>, false);
    if (file.size > 4194304) return peShowMsg(<?= json_encode(__('apedit.too_big')) ?>, false);
    _peSelectedFile = file;
    document.getElementById('peDropContent').style.display = 'none';
    document.getElementById('pePreviewArea').style.display = 'block';
    document.getElementById('peUploadBtn').classList.add('show');
    document.getElementById('peMsg').classList.remove('show');
    var r = new FileReader();
    r.onload = function(e){ document.getElementById('pePreviewImg').src = e.target.result; };
    r.readAsDataURL(file);
}

function peShowMsg(msg, ok) {
    var el = document.getElementById('peMsg');
    el.className = 'pe-msg show ' + (ok ? 'ok' : 'bad');
    el.innerHTML = '<i class="fa-solid fa-' + (ok ? 'circle-check' : 'circle-xmark') + '"></i> ' + msg;
}

async function peSubmitUpload() {
    if (!_peSelectedFile) return;
    var btn = document.getElementById('peUploadBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> ' + <?= json_encode(__('aprod.loading')) ?>;
    var fd = new FormData();
    fd.append('action', 'asset_upload');
    fd.append('ctx', 'products');
    fd.append('asset_type', 'cover');
    fd.append('file', _peSelectedFile);
    try {
        var r = await fetch('/action.php', {method:'POST', body:fd});
        var d = await r.json();
        if (d.ok) {
            peShowMsg(<?= json_encode(__('apedit.uploaded_ok')) ?>, true);
            peApplyImage(d.url);
            setTimeout(peCloseImageModal, 550);
        } else {
            peShowMsg(d.msg || <?= json_encode(__('apedit.upload_fail')) ?>, false);
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-upload"></i> ' + <?= json_encode(__('panel.upload')) ?>;
        }
    } catch (e) {
        peShowMsg(<?= json_encode(__('aprod.req_fail_short')) ?>, false);
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-upload"></i> ' + <?= json_encode(__('panel.upload')) ?>;
    }
}

function peApplyImage(url) {
    document.getElementById('peImageUrl').value = url;
    var thumb = document.getElementById('peCoverThumb');
    thumb.src = url;
    thumb.style.display = 'block';
    document.getElementById('peCoverPh').style.display = 'none';
    document.getElementById('peCoverLabel').textContent = <?= json_encode(__('apedit.cover_selected')) ?>;
    document.getElementById('peCoverSub').textContent = url;
    document.getElementById('peCoverSub').style.color = '#4ade80';
    _peDirty = true;
}

function peApplyLink() {
    var url = document.getElementById('peLinkInput').value.trim();
    if (!url) return peShowMsg(<?= json_encode(__('apedit.url_required')) ?>, false);
    var img = new Image();
    img.onload = function(){
        document.getElementById('peLinkOk').style.display = 'flex';
        document.getElementById('peLinkBad').style.display = 'none';
        peApplyImage(url);
        setTimeout(peCloseImageModal, 400);
    };
    img.onerror = function(){
        document.getElementById('peLinkBad').style.display = 'flex';
        document.getElementById('peLinkOk').style.display = 'none';
    };
    img.src = url;
}

(function(){
    var url = document.getElementById('peImageUrl').value;
    if (url) {
        document.getElementById('peCoverThumb').src = url;
        document.getElementById('peCoverThumb').style.display = 'block';
        document.getElementById('peCoverPh').style.display = 'none';
        document.getElementById('peCoverLabel').textContent = <?= json_encode(__('apedit.cover_selected')) ?>;
        document.getElementById('peCoverSub').textContent = url;
        document.getElementById('peCoverSub').style.color = '#4ade80';
    }
})();

(function(){
    var body = document.getElementById('edBody-peDescription');
    if (body) {
        var obs = new MutationObserver(function(){ _peDirty = true; });
        obs.observe(body, {childList:true, subtree:true, characterData:true});
    }
})();

var _peDirtyIds = ['peName','peCategory','pePrice','peStatusView','peDownloadLink','peDigitalFile','peShortDesc'];
_peDirtyIds.forEach(function(id){
    var el = document.getElementById(id);
    if (el) el.addEventListener('input', function(){ _peDirty = true; });
});
var _peChangeIds = ['peProductFile'];
_peChangeIds.forEach(function(id){
    var el = document.getElementById(id);
    if (el) el.addEventListener('change', function(){ _peDirty = true; });
});
document.querySelectorAll('#pePanel1 input, #pePanel2 input').forEach(function(el){
    el.addEventListener('input', function(){ _peDirty = true; });
});

window.addEventListener('beforeunload', function(e){
    if (_peDirty) { e.preventDefault(); e.returnValue = ''; }
});

document.getElementById('productEditorForm').addEventListener('submit', function(e){
    var body = document.getElementById('edBody-peDescription');
    var ta = document.getElementById('peDescription');
    if (body && ta) ta.value = body.innerHTML;
    var cvBody = document.getElementById('edBody-peCvBody');
    var cvTa = document.getElementById('peCvBody');
    if (cvBody && cvTa) cvTa.value = cvBody.innerHTML;
    var price = parseFloat(document.getElementById('pePrice').value);
    if (isNaN(price) || price < 0) { e.preventDefault(); peFlash(document.getElementById('pePrice'), <?= json_encode(__('apedit.price_invalid')) ?>); return; }
    _peDirty = false;
});

function peAiDesc(){
    var nm = document.getElementById('peName');
    var pr = document.getElementById('pePrice');
    vxwOpen({
        context: 'product_desc',
        title: 'AI Açıklama',
        approve: 'Açıklamaya Ekle',
        embed: 'peDescWrap',
        data: {name: nm ? nm.value : '', price: pr ? pr.value : ''},
        onApprove: function(html){
            var body = document.getElementById('edBody-peDescription');
            if (body) { body.innerHTML = (body.innerHTML.trim() !== '' ? body.innerHTML + '<p></p>' : '') + html; body.focus(); }
        }
    });
}
function peOpenPublish() {
    var nameEl = document.getElementById('peName');
    if (!nameEl.value.trim()) { peGo(1); peFlash(nameEl, <?= json_encode(__('apedit.name_required')) ?>); return; }
    var priceEl = document.getElementById('pePrice');
    var pv = parseFloat(priceEl.value);
    if (isNaN(pv) || pv < 0) { peGo(2); peFlash(priceEl, <?= json_encode(__('apedit.price_invalid')) ?>); return; }
    var cur = document.getElementById('peVersionInput');
    var cv = document.getElementById('peCvVersion');
    if (cur && cv && !cv.value) cv.placeholder = cur.value || '1.0.1';
    document.getElementById('pePublishModal').classList.add('show');
}
function peClosePublish() {
    document.getElementById('pePublishModal').classList.remove('show');
}
function peConfirmPublish() {
    var cv = document.getElementById('peCvVersion').value.trim();
    var sum = document.getElementById('peCvSummary').value.trim();
    var cvBody = document.getElementById('edBody-peCvBody');
    var cvHtml = cvBody ? cvBody.innerHTML.trim() : '';
    document.getElementById('peCvVersionHidden').value = cv;
    document.getElementById('peCvSummaryHidden').value = sum;
    var cvTa = document.getElementById('peCvBody');
    if (cvTa) cvTa.value = cvHtml;
    document.getElementById('peCvNotifyHidden').value = document.getElementById('peCvNotify').checked ? '1' : '0';
    if (cv) {
        var cur = document.getElementById('peVersionInput');
        if (cur) cur.value = cv;
    }
    var peBody = document.getElementById('edBody-peDescription');
    var peTa = document.getElementById('peDescription');
    if (peTa && peBody) peTa.value = peBody.innerHTML;
    peClosePublish();
    peSetStatus('active');
    document.getElementById('productEditorForm').submit();
}
</script>

<?php include __DIR__ . '/includes/ai-writer.php'; ?>
<?php include __DIR__ . '/includes/layout-end.php'; ?>