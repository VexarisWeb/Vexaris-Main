<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('aprod.title');
$activePage = 'products';

$flash = $_GET['flash'] ?? '';
[$flashType, $flashText] = $flash ? explode(':', urldecode($flash), 2) + ['',''] : ['', ''];

$editProduct = null;
if (isset($_GET['edit'])) {
    $ep = $adminDb->prepare('SELECT * FROM products WHERE id = ?');
    $ep->execute([(int)$_GET['edit']]);
    $editProduct = $ep->fetch() ?: null;
}

$products = $adminDb->query('SELECT * FROM products ORDER BY created_at DESC')->fetchAll();
$verCounts = [];
try { foreach ($adminDb->query('SELECT product_id, COUNT(*) AS c FROM product_versions GROUP BY product_id')->fetchAll() as $vc) $verCounts[(int)$vc['product_id']] = (int)$vc['c']; } catch (Throwable $e) {}

$extraHead = '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
<script src="https://cdn.tailwindcss.com"></script>
<style>.hidden{display:none!important}
@keyframes nxs-pop{from{opacity:0;transform:scale(.94) translateY(12px)}to{opacity:1;transform:scale(1) translateY(0)}}
@keyframes nxs-fade{from{opacity:0}to{opacity:1}}
.nxs-anim{animation:nxs-fade .25s ease;}
.nxs-anim>div{animation:nxs-pop .3s cubic-bezier(.34,1.56,.64,1);}
.nxs-sw{position:relative;display:inline-block;width:34px;height:19px;flex-shrink:0;vertical-align:middle;}
.nxs-sw input{opacity:0;width:0;height:0;}
.nxs-sw-slider{position:absolute;cursor:pointer;inset:0;background:rgba(148,163,184,.4);border-radius:19px;transition:background .2s;}
.nxs-sw-slider:before{content:"";position:absolute;height:13px;width:13px;left:3px;top:3px;background:#fff;border-radius:50%;transition:transform .2s;}
.nxs-sw input:checked+.nxs-sw-slider{background:var(--accent);}
.nxs-sw input:checked+.nxs-sw-slider:before{transform:translateX(15px);}</style>';
require_once __DIR__ . '/../core/editor.php';

include __DIR__ . '/includes/layout.php';
?>
<style>@media(max-width:640px){#verEditGrid{grid-template-columns:1fr!important;}}</style>

<?php if ($flashText): ?>
<div class="<?= $flashType === 'success' ? 'badge-green' : 'badge-red' ?>" style="padding:12px 18px;border-radius:12px;font-size:14px;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:8px;border:1px solid <?= $flashType === 'success' ? 'rgba(34,197,94,.3)' : 'rgba(239,68,68,.3)' ?>;">
    <i class="fa-solid fa-<?= $flashType === 'success' ? 'circle-check' : 'circle-xmark' ?>"></i>
    <?= e($flashText) ?>
</div>
<?php endif; ?>

<div class="admin-card" style="margin-bottom:24px;">
    <div class="admin-card-header">
        <span class="admin-card-title">
            <i class="fa-solid fa-box-open" style="color:#fbc853;margin-right:8px;"></i>
            <?= __('aprod.all_products') ?> <span style="color:var(--muted);font-weight:500;">(<?= count($products) ?>)</span>
        </span>
        <div style="display:flex;gap:8px;">
            <button type="button" onclick="openBulkStockModal()"
                    class="btn-admin btn-ghost-admin" style="font-size:13px;padding:9px 16px;">
                <i class="fa-solid fa-warehouse"></i> Toplu Stok
            </button>
            <a href="/admin/product-editor.php"
                    class="btn-admin btn-primary-admin" style="font-size:13px;padding:9px 18px;text-decoration:none;">
                <i class="fa-solid fa-plus"></i> <?= __('aprod.add_product') ?>
            </a>
        </div>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th><?= __('aprod.col_product') ?></th>
                <th><?= __('aprod.col_price') ?></th>
                <th><?= __('aprod.col_stock') ?></th>
                <th><?= __('adash.th_status') ?></th>
                <th><?= __('aprod.col_digital') ?></th>
                <th style="text-align:right;"><?= __('aprod.col_action') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($products as $p): ?>
        <tr class="animate-row" style="cursor:pointer;" onclick="window.location='/admin/products.php?detail=<?= $p['id'] ?>'">
            <td>
                <div style="display:flex;align-items:center;gap:12px;">
                    <?php if (!empty($p['image_url'])): ?>
                    <img src="<?= e($p['image_url']) ?>" style="width:44px;height:28px;object-fit:cover;border-radius:6px;flex-shrink:0;" alt="">
                    <?php else: ?>
                    <div style="width:44px;height:28px;background:var(--bg-surface);border-radius:6px;display:flex;align-items:center;justify-content:center;color:var(--dim);flex-shrink:0;">
                        <i class="fa-solid fa-box"></i>
                    </div>
                    <?php endif; ?>
                    <div>
                        <div style="font-weight:700;font-size:13px;<?= $p['is_hidden'] ? 'text-decoration:line-through;color:var(--muted);' : '' ?>"><?= e($p['name']) ?></div>
                        <div style="font-size:11px;color:var(--muted);"><?= e($p['category'] ?: '—') ?> · v<?= e($p['version']) ?></div>
                    </div>
                </div>
            </td>
            <td>
                <?php
                $pr = (float)$p['price'];
                $dp = (int)($p['discount_percent'] ?? 0);
                if ($pr > 0 && $dp > 0):
                    $net = $pr * (1 - $dp / 100);
                ?>
                <div style="display:flex;flex-direction:column;gap:2px;">
                    <div style="display:flex;align-items:center;gap:6px;">
                        <span style="font-size:11px;color:var(--muted);text-decoration:line-through;"><?= fmt_money($pr) ?></span>
                        <span class="badge badge-red" style="font-size:10px;padding:1px 6px;">%<?= $dp ?></span>
                    </div>
                    <span style="color:#fbc853;font-weight:800;"><?= fmt_money($net) ?></span>
                </div>
                <?php elseif ($pr > 0): ?>
                <span style="color:#fbc853;font-weight:700;"><?= fmt_money($pr) ?></span>
                <?php else: ?>
                <span class="badge badge-green"><i class="fa-solid fa-gift"></i> <?= __('home.free') ?></span>
                <?php endif; ?>
            </td>
            <td>
                <div style="display:flex;align-items:center;gap:8px;">
                    <label class="nxs-sw" title="<?= __('aprod.stock_toggle_title') ?>" onclick="event.stopPropagation()">
                        <input type="checkbox" id="stkToggle-<?= (int)$p['id'] ?>" <?= (($p['stock_type'] ?? 'unlimited') === 'limited') ? 'checked' : '' ?> onchange="toggleStockMode(<?= (int)$p['id'] ?>, this.checked)">
                        <span class="nxs-sw-slider"></span>
                    </label>
                    <span id="stockBadge-<?= (int)$p['id'] ?>">
                    <?php if (($p['stock_type'] ?? 'unlimited') === 'limited'): ?>
                        <?php $stkL = (int)($p['stock'] ?? 0); ?>
                        <?php if ($stkL < 1): ?>
                        <span class="badge badge-red"><i class="fa-solid fa-ban"></i> <?= __('product.soldout') ?></span>
                        <?php elseif ($stkL <= 5): ?>
                        <span class="badge badge-yellow"><i class="fa-solid fa-bolt"></i> Son <?= $stkL ?></span>
                        <?php else: ?>
                        <span class="badge badge-green"><?= $stkL ?> adet</span>
                        <?php endif; ?>
                    <?php else: ?>
                    <span class="badge badge-indigo"><i class="fa-solid fa-infinity"></i> <?= __('product.unlimited_short') ?></span>
                    <?php endif; ?>
                    </span>
                </div>
            </td>
            <td>
                <?php $sc = ['active' => 'badge-green', 'draft' => 'badge-yellow', 'hidden' => 'badge-red']; ?>
                <span class="badge <?= $sc[$p['status']] ?? 'badge-yellow' ?>">
                    <?= ['active' => 'Aktif', 'draft' => 'Taslak', 'hidden' => 'Gizli'][$p['status']] ?? $p['status'] ?>
                </span>
            </td>
            <td>
                <?php if (!empty($p['digital_file'])): ?>
                <span class="badge badge-indigo"><i class="fa-solid fa-key"></i> Veri Var</span>
                <?php elseif (!empty($p['file_path'])): ?>
                <span class="badge badge-green"><i class="fa-solid fa-file-arrow-down"></i> Dosya Var</span>
                <?php else: ?>
                <span style="color:var(--dim);font-size:12px;">—</span>
                <?php endif; ?>
            </td>
            <td onclick="event.stopPropagation()">
                <div style="display:flex;gap:6px;justify-content:flex-end;">
                    <a href="/admin/product-editor.php?id=<?= $p['id'] ?>"
                            class="btn-admin btn-ghost-admin" style="padding:6px 12px;font-size:12px;text-decoration:none;">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </a>
                    <button type="button" onclick="openVersionModal(<?= (int)$p['id'] ?>);event.stopPropagation()"
                            class="btn-admin btn-ghost-admin" style="padding:6px 12px;font-size:12px;position:relative;" title="<?= __('aprod.ver_manage_title') ?>">
                        <i class="fa-solid fa-code-branch"></i>
                        <?php if (!empty($verCounts[(int)$p['id']])): ?>
                        <span style="position:absolute;top:-7px;right:-7px;background:var(--accent);color:#fff;font-size:9px;font-weight:800;border-radius:999px;min-width:17px;height:17px;display:flex;align-items:center;justify-content:center;padding:0 4px;"><?= $verCounts[(int)$p['id']] ?></span>
                        <?php endif; ?>
                    </button>
                    <button id="stkRowBtn-<?= (int)$p['id'] ?>" style="padding:6px 12px;font-size:12px;<?= (($p['stock_type'] ?? 'unlimited') === 'limited') ? '' : 'display:none;' ?>"
                            onclick="openStockModal(<?= htmlspecialchars(json_encode(['id'=>$p['id'],'name'=>$p['name']]), ENT_QUOTES) ?>);event.stopPropagation()"
                            class="btn-admin btn-ghost-admin" title="<?= __('aprod.stock_edit_title') ?>">
                        <i class="fa-solid fa-boxes-stacked"></i>
                    </button>
                    <form method="POST" action="/action.php" onsubmit="return confirm('<?= __('aprod.delete_confirm') ?>');" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="product_delete">
                        <input type="hidden" name="id" value="<?= $p['id'] ?>">
                        <button type="submit" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;padding:6px 12px;font-size:12px;border:1px solid rgba(239,68,68,.2);">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($products)): ?>
        <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:32px;"><?= __('home.empty_products') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php if (isset($_GET['detail'])): ?>
<?php
$dp = $adminDb->prepare('SELECT * FROM products WHERE id = ?');
$dp->execute([(int)$_GET['detail']]);
$detailProduct = $dp->fetch();
if ($detailProduct):
    $dpImages = $adminDb->prepare('SELECT * FROM product_images WHERE product_id = ? ORDER BY sort_order ASC');
    try { $dpImages->execute([$detailProduct['id']]); $galleryImages = $dpImages->fetchAll(); }
    catch (\Exception $e) { $galleryImages = []; }
    $dpComments = $adminDb->prepare('SELECT c.*, u.username, u.avatar FROM comments c JOIN users u ON u.id = c.user_id WHERE c.product_id = ? ORDER BY c.id DESC');
    $dpComments->execute([$detailProduct['id']]);
    $detailComments = $dpComments->fetchAll();
?>
<div class="nxs-anim" style="position:fixed;inset:0;z-index:999;background:rgba(0,0,0,.75);display:flex;align-items:center;justify-content:center;padding:20px;" id="detailModal" onclick="if(event.target===this)window.location='/admin/products.php'">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;max-width:900px;max-height:90vh;overflow-y:auto;position:relative;">
        <div style="padding:20px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;">
            <span style="font-size:15px;font-weight:800;"><?= e($detailProduct['name']) ?></span>
            <a href="/admin/products.php" style="color:var(--muted);font-size:18px;"><i class="fa-solid fa-xmark"></i></a>
        </div>
        <div class="modal-inner-grid" style="padding:24px;display:grid;grid-template-columns:1fr 1fr;gap:24px;">
            <div>
                <?php if (!empty($detailProduct['image_url'])): ?>
                <img src="<?= e($detailProduct['image_url']) ?>" style="width:100%;border-radius:12px;object-fit:cover;aspect-ratio:16/9;" alt="">
                <?php else: ?>
                <div style="width:100%;aspect-ratio:16/9;background:var(--bg-surface);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:48px;color:var(--dim);">
                    <i class="fa-solid fa-box"></i>
                </div>
                <?php endif; ?>
                <?php if (!empty($galleryImages)): ?>
                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:10px;">
                    <?php foreach ($galleryImages as $gi): ?>
                    <img src="<?= e($gi['image_url']) ?>" style="width:100%;aspect-ratio:16/9;object-fit:cover;border-radius:8px;" alt="">
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <form method="POST" action="/action.php" enctype="multipart/form-data" style="margin-top:12px;">
                    <input type="hidden" name="action" value="product_image_add">
                    <input type="hidden" name="product_id" value="<?= $detailProduct['id'] ?>">
                    <?= csrf_field() ?>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.gallery_add') ?></label>
                    <div style="display:flex;gap:8px;">
                        <input type="hidden" name="MAX_FILE_SIZE" value="8388608">
                        <input type="file" name="gallery_image" accept="image/*" data-max-size="8388608" style="flex:1;background:var(--bg-surface);border:1px solid var(--border);border-radius:8px;padding:7px 10px;font-size:12px;color:var(--text);">
                        <button type="submit" class="btn-admin btn-ghost-admin" style="font-size:12px;padding:7px 14px;"><i class="fa-solid fa-plus"></i></button>
                    </div>
                </form>
            </div>
            <div>
                <div class="modal-inner-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px;">
                    <?php foreach ([[__('aprod.col_price'),fmt_money((float)$detailProduct['price'])], [__('aprod.version_label'),'v'.e($detailProduct['version'])], [__('support.category'),e($detailProduct['category']??'—')], [__('adash.th_status'),['active'=>__('adash.status_active'),'draft'=>__('adash.status_draft'),'hidden'=>__('adash.status_hidden')][$detailProduct['status']]??e($detailProduct['status'])]] as [$lk,$lv]): ?>
                    <div style="background:var(--bg-surface);border-radius:10px;padding:12px;">
                        <div style="font-size:10px;color:var(--muted);font-weight:700;margin-bottom:3px;"><?= $lk ?></div>
                        <div style="font-size:14px;font-weight:800;"><?= $lv ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php if (!empty($detailProduct['short_description'])): ?>
                <p style="font-size:13px;color:var(--muted);margin-bottom:12px;"><?= e($detailProduct['short_description']) ?></p>
                <?php endif; ?>
                <div style="font-size:12px;font-weight:700;color:var(--muted);margin-bottom:8px;"><?= __('product.tab_reviews') ?> (<?= count($detailComments) ?>)</div>
                <div style="display:flex;flex-direction:column;gap:8px;max-height:200px;overflow-y:auto;">
                    <?php if (empty($detailComments)): ?>
                    <p style="font-size:12px;color:var(--dim);"><?= __('product.no_reviews') ?></p>
                    <?php else: foreach ($detailComments as $dc): ?>
                    <div style="background:var(--bg-surface);border-radius:10px;padding:10px 12px;display:flex;gap:8px;align-items:flex-start;">
                        <img src="<?= e($dc['avatar'] ?: 'https://minotar.net/avatar/user.png') ?>" style="width:28px;height:28px;border-radius:50%;" alt="">
                        <div>
                            <div style="font-size:11px;font-weight:800;"><?= e($dc['username']) ?>
                                <?php if ((int)$dc['rating'] > 0): ?>
                                <span style="margin-left:6px;color:#facc15;font-size:10px;">
                                    <?= str_repeat('<i class="fa-solid fa-star"></i>', (int)$dc['rating']) ?><?= str_repeat('<i class="fa-regular fa-star"></i>', 5-(int)$dc['rating']) ?>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div style="font-size:12px;color:var(--muted);margin-top:2px;"><?= e($dc['comment_text']) ?></div>
                        </div>
                    </div>
                    <?php endforeach; endif; ?>
                </div>
                <div style="margin-top:16px;display:flex;gap:8px;">
                    <a href="/admin/product-editor.php?id=<?= $detailProduct['id'] ?>" class="btn-admin btn-primary-admin" style="flex:1;justify-content:center;font-size:13px;text-decoration:none;">
                        <i class="fa-solid fa-pen-to-square"></i> <?= __('aprod.fullscreen_edit') ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; endif; ?>

<div id="modalAddProduct" class="hidden" style="position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;padding:16px;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;max-width:860px;max-height:92vh;overflow-y:auto;">
        <div style="padding:18px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;">
            <span style="font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;">
                <i class="fa-solid fa-plus" style="color:var(--accent);"></i>
                <span id="wizardTitle"><?= __('aprod.wizard_step1') ?></span>
            </span>
            <button onclick="document.getElementById('modalAddProduct').classList.add('hidden')" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:18px;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <div style="padding:6px 22px 0;">
            <div style="display:flex;gap:4px;margin-bottom:18px;margin-top:14px;">
                <div id="stepDot1" style="flex:1;height:4px;border-radius:4px;background:var(--accent);transition:background .3s;"></div>
                <div id="stepDot2" style="flex:1;height:4px;border-radius:4px;background:var(--border);transition:background .3s;"></div>
            </div>
        </div>

        <form id="addProductForm" method="POST" action="/action.php" enctype="multipart/form-data">
            <input type="hidden" name="action" value="product_add">
            <?= csrf_field() ?>
            <div style="padding:0 22px 22px;">

                <div id="wizardStep1">
                    <div style="margin-bottom:14px;">
                        <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.name_label') ?></label>
                        <input type="text" name="name" required maxlength="120"
                               style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    </div>
                    <div style="margin-bottom:14px;">
                        <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.short_label') ?></label>
                        <input type="text" name="short_description" maxlength="300"
                               style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    </div>
                    <div style="margin-bottom:14px;">
                        <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.cover_label') ?></label>
                        <input type="hidden" name="MAX_FILE_SIZE" value="8388608">
                        <input type="file" name="cover_image" accept="image/*" data-max-size="8388608"
                               style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:8px 12px;color:var(--text);font-size:12px;">
                    </div>
                    <div>
                        <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.detail_desc_label') ?></label>
                        <?php render_editor('addProductDesc', '', '200px', 'description'); ?>
                    </div>
                </div>

                <div id="wizardStep2" style="display:none;">
                    <div class="modal-inner-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">
                        <div>
                            <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.price_label') ?></label>
                            <input type="number" name="price" step="0.01" min="0" value="0"
                                   style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                        </div>
                        <div>
                            <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('support.category') ?></label>
                            <select name="category" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                                <option value=""><?= __('aprod.not_selected') ?></option>
                                <?php foreach ($adminDb->query('SELECT name FROM categories ORDER BY sort_order ASC, name ASC')->fetchAll(PDO::FETCH_COLUMN) as $cn): ?>
                                <option value="<?= e($cn) ?>"><?= e($cn) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.version_label') ?></label>
                            <input type="text" name="version" maxlength="20" value="1.0.0"
                                   style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                        </div>
                        <div>
                            <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.prefix_label') ?></label>
                            <input type="text" name="license_prefix" maxlength="20" style="text-transform:uppercase;width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                        </div>
                    </div>
                    <div style="margin-bottom:14px;">
                        <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.digital_deliver_label') ?></label>
                        <textarea name="digital_file" rows="4"
                                  style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;resize:vertical;font-family:monospace;"></textarea>
                        <p style="font-size:11px;color:var(--muted);margin-top:4px;"><?= __('aprod.digital_hint') ?></p>
                    </div>
                    <div>
                        <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.digital_upload_label') ?></label>
                        <input type="hidden" name="MAX_FILE_SIZE" value="33554432">
                        <input type="file" name="product_file" data-max-size="33554432"
                               style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:8px 12px;color:var(--text);font-size:12px;">
                    </div>
                </div>

                <div style="display:flex;gap:10px;margin-top:22px;">
                    <button type="button" id="wizardBack" onclick="wizardStep(1)" style="display:none;flex:none;" class="btn-admin btn-ghost-admin">
                        <i class="fa-solid fa-arrow-left"></i> <?= __('aprod.back') ?>
                    </button>
                    <button type="button" id="wizardNext" onclick="wizardStep(2)"
                            style="flex:1;justify-content:center;" class="btn-admin btn-primary-admin">
                        <?= __('aprod.continue') ?> <i class="fa-solid fa-arrow-right"></i>
                    </button>
                    <button type="submit" id="wizardSubmit" style="display:none;flex:1;justify-content:center;" class="btn-admin btn-primary-admin">
                        <i class="fa-solid fa-floppy-disk"></i> <?= __('msg.save') ?>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<div id="modalEditProduct" class="hidden" style="position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;padding:16px;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;max-width:860px;max-height:92vh;overflow-y:auto;">
        <div style="padding:18px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;">
            <span style="font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;">
                <i class="fa-solid fa-pen-to-square" style="color:var(--accent);"></i> <?= __('aprod.edit_title') ?>
            </span>
            <button onclick="closeEditModal()" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:18px;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <form method="POST" action="/action.php" enctype="multipart/form-data" style="padding:22px;">
            <input type="hidden" name="action" value="product_edit">
            <input type="hidden" name="id" id="editId">
            <?= csrf_field() ?>
            <div class="modal-inner-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">
                <?php foreach ([['editName','name',__('aprod.name_label'),'text'],['editShort','short_description',__('aprod.short_label'),'text'],['editPrice','price',__('aprod.price_plain'),'number'],['editVersion','version',__('aprod.version_label'),'text'],['editPrefix','license_prefix',__('aprod.prefix_label'),'text']] as [$eid,$ename,$elabel,$etype]): ?>
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= $elabel ?></label>
                    <input type="<?= $etype ?>" id="<?= $eid ?>" name="<?= $ename ?>" <?= $ename === 'price' ? 'step="0.01" min="0"' : '' ?>
                           style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                </div>
                <?php endforeach; ?>
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('support.category') ?></label>
                    <select name="category" id="editCat" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                        <option value=""><?= __('aprod.not_selected') ?></option>
                        <?php foreach ($adminDb->query('SELECT name FROM categories ORDER BY sort_order ASC, name ASC')->fetchAll(PDO::FETCH_COLUMN) as $cn): ?>
                        <option value="<?= e($cn) ?>"><?= e($cn) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="modal-inner-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('adash.th_status') ?></label>
                    <select name="status" id="editStatus" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                        <option value="active"><?= __('adash.status_active') ?></option>
                        <option value="draft"><?= __('adash.status_draft') ?></option>
                        <option value="hidden"><?= __('adash.status_hidden') ?></option>
                    </select>
                </div>
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.cover_short') ?></label>
                    <input type="hidden" name="MAX_FILE_SIZE" value="8388608">
                    <input type="file" name="cover_image" accept="image/*" data-max-size="8388608"
                           style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:8px 12px;color:var(--text);font-size:12px;">
                </div>
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;">Dijital Veri</label>
                <textarea name="digital_file" id="editDigital" rows="3"
                          style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;resize:vertical;font-family:monospace;"></textarea>
            </div>
            <div style="margin-bottom:20px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.desc_label') ?></label>
                <?php render_editor('editDesc', '', '200px', 'description'); ?>
            </div>
            <div style="display:flex;gap:10px;">
                <button type="submit" class="btn-admin btn-primary-admin" style="flex:1;justify-content:center;">
                    <i class="fa-solid fa-floppy-disk"></i> <?= __('aprod.update') ?>
                </button>
                <button type="button" onclick="closeEditModal()" class="btn-admin btn-ghost-admin"><?= __('support.cancel') ?></button>
            </div>
        </form>
    </div>
</div>

<div id="modalStock" class="hidden" style="position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;padding:16px;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;max-width:680px;max-height:92vh;overflow-y:auto;">
        <div style="padding:18px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;">
            <span style="font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;">
                <i class="fa-solid fa-warehouse" style="color:var(--accent);"></i> <?= __('aprod.stock_mgmt') ?> <span id="stockProductName">-</span>
            </span>
            <button onclick="closeStockModal()" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:18px;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <div style="padding:22px;">

            <div style="display:flex;gap:8px;align-items:center;margin-bottom:18px;flex-wrap:wrap;">
                <button type="button" onclick="stockSet('unlimited')" id="stockBtnUnlimited" class="btn-admin btn-ghost-admin" style="font-size:12px;padding:7px 14px;border-color:rgba(var(--accent-rgb),.4);color:#a5b4fc;">
                    <i class="fa-solid fa-infinity"></i> <?= __('aprod.unlimited_stock') ?>
                </button>
                <button type="button" onclick="stockSet('limited_keep')" id="stockBtnLimited" class="btn-admin btn-ghost-admin" style="font-size:12px;padding:7px 14px;">
                    <i class="fa-solid fa-ban"></i> <?= __('aprod.make_limited') ?>
                </button>
                <span id="stockSummary" style="margin-left:auto;font-size:12px;color:var(--muted);"><?= __('aprod.loading') ?></span>
            </div>

            <div style="margin-bottom:18px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.new_contents_label') ?></label>
                <textarea id="stockContents" rows="5" placeholder="KEY-XXXX-YYYY-1&#10;KEY-XXXX-YYYY-2"
                          style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:12px;outline:none;resize:vertical;font-family:monospace;"></textarea>
                <div style="display:flex;gap:8px;margin-top:10px;">
                    <button type="button" onclick="stockAddContents()" class="btn-admin btn-primary-admin" style="font-size:12px;padding:8px 16px;">
                        <i class="fa-solid fa-plus"></i> <?= __('aprod.add_stocks') ?>
                    </button>
                </div>
            </div>

            <div id="stockUnlimitedInfo" style="display:none;background:rgba(var(--accent-rgb),.06);border:1px solid rgba(var(--accent-rgb),.2);border-radius:10px;padding:14px 16px;margin-bottom:16px;">
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
                    <i class="fa-solid fa-infinity" style="color:#a5b4fc;font-size:16px;"></i>
                    <span style="font-size:13px;font-weight:800;color:#a5b4fc;"><?= __('aprod.unlimited_mode') ?></span>
                </div>
                <p style="font-size:12px;color:var(--muted);line-height:1.5;margin:0;">
                    <?= __('aprod.unlimited_hint') ?>
                </p>
            </div>

            <div style="font-size:11px;font-weight:700;color:var(--muted);margin-bottom:8px;"><?= __('aprod.current_records') ?></div>
            <div id="stockList" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;max-height:320px;overflow-y:auto;padding-right:4px;">
                <span style="color:var(--muted);font-size:12px;grid-column:1/-1;"><?= __('aprod.loading') ?></span>
            </div>
        </div>
    </div>
</div>

<div id="bulkPickerModal" class="nxs-anim" onclick="if(event.target===this)closeBulkPicker()" style="display:none;position:fixed;inset:0;z-index:1300;background:rgba(0,0,0,.7);align-items:center;justify-content:center;padding:20px;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:16px;width:100%;max-width:760px;max-height:82vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.5);">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 22px;border-bottom:1px solid var(--border);">
            <span style="font-size:15px;font-weight:800;"><i class="fa-solid fa-box-open" style="color:var(--accent);margin-right:8px;"></i><?= __('aprod.bulk_pick_title') ?> <span id="bulkCountSpan" style="color:var(--accent);"></span></span>
            <button type="button" onclick="closeBulkPicker()" style="width:32px;height:32px;border-radius:8px;border:1px solid var(--border);background:var(--bg-surface);color:var(--muted);cursor:pointer;font-size:14px;"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div style="padding:14px 22px;border-bottom:1px solid var(--border);">
            <input type="text" id="bulkPickerSearch" oninput="applyBulkFilter()" placeholder="<?= __('aprod.search_ph') ?>" autocomplete="off"
                   style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
        </div>
        <div id="bulkPickerGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;padding:18px 22px;overflow-y:auto;"></div>
        <div style="display:flex;justify-content:flex-end;gap:10px;padding:16px 22px;border-top:1px solid var(--border);">
            <button type="button" onclick="closeBulkPicker()" class="btn-admin btn-ghost-admin" style="padding:10px 16px;"><?= __('support.cancel') ?></button>
            <button type="button" onclick="confirmBulkPicker()" class="btn-admin btn-primary-admin" style="padding:10px 16px;"><?= __('aprod.confirm') ?></button>
        </div>
    </div>
</div>

<div id="modalBulkStock" class="nxs-anim hidden" style="position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;padding:16px;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;max-width:560px;max-height:92vh;overflow-y:auto;">
        <div style="padding:18px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;">
            <span style="font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;">
                <i class="fa-solid fa-warehouse" style="color:var(--accent);"></i> <?= __('aprod.bulk_entry') ?>
            </span>
            <button onclick="closeBulkStockModal()" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:18px;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <div style="padding:22px;">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px;">
                <span style="font-size:13px;font-weight:800;"><?= __('aprod.selected_products') ?> <span id="bulkStockCount" style="color:#fbc853;">(0)</span></span>
                <button type="button" onclick="openBulkPicker()" class="btn-admin btn-ghost-admin" style="font-size:11px;padding:5px 12px;">
                    <i class="fa-solid fa-pen-to-square"></i> <?= __('aprod.pick_products') ?>
                </button>
            </div>
            <div id="bulkSelectedChips" style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px;"></div>
            <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.bulk_contents_label') ?></label>
            <textarea id="bulkStockContents" rows="6" placeholder="KEY-XXXX-YYYY-1&#10;KEY-XXXX-YYYY-2"
                      style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:12px;outline:none;resize:vertical;font-family:monospace;"></textarea>
            <div style="display:flex;gap:8px;margin-top:14px;">
                <button type="button" onclick="bulkAddContents()" class="btn-admin btn-primary-admin" style="font-size:12px;padding:8px 16px;flex:1;">
                    <i class="fa-solid fa-plus"></i> <?= __('aprod.add_to_selected') ?>
                </button>
                <button type="button" onclick="bulkSetUnlimited()" class="btn-admin btn-ghost-admin" style="font-size:12px;padding:8px 16px;">
                    <i class="fa-solid fa-infinity"></i> <?= __('aprod.make_unlimited') ?>
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function validateFileSizes(form) {
    const files = form.querySelectorAll('input[type="file"][data-max-size]');
    for (const input of files) {
        if (input.files.length > 0) {
            const maxBytes = parseInt(input.getAttribute('data-max-size'), 10);
            if (input.files[0].size > maxBytes) {
                const mb = (maxBytes / 1048576).toFixed(0);
                alert(<?= json_encode(__('aprod.file_too_big')) ?>.replace('{name}', input.files[0].name).replace('{mb}', mb));
                return false;
            }
        }
    }
    return true;
}

function syncEditor(id) {
    var body = document.getElementById('edBody-' + id);
    var ta = document.getElementById(id);
    if (body && ta) ta.value = body.innerHTML;
}

document.getElementById('addProductForm').addEventListener('submit', function(e){
    if (!validateFileSizes(this)) { e.preventDefault(); return; }
    syncEditor('addProductDesc');
});

document.querySelectorAll('#modalEditProduct form').forEach(function(f) {
    f.addEventListener('submit', function(e){
        if (!validateFileSizes(this)) { e.preventDefault(); return; }
        syncEditor('editDesc');
    });
});

function wizardStep(step) {
    const s1 = document.getElementById('wizardStep1');
    const s2 = document.getElementById('wizardStep2');
    if (step === 2) {
        const nameVal = document.querySelector('#addProductForm input[name="name"]').value.trim();
        if (!nameVal) { alert(<?= json_encode(__('aprod.name_required')) ?>); return; }
        s1.style.display = 'none'; s2.style.display = 'block';
        document.getElementById('wizardNext').style.display = 'none';
        document.getElementById('wizardBack').style.display = '';
        document.getElementById('wizardSubmit').style.display = '';
        document.getElementById('wizardTitle').textContent = <?= json_encode(__('aprod.wizard_step2')) ?>;
        document.getElementById('stepDot2').style.background = 'var(--accent)';
    } else {
        s2.style.display = 'none'; s1.style.display = 'block';
        document.getElementById('wizardNext').style.display = '';
        document.getElementById('wizardBack').style.display = 'none';
        document.getElementById('wizardSubmit').style.display = 'none';
        document.getElementById('wizardTitle').textContent = <?= json_encode(__('aprod.wizard_step1')) ?>;
        document.getElementById('stepDot2').style.background = 'var(--border)';
    }
}

function openAddModal() {
    const modal = document.getElementById('modalAddProduct');
    modal.classList.remove('hidden');
    document.getElementById('wizardStep1').style.display = 'block';
    document.getElementById('wizardStep2').style.display = 'none';
    document.getElementById('wizardNext').style.display = '';
    document.getElementById('wizardBack').style.display = 'none';
    document.getElementById('wizardSubmit').style.display = 'none';
    document.getElementById('wizardTitle').textContent = <?= json_encode(__('aprod.wizard_step1')) ?>;
    document.getElementById('stepDot1').style.background = 'var(--accent)';
    document.getElementById('stepDot2').style.background = 'var(--border)';
    setTimeout(function(){
        var ed = document.getElementById('edBody-addProductDesc');
        if (ed) ed.focus();
    }, 100);
}

function openEditModal(p) {
    document.getElementById('editId').value      = p.id ?? '';
    document.getElementById('editName').value    = p.name ?? '';
    document.getElementById('editShort').value   = p.short_description ?? '';
    document.getElementById('editPrice').value   = p.price ?? '0';
    document.getElementById('editVersion').value = p.version ?? '1.0.0';
    document.getElementById('editCat').value     = p.category ?? '';
    document.getElementById('editPrefix').value  = p.license_prefix ?? '';
    document.getElementById('editDigital').value = p.digital_file ?? '';
    document.getElementById('editStatus').value  = p.status ?? 'draft';

    var editBody = document.getElementById('edBody-editDesc');
    if (editBody) editBody.innerHTML = p.description ?? '';

    const modal = document.getElementById('modalEditProduct');
    modal.classList.remove('hidden');
}

function closeEditModal() {
    document.getElementById('modalEditProduct').classList.add('hidden');
}

/* ---------- Stok Yönetimi ---------- */
var currentStockPid = 0;
var stockRecords = [];

function postStock(action, data, quiet) {
    data.action = action;
    return fetch('/action.php', {
        method: 'POST',
        body: new URLSearchParams(data)
    }).then(function(r){ return r.json(); }).then(function(d){
        if (!(d.ok || d.success) && !quiet) alert(d.msg || d.error || d.message || <?= json_encode(__('topup.error')) ?>);
        return d;
    }).catch(function(err){ if (!quiet) alert(<?= json_encode(__('aprod.req_fail')) ?>.replace('{err}', err)); return {ok:false, success:false}; });
}

function openStockModal(p) {
    currentStockPid = p.id;
    document.getElementById('stockProductName').textContent = p.name;
    document.getElementById('stockContents').value = '';
    document.getElementById('modalStock').classList.remove('hidden');
    reloadStockList();
}
function closeStockModal() { document.getElementById('modalStock').classList.add('hidden'); }

function reloadStockList() {
    fetch('/admin/_stock_list.php?id=' + encodeURIComponent(currentStockPid) + '&_=' + Date.now())
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (!d.success) { document.getElementById('stockList').innerHTML = '<span style="color:var(--muted);font-size:12px;grid-column:1/-1;">' + <?= json_encode(__('err.load_fail')) ?> + '</span>'; return; }
            var type = d.stock_type || 'unlimited';
            document.getElementById('stockSummary').innerHTML =
                type === 'unlimited' ? '<i class="fa-solid fa-infinity"></i> ' + <?= json_encode(__('product.unlimited_short')) ?> :
                ('<b style="color:#fbc853;">' + d.available + '</b> / ' + d.total + ' ' + <?= json_encode(__('aprod.available')) ?>);
            var unlimitedInfo = document.getElementById('stockUnlimitedInfo');
            var stockListBox = document.getElementById('stockList');
            if (type === 'unlimited') {
                unlimitedInfo.style.display = 'block';
                stockListBox.style.display = 'none';
                return;
            }
            unlimitedInfo.style.display = 'none';
            stockListBox.style.display = 'grid';
            stockRecords = d.items || [];
            var box = stockListBox;
            if (!stockRecords.length) {
                box.innerHTML = '<span style="color:var(--muted);font-size:12px;font-style:italic;grid-column:1/-1;">' + <?= json_encode(__('aprod.no_records')) ?> + '</span>';
                return;
            }
            box.innerHTML = stockRecords.map(function(it, idx){
                var used = it.used;
                var badge = used
                    ? '<span style="color:#f87171;font-size:10px;font-weight:700;"><i class="fa-solid fa-circle-check"></i> ' + <?= json_encode(__('aprod.used')) ?> + '</span>'
                    : '<span style="color:#34d399;font-size:10px;font-weight:700;"><i class="fa-solid fa-circle" style="font-size:7px;"></i> ' + <?= json_encode(__('aprod.usable')) ?> + '</span>';
                var actions = !used
                    ? '<button onclick="deleteStockRecord(' + it.id + ')" title="' + <?= json_encode(__('aprod.stock_del_title')) ?> + '" style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#f87171;cursor:pointer;border-radius:6px;width:26px;height:26px;display:flex;align-items:center;justify-content:center;font-size:11px;flex-shrink:0;"><i class="fa-solid fa-trash"></i></button>'
                    : '<span style="width:26px;flex-shrink:0;"></span>';
                var val = used ? '<del style="color:var(--muted);">' + escHtml(it.content) + '</del>' : escHtml(it.content);
                var borderColor = used ? 'rgba(239,68,68,.15)' : 'rgba(var(--accent-rgb),.25)';
                var bgColor = used ? 'rgba(239,68,68,.04)' : 'rgba(var(--accent-rgb),.04)';
                return '<div style="display:flex;align-items:center;gap:8px;background:' + bgColor + ';border:1px solid ' + borderColor + ';border-radius:10px;padding:8px 10px;min-height:42px;">' +
                       '<span style="flex:1;font-family:monospace;font-size:11px;word-break:break-all;line-height:1.4;">' + val + '</span>' +
                       '<div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0;">' + badge + actions + '</div>' +
                       '</div>';
            }).join('');
        });
}

function escHtml(s) {
    return String(s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; });
}

function stockAddContents() {
    var contents = document.getElementById('stockContents').value.trim();
    if (!contents) { alert(<?= json_encode(__('aprod.contents_required')) ?>); return; }
    postStock('product_stock_items', {id: currentStockPid, op:'add', contents: contents}).then(function(d){
        if (d.ok || d.success) {
            document.getElementById('stockContents').value = '';
            reloadStockList();
        }
    });
    var row = document.getElementById('row-' + currentStockPid);
    if (row) row.querySelector('.stock-cell').innerHTML = '...';
}
function deleteStockRecord(recordId) {
    if (!confirm(<?= json_encode(__('aprod.stock_del_confirm')) ?>)) return;
    postStock('product_stock', {id: currentStockPid, op:'delete', qty: recordId}).then(function(d){
        if (d.ok || d.success) reloadStockList();
    });
}
function stockSet(op) {
    postStock('product_stock', {id: currentStockPid, op: op, qty: 1}).then(function(d){
        if (d.ok || d.success) reloadStockList();
    });
}
function toggleStockMode(id, on) {
    postStock('product_stock', {id: id, op: on ? 'limited_keep' : 'unlimited', qty: 1}).then(function(d){
        if (d.ok || d.success) renderStockBadge(id, on, d.available);
    });
}
function renderStockBadge(id, on, available) {
    var btn = document.getElementById('stkRowBtn-' + id);
    if (btn) btn.style.display = on ? '' : 'none';
    var badge = document.getElementById('stockBadge-' + id);
    if (!badge) return;
    if (!on) {
        badge.innerHTML = '<span class="badge badge-indigo"><i class="fa-solid fa-infinity"></i> <?= __('product.unlimited_short') ?></span>';
        return;
    }
    var a = parseInt(available || 0, 10);
    var html;
    if (a < 1) html = '<span class="badge badge-red"><i class="fa-solid fa-ban"></i> <?= __('product.soldout') ?></span>';
    else if (a <= 5) html = '<span class="badge badge-yellow"><i class="fa-solid fa-bolt"></i> ' + <?= json_encode(__('aprod.low_stock')) ?>.replace('{n}', a) + '</span>';
    else html = '<span class="badge badge-green">' + <?= json_encode(__('aprod.stock_pcs')) ?>.replace('{n}', a) + '</span>';
    badge.innerHTML = html;
}

/* ---------- Toplu Stok (görsel ürün seçim) ---------- */
var bulkProducts = <?= json_encode(array_map(fn($p) => ['id'=>(int)$p['id'],'name'=>$p['name'],'image'=>$p['image_url'],'stock_type'=>$p['stock_type'] ?? 'unlimited'], $products), JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var bulkSelected = [];
var bulkPickerModal = document.getElementById('bulkPickerModal');
var bulkPickerGrid = document.getElementById('bulkPickerGrid');
var bulkChips = document.getElementById('bulkSelectedChips');
var bulkCountSpan = document.getElementById('bulkCountSpan');
var bulkStockCountEl = document.getElementById('bulkStockCount');

function renderBulkGrid() {
    var q = (document.getElementById('bulkPickerSearch').value || '').toLowerCase().trim();
    var h = '';
    for (var i = 0; i < bulkProducts.length; i++) {
        var p = bulkProducts[i];
        if (p.stock_type !== 'limited') continue;
        if (q && p.name.toLowerCase().indexOf(q) === -1) continue;
        var sel = bulkSelected.indexOf(p.id) !== -1;
        h += '<div data-id="' + p.id + '" data-name="' + escHtml(p.name) + '" onclick="toggleBulk(this)" style="' + (sel ? 'border-color:var(--accent);box-shadow:0 0 0 2px rgba(var(--accent-rgb),.25);' : 'border-color:var(--border);') + 'border:2px solid;border-radius:12px;overflow:hidden;cursor:pointer;background:var(--bg-surface);transition:.15s;">';
        h += '<div style="height:78px;background:var(--bg-surface);display:flex;align-items:center;justify-content:center;overflow:hidden;">';
        if (p.image) h += '<img src="' + escHtml(p.image) + '" style="width:100%;height:100%;object-fit:cover;">';
        else h += '<i class="fa-solid fa-box-open" style="font-size:22px;color:var(--dim);"></i>';
        h += '</div>';
        h += '<div style="padding:8px 10px;display:flex;align-items:center;gap:8px;"><input type="checkbox" data-cb="1" ' + (sel?'checked':'') + ' style="accent-color:var(--accent);pointer-events:none;margin:0;"><span style="font-size:12px;font-weight:700;line-height:1.2;">' + escHtml(p.name) + '</span></div>';
        h += '</div>';
    }
    bulkPickerGrid.innerHTML = h || '<div style="grid-column:1/-1;text-align:center;color:var(--muted);padding:30px;">' + <?= json_encode(__('aprod.not_found')) ?> + '</div>';
}
function applyBulkFilter() { renderBulkGrid(); }
function toggleBulk(el) {
    var id = parseInt(el.getAttribute('data-id'), 10);
    var ix = bulkSelected.indexOf(id);
    if (ix === -1) bulkSelected.push(id); else bulkSelected.splice(ix, 1);
    renderBulkGrid();
    renderBulkChips();
}
function renderBulkChips() {
    var h = '';
    for (var i = 0; i < bulkSelected.length; i++) {
        var idx = -1;
        for (var j = 0; j < bulkProducts.length; j++) if (bulkProducts[j].id === bulkSelected[i]) { idx = j; break; }
        if (idx === -1) continue;
        var p = bulkProducts[idx];
        h += '<span style="display:inline-flex;align-items:center;gap:6px;background:rgba(var(--accent-rgb),.12);border:1px solid rgba(var(--accent-rgb),.3);color:#a5b4fc;border-radius:8px;padding:5px 10px;font-size:12px;font-weight:700;">';
        if (p.image) h += '<img src="' + escHtml(p.image) + '" style="width:18px;height:18px;border-radius:4px;object-fit:cover;">';
        else h += '<i class="fa-solid fa-box-open" style="font-size:12px;"></i>';
        h += escHtml(p.name);
        h += '<button type="button" onclick="event.stopPropagation();removeBulk(' + p.id + ')" style="background:none;border:none;color:#f87171;cursor:pointer;font-size:12px;padding:0;line-height:1;"><i class="fa-solid fa-xmark"></i></button>';
        h += '</span>';
    }
    bulkChips.innerHTML = h || '<span style="color:var(--dim);font-size:12px;font-style:italic;">' + <?= json_encode(__('aprod.none_selected')) ?> + '</span>';
    if (bulkStockCountEl) bulkStockCountEl.textContent = '(' + bulkSelected.length + ')';
    if (bulkCountSpan) bulkCountSpan.textContent = '(' + bulkSelected.length + ')';
}
function removeBulk(id) {
    var ix = bulkSelected.indexOf(id);
    if (ix !== -1) bulkSelected.splice(ix, 1);
    renderBulkGrid();
    renderBulkChips();
}
function openBulkPicker() {
    renderBulkGrid();
    renderBulkChips();
    bulkPickerModal.style.display = 'flex';
    document.getElementById('bulkPickerSearch').value = '';
    setTimeout(function(){ document.getElementById('bulkPickerSearch').focus(); }, 60);
}
function closeBulkPicker() { bulkPickerModal.style.display = 'none'; }
function confirmBulkPicker() {
    if (!bulkSelected.length) { alert(<?= json_encode(__('coupon.need_product')) ?>); return; }
    closeBulkPicker();
    renderBulkChips();
    document.getElementById('modalBulkStock').classList.remove('hidden');
}
function openBulkStockModal() {
    document.getElementById('bulkStockContents').value = '';
    renderBulkChips();
    var eligible = bulkProducts.some(function(p){ return p.stock_type === 'limited'; });
    if (!eligible) { alert(<?= json_encode(__('aprod.no_limited')) ?>); return; }
    if (!bulkSelected.length) { openBulkPicker(); return; }
    document.getElementById('modalBulkStock').classList.remove('hidden');
}
function closeBulkStockModal() { document.getElementById('modalBulkStock').classList.add('hidden'); }
function bulkAddContents() {
    var ids = [];
    for (var i = 0; i < bulkSelected.length; i++) {
        for (var j = 0; j < bulkProducts.length; j++) {
            if (bulkProducts[j].id === bulkSelected[i] && bulkProducts[j].stock_type === 'limited') { ids.push(bulkSelected[i]); break; }
        }
    }
    var contents = document.getElementById('bulkStockContents').value.trim();
    if (!ids.length) { alert(<?= json_encode(__('aprod.pick_limited')) ?>); return; }
    if (!contents) { alert(<?= json_encode(__('aprod.contents_required')) ?>); return; }
    postStock('stock_bulk_items', {product_ids: ids.join(','), contents: contents}).then(function(d){
        if (d.ok || d.success) { alert(d.msg || d.message); closeBulkStockModal(); location.reload(); }
    });
}
function bulkSetUnlimited() {
    var ids = bulkSelected;
    if (!ids.length) { alert(<?= json_encode(__('aprod.pick_first')) ?>); return; }
    if (!confirm(<?= json_encode(__('aprod.bulk_unlimited_confirm')) ?>)) return;
    postStock('stock_bulk_off', {product_ids: ids.join(',')}).then(function(d){
        if (d.ok || d.success) { alert(d.msg || d.message); closeBulkStockModal(); location.reload(); }
    });
}
</script>

<div id="modalVersions" class="nxs-anim hidden" style="position:fixed;inset:0;z-index:1200;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;padding:16px;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;max-width:640px;max-height:90vh;display:flex;flex-direction:column;overflow:hidden;">
        <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:10px;">
            <span style="font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;min-width:0;">
                <i class="fa-solid fa-code-branch" style="color:var(--accent);flex-shrink:0;"></i>
                <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= __('aprod.versions_title') ?> <span id="verModalName">-</span></span>
            </span>
            <div style="display:flex;gap:8px;flex-shrink:0;">
                <button type="button" onclick="verEditOpen(0)" class="btn-admin btn-primary-admin" style="font-size:12px;padding:7px 14px;"><i class="fa-solid fa-plus"></i> <?= __('aprod.new') ?></button>
                <button type="button" onclick="closeVersionModal()" style="background:none;border:none;color:var(--muted);font-size:18px;cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            </div>
        </div>
        <div id="verList" style="padding:16px 20px;overflow-y:auto;display:flex;flex-direction:column;gap:10px;"></div>
    </div>
</div>

<div id="modalVersionEdit" class="nxs-anim hidden" style="position:fixed;inset:0;z-index:1300;background:rgba(0,0,0,.85);display:flex;align-items:center;justify-content:center;padding:16px;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;max-width:680px;max-height:92vh;display:flex;flex-direction:column;overflow:hidden;">
        <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;">
            <span style="font-size:15px;font-weight:800;" id="verEditTitle"><?= __('aprod.ver_add_title') ?></span>
            <button type="button" onclick="closeVersionEdit()" style="background:none;border:none;color:var(--muted);font-size:18px;cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div style="padding:18px 20px;overflow-y:auto;">
            <input type="hidden" id="verEditId" value="0">
            <div style="display:grid;grid-template-columns:170px 1fr;gap:12px;margin-bottom:14px;" id="verEditGrid">
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.ver_version') ?></label>
                    <input type="text" id="verEditVersion" maxlength="20" placeholder="1.0.1" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                </div>
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.ver_summary') ?></label>
                    <input type="text" id="verEditSummary" maxlength="255" placeholder="<?= __('aprod.ver_summary_ph') ?>" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                </div>
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aprod.ver_detail') ?></label>
                <?php render_editor('verEditBody', '', '200px', 'ver_changelog'); ?>
            </div>
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:12px;font-weight:700;">
                <input type="checkbox" id="verEditFile" checked style="width:16px;height:16px;accent-color:var(--accent);"> <?= __('aprod.ver_notify') ?>
            </label>
        </div>
        <div style="display:flex;gap:10px;padding:14px 20px;border-top:1px solid var(--border);">
            <button type="button" onclick="verEditSave()" class="btn-admin btn-primary-admin" style="flex:1;justify-content:center;"><i class="fa-solid fa-floppy-disk"></i> <?= __('msg.save') ?></button>
            <button type="button" onclick="closeVersionEdit()" class="btn-admin btn-ghost-admin"><?= __('support.cancel') ?></button>
        </div>
    </div>
</div>

<script>
var verPid = 0;
function verPost(data) {
    return fetch('/action.php', {method:'POST', body:new URLSearchParams(data)})
        .then(function(r){ return r.json(); })
        .then(function(d){ if(!d.ok) alert(d.msg || <?= json_encode(__('topup.error')) ?>); return d; })
        .catch(function(){ alert(<?= json_encode(__('aprod.req_fail_short')) ?>); return {ok:false}; });
}
function openVersionModal(pid) {
    verPid = pid;
    document.getElementById('verModalName').textContent = '#'+pid;
    document.getElementById('verList').innerHTML = '<div style="text-align:center;color:var(--muted);padding:24px;font-size:13px;">' + <?= json_encode(__('aprod.loading')) ?> + '</div>';
    document.getElementById('modalVersions').classList.remove('hidden');
    verPost({action:'version_list', product_id:pid}).then(function(d){
        if (!d.ok) return;
        document.getElementById('verModalName').textContent = (d.product && d.product.name) ? d.product.name : '#'+pid;
        renderVerList(d.versions || []);
    });
}
function renderVerList(rows) {
    var box = document.getElementById('verList');
    if (!rows.length) { box.innerHTML = '<div style="text-align:center;color:var(--muted);padding:28px;font-size:13px;"><i class="fa-solid fa-code-branch" style="font-size:26px;display:block;margin-bottom:8px;opacity:.4;"></i>' + <?= json_encode(__('aprod.ver_empty')) ?> + '</div>'; return; }
    var h = '';
    for (var i = 0; i < rows.length; i++) {
        var v = rows[i];
        var sum = (v.summary || <?= json_encode(__('aprod.ver_default_summary')) ?>).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
        h += '<div style="border:1px solid var(--border);border-radius:12px;padding:12px 14px;background:var(--bg-surface);">';
        h += '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">';
        h += '<span style="font-size:11px;font-weight:800;background:rgba(var(--accent-rgb),.12);color:#a5b4fc;padding:3px 10px;border-radius:999px;">v' + String(v.version || '?').replace(/</g,'&lt;') + '</span>';
        if (v.has_file == 1) h += '<span style="font-size:10px;font-weight:800;background:rgba(34,197,94,.12);color:#4ade80;padding:3px 10px;border-radius:999px;"><i class="fa-solid fa-bell"></i> ' + <?= json_encode(__('aprod.notified')) ?> + '</span>';
        else h += '<span style="font-size:10px;font-weight:800;background:rgba(255,255,255,.06);color:var(--muted);padding:3px 10px;border-radius:999px;">' + <?= json_encode(__('aprod.silent')) ?> + '</span>';
        h += '<span style="font-size:11px;color:var(--muted);margin-left:auto;">' + String(v.created_at || '').substring(0,16).replace('T',' ') + '</span>';
        h += '</div>';
        h += '<div style="font-size:13px;font-weight:600;margin:8px 0;">' + sum + '</div>';
        h += '<div style="display:flex;gap:6px;justify-content:flex-end;">';
        h += '<button type="button" onclick="verEditOpen(' + v.id + ')" class="btn-admin btn-ghost-admin" style="padding:6px 12px;font-size:12px;"><i class="fa-solid fa-pen"></i></button>';
        h += '<button type="button" onclick="verDelete(' + v.id + ')" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;padding:6px 12px;font-size:12px;border:1px solid rgba(239,68,68,.2);"><i class="fa-solid fa-trash"></i></button>';
        h += '</div></div>';
    }
    box.innerHTML = h;
}
function closeVersionModal() { document.getElementById('modalVersions').classList.add('hidden'); }
function verEditOpen(id) {
    document.getElementById('verEditId').value = id || 0;
    document.getElementById('verEditTitle').textContent = id ? <?= json_encode(__('aprod.ver_edit_title')) ?> : <?= json_encode(__('aprod.ver_new_title')) ?>;
    if (!id) {
        document.getElementById('verEditVersion').value = '';
        document.getElementById('verEditSummary').value = '';
        var eb = document.getElementById('edBody-verEditBody');
        if (eb) eb.innerHTML = '';
        document.getElementById('verEditFile').checked = true;
        document.getElementById('modalVersionEdit').classList.remove('hidden');
        return;
    }
    verPost({action:'version_list', product_id:verPid}).then(function(d){
        if (!d.ok) return;
        var rows = d.versions || [];
        for (var i = 0; i < rows.length; i++) {
            if (parseInt(rows[i].id) === parseInt(id)) {
                document.getElementById('verEditVersion').value = rows[i].version || '';
                document.getElementById('verEditSummary').value = rows[i].summary || '';
                var eb2 = document.getElementById('edBody-verEditBody');
                if (eb2) eb2.innerHTML = rows[i].changelog || '';
                document.getElementById('verEditFile').checked = rows[i].has_file == 1;
                break;
            }
        }
        document.getElementById('modalVersionEdit').classList.remove('hidden');
    });
}
function closeVersionEdit() { document.getElementById('modalVersionEdit').classList.add('hidden'); }
function verEditSave() {
    var eb = document.getElementById('edBody-verEditBody');
    var ta = document.getElementById('verEditBody');
    if (eb && ta) ta.value = eb.innerHTML;
    var fd = {
        action:'version_save',
        id: document.getElementById('verEditId').value,
        product_id: verPid,
        version: document.getElementById('verEditVersion').value.trim(),
        summary: document.getElementById('verEditSummary').value.trim(),
        changelog: ta ? ta.value : '',
        has_file: document.getElementById('verEditFile').checked ? '1' : '0'
    };
    verPost(fd).then(function(d){
        if (d.ok) { closeVersionEdit(); openVersionModal(verPid); }
    });
}
function verDelete(id) {
    if (!confirm(<?= json_encode(__('aprod.ver_del_confirm')) ?>)) return;
    verPost({action:'version_delete', id:id}).then(function(d){
        if (d.ok) openVersionModal(verPid);
    });
}
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
