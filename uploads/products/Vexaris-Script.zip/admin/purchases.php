<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.purchases');
$activePage = 'purchases';

$msg = '';
$reopenUser = 0;

/* ── Satın alımı iptal et ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_sale'])) {
    $sid = (int)$_POST['cancel_sale'];
    $reopenUser = (int)($_POST['user_id'] ?? 0);
    try {
        $adminDb->beginTransaction();
        $st = $adminDb->prepare('SELECT user_id, product_id, price_paid, license_key FROM sales WHERE id=?');
        $st->execute([$sid]);
        $sale = $st->fetch();
        if (!$sale) {
            $adminDb->rollBack();
            $msg = ['type'=>'error','text'=>__('apurch.sale_not_found')];
        } else {
            $uid  = (int)$sale['user_id'];
            $pid  = (int)$sale['product_id'];
            $lic  = trim((string)($sale['license_key'] ?? ''));

            /* eşleşen sipariş kaydı (varsa) silinir */
            $adminDb->prepare('DELETE FROM orders WHERE user_id=? AND product_id=? ORDER BY id ASC LIMIT 1')->execute([$uid,$pid]);

            /* stok kaydı geri açılır (içerik lisans anahtarıyla eşleşiyorsa) */
            if ($lic !== '') {
                $rs = $adminDb->prepare('SELECT id FROM product_stocks WHERE product_id=? AND used_by_user=? AND used=1 AND content=? LIMIT 1');
                $rs->execute([$pid,$uid,$lic]);
                $stockId = $rs->fetchColumn();
                if ($stockId) {
                    $adminDb->prepare('UPDATE product_stocks SET used=0, used_by_user=NULL, used_at=NULL WHERE id=?')->execute([(int)$stockId]);
                    $adminDb->prepare('UPDATE products SET stock=(SELECT COUNT(*) FROM product_stocks WHERE product_id=? AND used=0) WHERE id=?')->execute([$pid,$pid]);
                }
                /* ayrı lisans tablosu satırı (kupon/manuel) varsa kaldirilir */
                $adminDb->prepare('DELETE FROM licenses WHERE product_id=? AND user_id=? AND license_key=?')->execute([$pid,$uid,$lic]);
            }

            $adminDb->prepare('DELETE FROM sales WHERE id=?')->execute([$sid]);
            $adminDb->commit();
            $msg = ['type'=>'success','text'=>__('apurch.cancel_done')];
        }
    } catch (\Throwable $e) {
        if ($adminDb->inTransaction()) $adminDb->rollBack();
        error_log('[Vexaris] purchases cancel_sale: ' . $e->getMessage());
        $msg = ['type'=>'error','text'=>__('apurch.cancel_fail')];
    }
}

/* ── Kupon / manuel lisansı iptal et ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_license'])) {
    $lid = (int)$_POST['cancel_license'];
    $reopenUser = (int)($_POST['user_id'] ?? 0);
    try {
        $adminDb->prepare('DELETE FROM licenses WHERE id=?')->execute([$lid]);
        $msg = ['type'=>'success','text'=>__('apurch.license_removed')];
    } catch (\Throwable $e) {
        error_log('[VNC] purchases cancel_license: ' . $e->getMessage());
        $msg = ['type'=>'error','text'=>__('apurch.license_remove_fail')];
    }
}

/* ── Kullanıcıya ürün tanımla (admin grant) ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['grant_product'])) {
    $uid  = (int)($_POST['grant_user_id'] ?? 0);
    $pid  = (int)($_POST['grant_product_id'] ?? 0);
    $qty  = min(50, max(1, (int)($_POST['grant_qty'] ?? 1)));
    $reopenUser = $uid;
    try {
        if (!$uid || !$pid) { $msg = ['type'=>'error','text'=>__('apurch.pick_user_product')]; }
        else {
            $us = $adminDb->prepare('SELECT username FROM users WHERE id=?');
            $us->execute([$uid]);
            if (!$us->fetch()) { $msg = ['type'=>'error','text'=>__('err.user_missing')]; }
            else {
                $ps = $adminDb->prepare('SELECT id,name,stock_type FROM products WHERE id=? AND is_active=1 AND is_hidden=0');
                $ps->execute([$pid]);
                $prod = $ps->fetch();
                if (!$prod) { $msg = ['type'=>'error','text'=>__('shop.product_missing')]; }
                else {
                    if (($prod['stock_type'] ?? 'unlimited') === 'limited' && stock_items_available($adminDb, $pid) < $qty) {
                        $msg = ['type'=>'error','text'=>__('apurch.low_stock', ['n' => stock_items_available($adminDb, $pid)])];
                    } else {
                        $adminDb->beginTransaction();
                        $grantCur = function_exists('store_currency') ? store_currency() : 'TRY';
                        $ins = $adminDb->prepare('INSERT INTO sales (user_id,product_id,price_paid,currency,purchased_at) VALUES (?,?,0,?,NOW())');
                        $upd = $adminDb->prepare('UPDATE sales SET license_key=? WHERE id=?');
                        $names = [];
                        for ($i = 0; $i < $qty; $i++) {
                            $ins->execute([$uid,$pid,$grantCur]);
                            $sid = (int)$adminDb->lastInsertId();
                            $lic = stock_consume($adminDb, $pid, 1, $uid);
                            if ($lic !== null) $upd->execute([$lic,$sid]);
                            $names[] = $prod['name'];
                        }
                        $adminDb->commit();
                        $msg = ['type'=>'success','text'=>__('apurch.grant_done', ['product' => $prod['name'], 'qty' => $qty, 'uid' => $uid])];
                    }
                }
            }
        }
    } catch (\Throwable $e) {
        if ($adminDb->inTransaction()) $adminDb->rollBack();
        error_log('[VNC] purchases grant: ' . $e->getMessage());
        $msg = ['type'=>'error','text'=>__('apurch.grant_fail')];
    }
}

/* ── Arama ── */
$search = trim($_GET['q'] ?? '');
$searchLike = str_replace(['\\','%','_'], ['\\\\','\\%','\\_'], $search);
$userFilter = (int)($_GET['user_id'] ?? 0);

/* kullanıcı listesi (popup için) */
if (isset($_GET['ajax']) && $qUser = (int)($_GET['ajax_user'] ?? 0)) {
    header('Content-Type: application/json');
    try {
        $out = ['ok'=>false];
        $us = $adminDb->prepare('SELECT id,username,email,avatar,balance,role,created_at FROM users WHERE id=?');
        $us->execute([$qUser]);
        $u = $us->fetch();
        if ($u) {
            $salesSt = $adminDb->prepare('SELECT s.id,s.product_id,s.price_paid,s.license_key,s.purchased_at,p.name AS product_name FROM sales s LEFT JOIN products p ON p.id=s.product_id WHERE s.user_id=? ORDER BY s.purchased_at DESC LIMIT 100');
            $salesSt->execute([$qUser]);
            $licSt = $adminDb->prepare('SELECT l.id,l.product_id,l.license_key,l.status,l.created_at,p.name AS product_name FROM licenses l LEFT JOIN products p ON p.id=l.product_id WHERE l.user_id=? ORDER BY l.created_at DESC LIMIT 100');
            $licSt->execute([$qUser]);
            $cuSt = $adminDb->prepare('SELECT c.code, cu.used_at FROM coupon_usages cu JOIN coupons c ON c.id=cu.coupon_id WHERE cu.user_id=? ORDER BY cu.used_at DESC LIMIT 50');
            $cuSt->execute([$qUser]);
            $out = [
                'ok'=>true,
                'user'=>$u,
                'sales'=>$salesSt->fetchAll(),
                'licenses'=>$licSt->fetchAll(),
                'coupons'=>$cuSt->fetchAll(),
            ];
        }
        echo json_encode($out, JSON_UNESCAPED_UNICODE);
    } catch (\Throwable $e) {
        echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
    }
    exit;
}

/* satışlar */
if ($search) {
    $st = $adminDb->prepare('SELECT s.id,s.user_id,s.product_id,s.price_paid,s.license_key,s.purchased_at,u.username,p.name AS product_name FROM sales s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN products p ON p.id=s.product_id WHERE u.username LIKE ? OR u.email LIKE ? OR p.name LIKE ? ORDER BY s.purchased_at DESC');
    $st->execute(["%$searchLike%","%$searchLike%","%$searchLike%"]);
} else {
    $st = $adminDb->query('SELECT s.id,s.user_id,s.product_id,s.price_paid,s.license_key,s.purchased_at,u.username,p.name AS product_name FROM sales s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN products p ON p.id=s.product_id ORDER BY s.purchased_at DESC LIMIT 200');
}
$sales = $st->fetchAll();

/* lisanslar (kupon / manuel) */
if ($search) {
    $ls = $adminDb->prepare('SELECT l.id,l.user_id,l.product_id,l.license_key,l.status,l.created_at,u.username,p.name AS product_name FROM licenses l LEFT JOIN users u ON u.id=l.user_id LEFT JOIN products p ON p.id=l.product_id WHERE u.username LIKE ? OR u.email LIKE ? OR p.name LIKE ? ORDER BY l.created_at DESC');
    $ls->execute(["%$searchLike%","%$searchLike%","%$searchLike%"]);
} else {
    $ls = $adminDb->query('SELECT l.id,l.user_id,l.product_id,l.license_key,l.status,l.created_at,u.username,p.name AS product_name FROM licenses l LEFT JOIN users u ON u.id=l.user_id LEFT JOIN products p ON p.id=l.product_id ORDER BY l.created_at DESC LIMIT 200');
}
$licenses = $ls->fetchAll();

/* kullanıcı (basic liste) */
if ($search) {
    $us = $adminDb->prepare('SELECT id,username,email,avatar,role FROM users WHERE username LIKE ? OR email LIKE ? ORDER BY username LIMIT 200');
    $us->execute(["%$searchLike%","%$searchLike%"]);
} else {
    $us = $adminDb->query('SELECT id,username,email,avatar,role FROM users ORDER BY username LIMIT 200');
}
$users = $us->fetchAll();

$products = $adminDb->query('SELECT id,name,stock_type FROM products WHERE is_active=1 AND is_hidden=0 ORDER BY name')->fetchAll();

include __DIR__ . '/includes/layout.php';
?>
<style>
.pu-user-row:hover{border-color:rgba(var(--accent-rgb,99,102,241),.35);background:var(--bg-hover);}
.pu-toolbar-form{display:flex;gap:8px;align-items:center;flex:1;min-width:220px;max-width:520px;flex-wrap:wrap;}
.pu-users-list{display:flex;flex-direction:column;gap:6px;max-height:340px;overflow-y:auto;padding-right:4px;}
.pu-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:flex-start;}
#userPopup .pu-head{position:sticky;top:0;background:var(--bg-card);border-bottom:1px solid var(--border);padding:18px 24px;display:flex;align-items:center;gap:14px;justify-content:space-between;z-index:2;flex-wrap:wrap;}
@media(max-width:900px){.pu-grid{grid-template-columns:1fr;}}
@media(max-width:640px){
  .pu-toolbar-form{min-width:0;max-width:none;width:100%;}
  #userPopup .pu-head{padding:14px 16px;gap:10px;}
  #puBody{padding:16px!important;}
  .admin-card-header{flex-wrap:wrap;gap:10px;}
}
</style>
<?php if ($msg): ?>
<div style="background:<?= $msg['type']==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;
     border:1px solid <?= $msg['type']==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;
     color:<?= $msg['type']==='success'?'#4ade80':'#f87171' ?>;
     padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;
     margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid <?= $msg['type']==='success'?'fa-circle-check':'fa-circle-xmark' ?>"></i>
    <?= e($msg['text']) ?>
</div>
<?php endif; ?>

<!-- Üst araç çubuğu -->
<div class="admin-card" style="padding:18px;margin-bottom:20px;">
    <div style="display:flex;gap:14px;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;">
        <div>
            <div style="font-size:15px;font-weight:800;"><i class="fa-solid fa-bag-shopping" style="color:var(--accent);margin-right:8px;"></i><?= __('amenu.purchases') ?></div>
            <div style="font-size:12px;color:var(--muted);margin-top:4px;"><?= __('apurch.subtitle') ?></div>
        </div>
        <form method="GET" class="pu-toolbar-form">
            <input type="text" name="q" value="<?= e($search) ?>" placeholder="<?= __('apurch.search_ph') ?>"
                   style="flex:1;min-width:0;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:9px 14px;color:var(--text);font-size:13px;outline:none;">
            <button type="submit" class="btn-admin btn-ghost-admin" style="padding:9px 14px;flex-shrink:0;"><i class="fa-solid fa-search"></i> <?= __('amenu.search') ?></button>
            <?php if ($search): ?>
            <a href="/admin/purchases.php" class="btn-admin btn-ghost-admin" style="padding:9px 14px;"><i class="fa-solid fa-xmark"></i> <?= __('apurch.clear') ?></a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Kullanıcıya ürün tanımla -->
<div class="admin-card" id="grantCard" style="margin-bottom:20px;">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-box-open" style="color:#22c55e;margin-right:8px;"></i><?= __('apurch.grant_title') ?></span>
        <button class="btn-admin btn-ghost-admin" style="padding:6px 12px;font-size:12px;" onclick="document.getElementById('grantCardBody').style.display = document.getElementById('grantCardBody').style.display==='none'?'grid':'none'">
            <i class="fa-solid fa-chevron-down"></i>
        </button>
    </div>
    <div id="grantCardBody">
        <form method="POST" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">
            <?= csrf_field() ?>
            <input type="hidden" name="grant_product" value="1">
            <div style="flex:1;min-width:180px;">
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('apurch.user') ?></label>
                <select name="grant_user_id" id="grantUserId" required
                        style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:9px 12px;color:var(--text);font-size:13px;outline:none;">
                    <option value=""><?= __('apurch.select') ?></option>
                    <?php foreach ($users as $u): ?>
                    <option value="<?= $u['id'] ?>"><?= e($u['username']) ?> (#<?= $u['id'] ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="flex:1.4;min-width:180px;">
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('apurch.product') ?></label>
                <select name="grant_product_id" id="grantProductId" required
                        style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:9px 12px;color:var(--text);font-size:13px;outline:none;">
                    <option value=""><?= __('apurch.select') ?></option>
                    <?php foreach ($products as $p): ?>
                    <option value="<?= $p['id'] ?>"><?= e($p['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="width:90px;">
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('apurch.qty') ?></label>
                <input type="number" name="grant_qty" min="1" max="50" value="1"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:9px 12px;color:var(--text);font-size:13px;outline:none;">
            </div>
            <button type="submit" class="btn-admin btn-success-admin" style="padding:10px 18px;">
                <i class="fa-solid fa-gift"></i> <?= __('apurch.assign') ?>
            </button>
        </form>
    </div>
</div>

<!-- Kullanıcılar listesi -->
<div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-users" style="color:var(--accent);margin-right:8px;"></i><?= __('amenu.users') ?> <span style="color:var(--muted);font-weight:500;">(<?= count($users) ?>)</span></span>
        <span style="font-size:11px;color:var(--muted);"><?= __('apurch.hint') ?></span>
    </div>
    <div class="pu-users-list">
        <?php foreach ($users as $u): ?>
        <div class="pu-user-row" data-uid="<?= $u['id'] ?>" data-uname="<?= htmlspecialchars($u['username'], ENT_QUOTES) ?>"
             style="display:flex;align-items:center;gap:12px;padding:9px 12px;background:var(--bg-surface);border-radius:10px;cursor:pointer;transition:border-color .15s,background .15s;border:1px solid transparent;">
            <img src="<?= e($u['avatar'] ?: 'https://minotar.net/avatar/user.png') ?>" onerror="this.src='https://minotar.net/avatar/user.png'"
                 style="width:30px;height:30px;border-radius:50%;image-rendering:pixelated;border:1.5px solid var(--border);" alt="">
            <div style="flex:1;min-width:0;">
                <div style="font-size:12px;font-weight:700;"><?= e($u['username']) ?></div>
                <div style="font-size:10px;color:var(--muted);"><?= e($u['email']) ?></div>
            </div>
            <i class="fa-solid fa-chevron-right" style="color:var(--dim);font-size:11px;"></i>
        </div>
        <?php endforeach; ?>
        <?php if (empty($users)): ?>
        <div style="text-align:center;color:var(--muted);padding:24px;font-size:12px;"><?= __('err.user_missing') ?></div>
        <?php endif; ?>
    </div>
</div>

<div class="pu-grid">

    <div class="admin-card" style="margin-bottom:0;min-width:0;">
        <div class="admin-card-header">
            <span class="admin-card-title"><i class="fa-solid fa-receipt" style="color:#22c55e;margin-right:8px;"></i><?= __('apurch.purchases') ?> <span style="color:var(--muted);font-weight:500;">(<?= count($sales) ?>)</span></span>
        </div>
        <div style="overflow-x:auto;">
        <table class="admin-table">
            <thead><tr><th>#</th><th><?= __('apurch.product') ?></th><th><?= __('apurch.user') ?></th><th><?= __('apurch.col_amount') ?></th><th><?= __('apurch.col_license') ?></th><th><?= __('apurch.col_date') ?></th><th><?= __('adash.th_action') ?></th></tr></thead>
            <tbody>
            <?php foreach ($sales as $s): ?>
            <tr>
                <td style="color:var(--muted);font-size:11px;"><?= $s['id'] ?></td>
                <td style="font-weight:700;font-size:12px;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($s['product_name'] ?? '—') ?></td>
                    <td><a href="#" onclick="event.preventDefault();openUserPopup(<?= (int)$s['user_id'] ?>, <?= json_encode($s['username'] ?? '', JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>);" style="color:var(--accent);font-weight:700;font-size:12px;"><?= e($s['username'] ?? '—') ?></a></td>
                <td style="font-weight:800;font-size:12px;color:<?= (float)$s['price_paid']>0?'#4ade80':'var(--muted)' ?>;"><?= (float)$s['price_paid']>0?fmt_money((float)$s['price_paid']):__('home.free') ?></td>
                <td><code style="word-break:break-all;white-space:normal;display:inline-block;max-width:100%;background:rgba(var(--accent-rgb),.1);color:#a5b4fc;padding:2px 6px;border-radius:6px;font-size:11px;"><?= e($s['license_key'] ?: '—') ?></code></td>
                <td style="color:var(--muted);font-size:11px;white-space:nowrap;"><?= date('d.m.Y H:i', strtotime($s['purchased_at'])) ?></td>
                <td style="white-space:nowrap;">
                    <form method="POST" onsubmit="return confirm('<?= __('apurch.confirm_cancel_sale') ?>');" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="cancel_sale" value="<?= $s['id'] ?>">
                        <input type="hidden" name="user_id" value="<?= (int)$s['user_id'] ?>">
                        <button type="submit" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;padding:5px 10px;font-size:12px;border:1px solid rgba(239,68,68,.2);"><i class="fa-solid fa-trash"></i> <?= __('topup.cancel') ?></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($sales)): ?>
            <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:28px;"><?= __('apurch.no_sales') ?></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>

    <!-- Kupon / manuel lisanslar -->
<div class="admin-card" style="margin-bottom:0;min-width:0;">
        <div class="admin-card-header">
            <span class="admin-card-title"><i class="fa-solid fa-ticket" style="color:#facc15;margin-right:8px;"></i><?= __('apurch.coupon_title') ?> <span style="color:var(--muted);font-weight:500;">(<?= count($licenses) ?>)</span></span>
        </div>
        <div style="overflow-x:auto;">
        <table class="admin-table">
            <thead><tr><th><?= __('apurch.col_key') ?></th><th><?= __('apurch.user') ?></th><th><?= __('apurch.product') ?></th><th><?= __('adash.th_status') ?></th><th><?= __('apurch.col_date') ?></th><th><?= __('adash.th_action') ?></th></tr></thead>
            <tbody>
            <?php foreach ($licenses as $l): ?>
            <tr>
                <td><code style="word-break:break-all;white-space:normal;display:inline-block;max-width:100%;background:rgba(var(--accent-rgb),.1);color:#a5b4fc;padding:2px 6px;border-radius:6px;font-size:11px;"><?= e($l['license_key']) ?></code></td>
                    <td><a href="#" onclick="event.preventDefault();openUserPopup(<?= (int)$l['user_id'] ?>, <?= json_encode($l['username'] ?? '', JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>);" style="color:var(--accent);font-weight:600;font-size:12px;"><?= e($l['username'] ?? '—') ?></a></td>
                <td style="font-size:12px;"><?= e($l['product_name'] ?? '—') ?></td>
                <td><span class="badge <?= $l['status']==='active'?'badge-green':'badge-red' ?>"><?= $l['status']==='active'?__('adash.status_active'):__('apurch.suspended') ?></span></td>
                <td style="color:var(--muted);font-size:11px;white-space:nowrap;"><?= date('d.m.Y', strtotime($l['created_at'])) ?></td>
                <td style="white-space:nowrap;">
                    <form method="POST" onsubmit="return confirm('<?= __('apurch.confirm_cancel_license') ?>');" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="cancel_license" value="<?= $l['id'] ?>">
                        <input type="hidden" name="user_id" value="<?= (int)$l['user_id'] ?>">
                        <button type="submit" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;padding:5px 10px;font-size:12px;border:1px solid rgba(239,68,68,.2);"><i class="fa-solid fa-trash"></i> <?= __('topup.cancel') ?></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($licenses)): ?>
            <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:28px;"><?= __('apurch.no_licenses') ?></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>

</div>

<!-- Kullanıcı popup -->
<div id="userPopup" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:1001;align-items:center;justify-content:center;"
     onclick="if(event.target===this)closeUserPopup()">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:720px;max-width:95vw;max-height:92vh;overflow-y:auto;animation:fadeSlideUp .25s ease;">
        <div class="pu-head">
            <div style="display:flex;align-items:center;gap:12px;min-width:0;">
                <img id="puAvatar" src="https://minotar.net/avatar/user.png" onerror="this.src='https://minotar.net/avatar/user.png'"
                     style="width:44px;height:44px;border-radius:50%;image-rendering:pixelated;border:2px solid rgba(var(--accent-rgb),.4);" alt="">
                <div>
                    <div id="puName" style="font-size:15px;font-weight:800;">—</div>
                    <div id="puMeta" style="font-size:11px;color:var(--muted);">—</div>
                </div>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
                <div id="puBalance" style="font-size:12px;font-weight:800;color:#fbc853;background:rgba(251,200,83,.1);border:1px solid rgba(251,200,83,.2);padding:6px 12px;border-radius:8px;"><?= __('panel.balance') ?>: <?= fmt_money(0) ?></div>
                <button onclick="closeUserPopup()" style="background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer;">&times;</button>
            </div>
        </div>
        <div id="puBody" style="padding:24px;">
            <div style="text-align:center;padding:40px;color:var(--muted);font-size:13px;">
                <i class="fa-solid fa-spinner fa-spin"></i> <?= __('apurch.loading') ?>
            </div>
        </div>
    </div>
</div>

<script>
function openUserPopup(uid, username) {
function nxEsc(s){ return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
    var NX_PURCH = <?= json_encode(['loading' => __('apurch.loading'), 'load_fail' => __('apurch.load_fail'), 'registered' => __('apurch.registered'), 'balance' => __('panel.balance'), 'chip_purchases' => __('apurch.chip_purchases'), 'chip_spent' => __('apurch.chip_spent'), 'chip_license' => __('apurch.col_license'), 'chip_coupon' => __('apurch.chip_coupon'), 'grant_title' => __('apurch.grant_popup_title'), 'select_product' => __('apurch.select_product'), 'purchases' => __('amenu.purchases'), 'no_user_sales' => __('apurch.no_user_sales'), 'th_product' => __('apurch.product'), 'col_amount' => __('apurch.col_amount'), 'col_license' => __('apurch.col_license'), 'col_date' => __('apurch.col_date'), 'free' => __('home.free'), 'confirm_cancel' => __('apurch.confirm_cancel_sale_short'), 'cancel_title' => __('apurch.cancel_title'), 'licenses' => __('amenu.licenses'), 'no_license_rec' => __('apurch.no_license_rec'), 'th_key' => __('apurch.col_key_acc'), 'active' => __('adash.status_active'), 'suspended' => __('apurch.suspended'), 'confirm_remove' => __('apurch.confirm_remove_license'), 'remove_title' => __('apurch.remove_title'), 'used_coupons' => __('apurch.used_coupons'), 'no_coupon_use' => __('apurch.no_coupon_use')]) ?>;
    var pop = document.getElementById('userPopup');
    document.getElementById('puName').textContent = username || ('ID #' + uid);
    document.getElementById('puBody').innerHTML = '<div style="text-align:center;padding:40px;color:var(--muted);font-size:13px;"><i class="fa-solid fa-spinner fa-spin"></i> ' + NX_PURCH.loading + '</div>';
    pop.style.display = 'flex';
    fetch('/admin/purchases.php?ajax=1&ajax_user=' + uid)
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (!d.ok) { document.getElementById('puBody').innerHTML = '<div style="text-align:center;padding:40px;color:#f87171;font-size:13px;">' + NX_PURCH.load_fail + '</div>'; return; }
            var u = d.user, html = '';
            document.getElementById('puName').textContent = u.username;
            document.getElementById('puMeta').textContent = 'ID #' + u.id + ' · ' + (u.email||'') + ' · ' + NX_PURCH.registered + ' ' + (u.created_at||'').slice(0,10);
            document.getElementById('puAvatar').src = u.avatar || 'https://minotar.net/avatar/user.png';
            document.getElementById('puBalance').textContent = NX_PURCH.balance + ': ' + window.nxFmt((parseFloat(u.balance)||0).toFixed(2));

            /* başlık çipleri */
            var spent = d.sales.reduce(function(a,s){ return a + parseFloat(s.price_paid||0); }, 0);
            html += '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;">'
                + '<span style="font-size:12px;font-weight:800;background:rgba(34,197,94,.12);color:#4ade80;padding:7px 14px;border-radius:10px;">' + d.sales.length + ' ' + NX_PURCH.chip_purchases + '</span>'
                + '<span style="font-size:12px;font-weight:800;background:rgba(var(--accent-rgb),.12);color:#a5b4fc;padding:7px 14px;border-radius:10px;">' + window.nxFmt(spent.toFixed(2)) + ' ' + NX_PURCH.chip_spent + '</span>'
                + '<span style="font-size:12px;font-weight:800;background:rgba(251,200,83,.12);color:#fbc853;padding:7px 14px;border-radius:10px;">' + d.licenses.length + ' ' + NX_PURCH.chip_license + '</span>'
                + '<span style="font-size:12px;font-weight:800;background:rgba(250,204,21,.12);color:#facc15;padding:7px 14px;border-radius:10px;">' + d.coupons.length + ' ' + NX_PURCH.chip_coupon + '</span>'
                + '</div>';

            /* ürün tanımla formu */
            html += '<div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:14px;padding:16px;margin-bottom:20px;">'
                + '<div style="font-size:13px;font-weight:800;margin-bottom:12px;"><i class="fa-solid fa-gift" style="color:#22c55e;margin-right:6px;"></i>' + NX_PURCH.grant_title + '</div>'
                + '<form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">'
                + '<input type="hidden" name="grant_product" value="1"><input type="hidden" name="grant_user_id" value="' + parseInt(u.id,10) + '">'
                + '<input type="hidden" name="user_id" value="' + parseInt(u.id,10) + '">'
                + '<?= csrf_field() ?>'
                + '<select name="grant_product_id" required style="flex:1;min-width:160px;background:var(--bg-card);border:1px solid var(--border);border-radius:9px;padding:9px 12px;color:var(--text);font-size:13px;outline:none;">'
                + '<option value="">' + NX_PURCH.select_product + '</option>'
                + '<?php foreach ($products as $p): ?>'
                + '<option value="<?= $p['id'] ?>"><?= e($p['name']) ?></option>'
                + '<?php endforeach; ?>'
                + '</select>'
                + '<input type="number" name="grant_qty" min="1" max="50" value="1" style="width:70px;background:var(--bg-card);border:1px solid var(--border);border-radius:9px;padding:9px 12px;color:var(--text);font-size:13px;outline:none;">'
                + '<button type="submit" class="btn-admin btn-success-admin" style="padding:9px 16px;"><i class="fa-solid fa-gift"></i> <?= __('apurch.assign') ?></button>'
                + '</form></div>';

            /* satın alımlar */
            html += '<div style="font-size:13px;font-weight:800;margin-bottom:10px;"><i class="fa-solid fa-receipt" style="color:#22c55e;margin-right:6px;"></i>' + NX_PURCH.purchases + ' (' + d.sales.length + ')</div>';
            if (d.sales.length === 0) { html += '<div style="font-size:12px;color:var(--muted);padding:14px;background:var(--bg-surface);border-radius:10px;margin-bottom:18px;">' + NX_PURCH.no_user_sales + '</div>'; }
            else {
                html += '<div style="overflow-x:auto;margin-bottom:20px;border:1px solid var(--border);border-radius:12px;"><table class="admin-table"><thead><tr><th>' + NX_PURCH.th_product + '</th><th>' + NX_PURCH.col_amount + '</th><th>' + NX_PURCH.col_license + '</th><th>' + NX_PURCH.col_date + '</th><th></th></tr></thead><tbody>';
                d.sales.forEach(function(s){
                    html += '<tr><td style="font-weight:700;font-size:12px;">' + nxEsc(s.product_name||'—') + '</td>'
                        + '<td style="font-weight:800;color:#4ade80;font-size:12px;">' + (parseFloat(s.price_paid)>0 ? window.nxFmt(parseFloat(s.price_paid).toFixed(2)) : NX_PURCH.free) + '</td>'
                        + '<td><code style="word-break:break-all;white-space:normal;display:inline-block;max-width:100%;background:rgba(var(--accent-rgb),.1);color:#a5b4fc;padding:2px 6px;border-radius:6px;font-size:11px;">' + nxEsc(s.license_key||'—') + '</code></td>'
                        + '<td style="color:var(--muted);font-size:11px;">' + nxEsc((s.purchased_at||'').slice(0,16)) + '</td>'
                        + '<td><form method="POST" onsubmit="return confirm(\'' + NX_PURCH.confirm_cancel + '\');" style="margin:0;"><?= csrf_field() ?><input type="hidden" name="cancel_sale" value="' + parseInt(s.id,10) + '"><input type="hidden" name="user_id" value="' + parseInt(u.id,10) + '"><button type="submit" style="background:none;border:none;color:#f87171;cursor:pointer;font-size:13px;" title="' + NX_PURCH.cancel_title + '"><i class="fa-solid fa-ban"></i></button></form></td></tr>';
                });
                html += '</tbody></table></div>';
            }

            /* kupon lisansları */
            html += '<div style="font-size:13px;font-weight:800;margin-bottom:10px;"><i class="fa-solid fa-key" style="color:#fbc853;margin-right:6px;"></i>' + NX_PURCH.licenses + ' (' + d.licenses.length + ')</div>';
            if (d.licenses.length === 0) { html += '<div style="font-size:12px;color:var(--muted);padding:14px;background:var(--bg-surface);border-radius:10px;margin-bottom:14px;">' + NX_PURCH.no_license_rec + '</div>'; }
            else {
                html += '<div style="overflow-x:auto;margin-bottom:20px;border:1px solid var(--border);border-radius:12px;"><table class="admin-table"><thead><tr><th>' + NX_PURCH.th_key + '</th><th>' + NX_PURCH.th_product + '</th><th>' + <?= json_encode(__('adash.th_status')) ?> + '</th><th>' + NX_PURCH.col_date + '</th><th></th></tr></thead><tbody>';
                d.licenses.forEach(function(l){
                    html += '<tr><td><code style="word-break:break-all;white-space:normal;display:inline-block;max-width:100%;background:rgba(var(--accent-rgb),.1);color:#a5b4fc;padding:2px 6px;border-radius:6px;font-size:11px;">' + nxEsc(l.license_key||'—') + '</code></td>'
                        + '<td style="font-size:12px;">' + nxEsc(l.product_name||'—') + '</td>'
                        + '<td><span class="badge ' + (l.status==='active'?'badge-green':'badge-red') + '">' + (l.status==='active'?NX_PURCH.active:NX_PURCH.suspended) + '</span></td>'
                        + '<td style="color:var(--muted);font-size:11px;">' + nxEsc((l.created_at||'').slice(0,10)) + '</td>'
                        + '<td><form method="POST" onsubmit="return confirm(\'' + NX_PURCH.confirm_remove + '\');" style="margin:0;"><?= csrf_field() ?><input type="hidden" name="cancel_license" value="' + parseInt(l.id,10) + '"><input type="hidden" name="user_id" value="' + parseInt(u.id,10) + '"><button type="submit" style="background:none;border:none;color:#f87171;cursor:pointer;font-size:13px;" title="' + NX_PURCH.remove_title + '"><i class="fa-solid fa-ban"></i></button></form></td></tr>';
                });
                html += '</tbody></table></div>';
            }

            /* kupon kullanımları */
            html += '<div style="font-size:13px;font-weight:800;margin-bottom:10px;"><i class="fa-solid fa-ticket" style="color:#facc15;margin-right:6px;"></i>' + NX_PURCH.used_coupons + ' (' + d.coupons.length + ')</div>';
            if (d.coupons.length === 0) { html += '<div style="font-size:12px;color:var(--muted);padding:14px;background:var(--bg-surface);border-radius:10px;">' + NX_PURCH.no_coupon_use + '</div>'; }
            else {
                html += '<div style="display:flex;flex-wrap:wrap;gap:8px;">';
                d.coupons.forEach(function(c){
                    html += '<span style="font-size:12px;font-weight:700;max-width:100%;word-break:break-all;background:rgba(250,204,21,.1);color:#facc15;padding:6px 12px;border-radius:20px;border:1px solid rgba(250,204,21,.25);">' + nxEsc(c.code) + ' · ' + nxEsc((c.used_at||'').slice(0,10)) + '</span>';
                });
                html += '</div>';
            }

            document.getElementById('puBody').innerHTML = html;
        })
        .catch(function(){ document.getElementById('puBody').innerHTML = '<div style="text-align:center;padding:30px;color:#f87171;font-size:13px;">' + NX_PURCH.load_fail + '</div>'; });
}
function closeUserPopup(){ document.getElementById('userPopup').style.display = 'none'; }
document.addEventListener('DOMContentLoaded', function(){
    document.querySelectorAll('.pu-user-row').forEach(function(row){
        row.addEventListener('click', function(){
            openUserPopup(parseInt(this.getAttribute('data-uid'),10), this.getAttribute('data-uname'));
        });
    });
});
<?php if ($reopenUser > 0): ?>
(function(){ openUserPopup(<?= $reopenUser ?>, ''); })();
<?php endif; ?>
</script>
<?php include __DIR__ . '/includes/layout-end.php'; ?>