<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('aref.title');
$activePage = 'references';

$flash = $_GET['flash'] ?? '';
[$flashType,$flashText] = $flash ? explode(':',urldecode($flash),2) + ['',''] : ['',''];
$editId = (int)($_GET['edit'] ?? 0);

$refs = $adminDb->query('SELECT * FROM `references` ORDER BY sort_order ASC, id DESC')->fetchAll();
$editRef = null;
if ($editId) {
    foreach ($refs as $r) { if ((int)$r['id'] === $editId) { $editRef = $r; break; } }
}

$mode = $adminDb->query("SELECT `value` FROM settings WHERE `key`='references_mode'")->fetchColumn();
$mode = ($mode === 'slider') ? 'slider' : 'grid';
$auto = $adminDb->query("SELECT `value` FROM settings WHERE `key`='references_autoplay'")->fetchColumn();

include __DIR__ . '/includes/layout.php';
?>
<style>@keyframes refModalIn{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}</style>

<style>
.ref-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px;}
.ref-card{background:var(--bg-card);border:1px solid var(--border);border-radius:16px;padding:20px;}
.ref-head{display:flex;align-items:center;gap:14px;margin-bottom:14px;}
.ref-avatar{width:52px;height:52px;border-radius:50%;object-fit:cover;flex-shrink:0;background:rgba(var(--accent-rgb),.12);display:flex;align-items:center;justify-content:center;font-size:20px;color:var(--accent);font-weight:800;}
.ref-stars{color:#facc15;font-size:13px;letter-spacing:2px;margin-top:3px;}
.ref-msg{font-size:13px;color:var(--muted);line-height:1.7;margin-bottom:16px;white-space:pre-wrap;}
.ref-actions{display:flex;gap:8px;}
.ref-actions form{display:inline;}
</style>

<?php if ($flashText): ?>
<div style="background:<?= $flashType==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;border:1px solid <?= $flashType==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;border-radius:12px;padding:12px 18px;font-size:13px;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:8px;color:<?= $flashType==='success'?'#4ade80':'#f87171' ?>;">
    <i class="fa-solid fa-<?= $flashType==='success'?'circle-check':'circle-xmark' ?>"></i>
    <?= e($flashText) ?>
</div>
<?php endif; ?>

<!-- ─── GÖRÜNÜM AYARLARI ─── -->
<div style="background:var(--bg-card);border:1px solid var(--border);border-radius:16px;padding:22px 26px;margin-bottom:24px;">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;">
        <div>
            <h2 style="font-size:15px;font-weight:900;display:flex;align-items:center;gap:8px;"><i class="fa-solid fa-sliders" style="color:var(--accent);"></i> <?= __('aref.view_title') ?></h2>
            <p style="font-size:12px;color:var(--muted);margin-top:4px;"><?= __('aref.view_hint') ?></p>
        </div>
        <form method="POST" action="/action.php" style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="reference_settings">
            <div style="display:flex;gap:6px;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:5px;">
                <button type="submit" name="mode" value="grid" class="btn-admin" <?= $mode==='grid'?"style='background:var(--accent);color:#fff;'":'' ?>>Grid</button>
                <button type="submit" name="mode" value="slider" class="btn-admin" <?= $mode==='slider'?"style='background:var(--accent);color:#fff;'":'' ?>>Slider</button>
            </div>
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:700;cursor:pointer;">
                <input type="checkbox" name="autoplay" value="1" <?= $auto==='1'?'checked':'' ?> onchange="this.form.submit()"> <?= __('aref.autoplay') ?>
            </label>
        </form>
    </div>
</div>

<!-- ─── YENİ REFERANS BUTONU ─── -->
<a href="?new=1#form" id="newRefBtn" style="display:flex;align-items:center;justify-content:center;gap:8px;width:100%;padding:14px;border-radius:14px;border:2px dashed var(--border);background:transparent;color:var(--muted);font-family:inherit;font-size:14px;font-weight:700;cursor:pointer;transition:border-color .2s,color .2s;margin-bottom:24px;text-decoration:none;">
    <i class="fa-solid fa-plus" style="font-size:18px;"></i> <?= __('aref.add_new') ?>
</a>

<!-- ─── FORM ─── -->
<?php if (isset($_GET['new']) || $editRef): ?>
<div id="form" style="background:var(--bg-card);border:1px solid var(--accent);border-radius:16px;padding:28px;margin-bottom:24px;box-shadow:0 0 0 3px rgba(var(--accent-rgb),.08);">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:22px;">
        <span style="font-size:15px;font-weight:800;"><i class="fa-solid fa-<?= $editRef?'pen-to-square':'plus' ?>" style="color:var(--accent);margin-right:8px;"></i><?= $editRef ? __('aref.edit') : __('aref.new') ?></span>
        <a href="/admin/references.php" style="font-size:24px;color:var(--muted);text-decoration:none;line-height:1;">&times;</a>
    </div>
    <form method="POST" action="/action.php" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="reference_save">
        <input type="hidden" name="op" value="<?= $editRef?'edit':'add' ?>">
        <?php if ($editRef): ?><input type="hidden" name="id" value="<?= (int)$editRef['id'] ?>"><?php endif; ?>

        <div>
            <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aref.name') ?></label>
            <input type="text" name="name" required value="<?= e($editRef['name'] ?? '') ?>" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:11px 14px;color:var(--text);font-size:14px;font-family:inherit;">
        </div>
        <div>
            <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aref.title_label') ?></label>
            <input type="text" name="title" value="<?= e($editRef['title'] ?? '') ?>" placeholder="<?= __('aref.title_ph') ?>" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:11px 14px;color:var(--text);font-size:14px;font-family:inherit;">
        </div>
        <div style="grid-column:1/-1;">
            <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aref.photo') ?></label>
            <div style="display:flex;align-items:center;gap:16px;background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;padding:14px 16px;">
                <img id="refPhotoPreview" src="<?= e($editRef['photo_url'] ?? '') ?>"
                     onerror="this.style.display='none'"
                     style="<?= empty($editRef['photo_url']) ? 'display:none;' : '' ?>width:60px;height:60px;border-radius:50%;object-fit:cover;flex-shrink:0;border:1px solid var(--border);">
                <div style="flex:1;">
                    <button type="button" onclick="openRefImageModal()" style="display:inline-flex;align-items:center;gap:8px;background:rgba(var(--accent-rgb),.12);color:var(--accent);border:1px solid rgba(var(--accent-rgb),.25);border-radius:10px;padding:9px 16px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;">
                        <i class="fa-solid fa-cloud-arrow-up"></i> <?= __('aref.photo_set') ?>
                    </button>
                    <button type="button" id="refPhotoClear" onclick="clearRefPhoto()" style="display:<?= empty($editRef['photo_url']) ? 'none' : 'inline-flex' ?>;margin-left:8px;align-items:center;gap:6px;background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2);border-radius:10px;padding:9px 14px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;">
                        <i class="fa-solid fa-trash"></i><?= __('support.remove_attach') ?>
                    </button>
                    <p style="font-size:11px;color:var(--dim);margin-top:8px;"><?= __('aref.photo_hint') ?></p>
                </div>
            </div>
            <input type="hidden" name="photo_url" id="refPhotoUrl" value="<?= e($editRef['photo_url'] ?? '') ?>">
        </div>
        <div>
            <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aref.rating') ?></label>
            <select name="rating" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:11px 14px;color:var(--text);font-size:14px;font-family:inherit;">
                <?php for ($i = 5; $i >= 1; $i--): ?>
                <option value="<?= $i ?>" <?= ($editRef['rating'] ?? 5) == $i ? 'selected' : '' ?>><?= $i ?> <?= __('aref.star') ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div style="grid-column:1/-1;">
            <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;">Yorum</label>
            <textarea name="message" rows="3" placeholder="<?= __('aref.comment_ph') ?>" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:11px 14px;color:var(--text);font-size:14px;font-family:inherit;resize:vertical;"><?= e($editRef['message'] ?? '') ?></textarea>
        </div>
        <div>
            <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('aref.order') ?></label>
            <input type="number" name="sort_order" value="<?= (int)($editRef['sort_order'] ?? 0) ?>" min="0" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:11px 14px;color:var(--text);font-size:14px;font-family:inherit;">
        </div>
        <div style="display:flex;align-items:flex-end;justify-content:space-between;">
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:700;cursor:pointer;margin-bottom:11px;">
                <input type="checkbox" name="is_active" value="1" <?= ($editRef ? $editRef['is_active'] : 1) ? 'checked' : '' ?>> <?= __('adash.status_active') ?>
            </label>
            <button type="submit" class="btn-primary-admin" style="padding:0 22px;height:42px;border:none;border-radius:10px;cursor:pointer;font-family:inherit;font-size:14px;font-weight:800;"><?= __('msg.save') ?></button>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- ─── LİSTE ─── -->
<div class="ref-grid">
    <?php if (empty($refs)): ?>
    <p style="color:var(--text-muted);font-size:14px;grid-column:1/-1;text-align:center;padding:40px 0;"><?= __('home.empty_refs') ?></p>
    <?php else: ?>
    <?php foreach ($refs as $r): ?>
    <div class="ref-card">
        <div class="ref-head">
            <?php if (!empty($r['photo_url'])): ?>
            <img src="<?= e($r['photo_url']) ?>" class="ref-avatar" alt="">
            <?php else: ?>
            <div class="ref-avatar"><?= htmlspecialchars(mb_strtoupper(mb_substr($r['name'],0,1))) ?></div>
            <?php endif; ?>
            <div style="flex:1;min-width:0;">
                <div style="display:flex;align-items:center;gap:8px;">
                    <strong style="font-size:14px;"><?= e($r['name']) ?></strong>
                    <span style="font-size:10px;padding:2px 8px;border-radius:20px;<?= $r['is_active'] ? 'background:rgba(34,197,94,.12);color:#4ade80;' : 'background:rgba(239,68,68,.1);color:#f87171;' ?>"><?= $r['is_active'] ? __('adash.status_active') : __('aint.passive') ?></span>
                </div>
                <?php if (!empty($r['title'])): ?><div style="font-size:12px;color:var(--accent);font-weight:600;margin-top:2px;"><?= e($r['title']) ?></div><?php endif; ?>
                <div class="ref-stars"><?= str_repeat('★', (int)$r['rating']) ?><span style="color:var(--dim);"><?= str_repeat('★', 5-(int)$r['rating']) ?></span></div>
            </div>
        </div>
        <?php if (!empty($r['message'])): ?><div class="ref-msg"><?= nl2br(e($r['message'])) ?></div><?php endif; ?>
        <div class="ref-actions">
            <form method="POST" action="/action.php">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="reference_save">
                <input type="hidden" name="op" value="toggle_active">
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button type="submit" class="btn-admin" style="padding:6px 12px;font-size:12px;"><?= $r['is_active'] ? __('aref.deactivate') : __('aref.activate') ?></button>
            </form>
            <a href="?edit=<?= (int)$r['id'] ?>#form" class="btn-admin" style="padding:6px 12px;font-size:12px;text-decoration:none;"><i class="fa-solid fa-pen"></i></a>
            <form method="POST" action="/action.php" onsubmit="return confirm(<?= json_encode(__('aref.delete_confirm')) ?>)">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="reference_save">
                <input type="hidden" name="op" value="delete">
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button type="submit" class="btn-admin" style="padding:6px 12px;font-size:12px;background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2);"><i class="fa-solid fa-trash"></i></button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- ─── FOTOĞRAF MODALI ─── -->
<div id="refImageModal" style="display:none;position:fixed;inset:0;z-index:999;align-items:center;justify-content:center;padding:16px;">
    <div style="position:absolute;inset:0;background:rgba(0,0,0,.6);backdrop-filter:blur(4px);" onclick="closeRefImageModal()"></div>
    <div style="position:relative;background:var(--bg-card);border:1px solid var(--border);border-radius:16px;width:100%;max-width:480px;box-shadow:0 24px 64px rgba(0,0,0,.5);animation:refModalIn .25s ease;">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--border);">
            <h3 style="font-size:15px;font-weight:900;display:flex;align-items:center;gap:8px;"><i class="fa-solid fa-image" style="color:var(--accent);"></i> <?= __('aref.photo_modal') ?></h3>
            <button onclick="closeRefImageModal()" style="background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div style="display:flex;border-bottom:1px solid var(--border);">
            <button type="button" id="refTabUploadBtn" onclick="switchRefTab('upload')" style="flex:1;padding:12px;text-align:center;font-size:13px;font-weight:700;background:rgba(var(--accent-rgb),.12);color:var(--accent);border-bottom:2px solid var(--accent);border:none;cursor:pointer;font-family:inherit;"><i class="fa-solid fa-cloud-arrow-up"></i><?= __('apedit.tab_file') ?></button>
            <button type="button" id="refTabLinkBtn" onclick="switchRefTab('link')" style="flex:1;padding:12px;text-align:center;font-size:13px;font-weight:700;color:var(--muted);border:none;cursor:pointer;background:transparent;font-family:inherit;"><i class="fa-solid fa-link"></i><?= __('asett.link_tab') ?></button>
        </div>
        <div id="refTabUpload" style="padding:20px;">
            <div id="refDropZone" style="background:var(--bg-surface);border:2px dashed var(--border);border-radius:12px;padding:28px;text-align:center;cursor:pointer;transition:border-color .2s;"
                 onclick="document.getElementById('refFileInput').click()"
                 ondragover="this.style.borderColor='var(--accent)';this.style.background='rgba(var(--accent-rgb),.06)';return false;"
                 ondragleave="this.style.borderColor='var(--border)';this.style.background='var(--bg-surface)';"
                 ondrop="handleRefDrop(event)">
                <input type="file" id="refFileInput" accept="image/jpeg,image/png,image/webp,image/gif" style="display:none;" onchange="handleRefFile(this.files[0])">
                <div id="refDropContent">
                    <i class="fa-solid fa-cloud-arrow-up" style="font-size:32px;color:var(--dim);display:block;margin-bottom:10px;"></i>
                    <p style="font-size:13px;color:var(--muted);font-weight:600;margin-bottom:4px;"><?= __('apedit.drop_title') ?></p>
                    <p style="font-size:11px;color:var(--dim);"><?= __('aref.drop_hint') ?></p>
                </div>
                <div id="refPreviewArea" style="display:none;">
                    <img id="refPreviewImg" style="max-height:120px;max-width:100%;object-fit:contain;border-radius:8px;margin:0 auto;">
                </div>
            </div>
            <div id="refStatus" style="display:none;margin-top:10px;padding:8px 12px;border-radius:8px;font-size:12px;font-weight:700;"></div>
            <button type="button" id="refUploadBtn" onclick="submitRefUpload()" style="display:none;width:100%;justify-content:center;margin-top:12px;background:linear-gradient(180deg,#fbc853,#f7b131);color:#4c3716;border:1px solid #d39522;border-radius:10px;padding:12px;font-size:13px;font-weight:800;cursor:pointer;font-family:inherit;box-shadow:0 3px 0 #a26e13;">
                <i class="fa-solid fa-upload"></i> <?= __('panel.upload') ?>
            </button>
        </div>
        <div id="refTabLink" style="padding:20px;display:none;">
            <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('apedit.image_url') ?></label>
            <div style="display:flex;gap:8px;">
                <input type="url" id="refLinkInput" placeholder="<?= __('aref.link_ph') ?>"
                       style="flex:1;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                <button type="button" onclick="applyRefLink()" style="padding:10px 18px;background:linear-gradient(180deg,#fbc853,#f7b131);color:#4c3716;border:1px solid #d39522;border-radius:10px;font-size:13px;font-weight:800;cursor:pointer;font-family:inherit;box-shadow:0 3px 0 #a26e13;">
                    <i class="fa-solid fa-check"></i> <?= __('aref.apply') ?>
                </button>
            </div>
            <div id="refLinkPreview" style="display:none;margin-top:10px;">
                <img id="refLinkPreviewImg" style="max-height:100px;max-width:100%;object-fit:contain;border-radius:6px;margin:0 auto;">
            </div>
        </div>
    </div>
</div>

<script>
var _refSelectedFile = null;
function openRefImageModal(){
    document.getElementById('refImageModal').style.display='flex';
    _refSelectedFile=null;
    document.getElementById('refFileInput').value='';
    document.getElementById('refDropContent').style.display='block';
    document.getElementById('refPreviewArea').style.display='none';
    document.getElementById('refUploadBtn').style.display='none';
    document.getElementById('refStatus').style.display='none';
    document.getElementById('refLinkInput').value='';
    document.getElementById('refLinkPreview').style.display='none';
    switchRefTab('upload');
}
function closeRefImageModal(){document.getElementById('refImageModal').style.display='none';}
function switchRefTab(tab){
    var u=document.getElementById('refTabUploadBtn'),l=document.getElementById('refTabLinkBtn');
    if(tab==='upload'){u.style.background='rgba(var(--accent-rgb),.12)';u.style.color='var(--accent)';u.style.borderBottom='2px solid var(--accent)';l.style.background='transparent';l.style.color='var(--muted)';l.style.borderBottom='';}
    else{l.style.background='rgba(var(--accent-rgb),.12)';l.style.color='var(--accent)';l.style.borderBottom='2px solid var(--accent)';u.style.background='transparent';u.style.color='var(--muted)';u.style.borderBottom='';}
    document.getElementById('refTabUpload').style.display=tab==='upload'?'block':'none';
    document.getElementById('refTabLink').style.display=tab==='link'?'block':'none';
}
function handleRefDrop(e){e.preventDefault();e.stopPropagation();if(e.dataTransfer.files[0])handleRefFile(e.dataTransfer.files[0]);}
function handleRefFile(file){
    if(!file.type.match(/image\/(jpeg|png|webp|gif)/))return void showRefStatus(<?= json_encode(__('apedit.bad_format')) ?>,false);
    if(file.size>4194304)return void showRefStatus(<?= json_encode(__('apedit.too_big')) ?>,false);
    _refSelectedFile=file;
    document.getElementById('refDropContent').style.display='none';
    document.getElementById('refPreviewArea').style.display='block';
    document.getElementById('refUploadBtn').style.display='flex';
    var r=new FileReader();r.onload=function(e){document.getElementById('refPreviewImg').src=e.target.result;};r.readAsDataURL(file);
    document.getElementById('refStatus').style.display='none';
}
function showRefStatus(msg,ok){
    var el=document.getElementById('refStatus');
    el.style.display='flex';
    el.style.background=ok?'rgba(34,197,94,.12)':'rgba(239,68,68,.1)';
    el.style.border=ok?'1px solid rgba(34,197,94,.3)':'1px solid rgba(239,68,68,.2)';
    el.style.color=ok?'#4ade80':'#f87171';
    el.innerHTML='<i class="fa-solid fa-'+(ok?'circle-check':'circle-xmark')+'"></i> '+msg;
}
async function submitRefUpload(){
    if(!_refSelectedFile)return;
    var btn=document.getElementById('refUploadBtn');btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> '+<?= json_encode(__('aprod.loading')) ?>;
    var fd=new FormData();fd.append('action','asset_upload');fd.append('ctx','references');fd.append('asset_type','cover');fd.append('file',_refSelectedFile);
    try{
        var r=await fetch('/action.php',{method:'POST',body:fd});var d=await r.json();
        if(d.ok){showRefStatus(<?= json_encode(__('aref.uploaded_ok')) ?>,true);applyRefUrl(d.url);}
        else{showRefStatus(d.msg||<?= json_encode(__('apedit.upload_fail')) ?>,false);btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-upload"></i> '+<?= json_encode(__('panel.upload')) ?>;}
    }catch(e){showRefStatus(<?= json_encode(__('aprod.req_fail_short')) ?>,false);btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-upload"></i> '+<?= json_encode(__('panel.upload')) ?>;}
}
function applyRefUrl(url){
    document.getElementById('refPhotoUrl').value=url;
    var pr=document.getElementById('refPhotoPreview');
    pr.src=url;pr.style.display='block';
    document.getElementById('refPhotoClear').style.display='inline-flex';
    closeRefImageModal();
}
function clearRefPhoto(){
    document.getElementById('refPhotoUrl').value='';
    document.getElementById('refPhotoPreview').style.display='none';
    document.getElementById('refPhotoClear').style.display='none';
}
function applyRefLink(){
    var url=document.getElementById('refLinkInput').value.trim();if(!url)return void showRefStatus(<?= json_encode(__('apedit.url_required')) ?>,false);
    var preview=document.getElementById('refLinkPreview');var img=document.getElementById('refLinkPreviewImg');
    img.src=url;preview.style.display='block';
    img.onload=function(){showRefStatus(<?= json_encode(__('aref.link_ok')) ?>,true);applyRefUrl(url);};
    img.onerror=function(){showRefStatus(<?= json_encode(__('apedit.link_bad')) ?>,false);};
}
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>