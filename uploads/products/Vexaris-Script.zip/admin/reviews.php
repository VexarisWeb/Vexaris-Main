<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.reviews');
$activePage = 'reviews';

$flash = $_GET['flash'] ?? '';
[$flashType, $flashText] = $flash ? explode(':', urldecode($flash), 2) + ['',''] : ['', ''];

$reviews = $adminDb->query(
    'SELECT c.*, u.username, u.avatar, p.name AS product_name FROM comments c
     JOIN users u ON u.id = c.user_id
     JOIN products p ON p.id = c.product_id
     ORDER BY c.id DESC'
)->fetchAll();

include __DIR__ . '/includes/layout.php';
?>
<style>
@keyframes nxsRowIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
@keyframes nxsPop{from{opacity:0;transform:scale(.92)}to{opacity:1;transform:scale(1)}}
.hidden { display: none !important; }
</style>

<?php if ($flashText): ?>
<div style="background:<?= $flashType==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;border:1px solid <?= $flashType==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;color:<?= $flashType==='success'?'#4ade80':'#f87171' ?>;padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid fa-<?= $flashType==='success'?'circle-check':'circle-xmark' ?>"></i> <?= e($flashText) ?>
</div>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title">
            <i class="fa-solid fa-star" style="color:#facc15;margin-right:8px;"></i>
            <?= __('amenu.reviews') ?> <span style="color:var(--muted);font-weight:500;">(<?= count($reviews) ?>)</span>
        </span>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th><?= __('apurch.user') ?></th>
                <th><?= __('apurch.product') ?></th>
                <th><?= __('aref.star') ?></th>
                <th><?= __('aref.comment') ?></th>
                <th><?= __('apurch.col_date') ?></th>
                <th style="text-align:right;"><?= __('aprod.col_action') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($reviews as $i => $r):
            $rSafe = [
                'id' => (int)$r['id'],
                'comment_text' => $r['comment_text'],
                'rating' => (int)$r['rating'],
                'username' => $r['username'],
                'product_name' => $r['product_name'],
            ];
        ?>
        <tr style="animation:nxsRowIn .45s ease both;animation-delay:<?= $i*35 ?>ms;transition:background .15s ease,box-shadow .15s ease;">
            <td>
                <div style="display:flex;align-items:center;gap:10px;">
                    <img src="<?= e($r['avatar'] ?? 'https://minotar.net/avatar/user.png') ?>"
                         onerror="this.src='https://minotar.net/avatar/user.png'"
                         style="width:30px;height:30px;border-radius:50%;object-fit:cover;image-rendering:pixelated;" alt="">
                    <span style="font-weight:700;font-size:13px;"><?= e($r['username']) ?></span>
                </div>
            </td>
            <td style="font-size:12px;color:var(--muted);">
                <a href="/products?product=<?= (int)$r['product_id'] ?>" style="color:var(--accent);font-weight:600;"><?= e($r['product_name']) ?></a>
            </td>
            <td>
                <span style="color:<?= (int)$r['rating'] > 0 ? '#facc15' : 'var(--dim)' ?>;font-size:12px;">
                    <?= $r['rating'] > 0 ? str_repeat('<i class="fa-solid fa-star"></i>', (int)$r['rating']).str_repeat('<i class="fa-regular fa-star"></i>', 5-(int)$r['rating']) : '—' ?>
                </span>
            </td>
            <td style="font-size:12px;color:var(--muted);max-width:320px;">
                <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($r['comment_text']) ?></div>
            </td>
            <td style="font-size:12px;color:var(--muted);white-space:nowrap;"><?= date('d.m.Y H:i', strtotime($r['created_at'])) ?></td>
            <td style="text-align:right;">
                <div style="display:flex;gap:6px;justify-content:flex-end;">
                    <button onclick="openEditReview(<?= htmlspecialchars(json_encode($rSafe), ENT_QUOTES) ?>)" class="btn-admin btn-ghost-admin" style="padding:6px 12px;font-size:12px;">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                    <form method="POST" action="/action.php" onsubmit="return confirm(<?= json_encode(__('arev.delete_confirm')) ?>);" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="review_delete">
                        <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                        <button type="submit" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;padding:6px 12px;font-size:12px;border:1px solid rgba(239,68,68,.2);">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($reviews)): ?>
        <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:32px;"><?= __('product.no_reviews') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<div id="editReviewModal" class="hidden" style="position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;padding:16px;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;max-width:520px;animation:nxsPop .28s ease;">
        <div style="padding:18px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;">
            <span style="font-size:15px;font-weight:800;"><i class="fa-solid fa-pen-to-square" style="color:var(--accent);margin-right:8px;"></i><?= __('arev.edit_title') ?></span>
            <button onclick="document.getElementById('editReviewModal').classList.add('hidden')" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:18px;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <form method="POST" action="/action.php" style="padding:22px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="review_update">
            <input type="hidden" name="id" id="editReviewId" value="">
            <div style="margin-bottom:14px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('arev.writer') ?></label>
                <div id="editReviewMeta" style="font-size:13px;font-weight:700;color:var(--text);"></div>
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:8px;"><?= __('aref.star') ?></label>
                <div id="editReviewStars" style="display:flex;gap:4px;">
                    <span style="cursor:pointer;color:var(--dim);font-size:24px;" data-val="1"><i class="fa-solid fa-star"></i></span>
                    <span style="cursor:pointer;color:var(--dim);font-size:24px;" data-val="2"><i class="fa-solid fa-star"></i></span>
                    <span style="cursor:pointer;color:var(--dim);font-size:24px;" data-val="3"><i class="fa-solid fa-star"></i></span>
                    <span style="cursor:pointer;color:var(--dim);font-size:24px;" data-val="4"><i class="fa-solid fa-star"></i></span>
                    <span style="cursor:pointer;color:var(--dim);font-size:24px;" data-val="5"><i class="fa-solid fa-star"></i></span>
                </div>
                <input type="hidden" name="rating" id="editReviewRating" value="0">
            </div>
            <div style="margin-bottom:20px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('arev.comment_label') ?></label>
                <textarea name="comment_text" id="editReviewText" rows="4" required minlength="3"
                          style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;resize:vertical;"></textarea>
            </div>
            <button type="submit" class="btn-admin btn-primary-admin" style="width:100%;justify-content:center;">
                <i class="fa-solid fa-floppy-disk"></i> <?= __('msg.save') ?>
            </button>
        </form>
    </div>
</div>

<script>
let _editStarEls = document.querySelectorAll('#editReviewStars > span');
let _editRatingInput = document.getElementById('editReviewRating');
function paintEditStars(val) {
    _editStarEls.forEach(el => {
        el.style.color = parseInt(el.dataset.val) <= val ? '#facc15' : 'var(--dim)';
    });
}
function openEditReview(r) {
    document.getElementById('editReviewId').value = r.id;
    document.getElementById('editReviewText').value = r.comment_text;
    document.getElementById('editReviewMeta').textContent = r.username + ' — ' + r.product_name;
    _editRatingInput.value = r.rating;
    paintEditStars(r.rating);
    document.getElementById('editReviewModal').classList.remove('hidden');
}
_editStarEls.forEach(el => {
    el.addEventListener('click', () => {
        _editRatingInput.value = el.dataset.val;
        paintEditStars(parseInt(el.dataset.val));
    });
    el.addEventListener('mouseenter', () => paintEditStars(parseInt(el.dataset.val)));
});
document.getElementById('editReviewStars').addEventListener('mouseleave', () => paintEditStars(parseInt(_editRatingInput.value || '0') || 0));
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
