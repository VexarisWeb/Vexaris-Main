<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.seo');
$activePage = 'seo';

$siteName = 'Vexaris';
$seoSettings = [];
$customPages = [];
$legalRows = [];

if ($adminDb) {
    try {
        $ss = $adminDb->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'seo\\_%'");
        foreach ($ss->fetchAll() as $r) $seoSettings[$r['key']] = (string)$r['value'];
        $sn = $adminDb->query("SELECT `value` FROM settings WHERE `key`='site_name' LIMIT 1");
        $siteName = trim((string)$sn->fetchColumn());
        if ($siteName === '') $siteName = 'Vexaris';
        $cp = $adminDb->query('SELECT id, slug, title, meta_description, status FROM custom_pages ORDER BY id DESC');
        $customPages = $cp->fetchAll();
        foreach ($customPages as $r) {
            $customPagesMap[$r['id']] = $r;
        }
        $lp = $adminDb->query('SELECT slug, title FROM legal_pages');
        foreach ($lp->fetchAll() as $r) $legalRows[$r['slug']] = $r['title'];
    } catch (\Exception $e) {}
}

$systemPages = [
    'home'     => ['label' => __('seo.home'),            'icon' => 'fa-house',                'url' => '/',              'default' => '{site} | ' . __('seo.home')],
    'products' => ['label' => __('seo.products'),               'icon' => 'fa-store',                'url' => '/products',      'default' => '{site} | ' . __('seo.products')],
    'news'     => ['label' => __('seo.news'),             'icon' => 'fa-newspaper',            'url' => '/news',          'default' => '{site} | ' . __('seo.news')],
    'support'  => ['label' => __('seo.support'),               'icon' => 'fa-headset',              'url' => '/support',       'default' => '{site} | ' . __('seo.support')],
    'login'    => ['label' => __('aseo.lbl_login'),                'icon' => 'fa-right-to-bracket',     'url' => '/login',         'default' => '{site} | ' . __('seo.login')],
    'register' => ['label' => __('seo.register'),             'icon' => 'fa-user-plus',            'url' => '/register',      'default' => '{site} | ' . __('seo.register')],
    '404'      => ['label' => __('aseo.lbl_404'),     'icon' => 'fa-triangle-exclamation', 'url' => '/404',           'default' => '{site} | ' . __('seo.notfound')],
];

$legalPages = [
    'cookie-policy'    => ['label' => __('legal.cookies'),    'icon' => 'fa-cookie-bite'],
    'privacy-policy'   => ['label' => __('legal.privacy'), 'icon' => 'fa-shield-halved'],
    'terms-of-service' => ['label' => __('legal.terms'),   'icon' => 'fa-file-contract'],
    'refund-policy'    => ['label' => __('legal.refund'),      'icon' => 'fa-rotate-left'],
];

include __DIR__ . '/includes/layout.php';
?>
<style>
.seo-group-label{font-size:10px;font-weight:900;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin:8px 2px 6px;}
.seo-card{display:flex;align-items:center;gap:10px;width:100%;padding:9px 10px;margin-bottom:6px;background:var(--bg-surface);border:1px solid var(--border);border-radius:11px;cursor:pointer;font-family:inherit;transition:all .15s;text-align:left;box-shadow:none;}
.seo-card:hover{border-color:rgba(var(--accent-rgb),.45);transform:translateY(-1px);}
.seo-card-icon{width:34px;height:34px;border-radius:9px;background:rgba(var(--accent-rgb),.1);color:#818cf8;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;}
.seo-badge{font-size:9px;font-weight:800;background:var(--bg);color:var(--muted);border:1px solid var(--border);border-radius:999px;padding:2px 8px;text-transform:uppercase;letter-spacing:.4px;flex-shrink:0;}
.seo-badge--on{background:rgba(34,197,94,.12);color:#4ade80;border-color:rgba(34,197,94,.3);}
.seo-empty{font-size:12px;color:var(--muted);padding:12px;border:1px dashed var(--border);border-radius:10px;line-height:1.6;}
.seo-modal-overlay{position:fixed;inset:0;z-index:100001;display:flex;align-items:stretch;justify-content:flex-end;opacity:0;pointer-events:none;transition:opacity .2s ease;}
.seo-modal-overlay.open{opacity:1;pointer-events:auto;}
.seo-modal-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.55);backdrop-filter:blur(3px);}
.seo-modal-box{position:relative;background:var(--bg-card,#0f1420);border-left:1px solid var(--border);width:100%;max-width:480px;height:100dvh;overflow:hidden;transform:translateX(40px);opacity:0;transition:transform .26s cubic-bezier(.34,1.36,.64,1),opacity .18s ease;display:flex;flex-direction:column;}
.seo-modal-overlay.open .seo-modal-box{transform:none;opacity:1;}
@media(max-width:560px){.seo-modal-box{max-width:100%;}}
.seo-modal-header{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 20px;border-bottom:1px solid var(--border);}
.seo-modal-close{background:rgba(255,255,255,.06);border:1px solid var(--border);color:var(--muted);width:34px;height:34px;border-radius:10px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:16px;transition:all .2s;font-family:inherit;}
.seo-modal-close:hover{background:#ef4444;color:#fff;border-color:#ef4444;}
.seo-modal-body{padding:20px;overflow-y:auto;}
.seo-field-label{display:block;font-size:11px;font-weight:800;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px;}
.seo-counter{text-align:right;font-size:11px;color:var(--muted);font-weight:600;margin-top:4px;}
.seo-preview{margin-top:18px;border:1px solid var(--border);border-radius:12px;overflow:hidden;}
.seo-preview-label{display:flex;align-items:center;gap:6px;font-size:10px;font-weight:800;color:var(--muted);text-transform:uppercase;letter-spacing:.6px;padding:8px 12px;background:rgba(255,255,255,.03);border-bottom:1px solid var(--border);}
.seo-modal-footer{display:flex;justify-content:space-between;gap:10px;padding:14px 20px;border-top:1px solid var(--border);}
</style>

<div style="margin-bottom:20px;">
    <h1 style="font-size:22px;font-weight:900;margin:0 0 4px;"><i class="fa-solid fa-magnifying-glass-chart" style="color:var(--accent);margin-right:8px;"></i><?= __('amenu.seo') ?></h1>
    <p style="font-size:13px;color:var(--muted);margin:0;"><?= __('aseo.subtitle_a') ?> <b><?= e($siteName) ?></b> <?= __('aseo.subtitle_b') ?></p>
</div>

<div class="admin-card" style="padding:0;overflow:hidden;">
    <div style="display:flex;gap:0;min-height:560px;flex-wrap:wrap;">

        <!-- SOL: SAYFA KARTLARI -->
        <div style="width:300px;flex-shrink:0;border-right:1px solid var(--border);display:flex;flex-direction:column;max-height:640px;">
            <div style="padding:14px 16px;border-bottom:1px solid var(--border);">
                <div style="display:flex;align-items:center;gap:8px;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:8px 12px;">
                    <i class="fa-solid fa-magnifying-glass" style="color:var(--muted);font-size:13px;"></i>
                    <input type="text" id="seoSearch" placeholder="<?= __('aseo.search_ph') ?>"
                           style="flex:1;background:none;border:none;outline:none;color:var(--text);font-size:13px;font-weight:600;font-family:inherit;">
                </div>
            </div>
            <div id="seoPageList" style="flex:1;overflow-y:auto;padding:12px;">

                <div class="seo-group-label"><?= __('aseo.group_system') ?></div>
                <?php foreach ($systemPages as $skey => $sinfo):
                    $sHas = isset($seoSettings['seo_'.$skey.'_title']) && $seoSettings['seo_'.$skey.'_title'] !== '';
                ?>
                <button type="button" class="seo-card" data-target="<?= $skey ?>" data-type="system"
                        data-label="<?= htmlspecialchars($sinfo['label'], ENT_QUOTES) ?>"
                        data-icon="<?= $sinfo['icon'] ?>"
                        data-url="<?= htmlspecialchars($sinfo['url'], ENT_QUOTES) ?>"
                        data-title="<?= htmlspecialchars($seoSettings['seo_'.$skey.'_title'] ?? str_replace('{site}', $siteName, $sinfo['default']), ENT_QUOTES) ?>"
                        data-default-title="<?= htmlspecialchars(str_replace('{site}', $siteName, $sinfo['default']), ENT_QUOTES) ?>"
                        data-description="<?= htmlspecialchars($seoSettings['seo_'.$skey.'_description'] ?? '', ENT_QUOTES) ?>"
                        data-search="<?= htmlspecialchars(mb_strtolower($sinfo['label'], 'UTF-8'), ENT_QUOTES) ?>">
                    <i class="fa-solid <?= $sinfo['icon'] ?> seo-card-icon"></i>
                    <div style="flex:1;min-width:0;text-align:left;">
                        <span style="display:block;font-size:13px;font-weight:800;color:var(--text);"><?= e($sinfo['label']) ?></span>
                        <span style="display:block;font-size:11px;color:var(--muted);font-weight:600;margin-top:2px;"><?= e($sinfo['url']) ?></span>
                    </div>
                    <span class="seo-badge <?= $sHas ? 'seo-badge--on' : '' ?>"><?= $sHas ? 'SEO' : __('aseo.badge_default') ?></span>
                </button>
                <?php endforeach; ?>

                <div class="seo-group-label" style="margin-top:14px;"><?= __('aseo.group_custom') ?></div>
                <?php if (!empty($customPagesMap)): ?>
                    <?php foreach ($customPagesMap as $pid => $cpage):
                        $clabel = $cpage['title'] !== '' ? $cpage['title'] : html_entity_decode('&nbsp;');
                    ?>
                    <button type="button" class="seo-card" data-target="cp-<?= $pid ?>" data-type="page"
                            data-label="<?= htmlspecialchars($cpage['title'] ?: __('aseo.page_fallback', ['id' => $pid]), ENT_QUOTES) ?>"
                            data-icon="fa-file-lines"
                            data-url="<?= htmlspecialchars('/pages/'.$cpage['slug'], ENT_QUOTES) ?>"
                            data-page-id="<?= (int)$cpage['id'] ?>"
                            data-title="<?= htmlspecialchars($cpage['title'] ?? '', ENT_QUOTES) ?>"
                            data-default-title="<?= htmlspecialchars($cpage['title'] ?? '', ENT_QUOTES) ?>"
                            data-description="<?= htmlspecialchars($cpage['meta_description'] ?? '', ENT_QUOTES) ?>"
                            data-search="<?= htmlspecialchars(mb_strtolower($cpage['title'].' '.$cpage['slug'], 'UTF-8'), ENT_QUOTES) ?>">
                        <span style="width:34px;height:34px;border-radius:9px;background:rgba(34,197,94,.12);display:flex;align-items:center;justify-content:center;font-size:14px;color:#4ade80;flex-shrink:0;"><i class="fa-solid fa-file-lines"></i></span>
                        <div style="flex:1;min-width:0;text-align:left;">
                            <span style="display:block;font-size:13px;font-weight:800;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($cpage['title'] ?: __('aseo.page_fallback', ['id' => $pid])) ?></span>
                            <span style="display:block;font-size:11px;color:var(--muted);font-weight:600;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e('/pages/'.$cpage['slug']) ?></span>
                        </div>
                        <span class="seo-badge <?= ($cpage['meta_description'] ?? '') !== '' ? 'seo-badge--on' : '' ?>"><?= ($cpage['meta_description'] ?? '') !== '' ? 'SEO' : __('aseo.badge_default') ?></span>
                    </button>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="seo-empty"><?= __('aseo.empty_custom') ?><br><a href="/admin/custom-pages.php" style="color:var(--accent);"><?= __('aseo.empty_custom_link') ?></a></div>
                <?php endif; ?>

                <div class="seo-group-label" style="margin-top:14px;"><?= __('aseo.group_legal') ?></div>
                <?php foreach ($legalPages as $lslug => $linfo):
                    $lkey = 'legal_'.$lslug;
                    $lTitleSaved = $legalRows[$lslug] ?? __('aseo.legal_fallback', ['slug' => $lslug]);
                    $lmeta = $seoSettings['seo_'.$lkey.'_description'] ?? '';
                ?>
                <button type="button" class="seo-card" data-target="legal_<?= $lslug ?>" data-type="legal"
                        data-label="<?= htmlspecialchars($linfo['label'], ENT_QUOTES) ?>"
                        data-icon="<?= $linfo['icon'] ?>"
                        data-url="<?= htmlspecialchars('/legal?p='.$lslug, ENT_QUOTES) ?>"
                        data-title="<?= htmlspecialchars($lTitleSaved, ENT_QUOTES) ?>"
                        data-default-title="<?= htmlspecialchars($lTitleSaved, ENT_QUOTES) ?>"
                        data-readonly-title="1"
                        data-description="<?= htmlspecialchars($lmeta, ENT_QUOTES) ?>"
                        data-search="<?= htmlspecialchars(mb_strtolower($linfo['label'], 'UTF-8'), ENT_QUOTES) ?>">
                    <i class="fa-solid <?= $linfo['icon'] ?> seo-card-icon" style="background:rgba(251,200,83,.12);color:#fbc853;"></i>
                    <div style="flex:1;min-width:0;text-align:left;">
                        <span style="display:block;font-size:13px;font-weight:800;color:var(--text);"><?= e($linfo['label']) ?></span>
                        <span style="display:block;font-size:11px;color:var(--muted);font-weight:600;margin-top:2px;"><?= e('/legal?p='.$lslug) ?></span>
                    </div>
                    <span class="seo-badge <?= $lmeta !== '' ? 'seo-badge--on' : '' ?>"><?= $lmeta !== '' ? 'SEO' : __('aseo.badge_default') ?></span>
                </button>
                <?php endforeach; ?>

            </div>
        </div>

        <!-- SAĞ: BİLGİ PANELİ -->
        <div style="flex:1;min-width:280px;padding:28px;background:var(--bg-content,var(--bg-surface,transparent));">
            <div style="text-align:center;padding:40px 0;">
                <div style="width:64px;height:64px;border-radius:18px;background:rgba(var(--accent-rgb),.1);display:flex;align-items:center;justify-content:center;font-size:24px;color:#818cf8;margin:0 auto 16px;">
                    <i class="fa-solid fa-magnifying-glass-chart"></i>
                </div>
                <h3 style="font-size:16px;font-weight:900;margin:0 0 6px;"><?= __('aseo.edit_title') ?></h3>
                <p style="font-size:13px;color:var(--muted);margin:0 auto;max-width:360px;line-height:1.7;"><?= __('aseo.edit_hint') ?></p>
                <div style="display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap;margin-top:18px;font-size:12px;color:var(--muted);">
                    <span style="display:inline-flex;align-items:center;gap:6px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.25);padding:6px 12px;border-radius:999px;font-weight:700;"><i class="fa-solid fa-circle-check" style="color:#4ade80;"></i> SEO</span>
                    <span style="display:inline-flex;align-items:center;gap:6px;background:var(--bg-surface);border:1px solid var(--border);padding:6px 12px;border-radius:999px;font-weight:700;"><i class="fa-solid fa-rotate" style="color:var(--muted);"></i> <?= __('aseo.badge_default') ?></span>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- SEO DÜZENLEME MODALI -->
<div id="seoModal" class="seo-modal-overlay" style="display:none;">
    <div class="seo-modal-backdrop" id="seoModalBackdrop"></div>
    <div class="seo-modal-box" role="dialog" aria-modal="true">
        <div class="seo-modal-header">
            <div>
                <h3 id="seoModalTitle" style="font-size:16px;font-weight:900;margin:0;"><?= __('aseo.modal_default_title') ?></h3>
                <span id="seoModalUrl" style="font-size:12px;color:var(--muted);font-weight:600;"></span>
            </div>
            <button type="button" class="seo-modal-close" id="seoModalClose" aria-label="<?= __('modal.close') ?>"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="seo-modal-body">
            <input type="hidden" id="seoKey">
            <input type="hidden" id="seoType">
            <input type="hidden" id="seoPageId">

            <div id="seoLegalNote" style="display:none;background:rgba(161,200,83,0.15);border:1px solid rgba(251,200,83,.25);border-radius:10px;padding:10px 12px;font-size:12px;color:#fbc853;font-weight:600;margin-bottom:16px;line-height:1.6;">
                <i class="fa-solid fa-circle-info"></i> <?= __('aseo.legal_note_a') ?> <strong><?= __('aseo.group_legal') ?></strong> <?= __('aseo.legal_note_b') ?> <a href="/admin/legal.php" style="color:#fff;text-decoration:underline;"><?= __('aseo.legal_note_link') ?></a> <?= __('aseo.legal_note_c') ?>
            </div>

            <label class="seo-field-label"><?= __('aseo.field_title') ?></label>
            <input type="text" id="seoTitleInput" maxlength="100" placeholder="<?= __('aseo.title_ph') ?>"
                   style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:11px 14px;color:var(--text);font-size:14px;font-weight:700;outline:none;font-family:inherit;">
            <div id="seoTitleCounter" class="seo-counter">0 / 100</div>

            <label class="seo-field-label" style="margin-top:16px;"><?= __('aseo.field_desc') ?></label>
            <textarea id="seoDescInput" rows="4" maxlength="200" placeholder="<?= __('aseo.desc_ph') ?>"
                      style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:11px 14px;color:var(--text);font-size:13px;font-weight:600;outline:none;font-family:inherit;resize:vertical;line-height:1.6;"></textarea>
            <div id="seoDescCounter" class="seo-counter">0 / 200</div>

            <div class="seo-preview">
                <span class="seo-preview-label"><i class="fa-solid fa-eye"></i> <?= __('aseo.preview_label') ?></span>
                <div id="seoPreview" style="background:#0b0f17;border:none;padding:14px 16px;">
                    <div id="seoPreviewUrl" style="font-size:12px;color:#9ca3af;font-weight:400;margin-bottom:2px;"></div>
                    <div id="seoPreviewTitle" style="font-size:16px;line-height:1.3;color:#7aa9ff;font-weight:400;text-decoration:none;"><?= __('aseo.preview_initial') ?><span style="display:inline-block;"></span></div>
                    <div id="seoPreviewDesc" style="font-size:12px;color:#bdc1c6;line-height:1.5;margin-top:6px;"><?= __('aseo.preview_no_desc') ?></div>
                </div>
            </div>

            <div id="seoStatusMsg" style="display:none;margin-top:6px;font-size:12px;font-weight:700;"></div>
        </div>
        <div class="seo-modal-footer">
            <button type="button" class="btn-admin" style="background:transparent;border:1px solid var(--border);color:var(--muted);box-shadow:none;" id="seoResetBtn"><i class="fa-solid fa-rotate-left"></i> <?= __('aseo.reset_btn') ?></button>
            <button type="button" class="btn-admin" id="seoAiBtn" style="background:linear-gradient(135deg,var(--accent),#7c3aed);color:#fff;border:none;"><i class="fa-solid fa-wand-magic-sparkles"></i> AI</button>
            <button type="button" class="btn-admin btn-primary-admin" id="seoSaveBtn"><i class="fa-solid fa-floppy-disk"></i> <?= __('msg.save') ?></button>
        </div>
    </div>
</div>

<script>
(function(){
    var cards = Array.prototype.slice.call(document.querySelectorAll('.seo-card'));
    var search = document.getElementById('seoSearch');
    var modal = document.getElementById('seoModal');
    var titleInput = document.getElementById('seoTitleInput');
    var descInput = document.getElementById('seoDescInput');

    if (search) {
        search.addEventListener('input', function(){
            var q = search.value.trim().toLowerCase('tr');
            cards.forEach(function(c){
                var hay = c.getAttribute('data-search') || '';
                c.style.display = (!q || hay.indexOf(q) !== -1) ? 'flex' : 'none';
            });
        });
    }

    function intStr(s){ return String(s||''); }

    function openModal(card){
        modal.classList.add('open');
        modal.style.display = 'flex';
        document.getElementById('seoKey').value = card.getAttribute('data-target') || '';
        document.getElementById('seoType').value = card.getAttribute('data-type') || 'system';
        document.getElementById('seoPageId').value = card.getAttribute('data-page-id') || '0';
        document.getElementById('seoModalTitle').textContent = card.getAttribute('data-label') || <?= json_encode(__('aseo.fallback_page')) ?>;
        document.getElementById('seoModalUrl').textContent = card.getAttribute('data-url') || '';
        titleInput.value = card.getAttribute('data-title') || '';
        descInput.value = card.getAttribute('data-description') || '';
        titleInput.readOnly = card.getAttribute('data-readonly-title') === '1';
        titleInput.style.opacity = titleInput.readOnly ? '0.55' : '1';
        titleInput.style.cursor = titleInput.readOnly ? 'not-allowed' : 'text';
        document.getElementById('seoLegalNote').style.display = (card.getAttribute('data-readonly-title') === '1') ? 'block' : 'none';
        syncPreview();
    }

    function syncPreview(){
        var t = titleInput.value.trim();
        var d = descInput.value.trim();
        var url = document.getElementById('seoModalUrl').textContent;
        var origin = (window.location.protocol + '//' + window.location.host);
        document.getElementById('seoPreviewUrl').textContent = origin + url;
        document.getElementById('seoPreviewTitle').textContent = t || <?= json_encode(__('aseo.preview_default_title')) ?>;
        document.getElementById('seoPreviewDesc').textContent = d || <?= json_encode(__('aseo.preview_default_desc')) ?>;
        document.getElementById('seoTitleCounter').textContent = titleInput.value.length + ' / 100';
        document.getElementById('seoDescCounter').textContent = descInput.value.length + ' / 200';
    }

    titleInput.addEventListener('input', syncPreview);
    descInput.addEventListener('input', syncPreview);

    cards.forEach(function(c){
        c.addEventListener('click', function(e){
            openModal(c);
        });
    });

    document.getElementById('seoModalBackdrop').addEventListener('click', closeModal);
    document.getElementById('seoModalClose').addEventListener('click', closeModal);

    function closeModal(){
        modal.classList.remove('open');
        setTimeout(function(){ modal.style.display = 'none'; }, 220);
    }
    document.addEventListener('keydown', function(e){ if (e.key === 'Escape') { var w = document.getElementById('vxwOverlay'); if (w && w.classList.contains('open')) return; closeModal(); } });

    function statusMsg(ok, msg){
        var el = document.getElementById('seoStatusMsg');
        el.style.display = 'block';
        el.style.color = ok ? '#4ade80' : '#f87171';
        el.innerHTML = (ok ? '<i class="fa-solid fa-circle-check"></i> ' : '<i class="fa-solid fa-circle-xmark"></i> ') + msg;
        setTimeout(function(){ el.style.display = 'none'; }, 3500);
    }

    document.getElementById('seoAiBtn').addEventListener('click', function(){
        var lbl = document.getElementById('seoModalTitle').textContent;
        var url = document.getElementById('seoModalUrl').textContent;
        vxwOpen({
            context: 'seo',
            mode: 'seo',
            title: 'AI SEO',
            approve: 'Uygula',
            data: {label: lbl, url: url},
            onApprove: function(seo){
                if (!seo) return;
                if (!titleInput.readOnly && seo.title) titleInput.value = seo.title;
                if (seo.desc) descInput.value = seo.desc;
                syncPreview();
            }
        });
    });

    document.getElementById('seoSaveBtn').addEventListener('click', function(){
        var btn = this;
        var mode = titleInput.readOnly ? 'meta' : 'full';
        var fd = new FormData();
        fd.append('action', 'seo_save');
        fd.append('seo_key', document.getElementById('seoKey').value);
        fd.append('type', document.getElementById('seoType').value);
        fd.append('page_id', document.getElementById('seoPageId').value);
        fd.append('title', titleInput.value);
        fd.append('description', descInput.value);
        btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> ' + <?= json_encode(__('aseo.saving')) ?>;
        fetch('/action.php', { method: 'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(d){
                btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> ' + <?= json_encode(__('msg.save')) ?>;
                if (d.ok) {
                    statusMsg(true, d.msg);
                    var activeCard = cards.find(function(c){ return c.getAttribute('data-target') === document.getElementById('seoKey').value; });
                    if (activeCard){
                        activeCard.setAttribute('data-title', titleInput.value);
                        activeCard.setAttribute('data-description', descInput.value);
                        var badge = activeCard.querySelector('.seo-badge');
                        if (badge){ badge.textContent = (titleInput.value.trim() !== '' || descInput.value.trim() !== '') ? 'SEO' : __('aseo.badge_default'); badge.classList.toggle('seo-badge--on', titleInput.value.trim() !== '' || descInput.value.trim() !== ''); }
                    }
                    closeModal();
                } else {
                    statusMsg(false, d.msg || <?= json_encode(__('topup.error')) ?>);
                }
            })
            .catch(function(){ btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> ' + <?= json_encode(__('msg.save')) ?>; statusMsg(false, <?= json_encode(__('cart.conn_err')) ?>); });
    });

    document.getElementById('seoResetBtn').addEventListener('click', function(){
        if (!confirm(<?= json_encode(__('aseo.confirm_reset')) ?>)) return;
        var fd = new FormData();
        fd.append('action', 'seo_reset');
        fd.append('seo_key', document.getElementById('seoKey').value);
        fd.append('type', document.getElementById('seoType').value);
        fd.append('page_id', document.getElementById('seoPageId').value);
        var btn = this;
        btn.disabled = true;
        fetch('/action.php', { method: 'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(d){
                btn.disabled = false;
                if (d.ok){
                    statusMsg(true, d.msg);
                    var c = document.getElementById('seoKey').value;
                    var card = cards.find(function(x){ return x.getAttribute('data-target') === c; });
                    if (card){
                        var def = card.getAttribute('data-default-title') || '';
                        titleInput.value = def;
                        descInput.value = '';
                        syncPreview();
                        var badge = card.querySelector('.seo-badge');
                        if (badge){ badge.textContent = __('aseo.badge_default'); badge.classList.remove('seo-badge--on'); }
                        card.setAttribute('data-title', def);
                        card.setAttribute('data-description', '');
                    }
                    closeModal();
                } else { statusMsg(false, d.msg); }
            })
            .catch(function(){ btn.disabled = false; statusMsg(false, <?= json_encode(__('cart.conn_err')) ?>); });
    });
})();
</script>

<?php include __DIR__ . '/includes/ai-writer.php'; ?>
<?php include __DIR__ . '/includes/layout-end.php'; ?>