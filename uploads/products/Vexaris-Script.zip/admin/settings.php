<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.settings_site');
$activePage = 'settings';

$tab = $_GET['tab'] ?? 'site';

$msg = '';

$settingsRaw = $adminDb->query("SELECT `key`,`value` FROM settings")->fetchAll();
$settings = [];
foreach ($settingsRaw as $r) $settings[$r['key']] = $r['value'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (isset($_POST['save_site_settings'])) {
        $allowed = ['site_name','site_url','site_language','active_theme','maintenance_mode','email_verify_required','site_logo','site_favicon','footer_copyright','footer_copyright_line','auto_update','loader_enabled'];
        if (isset($_POST['email_verify_required'])) $_POST['email_verify_required'] = (($_POST['email_verify_required'] ?? '0') === '1') ? '1' : '0';
        if (isset($_POST['maintenance_mode'])) $_POST['maintenance_mode'] = (($_POST['maintenance_mode'] ?? '0') === '1') ? '1' : '0';
        $pl = strtolower(trim($_POST['primary_lang'] ?? ''));
        if ($pl === 'tr' || $pl === 'en') {
            foreach (['primary_lang' => $pl, 'site_language' => $pl] as $k => $v) {
                $exists = $adminDb->prepare("SELECT `key` FROM settings WHERE `key`=? LIMIT 1");
                $exists->execute([$k]);
                if ($exists->fetch()) {
                    $adminDb->prepare("UPDATE settings SET `value`=? WHERE `key`=?")->execute([$v,$k]);
                } else {
                    $adminDb->prepare("INSERT INTO settings (`key`,`value`) VALUES (?,?)")->execute([$k,$v]);
                }
                $settings[$k] = $v;
            }
        }
        $sc = strtoupper(trim($_POST['store_currency'] ?? ''));
        if (in_array($sc, ['TRY','USD','EUR'], true)) {
            $oldSc = strtoupper(trim($settings['store_currency'] ?? 'TRY'));
            if (!in_array($oldSc, ['TRY','USD','EUR'], true)) $oldSc = 'TRY';
            $scOk = true;
            $fxNote = '';
            if ($sc !== $oldSc && function_exists('fx_migrate_currency')) {
                $mig = fx_migrate_currency($adminDb, $oldSc, $sc);
                if (empty($mig['ok'])) {
                    $scOk = false;
                    $msg = ['type'=>'error','text'=>__('bshop.fx_fail')];
                } else {
                    $fxNote = __('bshop.fx_ok', ['to' => $sc]);
                }
            }
            if ($scOk) {
                $exists = $adminDb->prepare("SELECT `key` FROM settings WHERE `key`='store_currency' LIMIT 1");
                $exists->execute();
                if ($exists->fetch()) {
                    $adminDb->prepare("UPDATE settings SET `value`=? WHERE `key`='store_currency'")->execute([$sc]);
                } else {
                    $adminDb->prepare("INSERT INTO settings (`key`,`value`) VALUES ('store_currency',?)")->execute([$sc]);
                }
                $settings['store_currency'] = $sc;
            }
        }
        foreach ($allowed as $k) {
            if (!isset($_POST[$k])) continue;
            $v = trim($_POST[$k]);
            if ($k === 'site_url') $v = rtrim($v, '/');
            $exists = $adminDb->prepare("SELECT `key` FROM settings WHERE `key`=? LIMIT 1");
            $exists->execute([$k]);
            if ($exists->fetch()) {
                $adminDb->prepare("UPDATE settings SET `value`=? WHERE `key`=?")->execute([$v,$k]);
            } else {
                $adminDb->prepare("INSERT INTO settings (`key`,`value`) VALUES (?,?)")->execute([$k,$v]);
            }
            $settings[$k] = $v;
        }
        if (empty($msg) || ($msg['type'] ?? '') !== 'error') {
            audit_log($adminDb, 'update', 'settings', 0, 'site', '/admin/settings.php?tab=site');
            $msg = ['type'=>'success','text'=>__('asett.saved_site')];
        }
        if (!empty($fxNote)) $msg['text'] .= ' ' . $fxNote;
    }

    if (isset($_POST['save_social_settings'])) {
        $socialKeys = ['social_discord','social_youtube','social_github','social_twitter'];
        foreach ($socialKeys as $k) {
            $v = trim($_POST[$k] ?? '');
            if ($v !== '') {
                $vt = rawurldecode(html_entity_decode($v, ENT_QUOTES, 'UTF-8'));
                $vt = (string)preg_replace('/[\x00-\x20\x7f]+/', '', $vt);
                if (!preg_match('~^(https?://|mailto:|/(?!/))~i', $vt)) $v = '';
                if (strlen($v) > 512) $v = substr($v, 0, 512);
            }
            $exists = $adminDb->prepare("SELECT `key` FROM settings WHERE `key`=? LIMIT 1");
            $exists->execute([$k]);
            if ($exists->fetch()) {
                $adminDb->prepare("UPDATE settings SET `value`=? WHERE `key`=?")->execute([$v,$k]);
            } else {
                $adminDb->prepare("INSERT INTO settings (`key`,`value`) VALUES (?,?)")->execute([$k,$v]);
            }
            $settings[$k] = $v;
        }
        audit_log($adminDb, 'update', 'settings', 0, 'social', '/admin/settings.php?tab=social');
        $msg = ['type'=>'success','text'=>__('asett.saved_social')];
    }

    if (isset($_POST['save_site_settings'])) {
        // footer ne ise embed o olsun
        if (isset($settings['footer_copyright'])) {
            $emb = $settings['footer_copyright'];
            $exists = $adminDb->prepare("SELECT `key` FROM settings WHERE `key`='embed_text' LIMIT 1");
            $exists->execute();
            if ($exists->fetch()) $adminDb->prepare("UPDATE settings SET `value`=? WHERE `key`='embed_text'")->execute([$emb]);
            else $adminDb->prepare("INSERT INTO settings (`key`,`value`) VALUES ('embed_text',?)")->execute([$emb]);
        }
    }
}

include __DIR__ . '/includes/layout.php';
?>
<style>
@keyframes fadeSlideUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
</style>

<?php if ($msg): ?>
<div style="background:<?= ($msg['type'] ?? '') === 'error' ? 'rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#f87171;' : 'rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#4ade80;' ?>
     padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;
     margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid <?= ($msg['type'] ?? '') === 'error' ? 'fa-circle-xmark' : 'fa-circle-check' ?>"></i> <?= e($msg['text']) ?>
</div>
<?php endif; ?>
<?php if (function_exists('fx_is_stale') && fx_is_stale()): ?>
<div style="background:rgba(234,179,8,.08);border:1px solid rgba(234,179,8,.3);color:#facc15;
     padding:12px 18px;border-radius:12px;font-size:13px;font-weight:600;
     margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid fa-triangle-exclamation"></i> <?= __('bshop.fx_stale') ?>
</div>
<?php endif; ?>

<?php if ($tab === 'site'): ?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-gear" style="color:var(--accent);margin-right:8px;"></i><?= __('asett.general') ?></span>
    </div>

    <form method="POST" id="siteSettingsForm">
        <?= csrf_field() ?>
        <input type="hidden" name="save_site_settings" value="1">

        <div class="set-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('asett.site_name') ?></label>
                <input type="text" name="site_name" maxlength="80"
                       value="<?= e($settings['site_name'] ?? 'Vexaris') ?>"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
            </div>

            <div style="grid-column:1/-1;">
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;">
                    <i class="fa-solid fa-link" style="color:var(--accent);margin-right:4px;"></i> <?= __('asett.site_url') ?> <span style="font-weight:500;color:var(--dim);"><?= __('asett.oauth_required') ?></span>
                </label>
                <input type="url" name="site_url" maxlength="120"
                       value="<?= e($settings['site_url'] ?? '') ?>"
                       placeholder="https://vexaris.com.tr"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                <p style="font-size:11px;color:var(--muted);margin-top:5px;"><i class="fa-solid fa-info-circle"></i> <?= __('asett.site_url_hint') ?></p>
                <?php
                $_oauthBase = trim($settings['site_url'] ?? '');
                if ($_oauthBase === '') {
                    $_proto = (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) ? explode(',', $_SERVER['HTTP_X_FORWARDED_PROTO'])[0] : ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http'));
                    $_oauthBase = $_proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
                }
                $_oauthBase = rtrim($_oauthBase, '/');
                ?>
                <div style="margin-top:10px;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:12px 14px;">
                    <div style="font-size:11px;font-weight:800;color:var(--muted);margin-bottom:8px;letter-spacing:.04em;"><?= __('asett.redirect_title') ?></div>
                    <?php foreach (['google','discord','microsoft','github'] as $_op): ?>
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                        <code style="flex:1;min-width:0;font-size:11px;color:var(--text);background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:7px;padding:6px 10px;overflow-x:auto;white-space:nowrap;"><?= e($_oauthBase . '/api/auth/' . $_op . '_auth') ?></code>
                        <button type="button" onclick="navigator.clipboard.writeText(this.previousElementSibling.textContent.trim()).then(()=>alert(<?= json_encode(__('panel.copied')) ?>))" style="background:var(--bg-surface);border:1px solid var(--border);border-radius:7px;padding:6px 10px;color:var(--muted);cursor:pointer;font-size:12px;" title="<?= __('panel.copy') ?>"><i class="fa-regular fa-copy"></i></button>
                    </div>
                    <?php endforeach; ?>
                    <p style="font-size:11px;color:var(--muted);margin:6px 0 0;"><i class="fa-solid fa-triangle-exclamation" style="color:#facc15;"></i> <?= __('asett.redirect_warn') ?></p>
                </div>
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('asett.site_lang') ?></label>
                <?php $siteLang = $settings['primary_lang'] ?? 'tr'; if ($siteLang !== 'tr' && $siteLang !== 'en') $siteLang = 'tr'; ?>
                <input type="hidden" name="primary_lang" id="primaryLangInput" value="<?= $siteLang ?>">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;" id="primaryLangCards">
                    <button type="button" data-lang="tr" onclick="pickPrimaryLang('tr')" style="display:flex;align-items:center;gap:10px;padding:10px;border-radius:9px;border:2px solid <?= $siteLang==='tr'?'var(--accent)':'transparent' ?>;background:rgba(255,255,255,.03);color:var(--text);font-family:inherit;font-size:13px;font-weight:700;cursor:pointer;">
                        <img src="/assets/images/flags/tr.svg" alt="TR" style="width:30px;height:20px;border-radius:3px;object-fit:cover;"> <?= __('amenu.lang_tr') ?>
                    </button>
                    <button type="button" data-lang="en" onclick="pickPrimaryLang('en')" style="display:flex;align-items:center;gap:10px;padding:10px;border-radius:9px;border:2px solid <?= $siteLang==='en'?'var(--accent)':'transparent' ?>;background:rgba(255,255,255,.03);color:var(--text);font-family:inherit;font-size:13px;font-weight:700;cursor:pointer;">
                        <img src="/assets/images/flags/en.svg" alt="EN" style="width:30px;height:20px;border-radius:3px;object-fit:cover;"> English
                    </button>
                </div>
                <p style="font-size:11px;color:var(--muted);margin:6px 0 0;"><?= __('asett.lang_hint') ?></p>
            </div>
            <script>
            function pickPrimaryLang(code){
                if(code!=='tr'&&code!=='en')code='tr';
                document.getElementById('primaryLangInput').value=code;
                document.querySelectorAll('#primaryLangCards button').forEach(function(b){
                    var on=b.getAttribute('data-lang')===code;
                    b.style.borderColor=on?'var(--accent)':'transparent';
                });
            }
            </script>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('asett.store_cur') ?></label>
                <?php $storeCur = $settings['store_currency'] ?? 'TRY'; if (!in_array($storeCur, ['TRY','USD','EUR'], true)) $storeCur = 'TRY'; ?>
                <input type="hidden" name="store_currency" id="storeCurInput" value="<?= $storeCur ?>">
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;" id="storeCurCards">
                    <?php foreach ([['TRY','₺'],['USD','$'],['EUR','€']] as [$cc,$sym]): ?>
                    <button type="button" data-cur="<?= $cc ?>" onclick="pickStoreCur('<?= $cc ?>')" style="display:flex;align-items:center;gap:10px;padding:10px;border-radius:9px;border:2px solid <?= $storeCur===$cc?'var(--accent)':'transparent' ?>;background:rgba(255,255,255,.03);color:var(--text);font-family:inherit;font-size:13px;font-weight:700;cursor:pointer;">
                        <span style="width:30px;height:20px;border-radius:3px;display:flex;align-items:center;justify-content:center;font-weight:900;background:rgba(255,255,255,.07);"><?= $sym ?></span> <?= $cc ?>
                    </button>
                    <?php endforeach; ?>
                </div>
                <p style="font-size:11px;color:var(--muted);margin:6px 0 0;"><?= __('asett.cur_hint') ?></p>
            </div>
            <script>
            function pickStoreCur(code){
                if(code!=='TRY'&&code!=='USD'&&code!=='EUR')code='TRY';
                document.getElementById('storeCurInput').value=code;
                document.querySelectorAll('#storeCurCards button').forEach(function(b){
                    var on=b.getAttribute('data-cur')===code;
                    b.style.borderColor=on?'var(--accent)':'transparent';
                });
            }
            </script>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('asett.logo_label') ?></label>
                <?php $logoUrl = $settings['site_logo'] ?? ''; ?>
                <input type="hidden" name="site_logo" id="inputSiteLogo" value="<?= e($logoUrl) ?>">
                <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                    <div id="logoPreviewBox" style="width:64px;height:64px;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;">
                        <?php if ($logoUrl): ?>
                        <img src="<?= e($logoUrl) ?>" style="max-width:100%;max-height:100%;object-fit:contain;">
                        <?php else: ?>
                        <i class="fa-solid fa-image" style="font-size:20px;color:var(--dim);"></i>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="btn-admin btn-ghost-admin" onclick="openAssetModal('logo')">
                        <i class="fa-solid fa-upload"></i> <?= __('asett.logo_pick') ?>
                    </button>
                    <?php if ($logoUrl): ?>
                    <button type="button" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2);" onclick="clearAsset('site_logo','logoPreviewBox')">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                    <?php endif; ?>
                </div>
                <p style="font-size:11px;color:var(--muted);margin-top:5px;"><i class="fa-solid fa-info-circle"></i> <?= __('asett.logo_hint') ?></p>
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;">Favicon</label>
                <?php $faviconUrl = $settings['site_favicon'] ?? ''; ?>
                <input type="hidden" name="site_favicon" id="inputSiteFavicon" value="<?= e($faviconUrl) ?>">
                <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                    <div id="faviconPreviewBox" style="width:64px;height:64px;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;">
                        <?php if ($faviconUrl): ?>
                        <img src="<?= e($faviconUrl) ?>" style="max-width:100%;max-height:100%;object-fit:contain;">
                        <?php else: ?>
                        <i class="fa-solid fa-image" style="font-size:20px;color:var(--dim);"></i>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="btn-admin btn-ghost-admin" onclick="openAssetModal('favicon')">
                        <i class="fa-solid fa-upload"></i> <?= __('asett.favicon_pick') ?>
                    </button>
                    <?php if ($faviconUrl): ?>
                    <button type="button" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2);" onclick="clearAsset('site_favicon','faviconPreviewBox')">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                    <?php endif; ?>
                </div>
                <p style="font-size:11px;color:var(--muted);margin-top:5px;"><i class="fa-solid fa-info-circle"></i> <?= __('asett.favicon_hint') ?></p>
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('asett.footer_desc') ?></label>
                <textarea name="footer_copyright" maxlength="300" rows="3" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;resize:vertical;"><?= e($settings['footer_copyright'] ?? __('asett.footer_default')) ?></textarea>
                <p style="font-size:11px;color:var(--muted);margin-top:5px;"><i class="fa-solid fa-info-circle"></i> <?= __('asett.footer_desc_hint') ?></p>
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('asett.footer_line') ?></label>
                <input type="text" name="footer_copyright_line" maxlength="160"
                       value="<?= e($settings['footer_copyright_line'] ?? __('footer.rights')) ?>"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                <p style="font-size:11px;color:var(--muted);margin-top:5px;"><i class="fa-solid fa-info-circle"></i> <?= __('asett.footer_line_hint') ?></p>
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('maint.title') ?></label>
                <select name="maintenance_mode" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <option value="0" <?= ($settings['maintenance_mode']??'0')==='0'?'selected':'' ?>><?= __('asett.opt_off') ?></option>
                    <option value="1" <?= ($settings['maintenance_mode']??'')==='1'?'selected':'' ?>><?= __('asett.opt_on') ?></option>
                </select>
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('asett.email_verify_label') ?></label>
                <select name="email_verify_required" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <option value="0" <?= ($settings['email_verify_required']??'0')==='0'?'selected':'' ?>><?= __('asett.opt_off') ?></option>
                    <option value="1" <?= ($settings['email_verify_required']??'')==='1'?'selected':'' ?>><?= __('asett.opt_on') ?></option>
                </select>
                <p style="font-size:11px;color:var(--muted);margin-top:5px;"><i class="fa-solid fa-info-circle"></i> <?= __('asett.email_verify_hint') ?></p>
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('asett.loader_label') ?></label>
                <select name="loader_enabled" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <option value="1" <?= ($settings['loader_enabled']??'1')==='1'?'selected':'' ?>><?= __('asett.opt_on') ?></option>
                    <option value="0" <?= ($settings['loader_enabled']??'1')==='0'?'selected':'' ?>><?= __('asett.opt_off') ?></option>
                </select>
                <p style="font-size:11px;color:var(--muted);margin-top:5px;"><i class="fa-solid fa-info-circle"></i> <?= __('asett.loader_hint') ?></p>
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;">
                    <i class="fa-solid fa-rotate" style="color:var(--accent);margin-right:4px;"></i> <?= __('asett.auto_update') ?>
                </label>
                <select name="auto_update" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <option value="0" <?= ($settings['auto_update']??'0')==='0'?'selected':'' ?>><?= __('asett.opt_off') ?></option>
                    <option value="1" <?= ($settings['auto_update']??'')==='1'?'selected':'' ?>><?= __('asett.opt_on') ?></option>
                </select>
                <p style="font-size:11px;color:var(--muted);margin-top:5px;"><i class="fa-solid fa-info-circle"></i> <?= __('asett.auto_update_hint') ?></p>
            </div>

            </div>

        <div style="margin-top:24px;padding-top:20px;border-top:1px solid var(--border);">
            <button type="submit" class="btn-admin btn-primary-admin">
                <i class="fa-solid fa-floppy-disk"></i> <?= __('asett.save_settings') ?>
            </button>
        </div>
    </form>

<?php elseif ($tab === 'social'): ?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-share-nodes" style="color:#22d3ee;margin-right:8px;"></i><?= __('asett.social_title') ?></span>
    </div>

    <form method="POST">
        <?= csrf_field() ?>
        <input type="hidden" name="save_social_settings" value="1">

        <div class="set-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;">
                    <i class="fa-brands fa-discord" style="color:#5865f2;margin-right:4px;"></i> Discord
                </label>
                <input type="url" name="social_discord"
                       value="<?= e($settings['social_discord'] ?? '') ?>"
                       placeholder="https://discord.gg/..."
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;">
                    <i class="fa-brands fa-youtube" style="color:#ff0000;margin-right:4px;"></i> YouTube
                </label>
                <input type="url" name="social_youtube"
                       value="<?= e($settings['social_youtube'] ?? '') ?>"
                       placeholder="https://youtube.com/@..."
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;">
                    <i class="fa-brands fa-github" style="color:#fff;margin-right:4px;"></i> GitHub
                </label>
                <input type="url" name="social_github"
                       value="<?= e($settings['social_github'] ?? '') ?>"
                       placeholder="https://github.com/..."
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;">
                    <i class="fa-brands fa-x-twitter" style="color:#fff;margin-right:4px;"></i> Twitter / X
                </label>
                <input type="url" name="social_twitter"
                       value="<?= e($settings['social_twitter'] ?? '') ?>"
                       placeholder="https://x.com/..."
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
            </div>

        </div>

        <div style="margin-top:24px;padding-top:20px;border-top:1px solid var(--border);">
            <button type="submit" class="btn-admin btn-primary-admin">
                <i class="fa-solid fa-floppy-disk"></i> <?= __('asett.save_social') ?>
            </button>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- ══ Asset Yükleme Modalı ══ -->
<div id="assetModal" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4" style="display:none;">
    <div class="absolute inset-0 bg-black/60 backdrop-blur-sm" onclick="closeAssetModal()"></div>
    <div class="relative bg-[var(--bg-card)] border border-white/10 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden" style="animation:fadeSlideUp .25s ease;">
        <div class="flex items-center justify-between p-5 border-b border-white/8">
            <h2 class="font-black text-base flex items-center gap-2" id="assetModalTitle">
                <i class="fa-solid fa-image text-indigo-400"></i> <span><?= __('asett.modal_image') ?></span>
            </h2>
            <button onclick="closeAssetModal()" class="text-slate-500 hover:text-white text-xl transition"><i class="fa-solid fa-xmark"></i></button>
        </div>

        <!-- Sekmeler -->
        <div class="flex border-b border-white/8">
            <button type="button" class="asset-tab flex-1 py-3 text-center text-sm font-bold transition" data-tab="upload" onclick="switchAssetTab('upload')" style="background:rgba(var(--accent-rgb),.12);color:#a5b4fc;border-bottom:2px solid var(--accent);">
                <i class="fa-solid fa-cloud-arrow-up mr-1"></i> <?= __('apedit.tab_file') ?>
            </button>
            <button type="button" class="asset-tab flex-1 py-3 text-center text-sm font-bold transition" data-tab="link" onclick="switchAssetTab('link')" style="color:var(--muted);">
                <i class="fa-solid fa-link mr-1"></i> <?= __('asett.link_tab') ?>
            </button>
        </div>

        <!-- Dosya Yükle Sekmesi -->
        <div id="assetTabUpload" class="p-5">
            <div id="assetDropZone"
                 style="background:var(--bg-surface);border:2px dashed var(--border);border-radius:12px;padding:32px;text-align:center;cursor:pointer;transition:border-color .2s,background .2s;"
                 onclick="document.getElementById('assetFileInput').click()"
                 ondragover="this.style.borderColor='var(--accent)';this.style.background='rgba(var(--accent-rgb),0.06)';return false;"
                 ondragleave="this.style.borderColor='var(--border)';this.style.background='var(--bg-surface)';"
                 ondrop="handleAssetDrop(event)">
                <input type="file" id="assetFileInput" accept="image/jpeg,image/png,image/webp,image/gif" style="display:none;" onchange="handleAssetFileSelect(this)">
                <div id="assetDropContent">
                    <i class="fa-solid fa-cloud-arrow-up" style="font-size:36px;color:var(--dim);display:block;margin-bottom:12px;"></i>
                    <p style="font-size:13px;color:var(--muted);font-weight:600;margin-bottom:4px;"><?= __('asett.drop_title') ?></p>
                    <p style="font-size:11px;color:var(--dim);">WEBP, JPG, PNG, GIF</p>
                </div>
                <div id="assetPreviewArea" style="display:none;">
                    <img id="assetPreviewImg" style="max-height:100px;max-width:100%;object-fit:contain;border-radius:8px;margin:0 auto;">
                </div>
            </div>
            <div id="assetUploadStatus" class="hidden mt-3 text-sm font-semibold rounded-lg px-3 py-2"></div>
            <button type="button" id="assetUploadBtn" onclick="submitAssetUpload()" class="btn-admin btn-primary-admin w-full justify-center mt-4 hidden">
                <i class="fa-solid fa-upload"></i> <?= __('panel.upload') ?>
            </button>
        </div>

        <!-- Link Sekmesi -->
        <div id="assetTabLink" class="p-5" style="display:none;">
            <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('apedit.image_url') ?></label>
            <div style="display:flex;gap:8px;">
                <input type="url" id="assetLinkInput" placeholder="https://ornek.com/resim.webp"
                       style="flex:1;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                <button type="button" onclick="applyAssetLink()" class="btn-admin btn-primary-admin">
                    <i class="fa-solid fa-check"></i> <?= __('cart.coupon_apply') ?>
                </button>
            </div>
            <div id="assetLinkPreview" class="mt-3 hidden">
                <img id="assetLinkPreviewImg" style="max-height:80px;max-width:100%;object-fit:contain;border-radius:6px;margin:0 auto;">
            </div>
        </div>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-server" style="color:#22d3ee;margin-right:8px;"></i><?= __('asett.sysinfo') ?></span>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;">
        <?php $info = [
            [__('asett.info_version'), function_exists('vexaris_current_version') ? 'v' . vexaris_current_version($adminDb) : '1.0.0', 'fa-box-archive'],
            [__('asett.info_php'), PHP_VERSION, 'fa-code'],
            [__('asett.info_server'), $_SERVER['SERVER_SOFTWARE'] ?? __('asett.info_unknown'), 'fa-server'],
            [__('asett.info_tz'), date_default_timezone_get(), 'fa-clock'],
            [__('asett.info_time'), date('d.m.Y H:i'), 'fa-calendar'],
        ]; foreach ($info as [$k,$v,$icon]): ?>
        <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;padding:16px;">
            <div style="font-size:11px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px;">
                <i class="fa-solid <?= $icon ?>" style="margin-right:5px;"></i><?= $k ?>
            </div>
            <div style="font-size:13px;font-weight:700;color:var(--text);overflow-wrap:anywhere;min-width:0;"><?= e($v) ?></div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php
$extraScripts = <<<JS

<script>
var _assetTargetField = '';
var _assetSelectedFile = null;

function openAssetModal(type) {
    _assetTargetField = type;
    document.getElementById('assetModalTitle').querySelector('span').textContent = type === 'logo' ? <?= json_encode(__('asett.logo_upload')) ?> : <?= json_encode(__('asett.favicon_upload')) ?>;
    document.getElementById('assetModal').style.display = 'flex';
    document.getElementById('assetModal').classList.remove('hidden');
    resetAssetModal();
}

function closeAssetModal() {
    document.getElementById('assetModal').style.display = 'none';
    document.getElementById('assetModal').classList.add('hidden');
}

function resetAssetModal() {
    _assetSelectedFile = null;
    document.getElementById('assetFileInput').value = '';
    document.getElementById('assetDropContent').style.display = 'block';
    document.getElementById('assetPreviewArea').style.display = 'none';
    document.getElementById('assetUploadBtn').classList.add('hidden');
    document.getElementById('assetUploadStatus').classList.add('hidden');
    document.getElementById('assetLinkInput').value = '';
    document.getElementById('assetLinkPreview').classList.add('hidden');
    switchAssetTab('upload');
}

function switchAssetTab(tab) {
    document.querySelectorAll('.asset-tab').forEach(function(t) {
        if (t.dataset.tab === tab) {
            t.style.background = 'rgba(var(--accent-rgb),.12)';
            t.style.color = '#a5b4fc';
            t.style.borderBottom = '2px solid var(--accent)';
        } else {
            t.style.background = '';
            t.style.color = 'var(--muted)';
            t.style.borderBottom = '';
        }
    });
    document.getElementById('assetTabUpload').style.display = tab === 'upload' ? 'block' : 'none';
    document.getElementById('assetTabLink').style.display = tab === 'link' ? 'block' : 'none';
}

function handleAssetDrop(e) {
    e.preventDefault();
    var zone = document.getElementById('assetDropZone');
    zone.style.borderColor = 'var(--border)';
    zone.style.background = 'var(--bg-surface)';
    var file = e.dataTransfer.files[0];
    if (file) handleAssetFile(file);
}

function handleAssetFileSelect(input) {
    if (input.files && input.files[0]) handleAssetFile(input.files[0]);
}

function handleAssetFile(file) {
    if (!file.type.match(/image\/(jpeg|png|webp|gif)/)) {
        showAssetStatus(<?= json_encode(__('apedit.bad_format')) ?>, false);
        return;
    }
    _assetSelectedFile = file;
    document.getElementById('assetDropContent').style.display = 'none';
    document.getElementById('assetPreviewArea').style.display = 'block';
    document.getElementById('assetUploadBtn').classList.remove('hidden');
    var reader = new FileReader();
    reader.onload = function(e) { document.getElementById('assetPreviewImg').src = e.target.result; };
    reader.readAsDataURL(file);
    document.getElementById('assetUploadStatus').classList.add('hidden');
}

function showAssetStatus(msg, ok) {
    var el = document.getElementById('assetUploadStatus');
    el.className = 'mt-3 text-sm font-semibold rounded-lg px-3 py-2 flex items-center gap-2' + (ok ? ' bg-green-900/30 border border-green-700 text-green-300' : ' bg-red-900/30 border border-red-700 text-red-300');
    el.innerHTML = '<i class="fa-solid fa-' + (ok ? 'circle-check' : 'circle-xmark') + '"></i> ' + msg;
    el.classList.remove('hidden');
}

async function submitAssetUpload() {
    if (!_assetSelectedFile) return;
    var btn = document.getElementById('assetUploadBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> ' + <?= json_encode(__('aprod.loading')) ?>;
    var fd = new FormData();
    fd.append('action', 'asset_upload');
    fd.append('ctx', 'settings');
    fd.append('asset_type', _assetTargetField);
    fd.append('file', _assetSelectedFile);
    try {
        var r = await fetch('/action.php', {method:'POST', body:fd});
        var d = await r.json();
        if (d.ok) {
            showAssetStatus(<?= json_encode(__('asett.uploaded_ok')) ?>, true);
            applyAssetUrl(d.url);
        } else {
            showAssetStatus(d.msg || <?= json_encode(__('apedit.upload_fail')) ?>, false);
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-upload"></i> ' + <?= json_encode(__('panel.upload')) ?>;
        }
    } catch(e) {
        showAssetStatus(<?= json_encode(__('aprod.req_fail_short')) ?>, false);
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-upload"></i> ' + <?= json_encode(__('panel.upload')) ?>;
    }
}

function applyAssetUrl(url) {
    var idMap = { logo: 'inputSiteLogo', favicon: 'inputSiteFavicon' };
    var hiddenInput = document.getElementById(idMap[_assetTargetField] || ('input' + _assetTargetField.charAt(0).toUpperCase() + _assetTargetField.slice(1)));
    var previewBox = document.getElementById(_assetTargetField + 'PreviewBox');
    if (hiddenInput) hiddenInput.value = url;
    if (previewBox) {
        previewBox.innerHTML = '<img src="' + url + '" style="max-width:100%;max-height:100%;object-fit:contain;">';
    }
    setTimeout(closeAssetModal, 1200);
}

function applyAssetLink() {
    var url = document.getElementById('assetLinkInput').value.trim();
    if (!url) { showAssetStatus(<?= json_encode(__('apedit.url_required')) ?>, false); return; }
    var preview = document.getElementById('assetLinkPreview');
    var img = document.getElementById('assetLinkPreviewImg');
    img.src = url;
    preview.classList.remove('hidden');
    img.onload = function() {
        showAssetStatus(<?= json_encode(__('asett.link_working')) ?>, true);
        applyAssetUrl(url);
    };
    img.onerror = function() {
        showAssetStatus(<?= json_encode(__('apedit.link_bad')) ?>, false);
    };
}

function clearAsset(field, previewId) {
    var idMap = { site_logo: 'inputSiteLogo', site_favicon: 'inputSiteFavicon' };
    var input = document.getElementById(idMap[field] || ('input' + field.charAt(0).toUpperCase() + field.slice(1)));
    if (input) input.value = '';
    document.getElementById(previewId).innerHTML = '<i class="fa-solid fa-image" style="font-size:20px;color:var(--dim);"></i>';
}

</script>
JS;
include __DIR__ . '/includes/layout-end.php';
?>
