<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = 'Slider';
$activePage = 'slider';

$flash = $_GET['flash'] ?? '';
[$flashType, $flashText] = $flash ? explode(':', urldecode($flash), 2) + ['',''] : ['',''];

$sliders = [];
try { $sliders = $adminDb->query('SELECT * FROM sliders ORDER BY sort_order ASC, id DESC')->fetchAll(); } catch (Throwable $e) {}

$sliderRowsJson = json_encode(array_map(function($s){
    return ['id' => (int)$s['id'], 'content' => (string)($s['content'] ?? ''), 'bg' => (string)($s['bg_color'] ?? 'var(--accent)'), 'link' => (string)($s['link_url'] ?? ''), 'marquee' => (int)($s['marquee'] ?? 0), 'speed' => (int)($s['speed'] ?? 20), 'active' => (int)($s['is_active'] ?? 1)];
}, $sliders), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);

require_once __DIR__ . '/../core/editor.php';
require_once __DIR__ . '/../core/color-picker.php';
include __DIR__ . '/includes/layout.php';
?>
<style>
#vxSliderModal{display:none;position:fixed;inset:0;z-index:9990;}
#vxSliderBackdrop{position:absolute;inset:0;background:rgba(2,6,23,.72);backdrop-filter:blur(6px);}
#vxSliderWrap{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding:20px;pointer-events:none;}
#vxSliderPanel{pointer-events:auto;margin:0;width:min(720px,100%);max-height:92vh;display:flex;flex-direction:column;animation:vxSliderIn .3s cubic-bezier(.22,1.2,.36,1);}
@keyframes vxSliderIn{from{opacity:0;transform:translateY(24px) scale(.98);}to{opacity:1;transform:none;}}
#vxSliderBody{overflow-y:auto;padding:20px 22px;}
@media(max-width:640px){
  #vxSliderWrap{padding:0;}
  #vxSliderPanel{width:100%;height:100dvh;max-height:100dvh;border-radius:0;}
}
</style>

<?php if ($flashText): ?>
<div style="padding:12px 18px;border-radius:12px;font-size:13px;font-weight:700;margin-bottom:18px;display:flex;align-items:center;gap:8px;background:<?= $flashType==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;border:1px solid <?= $flashType==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;color:<?= $flashType==='success'?'#4ade80':'#f87171' ?>;">
    <i class="fa-solid fa-<?= $flashType==='success'?'circle-check':'circle-xmark' ?>"></i> <?= e($flashText) ?>
</div>
<?php endif; ?>

<div class="admin-card" style="margin-bottom:0;">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-images" style="color:var(--accent);margin-right:8px;"></i> <?= __('aslid.list_title') ?> <span style="color:var(--muted);font-weight:500;">(<?= count($sliders) ?>)</span></span>
        <button type="button" class="btn-admin btn-primary-admin" style="font-size:12px;padding:8px 16px;" onclick="vxSliderOpen()"><i class="fa-solid fa-plus"></i> <?= __('aprod.new') ?></button>
    </div>
    <?php if (empty($sliders)): ?>
    <div style="text-align:center;padding:72px 20px;">
        <div style="width:76px;height:76px;border-radius:22px;background:rgba(var(--accent-rgb),.1);border:1px solid rgba(var(--accent-rgb),.2);display:flex;align-items:center;justify-content:center;margin:0 auto 18px;font-size:30px;color:#818cf8;"><i class="fa-solid fa-images"></i></div>
        <p style="font-size:16px;font-weight:800;margin-bottom:6px;"><?= __('aslid.empty_title') ?></p>
        <p style="font-size:13px;color:var(--muted);margin-bottom:22px;"><?= __('aslid.empty_hint') ?></p>
        <button type="button" class="btn-admin btn-primary-admin" style="padding:11px 26px;font-size:13px;" onclick="vxSliderOpen()"><i class="fa-solid fa-plus"></i> <?= __('aslid.add_first') ?></button>
    </div>
    <?php else: ?>
    <div style="display:flex;flex-direction:column;gap:10px;">
        <?php foreach ($sliders as $s): $bg = $s['bg_color'] ?? 'var(--accent)'; if(!preg_match('/^#[0-9a-fA-F]{6}$/',$bg)) $bg='var(--accent)'; ?>
        <div style="border:1px solid var(--border);border-radius:12px;overflow:hidden;background:var(--bg-surface);">
            <div style="background:<?= e($bg) ?>;padding:10px 14px;color:#fff;font-size:13px;line-height:1.5;text-align:center;min-height:38px;display:flex;align-items:center;justify-content:center;">
                <span style="display:block;word-break:break-word;"><?= nx_clean_html((string)($s['content'] ?? ''), 'basic') ?></span>
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;gap:10px;flex-wrap:wrap;">
                <div style="display:flex;align-items:center;gap:8px;font-size:11px;color:var(--muted);">
                    <span style="display:flex;align-items:center;gap:6px;"><span style="width:14px;height:14px;border-radius:4px;background:<?= e($bg) ?>;border:1px solid rgba(255,255,255,.15);display:inline-block;"></span> <?= e($bg) ?></span>
                    <span style="background:<?= $s['is_active']?'rgba(34,197,94,.12)':'rgba(239,68,68,.12)' ?>;color:<?= $s['is_active']?'#4ade80':'#f87171' ?>;padding:2px 8px;border-radius:999px;font-weight:800;font-size:10px;"><?= $s['is_active']?__('adash.status_active'):__('aint.passive') ?></span>
                    <span>#<?= $s['id'] ?> · <?= date('d.m.Y H:i', strtotime($s['created_at'])) ?></span>
                    <?php if (!empty($s['marquee'])): ?><span style="font-size:10px;color:#22d3ee;font-weight:800;"><i class="fa-solid fa-arrows-left-right"></i> <?= __('aslid.badge_marquee') ?> · <?= (int)($s['speed'] ?? 20) ?><?= __('aslid.sec') ?></span><?php endif; ?>
                    <?php if (!empty($s['link_url'])): ?><span style="font-size:10px;color:#a78bfa;font-weight:800;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= e($s['link_url']) ?>"><i class="fa-solid fa-link"></i> <?= e($s['link_url']) ?></span><?php endif; ?>
                </div>
                <div style="display:flex;gap:6px;">
                    <button type="button" class="btn-admin btn-ghost-admin" style="padding:6px 12px;font-size:12px;" onclick="vxSliderOpen(<?= (int)$s['id'] ?>)" title="<?= __('product.edit') ?>"><i class="fa-solid fa-pen"></i></button>
                    <form method="POST" action="/action.php" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="slider_toggle">
                        <input type="hidden" name="id" value="<?= $s['id'] ?>">
                        <button type="submit" class="btn-admin" style="padding:6px 12px;font-size:12px;background:<?= $s['is_active']?'rgba(234,179,8,.12)':'rgba(34,197,94,.12)' ?>;color:<?= $s['is_active']?'#facc15':'#4ade80' ?>;border:1px solid <?= $s['is_active']?'rgba(234,179,8,.25)':'rgba(34,197,94,.25)' ?>;"><i class="fa-solid fa-<?= $s['is_active']?'eye-slash':'eye' ?>"></i></button>
                    </form>
                    <form method="POST" action="/action.php" onsubmit="return confirm(<?= json_encode(__('aslid.delete_confirm')) ?>);" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="slider_delete">
                        <input type="hidden" name="id" value="<?= $s['id'] ?>">
                        <button type="submit" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;padding:6px 12px;font-size:12px;border:1px solid rgba(239,68,68,.2);"><i class="fa-solid fa-trash"></i></button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<script type="application/json" id="vxSliderRows"><?= $sliderRowsJson ?></script>

<div id="vxSliderModal" role="dialog" aria-label="Slider">
  <div id="vxSliderBackdrop" onclick="vxSliderClose()"></div>
  <div id="vxSliderWrap">
    <div class="admin-card" id="vxSliderPanel">
      <div class="admin-card-header" style="margin-bottom:0;padding:18px 22px 0;border:none;">
        <span class="admin-card-title" style="font-size:15px;"><i class="fa-solid fa-pen-to-square" style="color:var(--accent);"></i> <span id="vxSliderTitle"><?= __('aslid.modal_new') ?></span></span>
        <button type="button" onclick="vxSliderClose()" aria-label="<?= __('modal.close') ?>" style="background:var(--bg-surface);border:1px solid var(--border);color:var(--muted);width:32px;height:32px;border-radius:9px;cursor:pointer;font-size:14px;"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div id="vxSliderBody">
    <form method="POST" action="/action.php" id="sliderForm">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="slider_save">
        <input type="hidden" name="id" id="sliderId" value="0">

        <div style="margin-bottom:14px;">
            <label style="font-size:11px;font-weight:800;color:var(--muted);display:block;margin-bottom:6px;letter-spacing:.3px;text-transform:uppercase;"><i class="fa-solid fa-font" style="color:var(--accent);margin-right:4px;"></i> <?= __('aslid.content_label') ?></label>
            <?php render_slider_editor('sliderContent', '', '140px', 'content'); ?>
            <div style="font-size:11px;color:var(--dim);margin-top:6px;"><i class="fa-solid fa-circle-info"></i> <?= __('aslid.content_hint') ?></div>
        </div>

        <div style="margin-bottom:14px;">
            <label style="font-size:11px;font-weight:800;color:var(--muted);display:block;margin-bottom:6px;letter-spacing:.3px;text-transform:uppercase;"><i class="fa-solid fa-fill-drip" style="color:var(--accent);margin-right:4px;"></i> <?= __('aslid.bg_label') ?></label>
            <?php render_color_picker('sliderBg', 'var(--accent)', 'bg_color'); ?>
            <div style="font-size:11px;color:var(--dim);margin-top:6px;"><?= __('aslid.bg_hint') ?></div>
        </div>

        <div style="margin-bottom:14px;">
            <label style="font-size:11px;font-weight:800;color:var(--muted);display:block;margin-bottom:6px;letter-spacing:.3px;text-transform:uppercase;"><i class="fa-solid fa-link" style="color:var(--accent);margin-right:4px;"></i> <?= __('aslid.link_label') ?></label>
            <input type="text" id="sliderLink" name="link_url" value="" placeholder="<?= __('aslid.link_ph') ?>" maxlength="512" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 12px;color:var(--text);font-size:13px;outline:none;box-sizing:border-box;" onfocus="this.style.borderColor='var(--accent)'" onblur="this.style.borderColor='var(--border)'">
            <div style="font-size:11px;color:var(--dim);margin-top:6px;"><?= __('aslid.link_hint') ?></div>
        </div>

        <div style="margin-bottom:14px;">
            <label style="font-size:11px;font-weight:800;color:var(--muted);display:block;margin-bottom:6px;letter-spacing:.3px;text-transform:uppercase;"><i class="fa-solid fa-gauge-high" style="color:var(--accent);margin-right:4px;"></i> <?= __('aslid.speed_label') ?> <span id="sliderSpeedOut" style="color:var(--accent);"><?= __('aslid.speed_initial') ?></span></label>
            <input type="range" id="sliderSpeed" name="speed" min="5" max="60" step="1" value="20" style="width:100%;accent-color:var(--accent);">
            <div style="font-size:11px;color:var(--dim);margin-top:6px;"><?= __('aslid.speed_hint') ?></div>
        </div>

        <div style="margin-bottom:16px;display:grid;gap:10px;">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px;font-weight:700;color:var(--text);">
                <input type="checkbox" id="sliderMarquee" name="marquee" value="1" style="width:16px;height:16px;accent-color:var(--accent);"> <?= __('aslid.marquee_label') ?>
                <span style="font-size:11px;color:var(--muted);font-weight:500;"><?= __('aslid.marquee_hint') ?></span>
            </label>
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px;font-weight:700;color:var(--text);">
                <input type="checkbox" id="sliderActive" name="is_active" value="1" checked style="width:16px;height:16px;accent-color:var(--accent);"> <?= __('adash.status_active') ?>
                <span style="font-size:11px;color:var(--muted);font-weight:500;"><?= __('aslid.active_hint') ?></span>
            </label>
        </div>

        <button type="submit" class="btn-admin btn-primary-admin" style="width:100%;justify-content:center;padding:12px;font-size:13px;">
            <i class="fa-solid fa-floppy-disk"></i> <span id="vxSliderSave"><?= __('aint.save') ?></span>
        </button>
        <div style="margin-top:10px;background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.18);border-radius:10px;padding:10px 12px;font-size:11px;color:var(--muted);line-height:1.6;">
            <i class="fa-solid fa-eye" style="color:var(--accent);"></i> <?= __('aslid.visible_note') ?>
        </div>
    </form>
      </div>
    </div>
  </div>
</div>

<script>
var vxSliderRows = [];
try { vxSliderRows = JSON.parse(document.getElementById('vxSliderRows').textContent || '[]'); } catch (e) { vxSliderRows = []; }
function vxSliderFill(row) {
    document.getElementById('sliderId').value = row ? row.id : 0;
    var ta = document.getElementById('sliderContent');
    var body = document.getElementById('sedBody-sliderContent');
    var html = row ? row.content : '';
    if (ta) ta.value = html;
    if (body) body.innerHTML = html;
    var bg = document.getElementById('sliderBg');
    var prev = document.getElementById('cpPrev-sliderBg');
    var c = (row && /^#[0-9a-fA-F]{6}$/.test(row.bg)) ? row.bg.toUpperCase() : '#6366F1';
    if (bg) bg.value = c;
    if (prev) prev.style.background = c;
    document.getElementById('sliderActive').checked = row ? !!row.active : true;
    document.getElementById('sliderMarquee').checked = row ? !!row.marquee : false;
    document.getElementById('sliderLink').value = row ? (row.link || '') : '';
    vxSliderSpeed(row ? (parseInt(row.speed, 10) || 20) : 20);
    document.getElementById('vxSliderTitle').textContent = row ? <?= json_encode(__('aslid.modal_edit')) ?> : <?= json_encode(__('aslid.modal_new')) ?>;
    document.getElementById('vxSliderSave').textContent = row ? <?= json_encode(__('aprod.update')) ?> : <?= json_encode(__('aint.save')) ?>;
}
function vxSliderOpen(id) {
    var row = null;
    if (id) {
        for (var i = 0; i < vxSliderRows.length; i++) {
            if (vxSliderRows[i].id === parseInt(id, 10)) { row = vxSliderRows[i]; break; }
        }
    }
    vxSliderFill(row);
    document.getElementById('vxSliderModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}
function vxSliderClose() {
    document.getElementById('vxSliderModal').style.display = 'none';
    document.body.style.overflow = '';
}
function vxSliderSpeed(v) {
    v = Math.min(60, Math.max(5, parseInt(v, 10) || 20));
    document.getElementById('sliderSpeed').value = v;
    document.getElementById('sliderSpeedOut').textContent = v + ' sn';
}
document.getElementById('sliderSpeed').addEventListener('input', function(){ vxSliderSpeed(this.value); });
document.addEventListener('keydown', function(e){
    if (e.key === 'Escape' && document.getElementById('vxSliderModal').style.display === 'block') vxSliderClose();
});
</script>

<script>
document.getElementById('sliderForm').addEventListener('submit', function(e){
    var body = document.getElementById('sedBody-sliderContent');
    var ta = document.getElementById('sliderContent');
    if (body && ta) ta.value = body.innerHTML;
    var bg = document.getElementById('sliderBg');
    if (bg) {
        var v = bg.value.trim();
        if (!v.startsWith('#')) v = '#' + v;
        if (!/^#[0-9A-Fa-f]{6}$/.test(v)) {
            e.preventDefault();
            alert(<?= json_encode(__('aslid.err_bg')) ?>);
            bg.focus();
            return false;
        }
        bg.value = v.toUpperCase();
    }
    var content = ta ? ta.value.trim() : '';
    var stripped = content.replace(/<[^>]*>/g,'').trim();
    if (!stripped) {
        e.preventDefault();
        alert(<?= json_encode(__('aslid.err_empty')) ?>);
        if(body) body.focus();
        return false;
    }
});
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
