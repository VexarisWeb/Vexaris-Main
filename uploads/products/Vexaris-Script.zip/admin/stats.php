<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';
if (!function_exists('has_permission') || !has_permission('stats')) {
    header('Location: /admin', true, 302);
    exit;
}
$pageTitle  = __('amenu.stats');
$activePage = 'stats';

$range = (int)($_GET['range'] ?? 14);
if (!in_array($range, [7, 14, 30], true)) $range = 14;

$st = ['revenue' => 0.0, 'orders' => 0, 'users' => 0, 'products' => 0, 'views' => 0, 'avg_dur' => 0.0, 'regs' => 0, 'avg_order' => 0.0, 't_open' => 0, 't_replied' => 0, 't_closed' => 0, 'coupon_uses' => 0, 'rv_count' => 0, 'rv_avg' => 0.0];
$daily = [];
$dailyRegs = [];
$top = [];
$recent = [];
$gateways = [];
$tickets = [];
$coupons = [];
$rvDist = [];
try {
    $st['revenue'] = (float)$adminDb->query("SELECT COALESCE(SUM(total_amount),0) FROM payment_intents WHERE status='completed'")->fetchColumn();
    $st['orders'] = (int)$adminDb->query("SELECT COUNT(*) FROM sales")->fetchColumn();
    $st['users'] = (int)$adminDb->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
    $st['products'] = (int)$adminDb->query("SELECT COUNT(*) FROM products WHERE status='active' AND is_hidden=0")->fetchColumn();
} catch (Throwable $e) {}
$stpPlan = function_exists('plan_current') ? plan_current() : ['slug' => 'free', 'product_limit' => 7, 'revenue_limit_usd' => 100.0, 'revenue_reset' => 'never'];
$stpPCount = function_exists('plan_product_count') ? plan_product_count($adminDb) : 0;
$stpPLim = (int)($stpPlan['product_limit'] ?? 7);
$stpRevSum = function_exists('plan_revenue_sum') ? plan_revenue_sum($adminDb) : 0.0;
$stpRevLim = (float)($stpPlan['revenue_limit_usd'] ?? 100.0);
$stpStore = function_exists('store_currency') ? store_currency() : 'TRY';
$stpLimStore = ($stpRevLim >= 0 && function_exists('fx_convert')) ? (float)fx_convert($stpRevLim, 'USD', $stpStore) : $stpRevLim;
try {
    $rg = $adminDb->prepare("SELECT COUNT(*) AS c, COALESCE(SUM(total_amount),0) AS s FROM payment_intents WHERE status='completed' AND updated_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)");
    $rg->execute([$range]);
    $rgr = $rg->fetch() ?: [];
    $rc = (int)($rgr['c'] ?? 0);
    if ($rc > 0) $st['avg_order'] = (float)($rgr['s'] ?? 0) / $rc;
    $ur = $adminDb->prepare("SELECT COUNT(*) FROM users WHERE role='user' AND created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)");
    $ur->execute([$range]);
    $st['regs'] = (int)$ur->fetchColumn();
} catch (Throwable $e) {}
try {
    $gq = $adminDb->prepare("SELECT payment_method AS m, COUNT(*) AS c, COALESCE(SUM(total_amount),0) AS s FROM payment_intents WHERE status='completed' AND updated_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY) GROUP BY payment_method ORDER BY s DESC");
    $gq->execute([$range]);
    $gateways = $gq->fetchAll() ?: [];
} catch (Throwable $e) {}
try {
    $tq = $adminDb->query("SELECT status, COUNT(*) AS c FROM tickets GROUP BY status")->fetchAll();
    foreach ($tq as $tr) {
        if ($tr['status'] === 'open') $st['t_open'] = (int)$tr['c'];
        elseif ($tr['status'] === 'replied') $st['t_replied'] = (int)$tr['c'];
        elseif ($tr['status'] === 'closed') $st['t_closed'] = (int)$tr['c'];
    }
    $tickets = $tq ?: [];
} catch (Throwable $e) {}
try {
    $st['coupon_uses'] = (int)$adminDb->query("SELECT COALESCE(SUM(used_count),0) FROM coupons")->fetchColumn();
    $coupons = $adminDb->query("SELECT code, used_count, max_uses, is_active FROM coupons ORDER BY used_count DESC, code ASC LIMIT 8")->fetchAll() ?: [];
} catch (Throwable $e) {}
try {
    $rq = $adminDb->query("SELECT COUNT(*) AS c, COALESCE(AVG(NULLIF(rating,0)),0) AS a FROM comments WHERE rating>0")->fetch() ?: [];
    $st['rv_count'] = (int)($rq['c'] ?? 0);
    $st['rv_avg'] = round((float)($rq['a'] ?? 0), 1);
    $rvDist = $adminDb->query("SELECT rating AS r, COUNT(*) AS c FROM comments WHERE rating>0 GROUP BY rating ORDER BY rating DESC")->fetchAll() ?: [];
} catch (Throwable $e) {}
try {
    $uq = $adminDb->prepare("SELECT DATE(created_at) AS d, COUNT(*) AS c FROM users WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY) GROUP BY DATE(created_at) ORDER BY d ASC");
    $uq->execute([$range]);
    $umap = [];
    foreach ($uq->fetchAll() as $r) $umap[$r['d']] = (int)$r['c'];
    for ($i = $range - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime('-' . $i . ' days'));
        $dailyRegs[] = ['d' => $d, 'c' => $umap[$d] ?? 0];
    }
} catch (Throwable $e) {}
try {
    $q = $adminDb->prepare("SELECT DATE(updated_at) AS d, COALESCE(SUM(total_amount),0) AS s, COUNT(*) AS c FROM payment_intents WHERE status='completed' AND updated_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY) GROUP BY DATE(updated_at) ORDER BY d ASC");
    $q->execute([$range]);
    $rows = $q->fetchAll();
    $map = [];
    foreach ($rows as $r) $map[$r['d']] = $r;
    for ($i = $range - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime('-' . $i . ' days'));
        $daily[] = ['d' => $d, 's' => (float)($map[$d]['s'] ?? 0), 'c' => (int)($map[$d]['c'] ?? 0)];
    }
} catch (Throwable $e) {}
try {
    $t = $adminDb->query("SELECT p.id AS pid, p.name AS name, COUNT(*) AS c, COALESCE(SUM(s.price_paid),0) AS s FROM sales s JOIN products p ON p.id=s.product_id GROUP BY s.product_id ORDER BY c DESC, s DESC LIMIT 8")->fetchAll();
    $top = $t ?: [];
} catch (Throwable $e) {}
try {
    $r = $adminDb->query("SELECT s.product_id, s.price_paid, s.purchased_at, u.username, u.avatar, p.name AS pname FROM sales s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN products p ON p.id=s.product_id ORDER BY s.id DESC LIMIT 8")->fetchAll();
    $recent = $r ?: [];
} catch (Throwable $e) {}
try {
    $topCustomers = $adminDb->query("SELECT u.id, u.username, u.avatar, COUNT(s.id) AS c, COALESCE(SUM(s.price_paid),0) AS s FROM sales s JOIN users u ON u.id=s.user_id GROUP BY s.user_id ORDER BY s DESC LIMIT 6")->fetchAll() ?: [];
} catch (Throwable $e) { $topCustomers = []; }
try {
    $vq = $adminDb->prepare("SELECT COUNT(*) AS c, COUNT(DISTINCT session_key) AS u, COALESCE(AVG(NULLIF(duration_sec,0)),0) AS a FROM custom_page_views WHERE entered_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)");
    $vq->execute([$range]);
    $vr = $vq->fetch() ?: [];
    $st['views'] = (int)($vr['c'] ?? 0);
    $st['avg_dur'] = round((float)($vr['a'] ?? 0), 1);
} catch (Throwable $e) {}
$maxS = 1;
foreach ($daily as $dd) $maxS = max($maxS, $dd['s']);
$maxC = 1;
foreach ($daily as $dd) $maxC = max($maxC, $dd['c']);
$topMax = 1;
foreach ($top as $tp) $topMax = max($topMax, (int)$tp['c']);
function st_money(float $v): string { return fmt_money($v); }
function st_dur(float $s): string {
    if ($s <= 0) return '—';
    if ($s < 60) return rtrim(rtrim(number_format($s, 1, ',', '.'), '0'), ',') . __('apage.sec_suffix');
    return floor($s / 60) . __('apage.min_suffix') . round($s - floor($s / 60) * 60) . __('apage.sec_suffix');
}
$pts = [];
foreach ($daily as $i => $dd) {
    $x = count($daily) > 1 ? round($i / (count($daily) - 1) * 100, 1) : 0;
    $y = 100 - round($dd['s'] / $maxS * 88, 1) - 6;
    $pts[] = $x . ',' . $y;
}
include __DIR__ . '/includes/layout.php';
?>
<style>
.st-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;margin-bottom:20px;}
.st-kpi{background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:18px;}
.st-kpi .l{font-size:11px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px;}
.st-kpi .v{font-size:24px;font-weight:900;}
.st-kpi .s{font-size:11px;color:var(--dim);margin-top:4px;}
.st-grid{display:grid;grid-template-columns:1.4fr 1fr;gap:20px;margin-bottom:20px;}
.st-bars{display:flex;align-items:flex-end;gap:5px;height:150px;margin-top:14px;}
.st-bar{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;gap:5px;min-width:0;}
.st-bar i{display:block;width:100%;border-radius:5px 5px 2px 2px;background:linear-gradient(180deg,var(--accent),#4338ca);}
.st-bar span{font-size:9px;color:var(--muted);font-weight:600;}
.st-rowline{display:flex;align-items:center;gap:10px;margin-top:10px;}
.st-rowline .t{font-size:12px;font-weight:700;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.st-track{flex:2;height:8px;border-radius:99px;background:var(--bg-surface);overflow:hidden;}
.st-track i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#22d3ee,#0891b2);}
.st-num{font-size:12px;font-weight:800;white-space:nowrap;}
.st-bar i{transition:filter .15s;}
.st-bar:hover i{filter:brightness(1.3);}
.st-dot{fill:var(--accent);stroke:var(--bg-card);stroke-width:1.5;cursor:pointer;transition:r .15s;}
.st-dot:hover{r:4;}
#stTip{position:fixed;z-index:300;display:none;background:var(--bg-card);border:1px solid var(--accent);color:var(--text);padding:8px 12px;border-radius:10px;font-size:12px;font-weight:600;line-height:1.6;white-space:nowrap;pointer-events:none;box-shadow:0 10px 28px rgba(0,0,0,.4);}
#stTip b{color:var(--accent);}
.st-grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;margin-bottom:20px;}
@media(max-width:900px){.st-grid{grid-template-columns:1fr;}.st-grid3{grid-template-columns:1fr;gap:16px;margin-bottom:16px;}}
@media(max-width:768px){.st-kpis{grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:16px;}.st-kpi{padding:14px;}.st-kpi .v{font-size:19px;}.st-grid{gap:16px;margin-bottom:16px;}.st-rowline{flex-wrap:wrap;}.st-rowline .t{flex:1 1 100%;white-space:normal;}.st-rowline .st-track{flex:1;}}
@media(max-width:480px){.st-kpi{padding:12px;}.st-kpi .v{font-size:17px;}.st-bar span{font-size:8px;}}
</style>

<div style="display:flex;align-items:center;gap:10px;margin-bottom:20px;flex-wrap:wrap;">
    <span class="admin-card-title" style="font-size:17px;"><i class="fa-solid fa-chart-line" style="color:var(--accent);margin-right:8px;"></i> <?= __('amenu.stats') ?></span>
    <span style="flex:1;"></span>
    <?php foreach ([7, 14, 30] as $r): ?>
    <a href="/admin/stats.php?range=<?= $r ?>" class="btn-admin <?= $r === $range ? 'btn-primary-admin' : 'btn-ghost-admin' ?>" style="padding:7px 14px;font-size:12px;"><?= __('astat.last_days', ['n' => $r]) ?></a>
    <?php endforeach; ?>
</div>

<div class="st-kpis">
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-wallet"></i> <?= __('astat.kpi_revenue') ?></div><div class="v"><?= e(st_money($st['revenue'])) ?></div><div class="s"><?= __('astat.all_time') ?></div></div>
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-bag-shopping"></i> <?= __('adash.chart_orders') ?></div><div class="v"><?= number_format($st['orders']) ?></div><div class="s"><?= __('astat.all_time') ?></div></div>
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-users"></i> <?= __('astat.kpi_members') ?></div><div class="v"><?= number_format($st['users']) ?></div><div class="s"><?= __('astat.members_sub') ?></div></div>
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-box-open"></i> <?= __('astat.kpi_products') ?></div><div class="v"><?= number_format($st['products']) ?></div><div class="s"><?= __('astat.products_sub') ?> · <?= e(__('plan.products_x_y', ['have' => $stpPCount, 'limit' => $stpPLim >= 0 ? $stpPLim : __('plan.unlimited')])) ?></div></div>
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-crown"></i> <?= __('plan.period_revenue') ?> (<?= e(ucfirst((string)($stpPlan['slug'] ?? 'free'))) ?>)</div><div class="v"><?= e(st_money($stpRevSum)) ?></div><div class="s"><?= $stpLimStore >= 0 ? e(st_money($stpLimStore)) : e(__('plan.unlimited')) ?><?php if ($stpRevLim >= 0 && $stpStore !== 'USD'): ?> ($<?= number_format($stpRevLim, 2) ?>)<?php endif; ?> · <?= ($stpPlan['revenue_reset'] ?? 'monthly') === 'never' ? e(__('plan.reset_never')) : e(__('plan.reset_monthly')) ?></div></div>
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-eye"></i> <?= __('astat.kpi_views') ?></div><div class="v"><?= number_format($st['views']) ?></div><div class="s"><?= __('astat.views_sub', ['n' => $range]) ?></div></div>
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-clock"></i> <?= __('astat.kpi_stay') ?></div><div class="v"><?= e(st_dur($st['avg_dur'])) ?></div><div class="s"><?= __('astat.stay_sub', ['n' => $range]) ?></div></div>
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-user-plus"></i> <?= __('astat.kpi_registrations') ?></div><div class="v">+<?= number_format($st['regs']) ?></div><div class="s"><?= __('astat.range_sub', ['n' => $range]) ?></div></div>
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-receipt"></i> <?= __('astat.kpi_avg_order') ?></div><div class="v"><?= e(st_money($st['avg_order'])) ?></div><div class="s"><?= __('astat.range_sub', ['n' => $range]) ?></div></div>
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-headset"></i> <?= __('astat.kpi_tickets') ?></div><div class="v"><?= number_format($st['t_open'] + $st['t_replied'] + $st['t_closed']) ?></div><div class="s"><?= __('astat.ticket_open') ?>: <?= (int)$st['t_open'] ?> · <?= __('astat.ticket_replied') ?>: <?= (int)$st['t_replied'] ?> · <?= __('astat.ticket_closed') ?>: <?= (int)$st['t_closed'] ?></div></div>
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-ticket"></i> <?= __('astat.kpi_coupons') ?></div><div class="v"><?= number_format($st['coupon_uses']) ?></div><div class="s"><?= __('astat.all_time') ?></div></div>
    <div class="st-kpi"><div class="l"><i class="fa-solid fa-star"></i> <?= __('astat.kpi_reviews') ?></div><div class="v"><?= number_format($st['rv_avg'], 1) ?> <span style="font-size:13px;color:var(--muted);">/ 5</span></div><div class="s"><?= number_format($st['rv_count']) ?> <?= __('astat.review_count') ?></div></div>
</div>

<div class="st-grid">
    <div class="admin-card" style="margin-bottom:0;">
        <div class="admin-card-header"><span class="admin-card-title"><i class="fa-solid fa-sack-dollar" style="color:#22c55e;margin-right:8px;"></i> <?= __('astat.daily_revenue') ?></span></div>
        <?php if ($maxS > 0): ?>
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" style="width:100%;height:120px;display:block;background:var(--bg-surface);border-radius:10px;padding:0;">
            <polyline points="<?= e(implode(' ', $pts)) ?>" fill="none" style="stroke:var(--accent)" stroke-width="2" vector-effect="non-scaling-stroke" stroke-linejoin="round" stroke-linecap="round"/>
            <?php foreach ($daily as $i => $dd): ?>
            <?php $px = count($daily) > 1 ? round($i / (count($daily) - 1) * 100, 1) : 0; $py = 100 - round($dd['s'] / $maxS * 88, 1) - 6; ?>
            <circle cx="<?= $px ?>" cy="<?= $py ?>" r="2.2" class="st-dot" data-stip="<?= e('<b>' . date('d/m', strtotime($dd['d'])) . '</b><br>' . st_money($dd['s']) . ' · ' . $dd['c'] . __('astat.orders_suffix')) ?>" vector-effect="non-scaling-stroke"/>
            <?php endforeach; ?>
        </svg>
        <?php endif; ?>
        <div class="st-bars">
            <?php foreach ($daily as $dd): ?>
            <?php $h = $dd['s'] > 0 ? max(6, round($dd['s'] / $maxS * 100)) : 3; ?>
            <div class="st-bar" data-stip="<?= e('<b>' . date('d/m', strtotime($dd['d'])) . '</b><br>' . st_money($dd['s']) . ' · ' . $dd['c'] . __('astat.orders_suffix')) ?>">
                <i style="height:<?= $h ?>%;<?= $dd['s'] > 0 ? '' : 'background:rgba(255,255,255,.08);' ?>"></i>
                <span><?= e(date('d/m', strtotime($dd['d']))) ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="admin-card" style="margin-bottom:0;">
        <div class="admin-card-header"><span class="admin-card-title"><i class="fa-solid fa-crown" style="color:#fbc853;margin-right:8px;"></i> <?= __('astat.bestsellers') ?></span></div>
        <?php if (empty($top)): ?>
        <p style="font-size:13px;color:var(--muted);"><?= __('astat.no_sales') ?></p>
        <?php else: ?>
        <?php foreach ($top as $tp): ?>
        <div class="st-rowline">
            <span class="t"><a href="/admin/products.php?edit=<?= (int)($tp['pid'] ?? 0) ?>" style="color:var(--text);"><?= e($tp['name'] ?? '—') ?></a></span>
            <span class="st-track"><i style="width:<?= max(4, round((int)$tp['c'] / $topMax * 100)) ?>%;"></i></span>
            <span class="st-num"><?= (int)$tp['c'] ?> <?= __('astat.orders_suffix') ?></span>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<div class="st-grid">
    <div class="admin-card" style="margin-bottom:0;">
        <div class="admin-card-header"><span class="admin-card-title"><i class="fa-solid fa-user-plus" style="color:#818cf8;margin-right:8px;"></i> <?= __('astat.reg_title') ?></span><span style="font-size:11px;color:var(--muted);">+<?= number_format($st['regs']) ?></span></div>
        <?php $regMax = 1; foreach ($dailyRegs as $dd) $regMax = max($regMax, $dd['c']); ?>
        <div class="st-bars">
            <?php foreach ($dailyRegs as $dd): ?>
            <?php $h = $dd['c'] > 0 ? max(6, round($dd['c'] / $regMax * 100)) : 3; ?>
            <div class="st-bar" data-stip="<?= e('<b>' . date('d/m', strtotime($dd['d'])) . '</b><br>+' . $dd['c']) ?>">
                <i style="height:<?= $h ?>%;<?= $dd['c'] > 0 ? '' : 'background:rgba(255,255,255,.08);' ?>"></i>
                <span><?= e(date('d/m', strtotime($dd['d']))) ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="admin-card" style="margin-bottom:0;">
        <div class="admin-card-header"><span class="admin-card-title"><i class="fa-solid fa-credit-card" style="color:#22d3ee;margin-right:8px;"></i> <?= __('astat.gateway_title') ?></span></div>
        <?php if (empty($gateways)): ?>
        <p style="font-size:13px;color:var(--muted);"><?= __('astat.gateway_empty') ?></p>
        <?php else: ?>
        <?php $gwMax = 1.0; foreach ($gateways as $gs) $gwMax = max($gwMax, (float)$gs['s']); ?>
        <?php foreach ($gateways as $gs): ?>
        <div class="st-rowline">
            <span class="t"><?= e(role_gateway_label((string)$gs['m'])) ?></span>
            <span class="st-track"><i style="width:<?= max(4, round((float)$gs['s'] / $gwMax * 100)) ?>%;"></i></span>
            <span class="st-num"><?= e(st_money((float)$gs['s'])) ?> <span style="color:var(--muted);font-weight:600;">· <?= (int)$gs['c'] ?></span></span>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<div class="st-grid3">
    <div class="admin-card" style="margin-bottom:0;">
        <div class="admin-card-header"><span class="admin-card-title"><i class="fa-solid fa-headset" style="color:#eab308;margin-right:8px;"></i> <?= __('astat.ticket_title') ?></span></div>
        <div class="st-rowline"><span class="t"><?= __('astat.ticket_open') ?></span><span class="st-num" style="color:#f87171;"><?= (int)$st['t_open'] ?></span></div>
        <div class="st-rowline"><span class="t"><?= __('astat.ticket_replied') ?></span><span class="st-num" style="color:#eab308;"><?= (int)$st['t_replied'] ?></span></div>
        <div class="st-rowline"><span class="t"><?= __('astat.ticket_closed') ?></span><span class="st-num" style="color:#4ade80;"><?= (int)$st['t_closed'] ?></span></div>
    </div>
    <div class="admin-card" style="margin-bottom:0;">
        <div class="admin-card-header"><span class="admin-card-title"><i class="fa-solid fa-ticket" style="color:#4ade80;margin-right:8px;"></i> <?= __('astat.coupon_title') ?></span></div>
        <?php if (empty($coupons)): ?>
        <p style="font-size:13px;color:var(--muted);"><?= __('astat.coupon_empty') ?></p>
        <?php else: ?>
        <?php foreach ($coupons as $cp): ?>
        <div class="st-rowline">
            <span class="t"><?= e($cp['code']) ?></span>
            <span class="st-num"><?= (int)$cp['used_count'] ?>/<?= (int)$cp['max_uses'] ?> <?= __('astat.coupon_used') ?></span>
            <span class="badge <?= ((int)$cp['is_active'] === 1) ? 'badge-green' : 'badge-red' ?>" style="flex-shrink:0;"><?= ((int)$cp['is_active'] === 1) ? '●' : '○' ?></span>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <div class="admin-card" style="margin-bottom:0;">
        <div class="admin-card-header"><span class="admin-card-title"><i class="fa-solid fa-star" style="color:#facc15;margin-right:8px;"></i> <?= __('astat.review_title') ?></span><span style="font-size:11px;color:var(--muted);"><?= __('astat.review_avg') ?>: <?= number_format($st['rv_avg'], 1) ?></span></div>
        <?php if (empty($rvDist)): ?>
        <p style="font-size:13px;color:var(--muted);"><?= __('astat.review_empty') ?></p>
        <?php else: ?>
        <?php $rvMax = 1; foreach ($rvDist as $rd) $rvMax = max($rvMax, (int)$rd['c']); ?>
        <?php foreach ($rvDist as $rd): ?>
        <div class="st-rowline">
            <span class="t">★ <?= (int)$rd['r'] ?></span>
            <span class="st-track"><i style="width:<?= max(4, round((int)$rd['c'] / $rvMax * 100)) ?>%;"></i></span>
            <span class="st-num"><?= (int)$rd['c'] ?></span>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<div class="st-grid">
<div class="admin-card" style="margin-bottom:0;">
    <div class="admin-card-header"><span class="admin-card-title"><i class="fa-solid fa-clock-rotate-left" style="color:#818cf8;margin-right:8px;"></i> <?= __('astat.recent_sales') ?></span></div>
    <?php if (empty($recent)): ?>
    <p style="font-size:13px;color:var(--muted);"><?= __('astat.no_sales') ?></p>
    <?php else: ?>
    <div style="display:flex;flex-direction:column;gap:8px;">
    <?php foreach ($recent as $rc): ?>
    <div class="st-rowline" style="background:var(--bg-surface);border-radius:10px;padding:9px 12px;">
        <img src="<?= e($rc['avatar'] ?: 'https://minotar.net/avatar/user.png') ?>" onerror="this.src='https://minotar.net/avatar/user.png'" style="width:30px;height:30px;border-radius:50%;object-fit:cover;flex-shrink:0;" alt="">
        <span class="t"><a href="/admin/products.php?edit=<?= (int)($rc['product_id'] ?? 0) ?>" style="color:var(--text);"><?= e($rc['pname'] ?? '—') ?></a><br><span style="font-weight:600;color:var(--muted);font-size:11px;"><?= e($rc['username'] ?? '—') ?></span></span>
        <span class="st-num" style="color:#4ade80;"><?= e(st_money((float)$rc['price_paid'])) ?></span>
        <span style="font-size:10px;color:var(--muted);white-space:nowrap;"><?= e(date('d/m H:i', strtotime($rc['purchased_at']))) ?></span>
    </div>
    <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<div class="admin-card" style="margin-bottom:0;">
    <div class="admin-card-header"><span class="admin-card-title"><i class="fa-solid fa-users" style="color:#c084fc;margin-right:8px;"></i> <?= __('astat.top_customers') ?></span></div>
    <?php if (empty($topCustomers)): ?>
    <p style="font-size:13px;color:var(--muted);"><?= __('astat.no_sales') ?></p>
    <?php else: ?>
    <?php $tcMax = 1; foreach ($topCustomers as $tc) $tcMax = max($tcMax, (int)$tc['c']); ?>
    <?php foreach ($topCustomers as $tc): ?>
    <div class="st-rowline">
        <img src="<?= e($tc['avatar'] ?: 'https://minotar.net/avatar/user.png') ?>" onerror="this.src='https://minotar.net/avatar/user.png'" style="width:28px;height:28px;border-radius:50%;object-fit:cover;flex-shrink:0;" alt="">
        <span class="t"><?= e($tc['username'] ?? ('#' . (int)$tc['id'])) ?></span>
        <span class="st-track"><i style="width:<?= max(4, round((int)$tc['c'] / $tcMax * 100)) ?>%;"></i></span>
        <span class="st-num"><?= (int)$tc['c'] ?> <?= __('astat.orders_suffix') ?></span>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
</div>
</div>

<div id="stTip"></div>
<script>
(function(){
    var tip = document.getElementById('stTip');
    if (!tip) return;
    function show(html, x, y){
        tip.innerHTML = html;
        tip.style.display = 'block';
        var w = tip.offsetWidth, h = tip.offsetHeight;
        var lx = x + 14, ly = y - h - 12;
        if (lx + w > window.innerWidth - 8) lx = x - w - 14;
        if (ly < 8) ly = y + 16;
        tip.style.left = Math.round(lx) + 'px';
        tip.style.top = Math.round(ly) + 'px';
    }
    function hide(){ tip.style.display = 'none'; }
    document.querySelectorAll('[data-stip]').forEach(function(el){
        el.addEventListener('mousemove', function(e){ show(el.getAttribute('data-stip'), e.clientX, e.clientY); });
        el.addEventListener('mouseleave', hide);
    });
})();
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
