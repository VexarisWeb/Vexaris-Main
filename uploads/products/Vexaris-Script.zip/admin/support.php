<?php
require_once __DIR__ . '/includes/guard.php';

$pageTitle  = __('asupp.page_title');
$activePage = 'support';

$tid = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['change_status']) && $tid) {
        $newStatus = $_POST['new_status'] ?? 'open';
        if (in_array($newStatus, ['open','replied','closed'])) {
            $adminDb->prepare('UPDATE tickets SET status=? WHERE id=?')->execute([$newStatus, $tid]);
        }
        header("Location: /admin/support.php?id={$tid}&flash=" . urlencode('success:' . __('asupp.status_updated')));
        exit;
    }
}

/* ── Aktif ticket ── */
$activeTicket  = null;
$ticketReplies = [];
if ($tid) {
    $activeTicket = $adminDb->prepare(
        'SELECT t.*,u.username,u.email,u.avatar FROM tickets t
         LEFT JOIN users u ON u.id=t.user_id WHERE t.id=?'
    );
    $activeTicket->execute([$tid]);
    $activeTicket = $activeTicket->fetch();

    if ($activeTicket) {
        $rStmt = $adminDb->prepare(
            'SELECT r.*,u.username,u.avatar FROM ticket_replies r
             LEFT JOIN users u ON u.id=r.user_id WHERE r.ticket_id=? ORDER BY r.created_at ASC, r.id ASC'
        );
        $rStmt->execute([$tid]);
        $ticketReplies = $rStmt->fetchAll();
        try {
            $adminDb->prepare('UPDATE ticket_replies SET is_seen=1 WHERE ticket_id=? AND is_admin=0')->execute([$tid]);
            foreach ($ticketReplies as &$trow) { if ((int)$trow['is_admin'] === 0) $trow['is_seen'] = 1; }
            unset($trow);
        } catch (\PDOException $e) {}
    }
}

/* ── Ticket listesi ── */
$filterStatus = $_GET['status'] ?? 'all';
if (!in_array($filterStatus, ['all','open','replied','closed'], true)) $filterStatus = 'all';
$searchQ      = trim($_GET['q'] ?? '');
$searchQLike  = str_replace(['\\','%','_'], ['\\\\','\\%','\\_'], $searchQ);

$where  = [];
$params = [];
if ($filterStatus !== 'all') { $where[] = 't.status = ?'; $params[] = $filterStatus; }
if ($searchQ)                { $where[] = '(t.title LIKE ? OR u.username LIKE ? OR u.email LIKE ?)'; $params = array_merge($params, ["%$searchQLike%","%$searchQLike%","%$searchQLike%"]); }
$whereSql = $where ? 'WHERE '.implode(' AND ',$where) : '';

$tickets = $adminDb->prepare(
    "SELECT t.*,u.username,u.email,
            (SELECT COUNT(*) FROM ticket_replies r WHERE r.ticket_id=t.id) AS reply_count
     FROM tickets t LEFT JOIN users u ON u.id=t.user_id
     {$whereSql}
     ORDER BY FIELD(t.status,'open','answered','closed'), COALESCE(t.updated_at,t.created_at) DESC, t.id DESC"
);
$tickets->execute($params);
$tickets = $tickets->fetchAll();

/* İstatistik sayaçları */
$counts = ['all'=>0,'open'=>0,'replied'=>0,'closed'=>0];
foreach ($adminDb->query(
    'SELECT status,COUNT(*) c FROM tickets GROUP BY status'
)->fetchAll() as $r) {
    $counts[$r['status']] = (int)$r['c'];
    $counts['all'] += (int)$r['c'];
}

$flash = (string)($_GET['flash'] ?? '');
$flashType = $flashText = '';
if ($flash !== '') { [$flashType, $flashText] = array_pad(explode(':', $flash, 2), 2, ''); }

include __DIR__ . '/includes/layout.php';
?>

<style>
.ticket-admin-shell{display:grid;grid-template-columns:360px 1fr;gap:0;height:calc(100vh - 60px);overflow:hidden;}
.ticket-admin-left{background:var(--bg-card);border-right:1px solid var(--border);display:flex;flex-direction:column;overflow:hidden;min-height:0;}
.ticket-admin-right{display:flex;flex-direction:column;overflow:hidden;min-height:0;}
.ta-list{flex:1;overflow-y:auto;}
.ta-item{display:flex;flex-direction:column;gap:5px;padding:13px 16px;
  border-bottom:1px solid var(--border);cursor:pointer;transition:background .12s;}
.ta-item:hover{background:var(--bg-hover);}
.ta-item.active{background:rgba(var(--accent-rgb),.1);border-left:3px solid var(--accent);}
.ta-item-title{font-size:13px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.ta-item-sub{font-size:12px;color:var(--muted);display:flex;justify-content:space-between;}
.badge-s{display:inline-flex;align-items:center;gap:4px;padding:2px 9px;border-radius:999px;font-size:10px;font-weight:700;}
.badge-open    {background:rgba(239,68,68,.12);color:#f87171;}
.badge-replied {background:rgba(var(--accent-rgb),.12);color:#a5b4fc;}
.badge-closed  {background:rgba(100,116,139,.12);color:#94a3b8;}
.ta-head{padding:16px 20px;border-bottom:1px solid var(--border);flex-shrink:0;}
.ta-msgs{flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:14px;}
.ta-reply-area{padding:16px 20px;border-top:1px solid var(--border);flex-shrink:0;}
.msg-bubble{max-width:72%;display:flex;flex-direction:column;gap:5px;}
.msg-bubble.user-msg{align-self:flex-start;}
.msg-bubble.admin-msg{align-self:flex-end;}
.msg-text{padding:11px 15px;border-radius:14px;font-size:13px;line-height:1.6;}
.msg-bubble.user-msg .msg-text{background:var(--bg-surface);border:1px solid var(--border);border-bottom-left-radius:4px;}
.msg-bubble.admin-msg .msg-text{background:rgba(var(--accent-rgb),.18);border:1px solid rgba(var(--accent-rgb),.3);border-bottom-right-radius:4px;}
.msg-meta{font-size:10px;color:var(--muted);opacity:0;visibility:hidden;transition:opacity .2s;}
.msg-bubble:hover .msg-meta{opacity:1;visibility:visible;}
.msg-ticks{font-size:10px;font-weight:700;color:var(--muted);}
.msg-ticks.tick-seen{color:#53bdeb;}
@keyframes nxTickPop{0%{transform:scale(.4);opacity:0}60%{transform:scale(1.25)}100%{transform:scale(1);opacity:1}}
.tick-pop{animation:nxTickPop .45s cubic-bezier(.34,1.56,.64,1);}
@keyframes nxMsgIn{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}
.msg-in{animation:nxMsgIn .3s ease;}
@keyframes nxSendFly{0%{transform:translateX(0);opacity:1}100%{transform:translateX(26px);opacity:0}}
.nx-send-fly svg,.nx-send-fly i{animation:nxSendFly .35s ease;}
.nx-composer{display:flex;align-items:center;gap:8px;background:var(--bg-surface);border:1px solid var(--border);border-radius:999px;padding:6px 6px 6px 8px;transition:border-color .2s;}
.nx-composer:focus-within{border-color:rgba(var(--accent-rgb),.55);}
.nx-attach-btn{flex-shrink:0;width:38px;height:38px;border-radius:50%;border:1px solid var(--border);background:rgba(255,255,255,.04);color:var(--muted);cursor:pointer;font-size:15px;display:flex;align-items:center;justify-content:center;transition:.15s;}
.nx-attach-btn:hover{color:#fff;border-color:rgba(var(--accent-rgb),.5);}
.nx-chat-input{flex:1;min-width:0;background:transparent;border:none;outline:none;color:var(--text);font-family:inherit;font-size:13px;padding:8px 2px;}
.nx-chat-input::placeholder{color:var(--dim);}
.nx-count{flex-shrink:0;font-size:10px;color:var(--dim);font-weight:700;min-width:44px;text-align:right;}
.nx-send-btn{flex-shrink:0;width:42px;height:42px;border-radius:50%;border:none;cursor:pointer;background:linear-gradient(135deg,#38bdf8,#2563eb);color:#fff;font-size:15px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 14px rgba(37,99,235,.4);transition:transform .12s,filter .15s,opacity .15s;}
.nx-send-btn:hover{filter:brightness(1.1);}
.nx-send-btn:active{transform:scale(.9);}
.nx-send-btn.is-idle{opacity:.55;}
.nx-attach-preview{display:flex;align-items:center;gap:8px;margin-bottom:8px;}
.nx-attach-preview img{width:52px;height:52px;object-fit:cover;border-radius:10px;border:1px solid rgba(var(--accent-rgb),.4);}
.nx-attach-x{width:24px;height:24px;border-radius:50%;border:1px solid var(--border);background:rgba(239,68,68,.15);color:#f87171;cursor:pointer;font-size:11px;}
.nx-chat-img{max-width:240px;max-height:180px;border-radius:10px;border:1px solid var(--border);margin-bottom:6px;display:block;cursor:zoom-in;}
.hidden{display:none!important;}
@media(max-width:560px){.nx-count{display:none;}.msg-bubble{max-width:90%!important;}.nx-chat-img{max-width:180px;}}
.ff{width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;
  padding:9px 13px;color:var(--text);font-family:inherit;font-size:13px;outline:none;transition:border-color .2s;}
.ff:focus{border-color:rgba(var(--accent-rgb),.5);}
.btn-reply{display:inline-flex;align-items:center;gap:7px;padding:9px 20px;border-radius:9px;
  background:var(--accent);color:#fff;font-weight:700;font-size:13px;border:none;
  box-shadow:0 4px 0 var(--accent-dark),0 8px 14px rgba(0,0,0,.25);cursor:pointer;transition:transform .05s,box-shadow .05s;}
.btn-reply:active{transform:translateY(3px);box-shadow:0 1px 0 var(--accent-dark);}
@media(max-width:900px){.ticket-admin-shell{grid-template-columns:1fr;height:auto;}}
@media(max-width:480px){.ta-head{padding:10px 12px!important;flex-wrap:wrap;gap:8px;}.ta-list-item{padding:10px 12px!important;}.ta-msgs{padding:10px!important;}.msg-bubble{max-width:90%!important;font-size:13px!important;}.ta-reply-area{padding:10px 12px!important;}.ticket-admin-left,.ticket-admin-right{padding:0!important;}}
</style>

<div id="flashToast" class="<?= $flashType ? 'show' : '' ?>" data-type="<?= $flashType ?>" style="position:fixed;top:72px;right:24px;z-index:9999;transition:opacity .35s,transform .35s;opacity:0;transform:translateY(-12px);pointer-events:none;">
    <div style="display:flex;align-items:center;gap:10px;padding:14px 22px;border-radius:14px;font-size:13px;font-weight:700;box-shadow:0 8px 32px rgba(0,0,0,.35);backdrop-filter:blur(12px);background:rgba(16,185,129,.15);border:1px solid rgba(16,185,129,.3);color:#34d399;">
        <i class="fa-solid fa-circle-check fa-lg"></i>
        <span id="flashToastText"><?= e($flashText) ?></span>
    </div>
</div>
<script>
(function(){
    var t = document.getElementById('flashToast');
    if (t && t.dataset.type) {
        setTimeout(function(){ t.style.opacity = '1'; t.style.transform = 'translateY(0)'; }, 80);
        setTimeout(function(){
            t.style.opacity = '0';
            t.style.transform = 'translateY(-12px)';
        }, 4500);
        setTimeout(function(){ t.remove(); }, 5000);
    }
})();
</script>

<div class="ticket-admin-shell" style="margin:-28px;height:calc(100vh - 60px);">

    <!-- SOL: Liste -->
    <div class="ticket-admin-left">

        <!-- Filtreler -->
        <div class="ta-head">
            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;">
                <?php foreach (['all'=>__('shop.all'),'open'=>__('ticket.open'),'replied'=>__('ticket.replied'),'closed'=>__('ticket.closed')] as $sv=>$sl): ?>
                <a href="/admin/support.php?status=<?= $sv ?><?= $searchQ?'&q='.urlencode($searchQ):'' ?><?= $tid?"&id={$tid}":'' ?>"
                   style="display:inline-flex;align-items:center;gap:5px;padding:5px 12px;border-radius:8px;font-size:12px;font-weight:700;
                          background:<?= $filterStatus===$sv?'rgba(var(--accent-rgb),.15)':'var(--bg-surface)' ?>;
                          color:<?= $filterStatus===$sv?'#a5b4fc':'var(--muted)' ?>;
                          border:1px solid <?= $filterStatus===$sv?'rgba(var(--accent-rgb),.4)':'var(--border)' ?>;">
                    <?= $sl ?>
                    <span style="background:rgba(255,255,255,.08);padding:0 5px;border-radius:5px;"><?= $counts[$sv] ?></span>
                </a>
                <?php endforeach; ?>
            </div>
            <form method="GET" style="display:flex;gap:6px;">
                <?php if ($filterStatus!=='all'): ?><input type="hidden" name="status" value="<?= $filterStatus ?>"><?php endif; ?>
                <?php if ($tid): ?><input type="hidden" name="id" value="<?= $tid ?>"><?php endif; ?>
                <input type="text" name="q" value="<?= e($searchQ) ?>" class="ff" placeholder="<?= __('asupp.search_ph') ?>" style="flex:1;">
                <button type="submit" style="background:var(--accent);color:#fff;border:none;border-radius:8px;padding:8px 14px;cursor:pointer;font-size:13px;">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </form>
        </div>

        <!-- Ticket Listesi -->
        <div class="ta-list">
            <?php if (empty($tickets)): ?>
            <p style="text-align:center;color:var(--muted);padding:32px;font-size:13px;"><?= __('err.ticket_missing') ?></p>
            <?php else: ?>
            <?php foreach ($tickets as $t): ?>
            <?php $sc=['open'=>'badge-open','replied'=>'badge-replied','closed'=>'badge-closed']; ?>
            <a href="/admin/support.php?id=<?= $t['id'] ?>&status=<?= $filterStatus ?><?= $searchQ?'&q='.urlencode($searchQ):'' ?>"
               style="text-decoration:none;display:block;">
                <div class="ta-item <?= $tid===(int)$t['id']?'active':'' ?>">
                    <div class="ta-item-title"><?= e($t['title']) ?></div>
                    <div class="ta-item-sub">
                        <span style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                            <?= e($t['username'] ?? __('asupp.unknown_user')) ?>
                        </span>
                        <span class="badge-s <?= $sc[$t['status']] ?? 'badge-closed' ?>">
                            <?= ['open'=>__('ticket.open'),'replied'=>__('ticket.replied'),'closed'=>__('ticket.closed')][$t['status']] ?? e($t['status']) ?>
                        </span>
                    </div>
                    <div style="font-size:11px;color:var(--dim);display:flex;justify-content:space-between;">
                        <span><?= date('d.m.Y H:i', strtotime($t['created_at'])) ?></span>
                        <span><?= $t['reply_count'] ?> <i class="fa-regular fa-comment" style="font-size:10px;"></i></span>
                    </div>
                </div>
            </a>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- SAĞ: Detay & Yanıt -->
    <div class="ticket-admin-right">

        <?php if (!$tid || !$activeTicket): ?>
        <div style="flex:1;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;color:var(--muted);">
            <i class="fa-solid fa-messages" style="font-size:48px;color:var(--dim);"></i>
            <p style="font-size:14px;font-weight:600;"><?= __('asupp.pick_prompt') ?></p>
        </div>

        <?php else: ?>

        <!-- Ticket Başlık Barı -->
        <div class="ta-head" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
            <div>
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:3px;flex-wrap:wrap;">
                    <h2 style="font-size:15px;font-weight:800;"><?= e($activeTicket['title']) ?></h2>
                    <?php $sc=['open'=>'badge-open','replied'=>'badge-replied','closed'=>'badge-closed'];
                          $sl=['open'=>__('ticket.open'),'replied'=>__('ticket.replied'),'closed'=>__('ticket.closed')]; ?>
                    <span class="badge-s <?= $sc[$activeTicket['status']] ?? 'badge-closed' ?>"><?= $sl[$activeTicket['status']] ?? e($activeTicket['status']) ?></span>
                </div>
                <div style="font-size:12px;color:var(--muted);">
                    <span style="font-weight:700;"><?= e($activeTicket['username'] ?? '—') ?></span>
                    &lt;<?= e($activeTicket['email'] ?? '') ?>&gt;
                    · <?= e($activeTicket['category'] ?? __('shop.general')) ?>
                    · #<?= $activeTicket['id'] ?>
                    · <?= date('d.m.Y H:i', strtotime($activeTicket['created_at'])) ?>
                </div>
            </div>
            <!-- Durum Değiştir + Kapat + Sil + Kapat(X) -->
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                <form method="POST" style="display:flex;gap:6px;align-items:center;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="change_status" value="1">
                    <select name="new_status" class="ff" style="padding:6px 10px;font-size:12px;">
                        <option value="open"    <?= $activeTicket['status']==='open'   ?'selected':'' ?>><?= __('ticket.open') ?></option>
                        <option value="replied" <?= $activeTicket['status']==='replied'?'selected':'' ?>><?= __('ticket.replied') ?></option>
                        <option value="closed"  <?= $activeTicket['status']==='closed' ?'selected':'' ?>><?= __('ticket.closed') ?></option>
                    </select>
                    <button type="submit" class="btn-reply" style="padding:7px 14px;font-size:12px;">
                        <i class="fa-solid fa-check"></i> <?= __('cart.coupon_apply') ?>
                    </button>
                </form>
                <form method="POST" onsubmit="return confirm(<?= json_encode(__('support.confirm_close')) ?>);" title="<?= __('asupp.close_title') ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="change_status" value="1">
                    <input type="hidden" name="new_status" value="closed">
                    <button type="submit" style="background:rgba(255,255,255,.05);color:var(--text);border:1px solid var(--border);border-radius:9px;padding:7px 12px;cursor:pointer;font-size:12px;">
                        <i class="fa-solid fa-lock"></i>
                    </button>
                </form>
                <?php if (in_array(($adminUser['role'] ?? ''), ['admin', 'superadmin'], true)): ?>
                <form method="POST" action="/action.php" onsubmit="return confirm(<?= json_encode(__('asupp.delete_confirm')) ?>);" title="<?= __('asupp.delete_title') ?>">
                    <input type="hidden" name="action" value="ticket_delete">
                    <input type="hidden" name="ticket_id" value="<?= (int)$activeTicket['id'] ?>">
                    <?= csrf_field() ?>
                    <button type="submit" style="background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.25);border-radius:9px;padding:7px 12px;cursor:pointer;font-size:12px;">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </form>
                <?php endif; ?>
                <a href="/admin/support.php" title="<?= __('asupp.back_title') ?>" style="background:rgba(255,255,255,.05);color:var(--muted);border:1px solid var(--border);border-radius:9px;padding:7px 12px;font-size:12px;text-decoration:none;">
                    <i class="fa-solid fa-xmark"></i>
                </a>
            </div>
        </div>

        <!-- Mesaj Akışı -->
        <div class="ta-msgs" id="adminMsgBox">

            <!-- İlk mesaj -->
            <div class="msg-bubble user-msg">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
                    <img src="<?= e($activeTicket['avatar'] ?? 'https://minotar.net/avatar/user.png') ?>"
                         style="width:24px;height:24px;border-radius:50%;image-rendering:pixelated;border:1.5px solid var(--border);">
                    <span style="font-size:12px;font-weight:700;color:var(--text);"><?= e($activeTicket['username'] ?? __('asupp.user_fallback')) ?></span>
                </div>
                <div class="msg-text"><?= e($activeTicket['message'] ?? '—') ?></div>
                <div class="msg-meta"><?= date('d.m.Y H:i', strtotime($activeTicket['created_at'])) ?></div>
            </div>

            <!-- Tüm yanıtlar -->
            <?php foreach ($ticketReplies as $r): ?>
            <div class="msg-bubble <?= $r['is_admin']?'admin-msg':'user-msg' ?>" data-rid="<?= (int)$r['id'] ?>">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;<?= $r['is_admin']?'justify-content:flex-end':'' ?>">
                    <?php if (!$r['is_admin']): ?>
                    <img src="<?= e($r['avatar'] ?? 'https://minotar.net/avatar/user.png') ?>"
                         style="width:22px;height:22px;border-radius:50%;image-rendering:pixelated;border:1.5px solid var(--border);">
                    <?php endif; ?>
                    <span style="font-size:12px;font-weight:700;color:<?= $r['is_admin']?'#a5b4fc':'var(--text)' ?>;">
                        <?= e($r['username'] ?? '?') ?>
                        <?php if ($r['is_admin']): ?>
                        <span style="background:rgba(var(--accent-rgb),.15);padding:1px 7px;border-radius:5px;font-size:10px;letter-spacing:.05em;margin-left:4px;"><?= __('support.admin_badge') ?></span>
                        <?php endif; ?>
                    </span>
                    <?php if ($r['is_admin']): ?>
                    <img src="<?= e($r['avatar'] ?? 'https://minotar.net/avatar/user.png') ?>"
                         style="width:22px;height:22px;border-radius:50%;image-rendering:pixelated;border:1.5px solid rgba(var(--accent-rgb),.4);">
                    <?php endif; ?>
                </div>
                <div class="msg-text"><?= e($r['message']) ?></div>
                <?php if (!empty($r['image_url'])): ?>
                <a href="<?= htmlspecialchars(nx_safe_href($r['image_url'], '#')) ?>" target="_blank" rel="noopener"><img src="<?= e($r['image_url']) ?>" class="nx-chat-img" alt="" loading="lazy"></a>
                <?php endif; ?>
                <div class="msg-meta" style="<?= $r['is_admin']?'text-align:right':'' ?>"><?= date('d.m.Y H:i', strtotime($r['created_at'])) ?></div>
                <?php if ($r['is_admin']): ?>
                <?php $seen = (int)($r['is_seen'] ?? 0) === 1; ?>
                <div class="msg-ticks<?= $seen ? ' tick-seen' : '' ?>" data-tick="<?= (int)$r['id'] ?>" style="<?= $r['is_admin']?'text-align:right':'' ?>"><?= $seen ? __('support.seen') : '✓' ?></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>

        </div>

        <!-- Admin Yanıt Formu -->
        <div class="ta-reply-area">
            <div class="nx-attach-preview hidden" id="nxPreview">
                <img id="nxPreviewImg" alt="">
                <button type="button" class="nx-attach-x" id="nxPreviewX" title="<?= __('support.remove_attach') ?>"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <form style="margin:0;" id="adminReplyForm" data-tid="<?= (int)$activeTicket['id'] ?>">
                <?= csrf_field() ?>
                <div class="nx-composer">
                    <button type="button" class="nx-attach-btn" id="nxAttachBtn" title="<?= __('support.attach_title') ?>"><i class="fa-solid fa-paperclip"></i></button>
                    <input type="file" id="nxAttachFile" accept=".png,.jpg,.jpeg,.webp" hidden>
                    <input type="text" class="nx-chat-input" id="nxChatInput" maxlength="500" placeholder="<?= __('asupp.reply_ph') ?>" autocomplete="off">
                    <span class="nx-count" id="nxCount">0/500</span>
                    <button type="submit" class="nx-send-btn is-idle" id="nxSendBtn" title="<?= __('support.send') ?>"><i class="fa-solid fa-paper-plane"></i></button>
                </div>
            </form>
            <p style="font-size:11px;color:var(--dim);margin-top:5px;"><?= __('asupp.auto_note') ?></p>
        </div>

        <?php endif; ?>
    </div>

</div>

<script>
const ab = document.getElementById('adminMsgBox');
if (ab) ab.scrollTop = ab.scrollHeight;

function adminEsc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function adminMaxRid(){
    var m = 0;
    if (!ab) return m;
    ab.querySelectorAll('[data-rid]').forEach(function(el){
        var v = parseInt(el.getAttribute('data-rid'), 10);
        if (v > m) m = v;
    });
    return m;
}
function adminMarkSeen(ids, pop){
    if (!ab || !ids || !ids.length) return;
    ids.forEach(function(id){
        var t = ab.querySelector('[data-tick="' + id + '"]');
        if (t && !t.classList.contains('tick-seen')) {
            t.textContent = <?= json_encode(__('support.seen')) ?>;
            t.classList.add('tick-seen');
            if (pop) { t.classList.remove('tick-pop'); void t.offsetWidth; t.classList.add('tick-pop'); }
        }
    });
}

(function(){
    var form = document.getElementById('adminReplyForm');
    if (!ab || !form) return;
    var tid = form.getAttribute('data-tid');
    var csrf = form.querySelector('input[name="_csrf_token"]');
    var input = document.getElementById('nxChatInput');
    var sendBtn = document.getElementById('nxSendBtn');
    var count = document.getElementById('nxCount');
    var fileBtn = document.getElementById('nxAttachBtn');
    var fileInput = document.getElementById('nxAttachFile');
    var preview = document.getElementById('nxPreview');
    var previewImg = document.getElementById('nxPreviewImg');
    function refreshCount(){
        var n = input.value.length;
        count.textContent = n + '/500';
        sendBtn.classList.toggle('is-idle', n === 0 && !fileInput.files.length);
    }
    input.addEventListener('input', refreshCount);
    fileBtn.addEventListener('click', function(){ fileInput.click(); });
    fileInput.addEventListener('change', function(){
        var f = fileInput.files[0];
        if (!f) return;
        if (!/^(image\/png|image\/jpeg|image\/webp)$/.test(f.type) || f.size > 5242880) { fileInput.value = ''; return; }
        previewImg.src = URL.createObjectURL(f);
        preview.classList.remove('hidden');
        refreshCount();
    });
    document.getElementById('nxPreviewX').addEventListener('click', function(){ fileInput.value = ''; preview.classList.add('hidden'); refreshCount(); });
    function imgHtml(src){
        if (!src) return '';
        return '<a href="' + adminEsc(src) + '" target="_blank" rel="noopener"><img src="' + adminEsc(src) + '" class="nx-chat-img" alt="" loading="lazy"></a>';
    }
    form.addEventListener('submit', function(e){
        e.preventDefault();
        var txt = input.value.trim().slice(0, 500);
        var hasFile = fileInput.files.length > 0;
        if (txt === '' && !hasFile) return;
        sendBtn.classList.add('nx-send-fly');
        setTimeout(function(){ sendBtn.classList.remove('nx-send-fly'); }, 400);
        var div = document.createElement('div');
        div.className = 'msg-bubble admin-msg msg-in';
        var html = imgHtml(hasFile ? URL.createObjectURL(fileInput.files[0]) : '');
        if (txt !== '') html += '<div class="msg-text">' + adminEsc(txt) + '</div>';
        html += '<div class="msg-meta" style="text-align:right">' + <?= json_encode(__('support.now')) ?> + '</div>';
        div.innerHTML = html;
        ab.appendChild(div);
        ab.scrollTop = ab.scrollHeight;
        var fd = new FormData();
        fd.append('action', 'ticket_admin_reply');
        fd.append('ticket_id', tid);
        fd.append('reply_message', txt);
        if (hasFile) fd.append('image', fileInput.files[0]);
        fd.append('is_fetch', '1');
        if (csrf) fd.append('_csrf_token', csrf.value);
        input.value = '';
        fileInput.value = '';
        preview.classList.add('hidden');
        refreshCount();
        fetch('/action.php', {method: 'POST', body: fd, headers: {'Accept': 'application/json'}}).then(function(r){ return r.json(); }).then(function(d){
            if (!d || !d.ok) { div.style.opacity = '.55'; return; }
            if (d.id) div.setAttribute('data-rid', d.id);
            if (d.id) ab.querySelectorAll('[data-rid="' + d.id + '"]').forEach(function(o){ if (o !== div) o.remove(); });
            var ticks = document.createElement('div');
            ticks.className = 'msg-ticks';
            if (d.id) ticks.setAttribute('data-tick', d.id);
            ticks.style.textAlign = 'right';
            ticks.textContent = '✓';
            div.appendChild(ticks);
            if (d.image) {
                var a = div.querySelector('a');
                if (a) a.href = d.image;
                var im = div.querySelector('img.nx-chat-img');
                if (im) im.src = d.image;
            }
            var meta = div.querySelector('.msg-meta');
            if (meta && d.created) meta.textContent = d.created;
        }).catch(function(){ div.style.opacity = '.55'; });
    });
    function poll(){
        if (document.hidden) { schedule(4000); return; }
        var fd = new FormData();
        fd.append('action', 'ticket_poll');
        fd.append('ticket_id', tid);
        fd.append('after_id', adminMaxRid());
        fd.append('viewing', '1');
        if (csrf) fd.append('_csrf_token', csrf.value);
        fetch('/action.php', {method: 'POST', body: fd, headers: {'Accept': 'application/json'}}).then(function(r){ return r.json(); }).then(function(d){
            if (!d || !d.ok) { schedule(4000); return; }
            adminMarkSeen(d.seen_ids, true);
            if (!d.closed) {
                (d.replies || []).forEach(function(m){
                    if (ab.querySelector('[data-rid="' + m.id + '"]')) return;
                    var div = document.createElement('div');
                    div.className = 'msg-bubble msg-in ' + (m.admin ? 'admin-msg' : 'user-msg');
                    div.setAttribute('data-rid', m.id);
                    var html = imgHtml(m.image);
                    if (!m.admin) {
                        var av = m.avatar || 'https://minotar.net/avatar/user.png';
                        html += '<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">'
                            + '<img src="' + adminEsc(av) + '" style="width:22px;height:22px;border-radius:50%;image-rendering:pixelated;border:1.5px solid var(--border);">'
                            + '<span style="font-size:12px;font-weight:700;">' + adminEsc(m.username || '?') + '</span></div>';
                    }
                    if (m.message !== '') html += '<div class="msg-text">' + adminEsc(m.message) + '</div>';
                    html += '<div class="msg-meta"' + (m.admin ? ' style="text-align:right"' : '') + '>' + adminEsc(m.created || '') + '</div>';
                    if (m.admin) html += '<div class="msg-ticks" data-tick="' + m.id + '" style="text-align:right">✓</div>';
                    div.innerHTML = html;
                    var nearBottom = (ab.scrollHeight - ab.scrollTop - ab.clientHeight) < 120;
                    ab.appendChild(div);
                    if (nearBottom) ab.scrollTop = ab.scrollHeight;
                });
            }
            if ((d.replies || []).length >= 50) { schedule(300); return; }
            schedule(2000);
        }).catch(function(){ schedule(5000); });
    }
    function schedule(ms){ setTimeout(poll, ms); }
    document.addEventListener('visibilitychange', function(){ if (!document.hidden) poll(); });
    schedule(2000);
    refreshCount();
})();
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
