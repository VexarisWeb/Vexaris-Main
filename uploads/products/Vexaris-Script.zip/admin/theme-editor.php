<?php declare(strict_types=1);
require_once __DIR__ . '/includes/guard.php';
if (!function_exists('has_permission') || !has_permission('themes')) {
    header('Location: /admin', true, 302);
    exit;
}
$editTheme = preg_replace('/[^a-z0-9_\-]/', '', strtolower((string)($_GET['theme'] ?? '')));
if ($editTheme === '' || !is_dir(ROOT_PATH . '/themes/' . $editTheme)) {
    header('Location: /admin/themes.php', true, 302);
    exit;
}
$schema = theme_editor_schema($editTheme);
if (empty($schema)) {
    header('Location: /admin/themes.php', true, 302);
    exit;
}
$saved = theme_settings_map($editTheme);
$fieldVal = function (array $f) use ($saved) {
    return array_key_exists($f['key'], $saved) ? $saved[$f['key']] : '';
};
$fieldPh = function (array $f) {
    $d = (string)($f['default'] ?? ($f['placeholder'] ?? ''));
    return $d !== '' ? $d : __('atedit.empty_hint');
};
$flash = $_GET['flash'] ?? '';
[$flashType, $flashText] = $flash ? explode(':', urldecode($flash), 2) + ['',''] : ['', ''];
$activeTheme = 'default';
try {
    $ar = $adminDb->query("SELECT `value` FROM settings WHERE `key`='active_theme' LIMIT 1")->fetch();
    if ($ar && !empty($ar['value'])) $activeTheme = preg_replace('/[^a-z0-9_\-]/', '', (string)$ar['value']);
} catch (Exception $e) {}
$teMode = 'dark';
try {
    $tmV = $adminDb->query("SELECT `value` FROM settings WHERE `key`='admin_theme' LIMIT 1")->fetchColumn();
    if ($tmV) { $tmJ = json_decode((string)$tmV, true); if (is_array($tmJ) && ($tmJ['mode'] ?? '') === 'light') $teMode = 'light'; }
} catch (Exception $e) {}
?>
<!DOCTYPE html>
<html lang="<?= function_exists('lang_active') ? lang_active() : 'tr' ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title><?= __('atheme.editor_title') ?> — <?= e(ucfirst($editTheme)) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Plus Jakarta Sans',sans-serif;background:#0b0f17;color:#e8eaf6;min-height:100vh;}
.te-top{position:sticky;top:0;z-index:50;display:flex;align-items:center;gap:12px;padding:14px 22px;background:rgba(11,15,23,.92);backdrop-filter:blur(12px);border-bottom:1px solid rgba(255,255,255,.08);flex-wrap:wrap;}
.te-back{display:flex;align-items:center;gap:8px;color:#9ca3af;text-decoration:none;font-size:13px;font-weight:700;padding:9px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);}
.te-back:hover{color:#fff;border-color:rgba(var(--accent-rgb),.5);}
.te-title{display:flex;align-items:center;gap:10px;font-size:16px;font-weight:800;}
.te-title .ic{width:36px;height:36px;border-radius:10px;background:rgba(var(--accent-rgb),.15);color:#a5b4fc;display:flex;align-items:center;justify-content:center;font-size:16px;}
.te-live{font-size:10px;font-weight:800;background:rgba(34,197,94,.15);color:#4ade80;padding:3px 10px;border-radius:20px;}
.te-top .sp{flex:1;}
.te-btn{display:inline-flex;align-items:center;gap:8px;border:none;border-radius:10px;padding:11px 22px;font-size:13px;font-weight:800;cursor:pointer;text-decoration:none;}
.te-save{background:linear-gradient(135deg,var(--accent),#4f46e5);color:#fff;}
.te-save:hover{filter:brightness(1.12);}
.te-ghost{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12);color:#cbd5e1;}
.te-ghost:hover{border-color:#f87171;color:#f87171;}
.te-view{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12);color:#cbd5e1;}
.te-view:hover{color:#fff;border-color:rgba(var(--accent-rgb),.5);}
.te-wrap{max-width:1180px;margin:0 auto;padding:26px 22px 120px;}
.te-flash{padding:13px 18px;border-radius:12px;font-size:14px;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:8px;}
.te-flash.ok{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#4ade80;}
.te-flash.err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#f87171;}
.te-sec{background:#0f1422;border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:22px;margin-bottom:20px;}
.te-sec-h{display:flex;align-items:center;gap:10px;font-size:14px;font-weight:800;margin-bottom:18px;padding-bottom:14px;border-bottom:1px solid rgba(255,255,255,.07);}
.te-sec-h i{color:#818cf8;}
.te-fields{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.te-full{grid-column:1/-1;}
.te-label{display:block;font-size:12px;font-weight:700;color:#9ca3af;margin-bottom:6px;}
.te-input{width:100%;background:#0b0f17;border:1px solid rgba(255,255,255,.1);border-radius:9px;padding:11px 14px;color:#e8eaf6;font-size:13px;outline:none;font-family:inherit;}
.te-input:focus{border-color:var(--accent);}
textarea.te-input{resize:vertical;min-height:76px;}
.te-color-row{display:flex;gap:10px;align-items:center;}
.te-color{width:52px;height:42px;border:1px solid rgba(255,255,255,.12);border-radius:9px;background:#0b0f17;cursor:pointer;padding:2px;flex-shrink:0;}
.te-img-prev{max-width:100%;max-height:150px;border-radius:10px;border:1px solid rgba(255,255,255,.1);margin-bottom:8px;display:block;}
.te-drop{position:relative;border:2px dashed rgba(255,255,255,.15);border-radius:12px;padding:22px 14px;text-align:center;color:#9ca3af;transition:border-color .2s,background .2s;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer;}
.te-drop.over{border-color:var(--accent);background:rgba(var(--accent-rgb),.08);}
.te-drop input{position:absolute;inset:0;opacity:0;cursor:pointer;}
.te-hint{font-size:11px;color:#64748b;margin-top:6px;}
.te-savebar{position:fixed;bottom:0;left:0;right:0;z-index:50;display:flex;gap:10px;align-items:center;flex-wrap:wrap;background:rgba(11,15,23,.94);backdrop-filter:blur(12px);border-top:1px solid rgba(255,255,255,.08);padding:14px 22px;}
body.te-light{background:#eef2f7;color:#0f172a;}
body.te-light .te-top{background:rgba(255,255,255,.94);border-color:rgba(15,23,42,.1);}
body.te-light .te-back{background:rgba(15,23,42,.04);border-color:rgba(15,23,42,.12);color:#475569;}
body.te-light .te-back:hover{color:#0f172a;}
body.te-light .te-view{background:rgba(15,23,42,.04);border-color:rgba(15,23,42,.12);color:#475569;}
body.te-light .te-view:hover{color:#0f172a;}
body.te-light .te-sec{background:#ffffff;border-color:rgba(15,23,42,.1);}
body.te-light .te-sec-h{border-color:rgba(15,23,42,.08);}
body.te-light .te-label{color:#475569;}
body.te-light .te-input{background:#ffffff;border-color:rgba(15,23,42,.14);color:#0f172a;}
body.te-light select.te-input option{background:#ffffff;color:#0f172a;}
body.te-light .te-color{background:#ffffff;border-color:rgba(15,23,42,.14);}
body.te-light .te-img-prev{border-color:rgba(15,23,42,.12);}
body.te-light .te-drop{border-color:rgba(15,23,42,.2);color:#64748b;}
body.te-light .te-savebar{background:rgba(255,255,255,.94);border-color:rgba(15,23,42,.1);}
body.te-light .te-ghost{background:rgba(15,23,42,.04);border-color:rgba(15,23,42,.12);color:#475569;}
select.te-input option{background:#0b0f17;color:#e8eaf6;}
@media(max-width:640px){.te-fields{grid-template-columns:1fr;}.te-savebar .te-btn{flex:1;justify-content:center;}.te-wrap{padding:18px 14px 140px;}}
</style>
</head>
<body class="<?= $teMode === 'light' ? 'te-light' : '' ?>">
<div class="te-top">
    <a href="/admin/themes.php" class="te-back"><i class="fa-solid fa-arrow-left"></i> Temalar</a>
    <div class="te-title"><span class="ic"><i class="fa-solid fa-pen-ruler"></i></span> <?= e(ucfirst($editTheme)) ?> <?php if ($editTheme === $activeTheme): ?><span class="te-live">Aktif</span><?php endif; ?></div>
    <span class="sp"></span>
    <a href="/" target="_blank" rel="noopener" class="te-btn te-view"><i class="fa-solid fa-eye"></i> <?= __('apage.preview') ?></a>
    <button type="submit" form="teForm" class="te-btn te-save"><i class="fa-solid fa-floppy-disk"></i> <?= __('msg.save') ?></button>
</div>
<div class="te-wrap">
<?php if ($flashText): ?>
<div class="te-flash <?= $flashType === 'success' ? 'ok' : 'err' ?>">
    <i class="fa-solid fa-<?= $flashType === 'success' ? 'circle-check' : 'circle-xmark' ?>"></i>
    <?= e($flashText) ?>
</div>
<?php endif; ?>
<form method="POST" action="/action.php" enctype="multipart/form-data" id="teForm">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="theme_editor_save">
    <input type="hidden" name="theme" value="<?= e($editTheme) ?>">
    <?php foreach ($schema as $sec): ?>
    <div class="te-sec">
        <div class="te-sec-h"><i class="fa-solid <?= e($sec['icon']) ?>"></i> <?= e($sec['label']) ?></div>
        <div class="te-fields">
        <?php foreach ($sec['fields'] as $f): ?>
            <?php $fv = (string)$fieldVal($f); $fname = 't_' . $f['key']; $fph = (string)$fieldPh($f); ?>
            <?php if (($f['type'] ?? '') === 'color'): ?>
            <div>
                <label class="te-label"><?= e($f['label']) ?></label>
                <div class="te-color-row">
                    <input type="color" class="te-color" value="<?= e(preg_match('/^#[0-9a-fA-F]{6}$/', $fv) ? $fv : '#6366f1') ?>" oninput="this.nextElementSibling.value=this.value">
                    <input type="text" class="te-input" name="<?= e($fname) ?>" value="<?= e($fv) ?>" maxlength="7" oninput="if(/^#[0-9a-fA-F]{6}$/.test(this.value))this.previousElementSibling.value=this.value">
                </div>
            </div>
            <?php elseif (($f['type'] ?? '') === 'image'): ?>
            <div class="te-full">
                <label class="te-label"><?= e($f['label']) ?></label>
                <?php if ($fv !== ''): ?><img src="<?= e($fv) ?>" class="te-img-prev" alt=""><?php endif; ?>
                <div class="te-drop" data-drop>
                    <i class="fa-solid fa-cloud-arrow-up" style="font-size:22px;color:#818cf8;"></i>
                    <div style="font-size:13px;font-weight:700;"><?= __('atedit.drop') ?></div>
                    <div style="font-size:11px;"><?= __('atedit.drop_or') ?></div>
                    <input type="file" name="timg_<?= e($f['key']) ?>" accept=".jpg,.jpeg,.png,.webp,.gif,.ico">
                </div>
                <div class="te-hint" data-filename style="display:none;"></div>
                <input type="text" class="te-input" name="<?= e($fname) ?>" value="<?= e($fv) ?>" placeholder="<?= __('atedit.img_ph') ?>" style="margin-top:8px;">
                <div class="te-hint"><?= __('atedit.img_hint') ?></div>
            </div>
            <?php elseif (($f['type'] ?? '') === 'select'): ?>
            <div>
                <label class="te-label"><?= e($f['label']) ?></label>
                <select class="te-input" name="<?= e($fname) ?>">
                    <?php foreach (($f['options'] ?? []) as $o): ?>
                    <option value="<?= e($o['value']) ?>" <?= $fv === $o['value'] ? 'selected' : '' ?>><?= e($o['label']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php elseif (($f['type'] ?? '') === 'number'): ?>
            <div>
                <label class="te-label"><?= e($f['label']) ?></label>
                <input type="number" class="te-input" name="<?= e($fname) ?>" value="<?= e($fv) ?>">
            </div>
            <?php elseif (($f['type'] ?? '') === 'textarea' || ($f['type'] ?? '') === 'html'): ?>
            <div class="te-full">
                <label class="te-label"><?= e($f['label']) ?><?= ($f['type'] ?? '') === 'html' ? ' <span style="font-weight:500;">(span, em, strong, br)</span>' : '' ?></label>
                <textarea class="te-input" name="<?= e($fname) ?>" placeholder="<?= e($fph) ?>"><?= e($fv) ?></textarea>
            </div>
            <?php else: ?>
            <div class="te-full">
                <label class="te-label"><?= e($f['label']) ?></label>
                <input type="text" class="te-input" name="<?= e($fname) ?>" value="<?= e($fv) ?>" placeholder="<?= e($fph) ?>">
            </div>
            <?php endif; ?>
        <?php endforeach; ?>
        </div>
    </div>
    <?php endforeach; ?>
</form>
</div>
<div class="te-savebar">
    <button type="submit" form="teForm" class="te-btn te-save"><i class="fa-solid fa-floppy-disk"></i> <?= __('msg.save') ?></button>
    <button type="submit" form="teForm" name="reset_theme" value="1" class="te-btn te-ghost" onclick="return confirm(<?= json_encode(__('atedit.reset_confirm')) ?>)"><i class="fa-solid fa-rotate-left"></i> <?= __('aseo.reset_btn') ?></button>
    <span style="font-size:11px;color:#64748b;margin-left:auto;"><?= e(ucfirst($editTheme)) ?> <?= __('atedit.editing') ?></span>
</div>
<script>
(function(){
  document.querySelectorAll('[data-drop]').forEach(function(zone){
    var input = zone.querySelector('input[type="file"]');
    if (!input) return;
    var nameBox = zone.parentElement.querySelector('[data-filename]');
    function showName(){
      if (input.files && input.files.length) {
        if (nameBox) { nameBox.style.display = 'block'; nameBox.textContent = <?= json_encode(__('atedit.selected')) ?> + input.files[0].name; }
        var rd = new FileReader();
        rd.onload = function(){
          var img = zone.parentElement.querySelector('.te-img-prev');
          if (!img) { img = document.createElement('img'); img.className = 'te-img-prev'; img.alt = ''; zone.parentElement.insertBefore(img, zone); }
          img.src = rd.result;
        };
        rd.readAsDataURL(input.files[0]);
      }
    }
    input.addEventListener('change', showName);
    ['dragenter','dragover'].forEach(function(ev){ zone.addEventListener(ev, function(e){ e.preventDefault(); zone.classList.add('over'); }); });
    ['dragleave','drop'].forEach(function(ev){ zone.addEventListener(ev, function(e){ e.preventDefault(); zone.classList.remove('over'); }); });
    zone.addEventListener('drop', function(e){
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) { input.files = e.dataTransfer.files; showName(); }
    });
  });
})();
</script>
</body>
</html>
