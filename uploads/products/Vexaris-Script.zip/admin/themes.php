<?php
require_once __DIR__ . '/includes/guard.php';

$pageTitle  = __('atheme.title');
$activePage = 'themes';

$activeTheme = 'default';
if ($adminDb) {
    try {
        $row = $adminDb->query("SELECT `value` FROM settings WHERE `key` = 'active_theme' LIMIT 1")->fetch();
        if ($row && !empty($row['value'])) $activeTheme = $row['value'];
    } catch (Exception $e) {}
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['activate_theme'])) {
    $slug = preg_replace('/[^a-z0-9_\-]/', '', strtolower($_POST['activate_theme']));
    $themePath = ROOT_PATH . '/themes/' . $slug;

    if ($slug && is_dir($themePath)) {
        if ($adminDb) {
            $exists = $adminDb->query("SELECT `key` FROM settings WHERE `key`='active_theme' LIMIT 1")->fetch();
            if ($exists) {
                $adminDb->prepare("UPDATE settings SET `value`=?, updated_at=NOW() WHERE `key`='active_theme'")
                        ->execute([$slug]);
            } else {
                $adminDb->prepare("INSERT INTO settings (`key`,`value`) VALUES ('active_theme',?)")
                        ->execute([$slug]);
            }
            $activeTheme = $slug;
            audit_log($adminDb, 'update', 'themes', 0, $slug, '/admin/themes.php');
            $msg = __('atheme.activated', ['slug' => $slug]);
        }
    } else {
        $msg = __('atheme.invalid');
    }
}

$themesDir   = ROOT_PATH . '/themes/';
$themeFolders = [];
if (is_dir($themesDir)) {
    foreach (glob($themesDir . '*', GLOB_ONLYDIR) as $dir) {
        $themeFolders[] = basename($dir);
    }
}

include __DIR__ . '/includes/layout.php';
?>

<?php if ($msg): ?>
<div style="background:<?= str_starts_with($msg,'✓') ? 'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;
     border:1px solid <?= str_starts_with($msg,'✓') ? 'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;
     color:<?= str_starts_with($msg,'✓') ? '#4ade80':'#f87171' ?>;
     padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;margin-bottom:24px;
     display:flex;align-items:center;gap:8px;">
    <?= e($msg) ?>
</div>
<?php endif; ?>

<div style="margin-bottom:20px;">
    <p style="font-size:14px;color:var(--muted);">
        <i class="fa-solid fa-folder-open" style="margin-right:6px;color:var(--accent);"></i>
        <strong><?= count($themeFolders) ?></strong> <?= __('atheme.found') ?>
        <?= __('atheme.active_label') ?> <strong style="color:#a5b4fc;"><?= e($activeTheme) ?></strong>
    </p>
</div>

<?php if (empty($themeFolders)): ?>
<div style="text-align:center;padding:60px 20px;color:var(--muted);">
    <i class="fa-solid fa-palette" style="font-size:48px;margin-bottom:16px;display:block;color:var(--dim);"></i>
    <p style="font-size:15px;font-weight:600;"><?= __('atheme.empty') ?></p>
</div>
<?php else: ?>
<div class="themes-grid">
    <?php foreach ($themeFolders as $slug):
        $isActive  = ($slug === $activeTheme);
        $themeFile = $themesDir . $slug . '/index.php';
        $hasIndex  = file_exists($themeFile);
    ?>
    <div class="theme-card <?= $isActive ? 'active-theme' : '' ?>">

        <div class="theme-card-preview">
            <i class="fa-solid fa-desktop"></i>
            <?php if ($isActive): ?>
            <span class="theme-card-active-badge"><i class="fa-solid fa-check"></i> <?= __('adash.status_active') ?></span>
            <?php endif; ?>
        </div>

        <div class="theme-card-body">
            <div class="theme-card-name"><?= e(ucfirst($slug)) ?></div>
            <div class="theme-card-slug">
                <i class="fa-solid fa-folder" style="margin-right:4px;"></i>
                themes/<?= e($slug) ?>/
            </div>

            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                <?php if (!$isActive): ?>
                <form method="POST" action="/admin/themes.php" style="margin:0;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="activate_theme" value="<?= e($slug) ?>">
                    <button type="submit" class="btn-admin btn-primary-admin">
                        <i class="fa-solid fa-bolt"></i> <?= __('atheme.activate') ?>
                    </button>
                </form>
                <?php else: ?>
                <span class="badge badge-indigo" style="font-size:12px;padding:6px 14px;">
                    <i class="fa-solid fa-check"></i> <?= __('atheme.active_badge') ?>
                </span>
                <?php endif; ?>

                <?php if ($hasIndex): ?>
                <a href="/" class="btn-admin btn-ghost-admin">
                    <i class="fa-solid fa-eye"></i> <?= __('apage.preview') ?>
                </a>
                <?php endif; ?>
                <a href="/admin/theme-editor.php?theme=<?= e($slug) ?>" class="btn-admin btn-ghost-admin" title="<?= __('atheme.editor_title') ?>">
                    <i class="fa-solid fa-gear"></i>
                </a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
