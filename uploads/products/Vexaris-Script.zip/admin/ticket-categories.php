<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.ticket_categories');
$activePage = 'ticket_categories';

$flash = $_GET['flash'] ?? '';
[$flashType, $flashText] = $flash ? explode(':', urldecode($flash), 2) + ['',''] : ['', ''];

$editCat = null;
if (isset($_GET['edit'])) {
    $ec = $adminDb->prepare('SELECT * FROM ticket_categories WHERE id=?');
    $ec->execute([(int)$_GET['edit']]);
    $editCat = $ec->fetch() ?: null;
}

$categories = $adminDb->query('SELECT tc.*, (SELECT COUNT(*) FROM tickets t WHERE t.category=tc.name) AS ticket_count FROM ticket_categories tc ORDER BY tc.sort_order ASC, tc.name ASC')->fetchAll();

include __DIR__ . '/includes/layout.php';
?>
<style>
.hidden { display: none !important; }
.icn-sel{background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:8px;aspect-ratio:1;display:flex;align-items:center;justify-content:center;font-size:16px;color:var(--text);cursor:pointer;transition:all .15s;}
.icn-sel:hover{border-color:var(--accent);background:rgba(var(--accent-rgb,99,102,241),.1);transform:scale(1.08);}
.icn-sel.active{border-color:var(--accent);background:var(--accent);color:#fff;transform:scale(1.05);}
</style>

<?php if ($flashText): ?>
<div style="background:<?= $flashType==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;border:1px solid <?= $flashType==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;color:<?= $flashType==='success'?'#4ade80':'#f87171' ?>;padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid fa-<?= $flashType==='success'?'circle-check':'circle-xmark' ?>"></i> <?= e($flashText) ?>
</div>
<?php endif; ?>

<div class="admin-card" style="margin-bottom:24px;">
    <div class="admin-card-header">
        <span class="admin-card-title">
            <i class="fa-solid fa-headset" style="color:#22d3ee;margin-right:8px;"></i>
            <?= e(__('amenu.ticket_categories')) ?> <span style="color:var(--muted);font-weight:500;">(<?= count($categories) ?>)</span>
        </span>
        <button onclick="document.getElementById('addCatModal').classList.remove('hidden')"
                class="btn-admin btn-primary-admin" style="font-size:13px;padding:9px 18px;">
            <i class="fa-solid fa-plus"></i> <?= e(__('acat.add')) ?>
        </button>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th style="width:40px;"></th>
                <th><?= e(__('atcat.th_category')) ?></th>
                <th><?= e(__('atcat.th_tickets')) ?></th>
                <th><?= e(__('aref.order')) ?></th>
                <th style="text-align:right;"><?= e(__('adash.th_action')) ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($categories as $c): ?>
        <tr>
            <td>
                <?php if (!empty($c['icon'])): ?>
                <?= cat_icon_html($c['icon'], 'font-size:18px;color:var(--accent);width:24px;height:24px;object-fit:cover;border-radius:6px;') ?>
                <?php else: ?>
                <i class="fa-solid fa-tag" style="font-size:18px;color:var(--dim);"></i>
                <?php endif; ?>
            </td>
            <td>
                <div style="font-weight:700;font-size:13px;"><?= e($c['name']) ?></div>
            </td>
            <td><span class="badge badge-indigo"><?= (int)$c['ticket_count'] ?></span></td>
            <td style="font-size:13px;"><?= (int)$c['sort_order'] ?></td>
            <td style="text-align:right;">
                <div style="display:flex;gap:6px;justify-content:flex-end;">
                    <button onclick="openEditCat(<?= htmlspecialchars(json_encode($c), ENT_QUOTES) ?>)" class="btn-admin btn-ghost-admin" style="padding:6px 12px;font-size:12px;">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                    <form method="POST" action="/action.php" onsubmit="return confirm(<?= json_encode(__('acat.delete_confirm')) ?>);" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="ticket_category_delete">
                        <input type="hidden" name="id" value="<?= $c['id'] ?>">
                        <button type="submit" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;padding:6px 12px;font-size:12px;border:1px solid rgba(239,68,68,.2);">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($categories)): ?>
        <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:32px;"><?= e(__('acat.empty')) ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<div id="addCatModal" class="hidden" style="position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;padding:16px;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;max-width:480px;">
        <div style="padding:18px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;">
            <span style="font-size:15px;font-weight:800;"><i class="fa-solid fa-plus" style="color:var(--accent);margin-right:8px;"></i><?= e(__('acat.add')) ?></span>
            <button onclick="document.getElementById('addCatModal').classList.add('hidden')" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:18px;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <form method="POST" action="/action.php" style="padding:22px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="ticket_category_save">
            <div style="margin-bottom:14px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= e(__('acat.name_label')) ?></label>
                <input type="text" name="name" required maxlength="60"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= e(__('acat.icon_label')) ?></label>
                <div style="display:flex;gap:8px;align-items:center;margin-bottom:6px;">
                    <input type="text" name="icon" id="addCatIcon" maxlength="512" placeholder="fa-solid fa-tag"
                           style="flex:1;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <span id="addCatIconPreview" style="font-size:20px;width:36px;text-align:center;color:var(--accent);"></span>
                </div>
                <button type="button" onclick="toggleIconPicker('addCatIcon','addCatIconPreview')" class="btn-admin btn-ghost-admin" style="font-size:12px;">
                    <i class="fa-solid fa-icons"></i> <?= e(__('acat.icon_pick')) ?>
                </button>
                <button type="button" onclick="document.getElementById('addCatUpload').click()" class="btn-admin btn-ghost-admin" style="font-size:12px;margin-left:6px;">
                    <i class="fa-solid fa-cloud-arrow-up"></i> <?= e(__('panel.upload')) ?> <span style="opacity:.55;font-weight:400;">64x64</span>
                </button>
                <input type="file" id="addCatUpload" accept="image/png,image/jpeg,image/webp,image/gif" style="display:none;" onchange="uploadCatIcon(this,'addCatIcon','addCatIconPreview','addCatUploadStatus')">
                <span id="addCatUploadStatus" style="font-size:11px;font-weight:700;margin-left:8px;"></span>
            </div>
            <div style="margin-bottom:20px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= e(__('acat.sort_label')) ?></label>
                <input type="number" name="sort_order" min="0" value="0"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
            </div>
            <button type="submit" class="btn-admin btn-primary-admin" style="width:100%;justify-content:center;">
                <i class="fa-solid fa-floppy-disk"></i> <?= e(__('msg.save')) ?>
            </button>
        </form>
    </div>
</div>

<div id="editCatModal" class="hidden" style="position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;padding:16px;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;max-width:480px;">
        <div style="padding:18px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;">
            <span style="font-size:15px;font-weight:800;"><i class="fa-solid fa-pen-to-square" style="color:var(--accent);margin-right:8px;"></i><?= e(__('acat.edit_title')) ?></span>
            <button onclick="document.getElementById('editCatModal').classList.add('hidden')" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:18px;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <form method="POST" action="/action.php" style="padding:22px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="ticket_category_save">
            <input type="hidden" name="id" id="editCatId">
            <div style="margin-bottom:14px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= e(__('acat.name_label')) ?></label>
                <input type="text" name="name" id="editCatName" required maxlength="60"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= e(__('acat.icon_label')) ?></label>
                <div style="display:flex;gap:8px;align-items:center;margin-bottom:6px;">
                    <input type="text" name="icon" id="editCatIcon" maxlength="512" placeholder="fa-solid fa-tag"
                           style="flex:1;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <span id="editCatIconPreview" style="font-size:20px;width:36px;text-align:center;color:var(--accent);"></span>
                </div>
                <button type="button" onclick="toggleIconPicker('editCatIcon','editCatIconPreview')" class="btn-admin btn-ghost-admin" style="font-size:12px;">
                    <i class="fa-solid fa-icons"></i> <?= e(__('acat.icon_pick')) ?>
                </button>
                <button type="button" onclick="document.getElementById('editCatUpload').click()" class="btn-admin btn-ghost-admin" style="font-size:12px;margin-left:6px;">
                    <i class="fa-solid fa-cloud-arrow-up"></i> <?= e(__('panel.upload')) ?> <span style="opacity:.55;font-weight:400;">64x64</span>
                </button>
                <input type="file" id="editCatUpload" accept="image/png,image/jpeg,image/webp,image/gif" style="display:none;" onchange="uploadCatIcon(this,'editCatIcon','editCatIconPreview','editCatUploadStatus')">
                <span id="editCatUploadStatus" style="font-size:11px;font-weight:700;margin-left:8px;"></span>
            </div>
            <div style="margin-bottom:20px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= e(__('acat.sort_label')) ?></label>
                <input type="number" name="sort_order" id="editCatSort" min="0" value="0"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
            </div>
            <button type="submit" class="btn-admin btn-primary-admin" style="width:100%;justify-content:center;">
                <i class="fa-solid fa-floppy-disk"></i> <?= e(__('aprod.update')) ?>
            </button>
        </form>
    </div>
</div>

<div id="iconPickerModal" class="hidden" style="position:fixed;inset:0;z-index:1001;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;padding:16px;"
     onclick="if(event.target===this)closeIconPicker()">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;max-width:540px;max-height:80vh;display:flex;flex-direction:column;" onclick="event.stopPropagation()">
        <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:12px;flex-shrink:0;">
            <span style="font-size:15px;font-weight:800;"><i class="fa-solid fa-icons" style="color:var(--accent);margin-right:8px;"></i><?= e(__('acat.icon_pick')) ?></span>
            <div style="position:relative;flex:1;max-width:260px;">
                <input type="text" id="iconSearchInput" placeholder="<?= e(__('acat.search_ph')) ?>"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:8px 12px 8px 32px;color:var(--text);font-size:12px;outline:none;">
                <i class="fa-solid fa-magnifying-glass" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);font-size:12px;color:var(--muted);"></i>
            </div>
            <button onclick="closeIconPicker()" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:18px;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <div id="iconGrid" style="padding:14px;overflow-y:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(44px,1fr));gap:6px;flex:1;"></div>
    </div>
</div>

<script>
var _iconTarget = null;
var _iconPreview = null;
var _allIcons = [];

(function(){
    var icons = [
        ['fa-solid fa-puzzle-piece','puzzle piece game plugin extension'],
        ['fa-solid fa-cube','cube 3d block box package plugin'],
        ['fa-solid fa-cubes','cubes multiple 3d blocks stack'],
        ['fa-solid fa-key','key access unlock license security password'],
        ['fa-solid fa-lock','lock secure closed privacy protection'],
        ['fa-solid fa-unlock','unlock open accessible'],
        ['fa-solid fa-shield-halved','shield protect security safe armor'],
        ['fa-solid fa-shield','shield protect security guard'],
        ['fa-solid fa-sword','sword weapon fight combat warrior'],
        ['fa-solid fa-crosshairs','crosshairs aim target scope crosshair'],
        ['fa-solid fa-bullseye','bullseye target aim accuracy dart'],
        ['fa-solid fa-bolt','bolt lightning fast speed thunder zap'],
        ['fa-solid fa-star','star favorite rate review rating'],
        ['fa-solid fa-heart','heart like favorite love'],
        ['fa-solid fa-fire','fire hot popular flame burn'],
        ['fa-solid fa-crown','crown king royal admin leader'],
        ['fa-solid fa-user','user person account profile human'],
        ['fa-solid fa-users','users group team community people'],
        ['fa-solid fa-user-tie','user tie business executive professional'],
        ['fa-solid fa-user-shield','user shield admin protected secure'],
        ['fa-solid fa-user-gear','user gear settings configuration profile'],
        ['fa-solid fa-user-plus','user plus add invite register signup'],
        ['fa-solid fa-user-graduate','graduate student education learning'],
        ['fa-solid fa-robot','robot bot automation ai android'],
        ['fa-solid fa-gamepad','gamepad gaming controller console play'],
        ['fa-solid fa-dice','dice random game gambling board'],
        ['fa-solid fa-chess','chess game strategy board king queen'],
        ['fa-solid fa-gem','gem diamond premium valuable jewel'],
        ['fa-solid fa-sack-dollar','sack dollar money bag cash payment'],
        ['fa-solid fa-coin','coin money currency payment crypto'],
        ['fa-solid fa-wallet','wallet money payment balance purse'],
        ['fa-solid fa-cart-shopping','cart shopping buy purchase checkout cart'],
        ['fa-solid fa-bag-shopping','bag shopping buy purchase'],
        ['fa-solid fa-basket-shopping','basket shopping buy purchase'],
        ['fa-solid fa-credit-card','credit card payment checkout buy purchase'],
        ['fa-solid fa-money-bill','money bill payment currency cash'],
        ['fa-solid fa-percent','percent discount sale coupon promotion'],
        ['fa-solid fa-ticket','ticket coupon voucher support entrance'],
        ['fa-solid fa-tags','tags label category multiple'],
        ['fa-solid fa-tag','tag label category price'],
        ['fa-solid fa-folder','folder directory category organize'],
        ['fa-solid fa-folder-open','folder open directory browse'],
        ['fa-solid fa-layer-group','layers group stack multiple category'],
        ['fa-solid fa-store','store shop market marketplace merchant'],
        ['fa-solid fa-shop','shop market store ecommerce'],
        ['fa-solid fa-gift','gift present reward bonus giveaway'],
        ['fa-solid fa-wand-magic-sparkles','wand magic sparkles effect spell'],
        ['fa-solid fa-hat-wizard','hat wizard magic fantasy mage'],
        ['fa-solid fa-dragon','dragon fantasy mythical creature beast'],
        ['fa-solid fa-ghost','ghost halloween spirit phantom'],
        ['fa-solid fa-skull','skull death danger skeleton'],
        ['fa-solid fa-paw','paw animal pet claw footprint cat'],
        ['fa-solid fa-dog','dog animal pet canine woof'],
        ['fa-solid fa-cat','cat animal pet feline meow'],
        ['fa-solid fa-horse','horse animal riding mount'],
        ['fa-solid fa-fish','fish animal sea ocean aquatic'],
        ['fa-solid fa-feather','feather bird flight wing quill'],
        ['fa-solid fa-tree','tree nature forest plant wood'],
        ['fa-solid fa-leaf','leaf nature plant green eco'],
        ['fa-solid fa-flower','flower blossom nature plant rose'],
        ['fa-solid fa-campground','campground tent camping outdoor'],
        ['fa-solid fa-mountain','mountain nature terrain hill landscape'],
        ['fa-solid fa-sun','sun light day bright weather solar'],
        ['fa-solid fa-moon','moon night dark sleep lunar'],
        ['fa-solid fa-cloud','cloud weather storage server sky'],
        ['fa-solid fa-cloud-arrow-up','cloud upload cloud arrow up upload'],
        ['fa-solid fa-cloud-arrow-down','cloud download cloud arrow down download'],
        ['fa-solid fa-download','download arrow down save get'],
        ['fa-solid fa-upload','upload arrow up send share'],
        ['fa-solid fa-file','file document page text paper'],
        ['fa-solid fa-file-lines','file lines document text content article'],
        ['fa-solid fa-file-code','file code programming script developer'],
        ['fa-solid fa-file-zipper','file archive zip compressed folder'],
        ['fa-solid fa-database','database storage server data backup'],
        ['fa-solid fa-server','server hosting host rack data'],
        ['fa-solid fa-microchip','microchip chip cpu processor hardware tech'],
        ['fa-solid fa-cpu','cpu processor chip computing hardware'],
        ['fa-solid fa-wifi','wifi wireless internet network connection'],
        ['fa-solid fa-network-wired','network wired ethernet lan connection'],
        ['fa-solid fa-laptop-code','laptop code developer programming coding tech'],
        ['fa-solid fa-code','code programming development script tag'],
        ['fa-solid fa-terminal','terminal command console coding developer'],
        ['fa-solid fa-bug','bug error debug insect software'],
        ['fa-solid fa-gear','gear settings configuration mechanic cog'],
        ['fa-solid fa-gears','gears settings multiple configuration cogs'],
        ['fa-solid fa-sliders','sliders settings adjust configuration'],
        ['fa-solid fa-toolbox','toolbox tools repair fix maintenance'],
        ['fa-solid fa-wrench','wrench tool fix repair settings'],
        ['fa-solid fa-hammer','hammer tool build construction repair'],
        ['fa-solid fa-paintbrush','paintbrush paint design creative brush art'],
        ['fa-solid fa-palette','palette color design art paint theme'],
        ['fa-solid fa-eye','eye view visibility show preview see'],
        ['fa-solid fa-eye-slash','eye slash hidden invisible hide blind'],
        ['fa-solid fa-bell','bell notification alert reminder'],
        ['fa-solid fa-envelope','envelope mail message email contact'],
        ['fa-solid fa-message','message chat talk conversation text'],
        ['fa-solid fa-comment','comment feedback reply chat speech bubble'],
        ['fa-solid fa-comments','comments multiple chat conversation'],
        ['fa-solid fa-headset','headset support help assistance audio'],
        ['fa-solid fa-life-ring','life ring support help assistance rescue'],
        ['fa-solid fa-circle-question','circle question help faq support question'],
        ['fa-solid fa-circle-info','circle info information help details'],
        ['fa-solid fa-circle-exclamation','circle exclamation warning alert danger'],
        ['fa-solid fa-triangle-exclamation','triangle exclamation warning alert danger caution'],
        ['fa-solid fa-circle-check','circle check success complete done confirm verified'],
        ['fa-solid fa-circle-xmark','circle xmark cancel close delete remove error'],
        ['fa-solid fa-check','check tick mark done complete verify yes approve'],
        ['fa-solid fa-xmark','xmark close cancel remove delete times'],
        ['fa-solid fa-plus','plus add new create include'],
        ['fa-solid fa-pen','pen edit write draw pencil marker'],
        ['fa-solid fa-pen-to-square','pen to square edit compose write'],
        ['fa-solid fa-trash','trash delete remove bin garbage waste'],
        ['fa-solid fa-floppy-disk','floppy disk save storage backup retro'],
        ['fa-solid fa-copy','copy duplicate clone files'],
        ['fa-solid fa-paste','paste clipboard duplicate copy'],
        ['fa-solid fa-link','link url hyperlink chain connect anchor'],
        ['fa-solid fa-image','image picture photo gallery media'],
        ['fa-solid fa-camera','camera photo capture image picture'],
        ['fa-solid fa-video','video film movie camera recording'],
        ['fa-solid fa-music','music note sound audio melody song'],
        ['fa-solid fa-headphones','headphones music audio sound listen'],
        ['fa-solid fa-phone','phone call telephone contact mobile'],
        ['fa-solid fa-cart-flatbed','cart flatbed truck delivery shipping transport'],
        ['fa-solid fa-truck','truck delivery shipping transport van vehicle'],
        ['fa-solid fa-box','box package container parcel storage item'],
        ['fa-solid fa-boxes','boxes packages multiple items storage warehouse'],
        ['fa-solid fa-archive','archive storage box warehouse backlog old'],
        ['fa-solid fa-clock','clock time history recent hour minute schedule'],
        ['fa-solid fa-calendar','calendar date event schedule plan month day'],
        ['fa-solid fa-chart-line','chart line graph analytics growth stats trend'],
        ['fa-solid fa-chart-bar','chart bar graph analytics statistics histogram column'],
        ['fa-solid fa-chart-pie','chart pie graph analytics statistics distribution'],
        ['fa-solid fa-chart-simple','chart simple graph analytics stats simplified'],
        ['fa-solid fa-list','list checklist todo items bullet'],
        ['fa-solid fa-table','table grid spreadsheet data matrix'],
        ['fa-solid fa-search','search magnifying glass find explore scan'],
        ['fa-solid fa-filter','filter sort categorize refine funnel'],
        ['fa-solid fa-sort','sort order arrange organize asc desc'],
        ['fa-solid fa-arrow-up','arrow up direction top increase ascend'],
        ['fa-solid fa-arrow-down','arrow down direction bottom decrease descend'],
        ['fa-solid fa-arrow-left','arrow left direction back previous left'],
        ['fa-solid fa-arrow-right','arrow right direction next forward right'],
        ['fa-solid fa-arrow-up-right-from-square','arrow up right external link open square'],
        ['fa-solid fa-up-right-from-square','external link open blank new tab'],
        ['fa-solid fa-right-to-bracket','right to bracket login enter signin arrow'],
        ['fa-solid fa-left-from-bracket','left from bracket logout exit signout arrow'],
        ['fa-solid fa-rotate-right','rotate right refresh reload redo sync arrow'],
        ['fa-solid fa-rotate-left','rotate left undo history rollback arrow'],
        ['fa-solid fa-arrows-rotate','arrows rotate refresh sync reload spin'],
        ['fa-solid fa-check-double','check double verified double tick confirm complete'],
        ['fa-solid fa-medal','medal award achievement winner badge trophy'],
        ['fa-solid fa-trophy','trophy award achievement winner champion medal cup'],
        ['fa-solid fa-award','award achievement badge prize certificate'],
        ['fa-solid fa-certificate','certificate award achievement license verified badge'],
        ['fa-solid fa-book','book reading knowledge education manual guide'],
        ['fa-solid fa-book-open','book open reading knowledge education learning'],
        ['fa-solid fa-graduation-cap','graduation cap education learning degree student'],
        ['fa-solid fa-school','school education building institution learning'],
        ['fa-solid fa-newspaper','newspaper news article press media journal'],
        ['fa-solid fa-bullhorn','bullhorn announcement news broadcast notification'],
        ['fa-solid fa-megaphone','megaphone announcement broadcast speaker amplify'],
        ['fa-solid fa-globe','globe world earth language internet web global'],
        ['fa-solid fa-flag','flag country goal mark banner milestone'],
        ['fa-solid fa-location-dot','location dot map marker pin address place poi'],
        ['fa-solid fa-map','map location travel navigation compass directions'],
        ['fa-solid fa-compass','compass navigation direction travel location guide explore'],
        ['fa-solid fa-house','house home page main index dashboard'],
        ['fa-solid fa-door-open','door open entrance entry welcome access'],
        ['fa-solid fa-gauge','gauge dashboard speedometer metrics performance meter'],
        ['fa-solid fa-bars','bars hamburger menu toggle navigation mobile'],
        ['fa-solid fa-chevron-down','chevron down arrow expand dropdown menu'],
        ['fa-solid fa-chevron-up','chevron up arrow collapse fold menu'],
        ['fa-solid fa-chevron-left','chevron left arrow back previous collapse'],
        ['fa-solid fa-chevron-right','chevron right arrow next forward expand'],
        ['fa-solid fa-angles-right','angles right fast forward skip double chevron'],
        ['fa-solid fa-angles-left','angles left rewind skip double chevron'],
        ['fa-solid fa-circle-play','circle play video start media player'],
        ['fa-solid fa-circle-stop','circle stop halt media player square'],
        ['fa-solid fa-play','play start video media movie music'],
        ['fa-solid fa-pause','pause break stop media video music freeze'],
        ['fa-solid fa-stop','stop halt media player square'],
        ['fa-solid fa-power-off','power off switch shutdown reboot toggle on off'],
        ['fa-solid fa-qrcode','qrcode scan square barcode qr code'],
        ['fa-solid fa-barcode','barcode scan retail product code strip'],
        ['fa-solid fa-share','share spread social distribution send forward'],
        ['fa-solid fa-share-nodes','share nodes social network connection link'],
        ['fa-solid fa-paper-plane','paper plane send message email quick'],
        ['fa-solid fa-thumbs-up','thumbs up like approve yes positive good'],
        ['fa-solid fa-thumbs-down','thumbs down dislike disapprove no negative'],
        ['fa-solid fa-ban','ban forbidden prohibited no stop denied'],
        ['fa-solid fa-hand','hand stop gesture raise palm high five'],
        ['fa-solid fa-geo-alt','geo alt location map marker pin'],
        ['fa-solid fa-terrain','terrain landscape earth ground globe world'],
        ['fa-solid fa-water','water ocean sea lake droplet liquid wave'],
        ['fa-solid fa-tint','tint droplet water liquid drop moisture'],
        ['fa-solid fa-poop','poop poop emoji toilet crap garbage waste'],
        ['fa-solid fa-toilet','toilet bathroom restroom wc washroom'],
        ['fa-solid fa-coins','coins money currency payment treasure gold multiple'],
        ['fa-solid fa-cash-register','cash register payment checkout pos retail store'],
        ['fa-solid fa-couch','couch sofa furniture chair lounge relax seat'],
        ['fa-solid fa-bed','bed sleep night hotel furniture rest'],
        ['fa-solid fa-building','building office construction architecture corporate building'],
        ['fa-solid fa-warehouse','warehouse storage inventory stock depot building'],
        ['fa-solid fa-industry','industry factory manufacturing production building pipe'],
        ['fa-solid fa-bridge','bridge connection link structure network construction'],
        ['fa-solid fa-link-slash','link slash broken link disconnect unlink chain'],
        ['fa-solid fa-unlink','unlink break link disconnect separator broken'],
    ];
    icons.forEach(function(i){ _allIcons.push({c:i[0],k:i[1]}); });
})();

function toggleIconPicker(targetId, previewId) {
    var modal = document.getElementById('iconPickerModal');
    _iconTarget = document.getElementById(targetId);
    _iconPreview = document.getElementById(previewId);
    modal.classList.remove('hidden');
    renderIcons('');
    document.getElementById('iconSearchInput').value = '';
    document.getElementById('iconSearchInput').focus();
}

function closeIconPicker() {
    document.getElementById('iconPickerModal').classList.add('hidden');
}

function renderIcons(query) {
    var grid = document.getElementById('iconGrid');
    var q = query.toLowerCase().trim();
    var icons = q ? _allIcons.filter(function(i){ return i.c.indexOf(q) !== -1 || i.k.indexOf(q) !== -1; }) : _allIcons;
    grid.innerHTML = icons.map(function(i){
        var active = _iconTarget && _iconTarget.value === i.c ? ' active' : '';
        return '<div class="icn-sel'+active+'" data-class="'+i.c+'" onclick="pickIcon(this)"><i class="'+i.c+'"></i></div>';
    }).join('');
}

document.addEventListener('DOMContentLoaded', function(){
    document.getElementById('iconSearchInput').addEventListener('input', function(){
        renderIcons(this.value);
    });
});

function pickIcon(el) {
    document.querySelectorAll('.icn-sel').forEach(function(s){ s.classList.remove('active'); });
    el.classList.add('active');
    if (_iconTarget) {
        _iconTarget.value = el.getAttribute('data-class');
        if (_iconPreview) catIconPreview(_iconTarget.id, _iconPreview.id);
    }
    closeIconPicker();
}

function catIconIsUrl(v){ return /^(https?:\/\/|\/|data:image\/)/i.test((v||'').trim()); }

function catIconPreview(inputId, previewId) {
    var inp = document.getElementById(inputId);
    var pre = document.getElementById(previewId);
    if (!inp || !pre) return;
    var v = inp.value.trim();
    if (!v) { pre.innerHTML = ''; return; }
    var safe = v.replace(/"/g, '');
    pre.innerHTML = catIconIsUrl(v) ? '<img src="'+safe+'" style="width:28px;height:28px;object-fit:cover;border-radius:8px;" alt="">' : '<i class="'+safe+'"></i>';
}

function checkIconPreview(inputId, previewId) {
    catIconPreview(inputId, previewId);
}

function uploadCatIcon(fileInput, inputId, previewId, statusId) {
    var f = fileInput.files ? fileInput.files[0] : null;
    fileInput.value = '';
    var st = document.getElementById(statusId);
    function msg(t, ok){ if (st) { st.textContent = t; st.style.color = ok ? '#4ade80' : '#f87171'; } }
    if (!f) return;
    if (!/image\/(png|jpeg|webp|gif)/.test(f.type || '')) { msg(<?= json_encode(__('acat.js_badtype')) ?>, false); return; }
    if (f.size > 8388608) { msg(<?= json_encode(__('acat.js_maxsize')) ?>, false); return; }
    msg(<?= json_encode(__('aprod.loading')) ?>, true);
    var fd = new FormData();
    fd.append('action', 'asset_upload'); fd.append('ctx', 'ticket_categories'); fd.append('asset_type', 'caticon'); fd.append('file', f);
    fetch('/action.php', {method:'POST', body:fd}).then(function(r){ return r.json(); }).then(function(d){
        if (d && d.ok && d.url) {
            document.getElementById(inputId).value = d.url;
            catIconPreview(inputId, previewId);
            msg(<?= json_encode(__('acat.js_uploaded')) ?>, true);
        } else { msg((d && d.msg) || <?= json_encode(__('apedit.upload_fail')) ?>, false); }
    }).catch(function(){ msg(<?= json_encode(__('aprod.req_fail_short')) ?>, false); });
}

document.getElementById('addCatIcon').addEventListener('input', function(){ checkIconPreview('addCatIcon','addCatIconPreview'); });
document.getElementById('editCatIcon').addEventListener('input', function(){ checkIconPreview('editCatIcon','editCatIconPreview'); });

function openEditCat(c) {
    document.getElementById('editCatId').value = c.id;
    document.getElementById('editCatName').value = c.name;
    document.getElementById('editCatIcon').value = c.icon || '';
    checkIconPreview('editCatIcon','editCatIconPreview');
    document.getElementById('editCatSort').value = c.sort_order || 0;
    document.getElementById('editCatModal').classList.remove('hidden');
}
</script>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
