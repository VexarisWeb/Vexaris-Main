<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('asupp.page_title');
$activePage = 'tickets';

$msg = '';

/* ── Durum güncelle ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_ticket'])) {
    $tid    = (int)$_POST['update_ticket'];
    $status = in_array($_POST['status'], ['open','replied','closed']) ? $_POST['status'] : 'open';
    $adminDb->prepare('UPDATE tickets SET status = ? WHERE id = ?')->execute([$status, $tid]);
    $msg = ['type'=>'success','text'=>__('atick.updated_ok')];
}

/* ── Sil ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_ticket'])) {
    if (!in_array(($_SESSION['user']['role'] ?? ''), ['admin', 'superadmin'], true)) $msg = ['type'=>'error','text'=>__('atick.no_perm')];
    else {
        $adminDb->prepare('DELETE FROM tickets WHERE id = ?')->execute([(int)$_POST['delete_ticket']]);
        $msg = ['type'=>'success','text'=>__('atick.deleted_ok')];
    }
}

/* ── Filtre ── */
$filter = $_GET['status'] ?? 'all';
if ($filter !== 'all' && in_array($filter, ['open','replied','closed'])) {
    $stmt = $adminDb->prepare(
        'SELECT t.*,u.username,u.email FROM tickets t
         LEFT JOIN users u ON u.id=t.user_id WHERE t.status=? ORDER BY COALESCE(t.updated_at,t.created_at) DESC, t.id DESC'
    );
    $stmt->execute([$filter]);
} else {
    $stmt = $adminDb->query(
        'SELECT t.*,u.username,u.email FROM tickets t
         LEFT JOIN users u ON u.id=t.user_id ORDER BY COALESCE(t.updated_at,t.created_at) DESC, t.id DESC'
    );
}
$tickets = $stmt->fetchAll();

/* İstatistikler */
$counts = ['open'=>0,'replied'=>0,'closed'=>0];
foreach ($adminDb->query('SELECT status,COUNT(*) c FROM tickets GROUP BY status')->fetchAll() as $r) {
    $counts[$r['status']] = $r['c'];
}

include __DIR__ . '/includes/layout.php';
?>

<?php if ($msg): ?>
<div style="background:<?= ($msg['type'] ?? '')==='error'?'rgba(239,68,68,.1)':'rgba(34,197,94,.1)' ?>;border:1px solid <?= ($msg['type'] ?? '')==='error'?'rgba(239,68,68,.3)':'rgba(34,197,94,.3)' ?>;color:<?= ($msg['type'] ?? '')==='error'?'#f87171':'#4ade80' ?>;
     padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;
     margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid fa-<?= ($msg['type'] ?? '')==='error'?'circle-xmark':'circle-check' ?>"></i> <?= e($msg['text']) ?>
</div>
<?php endif; ?>

<!-- Özet -->
<div style="display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap;">
    <?php
    $tabs = ['all'=>[__('shop.all'),count($tickets),'badge-indigo'],
             'open'=>[__('ticket.open'),$counts['open'],'badge-red'],
             'replied'=>[__('ticket.replied'),$counts['replied'],'badge-yellow'],
             'closed'=>[__('ticket.closed'),$counts['closed'],'badge-green']];
    foreach ($tabs as $val=>[$label,$cnt,$bc]): ?>
    <a href="/admin/tickets.php?status=<?= $val ?>"
       style="display:flex;align-items:center;gap:8px;padding:8px 16px;
              background:<?= $filter===$val?'rgba(var(--accent-rgb),.12)':'var(--bg-card)' ?>;
              border:1px solid <?= $filter===$val?'rgba(var(--accent-rgb),.4)':'var(--border)' ?>;
              border-radius:10px;font-size:13px;font-weight:700;color:<?= $filter===$val?'#a5b4fc':'var(--muted)' ?>;
              transition:.15s;">
        <?= $label ?> <span class="badge <?= $bc ?>" style="padding:2px 8px;"><?= $cnt ?></span>
    </a>
    <?php endforeach; ?>
</div>

<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>#</th><th><?= __('aint.title') ?></th><th><?= __('apurch.user') ?></th><th><?= __('adash.th_status') ?></th><th><?= __('apurch.col_date') ?></th><th><?= __('adash.th_action') ?></th></tr></thead>
        <tbody>
        <?php foreach ($tickets as $t): ?>
        <tr class="animate-row">
            <td style="color:var(--muted);font-size:12px;">#<?= $t['id'] ?></td>
            <td style="font-weight:600;"><?= e($t['title']) ?></td>
            <td>
                <div style="font-size:13px;"><?= e($t['username'] ?? '—') ?></div>
                <div style="font-size:11px;color:var(--muted);"><?= e($t['email'] ?? '') ?></div>
            </td>
            <td>
                <?php $sc=['open'=>'badge-red','replied'=>'badge-yellow','closed'=>'badge-green']; ?>
                <span class="badge <?= $sc[$t['status']] ?>">
                    <?= ['open'=>__('ticket.open'),'replied'=>__('ticket.replied'),'closed'=>__('ticket.closed')][$t['status']] ?>
                </span>
            </td>
            <td style="color:var(--muted);font-size:12px;"><?= date('d.m.Y H:i', strtotime($t['created_at'])) ?></td>
            <td>
                <div style="display:flex;gap:6px;align-items:center;">
                    <form method="POST" style="margin:0;display:flex;gap:4px;align-items:center;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="update_ticket" value="<?= $t['id'] ?>">
                        <select name="status" style="background:var(--bg-surface);border:1px solid var(--border);
                                border-radius:8px;padding:5px 10px;color:var(--text);font-size:12px;outline:none;">
                            <option value="open"    <?= $t['status']==='open'?'selected':''    ?>><?= __('ticket.open') ?></option>
                            <option value="replied" <?= $t['status']==='replied'?'selected':'' ?>><?= __('ticket.replied') ?></option>
                            <option value="closed"  <?= $t['status']==='closed'?'selected':''  ?>><?= __('ticket.closed') ?></option>
                        </select>
                        <button type="submit" class="btn-admin btn-ghost-admin" style="padding:5px 10px;font-size:12px;">
                            <i class="fa-solid fa-check"></i>
                        </button>
                    </form>
                    <?php if (in_array(($adminUser['role'] ?? ''), ['admin', 'superadmin'], true)): ?>
                    <form method="POST" onsubmit="return confirm(<?= json_encode(__('atick.confirm_delete')) ?>);" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="delete_ticket" value="<?= $t['id'] ?>">
                        <button type="submit" class="btn-admin" style="background:rgba(239,68,68,.1);color:#f87171;padding:5px 10px;font-size:12px;border:1px solid rgba(239,68,68,.2);">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($tickets)): ?>
        <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:32px;"><?= __('err.ticket_missing') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/includes/layout-end.php'; ?>
