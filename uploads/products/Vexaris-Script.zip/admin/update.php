<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

require_once ROOT_PATH . '/core/init.php';
require_once __DIR__ . '/includes/guard.php';

$pageTitle = __('aupd.title');

$updSt  = update_state($adminDb);
$updVer = $updSt['version'];
$curVer = vexaris_current_version($adminDb);
$available = function_exists('update_available') && update_available($adminDb);
$delayed   = update_delay_blocked($adminDb);
$autoOn    = update_auto_enabled($adminDb);

require_once __DIR__ . '/includes/layout.php';
?>

<div style="max-width:720px;margin:0 auto">
  <div class="admin-card">
    <div class="admin-card-header">
      <div class="admin-card-title"><i class="fa-solid fa-cloud-arrow-down" style="color:var(--accent);margin-right:8px"></i><?= __('aupd.heading') ?></div>
      <span class="badge badge-indigo"><?= __('aupd.installed') ?> v<?= e($curVer) ?></span>
    </div>

    <?php if (!$available && !$delayed): ?>
    <div style="text-align:center;padding:1.5rem 0">
      <div style="font-size:3rem;margin-bottom:1rem"><i class="fa-solid fa-circle-check" style="color:var(--green)"></i></div>
      <div style="font-size:15px;font-weight:800;margin-bottom:.4rem"><?= __('aupd.up_to_date') ?></div>
      <div style="font-size:12px;color:var(--muted);margin-bottom:1.4rem"><?= __('aupd.installed_version') ?> v<?= e($curVer) ?></div>
      <button class="btn-admin btn-primary-admin" onclick="vxUpdCheck()"><i class="fa-solid fa-rotate-right"></i> <?= __('aupd.check') ?></button>
    </div>
    <?php elseif ($delayed): ?>
    <div style="text-align:center;padding:1.5rem 0">
      <div style="font-size:3rem;margin-bottom:1rem"><i class="fa-solid fa-clock" style="color:var(--yellow)"></i></div>
      <div style="font-size:15px;font-weight:800;margin-bottom:.4rem"><?= __('aupd.delayed') ?></div>
      <div style="font-size:12px;color:var(--muted);margin-bottom:1.4rem"><?= __('aupd.new_version') ?> v<?= e($updVer) ?></div>
      <button class="btn-admin btn-primary-admin" onclick="vxUpdNow()"><i class="fa-solid fa-cloud-arrow-down"></i> <?= __('aupd.now') ?></button>
    </div>
    <?php else: ?>
    <div style="margin-bottom:1.4rem">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:.5rem">
        <span class="badge badge-indigo" style="font-size:12px">v<?= e($updVer) ?></span>
        <?php if ($autoOn): ?>
        <span class="badge badge-green"><i class="fa-solid fa-wand-magic-sparkles"></i> <?= __('aupd.auto') ?></span>
        <?php endif; ?>
      </div>
      <?php if ($updSt['description'] !== ''): ?>
      <div style="font-size:12px;color:var(--muted);background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:12px 14px;margin-bottom:1.4rem"><?= e($updSt['description']) ?></div>
      <?php endif; ?>
      <?php if ($updSt['file_size'] !== ''): ?>
      <div style="font-size:12px;color:var(--muted);margin-bottom:1.4rem"><i class="fa-solid fa-file-zipper"></i> <?= __('amenu.size') ?> <?= e($updSt['file_size']) ?></div>
      <?php endif; ?>
    </div>
    <button class="btn-admin btn-primary-admin" style="width:100%;justify-content:center;padding:13px" onclick="vxUpdNow()"><i class="fa-solid fa-cloud-arrow-down"></i> <?= __('aupd.download_install') ?></button>
    <?php endif; ?>
  </div>

  <div class="admin-card" id="vxUpdProgressCard" style="display:none">
    <div class="admin-card-header">
      <div class="admin-card-title"><i class="fa-solid fa-spinner fa-spin" style="color:var(--accent);margin-right:8px"></i><?= __('aupd.installing') ?></div>
      <span class="badge badge-indigo" id="vxUpdProgressVersion"></span>
    </div>
    <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;height:18px;overflow:hidden;position:relative;margin-bottom:.8rem">
      <div id="vxUpdProgressBar" style="height:100%;width:0%;background:linear-gradient(90deg,var(--accent),var(--accent-dark));border-radius:12px;transition:width .4s ease"></div>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px">
      <div style="font-size:12px;color:var(--muted)" id="vxUpdProgressMsg"><?= __('aupd.starting') ?></div>
      <div style="font-size:13px;font-weight:800;color:var(--text)" id="vxUpdProgressPct">%0</div>
    </div>
  </div>

  <div class="admin-card" id="vxUpdDoneCard" style="display:none;text-align:center">
    <div style="font-size:3rem;margin-bottom:1rem"><i class="fa-solid fa-circle-check" style="color:var(--green)"></i></div>
    <div style="font-size:15px;font-weight:800;margin-bottom:.4rem" id="vxUpdDoneTitle"><?= __('aupd.done_title') ?></div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:1.4rem" id="vxUpdDoneSub"></div>
    <button class="btn-admin btn-primary-admin" onclick="window.location.reload()"><i class="fa-solid fa-rotate-right"></i> <?= __('aupd.refresh') ?></button>
  </div>

  <div class="admin-card" id="vxUpdErrCard" style="display:none;text-align:center">
    <div style="font-size:3rem;margin-bottom:1rem"><i class="fa-solid fa-triangle-exclamation" style="color:var(--red)"></i></div>
    <div style="font-size:15px;font-weight:800;margin-bottom:.4rem"><?= __('aupd.fail_title') ?></div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:1.4rem" id="vxUpdErrMsg"></div>
    <button class="btn-admin btn-primary-admin" onclick="window.location.reload()"><i class="fa-solid fa-rotate-right"></i> <?= __('aupd.retry') ?></button>
  </div>
</div>

<script>
const VX_CSRF = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
const vxUpdVer = <?= json_encode($updVer) ?>;
let vxUpdPoll = null;

function vxUpdFetch(action, extra) {
  const fd = new FormData();
  fd.append('action', action);
  if (extra) Object.keys(extra).forEach(k => fd.append(k, extra[k]));
  return fetch('/action.php', { method:'POST', body:fd, headers:{'X-CSRF-Token': VX_CSRF} });
}

function vxUpdShow(id) {
  ['vxUpdProgressCard','vxUpdDoneCard','vxUpdErrCard'].forEach(x => document.getElementById(x).style.display = 'none');
  document.getElementById(id).style.display = 'block';
}

function vxUpdPollProgress() {
  vxUpdFetch('update_progress').then(r => r.json()).then(d => {
    if (!d.ok) return;
    const p = d.progress || {};
    const bar = document.getElementById('vxUpdProgressBar');
    const pct = document.getElementById('vxUpdProgressPct');
    const msg = document.getElementById('vxUpdProgressMsg');
    const pv = parseInt(p.percent || 0, 10);
    bar.style.width = pv + '%';
    pct.textContent = '%' + pv;
    msg.textContent = p.msg || '';
    document.getElementById('vxUpdProgressVersion').textContent = 'v' + (p.version || vxUpdVer);
    if (p.phase === 'done') {
      clearInterval(vxUpdPoll);
      vxUpdShow('vxUpdDoneCard');
      document.getElementById('vxUpdDoneSub').textContent = 'v' + (p.version || vxUpdVer) + ' ' + <?= json_encode(__('aupd.done_suffix')) ?>;
    } else if (p.phase === 'error') {
      clearInterval(vxUpdPoll);
      vxUpdShow('vxUpdErrCard');
      document.getElementById('vxUpdErrMsg').textContent = p.msg || <?= json_encode(__('aupd.unknown')) ?>;
    }
  }).catch(() => {});
}

function vxUpdNow() {
  vxUpdShow('vxUpdProgressCard');
  vxUpdPoll = setInterval(vxUpdPollProgress, 2500);
  vxUpdFetch('update_download').then(r => r.json()).then(d => {
    if (d.ok) {
      document.getElementById('vxUpdProgressMsg').textContent = <?= json_encode(__('aupd.finishing')) ?>;
    } else {
      clearInterval(vxUpdPoll);
      vxUpdShow('vxUpdErrCard');
      document.getElementById('vxUpdErrMsg').textContent = d.msg || <?= json_encode(__('err.op_fail')) ?>;
    }
  }).catch(() => {
    clearInterval(vxUpdPoll);
    vxUpdShow('vxUpdErrCard');
    document.getElementById('vxUpdErrMsg').textContent = <?= json_encode(__('amenu.conn_err')) ?>;
  });
}

function vxUpdCheck() {
  vxUpdFetch('update_check').then(r => r.json()).then(d => {
    if (d.ok && d.available) {
      window.location.reload();
    } else {
      alert(d.msg || <?= json_encode(__('aupd.no_new')) ?>);
    }
  }).catch(() => alert(<?= json_encode(__('amenu.conn_err')) ?>));
}
</script>

<?php require_once __DIR__ . '/includes/layout-end.php'; ?>