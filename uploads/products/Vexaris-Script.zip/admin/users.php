<?php
require_once __DIR__ . '/includes/guard.php';
$pageTitle  = __('amenu.users');
$activePage = 'users';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') csrf_verify();

$myRole   = $adminUser['role'] ?? 'user';
$roleRank = roles_rank_map($adminDb);
$myRank   = $roleRank[$myRole] ?? 0;

function target_user_role(int $uid): ?string {
    global $adminDb;
    try {
        $st = $adminDb->prepare('SELECT role FROM users WHERE id=? LIMIT 1');
        $st->execute([$uid]);
        $r = $st->fetchColumn();
        return $r === false ? null : (string)$r;
    } catch (\PDOException $e) {
        error_log('[Vexaris] users role fetch: ' . $e->getMessage());
        return null;
    }
}

function users_can_bootstrap_superadmin(): bool {
    global $adminDb, $myRole;
    if ($myRole !== 'admin') return false;
    try {
        $st = $adminDb->query("SELECT COUNT(*) FROM users WHERE role='superadmin'");
        return ((int)$st->fetchColumn() === 0);
    } catch (\PDOException $e) {
        return false;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    $uid = (int)$_POST['delete_user'];
    if ($uid === (int)$adminUser['id']) {
        $msg = ['type'=>'error','text'=>__('ausers.self_delete_err')];
    } else {
        $tRole = target_user_role($uid);
        if ($tRole === null) {
            $msg = ['type'=>'error','text'=>__('err.user_missing')];
        } elseif ($tRole === 'superadmin' && $myRole !== 'superadmin') {
            $msg = ['type'=>'error','text'=>__('ausers.no_perm_delete')];
        } elseif ($myRole !== 'admin' && $myRole !== 'superadmin' && (($roleRank[$tRole] ?? 0) >= $myRank)) {
            $msg = ['type'=>'error','text'=>__('ausers.no_perm_delete')];
        } else {
            $tName = '';
            try { $nmSt = $adminDb->prepare('SELECT username FROM users WHERE id=?'); $nmSt->execute([$uid]); $tName = (string)($nmSt->fetchColumn() ?: ''); } catch (\PDOException $e) {}
            $adminDb->prepare('DELETE FROM users WHERE id = ?')->execute([$uid]);
            audit_log($adminDb, 'delete', 'users', $uid, $tName !== '' ? $tName : '#' . $uid, '/admin/users.php');
            $msg = ['type'=>'success','text'=>__('ausers.deleted_ok')];
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    $uid     = (int)$_POST['update_user'];
    $role    = $_POST['role'] ?? 'user';
    $allowed = array_keys($roleRank);
    if (!in_array($role, $allowed, true)) $role = 'user';
    $tRole = target_user_role($uid);
    if ($tRole === null) {
        $msg = ['type'=>'error','text'=>__('err.user_missing')];
    } elseif ($tRole === 'superadmin' && $myRole !== 'superadmin') {
        $msg = ['type'=>'error','text'=>__('ausers.no_perm_role')];
    } elseif ($role === 'superadmin' && $myRole !== 'superadmin' && !users_can_bootstrap_superadmin()) {
        $msg = ['type'=>'error','text'=>__('ausers.no_perm_role')];
    } elseif ($myRole !== 'admin' && $myRole !== 'superadmin' && (($roleRank[$tRole] ?? 0) >= $myRank)) {
        $msg = ['type'=>'error','text'=>__('ausers.no_perm_role')];
    } elseif ($role !== 'user' && $role !== 'superadmin' && ($tRole === 'user' || $tRole === 'superadmin') && function_exists('plan_seats_used') && function_exists('plan_seats') && plan_seats_used($adminDb) >= plan_seats()) {
        $msg = ['type'=>'error','text'=>__('plan.seats_full', ['have' => plan_seats_used($adminDb), 'limit' => plan_seats()])];
    } else {
        if ($myRole !== 'admin' && $myRole !== 'superadmin') {
            $role = 'user';
        }
        if ($uid === (int)$adminUser['id'] && !($role === 'superadmin' && users_can_bootstrap_superadmin())) {
            $role = $myRole;
        }
        $username = trim($_POST['username'] ?? '');
        $uok = true;
        try {
            if ($username !== '') {
                if (!preg_match('/^[a-zA-Z0-9_]{3,32}$/', $username)) {
                    $msg = ['type'=>'error','text'=>__('ausers.bad_username')];
                    $uok = false;
                } else {
                $st = $adminDb->prepare('UPDATE users SET role = ?, username = ? WHERE id = ?');
                $st->execute([$role, $username, $uid]);
                }
            } else {
                $st = $adminDb->prepare('UPDATE users SET role = ? WHERE id = ?');
                $st->execute([$role, $uid]);
            }
            if ($uok) {
                if ($role !== $tRole) {
                    auth_bump_session_version($adminDb, $uid);
                }
                audit_log($adminDb, 'update', 'users', $uid, ($username !== '' ? $username : '#' . $uid), '/admin/users.php');
                $msg = ['type'=>'success','text'=>__('ausers.updated_ok')];
            }
        } catch (\PDOException $e) {
            error_log('[Vexaris] users update: ' . $e->getMessage());
            $msg = ['type'=>'error','text'=>__('ausers.update_fail')];
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_credit'])) {
    $uid    = (int)($_POST['credit_user_id'] ?? 0);
    $amount = (float)($_POST['credit_amount'] ?? 0);
    $note   = trim($_POST['credit_note'] ?? '');
    if ($amount <= 0 || $amount > 1000000) {
        $msg = ['type'=>'error','text'=>__('ausers.bad_amount')];
    } else {
        $tRole = target_user_role($uid);
        if ($tRole === null) {
            $msg = ['type'=>'error','text'=>__('err.user_missing')];
        } elseif ($tRole === 'superadmin' && $myRole !== 'superadmin') {
            $msg = ['type'=>'error','text'=>__('ausers.no_perm_credit')];
        } elseif ($myRole !== 'admin' && $myRole !== 'superadmin' && (($roleRank[$tRole] ?? 0) >= $myRank)) {
            $msg = ['type'=>'error','text'=>__('ausers.no_perm_credit')];
        } else {
            try {
                $adminDb->prepare('UPDATE users SET balance = balance + ? WHERE id = ?')->execute([$amount, $uid]);
                $desc = $note !== '' ? $note : __('ausers.credit_default_note');
                $adminDb->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,?,NOW())')
                        ->execute([$uid, $amount, 'admin', $desc]);
                audit_log($adminDb, 'create', 'balance', $uid, '#' . $uid, '/admin/users.php?tab=balance');
                $msg = ['type'=>'success','text'=>sprintf(__('ausers.credit_sent_fmt'), $amount)];
            } catch (\PDOException $e) {
                error_log('[Vexaris] credit send: ' . $e->getMessage());
                $msg = ['type'=>'error','text'=>__('ausers.credit_fail')];
            }
        }
    }
}

$tab = $_GET['tab'] ?? 'users';

/* ── Bakiye kayıtları ── */
$balanceLog = [];
$balanceTotal = 0;
if ($tab === 'balance') {
    $blUid = (int)($_GET['user_id'] ?? 0);
    $blUidIsSuper = false;
    if ($blUid > 0 && $myRole !== 'superadmin') {
        try {
            $blSt = $adminDb->prepare('SELECT role FROM users WHERE id=? LIMIT 1');
            $blSt->execute([$blUid]);
            $blUidIsSuper = ((string)$blSt->fetchColumn() === 'superadmin');
        } catch (\PDOException $e) {}
    }
    if ($blUid && !$blUidIsSuper) {
        $bStmt = $adminDb->prepare('SELECT amount,type,description,created_at FROM balance_log WHERE user_id=? ORDER BY created_at DESC LIMIT 100');
        $bStmt->execute([$blUid]);
        $balanceLog = $bStmt->fetchAll();
    }
    if (empty($balanceLog)) {
        if ($myRole === 'superadmin') {
            $bStmt = $adminDb->query('SELECT bl.*,u.username FROM balance_log bl JOIN users u ON u.id=bl.user_id ORDER BY bl.created_at DESC LIMIT 200');
        } else {
            $bStmt = $adminDb->query("SELECT bl.*,u.username FROM balance_log bl JOIN users u ON u.id=bl.user_id WHERE u.role <> 'superadmin' ORDER BY bl.created_at DESC LIMIT 200");
        }
        $balanceLog = $bStmt->fetchAll();
    }
}

$search = trim($_GET['q'] ?? '');
$searchLike = str_replace(['\\','%','_'], ['\\\\','\\%','\\_'], $search);

$hideSuper = ($myRole === 'superadmin') ? '' : " AND role <> 'superadmin'";

/* AJAX arama endpoint'i — sayfa yenilenmez */
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    try {
        if (mb_strlen($search) < 2) { echo json_encode(['ok'=>true,'users'=>[]]); exit; }
        $st = $adminDb->prepare("SELECT id,username,email,role,avatar,created_at FROM users WHERE (username LIKE ? OR email LIKE ?)$hideSuper ORDER BY created_at DESC LIMIT 50");
        $st->execute(["%$searchLike%", "%$searchLike%"]);
        echo json_encode(['ok'=>true,'users'=>$st->fetchAll()]);
    } catch (\PDOException $e) {
        echo json_encode(['ok'=>false]);
    }
    exit;
}

if ($search) {
    $stmt = $adminDb->prepare(
        "SELECT id,username,email,role,avatar,created_at FROM users WHERE (username LIKE ? OR email LIKE ?)$hideSuper ORDER BY created_at DESC"
    );
    $stmt->execute(["%$searchLike%", "%$searchLike%"]);
} else {
    $stmt = $adminDb->query("SELECT id,username,email,role,avatar,created_at FROM users WHERE 1=1$hideSuper ORDER BY created_at DESC");
}
$users = $stmt->fetchAll();

$roleList = roles_all($adminDb);
if (empty($roleList)) {
    $roleList = ['user' => ['slug'=>'user','name_tr'=>'Üye','name_en'=>'Member','color'=>'#4ade80','icon'=>'fa-solid fa-user','rank'=>0,'is_system'=>1]];
}
$roleNames = [];
foreach ($roleList as $slug => $rr) $roleNames[$slug] = role_display($adminDb, $slug)['name'];
$roleJsColors = [];
$roleJsIcons = [];
foreach ($roleList as $slug => $rr) {
    $dd = role_display($adminDb, $slug);
    $roleJsColors[$slug] = $dd['color'];
    $roleJsIcons[$slug] = $dd['icon'];
}

include __DIR__ . '/includes/layout.php';
?>
<style>
@keyframes fadeSlideUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
#userSearchForm{flex-shrink:0;max-width:100%;}
#userSearchInput{max-width:60vw;}
.admin-card-header{flex-wrap:wrap;gap:10px;}
#userModal > div,#creditModal > div{max-height:calc(100dvh - 32px);overflow-y:auto;}
@media(max-width:640px){
  .u-table .u-hide-m{display:none;}
  #userModal > div,#creditModal > div{padding:20px 16px;}
  #userModal form > div[style*="display:flex"]{flex-wrap:wrap;}
  #userSearchInput{max-width:46vw;}
}
</style>

<?php if ($msg): ?>
<div style="background:<?= $msg['type']==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;
     border:1px solid <?= $msg['type']==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;
     color:<?= $msg['type']==='success'?'#4ade80':'#f87171' ?>;
     padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;
     margin-bottom:20px;display:flex;align-items:center;gap:8px;">
    <i class="fa-solid <?= $msg['type']==='success'?'fa-circle-check':'fa-circle-xmark' ?>"></i>
    <?= e($msg['text']) ?>
</div>
<?php endif; ?>

<?php if ($tab === 'users'): ?>
<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title">
            <i class="fa-solid fa-users" style="color:var(--accent);margin-right:8px;"></i>
            <?= __('ausers.all_users') ?> <span style="color:var(--muted);font-weight:500;">(<?= count($users) ?>)</span>
        </span>
        <form method="GET" id="userSearchForm" style="display:flex;align-items:center;gap:0;">
            <div style="position:relative;display:flex;align-items:center;" id="userSearchWrap">
                <input type="text" name="q" value="<?= e($search) ?>"
                       placeholder="<?= __('ausers.search_ph') ?>"
                       id="userSearchInput"
                       style="background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;
                              padding:8px 14px;padding-left:36px;color:var(--text);font-size:13px;outline:none;
                              width:0;box-sizing:border-box;transition:width .35s cubic-bezier(.4,0,.2,1),padding .35s,opacity .35s;
                              opacity:0;cursor:pointer;">
                <i class="fa-solid fa-magnifying-glass" id="userSearchIcon"
                   style="position:absolute;left:10px;top:50%;transform:translateY(-50%);font-size:13px;color:var(--muted);
                          pointer-events:none;transition:color .2s;z-index:1;"></i>
            </div>
            <?php if ($search): ?>
            <a href="/admin/users.php" class="btn-admin btn-ghost-admin" style="animation:fadeSlideUp .3s ease;margin-left:8px;flex-shrink:0;">
                <i class="fa-solid fa-xmark"></i> <?= __('apurch.clear') ?>
            </a>
            <?php endif; ?>
        </form>
    </div>

    <table class="admin-table u-table">
        <thead>
            <tr>
                <th><?= __('apurch.user') ?></th>
                <th class="u-hide-m"><?= __('auth.email') ?></th>
                <th><?= __('ausers.th_role') ?></th>
                <th class="u-hide-m"><?= __('ausers.th_registered') ?></th>
                <th><?= __('adash.th_action') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($users as $i => $u): ?>
        <tr class="animate-row user-row" data-id="<?= (int)$u['id'] ?>" data-username="<?= e($u['username']) ?>" data-role="<?= e($u['role']) ?>" style="cursor:pointer;">
            <td style="min-width:0;">
                <div style="display:flex;align-items:center;gap:10px;min-width:0;">
                    <img src="<?= e($u['avatar'] ?: 'https://minotar.net/avatar/user.png') ?>"
                         style="width:32px;height:32px;border-radius:50%;image-rendering:pixelated;flex-shrink:0;
                                border:1.5px solid rgba(var(--accent-rgb),.3);" alt="">
                    <div style="min-width:0;">
                        <div style="font-weight:700;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($u['username']) ?></div>
                        <div style="font-size:11px;color:var(--muted);">ID #<?= $u['id'] ?></div>
                    </div>
                </div>
            </td>
            <td class="u-hide-m" style="color:var(--muted);max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($u['email']) ?></td>
            <td>
                <?= role_badge($adminDb, (string)$u['role']) ?>
            </td>
            <td class="u-hide-m" style="color:var(--muted);font-size:12px;white-space:nowrap;"><?= date('d.m.Y H:i', strtotime($u['created_at'])) ?></td>
            <td>
                <button class="btn-admin btn-ghost-admin" style="padding:6px 12px;font-size:12px;pointer-events:none;">
                    <i class="fa-solid fa-pen"></i> <?= __('ausers.manage') ?>
                </button>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($users)): ?>
        <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:32px;"><?= __('err.user_missing') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php endif; ?>

<?php if ($tab === 'balance'): ?>

<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title">
            <i class="fa-solid fa-coins" style="color:#fbc853;margin-right:8px;"></i>
            <?= __('amenu.users_balance') ?> <span style="color:var(--muted);font-weight:500;">(<?= count($balanceLog) ?>)</span>
        </span>
        <form method="GET" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <input type="hidden" name="tab" value="balance">
            <input type="number" name="user_id" placeholder="<?= __('ausers.user_id_ph') ?>" min="1"
                   style="background:var(--bg-surface);border:1px solid var(--border);border-radius:8px;padding:7px 10px;color:var(--text);font-size:12px;outline:none;width:100px;">
            <button type="submit" class="btn-admin btn-ghost-admin" style="padding:7px 12px;font-size:11px;"><i class="fa-solid fa-search"></i> <?= __('ausers.filter') ?></button>
        </form>
    </div>
    <div style="overflow-x:auto;">
    <table class="admin-table">
        <thead>
            <tr>
                <th>#</th>
                <th><?= __('apurch.user') ?></th>
                <th><?= __('ausers.th_amount') ?></th>
                <th><?= __('ausers.th_type') ?></th>
                <th><?= __('ausers.th_desc') ?></th>
                <th><?= __('apurch.col_date') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($balanceLog as $i => $b): $blId = $b['user_id'] ?? 0; $blUser = $b['username'] ?? ('ID: '.$blId); ?>
        <tr>
            <td style="color:var(--muted);font-size:11px;"><?= $i+1 ?></td>
            <td style="font-size:13px;font-weight:600;"><?= e($blUser) ?></td>
            <td>
                <span style="font-weight:800;color:<?= $b['amount']>=0?'#4ade80':'#f87171' ?>;">
                    <?= $b['amount']>=0?'+':'' ?><?= fmt_money((float)$b['amount']) ?>
                </span>
            </td>
            <td>
                <?php $typeLabels = ['payment'=>__('panel.tx_payment'),'purchase'=>__('panel.tx_purchase'),'topup'=>__('panel.tx_topup'),'coupon'=>__('panel.tx_coupon'),'refund'=>__('panel.tx_refund'),'admin'=>__('nav.role_admin')]; ?>
                <span class="badge <?= $b['type']==='topup'||$b['type']==='refund'?'badge-green':($b['type']==='admin'?'badge-yellow':'badge-indigo') ?>">
                    <?= $typeLabels[$b['type']] ?? e($b['type']) ?>
                </span>
            </td>
            <td style="font-size:12px;color:var(--muted);"><?= e($b['description'] ?? '—') ?></td>
            <td style="font-size:12px;color:var(--muted);"><?= date('d.m.Y H:i', strtotime($b['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($balanceLog)): ?>
        <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:32px;"><?= __('ausers.no_logs') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

<?php endif; ?>

<div id="userModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:999;align-items:center;justify-content:center;"
     onclick="if(event.target===this)closeUserModal()">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;padding:28px;width:440px;max-width:94vw;animation:fadeSlideUp .25s ease;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:22px;">
            <div style="font-size:16px;font-weight:800;"><i class="fa-solid fa-user-gear" style="color:var(--accent);margin-right:8px;"></i><span id="modalTitle"><?= __('ausers.modal_title') ?></span></div>
            <button onclick="closeUserModal()" style="background:none;border:none;color:var(--muted);font-size:18px;cursor:pointer;">&times;</button>
        </div>
        <form method="POST" id="userForm">
            <?= csrf_field() ?>
            <input type="hidden" name="update_user" id="modalUserId">
            <div id="modalProtectNote" style="display:none;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#f87171;border-radius:10px;padding:10px 14px;font-size:12px;font-weight:700;margin-bottom:16px;">
                <i class="fa-solid fa-lock"></i> <?= __('ausers.no_perm_note') ?>
            </div>
            <div style="margin-bottom:16px;">
                <label style="font-size:11px;font-weight:700;color:var(--muted);display:block;margin-bottom:6px;"><?= __('auth.username') ?></label>
                <input type="text" name="username" id="modalUsername" required
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;font-weight:600;outline:none;">
            </div>
            <div style="margin-bottom:20px;">
                <label style="font-size:11px;font-weight:700;color:var(--muted);display:block;margin-bottom:6px;"><?= __('ausers.th_role') ?></label>
                <select name="role" id="modalRole"
                        style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;font-weight:600;outline:none;">
                    <?php foreach ($roleList as $slug => $rr): ?>
                    <?php if ($slug === 'superadmin' && $myRole !== 'superadmin') continue; ?>
                    <option value="<?= e($slug) ?>"><?= e($roleNames[$slug] ?? $slug) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="display:flex;gap:10px;">
                <button type="submit" class="btn-admin btn-primary-admin" style="flex:1;"><?= __('msg.save') ?></button>
                <button type="button" onclick="closeUserModal()" class="btn-admin btn-ghost-admin" style="flex:1;"><?= __('support.cancel') ?></button>
            </div>
        </form>
        <hr style="border:none;border-top:1px solid var(--border);margin:18px 0;">
        <button type="button" id="creditSendBtn" onclick="openCreditModal()"
                style="width:100%;background:rgba(251,200,83,.12);color:#fbc853;border:1px solid rgba(251,200,83,.25);border-radius:10px;padding:10px;font-size:12px;font-weight:700;cursor:pointer;font-family:inherit;margin-bottom:10px;">
            <i class="fa-solid fa-coins"></i> <?= __('ausers.credit_send') ?>
        </button>
        <form method="POST" onsubmit="return confirm('<?= __('ausers.confirm_delete') ?>');">
            <?= csrf_field() ?>
            <input type="hidden" name="delete_user" id="modalDeleteId">
            <button type="submit" style="width:100%;background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2);border-radius:10px;padding:10px;font-size:12px;font-weight:700;cursor:pointer;font-family:inherit;">
                <i class="fa-solid fa-trash"></i> <?= __('ausers.delete_user') ?>
            </button>
        </form>
    </div>
</div>

<div id="creditModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:1000;align-items:center;justify-content:center;"
     onclick="if(event.target===this)closeCreditModal()">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:20px;padding:28px;width:440px;max-width:94vw;animation:fadeSlideUp .25s ease;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:22px;">
            <div style="font-size:16px;font-weight:800;"><i class="fa-solid fa-coins" style="color:#fbc853;margin-right:8px;"></i><span id="creditModalTitle"><?= __('ausers.credit_send') ?></span></div>
            <button onclick="closeCreditModal()" style="background:none;border:none;color:var(--muted);font-size:18px;cursor:pointer;">&times;</button>
        </div>
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="send_credit" value="1">
            <input type="hidden" name="credit_user_id" id="creditUserId">
            <div style="margin-bottom:16px;">
                <label style="font-size:11px;font-weight:700;color:var(--muted);display:block;margin-bottom:6px;"><?= __('apurch.user') ?></label>
                <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;font-size:13px;font-weight:700;" id="creditUserName">—</div>
            </div>
            <div style="margin-bottom:16px;">
                <label style="font-size:11px;font-weight:700;color:var(--muted);display:block;margin-bottom:6px;"><?= __('ausers.amount_label') ?></label>
                <input type="number" name="credit_amount" id="creditAmount" min="1" step="0.01" required placeholder="<?= __('ausers.amount_ph') ?>"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:14px;font-weight:800;outline:none;">
            </div>
            <div style="margin-bottom:20px;">
                <label style="font-size:11px;font-weight:700;color:var(--muted);display:block;margin-bottom:6px;"><?= __('ausers.note_label') ?> <span style="font-weight:500;"><?= __('ausers.optional') ?></span></label>
                <textarea name="credit_note" id="creditNote" rows="2" placeholder="<?= __('ausers.note_ph') ?>"
                          style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;resize:vertical;font-family:inherit;"></textarea>
            </div>
            <div style="display:flex;gap:10px;">
                <button type="submit" class="btn-admin btn-primary-admin" style="flex:1;"><?= __('ausers.ok') ?></button>
                <button type="button" onclick="closeCreditModal()" class="btn-admin btn-ghost-admin" style="flex:1;"><?= __('support.cancel') ?></button>
            </div>
        </form>
    </div>
</div>

<script>
var _myRole = '<?= htmlspecialchars($myRole, ENT_QUOTES) ?>';
var _roleRank = <?= json_encode($roleRank, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
<?php
$_roleMeta = [];
foreach (array_keys($roleList) as $s) {
    $dd = role_display($adminDb, $s);
    $dd['is_url'] = (bool)preg_match('/^(\/|https?:|data:image\/)/i', $dd['icon']);
    $_roleMeta[$s] = $dd;
}
?>
var _roleMeta = <?= json_encode($_roleMeta, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
function _roleBadgeHtml(slug){
    var m = _roleMeta[slug] || {name: slug, color: '#4ade80', icon: 'fa-solid fa-user', is_url: false};
    function nxEsc(s){ return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
    var icon = m.is_url ? '<img src="' + nxEsc(m.icon).replace(/"/g,'') + '" style="width:12px;height:12px;object-fit:cover;border-radius:3px;" alt="">' : '<i class="' + nxEsc(m.icon) + '"></i>';
    return '<span class="badge" style="background:' + nxEsc(m.color) + '1f;color:' + nxEsc(m.color) + ';border:1px solid ' + nxEsc(m.color) + '55;">' + icon + ' ' + nxEsc(m.name) + '</span>';
}
function openUserModal(id,username,role){
    document.getElementById('modalUserId').value = id;
    document.getElementById('modalUsername').value = username;
    document.getElementById('modalRole').value = role;
    document.getElementById('modalDeleteId').value = id;
    document.getElementById('modalTitle').textContent = username + ' - ' + <?= json_encode(__('ausers.manage')) ?>;
    var protected = (_myRole !== 'admin' && _myRole !== 'superadmin') && ((_roleRank[role] ?? 0) >= (_roleRank[_myRole] ?? 0));
    if (!protected && _myRole !== 'superadmin' && role === 'superadmin') protected = true;
    var note = document.getElementById('modalProtectNote');
    if (note) note.style.display = protected ? 'block' : 'none';
    var usernameIn = document.getElementById('modalUsername');
    var roleSel = document.getElementById('modalRole');
    if (usernameIn) usernameIn.disabled = protected;
    if (roleSel) roleSel.disabled = protected;
    var saveBtn = document.querySelector('#userForm button[type="submit"]');
    if (saveBtn) saveBtn.disabled = protected;
    var delBtn = document.querySelector('#userModal form:last-of-type button[type="submit"]');
    if (delBtn) delBtn.disabled = protected;
    window._curCreditId = id;
    window._curCreditName = username;
    var creditBtn = document.getElementById('creditSendBtn');
    if (creditBtn) creditBtn.disabled = protected;
    document.getElementById('userModal').style.display = 'flex';
}
function closeUserModal(){
    document.getElementById('userModal').style.display = 'none';
}
function openCreditModal(){
    if (!window._curCreditId) return;
    document.getElementById('creditUserId').value = window._curCreditId;
    document.getElementById('creditUserName').textContent = window._curCreditName;
    document.getElementById('creditModalTitle').textContent = window._curCreditName + ' - ' + <?= json_encode(__('ausers.credit_send')) ?>;
    document.getElementById('creditAmount').value = '';
    document.getElementById('creditNote').value = '';
    document.getElementById('creditModal').style.display = 'flex';
}
function closeCreditModal(){
    document.getElementById('creditModal').style.display = 'none';
}
(function(){
    document.querySelectorAll('.user-row').forEach(function(row){
        row.addEventListener('click', function(){
            openUserModal(
                this.getAttribute('data-id'),
                this.getAttribute('data-username'),
                this.getAttribute('data-role')
            );
        });
    });
    var wrap = document.getElementById('userSearchWrap');
    var input = document.getElementById('userSearchInput');
    var icon = document.getElementById('userSearchIcon');
    if (!wrap || !input || !icon) return;
    var form = wrap.closest('form') || document.getElementById('userSearchForm');
    var openWidth = 260;
    if (input.value.trim() !== '') {
        input.style.width = openWidth + 'px';
        input.style.opacity = '1';
        input.style.paddingLeft = '36px';
        input.style.cursor = 'text';
        icon.style.color = 'var(--accent)';
    }
    function openSearch() {
        if (parseInt(input.style.width) > 50) return;
        input.style.width = openWidth + 'px';
        input.style.opacity = '1';
        input.style.paddingLeft = '36px';
        input.style.cursor = 'text';
        icon.style.color = 'var(--accent)';
        setTimeout(function(){ input.focus(); }, 350);
    }
    function closeSearch() {
        if (input.value.trim() !== '') return;
        input.style.width = '0';
        input.style.opacity = '0';
        input.style.paddingLeft = '0';
        input.style.cursor = 'pointer';
        icon.style.color = 'var(--muted)';
    }
    input.addEventListener('mouseenter', openSearch);
    input.addEventListener('focus', openSearch);
    input.addEventListener('blur', function(){
        setTimeout(closeSearch, 200);
    });
    var _searchTimer;
    var _lastQuery = '';
    input.addEventListener('input', function(){
        clearTimeout(_searchTimer);
        var q = input.value.trim();
        _searchTimer = setTimeout(function(){
            if (q === _lastQuery) return;
            _lastQuery = q;
            var url = '/admin/users.php?ajax=1' + (q ? '&q=' + encodeURIComponent(q) : '');
            fetch(url).then(function(r){ return r.json(); }).then(function(d){
                var tbody = document.querySelector('.admin-table tbody');
                if (!tbody || !d.ok) return;
                if (d.users.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:32px;">' + <?= json_encode(__('err.user_missing')) ?> + '</td></tr>';
                    document.querySelector('.admin-card-title span').textContent = '(0)';
                    return;
                }
                var html = '';
                d.users.forEach(function(u){
                    function nxEsc(s){ return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
                    var avatar = u.avatar || 'https://minotar.net/avatar/user.png';
                    var date = new Date(u.created_at).toLocaleDateString('tr-TR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'}) || u.created_at;
                    html += '<tr class="animate-row user-row" data-id="' + parseInt(u.id,10) + '" data-username="' + nxEsc(u.username) + '" data-role="' + nxEsc(u.role) + '" style="cursor:pointer;">';
                    html += '<td><div style="display:flex;align-items:center;gap:10px;"><img src="' + nxEsc(avatar) + '" style="width:32px;height:32px;border-radius:50%;image-rendering:pixelated;border:1.5px solid rgba(var(--accent-rgb),.3);" alt=""><div><div style="font-weight:700;font-size:13px;">' + nxEsc(u.username) + '</div><div style="font-size:11px;color:var(--muted);">ID #' + parseInt(u.id,10) + '</div></div></div></td>';
                    html += '<td class="u-hide-m" style="color:var(--muted);max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + nxEsc(u.email) + '</td>';
                    html += '<td>' + _roleBadgeHtml(u.role) + '</td>';
                    html += '<td class="u-hide-m" style="color:var(--muted);font-size:12px;white-space:nowrap;">' + date + '</td>';
                    html += '<td><button class="btn-admin btn-ghost-admin" style="padding:6px 12px;font-size:12px;pointer-events:none;"><i class="fa-solid fa-pen"></i> ' + <?= json_encode(__('ausers.manage')) ?> + '</button></td></tr>';
                });
                tbody.innerHTML = html;
                document.querySelector('.admin-card-title span').textContent = '(' + d.users.length + ')';
                document.querySelectorAll('.user-row').forEach(function(row){
                    row.addEventListener('click', function(){
                        openUserModal(this.getAttribute('data-id'), this.getAttribute('data-username'), this.getAttribute('data-role'));
                    });
                });
                if (q) {
                    var existing = document.querySelector('.admin-card-header a[href*="clear"]');
                    if (!existing) {
                        var link = document.createElement('a');
                        link.href = '/admin/users.php';
                        link.className = 'btn-admin btn-ghost-admin';
                        link.style.cssText = 'animation:fadeSlideUp .3s ease;margin-left:8px;flex-shrink:0;';
                        link.innerHTML = '<i class="fa-solid fa-xmark"></i> ' + <?= json_encode(__('apurch.clear')) ?>;
                        document.querySelector('.admin-card-header').appendChild(link);
                    }
                } else {
                    var el = document.querySelector('.admin-card-header a[href*="clear"]');
                    if (el) el.remove();
                }
            }).catch(function(){});
        }, 300);
    });
    input.addEventListener('keydown', function(e){
        if (e.key === 'Escape') {
            input.blur();
            closeSearch();
        }
    });
    icon.addEventListener('click', openSearch);
})();
</script>
<?php include __DIR__ . '/includes/layout-end.php'; ?>
