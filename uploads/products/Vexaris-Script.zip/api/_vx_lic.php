<?php
header('Content-Type: application/json; charset=utf-8');

define('NEXUS_BOOT', true);
define('ROOT_PATH', dirname(__DIR__));

require_once ROOT_PATH . '/core/db.php';
require_once ROOT_PATH . '/config/autoload.php';

$__d = strtolower(trim($_REQUEST['domain'] ?? $_SERVER['HTTP_HOST'] ?? ''));
$__t = (int)($_REQUEST['timestamp'] ?? 0);
$__n = strtolower(trim($_REQUEST['nonce'] ?? ''));
$__s = (string)($_REQUEST['signature'] ?? '');
if ($__d === '' || $__t <= 0 || $__n === '' || $__s === '' || !preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $__d)) { http_response_code(403); echo json_encode(['valid'=>false,'status'=>'bad_signature']); exit; }
if (abs(time() - $__t) > 300 || !preg_match('/^[a-f0-9]{16,64}$/', $__n)) { http_response_code(400); echo json_encode(['valid'=>false,'status'=>'bad_request']); exit; }
$exp = hash_hmac('sha256', $__d.'|'.$__t.'|'.$__n, _vx_k());
if (!hash_equals($exp, $__s)) { http_response_code(403); echo json_encode(['valid'=>false,'status'=>'bad_signature']); exit; }
try { $chk=$db??nexus_db(); if($chk){ $st=$chk->prepare("SELECT id FROM license_nonces WHERE nonce=?"); $st->execute([$__n]); if($st->fetch()){http_response_code(400); echo json_encode(['valid'=>false,'status'=>'nonce_used']); exit;} $chk->prepare("INSERT INTO license_nonces (nonce) VALUES (?)")->execute([$__n]); } } catch(Throwable $e){}

$key = trim($_REQUEST['key'] ?? '');
$ip  = $_SERVER['REMOTE_ADDR'] ?? '';

if (!$key) {
    http_response_code(400);
    echo json_encode(['valid'=>false,'status'=>'missing_key','message'=>'Lisans anahtarı gerekli.']);
    exit;
}

if (strlen($key) > 128) {
    http_response_code(400);
    echo json_encode(['valid'=>false,'status'=>'invalid_key','message'=>'Geçersiz anahtar.']);
    exit;
}

$db = nexus_db();
if (!$db) {
    http_response_code(503);
    echo json_encode(['valid'=>false,'status'=>'db_error','message'=>'Servis geçici olarak kullanılamıyor.']);
    exit;
}

$rlCount = 0;
if ($ip !== '') {
    $rlStmt = $db->prepare('SELECT COUNT(*) FROM license_check_attempts WHERE ip=? AND attempted_at > DATE_SUB(NOW(), INTERVAL 60 MINUTE)');
    $rlStmt->execute([$ip]);
    $rlCount = (int)$rlStmt->fetchColumn();
    if ($rlCount >= 120) {
        http_response_code(429);
        echo json_encode(['valid'=>false,'status'=>'rate_limited','message'=>'Çok fazla deneme. Lütfen bekleyin.']);
        exit;
    }
    try { $db->prepare('INSERT INTO license_check_attempts (ip) VALUES (?)')->execute([$ip]); } catch (\Throwable $e) {}
}

$res = _vx_q($db, $key, $ip, true);
if ($res === null) {
    echo json_encode(['valid'=>false,'status'=>'not_found','message'=>'Lisans bulunamadı.']);
    exit;
}
if (($res['valid'] ?? false) === false) {
    $msg = match($res['status'] ?? '') {
        'expired' => 'Lisans süresi dolmuş.',
        'suspended' => 'Lisans askıya alınmış.',
        'ip_mismatch' => 'Bu lisans farklı bir sunucuya kayıtlı.',
        default => 'Lisans geçersiz.'
    };
    echo json_encode(['valid'=>false,'status'=>$res['status'],'message'=>$msg]);
    exit;
}
echo json_encode([
    'valid'      => true,
    'status'     => 'active',
    'product'    => $res['product'] ?? '',
    'version'    => $res['version'] ?? '',
    'category'   => $res['category'] ?? '',
    'expires_at' => $res['expires_at'] ?? null,
    'message'    => 'Lisans geçerli.',
]);
exit;
