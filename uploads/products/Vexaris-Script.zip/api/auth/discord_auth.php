<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH') or define('ROOT_PATH', __DIR__ . '/../..');
require_once ROOT_PATH . '/core/init.php';
require_once __DIR__ . '/oauth_base.php';

$db = nexus_db();
$c = oauth_config($db, 'discord');
$clientId = $c['client_id'];
$clientSecret = $c['client_secret'];
$redirectUri = $c['redirect_uri'];
$isConnect = ($_GET['connect'] ?? '') === '1';

if (isset($_GET['error'])) {
    header('Location: /login?flash=' . urlencode('error:Giriş iptal edildi.'));
    exit;
}

if (isset($_GET['code'])) {
    $verified = oauth_verify_state('discord');
    if ($verified === null) {
        header('Location: /login?flash=' . urlencode('error:Güvenlik doğrulaması başarısız. Lütfen tekrar deneyin.'));
        exit;
    }
    $isConnect = $verified;

    $tokenRes = oauth_token_exchange('https://discord.com/api/oauth2/token', [
        'client_id' => $clientId,
        'client_secret' => $clientSecret,
        'grant_type' => 'authorization_code',
        'code' => $_GET['code'],
        'redirect_uri' => $redirectUri,
    ], ['Content-Type: application/x-www-form-urlencoded']);

    if (!isset($tokenRes['access_token'])) {
        header('Location: /login?flash=' . urlencode('error:Token alınamadı.'));
        exit;
    }

    $userRes = oauth_api_get('https://discord.com/api/users/@me', $tokenRes['access_token']);

    if (!isset($userRes['id'])) {
        header('Location: /login?flash=' . urlencode('error:Kullanıcı bilgisi alınamadı.'));
        exit;
    }

    $discordId = $userRes['id'];
    $email = $userRes['email'] ?? '';
    $username = $userRes['username'] ?? 'discord_' . substr($discordId, 0, 8);
    $avatar = $userRes['avatar']
        ? 'https://cdn.discordapp.com/avatars/' . $discordId . '/' . $userRes['avatar'] . '.png'
        : '';

    oauth_process_user($db, [
        'provider' => 'discord',
        'label'    => 'Discord',
        'is_connect' => $isConnect,
        'id'       => $discordId,
        'email'    => $email,
        'name'     => $username,
        'avatar'   => $avatar,
    ]);
}

$rlIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
if (!rate_limit_allow($db, 'oauth_init', $rlIp, 30, 10)) { header('Location: /login?flash=' . urlencode('error:Çok fazla deneme. Lütfen bekleyin.')); exit; }
rate_limit_hit($db, 'oauth_init', $rlIp);
$state = oauth_begin_state('discord', $isConnect);
$params = http_build_query([
    'client_id' => $clientId,
    'redirect_uri' => $redirectUri,
    'response_type' => 'code',
    'scope' => 'identify email',
    'state' => $state,
]);
header('Location: https://discord.com/api/oauth2/authorize?' . $params);
exit;