<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH') or define('ROOT_PATH', __DIR__ . '/../..');
require_once ROOT_PATH . '/core/init.php';
require_once __DIR__ . '/oauth_base.php';

$db = nexus_db();
$c = oauth_config($db, 'github');
$clientId = $c['client_id'];
$clientSecret = $c['client_secret'];
$redirectUri = $c['redirect_uri'];
$isConnect = ($_GET['connect'] ?? '') === '1';

if (isset($_GET['error'])) {
    header('Location: /login?flash=' . urlencode('error:Giriş iptal edildi.'));
    exit;
}

if (isset($_GET['code'])) {
    $verified = oauth_verify_state('github');
    if ($verified === null) {
        header('Location: /login?flash=' . urlencode('error:Güvenlik doğrulaması başarısız. Lütfen tekrar deneyin.'));
        exit;
    }
    $isConnect = $verified;

    $tokenRes = oauth_token_exchange('https://github.com/login/oauth/access_token', [
        'client_id' => $clientId,
        'client_secret' => $clientSecret,
        'code' => $_GET['code'],
        'redirect_uri' => $redirectUri,
    ], ['Accept: application/json']);

    if (!isset($tokenRes['access_token'])) {
        header('Location: /login?flash=' . urlencode('error:Token alınamadı.'));
        exit;
    }

    $ghHeaders = ['Accept: application/vnd.github+json', 'User-Agent: Nexus'];
    $userRes = oauth_api_get('https://api.github.com/user', $tokenRes['access_token'], $ghHeaders);

    if (!isset($userRes['id'])) {
        header('Location: /login?flash=' . urlencode('error:Kullanıcı bilgisi alınamadı.'));
        exit;
    }

    $githubId = (string)$userRes['id'];
    $email = $userRes['email'] ?? '';
    if (empty($email)) {
        $emailRes = oauth_api_get('https://api.github.com/user/emails', $tokenRes['access_token'], $ghHeaders);
        foreach ($emailRes as $em) {
            if (!empty($em['email']) && !empty($em['primary'])) { $email = $em['email']; break; }
        }
    }
    $name = $userRes['name'] ?? '';
    $uname = trim($userRes['login'] ?? '') ?: ($name ?: 'github_' . substr($githubId, 0, 8));
    $avatar = $userRes['avatar_url'] ?? '';
    $emailFallback = $email ?: ('github_' . $githubId . '@users.noreply.github.com');

    oauth_process_user($db, [
        'provider' => 'github',
        'label'    => 'GitHub',
        'is_connect' => $isConnect,
        'id'       => $githubId,
        'email'    => $emailFallback,
        'name'     => $uname,
        'avatar'   => $avatar,
    ]);
}

$rlIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
if (!rate_limit_allow($db, 'oauth_init', $rlIp, 30, 10)) { header('Location: /login?flash=' . urlencode('error:Çok fazla deneme. Lütfen bekleyin.')); exit; }
rate_limit_hit($db, 'oauth_init', $rlIp);
$state = oauth_begin_state('github', $isConnect);
$params = http_build_query([
    'client_id' => $clientId,
    'redirect_uri' => $redirectUri,
    'response_type' => 'code',
    'scope' => 'read:user user:email',
    'state' => $state,
]);
header('Location: https://github.com/login/oauth/authorize?' . $params);
exit;