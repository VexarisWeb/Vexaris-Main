<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH') or define('ROOT_PATH', __DIR__ . '/../..');
require_once ROOT_PATH . '/core/init.php';
require_once __DIR__ . '/oauth_base.php';

$db = nexus_db();
$c = oauth_config($db, 'google');
$clientId = $c['client_id'];
$clientSecret = $c['client_secret'];
$redirectUri = $c['redirect_uri'];
$isConnect = ($_GET['connect'] ?? '') === '1';

if (isset($_GET['error'])) {
    header('Location: /login?flash=' . urlencode('error:Giriş iptal edildi.'));
    exit;
}

if (isset($_GET['code'])) {
    $verified = oauth_verify_state('google');
    if ($verified === null) {
        header('Location: /login?flash=' . urlencode('error:Güvenlik doğrulaması başarısız. Lütfen tekrar deneyin.'));
        exit;
    }
    $isConnect = $verified;

    $tokenRes = oauth_token_exchange('https://oauth2.googleapis.com/token', [
        'code' => $_GET['code'],
        'client_id' => $clientId,
        'client_secret' => $clientSecret,
        'redirect_uri' => $redirectUri,
        'grant_type' => 'authorization_code',
    ]);

    if (!isset($tokenRes['access_token'])) {
        header('Location: /login?flash=' . urlencode('error:Token alınamadı.'));
        exit;
    }

    $userRes = oauth_api_get('https://www.googleapis.com/oauth2/v2/userinfo', $tokenRes['access_token']);

    if (!isset($userRes['id'])) {
        header('Location: /login?flash=' . urlencode('error:Kullanıcı bilgisi alınamadı.'));
        exit;
    }

    $googleId = $userRes['id'];
    $email = $userRes['email'] ?? '';
    $name = $userRes['name'] ?? $userRes['email'] ?? 'google_' . substr($googleId, 0, 8);
    $picture = $userRes['picture'] ?? '';

    oauth_process_user($db, [
        'provider' => 'google',
        'label'    => 'Google',
        'is_connect' => $isConnect,
        'id'       => $googleId,
        'email'    => $email,
        'name'     => $name,
        'avatar'   => $picture,
    ]);
}

$rlIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
if (!rate_limit_allow($db, 'oauth_init', $rlIp, 30, 10)) { header('Location: /login?flash=' . urlencode('error:Çok fazla deneme. Lütfen bekleyin.')); exit; }
rate_limit_hit($db, 'oauth_init', $rlIp);
$state = oauth_begin_state('google', $isConnect);
$params = http_build_query([
    'client_id' => $clientId,
    'redirect_uri' => $redirectUri,
    'response_type' => 'code',
    'scope' => 'openid email profile',
    'access_type' => 'online',
    'state' => $state,
]);
header('Location: https://accounts.google.com/o/oauth2/v2/auth?' . $params);
exit;