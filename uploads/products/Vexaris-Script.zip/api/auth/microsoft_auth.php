<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH') or define('ROOT_PATH', __DIR__ . '/../..');
require_once ROOT_PATH . '/core/init.php';
require_once __DIR__ . '/oauth_base.php';

$db = nexus_db();
$c = oauth_config($db, 'microsoft');
$clientId = $c['client_id'];
$clientSecret = $c['client_secret'];
$redirectUri = $c['redirect_uri'];
$isConnect = ($_GET['connect'] ?? '') === '1';

if (isset($_GET['error'])) {
    header('Location: /login?flash=' . urlencode('error:Giriş iptal edildi.'));
    exit;
}

if (isset($_GET['code'])) {
    $verified = oauth_verify_state('microsoft');
    if ($verified === null) {
        header('Location: /login?flash=' . urlencode('error:Güvenlik doğrulaması başarısız. Lütfen tekrar deneyin.'));
        exit;
    }
    $isConnect = $verified;

    $tokenRes = oauth_token_exchange('https://login.microsoftonline.com/common/oauth2/v2.0/token', [
        'client_id' => $clientId,
        'client_secret' => $clientSecret,
        'code' => $_GET['code'],
        'redirect_uri' => $redirectUri,
        'grant_type' => 'authorization_code',
    ]);

    if (!isset($tokenRes['access_token'])) {
        header('Location: /login?flash=' . urlencode('error:Token alınamadı.'));
        exit;
    }

    $userRes = oauth_api_get('https://graph.microsoft.com/v1.0/me', $tokenRes['access_token']);

    if (!isset($userRes['id'])) {
        header('Location: /login?flash=' . urlencode('error:Kullanıcı bilgisi alınamadı.'));
        exit;
    }

    $msId = $userRes['id'];
    $email = $userRes['mail'] ?? $userRes['userPrincipalName'] ?? '';
    $displayName = $userRes['displayName'] ?? $userRes['userPrincipalName'] ?? 'microsoft_' . substr($msId, 0, 8);

    $avatar = '';
    $photoBin = oauth_api_raw('https://graph.microsoft.com/v1.0/me/photo/$value', $tokenRes['access_token']);
    if ($photoBin) {
        $dir = ROOT_PATH . '/uploads/avatars/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $fname = 'ms_' . bin2hex(random_bytes(12)) . '.jpg';
        if (file_put_contents($dir . $fname, $photoBin)) {
            $avatar = '/uploads/avatars/' . $fname;
        }
    }

    $uname = preg_replace('/[^a-zA-Z0-9_]/', '_', $displayName);
    $uname = substr($uname, 0, 28);
    if (empty($uname)) $uname = 'msft_' . substr($msId, 0, 8);

    oauth_process_user($db, [
        'provider' => 'microsoft',
        'label'    => 'Microsoft',
        'is_connect' => $isConnect,
        'id'       => $msId,
        'email'    => $email,
        'name'     => $uname,
        'avatar'   => $avatar,
    ]);
}

$rlIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
if (!rate_limit_allow($db, 'oauth_init', $rlIp, 30, 10)) { header('Location: /login?flash=' . urlencode('error:Çok fazla deneme. Lütfen bekleyin.')); exit; }
rate_limit_hit($db, 'oauth_init', $rlIp);
$state = oauth_begin_state('microsoft', $isConnect);
$params = http_build_query([
    'client_id' => $clientId,
    'redirect_uri' => $redirectUri,
    'response_type' => 'code',
    'scope' => 'openid email profile User.Read',
    'state' => $state,
]);
header('Location: https://login.microsoftonline.com/common/oauth2/v2.0/authorize?' . $params);
exit;