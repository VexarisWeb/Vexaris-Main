<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH') or define('ROOT_PATH', __DIR__ . '/../..');
require_once ROOT_PATH . '/core/init.php';

if (!function_exists('oauth_load_config')) {
    function oauth_load_config(PDO $db, string $prefix): array
    {
        $st = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE " . $db->quote($prefix . '%'));
        $cfg = [];
        while ($r = $st->fetch()) $cfg[$r['key']] = $r['value'];
        return $cfg;
    }
}

if (!function_exists('oauth_redirect_uri')) {
    function oauth_redirect_uri(string $provider): string
    {
        // The OAuth callback is the auth endpoint itself. The previous /callback suffix
        // did not map to a real PHP route and caused a final 404 after provider login.
        try {
            $db = function_exists('nexus_db') ? nexus_db() : null;
            if ($db) {
                $st = $db->prepare("SELECT value FROM settings WHERE `key` IN ('site_url','base_url','public_url') AND TRIM(value)<>'' ORDER BY FIELD(`key`,'site_url','base_url','public_url') LIMIT 1");
                $st->execute();
                $base = trim((string)($st->fetchColumn() ?? ''));
                if (strpos($base, '://') === false) $base = 'https://' . $base;
                if ($base !== '' && $base !== 'https://') return rtrim($base, '/') . '/api/auth/' . $provider . '_auth';
            }
        } catch (Throwable $e) {}
        $fwdProto = strtolower(trim((string)(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0] ?? '')));
        if ($fwdProto !== 'http' && $fwdProto !== 'https') $fwdProto = '';
        $proto = $fwdProto !== '' ? $fwdProto : (((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http'));
        $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
        if (!preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) $host = 'localhost';
        return rtrim($proto . '://' . $host, '/') . '/api/auth/' . $provider . '_auth';
    }
}

if (!function_exists('oauth_config')) {
    function oauth_config(PDO $db, string $provider): array
    {
        $prefix = 'int_' . $provider . '_auth_';
        try {
            $cfg = oauth_load_config($db, $prefix);
        } catch (\PDOException $e) {
            error_log('[NS] ' . $provider . '_auth: ' . $e->getMessage());
            header('Location: /login?flash=' . urlencode('error:Başlatma hatası.'));
            exit;
        }
        $clientId = $cfg[$prefix . 'client_id'] ?? '';
        $clientSecret = $cfg[$prefix . 'client_secret'] ?? '';
        $enabled = ($cfg[$prefix . 'enabled'] ?? '0') === '1';
        if (!$enabled || empty($clientId) || empty($clientSecret)) {
            header('Location: /login?flash=' . urlencode('error:Giriş yapılandırılmamış.'));
            exit;
        }
        return [
            'client_id'     => $clientId,
            'client_secret' => $clientSecret,
            'redirect_uri'  => oauth_redirect_uri($provider),
        ];
    }
}

if (!function_exists('oauth_verify_state')) {
    function oauth_verify_state(string $provider): ?bool
    {
        $expected = $_SESSION['oauth_state'] ?? '';
        $prov = $_SESSION['oauth_provider'] ?? '';
        if (empty($expected) || $prov !== $provider || !hash_equals($expected, $_GET['state'] ?? '')) {
            return null;
        }
        $isConnect = ($_SESSION['oauth_connect'] ?? false) === true;
        unset($_SESSION['oauth_state'], $_SESSION['oauth_provider'], $_SESSION['oauth_connect']);
        return $isConnect;
    }
}

if (!function_exists('oauth_begin_state')) {
    function oauth_begin_state(string $provider, bool $isConnect): string
    {
        $state = bin2hex(random_bytes(16));
        $_SESSION['oauth_state'] = $state;
        $_SESSION['oauth_provider'] = $provider;
        $_SESSION['oauth_connect'] = $isConnect;
        return $state;
    }
}

if (!function_exists('oauth_token_exchange')) {
    function oauth_token_exchange(string $url, array $fields, array $headers = []): array
    {
        $opts = [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($fields),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
        ];
        if ($headers) $opts[CURLOPT_HTTPHEADER] = $headers;
        $ch = curl_init($url);
        curl_setopt_array($ch, $opts);
        $res = json_decode(curl_exec($ch), true);
        curl_close($ch);
        return is_array($res) ? $res : [];
    }
}

if (!function_exists('oauth_api_get')) {
    function oauth_api_get(string $url, string $token, array $headers = []): array
    {
        $headers[] = 'Authorization: Bearer ' . $token;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
        ]);
        $res = json_decode(curl_exec($ch), true);
        curl_close($ch);
        return is_array($res) ? $res : [];
    }
}

if (!function_exists('oauth_api_raw')) {
    function oauth_api_raw(string $url, string $token, array $headers = []): ?string
    {
        $headers[] = 'Authorization: Bearer ' . $token;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        return is_string($res) && $res !== '' ? $res : null;
    }
}

if (!function_exists('oauth_process_user')) {
    function oauth_process_user(PDO $db, array $p): void
    {
        $provider = (string)$p['provider'];
        $label    = (string)$p['label'];
        $connect  = !empty($p['is_connect']);
        $pid      = (string)$p['id'];
        $email    = (string)($p['email'] ?? '');
        $uname    = (string)($p['name'] ?? '');
        $avatar   = (string)($p['avatar'] ?? '');
        $providers = ['discord','google','github','microsoft'];
        if (!in_array($provider, $providers, true)) {
            header('Location: /login?flash=' . urlencode('error:Desteklenmeyen giriş yöntemi.'));
            exit;
        }
        $col      = 'oauth_' . $provider . '_id';

        $st = $db->prepare("SELECT id FROM users WHERE $col=? LIMIT 1");
        $st->execute([$pid]);
        $existing = $st->fetch();

        if ($existing) {
            if ($connect) {
                header('Location: /user/connections?flash=' . urlencode("error:Bağlamak istediğiniz $label hesabı zaten başka bir kullanıcıya bağlı."));
                exit;
            }
            auth_login_by_id($existing['id']);
            header('Location: /');
            exit;
        }

        if ($connect) {
            auth_require('/login');
            $cur = auth_user();
            $st = $db->prepare("SELECT id FROM users WHERE $col=? AND id!=? LIMIT 1");
            $st->execute([$pid, $cur['id']]);
            if ($st->fetch()) {
                header('Location: /user/connections?flash=' . urlencode("error:Bağlamak istediğiniz $label hesabı zaten başka bir kullanıcıya bağlı."));
                exit;
            }
            if (!empty($email)) {
                $st = $db->prepare("SELECT id FROM users WHERE email=? AND id!=? LIMIT 1");
                $st->execute([$email, $cur['id']]);
                if ($st->fetch()) {
                    header('Location: /user/connections?flash=' . urlencode('error:Bu e-posta başka bir kullanıcıya ait. Önce e-postayı değiştirin.'));
                    exit;
                }
            }
            $newAvatar = $avatar ?: $cur['avatar'];
            $db->prepare("UPDATE users SET $col=?,avatar=? WHERE id=?")->execute([$pid, $newAvatar, $cur['id']]);
            $_SESSION['user']['avatar'] = $newAvatar;
            header('Location: /user/connections?flash=' . urlencode("success:$label hesabınız bağlandı."));
            exit;
        }

        if (!empty($email)) {
            $st = $db->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
            $st->execute([$email]);
            $emailUser = $st->fetch();
            if ($emailUser) {
                header('Location: /login?flash=' . urlencode("error:Bu e-posta ile kayıtlı bir hesap var. Giriş yapıp Bağlantılar bölümünden $label hesabını bağlayabilirsin."));
                exit;
            }
        }

        if (empty($email)) {
            $email = $provider . '_' . $pid . '@noreply.invalid';
        }

        $st = $db->prepare("SELECT COUNT(*) FROM users WHERE username=?");
        $st->execute([$uname]);
        if ((int)$st->fetchColumn() > 0) $uname .= '_' . substr($pid, 0, 6);

        $st = $db->prepare("SELECT COUNT(*) FROM users WHERE username=?");
        $st->execute([$uname]);
        if ((int)$st->fetchColumn() > 0) $uname = 'user_' . substr($pid, 0, 8);

        $uname = mb_substr(trim($uname), 0, 32);
        if ($uname === '') $uname = $provider . '_' . substr($pid, 0, 8);

        try {
            $db->prepare("INSERT INTO users (username,email,password,avatar,$col,role,balance,created_at) VALUES (?,?,'',?,?,'user',0,NOW())")->execute([$uname, $email, $avatar, $pid]);
            $newId = $db->lastInsertId();
        } catch (\PDOException $e) {
            error_log('[NS] oauth register: ' . $e->getMessage());
            header('Location: /login?flash=' . urlencode('error:Kayıt oluşturulamadı. Lütfen tekrar deneyin.'));
            exit;
        }
        require_once ROOT_PATH . '/core/discord.php';
        discord_notify($db, 'register', '👤 Yeni Kayıt', __('bsupp.oauth_reg_body', ['label' => $label]), [
            'Kullanıcı adı' => $uname,
            'E-posta'      => $email,
        ], '15844338');
        auth_login_by_id($newId);
        header('Location: /');
        exit;
    }
}