<?php
require_once __DIR__ . '/_vx_lic.php';
