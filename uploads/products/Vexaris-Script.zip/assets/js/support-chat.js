function SupportChatInit(cfg){
  function G(id){ return document.getElementById(id); }
  var box = G(cfg.boxId) || (cfg.boxAlt ? document.querySelector(cfg.boxAlt) : null);
  var form = G(cfg.formId);
  if (!box || !form) return;
  var tid = form.getAttribute('data-tid');
  var csrfInput = form.querySelector('input[name="_csrf_token"]');
  if (!tid) return;
  var input = G(cfg.inputId), sendBtn = G(cfg.sendBtnId), count = G(cfg.countId);
  var fileBtn = G(cfg.fileBtnId), fileInput = G(cfg.fileInputId);
  var preview = G(cfg.previewId), previewImg = G(cfg.previewImgId), previewX = G(cfg.previewXId);
  function esc(s){ return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function maxRid(){
    var m = 0;
    box.querySelectorAll('[data-rid]').forEach(function(el){
      var v = parseInt(el.getAttribute('data-rid'), 10);
      if (v > m) m = v;
    });
    return m;
  }
  function tidyTicks(){
    var ticks = box.querySelectorAll('[data-tick],[data-tick-init]');
    for (var i = 0; i + 1 < ticks.length; i++) { ticks[i].style.display = 'none'; }
  }
  function popTick(t){ t.classList.remove('tick-pop'); void t.offsetWidth; t.classList.add('tick-pop'); }
  function markSeen(ids){
    if (!ids || !ids.length) return;
    ids.forEach(function(id){
      var t = box.querySelector('[data-tick="' + id + '"]');
      if (t && !t.classList.contains('tick-seen')) {
        t.textContent = ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.seen)||'✓✓ Görüldü');
        t.classList.add('tick-seen');
        popTick(t);
      }
    });
    var init = box.querySelector('[data-tick-init]');
    if (init && ids.length && !init.classList.contains('tick-seen')) {
      init.textContent = ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.seen)||'✓✓ Görüldü');
      init.classList.add('tick-seen');
      popTick(init);
      init.setAttribute('data-tick-init', 'seen');
    }
    tidyTicks();
  }
  function imgHtml(src){
    if (!src) return '';
    return '<a href="' + esc(src) + '" target="_blank" rel="noopener"><img src="' + esc(src) + '" class="nx-chat-img" alt="" loading="lazy"></a>';
  }
  function refreshCount(){
    if (!input || !count || !sendBtn) return;
    var n = input.value.length;
    count.textContent = n + '/500';
    sendBtn.classList.toggle('is-idle', n === 0 && !(fileInput && fileInput.files.length));
  }
  if (input) input.addEventListener('input', refreshCount);
  if (fileBtn && fileInput) fileBtn.addEventListener('click', function(){ fileInput.click(); });
  if (fileInput) fileInput.addEventListener('change', function(){
    var f = fileInput.files[0];
    if (!f) return;
    if (!/^(image\/png|image\/jpeg|image\/webp)$/.test(f.type) || f.size > 5242880) { fileInput.value = ''; return; }
    if (previewImg) previewImg.src = URL.createObjectURL(f);
    if (preview) preview.classList.remove('hidden');
    refreshCount();
  });
  if (previewX) previewX.addEventListener('click', function(){
    if (fileInput) fileInput.value = '';
    if (preview) preview.classList.add('hidden');
    refreshCount();
  });
  var H = { esc:esc, img:imgHtml, admin:function(m){ return cfg.adminHead(esc, m); } };
  form.addEventListener('submit', function(e){
    e.preventDefault();
    var txt = input.value.trim().slice(0, 500);
    var hasFile = fileInput && fileInput.files.length > 0;
    if (txt === '' && !hasFile) return;
    sendBtn.classList.add('nx-send-fly');
    setTimeout(function(){ sendBtn.classList.remove('nx-send-fly'); }, 400);
    var div = document.createElement('div');
    div.className = cfg.bubbleMine;
    div.innerHTML = cfg.optimistic(H, hasFile ? URL.createObjectURL(fileInput.files[0]) : '', txt);
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
    var fd = new FormData();
    fd.append('action', 'ticket_reply');
    fd.append('ticket_id', tid);
    fd.append('message', txt);
    if (hasFile) fd.append('image', fileInput.files[0]);
    fd.append('is_fetch', '1');
    if (csrfInput) fd.append('_csrf_token', csrfInput.value);
    input.value = '';
    if (fileInput) fileInput.value = '';
    if (preview) preview.classList.add('hidden');
    refreshCount();
    fetch('/action.php', {method:'POST', body:fd, headers:{'Accept':'application/json'}}).then(function(r){ return r.json(); }).then(function(d){
      if (!d || !d.ok) {
        div.style.opacity = '.55';
        if (d && d.msg && cfg.onError) cfg.onError(d.msg);
        return;
      }
      if (d.id) div.setAttribute('data-rid', d.id);
      if (d.id) box.querySelectorAll('[data-rid="' + d.id + '"]').forEach(function(o){ if (o !== div) o.remove(); });
      var ticks = document.createElement(cfg.tickTag);
      ticks.className = cfg.tickClass;
      if (d.id) ticks.setAttribute('data-tick', d.id);
      ticks.textContent = '✓';
      div.appendChild(ticks);
      tidyTicks();
      if (d.image) {
        var a = div.querySelector('a');
        if (a) a.href = d.image;
        var im = div.querySelector('img.nx-chat-img');
        if (im) im.src = d.image;
      }
      var meta = div.querySelector(cfg.metaSelect);
      if (meta && d.created) {
        if (cfg.metaDoneHtml) meta.innerHTML = cfg.metaDone(d.created);
        else meta.textContent = cfg.metaDone(d.created);
      }
    }).catch(function(){ div.style.opacity = '.55'; });
  });
  function poll(){
    if (document.hidden) { schedule(4000); return; }
    var fd = new FormData();
    fd.append('action', 'ticket_poll');
    fd.append('ticket_id', tid);
    fd.append('after_id', maxRid());
    fd.append('viewing', '1');
    if (csrfInput) fd.append('_csrf_token', csrfInput.value);
    fetch('/action.php', {method:'POST', body:fd, headers:{'Accept':'application/json'}}).then(function(r){ return r.json(); }).then(function(d){
      if (!d || !d.ok) { schedule(4000); return; }
      markSeen(d.seen_ids);
      if (!d.closed) {
        (d.replies || []).forEach(function(m){
          if (box.querySelector('[data-rid="' + m.id + '"]')) return;
          var div = document.createElement('div');
          var r = cfg.polled(H, m);
          div.className = r.cls;
          div.setAttribute('data-rid', m.id);
          div.innerHTML = r.html;
          var nearBottom = (box.scrollHeight - box.scrollTop - box.clientHeight) < 120;
          box.appendChild(div);
          if (nearBottom) box.scrollTop = box.scrollHeight;
        });
      }
      if ((d.replies || []).length >= 50) { schedule(300); return; }
      tidyTicks();
      schedule(2000);
    }).catch(function(){ schedule(5000); });
  }
  function schedule(ms){ setTimeout(poll, ms); }
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) poll(); });
  schedule(2000);
  tidyTicks();
  refreshCount();
}
