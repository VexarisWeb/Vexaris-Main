<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/bitpay.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); echo 'Error'; exit; }
license_gate_require('core', 503);

$isWebhook = (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST');

if ($isWebhook) {
    $rawBody   = file_get_contents('php://input');
    $signature = trim((string)($_SERVER['HTTP_X_SIGNATURE'] ?? ''));
    $eventName = trim((string)($_SERVER['HTTP_X_EVENT_NAME'] ?? ''));

    if (!bitpay_verify_webhook(bitpay_token($db), $signature, $rawBody)) {
        http_response_code(401);
        echo 'Invalid signature';
        exit;
    }

    $payload = json_decode($rawBody, true);
    if (!is_array($payload)) {
        http_response_code(400);
        echo 'Invalid payload';
        exit;
    }

    $data = $payload['data'] ?? [];
    if (!is_array($data)) $data = [];

    if ($eventName === '' && is_array($payload['event'] ?? null)) {
        $eventName = (string)($payload['event']['name'] ?? '');
    }

    $orderId = (string)($data['orderId'] ?? '');
    $invoiceId = (string)($data['id'] ?? '');
    if ($orderId === '' && $invoiceId === '') {
        http_response_code(400);
        echo 'Missing order';
        exit;
    }

    try {
        if (!in_array($eventName, ['invoice_confirmed', 'invoice_completed', 'invoice_paidInFull'], true)) {
            if ($eventName === 'invoice_expired') {
                $piExp = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
                $piExp->execute([$orderId]);
                $expIntent = $piExp->fetch();
                if ($expIntent && $expIntent['status'] === 'pending') {
                    $db->prepare("UPDATE payment_intents SET status='failed' WHERE id=?")->execute([$expIntent['id']]);
                }
            }
            http_response_code(200);
            echo 'Ignored';
            exit;
        }

        $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
        $piStmt->execute([$orderId]);
        $intent = $piStmt->fetch();

        if (!$intent) {
            $piStmt2 = $db->prepare("SELECT * FROM payment_intents WHERE payment_id=? LIMIT 1");
            $piStmt2->execute([substr($invoiceId, 0, 40)]);
            $intent = $piStmt2->fetch();
        }

        if (!$intent || $intent['status'] === 'completed') {
            http_response_code(200);
            echo 'OK';
            exit;
        }

        $expected = round((float)$intent['total_amount'], 2);
        $paid     = (float)($data['price'] ?? $expected);
        if (abs($paid - $expected) > 0.01) {
            error_log("[bitpay] Webhook tutar uyuşmazlığı: oid={$orderId} beklenen={$expected} gelen={$paid}");
            http_response_code(200);
            echo 'Mismatch';
            exit;
        }

        $payCur = strtoupper((string)($data['currency'] ?? ''));
        if ($payCur !== '' && $payCur !== strtoupper((string)$intent['currency'])) {
            error_log("[bitpay] Webhook para birimi uyuşmazlığı: oid={$orderId} beklenen={$intent['currency']} gelen={$payCur}");
            http_response_code(200);
            echo 'Mismatch';
            exit;
        }

        if (strncmp($orderId, 'TOPUP-', 6) !== 0) {
            require_once ROOT_PATH . '/core/purchase.php';
            [$snapItems] = purchase_items_for_intent($db, (int)$intent['user_id'], $intent);
            if (empty($snapItems)) {
                $cartChk = $db->prepare('SELECT id FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active" LIMIT 1');
                $cartChk->execute([(int)$intent['user_id']]);
                if (!$cartChk->fetch()) {
                    error_log("[bitpay] Teslim edilecek ürün bulunamadı, teslimat ertelendi: oid={$orderId}");
                    http_response_code(500);
                    echo 'Error';
                    exit;
                }
            }
        }

        $db->beginTransaction();
        try {
            $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
            $lock->execute([$intent['id']]);
            $locked = $lock->fetch();
            if (!$locked || $locked['status'] === 'completed') { $db->commit(); http_response_code(200); echo 'OK'; exit; }

            bitpay_complete_intent($db, $intent);
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            error_log('[bitpay] Webhook işlem hatası: ' . $e->getMessage());
            http_response_code(500);
            echo 'Error';
            exit;
        }

        http_response_code(200);
        echo 'OK';
    } catch (\Throwable $e) {
        error_log('[bitpay] Webhook hatası: ' . $e->getMessage());
        http_response_code(500);
        echo 'Error';
    }
    exit;
}

try {
    $orderId = trim((string)($_GET['order_id'] ?? ''));
    if ($orderId === '') {
        error_log('[bitpay] Sipariş eksik.');
        header('Location: /payment/cancel', true, 302);
        exit;
    }

    $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
    $piStmt->execute([$orderId]);
    $intent = $piStmt->fetch();

    if (!$intent) {
        error_log("[bitpay] Sipariş bulunamadı: {$orderId}");
        header('Location: /payment/cancel', true, 302);
        exit;
    }

    if ($intent['status'] === 'completed') {
        header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
        exit;
    }

    if (!auth_check()) {
        header('Location: /login', true, 302);
        exit;
    }

    if ((int)$intent['user_id'] !== (int)auth_user()['id']) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }

    $invoice = bitpay_get_invoice($db, (string)$intent['payment_id']);
    if (bitpay_invoice_is_paid($invoice['status'])) {
        $expected = round((float)$intent['total_amount'], 2);
        if (abs($invoice['price'] - $expected) > 0.01) {
            error_log("[bitpay] Tutar uyuşmazlığı: oid={$orderId} beklenen={$expected} gelen={$invoice['price']}");
            $db->prepare("UPDATE payment_intents SET status='failed' WHERE id=?")->execute([$intent['id']]);
            header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
            exit;
        }
        if ($invoice['currency'] !== '' && strtoupper($invoice['currency']) !== strtoupper((string)$intent['currency'])) {
            error_log("[bitpay] Para birimi uyuşmazlığı: oid={$orderId}");
            $db->prepare("UPDATE payment_intents SET status='failed' WHERE id=?")->execute([$intent['id']]);
            header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
            exit;
        }
        $db->beginTransaction();
        try {
            $lock2 = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
            $lock2->execute([$intent['id']]);
            $locked2 = $lock2->fetch();
            if (!$locked2 || $locked2['status'] === 'completed') {
                $db->commit();
                header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
                exit;
            }
            bitpay_complete_intent($db, $intent);
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            error_log('[bitpay] Sipariş işlenirken hata: ' . $e->getMessage());
            header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
            exit;
        }
        header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
        exit;
    }

    if ($invoice['status'] === 'paid') {
        header('Location: /payment/pending?order_id=' . urlencode($orderId), true, 302);
        exit;
    }

    error_log("[bitpay] Fatura ödenmedi: oid={$orderId} durum={$invoice['status']}");
    $db->prepare("UPDATE payment_intents SET status='failed' WHERE id=? AND status='pending'")->execute([$intent['id']]);
    header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
    exit;
} catch (\Exception $e) {
    error_log('[bitpay] Callback hatası: ' . $e->getMessage());
    header('Location: /payment/cancel', true, 302);
    exit;
}
