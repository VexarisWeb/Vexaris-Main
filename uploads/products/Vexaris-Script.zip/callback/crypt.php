<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/crypt.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); echo 'Error'; exit; }
license_gate_require('core', 503);

$isWebhook = (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST');

if ($isWebhook) {
    $rawBody = file_get_contents('php://input');
    if (!crypt_verify_webhook($db, $rawBody)) {
        http_response_code(401);
        echo 'Invalid signature';
        exit;
    }
    $payload = json_decode($rawBody, true);
    if (!is_array($payload)) {
        http_response_code(400);
        echo 'Invalid payload';
        exit;
    }

    $orderId  = (string)($payload['order_id'] ?? '');
    $uuid     = (string)($payload['uuid'] ?? '');
    $status   = (string)($payload['status'] ?? '');
    $amount   = (float)($payload['amount'] ?? 0);

    if ($orderId === '' && $uuid === '') {
        http_response_code(400);
        echo 'Missing order';
        exit;
    }

    try {
        if (!crypt_webhook_is_paid($status)) {
            if (in_array($status, ['fail', 'cancel', 'wrong_amount', 'system_fail'], true)) {
                $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
                $piStmt->execute([$orderId]);
                $intent = $piStmt->fetch();
                if ($intent && $intent['status'] === 'pending') {
                    $db->prepare("UPDATE payment_intents SET status='failed',payment_id=? WHERE id=?")
                       ->execute([substr($uuid, 0, 40), $intent['id']]);
                }
            }
            http_response_code(200);
            echo 'Ignored';
            exit;
        }

        $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
        $piStmt->execute([$orderId]);
        $intent = $piStmt->fetch();
        if (!$intent) {
            $piStmt2 = $db->prepare("SELECT * FROM payment_intents WHERE payment_id=? LIMIT 1");
            $piStmt2->execute([substr($uuid, 0, 40)]);
            $intent = $piStmt2->fetch();
        }
        if (!$intent || $intent['status'] === 'completed') {
            http_response_code(200);
            echo 'OK';
            exit;
        }

        $expected = round((float)$intent['total_amount'], 2);
        if (abs($amount - $expected) > 0.01) {
            error_log("[crypt] Webhook tutar uyuşmazlığı: oid={$orderId} beklenen={$expected} gelen={$amount}");
            http_response_code(200);
            echo 'Mismatch';
            exit;
        }

        $payCur = strtoupper((string)($payload['currency'] ?? ''));
        if ($payCur !== '' && $payCur !== strtoupper((string)$intent['currency'])) {
            error_log("[crypt] Webhook para birimi uyuşmazlığı: oid={$orderId} beklenen={$intent['currency']} gelen={$payCur}");
            http_response_code(200);
            echo 'Mismatch';
            exit;
        }

        $db->beginTransaction();
        try {
            $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
            $lock->execute([$intent['id']]);
            $locked = $lock->fetch();
            if (!$locked || $locked['status'] === 'completed') { $db->commit(); http_response_code(200); echo 'OK'; exit; }

            $db->prepare("UPDATE payment_intents SET payment_id=? WHERE id=?")
               ->execute([substr($uuid, 0, 40), $intent['id']]);
            crypt_complete_intent($db, $intent);
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            error_log('[crypt] Webhook işlem hatası: ' . $e->getMessage());
            http_response_code(500);
            echo 'Error';
            exit;
        }
        http_response_code(200);
        echo 'OK';
    } catch (\Throwable $e) {
        error_log('[crypt] Webhook hatası: ' . $e->getMessage());
        http_response_code(500);
        echo 'Error';
    }
    exit;
}

/* GET: ödeme sayfasından dönüş (durum denetimi) */
try {
    $orderId = trim((string)($_GET['order_id'] ?? ''));
    if ($orderId === '') {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
    $piStmt->execute([$orderId]);
    $intent = $piStmt->fetch();
    if (!$intent) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    if ($intent['status'] === 'completed') {
        header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
        exit;
    }
    if (!auth_check()) {
        header('Location: /login', true, 302);
        exit;
    }
    if ((int)$intent['user_id'] !== (int)auth_user()['id']) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    $uuid = (string)$intent['payment_id'];
    if ($uuid === '') {
        header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
        exit;
    }
    $info = crypt_get_payment($db, $uuid);
    if (crypt_webhook_is_paid($info['payment_status'])) {
        $expected = round((float)$intent['total_amount'], 2);
        if (abs($info['amount'] - $expected) > 0.01) {
            error_log("[crypt] Tutar uyuşmazlığı: oid={$orderId} beklenen={$expected} gelen={$info['amount']}");
            $db->prepare("UPDATE payment_intents SET status='failed' WHERE id=?")->execute([$intent['id']]);
            header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
            exit;
        }
        $infoCur = strtoupper((string)($info['currency'] ?? ''));
        if ($infoCur !== '' && $infoCur !== strtoupper((string)$intent['currency'])) {
            error_log("[crypt] Para birimi uyuşmazlığı: oid={$orderId} beklenen={$intent['currency']} gelen={$infoCur}");
            $db->prepare("UPDATE payment_intents SET status='failed' WHERE id=?")->execute([$intent['id']]);
            header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
            exit;
        }
        $db->beginTransaction();
        try {
            $lock2 = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
            $lock2->execute([$intent['id']]);
            $locked2 = $lock2->fetch();
            if (!$locked2 || $locked2['status'] === 'completed') {
                $db->commit();
                header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
                exit;
            }
            crypt_complete_intent($db, $intent);
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            error_log('[crypt] Sipariş işlenirken hata: ' . $e->getMessage());
            header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
            exit;
        }
        header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
        exit;
    }
    error_log("[crypt] Fatura ödenmedi: oid={$orderId} durum={$info['payment_status']}");
    $db->prepare("UPDATE payment_intents SET status='failed' WHERE id=? AND status='pending'")->execute([$intent['id']]);
    header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
    exit;
} catch (\Exception $e) {
    error_log('[crypt] Callback hatası: ' . $e->getMessage());
    header('Location: /payment/cancel', true, 302);
    exit;
}