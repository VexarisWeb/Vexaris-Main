<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/dodopayments.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); echo 'Error'; exit; }
license_gate_require('core', 503);

$raw = file_get_contents('php://input');
$headers = function_exists('getallheaders') ? getallheaders() : [];
if (!is_array($headers) || !$headers) {
    $headers = [];
    foreach ($_SERVER as $k => $v) {
        if (strncmp($k, 'HTTP_', 5) === 0) $headers[str_replace('_', '-', substr($k, 5))] = $v;
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $raw !== '') {
    $event = dodopayments_verify_webhook($db, $raw, $headers);

    if ($event === false) {
        error_log('[dodopayments] webhook imzası doğrulanamadı.');
        http_response_code(400);
        echo 'signature failure';
        exit;
    }

    if (($event['type'] ?? '') !== 'payment.succeeded') {
        echo 'OK';
        exit;
    }

    $data = is_array($event['data'] ?? null) ? $event['data'] : [];
    $meta = is_array($data['metadata'] ?? null) ? $data['metadata'] : [];
    $orderId = trim((string)($meta['order_id'] ?? ''));
    $payRef = substr((string)($data['payment_id'] ?? ''), 0, 40);

    if ($orderId === '') {
        error_log('[dodopayments] order_id yok.');
        echo 'OK';
        exit;
    }

    if (strtolower((string)($data['status'] ?? '')) !== 'succeeded') {
        echo 'OK';
        exit;
    }

    try {
        $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
        $piStmt->execute([$orderId]);
        $intent = $piStmt->fetch();

        if (!$intent || $intent['status'] === 'completed') {
            echo 'OK';
            exit;
        }

        if ($payRef !== '') {
            $dup = $db->prepare("SELECT id FROM payment_intents WHERE payment_id=? AND status='completed' LIMIT 1");
            $dup->execute([$payRef]);
            if ($dup->fetch()) {
                echo 'OK';
                exit;
            }
        }

        $total = $data['total_amount'] ?? null;
        $expectedMinor = (int)round((float)$intent['total_amount'] * 100);
        if (!is_numeric($total) || (int)$total < $expectedMinor) {
            error_log("[dodopayments] Tutar uyuşmazlığı: order={$orderId} beklenen={$expectedMinor} gelen={$total}");
            echo 'OK';
            exit;
        }
        if ((int)$total !== $expectedMinor) {
            error_log("[dodopayments] Tutar farkı (vergi?): order={$orderId} beklenen={$expectedMinor} gelen={$total}");
        }

        $cur = strtoupper((string)($data['currency'] ?? ''));
        if ($cur === '' || $cur !== strtoupper((string)$intent['currency'])) {
            error_log("[dodopayments] Para birimi uyuşmazlığı: order={$orderId}");
            echo 'OK';
            exit;
        }

        $db->beginTransaction();
        try {
            $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
            $lock->execute([$intent['id']]);
            $locked = $lock->fetch();
            if (!$locked || $locked['status'] === 'completed') { $db->commit(); echo 'OK'; exit; }
            dodopayments_complete_intent($db, $locked + $intent, $payRef);
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            error_log('[dodopayments] webhook işlem hatası: ' . $e->getMessage());
            http_response_code(500);
            echo 'Error';
            exit;
        }

        echo 'OK';
    } catch (\Throwable $e) {
        error_log('[dodopayments] webhook hatası: ' . $e->getMessage());
        http_response_code(500);
        echo 'Error';
    }
    exit;
}

try {
    $orderId = trim((string)($_GET['order_id'] ?? ''));
    $payId = trim((string)($_GET['payment_id'] ?? ''));
    if ($orderId === '' && $payId !== '') {
        $txStmt = $db->prepare('SELECT order_id FROM payment_intents WHERE payment_id=? LIMIT 1');
        $txStmt->execute([$payId]);
        $orderId = (string)($txStmt->fetchColumn() ?: '');
    }
    if ($orderId === '') {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
    $piStmt->execute([$orderId]);
    $intent = $piStmt->fetch();
    if (!$intent) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    if (!auth_check() || (int)$intent['user_id'] !== (int)auth_user()['id']) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    if ($intent['status'] === 'completed') {
        header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
        exit;
    }
    header('Location: /payment/pending?order_id=' . urlencode($orderId), true, 302);
    exit;
} catch (\Exception $e) {
    error_log('[dodopayments] Callback hatası: ' . $e->getMessage());
    header('Location: /payment/cancel', true, 302);
    exit;
}
