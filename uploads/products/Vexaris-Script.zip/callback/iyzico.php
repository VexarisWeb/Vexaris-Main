<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/iyzico.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); exit; }
license_gate_require('core', 503);

try {
    $token = trim((string)($_POST['token'] ?? $_GET['token'] ?? ''));
    if ($token === '') {
        error_log('[iyzico] Token bulunamadı.');
        http_response_code(400);
        exit;
    }

    $result = iyzico_retrieve($db, $token);
    if (!$result || $result->getStatus() !== 'success') {
        error_log('[iyzico] Doğrulama başarısız: ' . ($result ? $result->getErrorMessage() : 'yanıt yok'));
        header('Location: /payment/cancel', true, 302);
        exit;
    }

    if (!iyzico_verify_retrieve($db, $result)) {
        error_log('[iyzico] İmza doğrulanamadı.');
        header('Location: /payment/cancel', true, 302);
        exit;
    }

    if ((int)$result->getFraudStatus() !== 1) {
        error_log('[iyzico] Fraud kontrolü geçilemedi: fraudStatus=' . $result->getFraudStatus());
        header('Location: /payment/cancel', true, 302);
        exit;
    }

    $basketId      = trim((string)$result->getBasketId());
    $paymentStatus = (string)$result->getPaymentStatus();
    $paymentId     = substr((string)$result->getPaymentId(), 0, 40);
    $paidPrice     = (float)$result->getPaidPrice();
    if ($basketId === '') {
        $basketId = trim((string)$result->getConversationId());
    }

    $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
    $piStmt->execute([$basketId]);
    $intent = $piStmt->fetch();

    if (!$intent) {
        error_log("[iyzico] Sipariş bulunamadı: {$basketId}");
        header('Location: /payment/cancel', true, 302);
        exit;
    }

    if ($intent['status'] === 'completed') {
        header('Location: /payment/success?order_id=' . urlencode($basketId), true, 302);
        exit;
    }

    if ($paymentStatus !== 'SUCCESS') {
        $db->prepare("UPDATE payment_intents SET status='failed',payment_id=? WHERE id=?")->execute([$paymentId, $intent['id']]);
        header('Location: /payment/cancel?order_id=' . urlencode($basketId), true, 302);
        exit;
    }

    $expected = round((float)$intent['total_amount'], 2);
    if (abs($paidPrice - $expected) > 0.01) {
        error_log("[iyzico] Tutar uyuşmazlığı: oid={$basketId} beklenen={$expected} gelen={$paidPrice}");
        $db->prepare("UPDATE payment_intents SET status='failed',payment_id=? WHERE id=?")->execute([$paymentId, $intent['id']]);
        header('Location: /payment/cancel?order_id=' . urlencode($basketId), true, 302);
        exit;
    }

    $retCur = strtoupper((string)$result->getCurrency());
    if ($retCur !== '' && $retCur !== strtoupper((string)$intent['currency'])) {
        error_log("[iyzico] Para birimi uyuşmazlığı: oid={$basketId} beklenen={$intent['currency']} gelen={$retCur}");
        $db->prepare("UPDATE payment_intents SET status='failed',payment_id=? WHERE id=?")->execute([$paymentId, $intent['id']]);
        header('Location: /payment/cancel?order_id=' . urlencode($basketId), true, 302);
        exit;
    }

    $cur = strtoupper((string)$intent['currency'] ?: 'TRY');

    $db->beginTransaction();
    try {
        $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
        $lock->execute([$intent['id']]);
        $locked = $lock->fetch();
        if (!$locked || $locked['status'] === 'completed') {
            $db->commit();
            header('Location: /payment/success?order_id=' . urlencode($basketId), true, 302);
            exit;
        }

        $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
           ->execute([$paymentId, $intent['id']]);

        $uid       = (int)$intent['user_id'];
        $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);

        if (strncmp($basketId, 'TOPUP-', 6) === 0) {
            $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
            $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'iyzico']) . '",NOW())')->execute([$uid, $creditAmt, 'topup']);
            $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
            $uStmt->execute([$uid]);
            $uInfo = $uStmt->fetch();
            discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body'), [
                __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
                __('bsupp.f_method')    => 'iyzico',
            ], 16766720);
        } else {
            require_once ROOT_PATH . '/core/purchase.php';
            [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);

            if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);

            $doneIyzico = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
            $totalPaid = $doneIyzico['total_paid'];
            purchase_finish($db, $uid, $totalPaid, 'iyzico', 'payment', $snapCoupon, $doneIyzico['product_ids'] ?? null);

            $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
            $uStmt->execute([$uid]);
            $uInfo = $uStmt->fetch();
            discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body'), [
                __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                __('bsupp.f_products')   => implode(', ', $doneIyzico['product_names']),
                __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
                __('bsupp.f_method')    => 'iyzico',
            ], 5763719);
        }

        $db->commit();
    } catch (\Exception $e) {
        $db->rollBack();
        error_log('[iyzico] Sipariş işlenirken hata: ' . $e->getMessage());
        header('Location: /payment/cancel?order_id=' . urlencode($basketId), true, 302);
        exit;
    }

    header('Location: /payment/success?order_id=' . urlencode($basketId), true, 302);
    exit;
} catch (\Exception $e) {
    error_log('[iyzico] Callback hatası: ' . $e->getMessage());
    http_response_code(500);
}
