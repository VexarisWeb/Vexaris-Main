<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/lemonsqueezy.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); echo 'Error'; exit; }
license_gate_require('core', 503);

$raw = file_get_contents('php://input');
$headers = function_exists('getallheaders') ? getallheaders() : [];
if (!is_array($headers) || !$headers) {
    $headers = [];
    foreach ($_SERVER as $k => $v) {
        if (strncmp($k, 'HTTP_', 5) === 0) $headers[str_replace('_', '-', substr($k, 5))] = $v;
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $raw !== '') {
    $event = lemonsqueezy_verify_webhook($db, $raw, $headers);

    if ($event === false) {
        error_log('[lemonsqueezy] webhook imzası doğrulanamadı.');
        http_response_code(400);
        echo 'signature failure';
        exit;
    }

    if (($event['meta']['event_name'] ?? '') !== 'order_created') {
        echo 'OK';
        exit;
    }

    $meta = is_array($event['meta'] ?? null) ? $event['meta'] : [];
    $data = is_array($event['data'] ?? null) ? $event['data'] : [];
    $custom = is_array($meta['custom_data'] ?? null) ? $meta['custom_data'] : [];
    $orderId = trim((string)($custom['order_id'] ?? ''));
    $orderRef = substr((string)($data['id'] ?? ''), 0, 40);

    if ($orderId === '') {
        error_log('[lemonsqueezy] order_id yok.');
        echo 'OK';
        exit;
    }

    $attrs = is_array($data['attributes'] ?? null) ? $data['attributes'] : [];
    if (strtolower((string)($attrs['status'] ?? '')) !== 'paid') {
        echo 'OK';
        exit;
    }

    if ((bool)($meta['test_mode'] ?? false) !== lemonsqueezy_test_mode($db)) {
        error_log("[lemonsqueezy] test_mode uyuşmazlığı: order={$orderId}");
        echo 'OK';
        exit;
    }

    try {
        $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
        $piStmt->execute([$orderId]);
        $intent = $piStmt->fetch();

        if (!$intent || $intent['status'] === 'completed') {
            echo 'OK';
            exit;
        }

        if ($orderRef !== '') {
            $dup = $db->prepare("SELECT id FROM payment_intents WHERE payment_id=? AND status='completed' LIMIT 1");
            $dup->execute([$orderRef]);
            if ($dup->fetch()) {
                echo 'OK';
                exit;
            }
        }

        $total = $attrs['total'] ?? null;
        $expectedMinor = (int)round((float)$intent['total_amount'] * 100);
        if (!is_numeric($total) || (int)$total !== $expectedMinor) {
            error_log("[lemonsqueezy] Tutar uyuşmazlığı: order={$orderId} beklenen={$expectedMinor} gelen={$total}");
            echo 'OK';
            exit;
        }

        $cur = strtoupper((string)($attrs['currency'] ?? ''));
        if ($cur === '' || $cur !== strtoupper((string)$intent['currency'])) {
            error_log("[lemonsqueezy] Para birimi uyuşmazlığı: order={$orderId}");
            echo 'OK';
            exit;
        }

        $db->beginTransaction();
        try {
            $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
            $lock->execute([$intent['id']]);
            $locked = $lock->fetch();
            if (!$locked || $locked['status'] === 'completed') { $db->commit(); echo 'OK'; exit; }
            lemonsqueezy_complete_intent($db, $locked + $intent, $orderRef);
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            error_log('[lemonsqueezy] webhook işlem hatası: ' . $e->getMessage());
            http_response_code(500);
            echo 'Error';
            exit;
        }

        echo 'OK';
    } catch (\Throwable $e) {
        error_log('[lemonsqueezy] webhook hatası: ' . $e->getMessage());
        http_response_code(500);
        echo 'Error';
    }
    exit;
}

try {
    $orderId = trim((string)($_GET['order_id'] ?? ''));
    if ($orderId === '') {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
    $piStmt->execute([$orderId]);
    $intent = $piStmt->fetch();
    if (!$intent) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    if (!auth_check() || (int)$intent['user_id'] !== (int)auth_user()['id']) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    if ($intent['status'] === 'completed') {
        header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
        exit;
    }
    header('Location: /payment/pending?order_id=' . urlencode($orderId), true, 302);
    exit;
} catch (\Exception $e) {
    error_log('[lemonsqueezy] Callback hatası: ' . $e->getMessage());
    header('Location: /payment/cancel', true, 302);
    exit;
}
