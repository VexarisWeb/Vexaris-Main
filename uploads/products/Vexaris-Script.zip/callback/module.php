<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';

$db = nexus_db();
if (!$db) { http_response_code(500); exit; }
license_gate_require('core', 503);

$gwCode = trim($_GET['gateway'] ?? ($_POST['gateway'] ?? ''));
$gw = function_exists('modules_gateway_find') ? modules_gateway_find($gwCode, $db) : null;
if (!$gw) { http_response_code(404); exit; }
if (function_exists('module_ratelimit') && !module_ratelimit('gw:' . $gwCode . ':' . ($_SERVER['REMOTE_ADDR'] ?? ''), 120, 60, $db)) { http_response_code(429); exit; }
if (function_exists('has_action') && !has_action('gateway_callback_' . $gwCode)) {
    http_response_code(400);
    echo 'NO_HANDLER';
    exit;
}
do_action('gateway_callback_' . $gwCode);
