<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/paddle.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); echo 'Error'; exit; }
license_gate_require('core', 503);

$raw = file_get_contents('php://input');
$headers = function_exists('getallheaders') ? getallheaders() : [];
if (!is_array($headers) || !$headers) {
    $headers = [];
    foreach ($_SERVER as $k => $v) {
        if (strncmp($k, 'HTTP_', 5) === 0) $headers[str_replace('_', '-', substr($k, 5))] = $v;
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $raw !== '') {
    $event = paddle_verify_webhook($db, $raw, $headers);

    if ($event === false) {
        error_log('[paddle] webhook imzası doğrulanamadı.');
        http_response_code(400);
        echo 'signature failure';
        exit;
    }

    if (($event['event_type'] ?? '') !== 'transaction.completed') {
        echo 'OK';
        exit;
    }

    $data = $event['data'] ?? [];
    $custom = is_array($data['custom_data'] ?? null) ? $data['custom_data'] : [];
    $orderId = trim((string)($custom['order_id'] ?? ''));
    $payId = substr((string)($data['id'] ?? ''), 0, 40);

    if ($orderId === '') {
        error_log('[paddle] order_id yok.');
        echo 'OK';
        exit;
    }

    try {
        $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
        $piStmt->execute([$orderId]);
        $intent = $piStmt->fetch();

        if (!$intent || $intent['status'] === 'completed') {
            echo 'OK';
            exit;
        }

        if ($payId !== '') {
            $dup = $db->prepare("SELECT id FROM payment_intents WHERE payment_id=? AND status='completed' LIMIT 1");
            $dup->execute([$payId]);
            if ($dup->fetch()) {
                echo 'OK';
                exit;
            }
        }

        $totals = is_array($data['details']['totals'] ?? null) ? $data['details']['totals'] : [];
        $sub = $totals['subtotal'] ?? null;
        $expectedMinor = (int)round((float)$intent['total_amount'] * 100);
        if (!is_numeric($sub) || (int)$sub !== $expectedMinor) {
            error_log("[paddle] Tutar uyuşmazlığı: order={$orderId} beklenen={$expectedMinor} gelen={$sub}");
            echo 'OK';
            exit;
        }

        $cur = strtoupper((string)($data['currency_code'] ?? ''));
        if ($cur === '' || $cur !== strtoupper((string)$intent['currency'])) {
            error_log("[paddle] Para birimi uyuşmazlığı: order={$orderId}");
            echo 'OK';
            exit;
        }

        $db->beginTransaction();
        try {
            $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
            $lock->execute([$intent['id']]);
            $locked = $lock->fetch();
            if (!$locked || $locked['status'] === 'completed') { $db->commit(); echo 'OK'; exit; }
            paddle_complete_intent($db, $locked + $intent, $payId);
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            error_log('[paddle] webhook işlem hatası: ' . $e->getMessage());
            http_response_code(500);
            echo 'Error';
            exit;
        }

        echo 'OK';
    } catch (\Throwable $e) {
        error_log('[paddle] webhook hatası: ' . $e->getMessage());
        http_response_code(500);
        echo 'Error';
    }
    exit;
}

try {
    $orderId = trim((string)($_GET['order_id'] ?? ''));
    $ptxn = trim((string)($_GET['_ptxn'] ?? ''));
    if ($orderId === '' && $ptxn !== '') {
        $txStmt = $db->prepare('SELECT order_id FROM payment_intents WHERE payment_id=? LIMIT 1');
        $txStmt->execute([$ptxn]);
        $orderId = (string)($txStmt->fetchColumn() ?: '');
    }
    if ($orderId === '') {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
    $piStmt->execute([$orderId]);
    $intent = $piStmt->fetch();
    if (!$intent) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    if (!auth_check() || (int)$intent['user_id'] !== (int)auth_user()['id']) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    if ($intent['status'] === 'completed') {
        header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
        exit;
    }
    header('Location: /payment/pending?order_id=' . urlencode($orderId), true, 302);
    exit;
} catch (\Exception $e) {
    error_log('[paddle] Callback hatası: ' . $e->getMessage());
    header('Location: /payment/cancel', true, 302);
    exit;
}
