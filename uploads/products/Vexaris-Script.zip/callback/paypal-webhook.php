<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/paypal.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); echo 'Error'; exit; }
license_gate_require('core', 503);

$raw = file_get_contents('php://input');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $raw !== '') {
    $event = paypal_verify_webhook($db, $raw, paypal_server_headers());

    if ($event === false) {
        error_log('[paypal] webhook imzası doğrulanamadı.');
        http_response_code(400);
        exit;
    }

    if (($event['event_type'] ?? '') !== 'PAYMENT.CAPTURE.COMPLETED') {
        echo 'OK';
        exit;
    }

    $res = $event['resource'] ?? [];
    $orderId = trim((string)($res['custom_id'] ?? ''));
    $capId = substr((string)($res['id'] ?? ''), 0, 40);
    $paid = (float)(($res['amount'] ?? [])['value'] ?? 0);
    $paidCur = strtoupper((string)(($res['amount'] ?? [])['currency_code'] ?? ''));

    if ($orderId === '') {
        error_log('[paypal] webhook custom_id yok.');
        echo 'OK';
        exit;
    }

    try {
        $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
        $piStmt->execute([$orderId]);
        $intent = $piStmt->fetch();

        if (!$intent || $intent['status'] === 'completed') {
            echo 'OK';
            exit;
        }

        if ($capId !== '') {
            $dup = $db->prepare("SELECT id FROM payment_intents WHERE payment_id=? AND status='completed' LIMIT 1");
            $dup->execute([$capId]);
            if ($dup->fetch()) {
                echo 'OK';
                exit;
            }
        }

        $expected = round((float)$intent['total_amount'], 2);
        if (abs($paid - $expected) > 0.01) {
            error_log("[paypal] webhook tutar uyuşmazlığı: order={$orderId} beklenen={$expected} gelen={$paid}");
            echo 'OK';
            exit;
        }

        if ($paidCur !== '' && $paidCur !== strtoupper((string)$intent['currency'])) {
            error_log("[paypal] webhook para birimi uyuşmazlığı: order={$orderId}");
            echo 'OK';
            exit;
        }

        $db->beginTransaction();
        try {
            $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
            $lock->execute([$intent['id']]);
            $locked = $lock->fetch();
            if (!$locked || $locked['status'] === 'completed') { $db->commit(); echo 'OK'; exit; }

            $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
               ->execute([$capId !== '' ? $capId : $orderId, $intent['id']]);

            $uid       = (int)$intent['user_id'];
            $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);
            $cur       = strtoupper((string)$intent['currency'] ?: 'USD');

            if (strncmp($orderId, 'TOPUP-', 6) === 0) {
                $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
                $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'PayPal']) . '",NOW())')->execute([$uid, $creditAmt, 'topup']);
                $uStmt = $db->prepare('SELECT username FROM users WHERE id=?');
                $uStmt->execute([$uid]);
                $uInfo = $uStmt->fetch() ?: [];
                discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body'), [
                    __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                    __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
                    __('bsupp.f_method')    => 'PayPal',
                ], 16766720);
            } else {
                require_once ROOT_PATH . '/core/purchase.php';
                [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);
                if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);
                $done = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
                $totalPaid = $done['total_paid'];
                purchase_finish($db, $uid, $totalPaid, 'PayPal', 'payment', $snapCoupon, $done['product_ids'] ?? null);
                $uStmt = $db->prepare('SELECT username FROM users WHERE id=?');
                $uStmt->execute([$uid]);
                $uInfo = $uStmt->fetch() ?: [];
                discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body'), [
                    __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                    __('bsupp.f_products')   => implode(', ', $done['product_names']),
                    __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
                    __('bsupp.f_method')    => 'PayPal',
                ], 5763719);
            }

            $db->commit();
            echo 'OK';
        } catch (\Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            error_log('[paypal] webhook işlem hatası: ' . $e->getMessage());
            http_response_code(500);
            echo 'Error';
        }
    } catch (\Throwable $e) {
        error_log('[paypal] webhook hatası: ' . $e->getMessage());
        http_response_code(500);
        echo 'Error';
    }
    exit;
}

http_response_code(405);
header('Allow: POST');
