<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/paypal.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); exit; }
license_gate_require('core', 503);

try {
    $orderId = trim((string)($_GET['order_id'] ?? ''));
    $ppToken = trim((string)($_GET['token'] ?? ''));
    if ($orderId === '' || $ppToken === '') {
        error_log('[paypal] Sipariş veya token eksik.');
        header('Location: /payment/cancel', true, 302);
        exit;
    }

    $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
    $piStmt->execute([$orderId]);
    $intent = $piStmt->fetch();

    if (!$intent) {
        error_log("[paypal] Sipariş bulunamadı: {$orderId}");
        header('Location: /payment/cancel', true, 302);
        exit;
    }

    if ($intent['status'] === 'completed') {
        header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
        exit;
    }

    if (!auth_check()) {
        header('Location: /login', true, 302);
        exit;
    }

    if ((int)$intent['user_id'] !== (int)auth_user()['id']) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }

    $cap = paypal_capture_order($db, $ppToken);
    if ($cap['status'] !== 'COMPLETED' || $cap['capture_id'] === '') {
        error_log("[paypal] Tahsilat tamamlanmadı: oid={$orderId} durum={$cap['status']}");
        $db->prepare("UPDATE payment_intents SET status='failed',payment_id=? WHERE id=? AND status!='completed'")->execute([substr($ppToken, 0, 40), $intent['id']]);
        header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
        exit;
    }

    if (($cap['reference_id'] !== '' && $cap['reference_id'] !== $orderId) || ($cap['custom_id'] !== '' && $cap['custom_id'] !== $orderId)) {
        error_log("[paypal] Sipariş eşleşmedi: oid={$orderId} ref={$cap['reference_id']} custom={$cap['custom_id']}");
        $db->prepare("UPDATE payment_intents SET status='failed',payment_id=? WHERE id=? AND status!='completed'")->execute([substr($cap['capture_id'], 0, 40), $intent['id']]);
        header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
        exit;
    }

    if ($cap['currency'] !== '' && $cap['currency'] !== strtoupper((string)$intent['currency'])) {
        error_log("[paypal] Para birimi uyuşmazlığı: oid={$orderId} beklenen={$intent['currency']} gelen={$cap['currency']}");
        $db->prepare("UPDATE payment_intents SET status='failed',payment_id=? WHERE id=? AND status!='completed'")->execute([substr($cap['capture_id'], 0, 40), $intent['id']]);
        header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
        exit;
    }

    $expected = round((float)$intent['total_amount'], 2);
    if (abs($cap['paid'] - $expected) > 0.01) {
        error_log("[paypal] Tutar uyuşmazlığı: oid={$orderId} beklenen={$expected} gelen={$cap['paid']}");
        $db->prepare("UPDATE payment_intents SET status='failed',payment_id=? WHERE id=? AND status!='completed'")->execute([substr($cap['capture_id'], 0, 40), $intent['id']]);
        header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
        exit;
    }

    $cur = strtoupper((string)$intent['currency'] ?: 'USD');

    $db->beginTransaction();
    try {
        $lock2 = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
        $lock2->execute([$intent['id']]);
        $locked2 = $lock2->fetch();
        if (!$locked2 || $locked2['status'] === 'completed') {
            $db->commit();
            header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
            exit;
        }

        $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
           ->execute([substr($cap['capture_id'], 0, 40), $intent['id']]);

        $uid       = (int)$intent['user_id'];
        $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);

        if (strncmp($orderId, 'TOPUP-', 6) === 0) {
            $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
            $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'PayPal']) . '",NOW())')->execute([$uid, $creditAmt, 'topup']);
            $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
            $uStmt->execute([$uid]);
            $uInfo = $uStmt->fetch();
            discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body'), [
                __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
                __('bsupp.f_method')    => 'PayPal',
            ], 16766720);
        } else {
            require_once ROOT_PATH . '/core/purchase.php';
            [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);

            if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);

            $donePaypal = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
            $totalPaid = $donePaypal['total_paid'];
            purchase_finish($db, $uid, $totalPaid, 'PayPal', 'payment', $snapCoupon, $donePaypal['product_ids'] ?? $done['product_ids'] ?? null);

            $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
            $uStmt->execute([$uid]);
            $uInfo = $uStmt->fetch();
            discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body'), [
                __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                __('bsupp.f_products')   => implode(', ', $donePaypal['product_names']),
                __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
                __('bsupp.f_method')    => 'PayPal',
            ], 5763719);
        }

        $db->commit();
    } catch (\Exception $e) {
        $db->rollBack();
        error_log('[paypal] Sipariş işlenirken hata: ' . $e->getMessage());
        header('Location: /payment/cancel?order_id=' . urlencode($orderId), true, 302);
        exit;
    }

    header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
    exit;
} catch (\Exception $e) {
    error_log('[paypal] Callback hatası: ' . $e->getMessage());
    header('Location: /payment/cancel', true, 302);
    exit;
}
