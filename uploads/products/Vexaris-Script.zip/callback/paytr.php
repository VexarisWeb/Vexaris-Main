<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/paytr.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); exit; }
license_gate_require('core', 503);

try {
    $cfg = paytr_settings($db);
    $merchantKey  = trim((string)($cfg['payment_paytr_merchant_key'] ?? ''));
    $merchantSalt = trim((string)($cfg['payment_paytr_merchant_salt'] ?? ''));
    if ($merchantKey === '' || $merchantSalt === '') {
        error_log('[PayTR] merchant_key/salt eksik.');
        http_response_code(400);
        exit;
    }

    $post = $_POST;
    $merchantOid = trim((string)($post['merchant_oid'] ?? ''));
    $status      = (string)($post['status'] ?? '');
    $totalAmount = (string)($post['total_amount'] ?? '');
    $gelenHash   = (string)($post['hash'] ?? '');

    if ($merchantOid === '' || $totalAmount === '' || $gelenHash === '') {
        error_log('[PayTR] Eksik callback verisi.');
        http_response_code(400);
        exit;
    }

    $expected = paytr_callback_hash($merchantKey, $merchantSalt, $merchantOid, $status, $totalAmount);
    if (!hash_equals($expected, $gelenHash)) {
        error_log('[PayTR] Hash doğrulanamadı. oid=' . $merchantOid);
        http_response_code(400);
        exit;
    }

    if ((string)($post['test_mode'] ?? '0') === '1') {
        error_log('[PayTR] Test bildirimi alındı, işlem yapılmadı. oid=' . $merchantOid);
        echo 'OK';
        exit;
    }

    $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
    $piStmt->execute([$merchantOid]);
    $intent = $piStmt->fetch();

    if (!$intent) {
        error_log("[PayTR] Sipariş bulunamadı: {$merchantOid}");
        http_response_code(404);
        exit;
    }

    if ($intent['status'] === 'completed') {
        echo 'OK';
        exit;
    }

    $expectedKurus = (int)round((float)$intent['total_amount'] * 100);
    if ((int)$totalAmount < $expectedKurus) {
        error_log("[PayTR] Tutar uyuşmazlığı: oid={$merchantOid} beklenen={$expectedKurus} gelen={$totalAmount}");
        http_response_code(400);
        exit;
    }
    if ((int)$totalAmount !== $expectedKurus) {
        error_log("[PayTR] Taksitli/farklı tutar kabul edildi: oid={$merchantOid} beklenen={$expectedKurus} gelen={$totalAmount}");
    }

    $paymentId = substr((string)($post['oid'] ?? $merchantOid), 0, 40);

    if ($status === 'success') {
        $db->beginTransaction();
        try {
            $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
            $lock->execute([$intent['id']]);
            $locked = $lock->fetch();
            if (!$locked || $locked['status'] === 'completed') { $db->commit(); echo 'OK'; exit; }

            $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
               ->execute([$paymentId, $intent['id']]);

            $uid       = (int)$intent['user_id'];
            $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);

            if (strncmp($merchantOid, 'TOPUP-', 6) === 0) {
                $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
                $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'PayTR']) . '",NOW())')->execute([$uid, $creditAmt, 'topup']);
                $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
                $uStmt->execute([$uid]);
                $uInfo = $uStmt->fetch();
                discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body'), [
                    __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                    __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . strtoupper((string)($intent['currency'] ?? 'TRY')),
                    __('bsupp.f_method')    => 'PayTR',
                ], 16766720);
            } else {
                require_once ROOT_PATH . '/core/purchase.php';
                [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);

                if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);

                $donePaytr = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
                $totalPaid = $donePaytr['total_paid'];
                purchase_finish($db, $uid, $totalPaid, 'PayTR', 'payment', $snapCoupon, $donePaytr['product_ids'] ?? null);

                $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
                $uStmt->execute([$uid]);
                $uInfo = $uStmt->fetch();
                discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body'), [
                    __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                    __('bsupp.f_products')   => implode(', ', $donePaytr['product_names']),
                    __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . strtoupper((string)($intent['currency'] ?? 'TRY')),
                    __('bsupp.f_method')    => 'PayTR',
                ], 5763719);
            }

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            error_log('[PayTR] Sipariş işlenirken hata: ' . $e->getMessage());
            http_response_code(500);
            exit;
        }
    } else {
        $db->prepare("UPDATE payment_intents SET status='failed',payment_id=? WHERE id=?")
           ->execute([$paymentId, $intent['id']]);
    }

    echo 'OK';
} catch (\Exception $e) {
    error_log('[PayTR] Callback hatası: ' . $e->getMessage());
    http_response_code(500);
}
