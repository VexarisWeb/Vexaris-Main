<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/paywant.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); echo 'Error'; exit; }
license_gate_require('core', 503);

$isWebhook = (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') && isset($_POST['transactionID']);

if ($isWebhook) {
    $post = $_POST;

    if (!paywant_verify_ipn($db, $post)) {
        error_log('[paywant] IPN hash doğrulanamadı.');
        echo 'hash failure';
        exit;
    }

    $transactionId = (string)($post['transactionID'] ?? '');
    $extraData     = (int)($post['extraData'] ?? 0);
    $status        = (string)($post['status'] ?? '');
    $paidTotal     = (float)str_replace(',', '.', (string)($post['paymentTotal'] ?? 0));

    if (!paywant_ipn_is_paid($status)) {
        echo 'OK';
        exit;
    }

    if ($extraData < 1) {
        error_log('[paywant] IPN sipariş eşleşmedi: extraData=' . $extraData);
        echo 'OK';
        exit;
    }

    try {
        $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE id=? LIMIT 1");
        $piStmt->execute([$extraData]);
        $intent = $piStmt->fetch();

        if (!$intent || $intent['status'] === 'completed') {
            echo 'OK';
            exit;
        }

        $dup = $db->prepare("SELECT id FROM payment_intents WHERE payment_id=? AND status='completed' LIMIT 1");
        $dup->execute([substr($transactionId, 0, 40)]);
        if ($dup->fetch()) {
            echo 'OK';
            exit;
        }

        $expected = round((float)$intent['total_amount'], 2);
        if (abs($paidTotal - $expected) > 0.01) {
            error_log("[paywant] Tutar uyuşmazlığı: intent={$extraData} beklenen={$expected} gelen={$paidTotal}");
            echo 'OK';
            exit;
        }
        if (strtoupper((string)($intent['currency'] ?? '')) !== 'TRY') {
            error_log("[paywant] Para birimi uyuşmazlığı: intent={$extraData} para_birimi=" . ($intent['currency'] ?? ''));
            echo 'OK';
            exit;
        }

        $db->beginTransaction();
        try {
            $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
            $lock->execute([$intent['id']]);
            $locked = $lock->fetch();
            if (!$locked || $locked['status'] === 'completed') { $db->commit(); echo 'OK'; exit; }
            paywant_complete_intent($db, $locked + $intent, $transactionId);
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            error_log('[paywant] IPN işlem hatası: ' . $e->getMessage());
            http_response_code(500);
            echo 'Error';
            exit;
        }

        echo 'OK';
    } catch (\Throwable $e) {
        error_log('[paywant] IPN hatası: ' . $e->getMessage());
        http_response_code(500);
        echo 'Error';
    }
    exit;
}

try {
    $orderId = trim((string)($_GET['order_id'] ?? ''));
    if ($orderId === '') {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    $piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
    $piStmt->execute([$orderId]);
    $intent = $piStmt->fetch();
    if (!$intent) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    if (!auth_check() || (int)$intent['user_id'] !== (int)auth_user()['id']) {
        header('Location: /payment/cancel', true, 302);
        exit;
    }
    if ($intent['status'] === 'completed') {
        header('Location: /payment/success?order_id=' . urlencode($orderId), true, 302);
        exit;
    }
    header('Location: /payment/pending?order_id=' . urlencode($orderId), true, 302);
    exit;
} catch (\Exception $e) {
    error_log('[paywant] Callback hatası: ' . $e->getMessage());
    header('Location: /payment/cancel', true, 302);
    exit;
}
