<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH') or define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/shopier.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); exit; }
license_gate_require('core', 503);

try {
    $username = trim(shopier_setting($db, 'payment_shopier_osb_username'));
    $key      = trim(shopier_setting($db, 'payment_shopier_osb_password'));

    $data = shopier_osb_verify(
        (string)($_POST['res'] ?? ''),
        (string)($_POST['hash'] ?? ''),
        $username,
        $key
    );

    if ($data === null) {
        error_log('[Shopier CB] HMAC doğrulama başarısız.');
        http_response_code(400);
        exit;
    }

    require_once ROOT_PATH . '/core/purchase.php';

    $productId   = trim((string)($data['productid'] ?? ''));
    $orderId     = trim((string)($data['orderid'] ?? ''));
    $customerNote= trim((string)($data['customernote'] ?? $data['customnote'] ?? $data['custom_note'] ?? ''));
    $amount      = (float)($data['price'] ?? 0);

    error_log('[Shopier CB] Gelen: productid=' . $productId . ' orderid=' . $orderId . ' customernote=' . $customerNote . ' price=' . $amount);

    if ((int)($data['istest'] ?? 0) === 1) { echo 'success'; exit; }

    $intent = null;
    if ($productId !== '') {
        $st = $db->prepare("SELECT * FROM payment_intents WHERE shopier_product_id=? LIMIT 1");
        $st->execute([$productId]); $r = $st->fetch(); if ($r) { $intent = $r; error_log('[Shopier CB] shopier_product_id eşleşti'); }
    }
    if (!$intent && $productId !== '') {
        $st = $db->prepare("SELECT * FROM payment_intents WHERE payment_id=? LIMIT 1");
        $st->execute([$productId]); $r = $st->fetch(); if ($r) { $intent = $r; error_log('[Shopier CB] payment_id eşleşti'); }
    }
    if (!$intent && $orderId !== '') {
        $st = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
        $st->execute([$orderId]); $r = $st->fetch(); if ($r) { $intent = $r; error_log('[Shopier CB] order_id eşleşti'); }
    }
    if (!$intent && $customerNote !== '') {
        $st = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
        $st->execute([$customerNote]); $r = $st->fetch(); if ($r) { $intent = $r; error_log('[Shopier CB] customernote eşleşti: ' . $customerNote); }
    }

    if (!$intent) {
        error_log('[Shopier CB] Intent bulunamadı. productid=' . $productId . ' orderid=' . $orderId . ' customernote=' . $customerNote);
        echo 'success';
        exit;
    }

    if ($intent['status'] === 'completed') { echo 'success'; exit; }

    $expected = (float)$intent['total_amount'];
    if ($amount <= 0 || (abs($amount - $expected) > 0.01 && abs(($amount / 100) - $expected) > 0.01)) {
        error_log('[Shopier CB] Tutar uyuşmazlığı. local=' . $expected . ' remote=' . $amount);
        http_response_code(400);
        exit;
    }

    $db->beginTransaction();
    try {
        $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
        $lock->execute([$intent['id']]);
        $locked = $lock->fetch();
        if (!$locked || $locked['status'] === 'completed') { $db->commit(); echo 'success'; exit; }

        $uid = (int)$intent['user_id'];
        $payRef = $orderId !== '' ? $orderId : $productId;
        $db->prepare("UPDATE payment_intents SET status='completed', payment_id=COALESCE(NULLIF(payment_id,''),?) WHERE id=?")
           ->execute([$payRef, $intent['id']]);

        $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);

        if (strncmp((string)$intent['order_id'], 'TOPUP-', 6) === 0) {
            $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
            $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'Shopier']) . '",NOW())')
               ->execute([$uid, $creditAmt, 'topup']);
            $event = 'topup'; $title = __('bsupp.topup_title');
        } else {
            require_once ROOT_PATH . '/core/purchase.php';
            [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);
            if (empty($cartItems)) throw new RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);
            $done = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
            purchase_finish($db, $uid, $done['total_paid'], 'Shopier', 'payment', $snapCoupon, $done['product_ids'] ?? null);
            $totalPaid = $done['total_paid'];
            $event = 'order'; $title = __('bsupp.order_title');
        }

        $uStmt = $db->prepare('SELECT username FROM users WHERE id=?');
        $uStmt->execute([$uid]); $uInfo = $uStmt->fetch() ?: [];

        if ($event === 'order') {
            discord_notify($db, 'order', $title, __('bsupp.shopier_order'), [
                __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                __('bsupp.f_products')   => implode(', ', $done['product_names'] ?? []),
                __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . strtoupper((string)($intent['currency'] ?? 'TRY')),
                __('bsupp.f_method')    => 'Shopier',
            ], 5763719);
        } else {
            discord_notify($db, 'topup', $title, __('bsupp.shopier_topup'), [
                __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . strtoupper((string)($intent['currency'] ?? 'TRY')),
                __('bsupp.f_method')    => 'Shopier',
            ], 16766720);
        }

        $db->commit();
        echo 'success';
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        error_log('[Shopier CB] İşlem hatası: ' . $e->getMessage());
        http_response_code(500);
    }
} catch (Throwable $e) {
    error_log('[Shopier CB] Genel hata: ' . $e->getMessage());
    http_response_code(500);
}
