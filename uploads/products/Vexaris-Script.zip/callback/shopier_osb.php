<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH') or define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/shopier.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); exit; }
license_gate_require('core', 503);

function shopier_osb_finish_payment(PDO $db, array $payload): bool {
    $productId   = trim((string)($payload['productid'] ?? ''));
    $orderId     = trim((string)($payload['orderid'] ?? ''));
    $customerNote= trim((string)($payload['customernote'] ?? $payload['customnote'] ?? $payload['custom_note'] ?? ''));
    $amount      = (float)($payload['price'] ?? 0);
    $isTest      = (int)($payload['istest'] ?? 0) === 1;

    error_log('[Shopier OSB] Gelen payload: productid=' . $productId . ' orderid=' . $orderId . ' customernote=' . $customerNote . ' price=' . $amount . ' istest=' . (int)$isTest);

    if ($isTest) { error_log('[Shopier OSB] Test modu, işlem atlandı.'); return true; }

    $intent = null;

    if ($productId !== '') {
        $st = $db->prepare("SELECT * FROM payment_intents WHERE shopier_product_id=? LIMIT 1");
        $st->execute([$productId]);
        $intent = $st->fetch() ?: null;
        if ($intent) error_log('[Shopier OSB] Intent shopier_product_id ile bulundu: ' . $productId);
    }

    if (!$intent && $productId !== '') {
        $st = $db->prepare("SELECT * FROM payment_intents WHERE payment_id=? LIMIT 1");
        $st->execute([$productId]);
        $intent = $st->fetch() ?: null;
        if ($intent) error_log('[Shopier OSB] Intent payment_id ile bulundu: ' . $productId);
    }

    if (!$intent && $orderId !== '') {
        $st = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
        $st->execute([$orderId]);
        $intent = $st->fetch() ?: null;
        if ($intent) error_log('[Shopier OSB] Intent order_id ile bulundu: ' . $orderId);
    }

    if (!$intent && $customerNote !== '') {
        $st = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
        $st->execute([$customerNote]);
        $intent = $st->fetch() ?: null;
        if ($intent) error_log('[Shopier OSB] Intent customernote ile bulundu: ' . $customerNote);
    }

    if (!$intent) {
        error_log('[Shopier OSB] Eşleşen ödeme niyeti bulunamadı. productid=' . $productId . ' orderid=' . $orderId . ' customernote=' . $customerNote);
        return true;
    }

    if ($intent['status'] === 'completed') {
        return true;
    }

    $expected = (float)$intent['total_amount'];
    if ($amount <= 0 || (abs($amount - $expected) > 0.01 && abs(($amount / 100) - $expected) > 0.01)) {
        error_log('[Shopier OSB] Tutar uyuşmazlığı, teslimat yapılmadı. local=' . $expected . ' remote=' . $amount);
        return true;
    }

    $db->beginTransaction();
    try {
        $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
        $lock->execute([$intent['id']]);
        $locked = $lock->fetch();
        if (!$locked || $locked['status'] === 'completed') {
            $db->commit();
            return true;
        }

        $uid = (int)$intent['user_id'];
        $payRef = $orderId !== '' ? $orderId : $productId;
        $db->prepare("UPDATE payment_intents SET status='completed', payment_id=COALESCE(NULLIF(payment_id,''),?) WHERE id=?")
           ->execute([$payRef, $intent['id']]);

        $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);

        if (strncmp((string)$intent['order_id'], 'TOPUP-', 6) === 0) {
            $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
            $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'Shopier']) . '",NOW())')
               ->execute([$uid, $creditAmt, 'topup']);
            $event = 'topup';
            $title = __('bsupp.topup_title');
        } else {
            require_once ROOT_PATH . '/core/purchase.php';
            [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);

            if (empty($cartItems)) {
                throw new RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid . ' intent_id=' . $intent['id']);
            }

            $done = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
            purchase_finish($db, $uid, $done['total_paid'], 'Shopier', 'payment', $snapCoupon, $done['product_ids'] ?? null);
            $totalPaid = $done['total_paid'];
            $event = 'order';
            $title = __('bsupp.order_title');
        }

        $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
        $uStmt->execute([$uid]);
        $uInfo = $uStmt->fetch() ?: [];

        if ($event === 'order') {
            discord_notify($db, 'order', $title, __('bsupp.shopier_osb_order'), [
                __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                __('bsupp.f_products')   => implode(', ', $done['product_names'] ?? []),
                __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . strtoupper((string)($intent['currency'] ?? 'TRY')),
                __('bsupp.f_method')    => 'Shopier / OSB',
            ], 5763719);
        } else {
            discord_notify($db, 'topup', $title, __('bsupp.shopier_osb_topup'), [
                __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . strtoupper((string)($intent['currency'] ?? 'TRY')),
                __('bsupp.f_method')    => 'Shopier / OSB',
            ], 16766720);
        }

        $db->commit();
        return true;
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        error_log('[Shopier OSB] Sipariş işlenirken hata: ' . $e->getMessage());
        return false;
    }
}

try {
    $username = trim(shopier_setting($db, 'payment_shopier_osb_username'));
    $key      = trim(shopier_setting($db, 'payment_shopier_osb_password'));
    $data = shopier_osb_verify(
        (string)($_POST['res'] ?? ''),
        (string)($_POST['hash'] ?? ''),
        $username,
        $key
    );

    if ($data === null) {
        error_log('[Shopier OSB] HMAC doğrulama başarısız veya eksik parametre. res_len=' . strlen($_POST['res'] ?? '') . ' username_set=' . ($username !== '' ? 'yes' : 'no'));
        http_response_code(400);
        exit;
    }

    if (!shopier_osb_finish_payment($db, $data)) {
        http_response_code(500);
        exit;
    }

    echo 'success';
} catch (Throwable $e) {
    error_log('[Shopier OSB] callback error: ' . $e->getMessage());
    http_response_code(500);
}
