<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/core/stripe.php';
require_once ROOT_PATH . '/core/discord.php';

$db = nexus_db();
if (!$db) { http_response_code(500); exit; }
license_gate_require('core', 503);

try {
    $event = stripe_parse_webhook($db);
} catch (\Stripe\Exception\SignatureVerificationException $e) {
    error_log('[stripe] İmza doğrulanamadı: ' . $e->getMessage());
    http_response_code(400);
    exit;
} catch (\Exception $e) {
    error_log('[stripe] Webhook okuma hatası: ' . $e->getMessage());
    http_response_code(400);
    exit;
}

if ($event->type !== 'checkout.session.completed') {
    http_response_code(200);
    exit;
}

$session = $event->data->object;
$orderId = trim((string)($session->metadata->order_id ?? $session->client_reference_id ?? ''));
if ($orderId === '') {
    error_log('[stripe] Sipariş kimliği bulunamadı.');
    http_response_code(400);
    exit;
}

$paymentId = substr(trim((string)($session->payment_intent ?? $session->id)), 0, 40);

$piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
$piStmt->execute([$orderId]);
$intent = $piStmt->fetch();

if (!$intent) {
    error_log("[stripe] Sipariş bulunamadı: {$orderId}");
    http_response_code(200);
    exit;
}

if ($intent['status'] === 'completed') {
    http_response_code(200);
    exit;
}

$payStatus = (string)($session->payment_status ?? '');
if ($payStatus !== '' && $payStatus !== 'paid') {
    error_log("[stripe] Ödeme tamamlanmamış: oid={$orderId} payment_status={$payStatus}");
    http_response_code(400);
    exit;
}

$sessionCur = strtolower((string)($session->currency ?? ''));
$intentCur = strtolower((string)$intent['currency']);
if ($sessionCur !== '' && $intentCur !== '' && $sessionCur !== $intentCur) {
    error_log("[stripe] Para birimi uyuşmazlığı: oid={$orderId} beklenen={$intentCur} gelen={$sessionCur}");
    http_response_code(400);
    exit;
}

$expectedMinor = stripe_amount_to_minor($db, (float)$intent['total_amount']);
$gotMinor = (int)$session->amount_total;
if ($gotMinor !== $expectedMinor) {
    error_log("[stripe] Tutar uyuşmazlığı: oid={$orderId} beklenen={$expectedMinor} gelen={$gotMinor}");
    http_response_code(400);
    exit;
}

$cur = strtoupper((string)$intent['currency'] ?: 'USD');

$db->beginTransaction();
try {
    $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
    $lock->execute([$intent['id']]);
    $locked = $lock->fetch();
    if (!$locked || $locked['status'] === 'completed') { $db->commit(); http_response_code(200); echo 'OK'; exit; }

    $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
       ->execute([$paymentId, $intent['id']]);

    $uid       = (int)$intent['user_id'];
    $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);

    if (strncmp($orderId, 'TOPUP-', 6) === 0) {
        $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
        $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'Stripe']) . '",NOW())')->execute([$uid, $creditAmt, 'topup']);
        $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
        $uStmt->execute([$uid]);
        $uInfo = $uStmt->fetch();
        discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body'), [
            __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
            __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
            __('bsupp.f_method')    => 'Stripe',
        ], 16766720);
    } else {
        require_once ROOT_PATH . '/core/purchase.php';
        [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);

if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);

                $doneStripe = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
                $totalPaid = $doneStripe['total_paid'];
                purchase_finish($db, $uid, $totalPaid, 'Stripe', 'payment', $snapCoupon, $doneStripe['product_ids'] ?? null);

                $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
                $uStmt->execute([$uid]);
                $uInfo = $uStmt->fetch();
                discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body'), [
                    __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
                    __('bsupp.f_products')   => implode(', ', $doneStripe['product_names']),
                    __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
                    __('bsupp.f_method')    => 'Stripe',
                ], 5763719);
    }

    $db->commit();
} catch (\Exception $e) {
    $db->rollBack();
    error_log('[stripe] Sipariş işlenirken hata: ' . $e->getMessage());
    http_response_code(500);
    exit;
}

http_response_code(200);
echo 'OK';