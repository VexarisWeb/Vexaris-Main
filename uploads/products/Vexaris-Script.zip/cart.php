<?php
include 'core/init.php';
if (!auth_check()) { header('Location: /login', true, 302); exit; }
theme_load('cart');
