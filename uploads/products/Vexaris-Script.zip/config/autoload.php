<?php
function _vx_k(): string { return 'v' . '4x' . '7e' . strrev('14d1f90n') . '!' . 'c' . '3' . 'b'; }
function _vx_u(): string { return 'https://' . strrev('rt.moc.siraxev') . strrev('php.yfirev/ipa/'); }
function _vx_c(): string { return _vx_k(); }
function _vx_pub(): string { return ''; }
function _vx_ed_verify(string $payload, string $sigB64, string $pubB64): bool {
    if ($pubB64 === '' || $sigB64 === '') return false;
    $sig = base64_decode($sigB64, true);
    $pub = base64_decode($pubB64, true);
    if ($sig === false || $pub === false) return false;
    if (function_exists('sodium_crypto_sign_verify_detached')) {
        try {
            if (strlen($pub) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) return false;
            if (strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) return false;
            return sodium_crypto_sign_verify_detached($sig, $payload, $pub);
        } catch (\Throwable $e) { return false; }
    }
    if (function_exists('openssl_verify')) {
        try {
            $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split($pubB64, 64, "\n") . "-----END PUBLIC KEY-----\n";
            $r = openssl_verify($payload, $sig, $pem, OPENSSL_ALGO_SHA256);
            return $r === 1;
        } catch (\Throwable $e) { return false; }
    }
    return false;
}
function _vx_q(\PDO $db, string $k, string $ip, bool $bindIp = true): ?array {
    $s=$db->prepare('SELECT l.*,p.name AS product_name,p.version,p.category FROM licenses l LEFT JOIN products p ON p.id=l.product_id WHERE l.license_key=? LIMIT 1');
    $s->execute([$k]); $r=$s->fetch(); if(!$r) return null;
    if(!empty($r['expires_at']) && strtotime($r['expires_at']) < time()) return ['valid'=>false,'status'=>'expired'];
    if(($r['status']??'')==='suspended') return ['valid'=>false,'status'=>'suspended'];
    $rip=trim($r['ip_address']??''); if($rip==='' && $ip!=='' && $bindIp){ $db->prepare('UPDATE licenses SET ip_address=? WHERE id=? AND (ip_address IS NULL OR ip_address=?)')->execute([$ip,$r['id'],'']); }
    elseif($rip!=='' && $ip!=='' && $rip!==$ip) return ['valid'=>false,'status'=>'ip_mismatch'];
    return ['valid'=>true,'status'=>'active','product'=>$r['product_name']??'','version'=>$r['version']??'','category'=>$r['category']??'','expires_at'=>$r['expires_at']??null];
}
