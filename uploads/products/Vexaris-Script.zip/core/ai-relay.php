<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
define('AI_RELAY_URL', 'https://vexaris.com.tr/api/ai-chat.php');
function ai_relay_domain(): string {
    $h = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
    return preg_replace('/[^a-z0-9.\-:]/', '', $h);
}
function ai_relay_post(array $fields, int $timeout = 55): array {
    $multi = false;
    foreach ($fields as $v) if ($v instanceof CURLFile) { $multi = true; break; }
    $ch = curl_init(AI_RELAY_URL);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $multi ? $fields : http_build_query($fields),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => 10,
    ]);
    $resp = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if (!is_string($resp) || $resp === '') return ['ok' => false, 'transport' => true, 'msg' => 'SaaS erişilemez.'];
    $j = json_decode($resp, true);
    if (!is_array($j)) return ['ok' => false, 'transport' => true, 'msg' => 'SaaS yanıtı hatalı.'];
    return ['ok' => true, 'code' => $code, 'data' => $j];
}
function ai_relay_verify(array $j): bool {
    if (!isset($j['timestamp'], $j['signature'])) return false;
    $ts = (int)$j['timestamp'];
    if ($ts <= 0 || abs(time() - $ts) > 300) return false;
    $payload = $j;
    unset($payload['signature'], $payload['timestamp']);
    $exp = hash_hmac('sha256', json_encode($payload) . '|' . $ts, _vx_k());
    return is_string($j['signature']) && hash_equals($exp, $j['signature']);
}
function ai_relay_chat(?PDO $db, string $message, string $model = '', string $effort = '', array $files = [], string $system = '', array $past = [], string $mode = ''): array {
    $message = trim($message);
    if ($message === '' && !$files) return ['ok' => false, 'msg' => 'Boş mesaj.'];
    if (mb_strlen($message) > 2000) $message = mb_substr($message, 0, 2000);
    $system = mb_substr(trim($system), 0, 2000);
    $domain = ai_relay_domain();
    if ($domain === '') return ['ok' => false, 'transport' => true, 'msg' => 'Domain yok.'];
    $history = [];
    foreach (array_slice($past, -10) as $pm) {
        if (!is_array($pm)) continue;
        $pr = ($pm['role'] ?? 'user') === 'assistant' ? 'assistant' : 'user';
        $pc = mb_substr(trim(strip_tags((string)($pm['content'] ?? ''))), 0, 1500);
        if ($pc !== '') $history[] = ['role' => $pr, 'content' => $pc];
    }
    $history[] = ['role' => 'user', 'content' => $message];
    $tmpFiles = [];
    foreach (array_slice($files, 0, 3) as $i => $f) {
        if (!is_array($f) || empty($f['tmp']) || !is_file($f['tmp'])) continue;
        $cp = tempnam(sys_get_temp_dir(), 'vxai');
        if ($cp === false || !copy($f['tmp'], $cp)) continue;
        $tmpFiles['file' . $i] = new CURLFile($cp, (string)($f['mime'] ?? 'application/octet-stream'), mb_substr((string)($f['name'] ?? 'dosya'), 0, 120));
    }
    $hasFiles = !empty($tmpFiles);
    for ($round = 0; $round < 3; $round++) {
        $nonce = bin2hex(random_bytes(32));
        $ts = time();
        $sig = hash_hmac('sha256', $domain . '|' . $ts . '|' . $nonce, _vx_k());
        $fields = [
            'domain' => $domain,
            'timestamp' => $ts,
            'nonce' => $nonce,
            'signature' => $sig,
            'messages' => json_encode($history, JSON_UNESCAPED_UNICODE),
            'max_tokens' => 1024,
            'lang' => (function_exists('lang_active') && lang_active() === 'en') ? 'en' : 'tr',
        ];
        if ($system !== '') $fields['system'] = $system;
        if ($mode !== '') $fields['mode'] = $mode;
        foreach ($tmpFiles as $k => $cf) $fields[$k] = $cf;
        $r = ai_relay_post($fields);
        foreach ($tmpFiles as $cf) { $p = $cf->name; if (is_string($p) && strncmp($p, sys_get_temp_dir(), strlen(sys_get_temp_dir())) === 0) @unlink($p); }
        $tmpFiles = [];
        if (empty($r['ok'])) return ['ok' => false, 'transport' => true, 'msg' => (string)($r['msg'] ?? '')];
        $j = $r['data'];
        if ((int)($r['code'] ?? 200) === 402) return ['ok' => false, 'quota' => true, 'msg' => 'Aylık AI kotası doldu.', 'quota_info' => $j['quota'] ?? []];
        if (empty($j['ok'])) {
            $m = (string)($j['msg'] ?? '');
            if (in_array($m, ['no license', 'bad signature', 'no provider'], true)) return ['ok' => false, 'msg' => $m];
            return ['ok' => false, 'transport' => true, 'msg' => $m];
        }
        if (!ai_relay_verify($j)) return ['ok' => false, 'transport' => true, 'msg' => 'Yanıt imzası hatalı.'];
        $calls = (is_array($j['tool_calls'] ?? null)) ? $j['tool_calls'] : [];
        if (!$calls) {
            return ['ok' => true, 'reply' => (string)($j['text'] ?? ''), 'quota' => $j['quota'] ?? [], 'credits' => (int)($j['credits'] ?? 0), 'provider' => (string)($j['provider'] ?? ''), 'model' => (string)($j['model'] ?? ''), 'tool_data' => $allDetails ?? [], 'vision_dropped' => !empty($j['vision_dropped'])];
        }
        $history[] = ['role' => 'assistant', 'content' => ''];
        $tres = [];
        $tdetails = [];
        $pending = [];
        foreach (array_slice($calls, 0, 5) as $c) {
            if (!is_array($c) || empty($c['name'])) continue;
            $targs = (isset($c['args']) && is_array($c['args'])) ? $c['args'] : [];
            if (!empty($targs['confirm'])) unset($targs['confirm']);
            $tr = function_exists('ai_tool_run') ? ai_tool_run($db, (string)$c['name'], $targs) : ['ok' => false, 'msg' => 'tool yok'];
            if (!empty($tr['needs_confirm'])) {
                $pending[] = ['tool' => (string)$c['name'], 'args' => $targs, 'confirm_msg' => (string)($tr['msg'] ?? '')];
                continue;
            }
            $tsumm = !empty($tr['ok']) ? ai_tool_summary((string)$c['name'], $tr) : ('HATA: ' . ($tr['msg'] ?? ''));
            $tres[] = ['id' => (string)($c['id'] ?? ''), 'name' => (string)$c['name'], 'result' => mb_substr($tsumm, 0, 2000)];
            $tdetails[] = ['name' => (string)$c['name'], 'ok' => !empty($tr['ok']), 'summary' => mb_substr($tsumm, 0, 500)];
        }
        if ($pending) {
            return ['ok' => true, 'needs_confirm' => true, 'tools' => $pending, 'quota' => $j['quota'] ?? []];
        }
        if (!$tres) {
            return ['ok' => true, 'reply' => 'Anlaşılamadı, tekrar deneyin.', 'quota' => $j['quota'] ?? [], 'credits' => (int)($j['credits'] ?? 0), 'provider' => (string)($j['provider'] ?? ''), 'model' => (string)($j['model'] ?? ''), 'tool_data' => []];
        }
        $history[] = ['role' => 'tool', 'content' => '', 'tool_calls' => $tres];
        $allDetails = array_merge($allDetails ?? [], $tdetails);
    }
    return ['ok' => false, 'transport' => true, 'msg' => 'Döngü sınırı.'];
}
