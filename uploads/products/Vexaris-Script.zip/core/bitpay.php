<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

function bitpay_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_bitpay_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[bitpay] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function bitpay_is_ready(\PDO $db): bool {
    $cfg = bitpay_settings($db);
    return ($cfg['payment_bitpay_active'] ?? '0') === '1'
        && !empty($cfg['payment_bitpay_token'] ?? '');
}

function bitpay_is_test_mode(\PDO $db): bool {
    $cfg = bitpay_settings($db);
    return ((string)($cfg['payment_bitpay_test_mode'] ?? '0')) === '1';
}

function bitpay_base_url(): string {
    if (function_exists('site_base_url')) {
        try {
            $b = site_base_url(function_exists('nexus_db') ? nexus_db() : null);
            if ($b !== '') return rtrim($b, '/');
        } catch (\Throwable $e) {}
    }
    $scheme = function_exists('request_is_https') ? (request_is_https() ? 'https://' : 'http://') : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://');
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    if (!preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) $host = 'localhost';
    return rtrim($scheme . $host, '/');
}

function bitpay_api_base(\PDO $db): string {
    return bitpay_is_test_mode($db) ? 'https://test.bitpay.com' : 'https://bitpay.com';
}

function bitpay_token(\PDO $db): string {
    $cfg = bitpay_settings($db);
    return trim((string)($cfg['payment_bitpay_token'] ?? ''));
}

function bitpay_currency(\PDO $db): string {
    $cfg = bitpay_settings($db);
    $siteCurrency = trim((string)($cfg['payment_bitpay_currency'] ?? 'TRY'));
    $map = ['TRY' => 'TRY', 'USD' => 'USD', 'EUR' => 'EUR', 'GBP' => 'GBP'];
    return $map[$siteCurrency] ?? 'TRY';
}

function bitpay_http(\PDO $db, string $method, string $path, $body): array {
    $headers = ['Accept: application/json', 'X-Accept-Version: 2.0.0'];
    $opts = [
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_SSL_VERIFYPEER => true,
    ];
    if ($body !== null) {
        $opts[CURLOPT_POSTFIELDS] = is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE);
    }
    $ch = curl_init(bitpay_api_base($db) . $path);
    curl_setopt_array($ch, $opts);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) {
        throw new \RuntimeException('BitPay istek hatası: ' . $err);
    }
    $json = json_decode((string)$resp, true);
    if (!is_array($json)) {
        throw new \RuntimeException('BitPay yanıtı çözümlenemedi.');
    }
    return ['code' => $code, 'json' => $json];
}

function bitpay_create_invoice(\PDO $db, string $orderId, string $brand, float $total): array {
    $token = bitpay_token($db);
    if ($token === '') {
        throw new \RuntimeException('BitPay token eksik.');
    }
    $body = [
        'token'       => $token,
        'price'       => round($total, 2),
        'currency'    => bitpay_currency($db),
        'orderId'     => $orderId,
        'itemDesc'    => mb_substr(trim($brand), 0, 127) . ' - ' . $orderId,
        'redirectURL' => bitpay_base_url() . '/callback/bitpay.php?order_id=' . urlencode($orderId),
        'notificationURL' => bitpay_base_url() . '/callback/bitpay',
        'closeURL'    => bitpay_base_url() . '/payment/cancel?order_id=' . urlencode($orderId),
        'transactionSpeed' => 'medium',
        'physical'    => false,
        'fullNotifications' => true,
    ];
    $res = bitpay_http($db, 'POST', '/invoices', $body);
    if (($res['code'] ?? 0) >= 400) {
        $msg = $res['json']['error']['message'] ?? $res['json']['message'] ?? 'bilinmeyen hata';
        throw new \RuntimeException('BitPay fatura oluşturulamadı (HTTP ' . $res['code'] . '): ' . $msg);
    }
    $data = $res['json']['data'] ?? [];
    $id   = (string)($data['id'] ?? '');
    $url  = (string)($data['url'] ?? '');
    if ($id === '' || $url === '') {
        throw new \RuntimeException('BitPay fatura yanıtı eksik.');
    }
    return ['id' => $id, 'url' => $url, 'status' => (string)($data['status'] ?? '')];
}

function bitpay_get_invoice(\PDO $db, string $invoiceId): array {
    $token = bitpay_token($db);
    $res = bitpay_http($db, 'GET', '/invoices/' . rawurlencode($invoiceId) . '?token=' . rawurlencode($token), null);
    if (($res['code'] ?? 0) >= 400) {
        throw new \RuntimeException('BitPay fatura alınamadı (HTTP ' . $res['code'] . ').');
    }
    $data = $res['json']['data'] ?? [];
    return [
        'status'   => (string)($data['status'] ?? ''),
        'order_id' => (string)($data['orderId'] ?? ''),
        'price'    => (float)($data['price'] ?? 0),
        'currency' => (string)($data['currency'] ?? ''),
    ];
}

function bitpay_verify_webhook(string $token, string $signature, string $rawBody): bool {
    if ($token === '' || $signature === '' || $rawBody === '') return false;
    $expected = base64_encode(hash_hmac('sha256', $rawBody, $token, true));
    return hash_equals($expected, $signature);
}

function bitpay_invoice_is_paid(string $status): bool {
    return in_array($status, ['confirmed', 'complete'], true);
}

function bitpay_complete_intent(\PDO $db, array $intent): void {
    $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
       ->execute([substr((string)$intent['payment_id'], 0, 40), $intent['id']]);

    $uid       = (int)$intent['user_id'];
    $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);
    $orderId   = (string)$intent['order_id'];
    $cur       = strtoupper((string)($intent['currency'] ?? 'TRY'));

    if (strncmp($orderId, 'TOPUP-', 6) === 0) {
        $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
        $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'BitPay']) . '",NOW())')->execute([$uid, $creditAmt, 'topup']);
        $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
        $uStmt->execute([$uid]);
        $uInfo = $uStmt->fetch();
        discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body_crypto'), [
            __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
            __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
            __('bsupp.f_method')    => 'BitPay',
        ], 16766720);
        return;
    }

    require_once ROOT_PATH . '/core/purchase.php';
    [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);
    if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);

    $done = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
    purchase_finish($db, $uid, $done['total_paid'], 'BitPay', 'payment', $snapCoupon, $done['product_ids'] ?? null);

    $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
    $uStmt->execute([$uid]);
    $uInfo = $uStmt->fetch();
    discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body_crypto'), [
        __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
        __('bsupp.f_products')   => implode(', ', $done['product_names']),
        __('bsupp.f_amount')     => number_format($done['total_paid'], 2, ',', '.') . ' ' . $cur,
        __('bsupp.f_method')    => 'BitPay',
    ], 5763719);
}

function bitpay_test_connection(\PDO $db): void {
    $token = bitpay_token($db);
    if ($token === '') {
        throw new \RuntimeException('Token yapılandırılmamış.');
    }
    $ch = curl_init(bitpay_api_base($db) . '/invoices');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode(['token' => $token], JSON_UNESCAPED_UNICODE),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Accept: application/json', 'X-Accept-Version: 2.0.0'],
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) throw new \RuntimeException('BitPay bağlantı hatası: ' . $err);
    if ($code === 401) throw new \RuntimeException('Geçersiz BitPay token (401).');
    if ($code === 400 || $code === 422) return;
    throw new \RuntimeException('BitPay yanıt vermiyor (HTTP ' . $code . ').');
}
