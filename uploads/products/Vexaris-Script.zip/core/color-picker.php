<?php
defined('NEXUS_BOOT') or die('Direct access denied.');

function render_color_picker(string $id, string $value = '#6366f1', string $name = ''): void {
    $cssId = preg_replace('/[^a-z0-9_-]/i', '', $id);
    if ($name === '') $name = $cssId;
    $safeVal = preg_match('/^#[0-9a-fA-F]{6}$/', $value) ? $value : '#6366f1';
    $pal = ['#61BD6D','#1ABC9C','#54ACD2','#2C82C9','#9365B8','#475577','#CCCCCC','#41A85F','#00A885','#3D8EB9','#2969B0','#553982','#28324E','#000000','#F7DA64','#FBA026','#EB6B56','#E25041','#A38F84','#EFEFEF','#ffffff','#FAC51C','#F37934','#D14841','#B8312F','#7C706B'];
?>
<style>
.cp-wrap{position:relative;display:inline-flex;align-items:center;gap:8px;}
.cp-preview{width:32px;height:32px;border-radius:8px;border:2px solid rgba(255,255,255,.12);cursor:pointer;flex-shrink:0;box-shadow:0 2px 8px rgba(0,0,0,.25);}
.cp-drp{display:none;position:absolute;top:calc(100% + 8px);left:0;background:#1e1e1e;border:1px solid #333;border-radius:10px;padding:12px;box-shadow:0 12px 40px rgba(0,0,0,.6);z-index:9999;width:232px;flex-direction:column;gap:8px;}
.cp-drp.show{display:flex;}
.cp-grd{display:grid;grid-template-columns:repeat(7,1fr);gap:0;border-radius:6px;overflow:hidden;border:1px solid #333;}
.cp-sw{width:100%;aspect-ratio:1;cursor:pointer;border:none;transition:transform .1s;outline:none;}
.cp-sw:hover{transform:scale(1.12);z-index:2;box-shadow:0 0 8px rgba(0,0,0,.7);border-radius:3px;}
.cp-hex-lbl{font-size:11px;color:#888;margin-top:4px;}
.cp-hex-rw{display:flex;align-items:center;gap:6px;}
.cp-hex-rw input{flex:1;background:#121212;border:1px solid #333;color:#fff;padding:7px 10px;border-radius:6px;font-size:12px;outline:none;font-family:monospace;letter-spacing:1px;}
.cp-hex-rw input:focus{border-color:#6366f1;}
.cp-hex-ok{background:#6366f1;color:#fff;border:none;border-radius:6px;padding:7px 12px;cursor:pointer;font-size:12px;font-weight:800;}
.cp-hex-ok:hover{background:#4f46e5;}
.cp-input{width:110px;background:var(--bg-surface, #16161f);border:1px solid var(--border, #333);border-radius:9px;padding:8px 10px;color:var(--text, #fff);font-size:13px;font-family:monospace;outline:none;}
</style>
<div class="cp-wrap" id="cpWrap-<?= $cssId ?>">
    <div class="cp-preview" id="cpPrev-<?= $cssId ?>" style="background:<?= e($safeVal) ?>;" title="Renk seç"></div>
    <input type="text" id="<?= $cssId ?>" name="<?= e($name) ?>" value="<?= e($safeVal) ?>" class="cp-input" maxlength="7" placeholder="#6366f1" spellcheck="false">
    <div class="cp-drp" id="cpDrp-<?= $cssId ?>">
        <div class="cp-grd">
            <?php foreach ($pal as $c): ?>
            <button type="button" class="cp-sw" style="background:<?= $c ?>;" data-color="<?= $c ?>" aria-label="<?= $c ?>"></button>
            <?php endforeach; ?>
        </div>
        <div class="cp-hex-lbl">HEX Color</div>
        <div class="cp-hex-rw"><input type="text" class="cp-hex-inp" placeholder="#FFFFFF" maxlength="7"><button type="button" class="cp-hex-ok">OK</button></div>
    </div>
</div>
<script>
(function(){
    var wrap=document.getElementById('cpWrap-<?= $cssId ?>');
    var prev=document.getElementById('cpPrev-<?= $cssId ?>');
    var inp=document.getElementById('<?= $cssId ?>');
    var drp=document.getElementById('cpDrp-<?= $cssId ?>');
    var hexInp=drp.querySelector('.cp-hex-inp');
    var okBtn=drp.querySelector('.cp-hex-ok');
    var sws=drp.querySelectorAll('.cp-sw');
    function isHex(v){return /^#([0-9A-F]{3}){1,2}$/i.test(v) || /^#[0-9A-F]{6}$/i.test(v);}
    function apply(c){
        if(!isHex(c)) return;
        if(c.length===4){c='#'+c[1]+c[1]+c[2]+c[2]+c[3]+c[3];}
        c=c.toUpperCase();
        inp.value=c;
        prev.style.background=c;
        hexInp.value=c;
        inp.dispatchEvent(new Event('input',{bubbles:true}));
        inp.dispatchEvent(new Event('change',{bubbles:true}));
    }
    prev.addEventListener('click',function(e){
        e.stopPropagation();
        document.querySelectorAll('.cp-drp').forEach(function(d){if(d!==drp)d.classList.remove('show');});
        drp.classList.toggle('show');
        if(drp.classList.contains('show')) hexInp.value=inp.value.toUpperCase();
    });
    sws.forEach(function(s){
        s.addEventListener('click',function(e){
            e.preventDefault();
            apply(s.getAttribute('data-color'));
            drp.classList.remove('show');
        });
    });
    okBtn.addEventListener('click',function(){
        var v=hexInp.value.trim();
        if(!v.startsWith('#')) v='#'+v;
        if(isHex(v)){apply(v);drp.classList.remove('show');}
    });
    hexInp.addEventListener('keydown',function(e){
        if(e.key==='Enter'){e.preventDefault();okBtn.click();}
        if(e.key==='Escape'){drp.classList.remove('show');}
    });
    hexInp.addEventListener('input',function(){
        var v=hexInp.value.trim();
        if(!v.startsWith('#')) v='#'+v;
        if(isHex(v)){prev.style.background=v.toUpperCase(); inp.value=v.toUpperCase();}
    });
    inp.addEventListener('input',function(){
        var v=inp.value.trim();
        if(!v.startsWith('#')) v='#'+v;
        if(isHex(v)){prev.style.background=v.toUpperCase(); hexInp.value=v.toUpperCase();}
    });
    document.addEventListener('click',function(e){
        if(!wrap.contains(e.target)) drp.classList.remove('show');
    });
})();
</script>
<?php
}
