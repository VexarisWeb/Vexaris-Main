<?php
if (!defined('ROOT_PATH'))              define('ROOT_PATH',              dirname(__DIR__));
require_once __DIR__ . '/../config/autoload.php';
if (!defined('CONFIG_SYNC_ORIGIN'))     define('CONFIG_SYNC_ORIGIN',     _vx_u());
if (!defined('CONFIG_SYNC_PATH'))       define('CONFIG_SYNC_PATH',       '');
if (!defined('CONFIG_SYNC_TTL'))        define('CONFIG_SYNC_TTL',        3600);
if (!defined('CONFIG_SYNC_FAIL_LIMIT')) define('CONFIG_SYNC_FAIL_LIMIT', 72);
if (!defined('CONFIG_SYNC_COOLDOWN')) define('CONFIG_SYNC_COOLDOWN', 600);

function config_sync_key(): string { return _vx_k(); }

function config_sync_http_post(string $url, array $payload, int $timeout = 4): string {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_FOLLOWLOCATION => false,
        ]);
        $out = curl_exec($ch);
        curl_close($ch);
        return is_string($out) ? $out : '';
    }
    $body = http_build_query($payload);
    $ctx  = stream_context_create(['http' => [
        'method'        => 'POST',
        'header'        => "Content-Type: application/x-www-form-urlencoded\r\nContent-Length: " . strlen($body),
        'content'       => $body,
        'timeout'       => $timeout,
        'ignore_errors' => true,
    ]]);
    $out = @file_get_contents($url, false, $ctx);
    return is_string($out) ? $out : '';
}

function config_sync_request(?\PDO $db, string $domain): ?array {
    if ($db === null) return null;
    $nonce = bin2hex(random_bytes(32));
    $ts    = time();
    $sig   = hash_hmac('sha256', $domain . '|' . $ts . '|' . $nonce, config_sync_key());
    $raw   = config_sync_http_post(CONFIG_SYNC_ORIGIN . CONFIG_SYNC_PATH, [
        'domain'    => $domain,
        'timestamp' => $ts,
        'nonce'     => $nonce,
        'signature' => $sig,
    ]);
    if ($raw === '') return null;
    $j = json_decode($raw, true);
    if (!is_array($j)) return null;
    if (!isset($j['features'], $j['timestamp'], $j['signature'])) return null;
    if (!is_array($j['features'])) return null;
    $tsR = (int)$j['timestamp'];
    if ($tsR <= 0 || abs(time() - $tsR) > 300) return null;
    $algR = (string)($j['alg'] ?? 'hmac');
    $plan = null;
    if (isset($j['plan']) && is_array($j['plan']) && isset($j['plan']['slug']) && is_string($j['plan']['slug'])) {
        $planRaw = json_encode($j['plan']);
        if (is_string($planRaw) && strlen($planRaw) <= 4096 && isset($j['plan_sig']) && is_string($j['plan_sig'])) {
            $planPayload = $planRaw . '|' . $tsR;
            if ($algR === 'ed25519') {
                if (_vx_ed_verify($planPayload, $j['plan_sig'], _vx_pub())) $plan = $j['plan'];
            } else {
                $planExp = hash_hmac('sha256', $planPayload, config_sync_key());
                if (hash_equals($planExp, $j['plan_sig'])) $plan = $j['plan'];
            }
        }
    }
    if ($algR === 'ed25519') {
        $payload = json_encode($j['features']) . '|' . $tsR;
        if (!is_string($j['signature']) || !_vx_ed_verify($payload, $j['signature'], _vx_pub())) return null;
        return ['features' => $j['features'], 'plan' => $plan, 'timestamp' => $tsR, 'alg' => 'ed25519', 'sig' => $j['signature']];
    }
    $exp = hash_hmac('sha256', json_encode($j['features']) . '|' . $tsR, config_sync_key());
    if (!is_string($j['signature']) || !hash_equals($exp, $j['signature'])) return null;
    return ['features' => $j['features'], 'plan' => $plan, 'timestamp' => $tsR, 'alg' => 'hmac', 'sig' => $j['signature']];
}

function config_sync_state(bool $reload = false): array {
    static $c = null;
    if ($reload || $c === null) {
        $c = ['ts' => 0, 'fail' => 0, 'features' => [], 'plan' => null, 'sig' => '', 'last_try' => 0, 'alg' => 'hmac'];
        $db = function_exists('nexus_db') ? nexus_db() : null;
        if ($db) {
            try {
                $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='_vx_sync' LIMIT 1");
                $st->execute();
                $raw = $st->fetchColumn();
                if ($raw) {
                    $d = json_decode((string)$raw, true);
                    if (is_array($d)) {
                        $c['ts']       = (int)($d['ts'] ?? 0);
                        $c['fail']     = (int)($d['fail'] ?? 0);
                        $c['features'] = is_array($d['features'] ?? null) ? $d['features'] : [];
                        $c['sig']      = is_string($d['sig'] ?? null) ? $d['sig'] : '';
                        $c['last_try'] = (int)($d['last_try'] ?? 0);
                        $c['alg']      = (string)($d['alg'] ?? 'hmac');
                        if ($c['alg'] !== 'ed25519' && $c['alg'] !== 'hmac') $c['alg'] = 'hmac';
                        $c['plan']     = (isset($d['plan']) && is_array($d['plan'])) ? $d['plan'] : null;
                    }
                }
            } catch (\Throwable $e) {}
        }
    }
    return $c;
}

function config_sync_verify_cache(array $d): bool {
    if (empty($d['sig']) || !is_string($d['sig'])) return false;
    $features = $d['features'] ?? null;
    $ts = (int)($d['ts'] ?? 0);
    if (!is_array($features) || $ts <= 0) return false;
    $payload = json_encode($features) . '|' . $ts;
    if (($d['alg'] ?? 'hmac') === 'ed25519') {
        return _vx_ed_verify($payload, $d['sig'], _vx_pub());
    }
    $exp = hash_hmac('sha256', $payload, config_sync_key());
    return hash_equals($exp, $d['sig']);
}

function config_sync_store_json(\PDO $db, array $state): void {
    try {
        $st = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('_vx_sync',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        $st->execute([json_encode($state)]);
    } catch (\Throwable $e) {}
}

function config_sync_store_features(\PDO $db, array $features, int $ts, string $alg = 'hmac', string $sig = '', ?array $plan = null): void {
    if ($alg !== 'ed25519') $alg = 'hmac';
    if ($sig === '') $sig = hash_hmac('sha256', json_encode($features) . '|' . $ts, config_sync_key());
    config_sync_store_json($db, ['ts' => $ts, 'fail' => 0, 'features' => $features, 'plan' => $plan, 'sig' => $sig, 'last_try' => time(), 'alg' => $alg]);
}

function config_sync_lock_read(?\PDO $db): array {
    if ($db === null) return ['on' => 0, 'paths' => []];
    try {
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='_vx_lock' LIMIT 1");
        $st->execute();
        $raw = $st->fetchColumn();
        if ($raw) {
            $d = json_decode((string)$raw, true);
            if (is_array($d)) return $d;
        }
    } catch (\Throwable $e) {}
    return ['on' => 0, 'paths' => []];
}

function config_sync_lock_store(\PDO $db, array $state): void {
    try {
        $st = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('_vx_lock',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        $st->execute([json_encode($state)]);
    } catch (\Throwable $e) {}
}

function config_sync_lock_plant(\PDO $db): void {
    $seed = bin2hex(random_bytes(6));
    $slots = ['uploads', 'themes/default/assets/css', 'themes/azure/assets/js', 'pages', 'shop', 'api', 'payment', 'images', 'core/managers'];
    $stored = [];
    foreach ($slots as $i => $dir) {
        $abs = ROOT_PATH . '/' . $dir;
        if (!is_dir($abs)) continue;
        $name = '.' . substr(hash('sha256', $seed . '|' . $i), 0, 16);
        $path = $abs . '/' . $name;
        if (@file_put_contents($path, $seed) !== false) $stored[] = $path;
    }
    config_sync_lock_store($db, ['on' => 1, 'at' => time(), 'paths' => $stored]);
}

function config_sync_lock_release(\PDO $db): void {
    $old = config_sync_lock_read($db);
    foreach ((array)($old['paths'] ?? []) as $p) {
        if (is_string($p) && is_file($p)) @unlink($p);
    }
    try {
        $db->prepare("DELETE FROM settings WHERE `key`='_vx_lock'")->execute();
    } catch (\Throwable $e) {}
}

function config_sync_locked(?\PDO $db = null): bool {
    $db = $db ?: (function_exists('nexus_db') ? nexus_db() : null);
    if ($db === null) return false;
    $d = config_sync_lock_read($db);
    if ((int)($d['on'] ?? 0) === 1) return true;
    foreach ((array)($d['paths'] ?? []) as $p) {
        if (is_string($p) && is_file($p)) return true;
    }
    return false;
}

function config_sync_http_lock(): void {
    http_response_code(503);
    header('Retry-After: ' . CONFIG_SYNC_TTL);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8"><title>Hizmet Kullanılamıyor</title></head>'
       . '<body style="margin:0;font-family:sans-serif;background:#0b0f17;color:#e2e8f0;height:100vh;display:flex;align-items:center;justify-content:center;">'
       . '<div style="text-align:center;"><h1 style="font-size:2rem;margin:0 0 12px;color:#f59e0b;">Hizmet Kullanılamıyor</h1>'
       . '<p style="color:#94a3b8;margin:0;">Sunucu doğrulaması tamamlanana kadar site geçici olarak kilitlendi. Lütfen daha sonra tekrar deneyin.</p></div></body></html>';
    exit;
}

function config_sync_now(?\PDO $db = null, bool $force = false): bool {
    $db = $db ?: (function_exists('nexus_db') ? nexus_db() : null);
    if (!$db) return false;
    $st0 = config_sync_state();
    if (!$force && $st0['last_try'] > 0 && (time() - $st0['last_try']) < CONFIG_SYNC_COOLDOWN) return false;
    $domain = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
    if ($domain === '') return false;
    $res = config_sync_request($db, $domain);
    if ($res === null) {
        $st = config_sync_state(true);
        $fail = $st['fail'] + 1;
        config_sync_store_json($db, ['ts' => $st['ts'], 'fail' => $fail, 'features' => $st['features'], 'plan' => ($st['plan'] ?? null), 'sig' => $st['sig'], 'last_try' => time(), 'alg' => ($st['alg'] ?? 'hmac')]);
        if ($fail >= CONFIG_SYNC_FAIL_LIMIT && !config_sync_locked($db)) {
            config_sync_lock_plant($db);
        }
        return false;
    }
    if (config_sync_locked($db)) config_sync_lock_release($db);
    config_sync_store_features($db, $res['features'], $res['timestamp'], ($res['alg'] ?? 'hmac'), ($res['sig'] ?? ''), (isset($res['plan']) && is_array($res['plan']) ? $res['plan'] : null));
    return true;
}

function config_sync_maybe(): void {
    if (PHP_SAPI === 'cli') return;
    if (!function_exists('nexus_db')) return;
    $db = nexus_db();
    if (!$db) return;
    if (config_sync_locked($db)) {
        $st = config_sync_state();
        if (!($st['ts'] > 0 && time() - $st['ts'] < CONFIG_SYNC_TTL)) {
            $ok = config_sync_now($db);
            if ($ok) return;
        }
        config_sync_http_lock();
        return;
    }
    $st = config_sync_state();
    if ($st['ts'] > 0 && time() - $st['ts'] < CONFIG_SYNC_TTL && config_sync_verify_cache($st)) return;
    config_sync_now($db);
}

function feature_active(string $key): bool {
    if (!function_exists('nexus_db')) return false;
    $st    = config_sync_state();
    if (config_sync_locked()) return false;
    $fresh = $st['ts'] > 0 && (time() - $st['ts']) < CONFIG_SYNC_TTL && config_sync_verify_cache($st);
    if ($fresh) return (($st['features'][$key] ?? false) === true);
    if ($st['fail'] >= CONFIG_SYNC_FAIL_LIMIT) return false;
    return false;
}

function config_sync_probe(\PDO $db, string $domain): bool {
    $domain = strtolower(trim($domain));
    if ($domain === '') return false;
    $res = config_sync_request($db, $domain);
    if ($res === null) return false;
    if (($res['features']['core'] ?? false) !== true) return false;
    config_sync_store_features($db, $res['features'], $res['timestamp'], ($res['alg'] ?? 'hmac'), ($res['sig'] ?? ''), (isset($res['plan']) && is_array($res['plan']) ? $res['plan'] : null));
    return true;
}
