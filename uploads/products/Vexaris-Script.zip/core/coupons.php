<?php
if (!defined('NEXUS_BOOT')) exit;

if (!function_exists('coupon_consume')) {
    function coupon_consume($db, $couponId, $userId): bool {
        $couponId = (int)$couponId;
        $userId   = (int)$userId;
        if (!$couponId || !$userId) return false;
        try {
            $db->prepare('SELECT id FROM coupons WHERE id=? FOR UPDATE')->execute([$couponId]);
            $chk = $db->prepare('SELECT id FROM coupon_usages WHERE user_id=? AND coupon_id=?');
            $chk->execute([$userId, $couponId]);
            if ($chk->fetch()) return true;
            $up = $db->prepare('UPDATE coupons SET used_count=used_count+1 WHERE id=? AND is_active=1 AND used_count<max_uses AND reward_type="discount" AND (expires_at IS NULL OR expires_at > NOW())');
            $up->execute([$couponId]);
            if ($up->rowCount() === 0) return false;
            $db->prepare('INSERT IGNORE INTO coupon_usages (user_id,coupon_id,used_at) VALUES (?,?,NOW())')->execute([$userId, $couponId]);
            return true;
        } catch (\Throwable $e) {
            error_log('[NS] coupon_consume: ' . $e->getMessage());
            return false;
        }
    }
}
