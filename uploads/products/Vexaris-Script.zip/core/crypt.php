<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

/**
 * Cryptomus ödeme entegrasyonu.
 * API: https://api.cryptomus.com  (backend merchant API)
 * İmza: md5( base64_encode(json_encode(vücut)) . apiKey )
 */

function crypt_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_crypt_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[cryptp] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function crypt_is_ready(\PDO $db): bool {
    $cfg = crypt_settings($db);
    return ($cfg['payment_crypt_active'] ?? '0') === '1'
        && !empty($cfg['payment_crypt_merchant_id'] ?? '')
        && !empty($cfg['payment_crypt_api_key'] ?? '');
}

function crypt_base_url(): string {
    if (function_exists('site_base_url')) {
        try {
            $b = site_base_url(function_exists('nexus_db') ? nexus_db() : null);
            if ($b !== '') return rtrim($b, '/');
        } catch (\Throwable $e) {}
    }
    $scheme = function_exists('request_is_https') ? (request_is_https() ? 'https://' : 'http://') : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://');
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    if (!preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) $host = 'localhost';
    return rtrim($scheme . $host, '/');
}

function crypt_merchant_id(\PDO $db): string {
    $cfg = crypt_settings($db);
    return trim((string)($cfg['payment_crypt_merchant_id'] ?? ''));
}

function crypt_api_key(\PDO $db): string {
    $cfg = crypt_settings($db);
    return trim((string)($cfg['payment_crypt_api_key'] ?? ''));
}

function crypt_currency(\PDO $db): string {
    $cfg = crypt_settings($db);
    $siteCurrency = trim((string)($cfg['payment_crypt_currency'] ?? 'TRY'));
    $map = ['TRY' => 'TRY', 'USD' => 'USD', 'EUR' => 'EUR', 'GBP' => 'GBP'];
    return $map[$siteCurrency] ?? 'TRY';
}

function crypt_sign(\PDO $db, $body): string {
    $json = is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE);
    return md5(base64_encode($json) . crypt_api_key($db));
}

/**
 * Merchant API isteği. $body = array (veya null).
 * Dönen: HTTP yanıtının JSON dizisi.
 */
function crypt_http(\PDO $db, string $path, $body = null): array {
    $merchant = crypt_merchant_id($db);
    if ($merchant === '') throw new \RuntimeException('Cryptomus merchant kimliği eksik.');
    $json = ($body === null) ? '{}' : (is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE));
    $sign = md5(base64_encode($json) . crypt_api_key($db));

    $headers = [
        'merchant: ' . $merchant,
        'sign: ' . $sign,
        'Content-Type: application/json',
        'Accept: application/json',
    ];

    $ch = curl_init('https://api.cryptomus.com' . $path);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST  => 'POST',
        CURLOPT_POSTFIELDS     => $json,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) throw new \RuntimeException('Cryptomus istek hatası: ' . $err);
    $data = json_decode((string)$resp, true);
    if (!is_array($data)) throw new \RuntimeException('Cryptomus yanıtı çözümlenemedi (HTTP ' . $code . ').');
    $data['http_code'] = $code;
    return $data;
}

/**
 * Ödeme (invoice) oluşturur.
 * Dönen: ['uuid'=>..., 'url'=>..., 'payment_status'=>...]
 */
function crypt_create_invoice(\PDO $db, string $orderId, string $brand, float $total): array {
    $body = [
        'amount'        => number_format($total, 2, '.', ''),
        'currency'      => crypt_currency($db),
        'order_id'      => $orderId,
        'is_payment_multiple' => false,
        'lifetime'      => 3600,
        'url_callback'  => crypt_base_url() . '/callback/crypt',
        'url_success'   => crypt_base_url() . '/payment/success?order_id=' . urlencode($orderId),
        'url_return'    => crypt_base_url() . '/payment/cancel?order_id=' . urlencode($orderId),
        'additional_data' => mb_substr(trim($brand), 0, 200),
    ];
    $res = crypt_http($db, '/v1/payment', $body);
    if (($res['state'] ?? 1) !== 0) {
        $msg = $res['message'] ?? $res['errors'] ?? 'bilinmeyen hata';
        if (is_array($msg)) $msg = json_encode($msg, JSON_UNESCAPED_UNICODE);
        throw new \RuntimeException('Cryptomus fatura oluşturulamadı: ' . $msg);
    }
    $result = $res['result'] ?? [];
    $uuid = (string)($result['uuid'] ?? '');
    $url  = (string)($result['url'] ?? '');
    if ($uuid === '' || $url === '') throw new \RuntimeException('Cryptomus fatura yanıtı eksik.');
    return ['uuid' => $uuid, 'url' => $url, 'payment_status' => (string)($result['payment_status'] ?? '')];
}

/** Ödeme bilgisini uuid ile çeker. */
function crypt_get_payment(\PDO $db, string $uuid): array {
    $res = crypt_http($db, '/v1/payment/info', ['uuid' => $uuid]);
    if (($res['state'] ?? 1) !== 0) {
        $msg = $res['message'] ?? 'bilinmeyen hata';
        throw new \RuntimeException('Cryptomus ödeme bilgisi alınamadı: ' . $msg);
    }
    $result = $res['result'] ?? [];
    return [
        'payment_status' => (string)($result['payment_status'] ?? ''),
        'status'         => (string)($result['status'] ?? ''),
        'order_id'       => (string)($result['order_id'] ?? ''),
        'amount'         => (float)($result['amount'] ?? 0),
    ];
}

/**
 * Webhook doğrular. Cryptomus webhook gövdesi içinde `sign` alanı taşır.
 * İşaret: md5( base64( json_encode(body hariç sign, JSON_UNESCAPED_UNICODE) ) . apiKey )
 */
function crypt_verify_webhook(\PDO $db, string $rawBody): bool {
    $data = json_decode($rawBody, true);
    if (!is_array($data)) return false;
    $sign = (string)($data['sign'] ?? '');
    if ($sign === '') return false;
    unset($data['sign']);
    $expected = md5(base64_encode(json_encode($data, JSON_UNESCAPED_UNICODE)) . crypt_api_key($db));
    return hash_equals($expected, $sign);
}

/** Bir Webhook durumunun "ödendi" anlamına gelip gelmediği. */
function crypt_webhook_is_paid(string $status): bool {
    return in_array($status, ['paid', 'paid_over'], true);
}

/**
 * Ödeme intent'ini tamamlar. TOPUP kredisi ekler, aksi halde sepeti
 * satışa dönüştürür (ortak helper kullanır).
 */
function crypt_complete_intent(\PDO $db, array $intent, string $methodLabel = 'Cryptomus'): void {
    $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
       ->execute([substr((string)$intent['payment_id'], 0, 40), $intent['id']]);

    $uid       = (int)$intent['user_id'];
    $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);
    $orderId   = (string)$intent['order_id'];
    $cur       = strtoupper((string)($intent['currency'] ?? 'TRY'));

    if (strncmp($orderId, 'TOPUP-', 6) === 0) {
        $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
        $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,?,NOW())')->execute([$uid, $creditAmt, 'topup', __('bshop.topup_log', ['method' => $methodLabel])]);
        $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
        $uStmt->execute([$uid]);
        $uInfo = $uStmt->fetch();
        discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body_crypto'), [
            __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
            __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
            __('bsupp.f_method')    => $methodLabel,
        ], 16766720);
        return;
    }

    require_once ROOT_PATH . '/core/purchase.php';
    [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);
    if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);

    $done = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
    purchase_finish($db, $uid, $done['total_paid'], $methodLabel, 'payment', $snapCoupon, $done['product_ids'] ?? null);

    $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
    $uStmt->execute([$uid]);
    $uInfo = $uStmt->fetch();
    discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body_crypto'), [
        __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
        __('bsupp.f_products')   => implode(', ', $done['product_names']),
        __('bsupp.f_amount')     => number_format($done['total_paid'], 2, ',', '.') . ' ' . $cur,
        __('bsupp.f_method')    => $methodLabel,
    ], 5763719);
}

function crypt_test_connection(\PDO $db): void {
    if (!crypt_is_ready($db)) throw new \RuntimeException('Merchant ID ve API anahtarı yapılandırılmamış.');
    $res = crypt_http($db, '/v1/payment/services', '{}');
    if (($res['state'] ?? 1) !== 0) {
        $msg = $res['message'] ?? 'bilinmeyen hata';
        throw new \RuntimeException('Cryptomus yanıtı: ' . $msg);
    }
}