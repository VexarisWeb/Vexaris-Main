<?php

defined('NEXUS_BOOT') or die('Direct access denied.');

if (!function_exists('split_sql_statements')) {
    function split_sql_statements(string $sql): array {
        $out = []; $buf = ''; $q = ''; $n = strlen($sql);
        for ($i = 0; $i < $n; $i++) {
            $c = $sql[$i];
            if ($q !== '') {
                $buf .= $c;
                if ($c === '\\' && $i + 1 < $n) { $buf .= $sql[++$i]; continue; }
                if ($c === $q) $q = '';
                continue;
            }
            if ($c === "'" || $c === '"' || $c === '`') { $q = $c; $buf .= $c; continue; }
            if ($c === '-' && substr($sql, $i, 2) === '--') {
                $j = strpos($sql, "\n", $i);
                $i = ($j === false) ? $n : $j;
                continue;
            }
            if ($c === ';') {
                $t = trim($buf);
                if ($t !== '' && strncmp(ltrim($t), '--', 2) !== 0) $out[] = $t;
                $buf = '';
                continue;
            }
            $buf .= $c;
        }
        $t = trim($buf);
        if ($t !== '' && strncmp(ltrim($t), '--', 2) !== 0) $out[] = $t;
        return $out;
    }
}

function nexus_db(): ?PDO {

    static $pdo = false;

    if ($pdo !== false) return $pdo;



    $configFile = ROOT_PATH . DIRECTORY_SEPARATOR . 'install' . DIRECTORY_SEPARATOR . 'config.php';

    if (!file_exists($configFile)) { $pdo = null; return null; }



    $cfg = (static function (string $f): array { return include $f; })($configFile);

    if (empty($cfg['db_name']) || empty($cfg['db_user'])) { $pdo = null; return null; }



    try {

        $pdo = new PDO(

            "mysql:host={$cfg['db_host']};dbname={$cfg['db_name']};charset=utf8mb4",

            $cfg['db_user'],

            $cfg['db_pass'],

            [

                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,

                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,

                PDO::ATTR_EMULATE_PREPARES   => false,

            ]

        );



        static $schemaRun = false;

        if (!$schemaRun) {

            $schemaRun  = true;

            $schemaFile = ROOT_PATH . DIRECTORY_SEPARATOR . 'install' . DIRECTORY_SEPARATOR . 'database.sql';

            if (file_exists($schemaFile)) {

                $sql = file_get_contents($schemaFile);

                foreach (split_sql_statements($sql) as $stmt) {

                    $stmtNorm = strtoupper(ltrim($stmt));

                    if (strpos($stmtNorm, 'INSERT IGNORE INTO `CATEGORIES`') === 0) continue;

                    if (strpos($stmtNorm, 'INSERT IGNORE INTO `TICKET_CATEGORIES`') === 0) continue;

                    try { $pdo->exec($stmt); } catch (\PDOException $e) { error_log('[NS] migration failed: ' . $e->getMessage() . ' | SQL: ' . substr(preg_replace('/\s+/', ' ', $stmt), 0, 180)); }

                }

            }



            try { $pdo->exec("INSERT IGNORE INTO settings (`key`,`value`) VALUES ('powered_by','<a href=\"https://vexaris.com.tr\" target=\"_blank\" rel=\"noopener\" style=\"color:#6366f1;font-weight:700;text-decoration:none;\">Vexaris</a>')"); } catch (\PDOException $e) {}

            try { $pdo->exec("INSERT IGNORE INTO settings (`key`,`value`) VALUES ('_vex_brand','Powered by <a href=\"https://vexaris.com.tr\" target=\"_blank\" rel=\"noopener\" style=\"color:#6366f1;font-weight:700;text-decoration:none;\">Vexaris</a>')"); } catch (\PDOException $e) {}



            $migrations = [

                "ALTER TABLE `products` ADD COLUMN `slug` VARCHAR(140) NOT NULL DEFAULT '' AFTER `name`",

                "ALTER TABLE `products` ADD COLUMN `short_description` VARCHAR(300) DEFAULT NULL AFTER `slug`",

                "ALTER TABLE `products` ADD COLUMN `is_active` TINYINT(1) NOT NULL DEFAULT 1 AFTER `price`",

                "ALTER TABLE `products` ADD COLUMN `image_url` VARCHAR(512) DEFAULT NULL",

                "ALTER TABLE `products` ADD COLUMN `digital_file` VARCHAR(512) DEFAULT NULL",

                "ALTER TABLE `products` ADD COLUMN `is_hidden` TINYINT(1) NOT NULL DEFAULT 0",

                "ALTER TABLE `products` ADD COLUMN `file_path` VARCHAR(512) DEFAULT NULL",

                "ALTER TABLE `products` ADD COLUMN `download_link` VARCHAR(512) DEFAULT NULL",

                "ALTER TABLE `products` ADD COLUMN `license_prefix` VARCHAR(20) DEFAULT NULL",

                "ALTER TABLE `users` ADD COLUMN `balance` DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER `email`",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('maintenance_mode','0')",

                "ALTER TABLE `users` ADD COLUMN `cookie_consent` TINYINT(1) NOT NULL DEFAULT 0 AFTER `balance`",

                "UPDATE settings SET `value`='<a href=\"https://vexaris.com.tr\" target=\"_blank\" rel=\"noopener\" style=\"color:#6366f1;font-weight:700;text-decoration:none;\">Vexaris</a>' WHERE `key`='powered_by' AND (`value` NOT LIKE '%vexaris.com.tr%' OR `value` LIKE '%noopener noreferrer%')",

                "UPDATE settings SET `value`='Powered by <a href=\"https://vexaris.com.tr\" target=\"_blank\" rel=\"noopener\" style=\"color:#6366f1;font-weight:700;text-decoration:none;\">Vexaris</a>' WHERE `key`='_vex_brand' AND (`value` NOT LIKE '%vexaris.com.tr%' OR `value` LIKE '%noopener noreferrer%')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('site_name','Vexaris')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('site_logo','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('social_discord','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('site_url','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paywant_active','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paywant_title','Paywant')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paywant_priority','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paywant_fee','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paywant_api_key','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paywant_api_secret','')",

                "ALTER TABLE `sliders` ADD COLUMN `link_url` VARCHAR(512) DEFAULT NULL AFTER `bg_color`",

                "ALTER TABLE `users` ADD COLUMN `session_version` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `oauth_github_id`",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('social_youtube','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('social_github','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('social_twitter','')",

                "ALTER TABLE `sales` ADD COLUMN `license_key` VARCHAR(80) DEFAULT NULL AFTER `price_paid`",

                "ALTER TABLE `sales` ADD COLUMN `currency` VARCHAR(4) NOT NULL DEFAULT 'TRY' AFTER `price_paid`",

                "ALTER TABLE `tickets` ADD COLUMN `category` VARCHAR(60) NOT NULL DEFAULT 'Genel' AFTER `title`",

                "ALTER TABLE `tickets` ADD COLUMN `message` TEXT AFTER `category`",

                "ALTER TABLE `announcements` ADD COLUMN `slug` VARCHAR(280) NOT NULL DEFAULT '' AFTER `title`",

                "ALTER TABLE `announcements` ADD COLUMN `image_url` VARCHAR(255) DEFAULT NULL AFTER `content`",

                "ALTER TABLE `announcements` ADD COLUMN `status` VARCHAR(20) NOT NULL DEFAULT 'draft' AFTER `image_url`",

                "CREATE TABLE IF NOT EXISTS `categories` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`name` VARCHAR(60) NOT NULL,`slug` VARCHAR(80) NOT NULL,`icon` VARCHAR(512) DEFAULT NULL,`description` VARCHAR(300) DEFAULT NULL,`sort_order` INT UNSIGNED NOT NULL DEFAULT 0,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),UNIQUE KEY `uq_categories_slug` (`slug`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",



                "CREATE TABLE IF NOT EXISTS `orders` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`user_id` INT UNSIGNED NOT NULL,`product_id` INT UNSIGNED NOT NULL,`price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,`license_key` VARCHAR(255) DEFAULT NULL,`status` VARCHAR(50) NOT NULL DEFAULT 'completed',`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_orders_user` (`user_id`),KEY `idx_orders_product` (`product_id`),CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,CONSTRAINT `fk_orders_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `legal_pages` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`slug` VARCHAR(60) NOT NULL,`title` VARCHAR(120) NOT NULL,`content` TEXT,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`id`),UNIQUE KEY `uq_legal_slug` (`slug`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "INSERT IGNORE INTO `legal_pages` (`slug`,`title`,`content`) VALUES ('cookie-policy','Çerez Politikası','# Çerez Politikası\\n\\n**{site_name}** olarak çerezler kullanıyoruz. Bu sayfa hangi çerezleri kullandığımızı ve neden kullandığımızı açıklar.\\n\\n## 1. Çerez Nedir?\\nÇerez, tarayıcınız tarafından cihazınıza kaydedilen küçük metin dosyalarıdır.\\n\\n## 2. Kullandığımız Çerezler\\n- **Zorunlu Çerezler**: Site düzgün çalışması için gereklidir.\\n- **Analitik Çerezler**: Site trafiğini anonim olarak izlememizi sağlar.\\n- **İşlevsel Çerezler**: Oturum bilgilerinizi hatırlar.\\n\\n## 3. Çerezleri Kontrol Etme\\nTarayıcı ayarlarından çerezleri silebilir veya engelleyebilirsiniz. Ancak bu durumda site bazı özellikleri çalışmayabilir.\\n\\n## 4. Güncellemeler\\nBu politika zaman zaman güncellenebilir. Güncellemeler bu sayfada yayınlanır.\\n\\n_Son güncelleme: 2024_'),('privacy-policy','Gizlilik Politikası','# Gizlilik Politikası\\n\\n**{site_name}** olarak gizliliğinize önem veriyoruz. Bu politika, kişisel verilerinizi nasıl topladığımızı, kullandığımızı ve koruduğumuzu açıklar.\\n\\n## 1. Toplanan Bilgiler\\n- Hesap oluştururken sağladığınız kullanıcı adı ve e-posta adresi\\n- Satın alma işlemlerinize ait kayıtlar\\n- Site kullanım istatistikleri (anonim)\\n\\n## 2. Bilgilerin Kullanımı\\nToplanan bilgiler şu amaçlarla kullanılır:\\n- Hesabınızı yönetmek ve size hizmet sağlamak\\n- Satın aldığınız ürünlerin lisanslarını oluşturmak\\n- Size teknik destek sağlamak\\n- Platform güncellemeleri hakkında bilgilendirme yapmak\\n\\n## 3. Bilgi Paylaşımı\\nKişisel verileriniz üçüncü taraflarla paylaşılmaz, yasal zorunluluk olmadıkça ifşa edilmez.\\n\\n## 4. Veri Güvenliği\\nVerileriniz SSL şifreleme ve güvenli sunucu altyapısı ile korunmaktadır.\\n\\n## 5. Haklarınız\\nKVKK kapsamında verilerinize erişme, düzeltme ve silme hakkına sahipsiniz.\\n\\n_Son güncelleme: 2024_'),('terms-of-service','Kullanım Şartları','# Kullanım Şartları\\n\\n**{site_name}** platformunu kullanarak aşağıdaki şartları kabul etmiş sayılırsınız.\\n\\n## 1. Hesap\\n- Hesap oluştururken doğru bilgi vermekle yükümlüsünüz.\\n- Hesabınızın güvenliğinden siz sorumlusunuz.\\n- 13 yaşından küçükler hesap oluşturamaz.\\n\\n## 2. Satın Alma\\n- Tüm satın alımlar tek seferliktir ve dijital ürünler için geçerlidir.\\n- Satın alınan ürünlerin iadesi yalnızca aktif olmayan lisans durumunda yapılır.\\n- Lisans anahtarları yalnızca bir sunucuda kullanılabilir.\\n\\n## 3. Kullanım\\n- Satın aldığınız ürünleri yeniden satamaz veya dağıtamazsınız.\\n- Platformu kötüye kullanmak yasaktır.\\n- Telif hakkı ihlalleri ciddiye alınır.\\n\\n## 4. Sorumluluk\\nPlatform, sunucu kesintilerinden veya veri kaybından sorumlu tutulamaz.\\n\\n_Son güncelleme: 2024_'),('refund-policy','İade Politikası','# İade Politikası\\n\\n**{site_name}** olarak müşteri memnuniyetine öncelik veriyoruz.\\n\\n## 1. Dijital Ürün İadeleri\\nDijital ürünler fiziksel mallar gibi iade edilemez. Ancak aşağıdaki durumlarda iade talep edebilirsiniz:\\n\\n## 2. İade Koşulları\\n- Lisans anahtarının hiç kullanılmamış olması\\n- Satın alma tarihinden itibaren 14 gün içinde başvuru yapılması\\n- Ürünün teknik olarak çalışmaması ve çözüm sağlanamaması\\n\\n## 3. İade Süreci\\n1. Destek talebi oluşturun\\n2. İade sebebinizi belirtin\\n3. Ekibimiz talebi 48 saat içinde değerlendirir\\n4. Onaylanması durumunda bakiye 3 iş günü içinde hesabınıza yansıtılır\\n\\n## 4. İstisnalar\\n- Özel yapım ürünler iade edilemez.\\n- Kampanya/paket ürünlerde kısmi iade yapılmaz.\\n\\n_Son güncelleme: 2024_')",

                "CREATE TABLE IF NOT EXISTS `permissions` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`role` VARCHAR(30) NOT NULL,`resource` VARCHAR(60) NOT NULL,PRIMARY KEY (`id`),UNIQUE KEY `uq_perm_role_resource` (`role`,`resource`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES ('admin','dashboard'),('admin','users'),('admin','products'),('admin','categories'),('admin','licenses'),('admin','coupons'),('admin','themes'),('admin','announcements'),('admin','support'),('admin','settings'),('admin','permissions'),('admin','legal'),('yonetici','dashboard'),('yonetici','users'),('yonetici','products'),('yonetici','categories'),('yonetici','licenses'),('yonetici','coupons'),('yonetici','themes'),('yonetici','announcements'),('yonetici','support'),('yonetici','settings'),('yonetici','legal'),('moderator','dashboard'),('moderator','users'),('moderator','support'),('moderator','licenses'),('destek_ekibi','dashboard'),('destek_ekibi','support')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('admin_theme','{\"mode\":\"dark\",\"accent\":\"#10b981\",\"preset\":\"gece_mavisi\"}')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('_vex_brand','Powered by <a href=\"https://vexaris.com.tr\" target=\"_blank\" rel=\"noopener\" style=\"color:#6366f1;font-weight:700;text-decoration:none;\">Vexaris</a>')",

                "ALTER TABLE `users` MODIFY COLUMN `role` VARCHAR(30) NOT NULL DEFAULT 'user'",

                "CREATE TABLE IF NOT EXISTS `subcategories` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`category_id` INT UNSIGNED NOT NULL,`name` VARCHAR(60) NOT NULL,`slug` VARCHAR(80) NOT NULL,`description` VARCHAR(300) DEFAULT NULL,`sort_order` INT UNSIGNED NOT NULL DEFAULT 0,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_subcat_category` (`category_id`),CONSTRAINT `fk_subcat_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `category_options` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`category_id` INT UNSIGNED NOT NULL,`name` VARCHAR(60) NOT NULL,`type` VARCHAR(20) NOT NULL DEFAULT 'text',`options` TEXT DEFAULT NULL,`required` TINYINT(1) NOT NULL DEFAULT 0,`sort_order` INT UNSIGNED NOT NULL DEFAULT 0,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_catopt_category` (`category_id`),CONSTRAINT `fk_catopt_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `admin_recent_pages` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`user_id` INT UNSIGNED NOT NULL,`page_key` VARCHAR(80) NOT NULL,`page_label` VARCHAR(120) NOT NULL,`page_url` VARCHAR(255) NOT NULL,`page_icon` VARCHAR(60) DEFAULT NULL,`viewed_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),UNIQUE KEY `uq_arp_user_page` (`user_id`,`page_key`),KEY `idx_arp_user_viewed` (`user_id`,`viewed_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `payment_intents` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`user_id` INT UNSIGNED NOT NULL,`order_id` VARCHAR(40) NOT NULL,`total_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,`currency` VARCHAR(4) NOT NULL DEFAULT 'TRY',`status` ENUM('pending','completed','failed','cancelled') NOT NULL DEFAULT 'pending',`payment_method` VARCHAR(20) NOT NULL DEFAULT 'shopier',`payment_id` VARCHAR(40) DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`id`),UNIQUE KEY `uq_pi_order` (`order_id`),KEY `idx_pi_user` (`user_id`),KEY `idx_pi_status` (`status`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_shopier_active','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_shopier_title','Shopier')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_shopier_currency','TRY')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_shopier_priority','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_shopier_fee','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('primary_lang','tr')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('store_currency','TRY')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_shopier_pat','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_shopier_shop_slug','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_active','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_title','PayTR')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_currency','TRY')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_priority','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_fee','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_api_key','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_secret_key','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_merchant_id','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_merchant_key','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_merchant_salt','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_test_mode','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_iyzico_active','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_iyzico_title','iyzico')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_iyzico_currency','TRY')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_iyzico_priority','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_iyzico_fee','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_iyzico_api_key','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_iyzico_secret_key','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_iyzico_test_mode','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_stripe_active','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_stripe_title','Stripe')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_stripe_currency','TRY')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_stripe_priority','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_stripe_fee','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_stripe_api_key','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_stripe_webhook_secret','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_stripe_test_mode','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('int_discord_webhook_url','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('int_discord_register','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('int_discord_order','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('int_discord_topup','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('int_discord_review','0')",

                "CREATE TABLE IF NOT EXISTS `ticket_categories` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`name` VARCHAR(60) NOT NULL,`icon` VARCHAR(512) DEFAULT NULL,`sort_order` INT UNSIGNED NOT NULL DEFAULT 0,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES ('admin','ticket_categories'),('yonetici','ticket_categories')",

                "CREATE TABLE IF NOT EXISTS `balance_log` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`user_id` INT UNSIGNED NOT NULL,`amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,`type` ENUM('payment','purchase','topup','coupon','refund','admin') NOT NULL DEFAULT 'purchase',`description` VARCHAR(255) DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_bl_user` (`user_id`),KEY `idx_bl_created` (`created_at`),CONSTRAINT `fk_bl_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "ALTER TABLE `users` ADD COLUMN `oauth_google_id` VARCHAR(255) DEFAULT NULL AFTER `balance`",

                "ALTER TABLE `users` ADD COLUMN `oauth_discord_id` VARCHAR(255) DEFAULT NULL AFTER `oauth_google_id`",

                "ALTER TABLE `users` ADD COLUMN `oauth_microsoft_id` VARCHAR(255) DEFAULT NULL AFTER `oauth_discord_id`",

                "ALTER TABLE `users` ADD COLUMN `oauth_github_id` VARCHAR(255) DEFAULT NULL AFTER `oauth_microsoft_id`",

                "CREATE TABLE IF NOT EXISTS `login_attempts` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`ip` VARCHAR(45) NOT NULL,`attempted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_la_ip` (`ip`),KEY `idx_la_time` (`attempted_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `custom_pages` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`slug` VARCHAR(140) NOT NULL,`title` VARCHAR(120) NOT NULL,`meta_description` VARCHAR(300) DEFAULT NULL,`content` MEDIUMTEXT,`status` ENUM('published','draft') NOT NULL DEFAULT 'published',`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`id`),UNIQUE KEY `uq_custom_pages_slug` (`slug`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
                "ALTER TABLE `custom_pages` ADD COLUMN `page_type` ENUM('blog','html') NOT NULL DEFAULT 'blog'",

                "CREATE TABLE IF NOT EXISTS `custom_page_views` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`page_id` INT UNSIGNED NOT NULL,`session_key` VARCHAR(80) NOT NULL,`user_id` INT UNSIGNED DEFAULT NULL,`ip` VARCHAR(45) DEFAULT NULL,`duration_sec` INT UNSIGNED NOT NULL DEFAULT 0,`entered_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`left_at` DATETIME DEFAULT NULL,PRIMARY KEY (`id`),KEY `idx_cpv_page` (`page_id`),KEY `idx_cpv_session` (`session_key`),CONSTRAINT `fk_cpv_page` FOREIGN KEY (`page_id`) REFERENCES `custom_pages` (`id`) ON DELETE CASCADE,CONSTRAINT `fk_cpv_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES ('admin','custom_pages'),('yonetici','custom_pages')",

                "ALTER TABLE `comments` ADD COLUMN `rating` TINYINT NOT NULL DEFAULT 0 AFTER `comment_text`",

                "ALTER TABLE `coupons` ADD COLUMN `grant_product_ids` TEXT NULL AFTER `reward_value`",

                "ALTER TABLE `products` ADD COLUMN `user_notice` TEXT NULL AFTER `short_description`",

                "ALTER TABLE `users` ADD COLUMN `cookie_pref` VARCHAR(10) NOT NULL DEFAULT 'pending' AFTER `cookie_consent`",

                "UPDATE `users` SET `cookie_pref`='all' WHERE `cookie_consent`=1 AND `cookie_pref`='pending'",

                "CREATE TABLE IF NOT EXISTS `references` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`name` VARCHAR(120) NOT NULL,`title` VARCHAR(160) NOT NULL DEFAULT '',`photo_url` VARCHAR(512) DEFAULT NULL,`rating` TINYINT NOT NULL DEFAULT 5,`message` TEXT,`sort_order` INT UNSIGNED NOT NULL DEFAULT 0,`is_active` TINYINT(1) NOT NULL DEFAULT 1,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_ref_active` (`is_active`,`sort_order`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('references_mode','grid')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('references_autoplay','0')",

                "INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES ('admin','references'),('yonetici','references')",

                "ALTER TABLE `products` ADD COLUMN `discount_percent` TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER `price`",

                "ALTER TABLE `products` ADD COLUMN `stock_type` VARCHAR(10) NOT NULL DEFAULT 'unlimited' AFTER `discount_percent`",

                "ALTER TABLE `products` ADD COLUMN `stock` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `stock_type`",

                "ALTER TABLE `products` ADD COLUMN `total_stock` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `stock`",

                "CREATE TABLE IF NOT EXISTS `remember_tokens` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`user_id` INT UNSIGNED NOT NULL,`token_hash` VARCHAR(64) NOT NULL,`expires_at` DATETIME NOT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),UNIQUE KEY `uq_token_hash` (`token_hash`),KEY `idx_rt_user` (`user_id`),CONSTRAINT `fk_rt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `product_stocks` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`product_id` INT UNSIGNED NOT NULL,`content` TEXT NOT NULL,`used` TINYINT(1) NOT NULL DEFAULT 0,`used_by_user` INT UNSIGNED DEFAULT NULL,`used_at` DATETIME DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_ps_product_used` (`product_id`,`used`),CONSTRAINT `fk_ps_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `faqs` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`question` VARCHAR(255) NOT NULL,`answer` TEXT NOT NULL,`sort_order` INT NOT NULL DEFAULT 0,`is_active` TINYINT(1) NOT NULL DEFAULT 1,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_faqs_sort` (`sort_order`,`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "ALTER TABLE `sales` MODIFY COLUMN `license_key` TEXT",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('mail_enabled','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('mail_smtp_host','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('mail_smtp_port','587')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('mail_smtp_user','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('mail_smtp_pass','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('mail_smtp_encryption','tls')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('mail_from_name','')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('mail_from_email','')",

                "ALTER TABLE `users` ADD COLUMN `email_verified` TINYINT(1) NOT NULL DEFAULT 0 AFTER `cookie_pref`",

                "CREATE TABLE IF NOT EXISTS `mail_templates` (`id` INT AUTO_INCREMENT PRIMARY KEY,`slug` VARCHAR(64) UNIQUE NOT NULL,`subject` VARCHAR(255) NOT NULL,`header_title` VARCHAR(160) NOT NULL DEFAULT '',`body_html` MEDIUMTEXT NOT NULL,`accent_color` VARCHAR(7) DEFAULT '#4f46e5',`logo_url` VARCHAR(255) DEFAULT NULL,`updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "ALTER TABLE `mail_templates` ADD COLUMN `header_title` VARCHAR(160) NOT NULL DEFAULT '' AFTER `subject`",

                "CREATE TABLE IF NOT EXISTS `password_resets` (`id` INT AUTO_INCREMENT PRIMARY KEY,`email` VARCHAR(255) NOT NULL,`token` VARCHAR(64) NOT NULL,`expires_at` DATETIME NOT NULL,`used` TINYINT(1) NOT NULL DEFAULT 0,`created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY `uq_pr_token` (`token`),KEY `idx_pr_email` (`email`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `email_verifications` (`id` INT AUTO_INCREMENT PRIMARY KEY,`email` VARCHAR(255) NOT NULL,`token` VARCHAR(64) NOT NULL,`expires_at` DATETIME NOT NULL,`used` TINYINT(1) NOT NULL DEFAULT 0,`created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY `uq_ev_token` (`token`),KEY `idx_ev_email` (`email`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('_vx_installed_version','1.0.0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('faqs_enabled','1')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('auto_update','0')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('loader_enabled','1')",

                "ALTER TABLE `payment_intents` ADD COLUMN `shopier_product_id` VARCHAR(80) DEFAULT NULL",

                "CREATE TABLE IF NOT EXISTS `sliders` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`content` MEDIUMTEXT NOT NULL,`bg_color` VARCHAR(7) NOT NULL DEFAULT '#6366f1',`is_active` TINYINT(1) NOT NULL DEFAULT 1,`sort_order` INT UNSIGNED NOT NULL DEFAULT 0,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_sliders_active` (`is_active`,`sort_order`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `product_versions` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`product_id` INT UNSIGNED NOT NULL,`version` VARCHAR(20) NOT NULL DEFAULT '',`summary` VARCHAR(255) NOT NULL DEFAULT '',`changelog` MEDIUMTEXT,`has_file` TINYINT(1) NOT NULL DEFAULT 1,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_pv_product` (`product_id`,`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `product_update_reads` (`user_id` INT UNSIGNED NOT NULL,`product_id` INT UNSIGNED NOT NULL,`last_seen_version_id` INT UNSIGNED NOT NULL DEFAULT 0,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`user_id`,`product_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `modules` (`slug` VARCHAR(64) NOT NULL,`enabled` TINYINT(1) NOT NULL DEFAULT 0,`version` VARCHAR(16) NOT NULL DEFAULT '1.0.0',`settings` TEXT,`sidebar` TINYINT(1) NOT NULL DEFAULT 1,`installed_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`slug`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "ALTER TABLE `modules` ADD COLUMN `sidebar` TINYINT(1) NOT NULL DEFAULT 1",

                "INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES ('admin','modules'),('yonetici','modules')",

                "INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES ('admin','stats'),('yonetici','stats')",

                "ALTER TABLE `sliders` ADD COLUMN `marquee` TINYINT(1) NOT NULL DEFAULT 0",

                "ALTER TABLE `ticket_replies` ADD COLUMN `is_seen` TINYINT(1) NOT NULL DEFAULT 0",

                "CREATE TABLE IF NOT EXISTS `theme_settings` (`theme` VARCHAR(32) NOT NULL,`setting_key` VARCHAR(80) NOT NULL,`setting_value` MEDIUMTEXT,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`theme`,`setting_key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "UPDATE `legal_pages` SET `title`='Çerez Politikası', `content`='# Çerez Politikası

**{site_name}** olarak gizliliğinize saygı duyuyoruz. Bu sayfa hangi çerezleri kullandığımızı ve bunları nasıl yönetebileceğinizi açıklar.

## 1. Çerez Nedir?

Çerez, ziyaretiniz sırasında tarayıcınıza kaydedilen küçük metin dosyalarıdır. Oturumunuzu hatırlamak ve güvenliğinizi sağlamak için kullanılır.

## 2. Kullandığımız Çerezler

- **Zorunlu Çerezler:** Oturum (vexaris_sess), güvenlik doğrulaması ve yük dengeleme için şarttır. Bunlar olmadan site çalışmaz.
- **Tercih Çerezleri:** Çerez tercihiniz (nx_cc_*) ve tema seçiminiz gibi ayarları hatırlar.
- **Analitik Çerezler:** Yalnızca izninizle çalışır, sayfa görüntüleme sayılarını anonim olarak toplar.
- **Beni Hatırla:** İsteğe bağlı giriş kalıcılığı (remember_token) için kullanılır.

## 3. Üçüncü Taraf Çerezleri

Ödeme adımında yönlendiğiniz ödeme kuruluşları ile spam koruması (Cloudflare Turnstile / reCAPTCHA) kendi çerezlerini kullanabilir. Bu çerezlerden ilgili kuruluşlar sorumludur.

## 4. Çerezleri Kontrol Etme

- Sitedeki çerez bandından **Tümünü Kabul Et** veya **Sadece Zorunlu** seçimini dilediğiniz zaman değiştirebilirsiniz.
- Tarayıcı ayarlarından çerezleri silebilir veya engelleyebilirsiniz. Zorunlu çerezleri engellerseniz giriş ve satın alma çalışmayabilir.

## 5. KVKK Aydınlatma

Çerezlerle işlenen veriler 6698 sayılı KVKK kapsamında korunur. Detay için Gizlilik Politikamıza bakın.' WHERE `slug`='cookie-policy' AND `content` LIKE '%\_Son g%' AND `content` LIKE '%2024\_%'",

                "UPDATE `legal_pages` SET `title`='Gizlilik Politikası', `content`='# Gizlilik Politikası

**{site_name}** olarak kişisel verilerinizin güvenliğine önem veriyoruz. Bu metin 6698 sayılı KVKK uyarınca aydınlatma metni niteliğindedir.

## 1. Toplanan Veriler

- **Hesap verileri:** kullanıcı adı, e-posta adresi, parola (şifreli saklanır).
- **Sipariş verileri:** satın alınan ürün, tutar, tarih ve teslim edilen lisans kayıtları.
- **Teknik kayıtlar:** IP adresi, tarayıcı bilgisi, giriş denemeleri ve hata günlükleri.
- **Destek kayıtları:** açtığınız biletler ve mesajlaşmalar.

## 2. İşleme Amaçları ve Hukuki Sebepler

Verileriniz, hesabınızı yönetmek, siparişlerinizi teslim etmek, teknik destek sağlamak ve dolandırıcılığı önlemek için işlenir (KVKK m.5: sözleşmenin kurulması ve ifası, veri sorumlusunun hukuki yükümlülüğü ve meşru menfaati).

## 3. Kart Bilgileri

Kredi kartı bilgileriniz **sunucularımıza hiçbir zaman yazılmaz**. Tüm tahsilat lisanslı ödeme kuruluşları üzerinden gerçekleşir.

## 4. Saklama Süreleri

Hesap verileri üyeliğiniz sürdükçe, sipariş ve fatura kayıtları yasal zamanaşımı süreleri boyunca saklanır. Hesabınızı kapattığınızda kişisel verileriniz anonimleştirilir veya silinir.

## 5. Paylaşım

Verileriniz pazarlama amacıyla üçüncü kişilerle paylaşılmaz. Yalnızca ödeme tahsilatı ve yasal zorunluluklar (mahkeme kararı gibi) kapsamında gerekli taraflarla paylaşılır.

## 6. Haklarınız

KVKK m.11 uyarınca verilerinize erişme, düzeltme, silme, işlenmeye itiraz etme ve zararın giderilmesini talep etme haklarına sahipsiniz. Taleplerinizi destek sistemi üzerinden iletebilirsiniz.

## 7. Güvenlik

Veriler SSL şifreleme ile taşınır, parolalar tek yönlü şifreleme ile saklanır ve yönetim paneli rol bazlı yetkilendirme ile korunur.' WHERE `slug`='privacy-policy' AND `content` LIKE '%\_Son g%' AND `content` LIKE '%2024\_%'",

                "UPDATE `legal_pages` SET `title`='Kullanım Şartları', `content`='# Kullanım Şartları

**{site_name}** platformunu kullanarak aşağıdaki şartları kabul etmiş sayılırsınız.

## 1. Hizmetin Kapsamı

Platform, e-pin, lisans anahtarı, e-kitap ve yazılım paketi gibi dijital ürünlerin satıldığı bir pazaryeridir. Tüm ürünler dijital olarak, anında teslim edilir.

## 2. Hesap

- Kayıt sırasında doğru bilgi vermekle yükümlüsünüz.
- Hesabınızın güvenliğinden siz sorumlusunuz, şifrenizi kimseyle paylaşmayın.
- 18 yaşından küçükler veli izni olmadan işlem yapamaz.

## 3. Lisans Kullanımı

- Satın aldığınız lisans **size özeldir**, yeniden satılamaz, kiralanamaz veya herkese açık paylaşılamaz.
- Aksi belirtilmedikçe her lisans tek kullanım / tek alıcı içindir.
- Lisansın kötüye kullanıldığı tespit edilirse erişiminiz askıya alınabilir.

## 4. Fiyat ve Ödeme

- Fiyatlar Türk Lirasıdır ve KDV dahildir.
- Ödeme anında tahsil edilir, ödeme onaylanmadan teslimat başlamaz.

## 5. Teslimat

- Ödeme onayı sonrası ürün **otomatik ve anında** hesabınıza tanımlanır.
- Teslimat gecikmesi yaşanırsa destek talebi açmanız yeterlidir.

## 6. Yasak Kullanım

Platformu dolandırıcılık, tersine mühendislikle koruma atlatma, spam veya yasa dışı amaçlarla kullanmak yasaktır. İhlalde hesap kapatılır ve ödenmiş tutarlar iade edilmez.

## 7. Sorumluluk Sınırı

Platform, mücbir sebepler ve üçüncü taraf hizmet kesintilerinden doğan zararlardan sorumlu tutulamaz. Sorumluluk, ilgili sipariş tutarıyla sınırlıdır.

## 8. Değişiklik ve Yürürlük

Bu şartlar güncellenebilir, güncel metin her zaman bu sayfada yayınlanır. Uyuşmazlıklarda Türkiye Cumhuriyeti kanunları uygulanır.' WHERE `slug`='terms-of-service' AND `content` LIKE '%\_Son g%' AND `content` LIKE '%2024\_%'",

                "UPDATE `legal_pages` SET `title`='İade Politikası', `content`='# İade Politikası

**{site_name}** olarak müşteri memnuniyetini ön planda tutuyoruz. Dijital ürünlerin doğası gereği iade koşulları aşağıda tanımlanmıştır.

## 1. Temel İlke

Dijital teslimat ödeme onayı anında gerçekleştiği için, **kullanılmış lisans ve indirilmiş dosyalarda cayma hakkı teknik olarak uygulanamaz**. Yine de aşağıdaki durumlarda iade yapılır.

## 2. İade Koşulları

- Lisans anahtarının **hiç kullanılmamış** olması,
- Satın alma tarihinden itibaren **14 gün** içinde başvuru yapılması,
- Ürünün teknik olarak çalışmaması ve destek ekibinin sorunu **çözememesi**.

## 3. İade Süreci

1. Destek sistemi üzerinden iade talebi oluşturun.
2. Sipariş numaranızı ve iade sebebinizi yazın.
3. Ekibimiz talebi **48 saat** içinde değerlendirir.
4. Onaylanan iadeler önce **bakiyenize**, isterseniz 3 iş günü içinde ödeme yönteminize yansıtılır.

## 4. İstisnalar

- Kullanılmış veya süresi başlatılmış lisanslar iade edilmez.
- Size özel hazırlanan ürünler iade edilmez.
- Kampanyalı paketlerde kısmi iade yapılmaz, paket bütün olarak değerlendirilir.

## 5. Ödeme Kuruluşu İadeleri

Karta iade işlemleri bankanıza bağlı olarak 2-10 iş günü içinde ekstrelere yansır. Bu süre bankalardan kaynaklanır.' WHERE `slug`='refund-policy' AND `content` LIKE '%\_Son g%' AND `content` LIKE '%2024\_%'",

                "ALTER TABLE `sliders` ADD COLUMN `speed` INT UNSIGNED NOT NULL DEFAULT 20 AFTER `marquee`",

                "ALTER TABLE `ticket_replies` ADD COLUMN `image_url` VARCHAR(512) DEFAULT NULL",

                "ALTER TABLE `payment_intents` ADD COLUMN `items_snapshot` MEDIUMTEXT DEFAULT NULL",

                "CREATE TABLE IF NOT EXISTS `rate_limits` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`scope` VARCHAR(40) NOT NULL,`ip` VARCHAR(45) NOT NULL,`attempted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_rl_scope_ip` (`scope`,`ip`),KEY `idx_rl_time` (`attempted_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `license_check_attempts` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`ip` VARCHAR(45) NOT NULL,`attempted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_lca_ip` (`ip`),KEY `idx_lca_time` (`attempted_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "CREATE TABLE IF NOT EXISTS `license_nonces` (`nonce` VARCHAR(64) NOT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`nonce`),KEY `idx_ln_time` (`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "ALTER TABLE `tickets` ADD COLUMN `updated_at` DATETIME NULL DEFAULT NULL",

                "UPDATE `tickets` SET `updated_at` = COALESCE((SELECT MAX(`created_at`) FROM `ticket_replies` WHERE `ticket_id`=`tickets`.`id`), `created_at`) WHERE `updated_at` IS NULL",

                "INSERT IGNORE INTO `permissions` (`role`,`resource`) SELECT DISTINCT `role`,'purchases' FROM `permissions` WHERE `resource`='products'",

                "INSERT IGNORE INTO `permissions` (`role`,`resource`) SELECT DISTINCT `role`,'reviews' FROM `permissions` WHERE `resource`='products'",

                "INSERT IGNORE INTO `permissions` (`role`,`resource`) SELECT DISTINCT `role`,'slider' FROM `permissions` WHERE `resource`='products'",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('email_verify_required','0')",

                "CREATE TABLE IF NOT EXISTS `roles` (`slug` VARCHAR(30) NOT NULL,`name_tr` VARCHAR(60) NOT NULL DEFAULT '',`name_en` VARCHAR(60) NOT NULL DEFAULT '',`color` VARCHAR(7) NOT NULL DEFAULT '#818cf8',`icon` VARCHAR(512) NOT NULL DEFAULT 'fa-solid fa-user',`rank` INT NOT NULL DEFAULT 0,`is_system` TINYINT(1) NOT NULL DEFAULT 0,PRIMARY KEY (`slug`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "INSERT IGNORE INTO `roles` (`slug`,`name_tr`,`name_en`,`color`,`icon`,`rank`,`is_system`) VALUES ('superadmin','Süper Admin','Super Admin','#7c3aed','fa-solid fa-user-shield',200,1)",

                "INSERT IGNORE INTO `roles` (`slug`,`name_tr`,`name_en`,`color`,`icon`,`rank`,`is_system`) VALUES ('admin','Admin','Admin','#f43f5e','fa-solid fa-crown',100,1),('yonetici','Yönetici','Manager','#eab308','fa-solid fa-user-tie',30,1),('moderator','Moderatör','Moderator','#818cf8','fa-solid fa-shield-halved',20,1),('destek_ekibi','Destek Ekibi','Support Team','#22d3ee','fa-solid fa-headset',10,1),('user','Üye','Member','#4ade80','fa-solid fa-user',0,1)",

                "CREATE TABLE IF NOT EXISTS `audit_logs` (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,`user_id` INT UNSIGNED NOT NULL DEFAULT 0,`username` VARCHAR(32) NOT NULL DEFAULT '',`user_role` VARCHAR(30) NOT NULL DEFAULT '',`action` VARCHAR(20) NOT NULL DEFAULT 'update',`resource` VARCHAR(60) NOT NULL DEFAULT '',`resource_id` INT UNSIGNED NOT NULL DEFAULT 0,`label` VARCHAR(255) NOT NULL DEFAULT '',`url` VARCHAR(255) NOT NULL DEFAULT '',`ip` VARCHAR(45) NOT NULL DEFAULT '',`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_al_user` (`user_id`),KEY `idx_al_res` (`resource`,`resource_id`),KEY `idx_al_time` (`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

                "INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES ('admin','audit-logs'),('yonetici','audit-logs')",

                "INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('ai_system_prompt','')",

                "INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES ('superadmin','ai_assistant'),('admin','ai_assistant'),('yonetici','ai_assistant')",

            ];

            foreach ($migrations as $m) {

                try { $pdo->exec($m); } catch (\PDOException $e) {}

            }

            try {
                $hasIdx = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='sales' AND INDEX_NAME='idx_sales_purchased'")->fetchColumn();
                if ((int)$hasIdx === 0) $pdo->exec("ALTER TABLE `sales` ADD KEY `idx_sales_purchased` (`purchased_at`)");
            } catch (\PDOException $e) {}



            $seedTemplates = [

                'password_reset'      => ['subject' => 'Şifre Sıfırlama', 'body_html' => '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f1f5f9;padding:24px 16px;"><tr><td align="center"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:550px;width:100%;background-color:#ffffff;border-radius:12px;overflow:hidden;font-family:Arial,Helvetica,sans-serif;"><tr><td align="center" style="background-color:{accent_color};padding:28px 24px;">{logo}<h1 style="margin:0;color:#ffffff;font-size:20px;font-weight:700;">Şifre Sıfırlama</h1></td></tr><tr><td style="padding:32px 28px;"><p style="margin:0 0 16px;color:#334155;font-size:14px;line-height:1.6;">Merhaba <strong>{user_name}</strong>,</p><p style="margin:0 0 24px;color:#334155;font-size:14px;line-height:1.6;">Hesabınız için şifre sıfırlama talebi aldık. Aşağıdaki butona tıklayarak yeni şifrenizi belirleyebilirsiniz. Bu isteği siz yapmadıysanız bu e-postayı yok sayabilirsiniz, şifreniz değişmez.</p><table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;"><tr><td align="center" style="background-color:{accent_color};border-radius:8px;"><a href="{reset_link}" style="display:inline-block;padding:12px 28px;color:#ffffff;text-decoration:none;font-size:14px;font-weight:700;">Şifremi Sıfırla</a></td></tr></table><p style="margin:24px 0 0;color:#94a3b8;font-size:12px;line-height:1.6;">Buton çalışmazsa şu adresi tarayıcınıza yapıştırın:<br><a href="{reset_link}" style="color:{accent_color};word-break:break-all;">{reset_link}</a></p></td></tr><tr><td align="center" style="padding:20px 24px;background-color:#f8fafc;border-top:1px solid #e2e8f0;"><p style="margin:0;color:#94a3b8;font-size:12px;">© {site_name} — Tüm hakları saklıdır.</p></td></tr></table></td></tr></table>'],

                'account_activation'  => ['subject' => 'Hesabınızı Doğrulayın', 'body_html' => '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f1f5f9;padding:24px 16px;"><tr><td align="center"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:550px;width:100%;background-color:#ffffff;border-radius:12px;overflow:hidden;font-family:Arial,Helvetica,sans-serif;"><tr><td align="center" style="background-color:{accent_color};padding:28px 24px;">{logo}<h1 style="margin:0;color:#ffffff;font-size:20px;font-weight:700;">Hesabınızı Doğrulayın</h1></td></tr><tr><td style="padding:32px 28px;"><p style="margin:0 0 16px;color:#334155;font-size:14px;line-height:1.6;">Merhaba <strong>{user_name}</strong>,</p><p style="margin:0 0 24px;color:#334155;font-size:14px;line-height:1.6;">Aramıza hoş geldiniz! Hesabınızı aktifleştirmek için aşağıdaki butona tıklayarak e-posta adresinizi doğrulayın.</p><table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;"><tr><td align="center" style="background-color:{accent_color};border-radius:8px;"><a href="{verification_link}" style="display:inline-block;padding:12px 28px;color:#ffffff;text-decoration:none;font-size:14px;font-weight:700;">Hesabımı Doğrula</a></td></tr></table><p style="margin:24px 0 0;color:#94a3b8;font-size:12px;line-height:1.6;">Buton çalışmazsa şu adresi tarayıcınıza yapıştırın:<br><a href="{verification_link}" style="color:{accent_color};word-break:break-all;">{verification_link}</a></p></td></tr><tr><td align="center" style="padding:20px 24px;background-color:#f8fafc;border-top:1px solid #e2e8f0;"><p style="margin:0;color:#94a3b8;font-size:12px;">© {site_name} — Tüm hakları saklıdır.</p></td></tr></table></td></tr></table>'],

            ];

            foreach ($seedTemplates as $slug => $tpl) {

                try {

                    $chk = $pdo->prepare('SELECT COUNT(*) FROM mail_templates WHERE slug=?');

                    $chk->execute([$slug]);

                    if ((int)$chk->fetchColumn() === 0) {

                        $ins = $pdo->prepare('INSERT INTO mail_templates (slug,subject,body_html) VALUES (?,?,?)');

                        $ins->execute([$slug, $tpl['subject'], $tpl['body_html']]);

                    }

                } catch (\PDOException $e) {}

            }



            // v2 seed: yeni premium şablonlar (kullanıcının yüklediği HTML'ler) + header_title + accent

            if (function_exists('mail_template_defaults')) {

                try {

                    $v2flag = $pdo->query("SELECT `value` FROM settings WHERE `key`='mail_templates_seeded_v2'")->fetchColumn();

                    if ($v2flag !== '1') {

                        $v2tbl = false;

                        try { $v2tbl = (bool)$pdo->query("SHOW TABLES LIKE 'mail_templates'")->fetchColumn(); } catch (\PDOException $e2) {}

                        if ($v2tbl) {

                            foreach (['password_reset','account_activation'] as $slug) {

                                $def = mail_template_defaults($slug);

                                if (!$def) continue;

                                $up = $pdo->prepare('UPDATE mail_templates SET subject=?, header_title=?, body_html=?, accent_color=?, logo_url=NULL WHERE slug=?');

                                $up->execute([$def['subject'], $def['header_title'], $def['body_html'], $def['accent_color'], $slug]);

                            }

                            $pdo->exec("INSERT INTO settings (`key`,`value`) VALUES ('mail_templates_seeded_v2','1') ON DUPLICATE KEY UPDATE `value`='1'");

                        }

                    }

                } catch (\PDOException $e) { error_log('[Vexaris] mail_templates v2 seed: '.$e->getMessage()); }

            }

        }

    } catch (PDOException $e) {

        error_log('[Vexaris] DB bağlantı hatası: ' . $e->getMessage());

        $pdo = null;

    }



    return $pdo;

}

function faqs_fetch(?\PDO $db = null): array {
    $db = $db ?? nexus_db();
    if (!$db) return [];
    try {
        $st = $db->query("SELECT * FROM faqs WHERE is_active=1 ORDER BY sort_order ASC, id ASC");
        return $st->fetchAll();
    } catch (\Throwable $e) { return []; }
}

