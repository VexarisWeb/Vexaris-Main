<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

function discord_last_error(): string {
    return $GLOBALS['_discord_last_error'] ?? '';
}

function discord_footer_text(?PDO $db): string {
    $footerTxt = 'Vexaris Bildirim';
    try {
        if ($db) {
            $stF = $db->prepare("SELECT `value` FROM settings WHERE `key`='embed_text' LIMIT 1");
            $stF->execute(); $fv = $stF->fetchColumn();
            if (!($fv && trim((string)$fv) !== '')) {
                $st2 = $db->prepare("SELECT `value` FROM settings WHERE `key`='footer_copyright' LIMIT 1");
                $st2->execute(); $fv = $st2->fetchColumn();
            }
            if ($fv && trim((string)$fv) !== '') $footerTxt = mb_substr(trim(strip_tags(html_entity_decode((string)$fv, ENT_QUOTES, 'UTF-8'))), 0, 100);
        }
    } catch (\Exception $e) {}
    return $footerTxt;
}

function discord_curl_ips(): array {
    return ['162.159.135.232', '162.159.136.232', '162.159.137.232', '162.159.138.232', '162.159.128.233'];
}

function discord_curl_attempt(string $url, string $body, bool $pinDns): array {
    $opts = [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4,
    ];
    if ($pinDns) {
        $host = parse_url($url, PHP_URL_HOST) ?: 'discord.com';
        $port = ((int)parse_url($url, PHP_URL_PORT)) ?: 443;
        $opts[CURLOPT_RESOLVE] = [$host . ':' . $port . ':' . implode(',', discord_curl_ips())];
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, $opts);
    $res  = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($res !== false && $code >= 200 && $code < 300) return ['ok' => true];
    if ($res !== false) return ['ok' => false, 'http' => $code, 'body' => (string)$res];
    return ['ok' => false, 'err' => $err];
}

function discord_post(string $url, array $payload): bool {
    $GLOBALS['_discord_last_error'] = '';
    $body = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($body === false) { $GLOBALS['_discord_last_error'] = __('bdisc.json_err'); return false; }

    if (function_exists('curl_init')) {
        $err = '';
        for ($try = 0; $try < 4; $try++) {
            if ($try > 0) usleep(350000);
            $pinned = ($try === 3);
            $r = discord_curl_attempt($url, $body, $pinned);
            if (!empty($r['ok'])) { $GLOBALS['_discord_last_error'] = ''; return true; }
            if (isset($r['http'])) {
                $GLOBALS['_discord_last_error'] = 'HTTP ' . (int)$r['http'] . ': ' . mb_substr(strip_tags((string)($r['body'] ?? '')), 0, 300);
                return false;
            }
            $err = (string)($r['err'] ?? '');
        }
        $GLOBALS['_discord_last_error'] = __('bdisc.curl_err', ['e' => $err]);
    } elseif (ini_get('allow_url_fopen')) {
        $GLOBALS['_discord_last_error'] = __('bdisc.curl_off');
    } else {
        $GLOBALS['_discord_last_error'] = __('bdisc.both_off');
        return false;
    }

    if (ini_get('allow_url_fopen')) {
        $prev = $GLOBALS['_discord_last_error'];
        $ctx = stream_context_create(['http' => [
            'method'  => 'POST',
            'header'  => 'Content-Type: application/json',
            'content' => $body,
            'timeout' => 8,
            'ignore_errors' => true,
        ]]);
        $res  = @file_get_contents($url, false, $ctx);
        $code = 0;
        foreach ($http_response_header ?? [] as $h) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $h, $m)) $code = (int)$m[1];
        }
        if ($res !== false && $code >= 200 && $code < 300) return true;
        if ($res === false) {
            $GLOBALS['_discord_last_error'] = trim($prev . ' ' . __('bdisc.http_fail'));
            return false;
        }
        $GLOBALS['_discord_last_error'] = 'HTTP ' . $code . ': ' . mb_substr(strip_tags((string)$res), 0, 300);
        return false;
    }

    $GLOBALS['_discord_last_error'] .= __('bdisc.no_alt');
    return false;
}

function discord_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int_discord_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[discord] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function discord_is_ready(\PDO $db): bool {
    $cfg = discord_settings($db);
    $url = trim((string)($cfg['int_discord_webhook_url'] ?? ''));
    return $url !== '' && (strncmp($url, 'https://discord.com/api/webhooks/', 33) === 0 || strncmp($url, 'https://discordapp.com/api/webhooks/', 34) === 0);
}

function discord_notify(\PDO $db, string $event, string $title, string $description = '', array $fields = [], string $color = '5793549'): bool {
    if (function_exists('feature_active') && !feature_active('discord_integration')) return false;
    $cfg = discord_settings($db);
    $url = trim((string)($cfg['int_discord_webhook_url'] ?? ''));
    if ($url === '') return false;
    if (((string)($cfg['int_discord_' . $event] ?? '0')) !== '1') return false;

    $embed = [
        'title'       => mb_substr($title, 0, 256),
        'description' => mb_substr($description, 0, 4096),
        'color'       => max(0, min(16777215, (int)$color)),
        'timestamp'   => gmdate('c'),
        'footer'      => ['text' => discord_footer_text($db)],
    ];
    if (!empty($fields)) {
        $embed['fields'] = [];
        foreach ($fields as $name => $val) {
            $embed['fields'][] = [
                'name'   => mb_substr((string)$name, 0, 256),
                'value'  => mb_substr((string)$val, 0, 1024),
                'inline' => true,
            ];
        }
    }

    return discord_post($url, ['embeds' => [$embed]]);
}

function discord_send_test(string $url): bool {
    $pdo = function_exists('nexus_db') ? nexus_db() : null;
    $embed = [
        'title'       => __('bdisc.test_title'),
        'description' => __('bdisc.test_desc'),
        'color'       => 9421797,
        'timestamp'   => gmdate('c'),
        'footer'      => ['text' => discord_footer_text($pdo)],
    ];
    return discord_post($url, ['embeds' => [$embed]]);
}
