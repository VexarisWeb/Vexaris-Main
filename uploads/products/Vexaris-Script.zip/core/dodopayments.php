<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

function dodopayments_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_dodopayments_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[dodopayments] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function dodopayments_test_mode(\PDO $db): bool {
    $cfg = dodopayments_settings($db);
    return ($cfg['payment_dodopayments_test_mode'] ?? '0') === '1';
}

function dodopayments_api_base(\PDO $db): string {
    return dodopayments_test_mode($db) ? 'https://test.dodopayments.com' : 'https://live.dodopayments.com';
}

function dodopayments_api_key(\PDO $db): string {
    $cfg = dodopayments_settings($db);
    return trim((string)($cfg['payment_dodopayments_api_key'] ?? ''));
}

function dodopayments_webhook_secret(\PDO $db): string {
    $cfg = dodopayments_settings($db);
    return trim((string)($cfg['payment_dodopayments_webhook_secret'] ?? ''));
}

function dodopayments_product_id(\PDO $db): string {
    $cfg = dodopayments_settings($db);
    return trim((string)($cfg['payment_dodopayments_product_id'] ?? ''));
}

function dodopayments_currency(\PDO $db): string {
    $cfg = dodopayments_settings($db);
    $c = strtoupper(trim((string)($cfg['payment_dodopayments_currency'] ?? 'TRY')));
    return in_array($c, ['TRY', 'USD', 'EUR'], true) ? $c : 'TRY';
}

function dodopayments_is_ready(\PDO $db): bool {
    $s = dodopayments_settings($db);
    return !empty($s['payment_dodopayments_api_key']) && !empty($s['payment_dodopayments_webhook_secret'])
        && !empty($s['payment_dodopayments_product_id']) && ($s['payment_dodopayments_active'] ?? '0') === '1';
}

function dodopayments_request(\PDO $db, string $method, string $path, $body = null): array {
    $key = dodopayments_api_key($db);
    if ($key === '') throw new \RuntimeException('DodoPayments API anahtarı yapılandırılmamış.');
    $headers = ['Authorization: Bearer ' . $key, 'Accept: application/json'];
    $payload = null;
    if ($body !== null) {
        $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($payload === false) throw new \RuntimeException('DodoPayments isteği hazırlanamadı.');
        $headers[] = 'Content-Type: application/json';
    }
    $ch = curl_init(dodopayments_api_base($db) . $path);
    $opts = [CURLOPT_CUSTOMREQUEST => strtoupper($method), CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_HTTPHEADER => $headers];
    if ($payload !== null) $opts[CURLOPT_POSTFIELDS] = $payload;
    curl_setopt_array($ch, $opts);
    $resp = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) throw new \RuntimeException('DodoPayments bağlantı hatası: ' . $err);
    $data = json_decode((string)$resp, true);
    if ($code < 200 || $code >= 300) {
        $msg = is_array($data) ? (string)($data['message'] ?? json_encode($data, JSON_UNESCAPED_UNICODE)) : substr((string)$resp, 0, 200);
        throw new \RuntimeException('DodoPayments API hatası (HTTP ' . $code . '): ' . mb_substr($msg, 0, 200));
    }
    if (!is_array($data)) throw new \RuntimeException('DodoPayments yanıtı çözümlenemedi (HTTP ' . $code . ').');
    return $data;
}

function dodopayments_minor(float $total): int {
    $minor = (int)round($total * 100);
    if ($minor <= 0) throw new \RuntimeException('DodoPayments ile en az 1,00 tutarında ödeme alınabilir.');
    return $minor;
}

function dodopayments_min_check(float $total, string $cur): void {
    $mins = ['TRY' => 10.0, 'USD' => 1.0, 'EUR' => 1.0];
    $floor = $mins[$cur] ?? 10.0;
    if ($total < $floor) throw new \RuntimeException('DodoPayments minimum tutarın altında: ' . $cur . ' ' . $floor);
}

function dodopayments_return_url(string $orderId): string {
    if (function_exists('site_base_url')) {
        try {
            $b = site_base_url(function_exists('nexus_db') ? nexus_db() : null);
            if ($b !== '') return rtrim($b, '/') . '/callback/dodopayments.php?order_id=' . urlencode($orderId);
        } catch (\Throwable $e) {}
    }
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    if (!preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) $host = 'localhost';
    $scheme = function_exists('request_is_https') ? (request_is_https() ? 'https' : 'http') : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http');
    return $scheme . '://' . $host . '/callback/dodopayments.php?order_id=' . urlencode($orderId);
}

function dodopayments_create_checkout(\PDO $db, float $total, string $orderId, string $email = '', string $name = ''): array {
    if (!dodopayments_is_ready($db)) throw new \RuntimeException('DodoPayments aktif değil.');
    if ($orderId === '') throw new \RuntimeException('Sipariş numarası boş olamaz.');
    $total = round($total, 2);
    $cur = dodopayments_currency($db);
    dodopayments_min_check($total, $cur);
    $productId = dodopayments_product_id($db);
    $locale = function_exists('current_lang') ? (string)current_lang() : 'tr';
    if (!in_array($locale, ['tr', 'en'], true)) $locale = 'en';
    $customer = [];
    if ($email !== '') $customer['email'] = mb_substr($email, 0, 100);
    if ($name !== '') $customer['name'] = mb_substr($name, 0, 100);
    $body = [
        'product_cart' => [[
            'product_id' => $productId,
            'quantity' => 1,
            'amount' => dodopayments_minor($total),
        ]],
        'billing_currency' => $cur,
        'return_url' => dodopayments_return_url($orderId),
        'metadata' => ['order_id' => mb_substr($orderId, 0, 100)],
        'customization' => ['force_language' => $locale],
        'feature_flags' => ['allow_currency_selection' => false, 'redirect_immediately' => true],
    ];
    if (!empty($customer)) $body['customer'] = $customer;
    $sess = dodopayments_request($db, 'POST', '/checkouts', $body);
    $sessId = (string)($sess['session_id'] ?? '');
    $url = (string)($sess['checkout_url'] ?? '');
    if ($sessId === '' || $url === '') throw new \RuntimeException('DodoPayments ödeme bağlantısı oluşturulamadı.');
    return ['checkout_url' => $url, 'session_id' => $sessId];
}

function dodopayments_verify_webhook(\PDO $db, string $raw, array $headers) {
    $secret = dodopayments_webhook_secret($db);
    if ($secret === '' || $raw === '') return false;
    $h = [];
    foreach ($headers as $k => $v) $h[strtolower((string)$k)] = (string)$v;
    $msgId = trim((string)($h['webhook-id'] ?? ''));
    $msgTs = trim((string)($h['webhook-timestamp'] ?? ''));
    $msgSig = trim((string)($h['webhook-signature'] ?? ''));
    if ($msgId === '' || $msgTs === '' || $msgSig === '') return false;
    if (abs(time() - (int)$msgTs) > 300) return false;
    $key = $secret;
    if (strncmp($key, 'whsec_', 6) === 0) $key = substr($key, 6);
    $rawKey = base64_decode($key, true);
    if ($rawKey === false) return false;
    $calc = base64_encode(hash_hmac('sha256', $msgId . '.' . $msgTs . '.' . $raw, $rawKey, true));
    $ok = false;
    foreach (preg_split('/\s+/', $msgSig) as $part) {
        $part = trim((string)$part);
        if (strncmp($part, 'v1,', 3) === 0) $part = substr($part, 3);
        if ($part !== '' && hash_equals($calc, $part)) { $ok = true; break; }
    }
    if (!$ok) return false;
    $event = json_decode($raw, true);
    if (!is_array($event) || !isset($event['type'], $event['data'])) return false;
    return $event;
}

function dodopayments_complete_intent(\PDO $db, array $intent, string $paymentRef = ''): void {
    if ($paymentRef !== '') {
        $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
           ->execute([substr($paymentRef, 0, 40), $intent['id']]);
    } else {
        $db->prepare("UPDATE payment_intents SET status='completed' WHERE id=?")->execute([$intent['id']]);
    }

    $uid       = (int)$intent['user_id'];
    $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);
    $orderId   = (string)$intent['order_id'];
    $cur       = strtoupper((string)($intent['currency'] ?? 'TRY'));

    if (strncmp($orderId, 'TOPUP-', 6) === 0) {
        $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
        $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'DodoPayments']) . '",NOW())')->execute([$uid, $creditAmt, 'topup']);
        $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
        $uStmt->execute([$uid]);
        $uInfo = $uStmt->fetch();
        discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body'), [
            __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
            __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
            __('bsupp.f_method')    => 'DodoPayments',
        ], 16766720);
        return;
    }

    require_once ROOT_PATH . '/core/purchase.php';
    [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);
    if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);

    $done = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
    purchase_finish($db, $uid, $done['total_paid'], 'DodoPayments', 'payment', $snapCoupon, $done['product_ids'] ?? null);

    $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
    $uStmt->execute([$uid]);
    $uInfo = $uStmt->fetch();
    discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body'), [
        __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
        __('bsupp.f_products')   => implode(', ', $done['product_names']),
        __('bsupp.f_amount')     => number_format($done['total_paid'], 2, ',', '.') . ' ' . $cur,
        __('bsupp.f_method')    => 'DodoPayments',
    ], 5763719);
}

function dodopayments_test_connection(\PDO $db): void {
    if (!dodopayments_is_ready($db)) throw new \RuntimeException('API anahtarı yapılandırılmamış.');
    dodopayments_request($db, 'GET', '/products?limit=1');
}
