<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
function fx_supported(): array {
    return ['TRY', 'USD', 'EUR'];
}
function store_currency(): string {
    static $c = null;
    if ($c !== null) return $c;
    $c = 'TRY';
    try {
        $db = function_exists('nexus_db') ? nexus_db() : null;
        if ($db) {
            $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='store_currency' LIMIT 1");
            $st->execute();
            $v = strtoupper(trim((string)($st->fetchColumn() ?? '')));
            if (in_array($v, fx_supported(), true)) $c = $v;
        }
    } catch (\Throwable $e) {}
    return $c;
}
function store_name(\PDO $db): string {
    try {
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='site_name' LIMIT 1");
        $st->execute();
        $n = trim((string)($st->fetchColumn() ?? ''));
        if ($n !== '') return mb_substr(strip_tags($n), 0, 80);
    } catch (\Throwable $e) {}
    return 'Vexaris';
}
function gateway_topup_title(\PDO $db, float $total, ?string $cur = null): string {
    return __('bshop.topup_no', ['store' => store_name($db), 'amount' => fmt_money_short($total, $cur)]);
}
function fx_rates(bool $forceRefresh = false): array {
    static $m = [];
    $today = gmdate('Y-m-d');
    $ck = $forceRefresh ? 'force' : 'cache';
    if (isset($m[$ck])) return $m[$ck];
    $out = ['base' => 'TRY', 'rates' => ['TRY' => 1.0], 'ts' => 0, 'stale' => true];
    try {
        $db = function_exists('nexus_db') ? nexus_db() : null;
        if ($db) {
            $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='fx_rates' LIMIT 1");
            $st->execute();
            $raw = (string)($st->fetchColumn() ?? '');
            if ($raw !== '') {
                $d = json_decode($raw, true);
                if (is_array($d) && isset($d['rates']) && is_array($d['rates'])) {
                    foreach ($d['rates'] as $k => $v) {
                        $kk = strtoupper((string)$k);
                        if (preg_match('/^[A-Z]{3,4}$/', $kk) && (float)$v > 0) $out['rates'][$kk] = (float)$v;
                    }
                    $out['rates']['TRY'] = 1.0;
                    $out['ts'] = (int)($d['ts'] ?? 0);
                }
            }
        }
    } catch (\Throwable $e) {}
    $ttl = 6 * 3600;
    if (!$forceRefresh && $out['ts'] > 0 && (time() - $out['ts']) < $ttl && isset($out['rates']['USD'])) {
        $out['stale'] = false;
        $m[$ck] = $out;
        return $out;
    }
    $fresh = fx_fetch_rates($today);
    if ($fresh !== null) {
        $out['rates'] = $fresh;
        $out['rates']['TRY'] = 1.0;
        $out['ts'] = time();
        $out['stale'] = false;
        try {
            $db = function_exists('nexus_db') ? nexus_db() : null;
            if ($db) {
                $payload = json_encode(['base' => 'TRY', 'rates' => $out['rates'], 'ts' => $out['ts']]);
                $st = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('fx_rates',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
                $st->execute([$payload]);
            }
        } catch (\Throwable $e) {}
    }
    $m[$ck] = $out;
    return $out;
}
function fx_fetch_rates(string $date): ?array {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) return null;
    $urls = [
        'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@' . $date . '/v1/currencies/try.min.json',
        'https://' . $date . '.currency-api.pages.dev/v1/currencies/try.min.json',
    ];
    foreach ($urls as $u) {
        try {
            $ctx = stream_context_create(['http' => ['method' => 'GET', 'timeout' => 5, 'header' => "User-Agent: VexarisFX/1.0\r\nAccept: application/json\r\n"]]);
            $raw = @file_get_contents($u, false, $ctx);
            if (!is_string($raw) || $raw === '') continue;
            $d = json_decode($raw, true);
            if (!is_array($d) || !isset($d['try']) || !is_array($d['try'])) continue;
            $map = [];
            foreach ($d['try'] as $k => $v) {
                $kk = strtoupper((string)$k);
                if (preg_match('/^[A-Z]{3,4}$/', $kk) && (float)$v > 0) $map[$kk] = (float)$v;
            }
            if (isset($map['USD'])) return $map;
        } catch (\Throwable $e) {}
    }
    return null;
}
function fx_convert(float $amount, string $from, string $to): float {
    $from = strtoupper($from);
    $to = strtoupper($to);
    if ($from === $to) return round($amount, 2);
    $r = fx_rates();
    $toTry = static function (float $a, string $c) use ($r): float {
        if ($c === 'TRY' || $c === 'TL') return $a;
        $rate = $r['rates'][$c] ?? 0.0;
        if ($rate <= 0) return $a;
        return $a / $rate;
    };
    $try = $toTry($amount, $from);
    if ($to === 'TRY' || $to === 'TL') return round($try, 2);
    $rate = $r['rates'][$to] ?? 0.0;
    if ($rate <= 0) return round($amount, 2);
    return round($try * $rate, 2);
}
function fx_symbol(string $cur): string {
    $c = strtoupper($cur);
    if ($c === 'USD') return '$';
    if ($c === 'EUR') return '€';
    return '₺';
}
function fmt_money(float $amount, ?string $cur = null): string {
    $c = $cur === null ? store_currency() : strtoupper($cur);
    if ($c === 'USD') return '$' . number_format($amount, 2, '.', ',');
    if ($c === 'EUR') return number_format($amount, 2, ',', '.') . ' €';
    return '₺' . number_format($amount, 2, ',', '.');
}
function fx_is_stale(): bool {
    return fx_rates()['stale'];
}
function topup_min_amount(): float {
    $c = store_currency();
    if ($c === 'USD' || $c === 'EUR') return 1.0;
    return 10.0;
}
function fmt_money_short(float $amount, ?string $cur = null): string {
    $c = $cur === null ? store_currency() : strtoupper($cur);
    $sym = fx_symbol($c);
    $t = rtrim(rtrim(number_format($amount, 2, '.', ''), '0'), '.');
    if ($c === 'EUR') return $t . ' ' . $sym;
    return $sym . $t;
}
function fx_migrate_currency(\PDO $db, string $from, string $to): array {
    $from = strtoupper($from);
    $to = strtoupper($to);
    if ($from === $to) return ['ok' => true, 'rate' => 1.0];
    if (!in_array($from, fx_supported(), true) || !in_array($to, fx_supported(), true)) return ['ok' => false, 'rate' => 0.0];
    $r = fx_rates(true);
    $toTry = static function (float $a, string $c) use ($r): float {
        if ($c === 'TRY') return $a;
        $rate = $r['rates'][$c] ?? 0.0;
        if ($rate <= 0) return -1.0;
        return $a / $rate;
    };
    $try = $toTry(1.0, $from);
    if ($try < 0) return ['ok' => false, 'rate' => 0.0];
    if ($to === 'TRY') {
        $factor = $try;
    } else {
        $rate = $r['rates'][$to] ?? 0.0;
        if ($rate <= 0) return ['ok' => false, 'rate' => 0.0];
        $factor = $try * $rate;
    }
    if (!($factor > 0)) return ['ok' => false, 'rate' => 0.0];
    try {
        $db->beginTransaction();
        $db->prepare("UPDATE products SET price = ROUND(price * ?, 2)")->execute([$factor]);
        $uids = $db->query("SELECT id, balance FROM users WHERE balance <> 0")->fetchAll();
        $upU = $db->prepare("UPDATE users SET balance = ? WHERE id = ?");
        $upL = $db->prepare("INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,'admin',?,NOW())");
        foreach ($uids as $u) {
            $newB = round((float)$u['balance'] * $factor, 2);
            $upU->execute([$newB, (int)$u['id']]);
            $upL->execute([(int)$u['id'], round($newB - (float)$u['balance'], 2), __('bshop.fx_log', ['from' => $from, 'to' => $to, 'rate' => $factor])]);
        }
        $db->commit();
    } catch (\Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        return ['ok' => false, 'rate' => 0.0];
    }
    return ['ok' => true, 'rate' => $factor];
}
function fx_to_store(float $amount, string $fromCur): float {
    $fromCur = strtoupper(trim($fromCur));
    if (!function_exists('store_currency')) return round($amount, 2);
    $to = store_currency();
    if ($fromCur === '' || $fromCur === $to) return round($amount, 2);
    return fx_convert($amount, $fromCur, $to);
}
function fx_js_config(): array {
    $c = store_currency();
    if ($c === 'USD') return ['sym' => '$', 'pre' => true, 'dec' => '.', 'thou' => ',', 'sp' => ''];
    if ($c === 'EUR') return ['sym' => '€', 'pre' => false, 'dec' => ',', 'thou' => '.', 'sp' => ' '];
    return ['sym' => '₺', 'pre' => true, 'dec' => ',', 'thou' => '.', 'sp' => ''];
}
