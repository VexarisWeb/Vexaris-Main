<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
if (!function_exists('gateway_ready_list')) {

function gateway_ready_list(PDO $db): array {

    if (!function_exists('paytr_is_ready'))    require_once ROOT_PATH . '/core/paytr.php';

    if (!function_exists('iyzico_is_ready'))   require_once ROOT_PATH . '/core/iyzico.php';

    if (!function_exists('stripe_is_ready'))   require_once ROOT_PATH . '/core/stripe.php';

    if (!function_exists('paypal_is_ready'))   require_once ROOT_PATH . '/core/paypal.php';

    if (!function_exists('bitpay_is_ready'))   require_once ROOT_PATH . '/core/bitpay.php';

    if (!function_exists('crypt_is_ready'))    require_once ROOT_PATH . '/core/crypt.php';

    if (!function_exists('paywant_is_ready'))  require_once ROOT_PATH . '/core/paywant.php';

    if (!function_exists('whop_is_ready'))     require_once ROOT_PATH . '/core/whop.php';

    if (!function_exists('paddle_is_ready'))   require_once ROOT_PATH . '/core/paddle.php';

    if (!function_exists('lemonsqueezy_is_ready')) require_once ROOT_PATH . '/core/lemonsqueezy.php';

    if (!function_exists('dodopayments_is_ready')) require_once ROOT_PATH . '/core/dodopayments.php';

    $list = [];

    try {

        $cfg = [];

        $st = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_%'");

        foreach ($st->fetchAll() as $r) $cfg[$r['key']] = $r['value'];

    } catch (\Throwable $e) { return []; }

    if ((($cfg['payment_shopier_active'] ?? '0') === '1') && !empty($cfg['payment_shopier_pat'] ?? '') && !empty($cfg['payment_shopier_shop_slug'] ?? '') && !empty($cfg['payment_shopier_osb_username'] ?? '') && !empty($cfg['payment_shopier_osb_password'] ?? '')) $list[] = 'shopier';

    if (function_exists('paytr_is_ready') && paytr_is_ready($db)) $list[] = 'paytr';

    if (function_exists('iyzico_is_ready') && iyzico_is_ready($db)) $list[] = 'iyzico';

    if (function_exists('stripe_is_ready') && stripe_is_ready($db)) $list[] = 'stripe';

    if (function_exists('paypal_is_ready') && paypal_is_ready($db)) $list[] = 'paypal';

    if (function_exists('bitpay_is_ready') && bitpay_is_ready($db)) $list[] = 'bitpay';

    if (function_exists('crypt_is_ready') && crypt_is_ready($db)) $list[] = 'crypt';

    if (function_exists('paywant_is_ready') && paywant_is_ready($db)) $list[] = 'paywant';

    if (function_exists('whop_is_ready') && whop_is_ready($db)) $list[] = 'whop';

    if (function_exists('paddle_is_ready') && paddle_is_ready($db)) $list[] = 'paddle';

    if (function_exists('lemonsqueezy_is_ready') && lemonsqueezy_is_ready($db)) $list[] = 'lemonsqueezy';

    if (function_exists('dodopayments_is_ready') && dodopayments_is_ready($db)) $list[] = 'dodopayments';

    $builtIn = ['shopier','paytr','iyzico','stripe','paypal','bitpay','crypt','paywant','whop','paddle','lemonsqueezy','dodopayments'];

    if (function_exists('modules_gateways')) {

        $modGateways = modules_gateways($db);

        if (is_array($modGateways)) foreach ($modGateways as $code => $gw) { if (!in_array($code, $builtIn, true)) $list[] = 'mod:' . $code; }

    }

    return $list;

}

}

if (!function_exists('gateway_method_url')) {

function gateway_method_url(string $method): string {

    if (strncmp($method, 'mod:', 4) === 0) return '/shop/module-pay?gateway=' . urlencode(substr($method, 4));

    if ($method === 'shopier') return '';

    if ($method === 'paytr') return '';

    if ($method === 'iyzico') return '/shop/iyzico-pay';

    if ($method === 'stripe') return '/shop/stripe-pay';

    if ($method === 'paypal') return '/shop/paypal-pay';

    if ($method === 'bitpay') return '/shop/bitpay-pay';

    if ($method === 'crypt') return '/shop/crypt-pay';

    if ($method === 'paywant') return '/shop/paywant-pay';

    if ($method === 'whop') return '/shop/whop-pay';

    if ($method === 'paddle') return '/shop/paddle-pay';

    if ($method === 'lemonsqueezy') return '/shop/lemonsqueezy-pay';

    if ($method === 'dodopayments') return '/shop/dodopayments-pay';

    return '';

}

}

if (!function_exists('gateway_label_for')) {

function gateway_label_for(string $code): string {

    $map = ['shopier' => 'Shopier', 'paytr' => 'PayTR', 'iyzico' => 'iyzico', 'stripe' => 'Stripe', 'paypal' => 'PayPal', 'bitpay' => 'BitPay', 'crypt' => 'Kripto', 'paywant' => 'Paywant', 'whop' => 'Whop', 'paddle' => 'Paddle', 'lemonsqueezy' => 'Lemon Squeezy', 'dodopayments' => 'DodoPayments'];

    if (strncmp($code, 'mod:', 4) === 0) {

        $slug = substr($code, 4);

        if (function_exists('modules_gateway_find')) {

            $__gdb = function_exists('nexus_db') ? nexus_db() : null;

            $gw = $__gdb ? modules_gateway_find($slug, $__gdb) : null;

            if ($gw && !empty($gw['label'])) return (string)$gw['label'];

        }

        return ucfirst($slug);

    }

    return $map[$code] ?? ucfirst($code);

}

}

if (!function_exists('gateway_logo_url')) {

function gateway_logo_url(string $code): string {

    if (strncmp($code, 'mod:', 4) === 0) return '';

    $map = ['shopier' => 'shopier.png', 'paytr' => 'paytr.png', 'iyzico' => 'iyzico.png', 'stripe' => 'stripe.png', 'paypal' => 'paypal.png', 'bitpay' => 'bitpay.jpeg', 'crypt' => 'cryptomus.png', 'paywant' => 'paywant.png', 'whop' => 'whop.png', 'paddle' => 'Paddle.jpeg', 'lemonsqueezy' => 'lemonsquezy.jpeg', 'dodopayments' => 'Dodopayments.jpeg'];

    $f = $map[$code] ?? '';

    if ($f === '' || !is_file(ROOT_PATH . '/images/payments/' . $f)) return '';

    return '/images/payments/' . $f;

}

}

if (!function_exists('gateway_cart_redirect')) {

function gateway_cart_redirect(PDO $db): string {

    $list = gateway_ready_list($db);

    if (count($list) === 1) {

        $only = $list[0];

        $url = gateway_method_url($only);

        if ($url !== '') return $url;

        if ($only === 'shopier' || $only === 'paytr') return '/shop/payment';

    }

    if (count($list) > 1) return '/shop/payment';

    if (function_exists('apply_filters')) {

        $modRedirect = (string)apply_filters('gateway_redirect', '', $db);

        if ($modRedirect !== '') return $modRedirect;

    }

    return '';

}

}

if (!function_exists('gateways_cart_ready')) {

function gateways_cart_ready(PDO $db): bool {

    return count(gateway_ready_list($db)) > 0;

}

}