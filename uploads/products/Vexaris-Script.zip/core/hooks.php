<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
$GLOBALS['__vx_hooks'] = $GLOBALS['__vx_hooks'] ?? ['action' => [], 'filter' => []];
function add_action(string $tag, callable $fn, int $prio = 10): void {
    $tag = trim($tag);
    if ($tag === '') return;
    $GLOBALS['__vx_hooks']['action'][$tag][$prio][] = $fn;
}
function do_action(string $tag, ...$args): void {
    $tag = trim($tag);
    if ($tag === '' || empty($GLOBALS['__vx_hooks']['action'][$tag])) return;
    $hooks = $GLOBALS['__vx_hooks']['action'][$tag];
    ksort($hooks);
    foreach ($hooks as $list) {
        foreach ($list as $fn) {
            $t0 = microtime(true);
            try { $fn(...$args); } catch (\Throwable $e) { error_log('[Vexaris] hook action ' . $tag . ': ' . $e->getMessage()); }
            if (function_exists('module_hook_slow_log')) module_hook_slow_log($tag, microtime(true) - $t0);
        }
    }
}
function add_filter(string $tag, callable $fn, int $prio = 10): void {
    $tag = trim($tag);
    if ($tag === '') return;
    $GLOBALS['__vx_hooks']['filter'][$tag][$prio][] = $fn;
}
function apply_filters(string $tag, $value, ...$args) {
    $tag = trim($tag);
    if ($tag === '' || empty($GLOBALS['__vx_hooks']['filter'][$tag])) return $value;
    $hooks = $GLOBALS['__vx_hooks']['filter'][$tag];
    ksort($hooks);
    foreach ($hooks as $list) {
        foreach ($list as $fn) {
            $t0 = microtime(true);
            try { $value = $fn($value, ...$args); } catch (\Throwable $e) { error_log('[Vexaris] hook filter ' . $tag . ': ' . $e->getMessage()); }
            if (function_exists('module_hook_slow_log')) module_hook_slow_log($tag, microtime(true) - $t0);
        }
    }
    return $value;
}
function has_action(string $tag): bool {
    return !empty($GLOBALS['__vx_hooks']['action'][trim($tag)]);
}
function has_filter(string $tag): bool {
    return !empty($GLOBALS['__vx_hooks']['filter'][trim($tag)]);
}
