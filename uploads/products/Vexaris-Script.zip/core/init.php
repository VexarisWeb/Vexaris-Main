<?php
defined('NEXUS_BOOT')   or define('NEXUS_BOOT',   true);
defined('ROOT_PATH')    or define('ROOT_PATH',    dirname(__DIR__));
defined('LOCK_FILE')    or define('LOCK_FILE',    ROOT_PATH . DIRECTORY_SEPARATOR . 'install.lock');
defined('INSTALL_URL')  or define('INSTALL_URL',  '/install/index.php');
defined('HOME_URL')     or define('HOME_URL',     '/');

if (!headers_sent()) {
    header_remove('X-Powered-By');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    $nxProto = strtolower(trim((string)(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0] ?? '')));
    if ((!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') || $nxProto === 'https' || (string)($_SERVER['SERVER_PORT'] ?? '') === '443') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

$isInstalled = file_exists(LOCK_FILE);

$requestPath   = rtrim(strtok($_SERVER['REQUEST_URI'] ?? '/', '?'), '/');
$isInstallPage = ($requestPath === '/install' || strncmp($requestPath, '/install/', 9) === 0);

if (!$isInstalled && !$isInstallPage) {
    header('Location: ' . INSTALL_URL, true, 302);
    exit;
}

if ($isInstalled && $isInstallPage) {
    header('Location: ' . HOME_URL, true, 302);
    exit;
}

$nxErrDir = dirname(ROOT_PATH) . DIRECTORY_SEPARATOR . 'vexaris-logs';
if (!is_dir($nxErrDir)) @mkdir($nxErrDir, 0750, true);
if (is_dir($nxErrDir) && is_writable($nxErrDir)) @ini_set('error_log', $nxErrDir . DIRECTORY_SEPARATOR . 'php-error.log');
@ini_set('log_errors', '1');

require_once ROOT_PATH . '/core/lang.php';

if (!function_exists('e')) {
    function e($str): string {
        return htmlspecialchars((string)($str ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('cat_icon_html')) {
    function cat_icon_html($icon, string $style = ''): string {
        $icon = trim((string)($icon ?? ''));
        if ($icon === '') return '';
        $st = $style !== '' ? ' style="' . htmlspecialchars($style, ENT_QUOTES, 'UTF-8') . '"' : '';
        if (preg_match('#^(https?://|/|data:image/)#i', $icon)) {
            return '<img src="' . htmlspecialchars($icon, ENT_QUOTES, 'UTF-8') . '" alt="" loading="lazy"' . $st . '>';
        }
        return '<i class="' . htmlspecialchars($icon, ENT_QUOTES, 'UTF-8') . '"' . $st . '></i>';
    }
}

if (!function_exists('simple_markdown')) {
    function simple_markdown(string $text): string {
        $text = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
        $text = preg_replace_callback('/^```(.+?)```$/ms', function ($m) {
            return '<pre class="bg-white/10 rounded p-3 overflow-x-auto text-sm font-mono">' . $m[1] . '</pre>';
        }, $text);
        $text = preg_replace('/^### (.+)$/m', '<h3 class="text-base font-bold mt-3 mb-1">$1</h3>', $text);
        $text = preg_replace('/^## (.+)$/m',  '<h2 class="text-lg font-bold mt-4 mb-1">$1</h2>',  $text);
        $text = preg_replace('/^# (.+)$/m',   '<h1 class="text-xl font-bold mt-4 mb-2">$1</h1>',  $text);
        $text = preg_replace('/^\s*[-*]\s+(.+)$/m', '<li class="ml-4 list-disc">$1</li>', $text);
        $text = preg_replace('/(<li[^>]*>.*?<\/li>)+/s', '<ul class="my-2 space-y-1">$0</ul>', $text);
        $text = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $text);
        $text = preg_replace('/\*(.+?)\*/',     '<em>$1</em>', $text);
        $text = preg_replace('/`(.+?)`/', '<code class="bg-white/10 px-1 rounded text-sm font-mono">$1</code>', $text);
        $text = preg_replace_callback('/\[(.+?)\]\((.+?)\)/', function ($m) {
            $url = $m[2];
            if (!preg_match('#^(https?://|mailto:)#i', $url)) return $m[1];
            return '<a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" class="text-indigo-400 underline" target="_blank" rel="noopener noreferrer">' . $m[1] . '</a>';
        }, $text);
        return nl2br($text);
    }
}

if (!function_exists('truncate_text')) {
    function truncate_text(string $text, int $limit = 150): string {
        $text = strip_tags($text);
        $plain = preg_replace('/```.*?```/s', '', $text);
        $plain = preg_replace('/`[^`]+`/', '', $plain);
        $plain = preg_replace('/\*{1,2}([^*]+)\*{1,2}/', '$1', $plain);
        $plain = preg_replace('/^#{1,6}\s+/m', '', $plain);
        $plain = preg_replace('/^\s*[-*]\s+/m', '', $plain);
        $plain = preg_replace('/\[([^\]]+)\]\([^)]+\)/', '$1', $plain);
        $plain = preg_replace('/\s+/', ' ', trim($plain));
        if (mb_strlen($plain, 'UTF-8') <= $limit) return $plain;
        return mb_substr($plain, 0, $limit, 'UTF-8') . '...';
    }
}

if (!function_exists('tr_date')) {
    function tr_date(string $format, $ts = null): string {
        if ($ts === null) $ts = time();
        if (is_string($ts)) $ts = strtotime($ts);
        if (!$ts || $ts <= 0) return '';
        if (function_exists('lang_active') && lang_active() === 'en') return date($format, $ts);
        $months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
        $days   = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
        $out = date($format, $ts);
        $monthTr = $months[(int)date('n', $ts) - 1];
        $out = str_replace(date('F', $ts), $monthTr, $out);
        $out = str_replace(date('M', $ts), mb_substr($monthTr, 0, 3, 'UTF-8'), $out);
        $out = str_replace(date('l', $ts), $days[(int)date('N', $ts) - 1], $out);
        return $out;
    }
}

if ($isInstalled) {
    require_once ROOT_PATH . '/vendor/vexbrand/nex-brand.php';
    require_once ROOT_PATH . '/core/db.php';
    require_once ROOT_PATH . '/core/sanitize.php';
    require_once ROOT_PATH . '/core/hooks.php';
    require_once ROOT_PATH . '/core/config-sync.php';
    require_once ROOT_PATH . '/core/plan.php';
    require_once ROOT_PATH . '/core/license-gate.php';
    require_once ROOT_PATH . '/core/stock.php';
    require_once ROOT_PATH . '/core/managers/auth-man.php';
    require_once ROOT_PATH . '/core/managers/roles-man.php';
    require_once ROOT_PATH . '/core/managers/audit-man.php';
    require_once ROOT_PATH . '/core/managers/ai-man.php';
    require_once ROOT_PATH . '/core/ai-relay.php';
    require_once ROOT_PATH . '/core/managers/theme-man.php';
    require_once ROOT_PATH . '/core/managers/modules-man.php';
    require_once ROOT_PATH . '/core/managers/module-guard.php';
    require_once ROOT_PATH . '/core/managers/widgets-man.php';
    require_once ROOT_PATH . '/core/managers/slider-man.php';
    require_once ROOT_PATH . '/core/managers/version-man.php';
    require_once ROOT_PATH . '/core/color-picker.php';
    require_once ROOT_PATH . '/core/editor.php';
    require_once ROOT_PATH . '/core/markdown.php';
    require_once ROOT_PATH . '/core/mail.php';
    require_once ROOT_PATH . '/core/update.php';
    require_once ROOT_PATH . '/core/fx.php';
    require_once ROOT_PATH . '/core/gateways.php';

    $mmDb = nexus_db();
    if ($mmDb) {
        try {
            $mmStmt = $mmDb->prepare("SELECT `value` FROM settings WHERE `key`='maintenance_mode' LIMIT 1");
            $mmStmt->execute();
            if ($mmStmt->fetchColumn() === '1') {
                $mmUser = auth_check() ? auth_user() : null;
                $mmRole = $mmUser['role'] ?? '';
                $mmPath = rtrim(strtok($_SERVER['REQUEST_URI'] ?? '/', '?'), '/');
                $mmAllowed = in_array($mmPath, ['/maintenance', '/login', '/register']);
                if (!in_array($mmRole, ['admin', 'superadmin'], true) && !$mmAllowed) {
                    if ($mmPath === '/action.php' || (isset($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json'))) {
                        http_response_code(503);
                        header('Content-Type: application/json; charset=utf-8');
                        echo json_encode(['ok' => false, 'msg' => 'Site şu anda bakım modundadır.'], JSON_UNESCAPED_UNICODE);
                        exit;
                    }
                    header('Location: /maintenance', true, 307);
                    exit;
                }
            }
        } catch (\Exception $e) {}
    }

    config_sync_maybe();
    update_maybe();
    modules_boot();
}
