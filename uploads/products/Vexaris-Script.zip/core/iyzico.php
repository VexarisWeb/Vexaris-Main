<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

spl_autoload_register(function ($class) {
    static $prefix = 'Iyzipay\\';
    static $dir = null;
    if ($dir === null) $dir = ROOT_PATH . '/vendor/iyzipay/Iyzipay/';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) return;
    $file = $dir . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($file)) require $file;
});

function iyzico_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_iyzico_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[iyzico] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function iyzico_is_ready(\PDO $db): bool {
    $cfg = iyzico_settings($db);
    return ($cfg['payment_iyzico_active'] ?? '0') === '1'
        && !empty($cfg['payment_iyzico_api_key'] ?? '')
        && !empty($cfg['payment_iyzico_secret_key'] ?? '');
}

function iyzico_is_test_mode(\PDO $db): bool {
    $cfg = iyzico_settings($db);
    return ((string)($cfg['payment_iyzico_test_mode'] ?? '0')) === '1';
}

function iyzico_base_url(): string {
    if (function_exists('site_base_url')) {
        try {
            $b = site_base_url(function_exists('nexus_db') ? nexus_db() : null);
            if ($b !== '') return rtrim($b, '/');
        } catch (\Throwable $e) {}
    }
    $scheme = function_exists('request_is_https') ? (request_is_https() ? 'https://' : 'http://') : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://');
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    if (!preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) $host = 'localhost';
    return rtrim($scheme . $host, '/');
}

function iyzico_options(\PDO $db): \Iyzipay\Options {
    $cfg = iyzico_settings($db);
    $options = new \Iyzipay\Options();
    $options->setApiKey(trim((string)($cfg['payment_iyzico_api_key'] ?? '')));
    $options->setSecretKey(trim((string)($cfg['payment_iyzico_secret_key'] ?? '')));
    $options->setBaseUrl(iyzico_is_test_mode($db) ? 'https://sandbox-api.iyzipay.com' : 'https://api.iyzipay.com');
    return $options;
}

function iyzico_client_ip(): string {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    }
    return trim((string)$ip);
}

function iyzico_valid_tckn(): string {
    $d = [];
    for ($i = 0; $i < 9; $i++) $d[$i] = random_int(0, 9);
    $d[0] = random_int(1, 9);
    $d[9] = (((($d[0] + $d[2] + $d[4] + $d[6] + $d[8]) * 7) - ($d[1] + $d[3] + $d[5] + $d[7])) % 10);
    if ($d[9] < 0) $d[9] += 10;
    $sum = 0;
    for ($i = 0; $i < 10; $i++) $sum += $d[$i];
    $d[10] = $sum % 10;
    return implode('', $d);
}

function iyzico_currency(\PDO $db): string {
    $cfg = iyzico_settings($db);
    $siteCurrency = trim((string)($cfg['payment_iyzico_currency'] ?? 'TRY'));
    $currencyMap  = ['TRY' => 'TRY', 'EUR' => 'EUR', 'USD' => 'USD', 'GBP' => 'GBP'];
    return $currencyMap[$siteCurrency] ?? 'TRY';
}

class IyzicoIpv4Curl extends \Iyzipay\Curl {
    public function exec($url, $options) {
        $options[CURLOPT_IPRESOLVE] = CURL_IPRESOLVE_V4;
        return parent::exec($url, $options);
    }
}

function iyzico_use_ipv4_client(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    \Iyzipay\ApiResource::setHttpClient(\Iyzipay\DefaultHttpClient::create(new IyzicoIpv4Curl()));
}

function iyzico_create_payment(\PDO $db, string $orderId, string $email, string $username, float $totalTL, array $basket): array {
    require_once ROOT_PATH . '/vendor/autoload.php';
    iyzico_use_ipv4_client();
    $options = iyzico_options($db);
    if ($options->getApiKey() === '' || $options->getSecretKey() === '') {
        throw new \RuntimeException('iyzico yapılandırması eksik.');
    }

    $cfg = iyzico_settings($db);
    $currency = iyzico_currency($db);

    $nameParts = preg_split('/\s+/', trim($username), 2);
    $firstName = $nameParts[0] ?? ($username ?: 'Kullanıcı');
    $lastName  = $nameParts[1] ?? 'Kullanıcı';

    $request = new \Iyzipay\Request\CreateCheckoutFormInitializeRequest();
    $request->setLocale(\Iyzipay\Model\Locale::TR);
    $request->setConversationId($orderId);
    $rawSum = 0.0;
    foreach ($basket as $bi) $rawSum += (float)($bi[1] ?? 0) * max(1, (int)($bi[2] ?? 1));
    $rawSum = round($rawSum, 2);
    $charge = round($totalTL, 2);
    $request->setPrice(number_format($rawSum > 0 ? $rawSum : $charge, 2, '.', ''));
    $request->setPaidPrice(number_format($charge, 2, '.', ''));
    $request->setBasketId($orderId);
    $request->setPaymentGroup(\Iyzipay\Model\PaymentGroup::PRODUCT);
    $request->setCurrency($currency);
    $request->setCallbackUrl(iyzico_base_url() . '/callback/iyzico.php');
    $request->setEnabledInstallments([1]);

    $buyer = new \Iyzipay\Model\Buyer();
    $buyer->setId($orderId);
    $buyer->setName($firstName);
    $buyer->setSurname($lastName);
    $buyer->setIdentityNumber(iyzico_valid_tckn());
    $buyer->setEmail($email);
    $buyer->setGsmNumber('+905000000000');
    $buyer->setRegistrationAddress('Belirtilmedi');
    $buyer->setCity('Istanbul');
    $buyer->setCountry('Turkey');
    $buyer->setIp(iyzico_client_ip());
    $request->setBuyer($buyer);

    $address = new \Iyzipay\Model\Address();
    $address->setContactName($firstName . ' ' . $lastName);
    $address->setCity('Istanbul');
    $address->setCountry('Turkey');
    $address->setAddress('Belirtilmedi');
    $address->setZipCode('34000');
    $request->setShippingAddress($address);
    $request->setBillingAddress($address);

    $basketItems = [];
    $idx = 0;
    foreach ($basket as $item) {
        $idx++;
        $unitPrice = (float)($item[1] ?? 0);
        $qty       = max(1, (int)($item[2] ?? 1));
        $prc = number_format($unitPrice * $qty, 2, '.', '');
            if ((float)$prc <= 0) continue;
            $bi = new \Iyzipay\Model\BasketItem();
            $bi->setId('ITEM-' . $idx);
            $bi->setName(substr((string)($item[0] ?? 'Ürün'), 0, 100));
            $bi->setCategory1('Bilişim');
            $bi->setItemType(\Iyzipay\Model\BasketItemType::VIRTUAL);
            $bi->setPrice($prc);
            $basketItems[] = $bi;
    }
    if (empty($basketItems)) {
        throw new \RuntimeException('Ödenecek ürün bulunmuyor.');
    }
    $request->setBasketItems($basketItems);

    $result = null;
    $lastErr = 'yanıt yok';
    for ($att = 0; $att < 3; $att++) {
        try {
            $result = \Iyzipay\Model\CheckoutFormInitialize::create($request, $options);
        } catch (\Exception $e) {
            $lastErr = 'iyzico istek hatası: ' . $e->getMessage();
            usleep(500000 * ($att + 1));
            continue;
        }
        if ($result && $result->getStatus() === 'success') break;
        $lastErr = $result ? (string)$result->getErrorMessage() : 'yanıt yok';
        if ($lastErr !== '') break;
        usleep(500000 * ($att + 1));
    }
    if (!$result || $result->getStatus() !== 'success') {
        $errDetail = $lastErr;
        error_log('[iyzico] Form başlatılamadı: ' . $errDetail . ' | ham: ' . ($result ? substr((string)$result->getRawResult(), 0, 300) : ''));
        throw new \RuntimeException('iyzico ödeme başlatılamadı: ' . $errDetail);
    }
    $content = (string)$result->getCheckoutFormContent();
    $token   = (string)$result->getToken();
    if ($content === '' || $token === '') {
        throw new \RuntimeException('iyzico form içeriği alınamadı.');
    }
    return ['content' => $content, 'token' => $token, 'currency' => $currency, 'price' => number_format($rawSum > 0 ? $rawSum : $charge, 2, '.', ''), 'paid_price' => number_format($charge, 2, '.', '')];
}

function iyzico_retrieve(\PDO $db, string $token) {
    require_once ROOT_PATH . '/vendor/autoload.php';
    iyzico_use_ipv4_client();
    $options = iyzico_options($db);
    $request = new \Iyzipay\Request\RetrieveCheckoutFormRequest();
    $request->setLocale(\Iyzipay\Model\Locale::TR);
    $request->setConversationId('CB-' . time());
    $request->setToken($token);
    try {
        return \Iyzipay\Model\CheckoutForm::retrieve($request, $options);
    } catch (\Exception $e) {
        throw new \RuntimeException('iyzico sorgu hatası: ' . $e->getMessage());
    }
}

function iyzico_trim_price($v): string {
    $s = trim((string)$v);
    if (strpos($s, '.') !== false) {
        $s = rtrim($s, '0');
        $s = rtrim($s, '.');
    }
    return $s === '' || $s === '-' ? '0' : $s;
}

function iyzico_verify_retrieve(\PDO $db, $result): bool {
    if (!$result || !method_exists($result, 'getSignature')) return false;
    $cfg = iyzico_settings($db);
    $secret = trim((string)($cfg['payment_iyzico_secret_key'] ?? ''));
    if ($secret === '') return false;
    $parts = [
        (string)$result->getPaymentStatus(),
        (string)$result->getPaymentId(),
        (string)$result->getCurrency(),
        (string)$result->getBasketId(),
        (string)$result->getConversationId(),
        iyzico_trim_price($result->getPaidPrice()),
        iyzico_trim_price($result->getPrice()),
        (string)$result->getToken(),
    ];
    $expected = hash_hmac('sha256', implode(':', $parts), $secret);
    $given = (string)$result->getSignature();
    if ($given === '') return false;
    return hash_equals(strtolower($expected), strtolower($given));
}
