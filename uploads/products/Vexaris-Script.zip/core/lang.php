<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
function lang_list(): array {
    return [
        'tr' => ['name' => 'Türkçe', 'flag' => '/assets/images/flags/tr.svg'],
        'en' => ['name' => 'English', 'flag' => '/assets/images/flags/en.svg'],
    ];
}
function admin_lang(): ?string {
    $s = strtolower(trim((string)($_SESSION['admin_lang'] ?? '')));
    if (isset(lang_list()[$s])) return $s;
    $c = strtolower(trim((string)($_COOKIE['vx_admin_lang'] ?? '')));
    if (isset(lang_list()[$c])) return $c;
    return null;
}
function admin_lang_request(): bool {
    $uri = strtok((string)($_SERVER['REQUEST_URI'] ?? '/'), '?') ?: '/';
    if ($uri === '/action.php' || strncmp($uri, '/admin', 6) === 0) return true;
    $sn = (string)($_SERVER['SCRIPT_NAME'] ?? '');
    if ($sn !== '' && str_contains($sn, '/admin')) return true;
    return false;
}
function lang_active(): string {
    static $l = null;
    if (admin_lang_request()) {
        $al = admin_lang();
        if ($al !== null) return $al;
    }
    if ($l !== null) return $l;
    $l = 'tr';
    try {
        $db = function_exists('nexus_db') ? nexus_db() : null;
        if ($db) {
            $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='primary_lang' LIMIT 1");
            $st->execute();
            $v = strtolower(trim((string)($st->fetchColumn() ?? '')));
            if (isset(lang_list()[$v])) $l = $v;
        }
    } catch (\Throwable $e) {}
    return $l;
}
function lang_dict(string $lang): array {
    static $c = [];
    if (isset($c[$lang])) return $c[$lang];
    $c[$lang] = [];
    $f = ROOT_PATH . '/lang/' . preg_replace('/[^a-z]/', '', $lang) . '.json';
    if (is_file($f)) {
        try {
            $d = json_decode(file_get_contents($f), true);
            if (is_array($d)) $c[$lang] = $d;
        } catch (\Throwable $e) {}
    }
    return $c[$lang];
}
function lang_get(array $d, string $key): ?string {
    $v = $d;
    foreach (explode('.', $key) as $k) {
        if (!is_array($v) || !array_key_exists($k, $v)) return null;
        $v = $v[$k];
    }
    return is_string($v) ? $v : null;
}
function __(string $key, array $vars = []): string {
    $l = lang_active();
    $v = lang_get(lang_dict($l), $key);
    if ($v === null && $l !== 'tr') $v = lang_get(lang_dict('tr'), $key);
    if ($v === null) $v = $key;
    foreach ($vars as $k => $val) $v = str_replace('{' . $k . '}', (string)$val, $v);
    return $v;
}
