<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

function lemonsqueezy_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_lemonsqueezy_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[lemonsqueezy] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function lemonsqueezy_test_mode(\PDO $db): bool {
    $cfg = lemonsqueezy_settings($db);
    return ($cfg['payment_lemonsqueezy_test_mode'] ?? '0') === '1';
}

function lemonsqueezy_api_key(\PDO $db): string {
    $cfg = lemonsqueezy_settings($db);
    return trim((string)($cfg['payment_lemonsqueezy_api_key'] ?? ''));
}

function lemonsqueezy_signing_secret(\PDO $db): string {
    $cfg = lemonsqueezy_settings($db);
    return trim((string)($cfg['payment_lemonsqueezy_signing_secret'] ?? ''));
}

function lemonsqueezy_store_id(\PDO $db): string {
    $cfg = lemonsqueezy_settings($db);
    return trim((string)($cfg['payment_lemonsqueezy_store_id'] ?? ''));
}

function lemonsqueezy_variant_id(\PDO $db): string {
    $cfg = lemonsqueezy_settings($db);
    return trim((string)($cfg['payment_lemonsqueezy_variant_id'] ?? ''));
}

function lemonsqueezy_currency(\PDO $db): string {
    $cfg = lemonsqueezy_settings($db);
    $c = strtoupper(trim((string)($cfg['payment_lemonsqueezy_currency'] ?? 'TRY')));
    return in_array($c, ['TRY', 'USD', 'EUR'], true) ? $c : 'TRY';
}

function lemonsqueezy_is_ready(\PDO $db): bool {
    $s = lemonsqueezy_settings($db);
    return !empty($s['payment_lemonsqueezy_api_key']) && !empty($s['payment_lemonsqueezy_signing_secret'])
        && !empty($s['payment_lemonsqueezy_store_id']) && !empty($s['payment_lemonsqueezy_variant_id'])
        && ($s['payment_lemonsqueezy_active'] ?? '0') === '1';
}

function lemonsqueezy_request(\PDO $db, string $method, string $path, $body = null): array {
    $key = lemonsqueezy_api_key($db);
    if ($key === '') throw new \RuntimeException('Lemon Squeezy API anahtarı yapılandırılmamış.');
    $headers = ['Authorization: Bearer ' . $key, 'Accept: application/vnd.api+json'];
    $payload = null;
    if ($body !== null) {
        $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($payload === false) throw new \RuntimeException('Lemon Squeezy isteği hazırlanamadı.');
        $headers[] = 'Content-Type: application/vnd.api+json';
    }
    $ch = curl_init('https://api.lemonsqueezy.com/v1' . $path);
    $opts = [CURLOPT_CUSTOMREQUEST => strtoupper($method), CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_HTTPHEADER => $headers];
    if ($payload !== null) $opts[CURLOPT_POSTFIELDS] = $payload;
    curl_setopt_array($ch, $opts);
    $resp = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) throw new \RuntimeException('Lemon Squeezy bağlantı hatası: ' . $err);
    $data = json_decode((string)$resp, true);
    if ($code < 200 || $code >= 300) {
        $msg = is_array($data) ? (string)(json_encode($data['errors'] ?? $data, JSON_UNESCAPED_UNICODE)) : substr((string)$resp, 0, 200);
        throw new \RuntimeException('Lemon Squeezy API hatası (HTTP ' . $code . '): ' . mb_substr($msg, 0, 200));
    }
    if (!is_array($data) || !isset($data['data'])) throw new \RuntimeException('Lemon Squeezy yanıtı çözümlenemedi (HTTP ' . $code . ').');
    return $data['data'];
}

function lemonsqueezy_minor(float $total): int {
    $minor = (int)round($total * 100);
    if ($minor <= 0) throw new \RuntimeException('Lemon Squeezy ile en az 1,00 tutarında ödeme alınabilir.');
    return $minor;
}

function lemonsqueezy_min_check(float $total, string $cur): void {
    $mins = ['TRY' => 30.0, 'USD' => 1.0, 'EUR' => 1.0];
    $floor = $mins[$cur] ?? 30.0;
    if ($total < $floor) throw new \RuntimeException('Lemon Squeezy minimum tutarın altında: ' . $cur . ' ' . $floor);
}

function lemonsqueezy_return_url(string $orderId): string {
    if (function_exists('site_base_url')) {
        try {
            $b = site_base_url(function_exists('nexus_db') ? nexus_db() : null);
            if ($b !== '') return rtrim($b, '/') . '/callback/lemonsqueezy.php?order_id=' . urlencode($orderId);
        } catch (\Throwable $e) {}
    }
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    if (!preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) $host = 'localhost';
    $scheme = function_exists('request_is_https') ? (request_is_https() ? 'https' : 'http') : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http');
    return $scheme . '://' . $host . '/callback/lemonsqueezy.php?order_id=' . urlencode($orderId);
}

function lemonsqueezy_create_checkout(\PDO $db, float $total, string $orderId, string $title, string $email = '', string $name = ''): array {
    if (!lemonsqueezy_is_ready($db)) throw new \RuntimeException('Lemon Squeezy aktif değil.');
    if ($orderId === '') throw new \RuntimeException('Sipariş numarası boş olamaz.');
    $total = round($total, 2);
    $cur = lemonsqueezy_currency($db);
    lemonsqueezy_min_check($total, $cur);
    $storeId = lemonsqueezy_store_id($db);
    $variantId = lemonsqueezy_variant_id($db);
    $locale = function_exists('current_lang') ? (string)current_lang() : 'tr';
    if (!in_array($locale, ['tr', 'en'], true)) $locale = 'en';
    $checkoutData = ['custom' => ['order_id' => mb_substr($orderId, 0, 100)]];
    if ($email !== '') $checkoutData['email'] = mb_substr($email, 0, 100);
    if ($name !== '') $checkoutData['name'] = mb_substr($name, 0, 100);
    $body = [
        'data' => [
            'type' => 'checkouts',
            'attributes' => [
                'custom_price' => lemonsqueezy_minor($total),
                'product_options' => [
                    'name' => mb_substr($title, 0, 100),
                    'redirect_url' => lemonsqueezy_return_url($orderId),
                    'enabled_variants' => [(int)$variantId],
                ],
                'checkout_options' => ['locale' => $locale],
                'checkout_data' => $checkoutData,
                'test_mode' => lemonsqueezy_test_mode($db),
            ],
            'relationships' => [
                'store' => ['data' => ['type' => 'stores', 'id' => (string)$storeId]],
                'variant' => ['data' => ['type' => 'variants', 'id' => (string)$variantId]],
            ],
        ],
    ];
    $chk = lemonsqueezy_request($db, 'POST', '/checkouts', $body);
    $chkId = (string)($chk['id'] ?? '');
    $url = (string)($chk['attributes']['url'] ?? '');
    if ($chkId === '' || $url === '') throw new \RuntimeException('Lemon Squeezy ödeme bağlantısı oluşturulamadı.');
    return ['checkout_url' => $url, 'checkout_id' => $chkId];
}

function lemonsqueezy_verify_webhook(\PDO $db, string $raw, array $headers) {
    $secret = lemonsqueezy_signing_secret($db);
    if ($secret === '' || $raw === '') return false;
    $h = [];
    foreach ($headers as $k => $v) $h[strtolower((string)$k)] = (string)$v;
    $sig = trim((string)($h['x-signature'] ?? ''));
    if ($sig === '' || !preg_match('/^[0-9a-f]{64}$/i', $sig)) return false;
    $calc = hash_hmac('sha256', $raw, $secret);
    if (!hash_equals($calc, strtolower($sig))) return false;
    $event = json_decode($raw, true);
    if (!is_array($event) || !isset($event['meta']['event_name'], $event['data'])) return false;
    return $event;
}

function lemonsqueezy_complete_intent(\PDO $db, array $intent, string $orderRef = ''): void {
    if ($orderRef !== '') {
        $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
           ->execute([substr($orderRef, 0, 40), $intent['id']]);
    } else {
        $db->prepare("UPDATE payment_intents SET status='completed' WHERE id=?")->execute([$intent['id']]);
    }

    $uid       = (int)$intent['user_id'];
    $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);
    $orderId   = (string)$intent['order_id'];
    $cur       = strtoupper((string)($intent['currency'] ?? 'TRY'));

    if (strncmp($orderId, 'TOPUP-', 6) === 0) {
        $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
        $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'Lemon Squeezy']) . '",NOW())')->execute([$uid, $creditAmt, 'topup']);
        $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
        $uStmt->execute([$uid]);
        $uInfo = $uStmt->fetch();
        discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body'), [
            __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
            __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
            __('bsupp.f_method')    => 'Lemon Squeezy',
        ], 16766720);
        return;
    }

    require_once ROOT_PATH . '/core/purchase.php';
    [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);
    if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);

    $done = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
    purchase_finish($db, $uid, $done['total_paid'], 'Lemon Squeezy', 'payment', $snapCoupon, $done['product_ids'] ?? null);

    $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
    $uStmt->execute([$uid]);
    $uInfo = $uStmt->fetch();
    discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body'), [
        __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
        __('bsupp.f_products')   => implode(', ', $done['product_names']),
        __('bsupp.f_amount')     => number_format($done['total_paid'], 2, ',', '.') . ' ' . $cur,
        __('bsupp.f_method')    => 'Lemon Squeezy',
    ], 5763719);
}

function lemonsqueezy_test_connection(\PDO $db): void {
    if (!lemonsqueezy_is_ready($db)) throw new \RuntimeException('API anahtarı yapılandırılmamış.');
    lemonsqueezy_request($db, 'GET', '/stores/' . urlencode(lemonsqueezy_store_id($db)));
}
