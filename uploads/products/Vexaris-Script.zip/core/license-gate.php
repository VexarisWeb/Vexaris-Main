<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
function license_gate_state(): array {
    $out = ['ok' => false, 'features' => []];
    if (!function_exists('nexus_db') || !function_exists('_vx_k')) return $out;
    try {
        $db = nexus_db();
        if (!$db) return $out;
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='_vx_sync' LIMIT 1");
        $st->execute();
        $raw = $st->fetchColumn();
        if (!$raw) return $out;
        $d = json_decode((string)$raw, true);
        if (!is_array($d)) return $out;
        $ts = (int)($d['ts'] ?? 0);
        $fail = (int)($d['fail'] ?? 0);
        $features = $d['features'] ?? null;
        $sig = $d['sig'] ?? null;
        $alg = (string)($d['alg'] ?? 'hmac');
        if (!is_array($features) || $ts <= 0 || !is_string($sig) || $sig === '') return $out;
        if (!defined('CONFIG_SYNC_TTL')) define('CONFIG_SYNC_TTL', 3600);
        if (!((time() - $ts) < CONFIG_SYNC_TTL)) return $out;
        if ($fail >= 72) return $out;
        if ($alg === 'ed25519') {
            if (!function_exists('_vx_ed_verify') || !function_exists('_vx_pub')) return $out;
            if (!_vx_ed_verify(json_encode($features) . '|' . $ts, $sig, _vx_pub())) return $out;
        } else {
            $exp = hash_hmac('sha256', json_encode($features) . '|' . $ts, _vx_k());
            if (!hash_equals($exp, $sig)) return $out;
        }
        $lk = $db->prepare("SELECT `value` FROM settings WHERE `key`='_vx_lock' LIMIT 1");
        $lk->execute();
        if ($lk->fetchColumn()) return $out;
        $out = ['ok' => true, 'features' => $features];
    } catch (\Throwable $e) {}
    return $out;
}
function license_gate_ok(string $key): bool {
    $s = license_gate_state();
    if (!$s['ok']) return false;
    return (($s['features'][$key] ?? false) === true);
}
function license_gate_require(string $key, int $code = 404): void {
    if (license_gate_ok($key)) return;
    http_response_code($code);
    echo "<!DOCTYPE html><html lang='tr'><head><meta charset='UTF-8'><title>404</title></head>"
       . "<body style='margin:0;font-family:sans-serif;background:#0b0f17;color:#e2e8f0;height:100vh;display:flex;align-items:center;justify-content:center;'>"
       . "<div style='text-align:center;'><h1 style='font-size:3rem;margin:0;color:#64748b;'>404</h1>"
       . "<p style='color:#94a3b8;'>Sayfa Bulunamadı</p></div></body></html>";
    exit;
}
