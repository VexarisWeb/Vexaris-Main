<?php
defined('NEXUS_BOOT') or die('Direct access denied.');

if (!defined('MAIL_ENC_KEY')) {
    $mailKeySeed = '';
    $cfgFileMail = defined('ROOT_PATH') ? ROOT_PATH . DIRECTORY_SEPARATOR . 'install' . DIRECTORY_SEPARATOR . 'config.php' : '';
    if ($cfgFileMail !== '' && is_file($cfgFileMail)) {
        try {
            $cfgArrMail = (static function (string $f): array { return include $f; })($cfgFileMail);
            if (is_string($cfgArrMail['app_key'] ?? null) && $cfgArrMail['app_key'] !== '') {
                $mailKeySeed = $cfgArrMail['app_key'];
            }
        } catch (\Throwable $e) {
            $mailKeySeed = '';
        }
    }
    if ($mailKeySeed === '') {
        error_log('[NS] MAIL_ENC_KEY: install/config.php icinde app_key bulunamadi, sabit anahtar kullanildi.');
        $mailKeySeed = 'vexaris-smtp-v2-fallback';
    }
    define('MAIL_ENC_KEY', substr(hash('sha256', 'vexaris-smtp:' . $mailKeySeed), 0, 32));
}

function mail_encrypt_secret(string $plain): string {
    if ($plain === '') return '';
    $iv = random_bytes(16);
    $enc = openssl_encrypt($plain, 'AES-256-CBC', MAIL_ENC_KEY, OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $enc);
}

function mail_decrypt_secret(string $payload): string {
    if ($payload === '') return '';
    try {
        $raw = base64_decode($payload, true);
        if ($raw === false || strlen($raw) < 17) return '';
        $iv = substr($raw, 0, 16);
        $enc = substr($raw, 16);
        $out = openssl_decrypt($enc, 'AES-256-CBC', MAIL_ENC_KEY, OPENSSL_RAW_DATA, $iv);
        return $out === false ? '' : $out;
    } catch (\Throwable $e) {
        error_log('[NS] mail_decrypt_secret: ' . $e->getMessage());
        return '';
    }
}

function mail_get_settings(\PDO $db): array {
    $cfg = [];
    try {
        $st = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'mail\\_%'");
        while ($r = $st->fetch()) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[NS] mail_get_settings: ' . $e->getMessage());
    }
    return $cfg;
}

function mail_is_available(): bool {
    $db = nexus_db();
    if (!$db) return false;
    $cfg = mail_get_settings($db);
    return (($cfg['mail_enabled'] ?? '0') === '1')
        && trim((string)($cfg['mail_smtp_host'] ?? '')) !== ''
        && trim((string)($cfg['mail_smtp_user'] ?? '')) !== '';
}

function mail_template_defaults(string $slug): ?array {
    $passwordReset = <<<'HTML'
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Şifre Sıfırlama</title>
</head>
<body style="margin:0;padding:0;background-color:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed;background-color:#f4f5f7;padding:40px 10px;">
<tr>
<td align="center">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:550px;background-color:#ffffff;border-radius:12px;border:1px solid #e1e4e8;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,0.05);">
<tr>
<td align="center" style="background-color:{accent_color};padding:36px 30px 28px 30px;">
{logo}
<h1 style="color:#ffffff;font-size:22px;margin:0;font-weight:600;letter-spacing:-0.3px;">{header_title}</h1>
</td>
</tr>
<tr>
<td style="padding:32px 30px;line-height:1.6;">
<!--NEXUS_BODY_START-->
<h2 style="font-size:18px;color:#111827;margin:0 0 12px 0;font-weight:600;">Merhaba {user_name},</h2>
<p style="font-size:15px;color:#4b5563;margin:0 0 16px 0;">Hesabınız için bir şifre sıfırlama talebi aldık. Yeni ve güvenli bir şifre belirlemek için aşağıdaki butonu kullanabilirsiniz.</p>
<p style="font-size:15px;color:#4b5563;margin:0 0 24px 0;">Bu işlem bağlantısı güvenliğiniz nedeniyle <strong>30 dakika</strong> boyunca geçerlidir:</p>
<table border="0" cellpadding="0" cellspacing="0" style="margin:0 auto 28px auto;">
<tr>
<td align="center" bgcolor="{accent_color}" style="border-radius:6px;">
<a href="{reset_link}" target="_blank" style="display:inline-block;padding:13px 32px;font-size:15px;color:#ffffff;text-decoration:none;font-weight:600;border-radius:6px;">Şifremi Sıfırla</a>
</td>
</tr>
</table>
<div style="background-color:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:14px;margin-bottom:24px;">
<p style="font-size:12px;color:#6b7280;margin:0 0 6px 0;">Buton çalışmıyorsa aşağıdaki bağlantıyı tarayıcınıza kopyalayabilirsiniz:</p>
<a href="{reset_link}" style="color:{accent_color};font-size:13px;word-break:break-all;text-decoration:underline;">{reset_link}</a>
</div>
<p style="font-size:13px;color:#6b7280;border-top:1px solid #e5e7eb;padding-top:16px;margin:0;">Bu talebi siz yapmadıysanız lütfen bu e-postayı dikkate almayın. Hesabınızın şifresi değiştirilmeyecek ve güvende kalacaktır.</p>
<!--NEXUS_BODY_END-->
</td>
</tr>
<tr>
<td align="center" style="background-color:#f9fafb;padding:24px 30px;border-top:1px solid #f3f4f6;">
<p style="margin:0;font-size:12px;color:#9ca3af;line-height:1.5;">
&copy; {year} {site_name}. Tüm hakları saklıdır.<br>
Bu e-posta otomatik olarak gönderilmiştir, lütfen yanıtlamayınız.
</p>
</td>
</tr>
</table>
</td>
</tr>
</table>
</body>
</html>
HTML;

    $accountActivation = <<<'HTML'
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hesabınızı Doğrulayın</title>
</head>
<body style="margin:0;padding:0;background-color:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed;background-color:#f4f5f7;padding:40px 10px;">
<tr>
<td align="center">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:550px;background-color:#ffffff;border-radius:12px;border:1px solid #e1e4e8;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,0.05);">
<tr>
<td align="center" style="background-color:{accent_color};padding:36px 30px 28px 30px;">
{logo}
<h1 style="color:#ffffff;font-size:22px;margin:0;font-weight:600;letter-spacing:-0.3px;">{header_title}</h1>
</td>
</tr>
<tr>
<td style="padding:32px 30px;line-height:1.6;">
<!--NEXUS_BODY_START-->
<h2 style="font-size:18px;color:#111827;margin:0 0 12px 0;font-weight:600;">Merhaba {user_name},</h2>
<p style="font-size:15px;color:#4b5563;margin:0 0 16px 0;">Platformumuza kaydolduğunuz için çok heyecanlıyız! Hesabınızı güvenli bir şekilde kullanmaya başlamak ve tüm avantajlardan yararlanmak için e-posta adresinizi doğrulamanız gerekmektedir.</p>
<p style="font-size:15px;color:#4b5563;margin:0 0 24px 0;">Aşağıdaki butona tıklayarak üyeliğinizi anında aktifleştirebilirsiniz:</p>
<table border="0" cellpadding="0" cellspacing="0" style="margin:0 auto 28px auto;">
<tr>
<td align="center" bgcolor="{accent_color}" style="border-radius:6px;">
<a href="{verification_link}" target="_blank" style="display:inline-block;padding:13px 32px;font-size:15px;color:#ffffff;text-decoration:none;font-weight:600;border-radius:6px;">Hesabımı Doğrula</a>
</td>
</tr>
</table>
<div style="background-color:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:14px;margin-bottom:24px;">
<p style="font-size:12px;color:#6b7280;margin:0 0 6px 0;">Buton çalışmıyorsa aşağıdaki bağlantıyı tarayıcınıza kopyalayabilirsiniz:</p>
<a href="{verification_link}" style="color:{accent_color};font-size:13px;word-break:break-all;text-decoration:underline;">{verification_link}</a>
</div>
<p style="font-size:13px;color:#6b7280;border-top:1px solid #e5e7eb;padding-top:16px;margin:0;">Bu hesabı siz oluşturmadıysanız herhangi bir işlem yapmanıza gerek yoktur. Doğrulama yapılmayan hesaplar otomatik olarak silinecektir.</p>
<!--NEXUS_BODY_END-->
</td>
</tr>
<tr>
<td align="center" style="background-color:#f9fafb;padding:24px 30px;border-top:1px solid #f3f4f6;">
<p style="margin:0;font-size:12px;color:#9ca3af;line-height:1.5;">
&copy; {year} {site_name}. Tüm hakları saklıdır.<br>
Bu e-posta otomatik olarak gönderilmiştir, lütfen yanıtlamayınız.
</p>
</td>
</tr>
</table>
</td>
</tr>
</table>
</body>
</html>
HTML;

    $defaults = [
        'password_reset' => [
            'subject'      => 'Şifre Sıfırlama',
            'header_title' => 'Şifre Sıfırlama',
            'accent_color' => '#0284c7',
            'body_html'    => $passwordReset,
        ],
        'account_activation' => [
            'subject'      => 'Hesabınızı Doğrulayın',
            'header_title' => 'Hesap Doğrulama',
            'accent_color' => '#4f46e5',
            'body_html'    => $accountActivation,
        ],
    ];

    return $defaults[$slug] ?? null;
}

function mail_render_template(string $slug, array $vars): array {
    $db = nexus_db();
    if (!$db) return ['subject' => '', 'html' => ''];

    try {
        $st = $db->prepare('SELECT subject, header_title, body_html, accent_color, logo_url FROM mail_templates WHERE slug=? LIMIT 1');
        $st->execute([$slug]);
        $tpl = $st->fetch();
    } catch (\PDOException $e) {
        error_log('[NS] mail_render_template fetch: ' . $e->getMessage());
        return ['subject' => '', 'html' => ''];
    }
    if (!$tpl) {
        error_log("[NS] mail_render_template: şablon bulunamadı (slug={$slug})");
        return ['subject' => '', 'html' => ''];
    }

    $siteName = '';
    $siteLogo = '';
    try {
        $s = $db->query("SELECT `key`,`value` FROM settings WHERE `key` IN ('site_name','site_logo')");
        while ($r = $s->fetch()) {
            if ($r['key'] === 'site_name') $siteName = (string)$r['value'];
            if ($r['key'] === 'site_logo') $siteLogo = trim((string)$r['value']);
        }
    } catch (\PDOException $e) {}

    $accent = $tpl['accent_color'] ?: '#4f46e5';
    $logo   = '';
    $logoUrl = trim((string)($tpl['logo_url'] ?? ''));
    if ($logoUrl === '') $logoUrl = $siteLogo;
    if ($logoUrl !== '') {
        $logo = '<img src="' . htmlspecialchars($logoUrl, ENT_QUOTES, 'UTF-8') . '" alt="' . htmlspecialchars($siteName !== '' ? $siteName : 'Logo', ENT_QUOTES, 'UTF-8') . '" style="display:block;max-width:160px;max-height:64px;height:auto;border:0;outline:none;text-decoration:none;margin-bottom:16px;">';
    }

    $map = [
        '{accent_color}' => htmlspecialchars((string)$accent, ENT_QUOTES, 'UTF-8'),
        '{header_title}' => htmlspecialchars((string)($tpl['header_title'] ?? ''), ENT_QUOTES, 'UTF-8'),
        '{logo}'         => $logo,
        '{site_name}'    => htmlspecialchars((string)$siteName, ENT_QUOTES, 'UTF-8'),
        '{year}'         => date('Y'),
    ];
    foreach ($vars as $k => $v) {
        $map['{' . $k . '}'] = htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    }

    $html = strtr($tpl['body_html'], $map);
    $html = preg_replace('/<!--NEXUS_BODY_(?:START|END)-->/', '', $html);

    return [
        'subject' => strtr($tpl['subject'], $map),
        'html'    => $html,
    ];
}

function mail_send(string $to, string $slug, array $vars, bool $force = false): bool {
    $to = trim($to);
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return false;
    if (function_exists('feature_active') && !feature_active('mail_system')) return false;
    $db = nexus_db();
    if (!$db) return false;

    $cfg = mail_get_settings($db);
    if (!$force && ($cfg['mail_enabled'] ?? '0') !== '1') return false;

    $rendered = mail_render_template($slug, $vars);
    if ($rendered['html'] === '' || $rendered['subject'] === '') {
        error_log('[NS] mail_send: render boş, gönderilmedi (to=' . $to . ', slug=' . $slug . ')');
        return false;
    }

    $autoload = ROOT_PATH . '/vendor/autoload.php';
    if (!is_file($autoload)) {
        error_log('[NS] mail_send: vendor/autoload.php yok, PHPMailer yüklenemedi.');
        return false;
    }
    require_once $autoload;
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        error_log('[NS] mail_send: PHPMailer sınıfı bulunamadı.');
        return false;
    }

    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = $cfg['mail_smtp_host'] ?? '';
        $smtpUser = trim((string)($cfg['mail_smtp_user'] ?? ''));
        $mail->SMTPAuth = $smtpUser !== '';
        $mail->Username = $smtpUser;
        $mail->Password = mail_decrypt_secret($cfg['mail_smtp_pass'] ?? '');
        $enc = $cfg['mail_smtp_encryption'] ?? 'tls';
        $mail->SMTPSecure = $enc === 'none' ? '' : ($enc === 'ssl' ? 'ssl' : 'tls');
        $mail->Port = (int)($cfg['mail_smtp_port'] ?? 587);
        $mail->CharSet = 'UTF-8';
        $mail->SMTPDebug = 0;
        $mail->Timeout = 10;

        $fromEmail = $cfg['mail_from_email'] ?? '';
        $fromName  = $cfg['mail_from_name'] ?? '';
        $siteName  = '';
        try {
            $s = $db->prepare("SELECT `value` FROM settings WHERE `key`='site_name' LIMIT 1");
            $s->execute();
            $siteName = (string)$s->fetchColumn();
        } catch (\PDOException $e) {}
        $fromEmail = $fromEmail !== '' ? $fromEmail : ($cfg['mail_smtp_user'] ?? '');
        $fromName  = $fromName !== '' ? $fromName : $siteName;

        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $rendered['subject'];
        $mail->Body    = $rendered['html'];
        $mail->AltBody = trim(html_entity_decode(strip_tags(preg_replace('/<(br|p|div|tr|li)[^>]*>/i', "\n", (string)$rendered['html'])), ENT_QUOTES, 'UTF-8'));
        $mail->send();
        return true;
    } catch (\Throwable $e) {
        error_log('[NS] mail_send: ' . $e->getMessage());
        return false;
    }
}