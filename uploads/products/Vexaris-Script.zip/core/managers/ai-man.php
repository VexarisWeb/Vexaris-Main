<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
function ai_tools(): array {
    return [
        'store.stats' => ['permission' => 'dashboard', 'destructive' => false, 'params' => []],
        'sales.recent' => ['permission' => 'purchases', 'destructive' => false, 'params' => ['limit' => ['type' => 'int', 'default' => 5, 'min' => 1, 'max' => 20]]],
        'products.top' => ['permission' => 'products', 'destructive' => false, 'params' => ['limit' => ['type' => 'int', 'default' => 5, 'min' => 1, 'max' => 20]]],
        'products.low_stock' => ['permission' => 'products', 'destructive' => false, 'params' => ['limit' => ['type' => 'int', 'default' => 8, 'min' => 1, 'max' => 30]]],
        'product.get' => ['permission' => 'products', 'destructive' => false, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1]]],
        'product.create' => ['permission' => 'products', 'destructive' => true, 'params' => ['name' => ['type' => 'string', 'required' => true, 'max' => 120], 'price' => ['type' => 'float', 'default' => 0, 'min' => 0], 'category' => ['type' => 'string', 'default' => '', 'max' => 60], 'image_url' => ['type' => 'string', 'default' => '', 'max' => 512], 'short_description' => ['type' => 'string', 'default' => '', 'max' => 300], 'description' => ['type' => 'string', 'default' => '', 'max' => 2000]]],
        'product.update' => ['permission' => 'products', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1], 'name' => ['type' => 'string', 'default' => '', 'max' => 120], 'price' => ['type' => 'float', 'default' => null, 'min' => 0], 'category' => ['type' => 'string', 'default' => null, 'max' => 60], 'status' => ['type' => 'string', 'default' => null, 'enum' => ['active', 'draft', 'hidden']]]],
        'product.delete' => ['permission' => 'products', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1]]],
        'users.stats' => ['permission' => 'users', 'destructive' => false, 'params' => []],
        'users.list' => ['permission' => 'users', 'destructive' => false, 'params' => ['q' => ['type' => 'string', 'default' => '', 'max' => 60], 'limit' => ['type' => 'int', 'default' => 10, 'min' => 1, 'max' => 30]]],
        'user.get' => ['permission' => 'users', 'destructive' => false, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1]]],
        'user.set_role' => ['permission' => 'users', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1], 'role' => ['type' => 'string', 'required' => true, 'max' => 30]]],
        'sales.list' => ['permission' => 'purchases', 'destructive' => false, 'params' => ['limit' => ['type' => 'int', 'default' => 10, 'min' => 1, 'max' => 30]]],
        'products.list' => ['permission' => 'products', 'destructive' => false, 'params' => ['q' => ['type' => 'string', 'default' => '', 'max' => 60], 'limit' => ['type' => 'int', 'default' => 10, 'min' => 1, 'max' => 30]]],
        'tickets.list' => ['permission' => 'support', 'destructive' => false, 'params' => ['status' => ['type' => 'string', 'default' => '', 'enum' => ['open', 'replied', 'closed']], 'limit' => ['type' => 'int', 'default' => 10, 'min' => 1, 'max' => 30]]],
        'tickets.open' => ['permission' => 'support', 'destructive' => false, 'params' => ['limit' => ['type' => 'int', 'default' => 5, 'min' => 1, 'max' => 20]]],
        'ticket.reply' => ['permission' => 'support', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1], 'message' => ['type' => 'string', 'required' => true, 'max' => 2000]]],
        'ticket.close' => ['permission' => 'support', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1]]],
        'coupons.list' => ['permission' => 'coupons', 'destructive' => false, 'params' => ['limit' => ['type' => 'int', 'default' => 8, 'min' => 1, 'max' => 30]]],
        'coupon.delete' => ['permission' => 'coupons', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1]]],
        'announcement.delete' => ['permission' => 'announcements', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1]]],
        'sales.get' => ['permission' => 'purchases', 'destructive' => false, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1]]],
        'coupon.create' => ['permission' => 'coupons', 'destructive' => true, 'params' => ['code' => ['type' => 'string', 'required' => true, 'max' => 50], 'type' => ['type' => 'string', 'default' => 'percent', 'enum' => ['percent', 'flat_tl', 'flat_usd', 'flat_eur']], 'value' => ['type' => 'float', 'default' => 10, 'min' => 0], 'max_uses' => ['type' => 'int', 'default' => 100, 'min' => 1]]],
        'coupon.toggle' => ['permission' => 'coupons', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1]]],
        'audit.recent' => ['permission' => 'audit-logs', 'destructive' => false, 'params' => ['limit' => ['type' => 'int', 'default' => 8, 'min' => 1, 'max' => 30], 'username' => ['type' => 'string', 'default' => '', 'max' => 32]]],
        'settings.get' => ['permission' => 'settings', 'destructive' => false, 'params' => []],
        'settings.set' => ['permission' => 'settings', 'destructive' => true, 'params' => ['key' => ['type' => 'string', 'required' => true, 'enum' => ['site_name', 'footer_copyright', 'maintenance_mode']], 'value' => ['type' => 'string', 'required' => true, 'max' => 300]]],
        'seo.get' => ['permission' => 'seo', 'destructive' => false, 'params' => []],
        'seo.set' => ['permission' => 'seo', 'destructive' => true, 'params' => ['key' => ['type' => 'string', 'required' => true, 'max' => 60], 'title' => ['type' => 'string', 'default' => '', 'max' => 100], 'desc' => ['type' => 'string', 'default' => '', 'max' => 200]]],
        'announcements.list' => ['permission' => 'announcements', 'destructive' => false, 'params' => ['limit' => ['type' => 'int', 'default' => 8, 'min' => 1, 'max' => 20]]],
        'announcement.create' => ['permission' => 'announcements', 'destructive' => true, 'params' => ['title' => ['type' => 'string', 'required' => true, 'max' => 200], 'content' => ['type' => 'string', 'default' => '', 'max' => 2000]]],
        'user.add_balance' => ['permission' => 'users', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1], 'amount' => ['type' => 'float', 'required' => true, 'min' => 1], 'note' => ['type' => 'string', 'default' => '', 'max' => 200]]],
        'product.set_stock' => ['permission' => 'products', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1], 'stock' => ['type' => 'int', 'required' => true, 'min' => 0]]],
        'product.set_image' => ['permission' => 'products', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1], 'url' => ['type' => 'string', 'required' => true, 'max' => 512]]],
        'licenses.list' => ['permission' => 'licenses', 'destructive' => false, 'params' => ['limit' => ['type' => 'int', 'default' => 10, 'min' => 1, 'max' => 30]]],
        'license.toggle' => ['permission' => 'licenses', 'destructive' => true, 'params' => ['id' => ['type' => 'int', 'required' => true, 'min' => 1]]],
    ];
}
function ai_tool_summary(string $name, array $res): string {
    $d = $res['data'] ?? null;
    if ($name === 'store.stats' && is_array($d)) return 'Ciro: ' . ($d['revenue'] ?? 0) . ', Satış: ' . (int)($d['sales'] ?? 0) . ', Müşteri: ' . (int)($d['customers'] ?? 0) . ', Açık destek: ' . (int)($d['open_tickets'] ?? 0) . ', Kritik stok: ' . (int)($d['low_stock'] ?? 0);
    if (is_array($d) && array_is_list($d)) {
        if (!$d) return 'Kayıt yok.';
        $parts = [];
        foreach (array_slice($d, 0, 5) as $r) {
            $parts[] = (string)($r['name'] ?? $r['title'] ?? $r['username'] ?? $r['code'] ?? $r['label'] ?? ('#' . ($r['id'] ?? '?')));
        }
        return implode(' | ', $parts) . (count($d) > 5 ? ' (+' . (count($d) - 5) . ')' : '');
    }
    if (is_array($d)) {
        $bits = [];
        foreach (['name', 'username', 'code', 'title', 'label'] as $k) if (isset($d[$k])) $bits[] = (string)$d[$k];
        return $bits ? implode(' ', $bits) : 'Tamam.';
    }
    return (string)($res['label'] ?? 'Tamam.');
}
function ai_tool_run(?PDO $db, string $name, array $args = []): array {
    $tools = ai_tools();
    if (!isset($tools[$name])) return ['ok' => false, 'msg' => __('vai.err_tool')];
    $def = $tools[$name];
    if ($db === null && function_exists('nexus_db')) $db = nexus_db();
    if (!$db) return ['ok' => false, 'msg' => __('vai.err_nodb')];
    $role = function_exists('auth_user') ? ((string)(auth_user()['role'] ?? '')) : '';
    if ($role !== 'admin' && $role !== 'superadmin') {
        try {
            $st = $db->prepare('SELECT COUNT(*) FROM permissions WHERE role=? AND resource=?');
            $st->execute([$role, $def['permission']]);
            if ((int)$st->fetchColumn() === 0) return ['ok' => false, 'msg' => __('vai.err_noperm')];
        } catch (\Throwable $e) { return ['ok' => false, 'msg' => __('vai.err_permfail')]; }
    }
    $clean = [];
    foreach ($def['params'] as $k => $spec) {
        $v = $args[$k] ?? ($spec['default'] ?? null);
        if (($spec['required'] ?? false) && ($v === null || $v === '')) return ['ok' => false, 'msg' => __('vai.err_param', ['k' => $k])];
        if ($v === null) { $clean[$k] = null; continue; }
        $t = $spec['type'] ?? 'string';
        if ($t === 'int') {
            if (!is_numeric($v)) return ['ok' => false, 'msg' => __('vai.err_badparam', ['k' => $k])];
            $v = (int)$v;
            if (isset($spec['min']) && $v < $spec['min']) $v = (int)$spec['min'];
            if (isset($spec['max']) && $v > $spec['max']) $v = (int)$spec['max'];
        } elseif ($t === 'float') {
            if (!is_numeric($v)) return ['ok' => false, 'msg' => __('vai.err_badparam', ['k' => $k])];
            $v = (float)$v;
            if (isset($spec['min']) && $v < $spec['min']) $v = (float)$spec['min'];
        } else {
            $v = mb_substr(trim((string)$v), 0, (int)($spec['max'] ?? 512));
            if (isset($spec['enum']) && $v !== '' && !in_array($v, $spec['enum'], true)) return ['ok' => false, 'msg' => __('vai.err_badparam', ['k' => $k])];
        }
        $clean[$k] = $v;
    }
    if (!empty($def['destructive']) && empty($args['confirm'])) {
        return ['ok' => false, 'needs_confirm' => true, 'msg' => __('vai.confirm_needed')];
    }
    $fn = 'ai_tool_' . str_replace('.', '_', $name);
    if (!function_exists($fn)) return ['ok' => false, 'msg' => __('vai.err_undef')];
    try {
        $res = $fn($db, $clean);
    } catch (\Throwable $e) {
        error_log('[Vexaris] ai_tool ' . $name . ': ' . $e->getMessage());
        return ['ok' => false, 'msg' => __('vai.err_toolfail')];
    }
    if (!empty($res['ok']) && function_exists('audit_log')) {
        audit_log($db, $name === 'product.delete' ? 'delete' : (str_contains($name, 'create') ? 'create' : 'update'), explode('.', $name)[0] === 'product' || explode('.', $name)[0] === 'products' ? 'products' : explode('.', $name)[0], (int)($res['id'] ?? 0), mb_substr((string)($res['label'] ?? $name), 0, 120), (string)($res['url'] ?? ''));
    }
    return $res;
}
function ai_tool_store_stats(PDO $db, array $a): array {
    $rev = (float)($db->query("SELECT COALESCE(SUM(total_amount),0) FROM payment_intents WHERE status='completed'")->fetchColumn() ?: 0);
    $sales = (int)$db->query('SELECT COUNT(*) FROM sales')->fetchColumn();
    $users = (int)$db->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
    $topen = (int)$db->query("SELECT COUNT(*) FROM tickets WHERE status='open'")->fetchColumn();
    $low = (int)$db->query("SELECT COUNT(*) FROM products WHERE stock_type='limited' AND stock<=5")->fetchColumn();
    return ['ok' => true, 'data' => ['revenue' => $rev, 'sales' => $sales, 'customers' => $users, 'open_tickets' => $topen, 'low_stock' => $low]];
}
function ai_tool_sales_recent(PDO $db, array $a): array {
    $st = $db->prepare('SELECT s.id,s.price_paid,s.purchased_at,u.username,p.name AS pname FROM sales s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN products p ON p.id=s.product_id ORDER BY s.id DESC LIMIT ?');
    $st->bindValue(1, (int)($a['limit'] ?? 5), PDO::PARAM_INT);
    $st->execute();
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_products_top(PDO $db, array $a): array {
    $st = $db->prepare('SELECT p.id,p.name,COUNT(s.id) AS c FROM sales s JOIN products p ON p.id=s.product_id GROUP BY s.product_id ORDER BY c DESC LIMIT ?');
    $st->bindValue(1, (int)($a['limit'] ?? 5), PDO::PARAM_INT);
    $st->execute();
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_products_low_stock(PDO $db, array $a): array {
    $st = $db->prepare('SELECT id,name,stock FROM products WHERE stock_type=? AND stock<=5 ORDER BY stock ASC LIMIT ?');
    $st->bindValue(1, 'limited', PDO::PARAM_STR);
    $st->bindValue(2, (int)($a['limit'] ?? 8), PDO::PARAM_INT);
    $st->execute();
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_product_get(PDO $db, array $a): array {
    $st = $db->prepare('SELECT id,name,price,category,status,stock,stock_type,version FROM products WHERE id=? LIMIT 1');
    $st->execute([(int)$a['id']]);
    $row = $st->fetch();
    if (!$row) return ['ok' => false, 'msg' => __('vai.err_noproduct')];
    return ['ok' => true, 'data' => $row];
}
function ai_tool_product_create(PDO $db, array $a): array {
    if ($a['name'] === '') return ['ok' => false, 'msg' => __('vai.err_noname')];
    $aiPLim = plan_product_limit();
    $aiPCount = plan_product_count($db);
    if ($aiPLim >= 0 && $aiPCount >= $aiPLim) return ['ok' => false, 'msg' => __('plan.product_limit_reached', ['have' => $aiPCount, 'limit' => $aiPLim])];
    $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower(substr($a['name'], 0, 80))), '-');
    if ($slug === '') $slug = 'urun';
    $base = $slug; $i = 1;
    while (true) {
        $ck = $db->prepare('SELECT id FROM products WHERE slug=? LIMIT 1');
        $ck->execute([$slug]);
        if (!$ck->fetch()) break;
        $slug = $base . '-' . ($i++);
    }
    $img = trim((string)($a['image_url'] ?? ''));
    if ($img !== '' && strncmp($img, '/uploads/', 9) !== 0 && !preg_match('#^https?://#i', $img)) $img = '';
    $desc = trim((string)($a['description'] ?? ''));
    $db->prepare('INSERT INTO products (name,slug,price,category,image_url,short_description,description,status,created_at) VALUES (?,?,?,?,?,?,?,"active",NOW())')->execute([$a['name'], $slug, (float)($a['price'] ?? 0), ($a['category'] ?? '') !== '' ? $a['category'] : null, $img !== '' ? $img : null, ($a['short_description'] ?? '') !== '' ? $a['short_description'] : null, $desc !== '' ? $desc : null]);
    $id = (int)$db->lastInsertId();
    plan_product_bump($db, 1);
    return ['ok' => true, 'id' => $id, 'label' => $a['name'], 'url' => '/admin/products.php?edit=' . $id, 'data' => ['id' => $id]];
}
function ai_tool_product_update(PDO $db, array $a): array {
    $sets = []; $vals = [];
    foreach (['name' => 120, 'category' => 60] as $k => $mx) {
        if ($a[$k] !== null && $a[$k] !== '') { $sets[] = $k . '=?'; $vals[] = mb_substr($a[$k], 0, $mx); }
    }
    if ($a['price'] !== null) { $sets[] = 'price=?'; $vals[] = (float)$a['price']; }
    if ($a['status'] !== null && $a['status'] !== '') { $sets[] = 'status=?'; $vals[] = $a['status']; }
    if (!$sets) return ['ok' => false, 'msg' => __('vai.err_nofields')];
    $vals[] = (int)$a['id'];
    $st = $db->prepare('UPDATE products SET ' . implode(',', $sets) . ' WHERE id=?');
    $st->execute($vals);
    if ($st->rowCount() === 0) return ['ok' => false, 'msg' => __('vai.err_noproduct')];
    return ['ok' => true, 'id' => (int)$a['id'], 'label' => '#' . (int)$a['id'], 'url' => '/admin/products.php?edit=' . (int)$a['id']];
}
function ai_tool_product_delete(PDO $db, array $a): array {
    $st = $db->prepare('SELECT name FROM products WHERE id=? LIMIT 1');
    $st->execute([(int)$a['id']]);
    $name = (string)($st->fetchColumn() ?: '#' . (int)$a['id']);
    $del = $db->prepare('DELETE FROM products WHERE id=?');
    $del->execute([(int)$a['id']]);
    if ($del->rowCount() === 0) return ['ok' => false, 'msg' => __('vai.err_noproduct')];
    return ['ok' => true, 'id' => (int)$a['id'], 'label' => $name, 'url' => '/admin/products.php'];
}
function ai_tool_users_list(PDO $db, array $a): array {
    $q = trim((string)($a['q'] ?? ''));
    $lim = (int)($a['limit'] ?? 10);
    $me = function_exists('auth_user') ? auth_user() : null;
    $hideSuper = ((string)($me['role'] ?? '') === 'superadmin') ? '' : " AND role <> 'superadmin'";
    if ($q !== '') {
        $st = $db->prepare("SELECT id,username,email,role,balance,created_at FROM users WHERE (username LIKE ? OR email LIKE ?)$hideSuper ORDER BY created_at DESC LIMIT ?");
        $like = '%' . $q . '%';
        $st->bindValue(1, $like, PDO::PARAM_STR);
        $st->bindValue(2, $like, PDO::PARAM_STR);
        $st->bindValue(3, $lim, PDO::PARAM_INT);
        $st->execute();
    } else {
        $st = $db->prepare("SELECT id,username,email,role,balance,created_at FROM users WHERE 1=1$hideSuper ORDER BY created_at DESC LIMIT ?");
        $st->bindValue(1, $lim, PDO::PARAM_INT);
        $st->execute();
    }
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_user_get(PDO $db, array $a): array {
    $st = $db->prepare('SELECT id,username,email,role,balance,created_at FROM users WHERE id=? LIMIT 1');
    $st->execute([(int)$a['id']]);
    $row = $st->fetch();
    if (!$row) return ['ok' => false, 'msg' => __('vai.err_nouser')];
    $meGet = function_exists('auth_user') ? auth_user() : null;
    if ((string)($row['role'] ?? '') === 'superadmin' && (string)($meGet['role'] ?? '') !== 'superadmin') return ['ok' => false, 'msg' => __('vai.err_nouser')];
    $s = $db->prepare('SELECT COUNT(*) AS c, COALESCE(SUM(price_paid),0) AS s FROM sales WHERE user_id=?');
    $s->execute([(int)$a['id']]);
    $agg = $s->fetch() ?: [];
    $row['orders'] = (int)($agg['c'] ?? 0);
    $row['spent'] = (float)($agg['s'] ?? 0);
    return ['ok' => true, 'data' => $row];
}
function ai_tool_user_set_role(PDO $db, array $a): array {
    $id = (int)$a['id'];
    $role = trim((string)$a['role']);
    if (!role_slug_valid($role)) return ['ok' => false, 'msg' => __('vai.err_badrole')];
    if (role_get($db, $role) === null) return ['ok' => false, 'msg' => __('vai.err_role404')];
    $me = function_exists('auth_user') ? auth_user() : null;
    if ($id === (int)($me['id'] ?? 0)) return ['ok' => false, 'msg' => __('vai.err_selfrole')];
    if ($role === 'superadmin' && (string)($me['role'] ?? '') !== 'superadmin') {
        $boot = false;
        if ((string)($me['role'] ?? '') === 'admin') {
            try { $boot = ((int)$db->query("SELECT COUNT(*) FROM users WHERE role='superadmin'")->fetchColumn() === 0); } catch (\Throwable $e) { $boot = false; }
        }
        if (!$boot) return ['ok' => false, 'msg' => __('vai.err_badrole')];
    }
    $cur = $db->prepare('SELECT role FROM users WHERE id=? LIMIT 1');
    $cur->execute([$id]);
    $curRole = (string)($cur->fetchColumn() ?: '');
    if ($curRole === 'superadmin' && (string)($me['role'] ?? '') !== 'superadmin') return ['ok' => false, 'msg' => __('vai.err_badrole')];
    $st = $db->prepare('SELECT username FROM users WHERE id=? LIMIT 1');
    $st->execute([$id]);
    $un = (string)($st->fetchColumn() ?: '#' . $id);
    $up = $db->prepare('UPDATE users SET role=? WHERE id=?');
    $up->execute([$role, $id]);
    if ($up->rowCount() === 0) return ['ok' => false, 'msg' => __('vai.err_nouser')];
    auth_bump_session_version($db, $id);
    return ['ok' => true, 'id' => $id, 'label' => $un . ' → ' . $role, 'url' => '/admin/users.php'];
}
function ai_tool_sales_list(PDO $db, array $a): array {
    $st = $db->prepare('SELECT s.id,s.price_paid,s.purchased_at,u.username,p.name AS pname FROM sales s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN products p ON p.id=s.product_id ORDER BY s.id DESC LIMIT ?');
    $st->bindValue(1, (int)($a['limit'] ?? 10), PDO::PARAM_INT);
    $st->execute();
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_products_list(PDO $db, array $a): array {
    $q = trim((string)($a['q'] ?? ''));
    $lim = (int)($a['limit'] ?? 10);
    if ($q !== '') {
        $st = $db->prepare('SELECT id,name,price,category,status,stock,stock_type FROM products WHERE name LIKE ? ORDER BY created_at DESC LIMIT ?');
        $st->bindValue(1, '%' . $q . '%', PDO::PARAM_STR);
        $st->bindValue(2, $lim, PDO::PARAM_INT);
        $st->execute();
    } else {
        $st = $db->prepare('SELECT id,name,price,category,status,stock,stock_type FROM products ORDER BY created_at DESC LIMIT ?');
        $st->bindValue(1, $lim, PDO::PARAM_INT);
        $st->execute();
    }
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_tickets_list(PDO $db, array $a): array {
    $status = trim((string)($a['status'] ?? ''));
    $lim = (int)($a['limit'] ?? 10);
    if ($status !== '') {
        $st = $db->prepare('SELECT t.id,t.title,t.status,t.created_at,u.username FROM tickets t LEFT JOIN users u ON u.id=t.user_id WHERE t.status=? ORDER BY t.created_at DESC LIMIT ?');
        $st->bindValue(1, $status, PDO::PARAM_STR);
        $st->bindValue(2, $lim, PDO::PARAM_INT);
        $st->execute();
    } else {
        $st = $db->prepare('SELECT t.id,t.title,t.status,t.created_at,u.username FROM tickets t LEFT JOIN users u ON u.id=t.user_id ORDER BY t.created_at DESC LIMIT ?');
        $st->bindValue(1, $lim, PDO::PARAM_INT);
        $st->execute();
    }
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_ticket_reply(PDO $db, array $a): array {
    $id = (int)$a['id'];
    $msg = mb_substr(trim((string)$a['message']), 0, 2000);
    if ($msg === '') return ['ok' => false, 'msg' => __('vai.err_emptymsg')];
    $me = function_exists('auth_user') ? auth_user() : null;
    $uid = (int)($me['id'] ?? 0);
    $ck = $db->prepare('SELECT id FROM tickets WHERE id=? LIMIT 1');
    $ck->execute([$id]);
    if (!$ck->fetch()) return ['ok' => false, 'msg' => __('vai.err_ticket404')];
    $db->prepare('INSERT INTO ticket_replies (ticket_id,user_id,is_admin,message,created_at) VALUES (?,?,1,?,NOW())')->execute([$id, $uid, $msg]);
    $db->prepare('UPDATE tickets SET status=?,updated_at=NOW() WHERE id=?')->execute(['replied', $id]);
    return ['ok' => true, 'id' => $id, 'label' => '#' . $id, 'url' => '/admin/support.php'];
}
function ai_tool_ticket_close(PDO $db, array $a): array {
    $id = (int)$a['id'];
    $st = $db->prepare('UPDATE tickets SET status=?,updated_at=NOW() WHERE id=?');
    $st->execute(['closed', $id]);
    if ($st->rowCount() === 0) return ['ok' => false, 'msg' => __('vai.err_ticket404')];
    return ['ok' => true, 'id' => $id, 'label' => '#' . $id, 'url' => '/admin/support.php'];
}
function ai_tool_coupon_create(PDO $db, array $a): array {
    $code = strtoupper(trim((string)$a['code']));
    if ($code === '') return ['ok' => false, 'msg' => __('vai.err_code')];
    try {
        $db->prepare('INSERT INTO coupons (code,type,reward_type,reward_value,max_uses,is_active) VALUES (?,?,?,?,?,1)')->execute([$code, $a['type'] ?? 'percent', 'discount', (float)($a['value'] ?? 10), (int)($a['max_uses'] ?? 100)]);
    } catch (\Throwable $e) { return ['ok' => false, 'msg' => __('vai.err_codedup')]; }
    $id = (int)$db->lastInsertId();
    return ['ok' => true, 'id' => $id, 'label' => $code, 'url' => '/admin/coupons.php'];
}
function ai_tool_coupon_toggle(PDO $db, array $a): array {
    $st = $db->prepare('UPDATE coupons SET is_active=1-is_active WHERE id=?');
    $st->execute([(int)$a['id']]);
    if ($st->rowCount() === 0) return ['ok' => false, 'msg' => __('vai.err_coupon404')];
    return ['ok' => true, 'id' => (int)$a['id'], 'label' => '#' . (int)$a['id'], 'url' => '/admin/coupons.php'];
}
function ai_tool_settings_set(PDO $db, array $a): array {
    $key = trim((string)$a['key']);
    $val = mb_substr(trim((string)$a['value']), 0, 300);
    if (!in_array($key, ['site_name', 'footer_copyright', 'maintenance_mode'], true)) return ['ok' => false, 'msg' => __('vai.err_keylock')];
    if ($key === 'maintenance_mode' && $val !== '0' && $val !== '1') return ['ok' => false, 'msg' => __('vai.err_01')];
    $st = $db->prepare('SELECT `key` FROM settings WHERE `key`=? LIMIT 1');
    $st->execute([$key]);
    if ($st->fetch()) $db->prepare('UPDATE settings SET `value`=? WHERE `key`=?')->execute([$val, $key]);
    else $db->prepare('INSERT INTO settings (`key`,`value`) VALUES (?,?)')->execute([$key, $val]);
    return ['ok' => true, 'label' => $key, 'url' => '/admin/settings.php?tab=site'];
}
function ai_tool_announcements_list(PDO $db, array $a): array {
    $st = $db->prepare('SELECT id,title,status,created_at FROM announcements ORDER BY created_at DESC LIMIT ?');
    $st->bindValue(1, (int)($a['limit'] ?? 8), PDO::PARAM_INT);
    $st->execute();
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_seo_set(PDO $db, array $a): array {
    $key = trim((string)$a['key']);
    if (!preg_match('/^[a-z0-9_\-]{1,60}$/', $key)) return ['ok' => false, 'msg' => __('vai.err_badparam', ['k' => 'key'])];
    $t = mb_substr(trim((string)($a['title'] ?? '')), 0, 100);
    $d = mb_substr(trim((string)($a['desc'] ?? '')), 0, 200);
    $up = $db->prepare('INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');
    $up->execute(['seo_' . $key . '_title', $t]);
    $up->execute(['seo_' . $key . '_description', $d]);
    return ['ok' => true, 'label' => $key, 'url' => '/admin/seo.php'];
}
function ai_tool_announcement_create(PDO $db, array $a): array {
    $title = trim((string)$a['title']);
    if ($title === '') return ['ok' => false, 'msg' => __('vai.err_noname')];
    $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower(mb_substr($title, 0, 80))), '-');
    if ($slug === '') $slug = 'duyuru';
    $base = $slug; $i = 1;
    while (true) {
        $ck = $db->prepare('SELECT id FROM announcements WHERE slug=? LIMIT 1');
        $ck->execute([$slug]);
        if (!$ck->fetch()) break;
        $slug = $base . '-' . ($i++);
    }
    $body = function_exists('nx_clean_html') ? nx_clean_html(trim((string)($a['content'] ?? '')), 'rich') : trim(strip_tags((string)($a['content'] ?? '')));
    $db->prepare('INSERT INTO announcements (title,slug,content,status,created_at) VALUES (?,?,?,?,NOW())')->execute([$title, $slug, $body, 'published']);
    $id = (int)$db->lastInsertId();
    return ['ok' => true, 'id' => $id, 'label' => $title, 'url' => '/admin/announcements.php'];
}
function ai_tool_user_add_balance(PDO $db, array $a): array {
    $id = (int)$a['id'];
    $amount = round((float)$a['amount'], 2);
    if ($amount <= 0 || $amount > 1000000) return ['ok' => false, 'msg' => __('vai.err_badparam', ['k' => 'amount'])];
    $ck = $db->prepare('SELECT username,role FROM users WHERE id=? LIMIT 1');
    $ck->execute([$id]);
    $urow = $ck->fetch() ?: [];
    $un = (string)($urow['username'] ?? '');
    if ($un === '') return ['ok' => false, 'msg' => __('vai.err_nouser')];
    $meBal = function_exists('auth_user') ? auth_user() : null;
    if ((string)($urow['role'] ?? '') === 'superadmin' && (string)($meBal['role'] ?? '') !== 'superadmin') return ['ok' => false, 'msg' => __('vai.err_noperm')];
    $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$amount, $id]);
    $note = trim((string)($a['note'] ?? ''));
    try {
        $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?, ?,NOW())')->execute([$id, $amount, 'admin', $note !== '' ? $note : 'AI']);
    } catch (\Throwable $e) {}
    return ['ok' => true, 'id' => $id, 'label' => $un, 'url' => '/admin/users.php'];
}
function ai_tool_product_set_stock(PDO $db, array $a): array {
    $id = (int)$a['id'];
    $stock = max(0, (int)$a['stock']);
    $st = $db->prepare('UPDATE products SET stock_type=?, stock=? WHERE id=?');
    $st->execute(['limited', $stock, $id]);
    if ($st->rowCount() === 0) return ['ok' => false, 'msg' => __('vai.err_noproduct')];
    return ['ok' => true, 'id' => $id, 'label' => '#' . $id, 'url' => '/admin/products.php?edit=' . $id];
}
function ai_tool_product_set_image(PDO $db, array $a): array {
    $id = (int)$a['id'];
    $url = trim((string)$a['url']);
    if ($url === '' || (!preg_match('#^https?://#i', $url) && strncmp($url, '/uploads/', 9) !== 0)) return ['ok' => false, 'msg' => __('vai.err_badparam', ['k' => 'url'])];
    $st = $db->prepare('UPDATE products SET image_url=? WHERE id=?');
    $st->execute([mb_substr($url, 0, 512), $id]);
    if ($st->rowCount() === 0) return ['ok' => false, 'msg' => __('vai.err_noproduct')];
    return ['ok' => true, 'id' => $id, 'label' => '#' . $id, 'url' => '/admin/products.php?edit=' . $id];
}
function ai_tool_licenses_list(PDO $db, array $a): array {
    $st = $db->prepare('SELECT l.id,u.username,p.name AS pname,l.status FROM licenses l LEFT JOIN users u ON u.id=l.user_id LEFT JOIN products p ON p.id=l.product_id ORDER BY l.id DESC LIMIT ?');
    $st->bindValue(1, (int)($a['limit'] ?? 10), PDO::PARAM_INT);
    $st->execute();
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_license_toggle(PDO $db, array $a): array {
    $st = $db->prepare("UPDATE licenses SET status=IF(status='active','suspended','active') WHERE id=?");
    $st->execute([(int)$a['id']]);
    if ($st->rowCount() === 0) return ['ok' => false, 'msg' => __('vai.err_nolicense')];
    return ['ok' => true, 'id' => (int)$a['id'], 'label' => '#' . (int)$a['id'], 'url' => '/admin/licenses.php'];
}
function ai_tool_coupon_delete(PDO $db, array $a): array {
    $st = $db->prepare('SELECT code FROM coupons WHERE id=? LIMIT 1');
    $st->execute([(int)$a['id']]);
    $code = (string)($st->fetchColumn() ?: '#' . (int)$a['id']);
    $del = $db->prepare('DELETE FROM coupons WHERE id=?');
    $del->execute([(int)$a['id']]);
    if ($del->rowCount() === 0) return ['ok' => false, 'msg' => __('vai.err_coupon404')];
    return ['ok' => true, 'id' => (int)$a['id'], 'label' => $code, 'url' => '/admin/coupons.php'];
}
function ai_tool_announcement_delete(PDO $db, array $a): array {
    $st = $db->prepare('SELECT title FROM announcements WHERE id=? LIMIT 1');
    $st->execute([(int)$a['id']]);
    $title = (string)($st->fetchColumn() ?: '#' . (int)$a['id']);
    $del = $db->prepare('DELETE FROM announcements WHERE id=?');
    $del->execute([(int)$a['id']]);
    if ($del->rowCount() === 0) return ['ok' => false, 'msg' => 'Duyuru bulunamadı.'];
    return ['ok' => true, 'id' => (int)$a['id'], 'label' => $title, 'url' => '/admin/announcements.php'];
}
function ai_tool_sales_get(PDO $db, array $a): array {
    $st = $db->prepare('SELECT s.id,s.price_paid,s.purchased_at,u.username,p.name AS pname FROM sales s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN products p ON p.id=s.product_id WHERE s.id=? LIMIT 1');
    $st->execute([(int)$a['id']]);
    $row = $st->fetch();
    if (!$row) return ['ok' => false, 'msg' => 'Sipariş bulunamadı.'];
    return ['ok' => true, 'data' => $row];
}
function ai_tool_users_stats(PDO $db, array $a): array {
    $total = (int)$db->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
    $week = (int)$db->query("SELECT COUNT(*) FROM users WHERE role='user' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)")->fetchColumn();
    $staff = (int)$db->query("SELECT COUNT(*) FROM users WHERE role<>'user'")->fetchColumn();
    return ['ok' => true, 'data' => ['customers' => $total, 'new_7d' => $week, 'staff' => $staff]];
}
function ai_tool_tickets_open(PDO $db, array $a): array {
    $st = $db->prepare('SELECT t.id,t.title,t.category,t.created_at,u.username FROM tickets t LEFT JOIN users u ON u.id=t.user_id WHERE t.status=? ORDER BY t.created_at DESC LIMIT ?');
    $st->bindValue(1, 'open', PDO::PARAM_STR);
    $st->bindValue(2, (int)($a['limit'] ?? 5), PDO::PARAM_INT);
    $st->execute();
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_coupons_list(PDO $db, array $a): array {
    $st = $db->prepare('SELECT code,used_count,max_uses,is_active FROM coupons ORDER BY used_count DESC LIMIT ?');
    $st->bindValue(1, (int)($a['limit'] ?? 8), PDO::PARAM_INT);
    $st->execute();
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_audit_recent(PDO $db, array $a): array {
    $sql = 'SELECT username,user_role,`action`,resource,label,created_at FROM audit_logs';
    $params = [];
    $w = [];
    if (trim((string)($a['username'] ?? '')) !== '') { $w[] = 'username LIKE ?'; $params[] = '%' . $a['username'] . '%'; }
    if ($w) $sql .= ' WHERE ' . implode(' AND ', $w);
    $sql .= ' ORDER BY id DESC LIMIT ?';
    $st = $db->prepare($sql);
    foreach ($params as $i => $p) $st->bindValue($i + 1, $p, PDO::PARAM_STR);
    $st->bindValue(count($params) + 1, (int)($a['limit'] ?? 8), PDO::PARAM_INT);
    $st->execute();
    return ['ok' => true, 'data' => $st->fetchAll()];
}
function ai_tool_settings_get(PDO $db, array $a): array {
    $out = [];
    foreach ($db->query("SELECT `key`,`value` FROM settings WHERE `key` IN ('site_name','site_url','active_theme','primary_lang','store_currency','maintenance_mode')")->fetchAll() as $r) {
        $out[$r['key']] = $r['value'];
    }
    return ['ok' => true, 'data' => $out];
}
function ai_tool_seo_get(PDO $db, array $a): array {
    $out = [];
    foreach ($db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'seo\\_%' ESCAPE '\\' LIMIT 40")->fetchAll() as $r) {
        $out[$r['key']] = mb_substr((string)$r['value'], 0, 200);
    }
    return ['ok' => true, 'data' => $out];
}
function ai_secret_mask(string $key): bool {
    return (bool)preg_match('/secret|_key$|pat|password|token|salt/i', $key);
}
function ai_lang(): string {
    return (function_exists('lang_active') && lang_active() === 'en') ? 'en' : 'tr';
}
function ai_writer_prompt(?PDO $db, string $context): string {
    $key = 'ai_prompt_' . preg_replace('/[^a-z_]/', '', $context);
    try {
        if ($db === null && function_exists('nexus_db')) $db = nexus_db();
        if ($db) {
            $st = $db->prepare("SELECT `value` FROM settings WHERE `key`=? LIMIT 1");
            $st->execute([$key]);
            $custom = trim((string)($st->fetchColumn() ?? ''));
            if ($custom !== '') return $custom;
        }
    } catch (\Throwable $e) {}
    $en = ai_lang() === 'en';
    if ($context === 'announcement') {
        if ($en) return 'You are an official announcement editor. Short, clear, corporate English. No fluff, highlight dates if given. Use markdown, never return plain text inside code blocks. If info is missing, add ONLY this block and nothing else: ```ask {"questions":[{"q":"question","options":["a","b"]}]}```';
        return 'Sen resmi duyuru metinleri yazan bir editörsün. Kısa, net, kurumsal ve güven veren Türkçe kullan. Gereksiz süsleme yapma, tarih/saat bilgisi varsa öne çıkar. Markdown kullan, asla kod bloğu içinde düz metin döndürme. Bilgin eksikse yanıtına SADECE şu bloğu ekle, başka metin yazma: ```ask {"questions":[{"q":"soru","options":["a","b"]}]}```';
    }
    if ($context === 'seo') {
        if ($en) return 'You are an English SEO specialist. Reply with ONLY this JSON block, nothing else: ```json {"title":"title under 60 chars","desc":"description under 160 chars"}``` Put the page keyword first, write clickably.';
        return 'Sen Türkçe SEO uzmanısın. Yanıtın SADECE şu JSON bloğu olsun, başka metin yazma: ```json {"title":"60 karakteri geçmeyen başlık","desc":"160 karakteri geçmeyen açıklama"}``` Sayfa adındaki anahtar kelimeyi başa koy, tıklanabilir yaz.';
    }
    if ($en) return 'You are an English e-commerce copywriter. Persuasive, honest, trustworthy promo language. Markdown: short intro, feature list, closing. NEVER put the product name or price inside the body text unless asked; use the provided context only as background. Never return plain text inside code blocks. If info is missing, add ONLY this block and nothing else: ```ask {"questions":[{"q":"question","options":["a","b"]}]}```. Use previous answers from the conversation, never ask twice.';
    return 'Sen Türkçe e-ticaret metin yazarısın. Ürünü satan, abartısız, güven veren tanıtım dili kullan. Ürün adı ve fiyatı SADECE bağlam bilgisidir; sorulmadıkça gövde metnine yazma. Markdown kullan: kısa giriş, özellik listesi, kapanış. Asla kod bloğu içinde düz metin döndürme. Sohbetteki önceki cevapları hatırla, aynı şeyi iki kez sorma. Bilgin eksikse yanıtına SADECE şu bloğu ekle, başka metin yazma: ```ask {"questions":[{"q":"soru","options":["a","b"]}]}```';
}
function ai_demo_write(?PDO $db, string $context, string $prompt, array $data = []): string {
    $p = trim($prompt) !== '' ? trim($prompt) : 'ürün';
    if ($context === 'announcement') {
        return '## Duyuru' . "\n" . $p . ' hakkında detaylar çok yakında burada olacak.' . "\n" . '- Tarih netleşince güncellenecek' . "\n" . '- Sorularınız için destek sayfası';
    }
    if ($context === 'seo') {
        $t = mb_substr(trim((string)($data['label'] ?? $p)), 0, 55);
        return '```json {"title":"' . str_replace('"', '', $t) . '","desc":"' . str_replace('"', '', mb_substr($t . ' en uygun fiyatlarla burada.', 0, 150)) . '"}```';
    }
    $name = trim((string)($data['name'] ?? $p));
    $out = '## ' . $name . "\n" . $name . ' ile tanışın: günlük kullanım için pratik çözüm.' . "\n";
    if (trim((string)($data['price'] ?? '')) !== '') $out .= "\n" . '**Fiyat:** ' . $data['price'] . "\n";
    $out .= "\n" . '- Hızlı teslimat' . "\n" . '- Güvenli ödeme' . "\n" . '- 7/24 destek';
    return $out;
}
function ai_system_prompt(?PDO $db = null): string {
    $custom = '';
    try {
        if ($db === null && function_exists('nexus_db')) $db = nexus_db();
        if ($db) {
            $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='ai_system_prompt' LIMIT 1");
            $st->execute();
            $custom = trim((string)($st->fetchColumn() ?? ''));
        }
    } catch (\Throwable $e) {}
    $lines = [];
    foreach (ai_tools() as $name => $def) {
        $ps = [];
        foreach ($def['params'] as $k => $spec) {
            $ps[] = $k . ':' . ($spec['type'] ?? 'string') . (!empty($spec['required']) ? '*' : '');
        }
        $lines[] = '- ' . $name . '(' . implode(',', $ps) . ') [' . $def['permission'] . ']' . (!empty($def['destructive']) ? ' ONAYLI' : '');
    }
    $base = "Sen Vexaris mağaza asistanısın. Türkçe yanıt ver, markdown kullan. Sana verilen araçları (tool) çağırarak mağazayı yönetirsin. Yıkıcı işlemlerde önce özet gösterip onay istersin. Gizli anahtarları asla açık yazmazsın. Kullanılabilir araçlar:\n" . implode("\n", $lines);
    return $custom !== '' ? $custom . "\n\n" . $base : $base;
}
function ai_parse_command(string $message): ?array {
    $m = trim($message);
    if (strncmp($m, '/', 1) !== 0) return null;
    $parts = preg_split('/\s+/', $m, 3);
    $cmd = mb_strtolower($parts[0]);
    $rest = trim(trim($parts[1] ?? '') . ' ' . trim($parts[2] ?? ''));
    if (preg_match('/^\/user:(\d+)$/i', $m, $mm)) return ['tool' => 'user.get', 'args' => ['id' => (int)$mm[1]]];
    if (preg_match('/^\/product:(\d+)$/i', $m, $mm)) return ['tool' => 'product.get', 'args' => ['id' => (int)$mm[1]]];
    if (preg_match('/^\/ticket:(\d+)$/i', $m, $mm)) return ['tool' => 'tickets.list', 'args' => ['limit' => 1]];
    $map = ['/users' => 'users.list', '/products' => 'products.list', '/orders' => 'sales.list', '/sales' => 'sales.list', '/stock' => 'products.low_stock', '/tickets' => 'tickets.list', '/logs' => 'audit.recent', '/coupons' => 'coupons.list', '/stats' => 'store.stats', '/help' => 'help'];
    if (!isset($map[$cmd])) return null;
    if ($cmd === '/help') return ['tool' => 'help', 'args' => []];
    $args = ['limit' => 10];
    if ($rest !== '' && in_array($cmd, ['/users', '/products'], true)) {
        if (ctype_digit($rest)) $args['limit'] = min(30, max(1, (int)$rest));
        else { $args['q'] = mb_substr($rest, 0, 60); }
    } elseif ($rest !== '' && $cmd === '/tickets' && in_array(mb_strtolower($rest), ['open', 'replied', 'closed'], true)) {
        $args['status'] = mb_strtolower($rest);
    }
    return ['tool' => $map[$cmd], 'args' => $args];
}
function ai_format_rows(string $title, array $rows, callable $fmt): string {
    if (!$rows) return 'Kayıt yok.';
    $out = ['## ' . $title];
    foreach ($rows as $r) $out[] = '- ' . $fmt($r);
    return implode("\n", $out);
}
function ai_demo_reply(?PDO $db, string $message): array {
    $cmd = ai_parse_command($message);
    if ($cmd !== null) {
        if ($cmd['tool'] === 'help') {
            return ['reply' => "Komutlar:\n- `/users [ara|limit]` `/user:ID`\n- `/products [ara|limit]` `/product:ID`\n- `/orders` `/stock` `/tickets [open|replied|closed]`\n- `/coupons` `/logs` `/stats`"];
        }
        $r = ai_tool_run($db, $cmd['tool'], $cmd['args']);
        if (empty($r['ok'])) return ['reply' => $r['msg'] ?? 'Araç hatası.'];
        $rows = $r['data'] ?? [];
        if ($cmd['tool'] === 'users.list') return ['reply' => ai_format_rows('Kullanıcılar', $rows, function ($u) { return '**' . ($u['username'] ?? '?') . '** (' . ($u['role'] ?? '') . ')'; })];
        if ($cmd['tool'] === 'user.get') {
            $u = $rows;
            return ['reply' => '## ' . ($u['username'] ?? '?') . "\n- **Rol:** " . ($u['role'] ?? '') . "\n- **Bakiye:** " . ($u['balance'] ?? 0) . "\n- **Sipariş:** " . (int)($u['orders'] ?? 0)];
        }
        if ($cmd['tool'] === 'products.list') return ['reply' => ai_format_rows('Ürünler', $rows, function ($p) { return '**' . ($p['name'] ?? '?') . '** #' . (int)($p['id'] ?? 0); })];
        if ($cmd['tool'] === 'product.get') {
            $p = $rows;
            return ['reply' => '## ' . ($p['name'] ?? '?') . "\n- **Fiyat:** " . ($p['price'] ?? 0) . "\n- **Stok:** " . ($p['stock'] ?? 0) . "\n- **Durum:** " . ($p['status'] ?? '')];
        }
        if ($cmd['tool'] === 'sales.list') return ['reply' => ai_format_rows('Siparişler', $rows, function ($s) { return '**' . ($s['pname'] ?? '#') . '** — ' . ($s['username'] ?? '?'); })];
        if ($cmd['tool'] === 'tickets.list') return ['reply' => ai_format_rows('Talepler', $rows, function ($t) { return '#**' . $t['id'] . '** ' . ($t['title'] ?? '') . ' (' . ($t['status'] ?? '') . ')'; })];
        if ($cmd['tool'] === 'coupons.list') return ['reply' => ai_format_rows('Kuponlar', $rows, function ($c) { return '`' . $c['code'] . '` ' . (int)$c['used_count'] . '/' . (int)$c['max_uses']; })];
        if ($cmd['tool'] === 'audit.recent') return ['reply' => ai_format_rows('Son Olaylar', $rows, function ($l) { return '**' . ($l['username'] ?? '?') . '** ' . ($l['action'] ?? '') . ' ' . ($l['resource'] ?? ''); })];
        if ($cmd['tool'] === 'store.stats') {
            $d = $rows;
            return ['reply' => '## Mağaza Özeti' . "\n- **Ciro:** " . ($d['revenue'] ?? 0) . "\n- **Satış:** " . (int)($d['sales'] ?? 0)];
        }
        if ($cmd['tool'] === 'products.low_stock') return ['reply' => ai_format_rows('Kritik Stok', $rows, function ($p) { return '**' . ($p['name'] ?? '?') . '** — ' . (int)($p['stock'] ?? 0); })];
    }
    $m = mb_strtolower(trim($message));
    $has = function (array $words) use ($m) {
        foreach ($words as $w) if (mb_strpos($m, $w) !== false) return true;
        return false;
    };
    if ($has(['ciro', 'kazanç', 'kazanc', 'gelir', 'toplam'])) {
        $r = ai_tool_run($db, 'store.stats', []);
        $d = $r['data'] ?? [];
        return ['reply' => "## Mağaza Özeti\n- **Ciro:** " . number_format((float)($d['revenue'] ?? 0), 2, ',', '.') . "\n- **Satış:** " . (int)($d['sales'] ?? 0) . "\n- **Müşteri:** " . (int)($d['customers'] ?? 0) . "\n- **Açık destek:** " . (int)($d['open_tickets'] ?? 0) . "\n- **Kritik stok:** " . (int)($d['low_stock'] ?? 0)];
    }
    if ($has(['stok'])) {
        $r = ai_tool_run($db, 'products.low_stock', ['limit' => 8]);
        $rows = $r['data'] ?? [];
        if (!$rows) return ['reply' => 'Kritik stokta ürün yok.'];
        $out = ["## Kritik Stok"];
        foreach ($rows as $p) $out[] = '- **' . $p['name'] . '** — ' . (int)$p['stock'] . ' adet';
        return ['reply' => implode("\n", $out)];
    }
    if ($has(['üye', 'uye', 'kullanıcı', 'kullanici', 'müşteri', 'musteri'])) {
        $r = ai_tool_run($db, 'users.stats', []);
        $d = $r['data'] ?? [];
        return ['reply' => "## Üyeler\n- **Müşteri:** " . (int)($d['customers'] ?? 0) . "\n- **Son 7 gün:** +" . (int)($d['new_7d'] ?? 0) . "\n- **Ekip:** " . (int)($d['staff'] ?? 0)];
    }
    if ($has(['sipariş', 'siparis', 'satış', 'satis', 'son'])) {
        $r = ai_tool_run($db, 'sales.recent', ['limit' => 5]);
        $rows = $r['data'] ?? [];
        if (!$rows) return ['reply' => 'Henüz satış yok.'];
        $out = ["## Son Satışlar"];
        foreach ($rows as $s) $out[] = '- **' . ($s['pname'] ?? '#') . '** — ' . ($s['username'] ?? '?');
        return ['reply' => implode("\n", $out)];
    }
    if ($has(['log', 'denetim', 'kim ne'])) {
        $r = ai_tool_run($db, 'audit.recent', ['limit' => 8]);
        $rows = $r['data'] ?? [];
        if (!$rows) return ['reply' => 'Denetim kaydı yok.'];
        $out = ["## Son Olaylar"];
        foreach ($rows as $l) $out[] = '- **' . ($l['username'] ?? '?') . '** ' . ($l['action'] ?? '') . ' ' . ($l['resource'] ?? '') . ' — ' . ($l['label'] ?? '');
        return ['reply' => implode("\n", $out)];
    }
    if ($has(['destek', 'ticket', 'talep'])) {
        $r = ai_tool_run($db, 'tickets.open', ['limit' => 5]);
        $rows = $r['data'] ?? [];
        if (!$rows) return ['reply' => 'Açık destek talebi yok.'];
        $out = ["## Açık Talepler"];
        foreach ($rows as $t) $out[] = '- #' . $t['id'] . ' **' . $t['title'] . '** (' . ($t['username'] ?? '?') . ')';
        return ['reply' => implode("\n", $out)];
    }
    if ($has(['kupon'])) {
        $r = ai_tool_run($db, 'coupons.list', ['limit' => 8]);
        $rows = $r['data'] ?? [];
        if (!$rows) return ['reply' => 'Kupon yok.'];
        $out = ["## Kuponlar"];
        foreach ($rows as $c) $out[] = '- `' . $c['code'] . '` ' . (int)$c['used_count'] . '/' . (int)$c['max_uses'];
        return ['reply' => implode("\n", $out)];
    }
    if ($has(['ürün', 'urun'])) {
        $r = ai_tool_run($db, 'products.top', ['limit' => 5]);
        $rows = $r['data'] ?? [];
        if (!$rows) return ['reply' => 'Satışlı ürün yok.'];
        $out = ["## Çok Satanlar"];
        foreach ($rows as $p) $out[] = '- **' . $p['name'] . '** (' . (int)$p['c'] . ')';
        return ['reply' => implode("\n", $out)];
    }
    return ['reply' => "Merhaba! Mağazanı yönetebilirim. Örnekler:\n- `ciro nedir?`\n- `kritik stoklar`\n- `son satışlar`\n- `açık talepler`\n- `son olaylar`"];
}
