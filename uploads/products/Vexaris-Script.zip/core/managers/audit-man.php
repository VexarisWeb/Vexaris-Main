<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
function audit_log(?PDO $db, string $action, string $resource, int $resourceId, string $label, string $url = '', ?array $asUser = null): void {
    try {
        if ($db === null && function_exists('nexus_db')) $db = nexus_db();
        if (!$db) return;
        $u = $asUser !== null ? $asUser : (function_exists('auth_user') ? auth_user() : null);
        $uid = (int)($u['id'] ?? 0);
        $un = mb_substr(trim((string)($u['username'] ?? '')), 0, 32);
        $rl = mb_substr(trim((string)($u['role'] ?? '')), 0, 30);
        $a = in_array($action, ['create','update','delete'], true) ? $action : 'update';
        $ip = mb_substr(trim((string)($_SERVER['REMOTE_ADDR'] ?? '')), 0, 45);
        $res = mb_substr($resource, 0, 60);
        $rid = max(0, $resourceId);
        $lbl = mb_substr($label, 0, 255);
        $dup = $db->prepare("SELECT id FROM audit_logs WHERE user_id=? AND `action`=? AND resource=? AND resource_id=? AND label=? AND created_at >= DATE_SUB(NOW(), INTERVAL 10 SECOND) LIMIT 1");
        $dup->execute([$uid, $a, $res, $rid, $lbl]);
        if ($dup->fetch()) return;
        $st = $db->prepare('INSERT INTO audit_logs (user_id,username,user_role,action,resource,resource_id,label,url,ip) VALUES (?,?,?,?,?,?,?,?,?)');
        $st->execute([$uid, $un, $rl, $a, $res, $rid, $lbl, mb_substr($url, 0, 255), $ip]);
    } catch (\Throwable $e) {}
}
function audit_resource_icon(string $resource): string {
    static $map = null;
    if ($map === null) {
        $map = [
            'products' => 'fa-solid fa-box', 'purchases' => 'fa-solid fa-bag-shopping',
            'categories' => 'fa-solid fa-tags', 'licenses' => 'fa-solid fa-key',
            'reviews' => 'fa-solid fa-star', 'coupons' => 'fa-solid fa-ticket',
            'slider' => 'fa-solid fa-images', 'announcements' => 'fa-solid fa-bullhorn',
            'references' => 'fa-solid fa-quote-right', 'seo' => 'fa-solid fa-magnifying-glass-chart',
            'custom_pages' => 'fa-solid fa-file-lines', 'legal' => 'fa-solid fa-gavel',
            'themes' => 'fa-solid fa-swatchbook', 'users' => 'fa-solid fa-user',
            'permissions' => 'fa-solid fa-shield-halved', 'roles' => 'fa-solid fa-user-gear',
            'settings' => 'fa-solid fa-sliders', 'integrations' => 'fa-solid fa-plug',
            'modules' => 'fa-solid fa-puzzle-piece', 'support' => 'fa-solid fa-message',
            'ticket_categories' => 'fa-solid fa-tags', 'discord-webhook' => 'fa-brands fa-discord',
            'stats' => 'fa-solid fa-chart-line', 'dashboard' => 'fa-solid fa-house',
            'versions' => 'fa-solid fa-code-branch', 'stock' => 'fa-solid fa-boxes',
            'sales' => 'fa-solid fa-receipt', 'balance' => 'fa-solid fa-coins',
        ];
    }
    return $map[$resource] ?? 'fa-solid fa-circle-dot';
}
function audit_action_meta(string $action): array {
    if ($action === 'create') return ['fa-solid fa-plus', '#4ade80'];
    if ($action === 'delete') return ['fa-solid fa-trash', '#f87171'];
    return ['fa-solid fa-pen', '#818cf8'];
}
