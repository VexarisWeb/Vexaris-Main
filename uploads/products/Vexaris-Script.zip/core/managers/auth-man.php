<?php
defined('NEXUS_BOOT') or die('Direct access denied.');

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_samesite', 'Lax');
    if (function_exists('request_is_https') ? request_is_https() : (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')) {
        ini_set('session.cookie_secure', 1);
    }
    session_start();
}
if (!isset($_SESSION['user']) && isset($_COOKIE['remember_token'])) {
    $tok = $_COOKIE['remember_token'];
    if (preg_match('/^[a-f0-9]{64}$/', $tok)) {
        $h = hash('sha256', $tok);
        try {
            $dbR = nexus_db();
            if ($dbR) {
                $st = $dbR->prepare("SELECT user_id FROM remember_tokens WHERE token_hash=? AND expires_at > NOW() LIMIT 1");
                $st->execute([$h]);
                $uid = $st->fetchColumn();
                if ($uid) {
                    $u = $dbR->prepare("SELECT id, username, email, password, avatar, role, balance, session_version FROM users WHERE id=? LIMIT 1");
                    $u->execute([(int)$uid]);
                    $user = $u->fetch();
                    if ($user) {
                        try {
                            $dbR->beginTransaction();
                            $claim = $dbR->prepare("DELETE FROM remember_tokens WHERE token_hash=?");
                            $claim->execute([$h]);
                            if ($claim->rowCount() === 0) { $dbR->rollBack(); }
                            else {
                                $dbR->prepare("DELETE FROM remember_tokens WHERE expires_at < NOW()")->execute();
                                $rawNew = bin2hex(random_bytes(32));
                                $expNew = date('Y-m-d H:i:s', time() + 60*60*24*30);
                                $dbR->prepare("INSERT INTO remember_tokens (user_id, token_hash, expires_at) VALUES (?,?,?)")->execute([(int)$uid, hash('sha256', $rawNew), $expNew]);
                                $dbR->commit();
                                session_regenerate_id(true);
                                $_SESSION['user'] = [
                                    'id'              => $user['id'],
                                    'username'        => $user['username'],
                                    'email'           => $user['email'],
                                    'avatar'          => $user['avatar'] ?: 'https://minotar.net/avatar/user.png',
                                    'role'            => $user['role'],
                                    'balance'         => (float)($user['balance'] ?? 0),
                                    'session_version' => (int)($user['session_version'] ?? 0),
                                ];
                                $secNew = function_exists('request_is_https') ? request_is_https() : (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
                                setcookie('remember_token', $rawNew, ['expires'=>time()+60*60*24*30,'path'=>'/','httponly'=>true,'samesite'=>'Lax','secure'=>$secNew]);
                            }
                        } catch (Throwable $e) {
                            if ($dbR->inTransaction()) $dbR->rollBack();
                        }
                    }
                }
            }
        } catch (Throwable $e) {}
    }
}

/* ──────────────────────────────────────────
   Yardımcılar
────────────────────────────────────────── */

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="_csrf_token" value="' . csrf_token() . '">';
}

function csrf_check(): bool {
    $token = $_POST['_csrf_token'] ?? '';
    if ($token === '') $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if ($token === '' && !empty($_POST)) {
        $raw = file_get_contents('php://input');
        if (!empty($raw) && strpos($raw, '{') === 0) {
            $json = json_decode($raw, true);
            $token = is_array($json) ? ($json['_csrf_token'] ?? '') : '';
        }
    }
    return !empty($token) && hash_equals(csrf_token(), (string)$token);
}

function csrf_verify(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    $token = $_POST['_csrf_token'] ?? '';
    if ($token === '') $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if ($token === '') {
        $raw = file_get_contents('php://input');
        if (!empty($raw) && strpos($raw, '{') === 0) {
            $json = json_decode($raw, true);
            $token = is_array($json) ? ($json['_csrf_token'] ?? '') : '';
        }
    }
    if (empty($token) || !hash_equals(csrf_token(), $token)) {
        $acceptJson = strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false;
        $isXhr = strtolower(trim($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
        $fetchMode = strtolower(trim($_SERVER['HTTP_SEC_FETCH_MODE'] ?? ''));
        if ($acceptJson || $isXhr || $fetchMode === 'cors') {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'code' => 'csrf_fail', 'msg' => __('auth.csrf_fail')]);
            exit;
        }
        header('Location: /login?flash=error%3AGüvenlik+doğrulaması+başarısız.', true, 302);
        exit;
    }
}

function verify_captcha(): bool {
    $db = nexus_db();
    if (!$db) return true;
    try {
        $st = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'");
        $cfg = [];
        while ($r = $st->fetch()) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[NS] verify_captcha settings: ' . $e->getMessage());
        return true;
    }
    $endpoint = '';
    $secret   = '';
    $token    = '';
    if (($cfg['int_cf_captcha_enabled'] ?? '0') === '1' && !empty($cfg['int_cf_captcha_secret_key'])) {
        $endpoint = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
        $secret   = $cfg['int_cf_captcha_secret_key'];
        $token    = $_POST['cf-turnstile-response'] ?? '';
    } elseif (($cfg['int_recaptcha_enabled'] ?? '0') === '1' && !empty($cfg['int_recaptcha_secret_key'])) {
        $endpoint = 'https://www.google.com/recaptcha/api/siteverify';
        $secret   = $cfg['int_recaptcha_secret_key'];
        $token    = $_POST['g-recaptcha-response'] ?? '';
    }
    if ($endpoint === '') return true;
    if ($token === '') return false;
    $postData = http_build_query(['secret' => $secret, 'response' => $token]);
    if (function_exists('curl_init')) {
        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $postData,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
        ]);
        $raw = curl_exec($ch);
        if ($raw === false) error_log('[NS] verify_captcha curl: ' . curl_error($ch));
        curl_close($ch);
    } else {
        $ctx = stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => 'Content-Type: application/x-www-form-urlencoded',
                'content' => $postData,
                'timeout' => 10,
            ],
        ]);
        $raw = @file_get_contents($endpoint, false, $ctx);
    }
    if (empty($raw)) return false;
    $json = json_decode($raw, true);
    return !empty($json['success']);
}

function rate_limit_allow(PDO $db, string $scope, string $ip, int $limit, int $minutes): bool {
    try {
        $mins = max(1, min(1440, $minutes));
        $st = $db->prepare('SELECT COUNT(*) FROM rate_limits WHERE scope=? AND ip=? AND attempted_at > DATE_SUB(NOW(), INTERVAL ' . $mins . ' MINUTE)');
        $st->execute([$scope, $ip]);
        return ((int)$st->fetchColumn() < $limit);
    } catch (Throwable $e) {
        return true;
    }
}

function rate_limit_hit(PDO $db, string $scope, string $ip): void {
    try {
        $db->prepare('INSERT INTO rate_limits (scope,ip,attempted_at) VALUES (?,?,NOW())')->execute([$scope, $ip]);
        if (mt_rand(1, 100) === 1) $db->exec('DELETE FROM rate_limits WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 2 HOUR)');
    } catch (Throwable $e) {}
}

if (isset($_SESSION['user']['id'])) {
    try {
        $dbV = nexus_db();
        if ($dbV) {
            $vSt = $dbV->prepare('SELECT session_version FROM users WHERE id=? LIMIT 1');
            $vSt->execute([(int)$_SESSION['user']['id']]);
            $dbVer = $vSt->fetchColumn();
            if ($dbVer === false || (int)($_SESSION['user']['session_version'] ?? -1) !== (int)$dbVer) {
                auth_logout();
                if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false) {
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode(['ok' => false, 'msg' => __('auth.session_killed')]);
                    exit;
                }
            }
        }
    } catch (Throwable $e) {}
}

function auth_bump_session_version(PDO $db, int $userId): int {
    $db->prepare('UPDATE users SET session_version=session_version+1 WHERE id=?')->execute([$userId]);
    $st = $db->prepare('SELECT session_version FROM users WHERE id=? LIMIT 1');
    $st->execute([$userId]);
    $ver = (int)($st->fetchColumn() ?? 0);
    try { $db->prepare('DELETE FROM remember_tokens WHERE user_id=?')->execute([$userId]); } catch (Throwable $e) {}
    return $ver;
}

function auth_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function auth_check(): bool {
    return isset($_SESSION['user']);
}

function auth_redirect_if_logged_in(string $to = '/'): void {
    if (auth_check()) {
        header('Location: ' . $to, true, 302);
        exit;
    }
}

function auth_require(string $to = '/login'): void {
    if (!auth_check()) {
        header('Location: ' . $to, true, 302);
        exit;
    }
}

/* ──────────────────────────────────────────
   Kayıt
────────────────────────────────────────── */

function auth_register(string $username, string $email, string $password): array {
    $db = nexus_db();
    if (!$db) return ['ok' => false, 'msg' => __('auth.db_fail')];

    $username = trim($username);
    $email    = trim(strtolower($email));

    if (strlen($username) < 3 || strlen($username) > 32)
        return ['ok' => false, 'msg' => __('err.username_length')];
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username))
        return ['ok' => false, 'msg' => __('err.username_chars')];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        return ['ok' => false, 'msg' => __('err.invalid_email')];
    if (strlen($password) < 8)
        return ['ok' => false, 'msg' => __('auth.password_min')];

    // Tekrar kontrolü
    $stmt = $db->prepare('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1');
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) return ['ok' => false, 'msg' => __('err.username_taken')];

    $hash   = password_hash($password, PASSWORD_BCRYPT);
    $avatar = 'https://minotar.net/avatar/user.png';

    $stmt = $db->prepare(
        'INSERT INTO users (username, email, password, avatar, role, created_at)
         VALUES (?, ?, ?, ?, "user", NOW())'
    );
    $stmt->execute([$username, $email, $hash, $avatar]);

    if (defined('ROOT_PATH')) {
        require_once ROOT_PATH . '/core/discord.php';
        discord_notify($db, 'register', __('bsupp.reg_new'), __('bsupp.reg_body'), [
            __('bsupp.field_username') => $username,
            'E-posta'      => $email,
        ], '15844338');
    }

    try {
        require_once ROOT_PATH . '/core/mail.php';
        if (mail_is_available()) {
            $vToken = bin2hex(random_bytes(32));
            $db->prepare('UPDATE email_verifications SET used=1 WHERE email=?')->execute([$email]);
            $db->prepare('INSERT INTO email_verifications (email, token, expires_at) VALUES (?,?,DATE_ADD(NOW(), INTERVAL 48 HOUR))')
                ->execute([$email, $vToken]);
            mail_send($email, 'account_activation', [
                'user_name'         => $username,
                'verification_link' => mail_base_url() . '/verify-email?token=' . $vToken,
            ]);
        }
    } catch (\Throwable $e) {
        error_log('[NS] auth_register activation mail: ' . $e->getMessage());
    }

    return ['ok' => true, 'msg' => __('auth.register_ok')];
}

/* ──────────────────────────────────────────
   Giriş
────────────────────────────────────────── */

function auth_login(string $identifier, string $password, bool $remember = false): array {
    $db = nexus_db();
    if (!$db) return ['ok' => false, 'msg' => __('auth.db_fail')];

    $identifier = trim($identifier);

    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $st = $db->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip=? AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)');
    $st->execute([$ip]);
    if ((int)$st->fetchColumn() >= 5) {
        return ['ok' => false, 'msg' => __('auth.too_many')];
    }

    $stmt = $db->prepare(
        'SELECT id, username, email, password, avatar, role, balance, session_version FROM users
         WHERE username = ? OR email = ? LIMIT 1'
    );
    $stmt->execute([$identifier, $identifier]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        $db->prepare('INSERT INTO login_attempts (ip,attempted_at) VALUES (?,NOW())')->execute([$ip]);
        return ['ok' => false, 'msg' => __('auth.bad_credentials')];
    }

    try {
        $evSt = $db->prepare("SELECT `value` FROM settings WHERE `key`='email_verify_required' LIMIT 1");
        $evSt->execute();
        if ($evSt->fetchColumn() === '1') {
            $uvSt = $db->prepare('SELECT email_verified FROM users WHERE id=? LIMIT 1');
            $uvSt->execute([(int)$user['id']]);
            if ((int)($uvSt->fetchColumn() ?? 0) !== 1) {
                return ['ok' => false, 'msg' => __('auth.email_not_verified')];
            }
        }
    } catch (\Throwable $e) {}

    $db->prepare('DELETE FROM login_attempts WHERE ip=?')->execute([$ip]);

    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id'              => $user['id'],
        'username'        => $user['username'],
        'email'           => $user['email'],
        'avatar'          => $user['avatar'] ?: 'https://minotar.net/avatar/user.png',
        'role'            => $user['role'],
        'balance'         => (float)($user['balance'] ?? 0),
        'session_version' => (int)($user['session_version'] ?? 0),
    ];
    if ($remember) {
        try {
            $raw = bin2hex(random_bytes(32));
            $hash = hash('sha256', $raw);
            $exp = date('Y-m-d H:i:s', time() + 60*60*24*30);
            $db->prepare("INSERT INTO remember_tokens (user_id, token_hash, expires_at) VALUES (?,?,?)")->execute([$user['id'], $hash, $exp]);
            $secure = function_exists('request_is_https') ? request_is_https() : (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
            setcookie('remember_token', $raw, ['expires'=>time()+60*60*24*30,'path'=>'/','httponly'=>true,'samesite'=>'Lax','secure'=>$secure]);
        } catch (Throwable $e) {}
    }

    return ['ok' => true, 'msg' => __('auth.login_ok')];
}

/* ──────────────────────────────────────────
   ID ile Giriş (OAuth)
────────────────────────────────────────── */

function auth_login_by_id(int $userId): bool {
    $db = nexus_db();
    if (!$db) return false;

    $stmt = $db->prepare('SELECT id, username, email, password, avatar, role, balance, session_version FROM users WHERE id=? LIMIT 1');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) return false;

    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id'              => $user['id'],
        'username'        => $user['username'],
        'email'           => $user['email'],
        'avatar'          => $user['avatar'] ?: 'https://minotar.net/avatar/user.png',
        'role'            => $user['role'],
        'balance'         => (float)($user['balance'] ?? 0),
        'session_version' => (int)($user['session_version'] ?? 0),
    ];

    return true;
}

/* ──────────────────────────────────────────
   Çıkış
────────────────────────────────────────── */

function auth_logout(): void {
    if (isset($_COOKIE['remember_token'])) {
        $h = hash('sha256', $_COOKIE['remember_token']);
        try { $dbL = nexus_db(); if ($dbL) $dbL->prepare("DELETE FROM remember_tokens WHERE token_hash=?")->execute([$h]); } catch (Throwable $e) {}
        $secure = function_exists('request_is_https') ? request_is_https() : (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        setcookie('remember_token', '', ['expires'=>time()-3600,'path'=>'/','httponly'=>true,'samesite'=>'Lax','secure'=>$secure]);
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 3600, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/* ──────────────────────────────────────────
   Parola Sıfırlama
────────────────────────────────────────── */

function mail_base_url(): string {
    try {
        $db = function_exists('nexus_db') ? nexus_db() : null;
        if ($db) {
            $st = $db->prepare("SELECT value FROM settings WHERE `key`='site_url' LIMIT 1");
            $st->execute();
            $base = trim((string)($st->fetchColumn() ?? ''));
            if ($base !== '') {
                if (strpos($base, '://') === false) $base = 'https://' . $base;
                return rtrim($base, '/');
            }
        }
    } catch (\Throwable $e) {}
    try {
        if (defined('LOCK_FILE') && is_file(LOCK_FILE)) {
            $lockRaw = @file_get_contents(LOCK_FILE);
            $lock = is_string($lockRaw) ? json_decode($lockRaw, true) : null;
            $lockDomain = strtolower(trim((string)(is_array($lock) ? ($lock['domain'] ?? '') : '')));
            if ($lockDomain !== '' && preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $lockDomain)) {
                return 'https://' . rtrim($lockDomain, '/');
            }
        }
    } catch (\Throwable $e) {}
    $scheme = function_exists('request_is_https') ? (request_is_https() ? 'https' : 'http') : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http');
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    if (!preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) $host = 'localhost';
    error_log('[NS] mail_base_url host fallback: ' . $host);
    return $scheme . '://' . $host;
}

function auth_request_password_reset(string $email): array {
    $db = nexus_db();
    if (!$db) return ['ok' => false, 'msg' => __('auth.db_error')];
    $email = trim(strtolower($email));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        return ['ok' => false, 'msg' => __('err.invalid_email')];

    $rlIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if (!rate_limit_allow($db, 'pwd_request', $rlIp, 5, 60))
        return ['ok' => false, 'msg' => __('auth.reset_throttled')];
    rate_limit_hit($db, 'pwd_request', $rlIp);

    if (defined('ROOT_PATH')) {
        require_once ROOT_PATH . '/core/mail.php';
    }
    if (!function_exists('mail_is_available') || !mail_is_available()) {
        return ['ok' => false, 'msg' => __('auth.reset_unavailable')];
    }

    try {
        $st = $db->prepare('SELECT id, username FROM users WHERE email=? LIMIT 1');
        $st->execute([$email]);
        $user = $st->fetch();
        if (!$user) return ['ok' => true, 'msg' => __('auth.reset_sent_generic')];

        $token = bin2hex(random_bytes(32));
        $db->prepare('UPDATE password_resets SET used=1 WHERE email=?')->execute([$email]);
        $db->prepare('INSERT INTO password_resets (email, token, expires_at) VALUES (?,?,DATE_ADD(NOW(), INTERVAL 1 HOUR))')
           ->execute([$email, hash('sha256', $token)]);

        $resetLink = mail_base_url() . '/reset-password?token=' . $token;
        try {
            require_once ROOT_PATH . '/core/mail.php';
            mail_send($email, 'password_reset', [
                'user_name'  => $user['username'],
                'reset_link' => $resetLink,
            ]);
        } catch (\Throwable $e) {
            error_log('[NS] auth_request_password_reset mail: ' . $e->getMessage());
        }
        return ['ok' => true, 'msg' => __('auth.reset_sent')];
    } catch (\Exception $e) {
        error_log('[NS] auth_request_password_reset: ' . $e->getMessage());
        return ['ok' => false, 'msg' => __('op.error')];
    }
}

function auth_reset_password(string $token, string $newPassword): array {
    $db = nexus_db();
    if (!$db) return ['ok' => false, 'msg' => __('auth.db_error')];
    $token = trim($token);
    if (strlen($newPassword) < 8)
        return ['ok' => false, 'msg' => __('auth.password_min')];
    if ($token === '')
        return ['ok' => false, 'msg' => __('auth.reset_invalid')];

    $rlIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if (!rate_limit_allow($db, 'pwd_reset', $rlIp, 10, 60))
        return ['ok' => false, 'msg' => __('bsupp.too_many')];
    rate_limit_hit($db, 'pwd_reset', $rlIp);

    try {
        $db->beginTransaction();
        $st = $db->prepare('SELECT email FROM password_resets WHERE token=? AND used=0 AND expires_at > NOW() LIMIT 1 FOR UPDATE');
        $st->execute([hash('sha256', $token)]);
        $row = $st->fetch();
        if (!$row) { $db->rollBack(); return ['ok' => false, 'msg' => __('auth.reset_invalid')]; }

        $hash = password_hash($newPassword, PASSWORD_BCRYPT);
        $db->prepare('UPDATE users SET password=?, session_version=session_version+1 WHERE email=?')->execute([$hash, $row['email']]);
        try {
            $rv = $db->prepare('SELECT id FROM users WHERE email=? LIMIT 1');
            $rv->execute([$row['email']]);
            if ($rid = $rv->fetchColumn()) $db->prepare('DELETE FROM remember_tokens WHERE user_id=?')->execute([(int)$rid]);
        } catch (Throwable $e) {}
        $db->prepare('UPDATE password_resets SET used=1 WHERE token=?')->execute([hash('sha256', $token)]);
        $db->prepare('DELETE FROM login_attempts WHERE ip=?')->execute([$_SERVER['REMOTE_ADDR'] ?? 'unknown']);
        $db->commit();
        return ['ok' => true, 'msg' => __('bsupp.pass_reset_ok')];
    } catch (\Exception $e) {
        error_log('[NS] auth_reset_password: ' . $e->getMessage());
        return ['ok' => false, 'msg' => __('op.error')];
    }
}
