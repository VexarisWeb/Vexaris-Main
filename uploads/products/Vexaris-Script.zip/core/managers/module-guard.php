<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
class ModuleGuardViolation extends \RuntimeException {}
class ModuleGuardPDO {
    private $db;
    private $slug;
    public function __construct(PDO $db, string $slug) {
        $this->db = $db;
        $this->slug = $slug;
    }
    public function slug(): string {
        return $this->slug;
    }
    public function inner(): PDO {
        return $this->db;
    }
    private function check(string $sql): string {
        module_guard_check($sql);
        return $sql;
    }
    public function prepare($sql, $options = []) {
        return $this->db->prepare($this->check((string)$sql), $options);
    }
    public function query($sql, ...$args) {
        return $this->db->query($this->check((string)$sql), ...$args);
    }
    public function exec($sql) {
        return $this->db->exec($this->check((string)$sql));
    }
    public function __call($name, $args) {
        return $this->db->$name(...$args);
    }
    public function lastInsertId($name = null) {
        return $this->db->lastInsertId($name);
    }
    public function beginTransaction() {
        return $this->db->beginTransaction();
    }
    public function commit() {
        return $this->db->commit();
    }
    public function rollBack() {
        return $this->db->rollBack();
    }
    public function inTransaction() {
        return $this->db->inTransaction();
    }
    public function errorCode() {
        return $this->db->errorCode();
    }
    public function errorInfo() {
        return $this->db->errorInfo();
    }
    public function quote($str, $type = PDO::PARAM_STR) {
        return $this->db->quote($str, $type);
    }
}
function module_db(string $slug, ?PDO $db = null): ModuleGuardPDO {
    if (!module_slug_valid($slug)) throw new ModuleGuardViolation('slug');
    if ($db === null && function_exists('nexus_db')) $db = nexus_db();
    if (!$db) throw new ModuleGuardViolation('db');
    return new ModuleGuardPDO($db, $slug);
}
function module_guard_check(string $sql): void {
    $s = ltrim($sql);
    $s = preg_replace('/^\(\s*/', '', $s);
    $s = preg_replace('/^(?:\/\*.*?\*\/|--[^\n]*\n|#[^\n]*\n|\s)+/s', '', $s);
    $low = strtolower(substr($s, 0, 24));
    $first = strtolower(strtok($s, " \t\n\r("));
    if ($first === 'select' || $first === 'show' || $first === 'describe' || $first === 'desc' || $first === 'explain') {
        module_guard_no_multistatement($s);
        return;
    }
    if ($first === 'begin' || $first === 'start' || $first === 'commit' || $first === 'rollback' || $first === 'savepoint') {
        module_guard_no_multistatement($s);
        return;
    }
    if ($first === 'insert') {
        module_guard_no_multistatement($s);
        $t = module_guard_target_table($s, 'insert');
        if ($t === '' || strncmp($t, 'mod_', 4) !== 0) throw new ModuleGuardViolation('insert');
        return;
    }
    if ($first === 'update' || $first === 'delete') {
        module_guard_no_multistatement($s);
        $t = module_guard_target_table($s, $first);
        if ($t === '' || strncmp($t, 'mod_', 4) !== 0) throw new ModuleGuardViolation($first);
        if (!preg_match('/\bwhere\b/i', $s)) throw new ModuleGuardViolation('where');
        return;
    }
    throw new ModuleGuardViolation($first === '' ? 'empty' : $first);
}
function module_guard_no_multistatement(string $s): void {
    $t = rtrim($s);
    if (substr($t, -1) === ';') $t = rtrim(substr($t, 0, -1));
    $inS = false;
    $inD = false;
    $len = strlen($t);
    for ($i = 0; $i < $len; $i++) {
        $c = $t[$i];
        if ($c === "'" && !$inD) {
            if ($i + 1 < $len && $t[$i + 1] === "'") { $i++; continue; }
            $inS = !$inS;
        } elseif ($c === '"' && !$inS) {
            $inD = !$inD;
        } elseif ($c === ';' && !$inS && !$inD) {
            throw new ModuleGuardViolation('multi');
        }
    }
}
function module_guard_target_table(string $s, string $verb): string {
    $pat = $verb === 'insert'
        ? '/insert\s+(?:ignore\s+)?(?:into\s+)?[`"\[]?([a-z0-9_]+)/i'
        : '/(?:update\s+|delete\s+(?:ignore\s+)?(?:low_priority\s+|quick\s+)?(?:from\s+)?)[`"\[]?([a-z0-9_]+)/i';
    if (!preg_match($pat, $s, $mm)) return '';
    return strtolower($mm[1]);
}
function module_guard_tables(string $sql): array {
    $out = [];
    if (preg_match_all('/(?:from|join|update|into|table)\s+[`"\[]?([a-z0-9_]+)/i', $sql, $mm)) {
        foreach ($mm[1] as $t) $out[] = strtolower($t);
    }
    return array_values(array_unique($out));
}
function module_safe_mode(?PDO $db = null): bool {
    try {
        if ($db === null && function_exists('nexus_db')) $db = nexus_db();
        if (!$db) return true;
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='module_safe_mode' LIMIT 1");
        $st->execute();
        $v = $st->fetchColumn();
        if ($v === false || $v === null) return true;
        return ((string)$v === '1');
    } catch (\Throwable $e) { return true; }
}
function module_scan_files(string $slug): array {
    $out = [];
    if (!module_slug_valid($slug)) return $out;
    $base = modules_dir() . DIRECTORY_SEPARATOR . $slug . DIRECTORY_SEPARATOR;
    foreach (['module.php', 'admin.php', 'install.sql'] as $rel) {
        $f = $base . $rel;
        if (is_file($f)) $out[] = $f;
    }
    $cb = $base . 'callback';
    if (is_dir($cb)) {
        foreach (@scandir($cb) ?: [] as $e) {
            if (substr($e, -4) !== '.php') continue;
            $out[] = $cb . DIRECTORY_SEPARATOR . $e;
        }
    }
    return $out;
}
function module_scan_risks(string $slug): array {
    $risks = [];
    foreach (module_scan_files($slug) as $file) {
        $raw = @file_get_contents($file);
        if (!is_string($raw) || $raw === '') continue;
        $rel = basename($file);
        $code = preg_replace('/\/\*.*?\*\//s', ' ', $raw);
        $code = preg_replace('/\/\/[^\n]*/', ' ', (string)$code);
        $code = preg_replace('/#[^\n]*/', ' ', (string)$code);
        $bare = module_scan_strip_strings((string)$code);
        $critCode = [
            '/\beval\s*\(/i' => 'eval',
            '/\bcreate_function\s*\(/i' => 'create_function',
            '/\bexec\s*\(/i' => 'exec',
            '/\bshell_exec\s*\(/i' => 'shell_exec',
            '/\bsystem\s*\(/i' => 'system',
            '/\bpassthru\s*\(/i' => 'passthru',
            '/\bpopen\s*\(/i' => 'popen',
            '/\bproc_open\s*\(/i' => 'proc_open',
            '/\bpcntl_exec\s*\(/i' => 'pcntl_exec',
            '/`[^`]*[\s;$|][^`]*`/' => 'backtick',
        ];
        $critSql = [
            '/\bdrop\s+(table|database)\b/i' => 'drop',
            '/\btruncate\s+[`"\[]?[a-z0-9_]+/i' => 'truncate',
            '/\balter\s+table\s+[`"\[]?(?!mod_)[a-z0-9_]+/i' => 'alter',
            '/\bdelete\s+(?:ignore\s+)?(?:low_priority\s+|quick\s+)?(?:from\s+)?[`"\[]?(?!mod_)[a-z0-9_]+/i' => 'delete',
        ];
        $isSql = substr($rel, -4) === '.sql';
        foreach ($critCode as $pat => $name) {
            if ($isSql) continue;
            if (!preg_match($pat, (string)$bare)) continue;
            $lvl = ($name === 'backtick' && $rel === 'admin.php') ? 'high' : 'critical';
            $risks[] = ['level' => $lvl, 'pattern' => $name, 'file' => $rel];
        }
        if (!$isSql) {
            foreach ($critSql as $pat => $name) {
                if (preg_match($pat, (string)$code)) $risks[] = ['level' => 'critical', 'pattern' => $name, 'file' => $rel];
            }
        }
        $highCode = [
            '/\bbase64_decode\s*\(/i' => 'base64_decode',
            '/\bgzinflate\s*\(/i' => 'gzinflate',
            '/\bgzuncompress\s*\(/i' => 'gzuncompress',
            '/\bstr_rot13\s*\(/i' => 'str_rot13',
            '/\bcurl_init\s*\(/i' => 'curl',
            '/\bset_time_limit\s*\(/i' => 'set_time_limit',
            '/\bignore_user_abort\s*\(/i' => 'ignore_user_abort',
            '/\bini_set\s*\(/i' => 'ini_set',
            '/\bnexus_db\s*\(/i' => 'nexus_db',
            '/\bunlink\s*\(/i' => 'unlink',
            '/\bchmod\s*\(|\bchown\s*\(|\bsymlink\s*\(/i' => 'fs_perm',
            '/\bfile_put_contents\s*\(/i' => 'file_write',
            '/\bmove_uploaded_file\s*\(/i' => 'upload_move',
        ];
        foreach ($highCode as $pat => $name) {
            if (preg_match($pat, (string)$bare)) $risks[] = ['level' => ($name === 'file_write' || $name === 'upload_move') ? 'medium' : 'high', 'pattern' => $name, 'file' => $rel];
        }
        if (preg_match('/file_get_contents\s*\(\s*[\'"]https?:\/\//i', (string)$code)) $risks[] = ['level' => 'high', 'pattern' => 'remote_fetch', 'file' => $rel];
        if (preg_match('/\b(update|insert\s+(?:ignore\s+)?(?:into\s+)?)\s+[`"\[]?(?!mod_)([a-z0-9_]+)/i', (string)$code)) $risks[] = ['level' => 'medium', 'pattern' => 'core_write', 'file' => $rel];
    }
    return $risks;
}
function module_scan_strip_strings(string $code): string {
    try {
        $toks = @token_get_all($code);
        if (!is_array($toks)) return $code;
        $out = '';
        foreach ($toks as $t) {
            if (is_array($t)) {
                $id = $t[0];
                if ($id === T_CONSTANT_ENCAPSED_STRING) { $out .= "''"; continue; }
                if ($id === T_ENCAPSED_AND_WHITESPACE || $id === T_START_HEREDOC || $id === T_END_HEREDOC) { $out .= ' '; continue; }
                $out .= $t[1];
            } else {
                $out .= $t;
            }
        }
        return $out;
    } catch (\Throwable $e) { return $code; }
}
function module_risk_level(string $slug): string {
    $hasHigh = false;
    $hasMed = false;
    foreach (module_scan_risks($slug) as $r) {
        if (($r['level'] ?? '') === 'critical') return 'critical';
        if (($r['level'] ?? '') === 'high') $hasHigh = true;
        if (($r['level'] ?? '') === 'medium') $hasMed = true;
    }
    if ($hasHigh) return 'high';
    if ($hasMed) return 'medium';
    return 'low';
}
function module_hook_slow_log(string $tag, float $seconds): void {
    if ($seconds < 2.0) return;
    try { error_log('[Vexaris] slow hook ' . $tag . ': ' . round($seconds, 2) . 's'); } catch (\Throwable $e) {}
    try {
        $db = function_exists('nexus_db') ? nexus_db() : null;
        if (!$db) return;
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='_mod_slow' LIMIT 1");
        $st->execute();
        $raw = (string)($st->fetchColumn() ?: '[]');
        $list = json_decode($raw, true);
        if (!is_array($list)) $list = [];
        array_unshift($list, ['tag' => mb_substr($tag, 0, 80), 'sec' => round($seconds, 2), 'ts' => time()]);
        $list = array_slice($list, 0, 20);
        $js = json_encode($list, JSON_UNESCAPED_UNICODE);
        $ck = $db->prepare("SELECT `key` FROM settings WHERE `key`='_mod_slow' LIMIT 1");
        $ck->execute();
        if ($ck->fetch()) $db->prepare("UPDATE settings SET `value`=? WHERE `key`='_mod_slow'")->execute([$js]);
        else $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('_mod_slow',?)")->execute([$js]);
    } catch (\Throwable $e) {}
}
function module_ratelimit_table(?PDO $db): void {
    if (!$db) return;
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS `mod_rate` (`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,`k` VARCHAR(128) NOT NULL,`ts` INT UNSIGNED NOT NULL,PRIMARY KEY (`id`),KEY `idx_mr_k_ts` (`k`,`ts`),KEY `idx_mr_ts` (`ts`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (\Throwable $e) {}
}
function module_ratelimit(string $key, int $limit, int $windowSec = 60, ?PDO $db = null): bool {
    $key = mb_substr(preg_replace('/[^a-zA-Z0-9_:\-\.]/', '_', $key), 0, 120);
    if ($key === '' || $limit < 1) return false;
    try {
        if ($db === null && function_exists('nexus_db')) $db = nexus_db();
        if (!$db) return true;
        module_ratelimit_table($db);
        $now = time();
        $win = max(1, $windowSec);
        $db->prepare("DELETE FROM `mod_rate` WHERE ts < ?")->execute([$now - $win]);
        $st = $db->prepare("SELECT COUNT(*) FROM `mod_rate` WHERE `k`=? AND ts >= ?");
        $st->execute([$key, $now - $win]);
        if ((int)$st->fetchColumn() >= $limit) return false;
        $db->prepare("INSERT IGNORE INTO `mod_rate` (`k`,`ts`) VALUES (?,?)")->execute([$key, $now]);
        return true;
    } catch (\Throwable $e) { return true; }
}
