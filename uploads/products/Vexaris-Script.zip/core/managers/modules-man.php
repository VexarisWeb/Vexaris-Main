<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
function modules_dir(): string {
    return ROOT_PATH . DIRECTORY_SEPARATOR . 'modules';
}
function module_slug_valid(string $slug): bool {
    return (bool)preg_match('/^[a-z0-9][a-z0-9\-]{0,62}[a-z0-9]$/', $slug) || (bool)preg_match('/^[a-z0-9]$/', $slug);
}
function module_manifest(string $slug): ?array {
    if (!module_slug_valid($slug)) return null;
    $file = modules_dir() . DIRECTORY_SEPARATOR . $slug . DIRECTORY_SEPARATOR . 'module.json';
    if (!is_file($file)) return null;
    if ((int)@filesize($file) > 262144) return null;
    $raw = @file_get_contents($file);
    if ($raw === false) return null;
    $data = json_decode($raw, true, 32);
    if (!is_array($data)) return null;
    $name = trim((string)($data['name'] ?? ''));
    $desc = trim((string)($data['description'] ?? ''));
    $version = trim((string)($data['version'] ?? ''));
    if ($name === '' || $version === '') return null;
    if (!preg_match('/^\d+\.\d+\.\d+$/', $version)) return null;
    $fields = $data['fields'] ?? [];
    if (!is_array($fields)) return null;
    if (count($fields) > 50) return null;
    $allowedTypes = ['text', 'number', 'select', 'textarea'];
    $cleanFields = [];
    foreach ($fields as $f) {
        if (!is_array($f)) return null;
        $key = trim((string)($f['key'] ?? ''));
        $label = trim((string)($f['label'] ?? ''));
        if (!preg_match('/^[a-z0-9_]{1,40}$/', $key)) return null;
        if ($label === '') return null;
        $type = (string)($f['type'] ?? 'text');
        if (!in_array($type, $allowedTypes, true)) return null;
        $field = ['key' => $key, 'label' => $label, 'type' => $type];
        if (isset($f['placeholder'])) $field['placeholder'] = mb_substr((string)$f['placeholder'], 0, 200);
        if (isset($f['step'])) $field['step'] = mb_substr((string)$f['step'], 0, 20);
        if ($type === 'select') {
            $opts = $f['options'] ?? null;
            if (!is_array($opts) || count($opts) === 0 || count($opts) > 200) return null;
            $cleanOpts = [];
            foreach ($opts as $opt) {
                if (is_array($opt)) {
                    $v = (string)($opt['value'] ?? '');
                    $l = (string)($opt['label'] ?? $v);
                } else {
                    $v = (string)$opt;
                    $l = (string)$opt;
                }
                if ($v === '') return null;
                $cleanOpts[] = ['value' => mb_substr($v, 0, 100), 'label' => mb_substr($l, 0, 100)];
            }
            $field['options'] = $cleanOpts;
        }
        $cleanFields[] = $field;
    }
    $adminPage = !empty($data['admin_page']) && is_file(modules_dir() . DIRECTORY_SEPARATOR . $slug . DIRECTORY_SEPARATOR . 'admin.php');
    $gateway = null;
    if (is_array($data['gateway'] ?? null)) {
        $gwCode = trim((string)($data['gateway']['code'] ?? ''));
        $gwLabel = trim((string)($data['gateway']['label'] ?? ''));
        $coreCodes = ['shopier', 'paytr', 'iyzico', 'stripe', 'paypal', 'bitpay', 'crypt', 'paywant'];
        if (preg_match('/^[a-z0-9_]{1,20}$/', $gwCode) && !in_array($gwCode, $coreCodes, true) && $gwLabel !== '') {
            $gwColor = trim((string)($data['gateway']['color'] ?? ''));
            if (!preg_match('/^#[0-9a-fA-F]{6}$/', $gwColor)) $gwColor = '#0ea5e9';
            $gateway = ['code' => $gwCode, 'label' => mb_substr($gwLabel, 0, 40), 'color' => $gwColor];
        }
    }
    $adminMenu = null;
    if ($adminPage && is_array($data['admin_menu'] ?? null)) {
        $menuLabel = trim((string)($data['admin_menu']['label'] ?? ''));
        if ($menuLabel !== '') {
            $menuIcon = trim((string)($data['admin_menu']['icon'] ?? 'fa-puzzle-piece'));
            if (!preg_match('/^[a-z0-9 \-]+$/i', $menuIcon)) $menuIcon = 'fa-puzzle-piece';
            $adminMenu = ['label' => mb_substr($menuLabel, 0, 60), 'icon' => mb_substr($menuIcon, 0, 60)];
        }
    }
    $adminSection = ['key' => 'modules', 'label' => 'Modüller', 'icon' => 'fa-puzzle-piece'];
    if (is_array($data['admin_section'] ?? null)) {
        $secKey = trim((string)($data['admin_section']['key'] ?? 'modules'));
        if (!preg_match('/^[a-z0-9_]{1,30}$/', $secKey)) $secKey = 'modules';
        $secLabel = trim((string)($data['admin_section']['label'] ?? 'Modüller'));
        if ($secLabel === '') $secLabel = 'Modüller';
        $secIcon = trim((string)($data['admin_section']['icon'] ?? 'fa-puzzle-piece'));
        if (!preg_match('/^[a-z0-9 \-]+$/i', $secIcon)) $secIcon = 'fa-puzzle-piece';
        $adminSection = ['key' => $secKey, 'label' => mb_substr($secLabel, 0, 60), 'icon' => mb_substr($secIcon, 0, 60)];
    }
    return [
        'slug' => $slug,
        'name' => mb_substr($name, 0, 80),
        'description' => mb_substr($desc, 0, 300),
        'version' => $version,
        'author' => mb_substr(trim((string)($data['author'] ?? '')), 0, 80),
        'icon' => (function () use ($data) { $v = trim((string)($data['icon'] ?? 'fa-puzzle-piece')); return preg_match('/^[a-z0-9 \-]+$/i', $v) ? mb_substr($v, 0, 60) : 'fa-puzzle-piece'; })(),
        'iconPrefix' => (function () use ($data) { $v = trim((string)($data['iconPrefix'] ?? 'fa-solid')); return preg_match('/^[a-z0-9 \-]+$/i', $v) ? mb_substr($v, 0, 30) : 'fa-solid'; })(),
        'color' => preg_match('/^#[0-9a-fA-F]{6}$/', (string)($data['color'] ?? '')) ? (string)$data['color'] : '#8b5cf6',
        'type' => mb_substr(trim((string)($data['type'] ?? 'other')), 0, 30),
        'fields' => $cleanFields,
        'admin_page' => $adminPage,
        'admin_menu' => $adminMenu,
        'admin_section' => $adminSection,
        'gateway' => $gateway,
    ];
}
function modules_scan(): array {
    $dir = modules_dir();
    if (!is_dir($dir)) return [];
    $out = [];
    foreach (@scandir($dir) ?: [] as $entry) {
        if ($entry === '.' || $entry === '..') continue;
        if (!is_dir($dir . DIRECTORY_SEPARATOR . $entry)) continue;
        if (!module_slug_valid($entry)) continue;
        $m = module_manifest($entry);
        if ($m !== null) $out[$entry] = $m;
    }
    ksort($out);
    return $out;
}
function modules_ensure_table(?PDO $db): void {
    if (!$db) return;
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS `modules` (`slug` VARCHAR(64) NOT NULL,`enabled` TINYINT(1) NOT NULL DEFAULT 0,`version` VARCHAR(16) NOT NULL DEFAULT '1.0.0',`settings` TEXT,`sidebar` TINYINT(1) NOT NULL DEFAULT 1,`installed_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`slug`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (\PDOException $e) {}
    try {
        $db->exec("ALTER TABLE `modules` ADD COLUMN `sidebar` TINYINT(1) NOT NULL DEFAULT 1");
    } catch (\PDOException $e) {}
}
function modules_sync(?PDO $db): void {
    if (!$db) return;
    modules_ensure_table($db);
    modules_cache_clear();
    foreach (modules_scan() as $slug => $m) {
        try {
            $ins = $db->prepare("INSERT IGNORE INTO modules (`slug`,`enabled`,`version`,`settings`) VALUES (?,?,?,?)");
            $ins->execute([$slug, 0, $m['version'], json_encode(new \stdClass(), JSON_UNESCAPED_UNICODE)]);
        } catch (\Throwable $e) {}
        try {
            $up = $db->prepare("UPDATE modules SET `version`=? WHERE `slug`=? AND `version`!=?");
            $up->execute([$m['version'], $slug, $m['version']]);
        } catch (\Throwable $e) {}
    }
}
function modules_cache_clear(): void {
    $GLOBALS['__vx_modules_cache'] = null;
}
function modules_all(?PDO $db = null): array {
    if (isset($GLOBALS['__vx_modules_cache']) && is_array($GLOBALS['__vx_modules_cache'])) return $GLOBALS['__vx_modules_cache'];
    $db = $db ?? nexus_db();
    $scan = modules_scan();
    $rows = [];
    if ($db) {
        modules_ensure_table($db);
        try {
            $rows = $db->query("SELECT `slug`,`enabled`,`version`,`settings`,`sidebar` FROM modules")->fetchAll();
        } catch (\Throwable $e) {
            try {
                $rows = $db->query("SELECT `slug`,`enabled`,`version`,`settings` FROM modules")->fetchAll();
            } catch (\Throwable $e2) { $rows = []; }
        }
    }
    $bySlug = [];
    foreach ($rows as $r) $bySlug[$r['slug']] = $r;
    $out = [];
    foreach ($scan as $slug => $m) {
        $row = $bySlug[$slug] ?? null;
        $settings = [];
        if ($row && is_string($row['settings']) && $row['settings'] !== '') {
            $dec = json_decode($row['settings'], true);
            if (is_array($dec)) $settings = $dec;
        }
        $m['enabled'] = $row ? (string)$row['enabled'] : '0';
        $m['sidebar'] = ($row && array_key_exists('sidebar', $row)) ? (string)$row['sidebar'] : '1';
        $m['settings'] = $settings;
        $out[$slug] = $m;
    }
    $GLOBALS['__vx_modules_cache'] = $out;
    return $out;
}
function module_enabled(string $slug, ?PDO $db = null): bool {
    $db = $db ?? nexus_db();
    if (!$db) return false;
    try {
        $st = $db->prepare("SELECT `enabled` FROM modules WHERE `slug`=? LIMIT 1");
        $st->execute([$slug]);
        return ((string)$st->fetchColumn() === '1');
    } catch (\Throwable $e) { return false; }
}
function module_setting(string $slug, string $key, $default = '', ?PDO $db = null) {
    $db = $db ?? nexus_db();
    if (!$db) return $default;
    try {
        $st = $db->prepare("SELECT `settings` FROM modules WHERE `slug`=? LIMIT 1");
        $st->execute([$slug]);
        $raw = $st->fetchColumn();
        if (!is_string($raw) || $raw === '') return $default;
        $dec = json_decode($raw, true);
        if (!is_array($dec)) return $default;
        return $dec[$key] ?? $default;
    } catch (\Throwable $e) { return $default; }
}
function module_dict(string $slug, string $lang): array {
    static $c = [];
    $slug = preg_replace('/[^a-z0-9_\-]/', '', $slug);
    $k = $slug . '|' . $lang;
    if (isset($c[$k])) return $c[$k];
    $c[$k] = [];
    $f = ROOT_PATH . '/modules/' . $slug . '/lang/' . preg_replace('/[^a-z]/', '', $lang) . '.json';
    if ($slug !== '' && is_file($f)) {
        try {
            $d = json_decode(file_get_contents($f), true);
            if (is_array($d)) $c[$k] = $d;
        } catch (\Throwable $e) {}
    }
    return $c[$k];
}
function module_lang(string $slug, string $key, array $vars = []): string {
    $l = function_exists('lang_active') ? lang_active() : 'tr';
    $d = module_dict($slug, $l);
    $v = array_key_exists($key, $d) ? $d[$key] : null;
    if ($v === null && $l !== 'tr') {
        $d = module_dict($slug, 'tr');
        $v = array_key_exists($key, $d) ? $d[$key] : null;
    }
    if ($v === null || !is_string($v)) return function_exists('__') ? __($key, $vars) : $key;
    foreach ($vars as $k => $val) $v = str_replace('{' . $k . '}', (string)$val, $v);
    return $v;
}
function module_text(string $slug, string $key, string $default = ''): string {
    $l = function_exists('lang_active') ? lang_active() : 'tr';
    $d = module_dict($slug, $l);
    if (array_key_exists($key, $d) && is_string($d[$key]) && $d[$key] !== '') return $d[$key];
    if ($l !== 'tr') {
        $d = module_dict($slug, 'tr');
        if (array_key_exists($key, $d) && is_string($d[$key]) && $d[$key] !== '') return $d[$key];
    }
    return $default;
}
function module_optkey(string $field, string $value): string {
    $f = preg_replace('/[^A-Za-z0-9_]/', '_', $field);
    $v = preg_replace('/[^A-Za-z0-9_]/', '_', $value);
    return '_option_' . $f . '_' . $v . '_label';
}
function modules_run_install(?PDO $db, string $slug): array {
    $done = 0;
    $skipped = 0;
    if (!$db) return [$done, $skipped];
    $file = modules_dir() . DIRECTORY_SEPARATOR . $slug . DIRECTORY_SEPARATOR . 'install.sql';
    if (!is_file($file)) return [$done, $skipped];
    $sql = @file_get_contents($file);
    if (!is_string($sql) || trim($sql) === '') return [$done, $skipped];
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt === '' || strncmp(ltrim($stmt), '--', 2) === 0) { $skipped++; continue; }
        $low = strtolower(ltrim($stmt));
        $isCreate = strncmp($low, 'create table if not exists', 26) === 0;
        $isInsert = strncmp($low, 'insert ignore', 13) === 0;
        if (!$isCreate && !$isInsert) { $skipped++; continue; }
        $target = '';
        if (preg_match('/(?:create\s+table\s+if\s+not\s+exists|insert\s+ignore\s+(?:into\s+)?)\s*[`"\[]?([a-z0-9_]+)/i', $stmt, $mm)) $target = strtolower($mm[1]);
        if (strncmp($target, 'mod_', 4) !== 0) { $skipped++; continue; }
        try { $db->exec($stmt); $done++; } catch (\PDOException $e) { $skipped++; }
    }
    return [$done, $skipped];
}
function modules_set_enabled(?PDO $db, string $slug, bool $on): bool {
    if (!$db) return false;
    if (module_manifest($slug) === null) return false;
    if ($on && function_exists('module_safe_mode') && module_safe_mode($db) && function_exists('module_risk_level') && module_risk_level($slug) === 'critical') return false;
    modules_ensure_table($db);
    try {
        $st = $db->prepare("SELECT `slug` FROM modules WHERE `slug`=? LIMIT 1");
        $st->execute([$slug]);
        if (!$st->fetch()) {
            $ins = $db->prepare("INSERT INTO modules (`slug`,`enabled`,`version`,`settings`) VALUES (?,?,?,?)");
            $ins->execute([$slug, $on ? 1 : 0, (string)(module_manifest($slug)['version'] ?? '1.0.0'), json_encode(new \stdClass(), JSON_UNESCAPED_UNICODE)]);
        } else {
            $up = $db->prepare("UPDATE modules SET `enabled`=? WHERE `slug`=?");
            $up->execute([$on ? 1 : 0, $slug]);
        }
    } catch (\Throwable $e) { return false; }
    if ($on) modules_run_install($db, $slug);
    modules_cache_clear();
    return true;
}
function modules_set_sidebar(?PDO $db, string $slug, bool $show): bool {
    if (!$db) return false;
    if (module_manifest($slug) === null) return false;
    modules_ensure_table($db);
    try {
        $st = $db->prepare("SELECT `slug` FROM modules WHERE `slug`=? LIMIT 1");
        $st->execute([$slug]);
        if (!$st->fetch()) {
            $ins = $db->prepare("INSERT INTO modules (`slug`,`enabled`,`version`,`settings`,`sidebar`) VALUES (?,?,?, ?,?)");
            $ins->execute([$slug, 0, (string)(module_manifest($slug)['version'] ?? '1.0.0'), json_encode(new \stdClass(), JSON_UNESCAPED_UNICODE), $show ? 1 : 0]);
        } else {
            $up = $db->prepare("UPDATE modules SET `sidebar`=? WHERE `slug`=?");
            $up->execute([$show ? 1 : 0, $slug]);
        }
    } catch (\Throwable $e) { return false; }
    modules_cache_clear();
    return true;
}
function modules_save_settings(?PDO $db, string $slug, array $values): bool {
    if (!$db) return false;
    $m = module_manifest($slug);
    if ($m === null) return false;
    $clean = [];
    foreach ($m['fields'] as $f) {
        $key = $f['key'];
        $raw = trim((string)($values[$key] ?? ''));
        $raw = mb_substr($raw, 0, 2000);
        if (($f['type'] ?? 'text') === 'number' && $raw !== '' && !is_numeric($raw)) return false;
        if (($f['type'] ?? 'text') === 'select') {
            $allowed = array_map(function ($o) { return (string)$o['value']; }, $f['options']);
            if (!in_array($raw, $allowed, true)) return false;
        }
        $clean[$key] = $raw;
    }
    modules_ensure_table($db);
    try {
        $st = $db->prepare("SELECT `slug` FROM modules WHERE `slug`=? LIMIT 1");
        $st->execute([$slug]);
        $json = json_encode($clean, JSON_UNESCAPED_UNICODE);
        if (!$st->fetch()) {
            $ins = $db->prepare("INSERT INTO modules (`slug`,`enabled`,`version`,`settings`) VALUES (?,?,?,?)");
            $ins->execute([$slug, 0, (string)$m['version'], $json]);
        } else {
            $up = $db->prepare("UPDATE modules SET `settings`=? WHERE `slug`=?");
            $up->execute([$json, $slug]);
        }
    } catch (\Throwable $e) { return false; }
    modules_cache_clear();
    return true;
}
function modules_load_active(?PDO $db = null): void {
    $db = $db ?? nexus_db();
    if (!$db) return;
    try {
        $st = $db->query("SELECT `slug` FROM modules WHERE `enabled`='1'");
        $rows = $st ? $st->fetchAll() : [];
    } catch (\Throwable $e) { return; }
    foreach ($rows as $r) {
        $slug = (string)($r['slug'] ?? '');
        if (!module_slug_valid($slug)) continue;
        $mani = module_manifest($slug);
        if ($mani === null) continue;
        if (function_exists('plan_module_allowed') && !plan_module_allowed($slug, $mani)) continue;
        $file = modules_dir() . DIRECTORY_SEPARATOR . $slug . DIRECTORY_SEPARATOR . 'module.php';
        if (!is_file($file)) continue;
        try { require_once $file; } catch (\Throwable $e) { error_log('[Vexaris] module load ' . $slug . ': ' . $e->getMessage()); }
    }
}
function modules_print_head_assets(): void {
    foreach (modules_all() as $slug => $m) {
        if (($m['enabled'] ?? '0') !== '1') continue;
        $css = modules_dir() . DIRECTORY_SEPARATOR . $slug . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'css' . DIRECTORY_SEPARATOR . 'style.css';
        if (is_file($css)) {
            echo '<link rel="stylesheet" href="/modules/' . $slug . '/assets/css/style.css?v=' . e($m['version'] ?? '1.0.0') . '">' . "\n";
        }
    }
}
function modules_print_footer_assets(): void {
    foreach (modules_all() as $slug => $m) {
        if (($m['enabled'] ?? '0') !== '1') continue;
        $js = modules_dir() . DIRECTORY_SEPARATOR . $slug . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'js' . DIRECTORY_SEPARATOR . 'app.js';
        if (is_file($js)) {
            echo '<script src="/modules/' . $slug . '/assets/js/app.js?v=' . e($m['version'] ?? '1.0.0') . '"></script>' . "\n";
        }
    }
}
function modules_gateways(?PDO $db = null): array {
    $out = [];
    foreach (modules_all($db) as $slug => $m) {
        if (($m['enabled'] ?? '0') !== '1') continue;
        if (empty($m['gateway'])) continue;
        $out[$m['gateway']['code']] = [
            'module' => $slug,
            'code' => $m['gateway']['code'],
            'label' => module_text($slug, '_gateway_label', (string)($m['gateway']['label'] ?? $m['gateway']['code'])),
            'color' => $m['gateway']['color'],
            'icon' => $m['icon'] ?? 'fa-puzzle-piece',
            'iconPrefix' => $m['iconPrefix'] ?? 'fa-solid',
        ];
    }
    return $out;
}
function modules_gateway_find(string $code, ?PDO $db = null): ?array {
    $gw = modules_gateways($db);
    return $gw[$code] ?? null;
}
function modules_gateway_complete(PDO $db, string $orderId, string $paymentId): array {
    $orderId = mb_substr(trim($orderId), 0, 40);
    $paymentId = mb_substr(trim($paymentId), 0, 40);
    if ($orderId === '') return [false, 'Sipariş kimliği boş.'];
    try {
        $st = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
        $st->execute([$orderId]);
        $intent = $st->fetch();
    } catch (\Throwable $e) { return [false, 'Sipariş bulunamadı.']; }
    if (!$intent) return [false, 'Sipariş bulunamadı.'];
    if (($intent['status'] ?? '') === 'completed') return [true, 'Sipariş zaten tamamlanmış.'];
    if (($intent['status'] ?? '') !== 'pending') return [false, 'Sipariş durumu uygun değil.'];
    require_once ROOT_PATH . '/core/purchase.php';
    $savedCoupon = $_SESSION['applied_coupon'] ?? null;
    unset($_SESSION['applied_coupon']);
    $db->beginTransaction();
    try {
        $lock = $db->prepare("SELECT id, status FROM payment_intents WHERE id=? FOR UPDATE");
        $lock->execute([$intent['id']]);
        $locked = $lock->fetch();
        if (!$locked || ($locked['status'] ?? '') === 'completed') { $db->commit(); return [true, 'Sipariş zaten tamamlanmış.']; }
        $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
           ->execute([$paymentId, $intent['id']]);
        $uid = (int)$intent['user_id'];
        $totalPaid = (float)$intent['total_amount'];
        $methodLabel = (string)($intent['payment_method'] ?? 'module');
        if (strncmp($orderId, 'TOPUP-', 6) === 0) {
            $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$totalPaid, $uid]);
            $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,?,NOW())')->execute([$uid, $totalPaid, 'topup', $methodLabel . ' ile kredi yükleme']);
        } else {
            [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);
            if (empty($cartItems)) throw new RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);
            $done = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
            $totalPaid = $done['total_paid'];
            purchase_finish($db, $uid, $totalPaid, $methodLabel, 'payment', $snapCoupon, $done['product_ids'] ?? null);
        }
        $db->commit();
    } catch (\Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        if ($savedCoupon !== null) $_SESSION['applied_coupon'] = $savedCoupon;
        error_log('[Vexaris] gateway complete ' . $orderId . ': ' . $e->getMessage());
        return [false, 'Sipariş işlenirken hata oluştu.'];
    }
    if ($savedCoupon !== null) $_SESSION['applied_coupon'] = $savedCoupon;
    return [true, 'Sipariş tamamlandı.'];
}
function modules_boot(): void {
    $db = nexus_db();
    if (!$db) return;
    modules_sync($db);
    if (function_exists('add_action')) {
        add_action('mod_head', 'modules_print_head_assets');
        add_action('mod_footer', 'modules_print_footer_assets');
        add_action('admin_menu', 'modules_render_admin_menu');
    }
    modules_load_active($db);
}
function modules_render_admin_menu(): void {
    if (function_exists('has_permission') && !has_permission('modules')) return;
    $groups = [];
    foreach (modules_all() as $slug => $m) {
        if (($m['enabled'] ?? '0') !== '1') continue;
        if (($m['sidebar'] ?? '1') !== '1') continue;
        if (empty($m['admin_page']) || empty($m['admin_menu'])) continue;
        $sec = $m['admin_section'] ?? ['key' => 'modules', 'label' => 'Modüller', 'icon' => 'fa-puzzle-piece'];
        $sec['label'] = module_text($slug, '_section_label', (string)($sec['label'] ?? 'Modüller'));
        $groups[$sec['key']]['meta'] = $sec;
        $menuItem = $m['admin_menu'];
        $menuItem['label'] = module_text($slug, '_menu_label', (string)($menuItem['label'] ?? $slug));
        $groups[$sec['key']]['items'][$slug] = $menuItem;
    }
    if (empty($groups)) return;
    $active = isset($GLOBALS['activePage']) ? (string)$GLOBALS['activePage'] : '';
    foreach ($groups as $secKey => $g) {
        $subId = 'subMod_' . preg_replace('/[^a-z0-9_]/', '', $secKey);
        $open = (strncmp($active, 'module_', 7) === 0) ? 'open' : '';
        echo '<div class="admin-nav-item" onclick="toggleSub(\'' . $subId . '\',this)" id="nav' . e($subId) . '">';
        echo '<i class="fa-solid ' . e($g['meta']['icon']) . ' nav-icon"></i>';
        echo '<span>' . e($g['meta']['label']) . '</span>';
        echo '<i class="fa-solid fa-chevron-right nav-arrow"></i>';
        echo '</div>';
        echo '<div class="admin-nav-submenu ' . $open . '" id="' . $subId . '">';
        foreach ($g['items'] as $slug => $item) {
            $isActive = ($active === 'module_' . $slug) ? 'active' : '';
            echo '<a href="/admin/module.php?module=' . e($slug) . '" class="admin-nav-subitem ' . $isActive . '"';
            echo ' data-track-key="module-' . e($slug) . '" data-track-label="' . e($item['label']) . '" data-track-icon="' . e($item['icon']) . '">';
            echo '<i class="fa-solid ' . e($item['icon']) . '"></i> ' . e($item['label']);
            echo '</a>';
        }
        echo '</div>';
    }
}
