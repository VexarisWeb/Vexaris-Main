<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
function role_slug_valid(string $slug): bool {
    return (bool)preg_match('/^[a-z0-9_]{2,30}$/', $slug);
}
function roles_all(?PDO $db = null): array {
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = [];
    try {
        if ($db === null && function_exists('nexus_db')) $db = nexus_db();
        if (!$db) return $cache;
        $st = $db->query('SELECT `slug`,`name_tr`,`name_en`,`color`,`icon`,`rank`,`is_system` FROM `roles` ORDER BY `rank` DESC, `slug` ASC');
        foreach ($st->fetchAll() as $r) $cache[(string)$r['slug']] = $r;
    } catch (\Throwable $e) {}
    return $cache;
}
function role_get(?PDO $db, string $slug): ?array {
    $all = roles_all($db);
    return $all[$slug] ?? null;
}
function roles_rank_map(?PDO $db = null): array {
    $map = ['user' => 0, 'superadmin' => 200, 'admin' => 100];
    foreach (roles_all($db) as $slug => $r) $map[$slug] = (int)($r['rank'] ?? 0);
    $map['superadmin'] = 200;
    $map['admin'] = 100;
    return $map;
}
function role_color_safe($color): string {
    $c = trim((string)($color ?? ''));
    if (preg_match('/^#[0-9a-fA-F]{6}$/', $c)) return strtolower($c);
    return '#818cf8';
}
function role_display(?PDO $db, string $slug): array {
    $r = role_get($db, $slug);
    $lang = function_exists('lang_active') ? lang_active() : 'tr';
    if ($r === null) {
        return ['name' => $slug, 'color' => '#4ade80', 'icon' => 'fa-solid fa-user', 'rank' => 0, 'is_system' => 0];
    }
    $name = $lang === 'en' ? trim((string)($r['name_en'] ?? '')) : '';
    if ($name === '') $name = trim((string)($r['name_tr'] ?? ''));
    if ($name === '') $name = $slug;
    $icon = trim((string)($r['icon'] ?? ''));
    if ($icon === '') $icon = 'fa-solid fa-user';
    return ['name' => $name, 'color' => role_color_safe($r['color'] ?? ''), 'icon' => $icon, 'rank' => (int)($r['rank'] ?? 0), 'is_system' => (int)($r['is_system'] ?? 0)];
}
function role_badge(?PDO $db, string $slug): string {
    $d = role_display($db, $slug);
    $c = $d['color'];
    $icon = function_exists('cat_icon_html') ? cat_icon_html($d['icon'], 'width:12px;height:12px;object-fit:cover;border-radius:3px;') : '';
    if ($icon === '') $icon = '<i class="fa-solid fa-user"></i>';
    return '<span class="badge" style="background:' . $c . '1f;color:' . $c . ';border:1px solid ' . $c . '55;">' . $icon . ' ' . htmlspecialchars($d['name'], ENT_QUOTES, 'UTF-8') . '</span>';
}
function roles_user_count(PDO $db, string $slug): int {
    try {
        $st = $db->prepare('SELECT COUNT(*) FROM users WHERE role=?');
        $st->execute([$slug]);
        return (int)$st->fetchColumn();
    } catch (\Throwable $e) { return 0; }
}
function role_gateway_label(string $method): string {
    static $map = null;
    if ($map === null) {
        $map = ['shopier' => 'Shopier', 'paytr' => 'PayTR', 'iyzico' => 'iyzico', 'stripe' => 'Stripe', 'paypal' => 'PayPal', 'bitpay' => 'BitPay', 'crypt' => 'Kripto', 'paywant' => 'Paywant', 'whop' => 'Whop', 'paddle' => 'Paddle', 'lemonsqueezy' => 'Lemon Squeezy', 'dodopayments' => 'DodoPayments', 'balance' => 'Bakiye'];
    }
    $m = trim($method);
    if (isset($map[$m])) return $map[$m];
    if (strncmp($m, 'mod:', 4) === 0) return ucfirst(substr($m, 4));
    if ($m === '') return '?';
    return ucfirst($m);
}
