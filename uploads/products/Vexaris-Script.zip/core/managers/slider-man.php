<?php
defined('NEXUS_BOOT') or die('Direct access denied.');

function slider_fetch_all(?PDO $db = null): array {
    if ($db === null) {
        if (!function_exists('nexus_db')) return [];
        $db = nexus_db();
    }
    if (!$db) return [];
    try {
        $st = $db->query('SELECT * FROM sliders ORDER BY sort_order ASC, id DESC');
        return $st->fetchAll();
    } catch (Throwable $e) { return []; }
}

function slider_fetch_active(?PDO $db = null): array {
    if ($db === null) {
        if (!function_exists('nexus_db')) return [];
        $db = nexus_db();
    }
    if (!$db) return [];
    try {
        $st = $db->prepare('SELECT * FROM sliders WHERE is_active=1 ORDER BY sort_order ASC, id DESC');
        $st->execute();
        return $st->fetchAll();
    } catch (Throwable $e) { return []; }
}

function slider_render(?PDO $db = null): void {
    $rows = slider_fetch_active($db);
    if (empty($rows)) return;
    static $cssDone = false;
    if (!$cssDone) {
        $cssDone = true;
        echo '<style>@keyframes vxSliderKayma{from{transform:translateX(0);}to{transform:translateX(-100%);}}.site-slider-kayma{overflow:hidden;white-space:nowrap;display:block;}.site-slider-track{display:inline-block;white-space:nowrap;padding-left:100%;box-sizing:content-box;animation-name:vxSliderKayma;animation-timing-function:linear;animation-iteration-count:infinite;will-change:transform;}.site-slider-bar:hover .site-slider-track{animation-play-state:paused;}.vx-mgroup{display:inline-block;white-space:nowrap;}.vx-mgroup p,.vx-mgroup div{margin:0;padding:0;display:inline;}.vx-mgroup a{color:inherit;}</style>';
    }
    foreach ($rows as $r) {
        $bg = trim((string)($r['bg_color'] ?? '#6366f1'));
        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $bg)) $bg = '#6366f1';
        $content = (string)($r['content'] ?? '');
        if (trim(strip_tags($content)) === '' && trim($content) === '') continue;
        $link = trim((string)($r['link_url'] ?? ''));
        if ($link !== '' && !preg_match('~^(https?://|mailto:|/|#)~i', $link)) $link = '';
        $kayma = !empty($r['marquee']);
        $speed = (int)($r['speed'] ?? 20);
        if ($speed < 5) $speed = 5;
        if ($speed > 60) $speed = 60;
        $body = nx_clean_html($content, 'basic');
        if ($link !== '') $body = (string)preg_replace('#</?a(\s[^>]*)?>#i', '', $body);
        $tag = $link !== '' ? 'a' : 'div';
        $attr = $link !== '' ? ' href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '"' : '';
        $extra = $link !== '' ? 'text-decoration:none;cursor:pointer;' : '';
        echo '<' . $tag . $attr . ' class="site-slider-bar" style="display:block;background:' . htmlspecialchars($bg, ENT_QUOTES, 'UTF-8') . ';color:#fff;padding:8px 16px;text-align:center;font-size:13px;line-height:1.5;position:relative;z-index:9998;word-break:break-word;' . $extra . '">';
        if ($kayma) {
            echo '<div class="site-slider-kayma"><div class="site-slider-track" style="animation-duration:' . $speed . 's;"><div class="vx-mgroup">' . $body . '</div></div></div>';
        } else {
            echo '<div class="site-slider-inner" style="max-width:1200px;margin:0 auto;">' . $body . '</div>';
        }
        echo '</' . $tag . '>';
    }
}
