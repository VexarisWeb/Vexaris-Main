<?php
/**
 * core/managers/theme-man.php
 * Tema Motoru — aktif temayı settings tablosundan okur,
 * istenen şablonu themes/{aktif-tema}/{şablon}.php olarak yükler.
 */
defined('NEXUS_BOOT') or die('Direct access denied.');

/**
 * Aktif tema adını döner.
 * Önce DB'den okur, yoksa 'default' döner.
 */
function theme_active(): string {
    static $theme = null;
    if ($theme !== null) return $theme;

    $db = nexus_db();
    if ($db) {
        try {
            $row = $db->query("SELECT `value` FROM settings WHERE `key`='active_theme' LIMIT 1")->fetch();
            if ($row && !empty($row['value'])) {
                $slug = preg_replace('/[^a-z0-9_\-]/', '', $row['value']);
                if ($slug === 'azure' && function_exists('feature_active') && !feature_active('theme_azure')) {
                    $slug = 'default';
                }
                if ($slug === 'ember') {
                    $emberOk = function_exists('feature_active') ? feature_active('theme_ember') : false;
                    if (!$emberOk) {
                        $slug = 'default';
                    } else {
                        $emberPath = ROOT_PATH . '/themes/ember';
                        if (!is_dir($emberPath) || !is_file($emberPath . '/assets/css/style.css') || !is_file($emberPath . '/includes/header.php')) {
                            http_response_code(503);
                            header('Content-Type: text/html; charset=utf-8');
                            header('Retry-After: 600');
                            echo '<!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8"><title>Tema Hatası</title></head><body style="background:#0a0a0c;color:#f6f6f7;font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center"><div><h1 style="color:#ff6a18">503 — Tema Dosyaları Eksik</h1><p style="color:#9a9aa0">Ember teması silinmiş veya bozulmuş. Lütfen temayı yeniden yükleyin veya Site Ayarları\'ndan varsayılan temaya dönün.</p></div></body></html>';
                            exit;
                        }
                    }
                }
                $path = ROOT_PATH . '/themes/' . $slug;
                $theme = is_dir($path) ? $slug : 'default';
                return $theme;
            }
        } catch (Exception $e) { /* DB hazır değil */ }
    }

    $theme = 'default';
    return $theme;
}

/**
 * Aktif temanın header include'sini yükler (sayfada $pageTitle değişkenine göre başlık set edilir).
 * Tema dosyası yoksa default temaya döner.
 */
function theme_header(string $title = ''): void {
    global $pageTitle;
    if ($title !== '' && empty($pageTitle)) $pageTitle = $title;
    $active = theme_active();
    $file   = ROOT_PATH . "/themes/{$active}/includes/header.php";
    if (!file_exists($file)) $file = ROOT_PATH . '/themes/default/includes/header.php';
    include $file;
}

/**
 * Aktif temanın footer include'sini yükler.
 * Tema dosyası yoksa default temaya döner.
 */
function theme_footer(): void {
    $active = theme_active();
    $file   = ROOT_PATH . "/themes/{$active}/includes/footer.php";
    if (!file_exists($file)) $file = ROOT_PATH . '/themes/default/includes/footer.php';
    include $file;
}

/**
 * Aktif temanın belirtilen şablonunu yükler.
 *
 * Kullanım:
 *   theme_load('index');          → themes/{aktif}/index.php
 *   theme_load('login');          → themes/{aktif}/login.php
 *   theme_load('user/dashboard'); → themes/{aktif}/user/dashboard.php
 *
 * Şablon aktif temada yoksa 'default' temadan yükler.
 * O da yoksa 404 gönderir.
 */
function theme_load(string $template): void {
    $active  = theme_active();
    $primary = ROOT_PATH . "/themes/{$active}/{$template}.php";
    $fallback= ROOT_PATH . "/themes/default/{$template}.php";

    if (file_exists($primary)) {
        include $primary;
        return;
    }

    if ($active !== 'default' && file_exists($fallback)) {
        include $fallback;
        return;
    }

    // Şablon bulunamadı
    http_response_code(404);
    echo "<!DOCTYPE html><html><body style='font-family:sans-serif;background:#0b0f17;color:#e2e8f0;padding:60px;text-align:center;'>"
       . "<h2>404 — Sayfa Bulunamadı</h2>"
       . "<p style='color:#64748b;'>Tema: <code>{$active}</code> | Şablon: <code>{$template}.php</code></p>"
       . "<a href='/' style='color:#6366f1;'>Ana sayfaya dön</a></body></html>";
}

function theme_editor_schema(string $theme): array {
    $theme = preg_replace('/[^a-z0-9_\-]/', '', $theme);
    if ($theme === '') return [];
    $file = ROOT_PATH . '/themes/' . $theme . '/editor.php';
    if (!is_file($file)) return [];
    try { $schema = include $file; } catch (\Throwable $e) { return []; }
    if (!is_array($schema) || empty($schema['sections']) || !is_array($schema['sections'])) return [];
    $out = [];
    foreach ($schema['sections'] as $sec) {
        if (!is_array($sec)) continue;
        $skey = preg_replace('/[^a-z0-9_]/', '', (string)($sec['key'] ?? ''));
        $slabel = trim((string)($sec['label'] ?? ''));
        if (str_starts_with($slabel, '@')) $slabel = theme_lang(substr($slabel, 1), [], $theme);
        if ($skey === '' || $slabel === '' || empty($sec['fields']) || !is_array($sec['fields'])) continue;
        $fields = [];
        foreach ($sec['fields'] as $f) {
            if (!is_array($f)) continue;
            $key = trim((string)($f['key'] ?? ''));
            $label = trim((string)($f['label'] ?? ''));
            if (str_starts_with($label, '@')) $label = theme_lang(substr($label, 1), [], $theme);
            if (!preg_match('/^[a-z0-9_]{1,60}$/', $key) || $label === '') continue;
            $type = (string)($f['type'] ?? 'text');
            if (!in_array($type, ['text', 'textarea', 'html', 'color', 'image', 'select', 'number'], true)) continue;
            $field = ['key' => $key, 'label' => mb_substr($label, 0, 80), 'type' => $type];
            if (isset($f['placeholder'])) $field['placeholder'] = mb_substr((string)$f['placeholder'], 0, 200);
            if (array_key_exists('default', $f)) $field['default'] = mb_substr((string)$f['default'], 0, 2000);
            if (isset($f['var'])) {
                $v = trim((string)$f['var']);
                if (preg_match('/^--[a-z0-9\-]+$/', $v)) $field['var'] = $v;
            }
            if ($type === 'select') {
                $opts = $f['options'] ?? [];
                if (!is_array($opts) || count($opts) === 0) continue;
                $clean = [];
                foreach ($opts as $o) {
                    if (is_array($o)) { $vv = (string)($o['value'] ?? ''); $ll = (string)($o['label'] ?? $vv); }
                    else { $vv = (string)$o; $ll = (string)$o; }
                    if ($vv === '') continue;
                    $clean[] = ['value' => mb_substr($vv, 0, 100), 'label' => mb_substr($ll, 0, 100)];
                }
                if (count($clean) === 0) continue;
                $field['options'] = $clean;
            }
            $fields[] = $field;
        }
        if (count($fields) === 0) continue;
        $icon = preg_replace('/[^a-z0-9 \-]/i', '', (string)($sec['icon'] ?? 'fa-sliders'));
        if ($icon === '') $icon = 'fa-sliders';
        $out[] = ['key' => $skey, 'label' => mb_substr($slabel, 0, 60), 'icon' => mb_substr($icon, 0, 40), 'fields' => $fields];
    }
    return $out;
}

function theme_settings_map(string $theme): array {
    static $cache = [];
    $theme = preg_replace('/[^a-z0-9_\-]/', '', $theme);
    if ($theme === '') return [];
    if (isset($cache[$theme])) return $cache[$theme];
    $map = [];
    $db = function_exists('nexus_db') ? nexus_db() : null;
    if ($db) {
        try {
            $st = $db->prepare("SELECT `setting_key`,`setting_value` FROM theme_settings WHERE `theme`=?");
            $st->execute([$theme]);
            foreach ($st->fetchAll() as $r) $map[(string)$r['setting_key']] = (string)$r['setting_value'];
        } catch (\Throwable $e) {}
    }
    $cache[$theme] = $map;
    return $map;
}

function theme_setting(string $key, $default = '') {
    $theme = function_exists('theme_active') ? theme_active() : 'default';
    $map = theme_settings_map($theme);
    return array_key_exists($key, $map) ? $map[$key] : $default;
}

function theme_visible(string $key, $default = '') {
    $theme = function_exists('theme_active') ? theme_active() : 'default';
    $map = theme_settings_map($theme);
    if (array_key_exists($key, $map) && trim((string)$map[$key]) === '') return null;
    return array_key_exists($key, $map) ? $map[$key] : $default;
}

function theme_dict(string $theme, string $lang): array {
    static $c = [];
    $theme = preg_replace('/[^a-z0-9_\-]/', '', $theme);
    $k = $theme . '|' . $lang;
    if (isset($c[$k])) return $c[$k];
    $c[$k] = [];
    $f = ROOT_PATH . '/themes/' . $theme . '/lang/' . preg_replace('/[^a-z]/', '', $lang) . '.json';
    if ($theme !== '' && is_file($f)) {
        try {
            $d = json_decode(file_get_contents($f), true);
            if (is_array($d)) $c[$k] = $d;
        } catch (\Throwable $e) {}
    }
    return $c[$k];
}
function theme_lang(string $key, array $vars = [], ?string $theme = null): string {
    if ($theme === null) $theme = function_exists('theme_active') ? theme_active() : 'default';
    $l = function_exists('lang_active') ? lang_active() : 'tr';
    $d = theme_dict($theme, $l);
    $v = array_key_exists($key, $d) ? $d[$key] : null;
    if ($v === null && $l !== 'tr') {
        $d = theme_dict($theme, 'tr');
        $v = array_key_exists($key, $d) ? $d[$key] : null;
    }
    if ($v === null || !is_string($v)) return function_exists('__') ? __($key, $vars) : $key;
    foreach ($vars as $k => $val) $v = str_replace('{' . $k . '}', (string)$val, $v);
    return $v;
}
function theme_setting_validate(string $type, $raw, array $field = []) {
    $raw = is_string($raw) ? $raw : (string)$raw;
    if ($type === 'number') {
        $raw = trim($raw);
        return ($raw !== '' && is_numeric($raw)) ? mb_substr($raw, 0, 20) : null;
    }
    if ($type === 'color') {
        $raw = trim($raw);
        return preg_match('/^#[0-9a-fA-F]{6}$/', $raw) ? $raw : null;
    }
    if ($type === 'select') {
        $raw = trim($raw);
        foreach ($field['options'] ?? [] as $o) {
            if ((string)($o['value'] ?? '') === $raw) return mb_substr($raw, 0, 100);
        }
        return null;
    }
    if ($type === 'html') {
        $raw = trim($raw);
        if ($raw === '') return '';
        return mb_substr(strip_tags($raw, '<span><em><strong><br>'), 0, 2000);
    }
    if ($type === 'image') {
        $raw = trim($raw);
        if ($raw === '') return '';
        if (strncmp($raw, '/uploads/', 9) === 0 && strpos($raw, '..') === false && preg_match('/^\/uploads\/[a-zA-Z0-9_\-\/\.]{1,400}$/', $raw)) return mb_substr($raw, 0, 512);
        if (preg_match('/^https?:\/\/[^\s<>"\']{1,500}$/', $raw)) return mb_substr($raw, 0, 512);
        return null;
    }
    return mb_substr(trim($raw), 0, 2000);
}

function theme_setting_save(?PDO $db, string $theme, array $values): bool {
    if (!$db) return false;
    $theme = preg_replace('/[^a-z0-9_\-]/', '', $theme);
    if ($theme === '' || !is_dir(ROOT_PATH . '/themes/' . $theme)) return false;
    $schema = theme_editor_schema($theme);
    if (count($schema) === 0) return false;
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS `theme_settings` (`theme` VARCHAR(32) NOT NULL,`setting_key` VARCHAR(80) NOT NULL,`setting_value` MEDIUMTEXT,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`theme`,`setting_key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (\PDOException $e) {}
    $ok = true;
    try {
        $up = $db->prepare("REPLACE INTO theme_settings (`theme`,`setting_key`,`setting_value`) VALUES (?,?,?)");
        foreach ($schema as $sec) {
            foreach ($sec['fields'] as $f) {
                $k = $f['key'];
                if (!array_key_exists($k, $values)) continue;
                $v = theme_setting_validate($f['type'], $values[$k], $f);
                if ($v === null) continue;
                $up->execute([$theme, $k, $v]);
            }
        }
    } catch (\Throwable $e) { $ok = false; }
    return $ok;
}

function theme_settings_reset(?PDO $db, string $theme): bool {
    if (!$db) return false;
    $theme = preg_replace('/[^a-z0-9_\-]/', '', $theme);
    if ($theme === '') return false;
    try {
        $db->prepare("DELETE FROM theme_settings WHERE `theme`=?")->execute([$theme]);
        return true;
    } catch (\Throwable $e) { return false; }
}

function theme_image_upload(array $file, string $theme): string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return '';
    if ((int)($file['size'] ?? 0) > 2097152) return '';
    $name = (string)($file['name'] ?? '');
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'ico'], true)) return '';
    $tmp = (string)($file['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) return '';
    $fi = new finfo(FILEINFO_MIME_TYPE); $mime = $fi->file($tmp);
    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/x-icon', 'image/vnd.microsoft.icon'], true)) return '';
    if (@getimagesize($tmp) === false) return '';
    $dir = ROOT_PATH . '/uploads/theme/';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (!is_dir($dir)) return '';
    $htf = $dir . '.htaccess';
    if (!is_file($htf)) @file_put_contents($htf, "<IfModule mod_php.c>\n    php_flag engine off\n</IfModule>\n<FilesMatch \"\\.(?i:php[0-9]*|phtml|phps|phar|inc)$\">\n    <IfModule mod_authz_core.c>\n        Require all denied\n    </IfModule>\n    <IfModule !mod_authz_core.c>\n        Order allow,deny\n        Deny from all\n    </IfModule>\n</FilesMatch>\n");
    $theme = preg_replace('/[^a-z0-9_\-]/', '', $theme);
    $new = 'theme_' . ($theme !== '' ? $theme . '_' : '') . bin2hex(random_bytes(8)) . '.' . $ext;
    if (!@move_uploaded_file($tmp, $dir . $new)) return '';
    return '/uploads/theme/' . $new;
}

function theme_vars_css(?string $theme = null): void {
    $theme = $theme ?? (function_exists('theme_active') ? theme_active() : 'default');
    $schema = theme_editor_schema($theme);
    if (count($schema) === 0) return;
    $map = theme_settings_map($theme);
    if (count($map) === 0) return;
    $vars = [];
    foreach ($schema as $sec) {
        foreach ($sec['fields'] as $f) {
            if (($f['type'] ?? '') !== 'color' || empty($f['var'])) continue;
            $v = trim((string)($map[$f['key']] ?? ''));
            if (preg_match('/^#[0-9a-fA-F]{6}$/', $v)) $vars[$f['var']] = $v;
        }
    }
    if (count($vars) === 0) return;
    echo '<style id="vx-theme-vars">:root{';
    foreach ($vars as $k => $v) echo $k . ':' . $v . ';';
    echo '}</style>';
}

function vx_custom_css_render(): void {
    try {
        if (!function_exists('nexus_db')) return;
        $db = nexus_db();
        if (!$db) return;
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='custom_css' LIMIT 1");
        $st->execute();
        $css = trim((string)($st->fetchColumn() ?? ''));
        if ($css === '') return;
        $css = (string)preg_replace('#</style[^>]*>#i', '', $css);
        if (trim($css) === '') return;
        echo '<style id="vx-custom-css">' . $css . '</style>';
    } catch (Throwable $e) { return; }
}
if (function_exists('add_action')) add_action('mod_head', 'vx_custom_css_render');
function footer_links_data(?PDO $db = null): array {
    if ($db === null) {
        if (!function_exists('nexus_db')) return [];
        $db = nexus_db();
    }
    if (!$db) return [];
    try {
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='footer_links' LIMIT 1");
        $st->execute();
        $raw = trim((string)($st->fetchColumn() ?? ''));
        if ($raw === '') return [];
        $arr = json_decode($raw, true);
        if (!is_array($arr)) return [];
        $out = [];
        foreach (['platform','account','legal'] as $g) {
            $gd = (isset($arr[$g]) && is_array($arr[$g])) ? $arr[$g] : [];
            $links = [];
            if (isset($gd['links']) && is_array($gd['links'])) {
                foreach ($gd['links'] as $it) {
                    if (!is_array($it)) continue;
                    $lb = trim((string)($it['label'] ?? ''));
                    $url = trim((string)($it['url'] ?? ''));
                    if ($lb === '' || $url === '') continue;
                    if (!preg_match('~^(https?://|mailto:|/|#)~i', $url)) continue;
                    $links[] = ['label' => $lb, 'url' => $url, 'icon' => trim((string)($it['icon'] ?? ''))];
                }
            }
            $out[$g] = ['title' => trim((string)($gd['title'] ?? '')), 'links' => $links];
        }
        return $out;
    } catch (Throwable $e) { return []; }
}
