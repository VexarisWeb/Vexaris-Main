<?php
defined('NEXUS_BOOT') or die('Direct access denied.');

function product_versions_list(?PDO $db, int $productId): array {
    if ($db === null) {
        if (!function_exists('nexus_db')) return [];
        $db = nexus_db();
    }
    if (!$db || $productId < 1) return [];
    try {
        $st = $db->prepare('SELECT * FROM product_versions WHERE product_id=? ORDER BY id DESC');
        $st->execute([$productId]);
        return $st->fetchAll();
    } catch (Throwable $e) { return []; }
}

function product_update_unread(?PDO $db, int $userId): array {
    $out = ['total' => 0, 'by_product' => []];
    if ($db === null) {
        if (!function_exists('nexus_db')) return $out;
        $db = nexus_db();
    }
    if (!$db || $userId < 1) return $out;
    try {
        $sales = $db->prepare('SELECT product_id, MIN(purchased_at) AS first_buy FROM sales WHERE user_id=? GROUP BY product_id');
        $sales->execute([$userId]);
        $rows = $sales->fetchAll();
        if (!$rows) return $out;
        $seen = [];
        try {
            $rs = $db->prepare('SELECT product_id, last_seen_version_id FROM product_update_reads WHERE user_id=?');
            $rs->execute([$userId]);
            foreach ($rs->fetchAll() as $r) $seen[(int)$r['product_id']] = (int)$r['last_seen_version_id'];
        } catch (Throwable $e) {}
        $vs = $db->prepare('SELECT * FROM product_versions WHERE product_id=? AND has_file=1 AND id>? AND created_at>? ORDER BY id DESC');
        foreach ($rows as $s) {
            $pid = (int)$s['product_id'];
            $vs->execute([$pid, $seen[$pid] ?? 0, $s['first_buy']]);
            $un = $vs->fetchAll();
            if ($un) {
                $out['by_product'][$pid] = ['count' => count($un), 'latest' => $un[0], 'items' => $un];
                $out['total'] += count($un);
            }
        }
    } catch (Throwable $e) {}
    return $out;
}

function product_update_total(?PDO $db, int $userId): int {
    $u = product_update_unread($db, $userId);
    return (int)$u['total'];
}

function product_update_mark_seen(?PDO $db, int $userId): void {
    if ($db === null) {
        if (!function_exists('nexus_db')) return;
        $db = nexus_db();
    }
    if (!$db || $userId < 1) return;
    try {
        $sales = $db->prepare('SELECT DISTINCT product_id FROM sales WHERE user_id=?');
        $sales->execute([$userId]);
        $pids = $sales->fetchAll(PDO::FETCH_COLUMN);
        if (!$pids) return;
        $mx = $db->prepare('SELECT COALESCE(MAX(id),0) FROM product_versions WHERE product_id=?');
        $up = $db->prepare('INSERT INTO product_update_reads (user_id,product_id,last_seen_version_id) VALUES (?,?,?) ON DUPLICATE KEY UPDATE last_seen_version_id=GREATEST(last_seen_version_id,VALUES(last_seen_version_id))');
        foreach ($pids as $pid) {
            $mx->execute([(int)$pid]);
            $mid = (int)$mx->fetchColumn();
            if ($mid > 0) $up->execute([$userId, (int)$pid, $mid]);
        }
    } catch (Throwable $e) {}
}

function render_product_updates(array $versions, string $accent = '#6366f1'): void {
    if (empty($versions)) {
        echo '<div style="text-align:center;padding:28px 12px;color:var(--muted,#94a3b8);font-size:13px;"><i class="fa-solid fa-code-branch" style="font-size:26px;opacity:.4;display:block;margin-bottom:8px;"></i>Henüz sürüm notu paylaşılmadı.</div>';
        return;
    }
?>
<style>
.pu-row{display:flex;align-items:center;gap:12px;padding:12px 14px;border:1px solid rgba(255,255,255,.08);border-radius:12px;margin-bottom:8px;background:rgba(255,255,255,.03);}
.pu-ver{font-size:11px;font-weight:800;background:<?= e($accent) ?>22;color:<?= e($accent) ?>;border:1px solid <?= e($accent) ?>44;padding:3px 10px;border-radius:999px;white-space:nowrap;}
.pu-sum{flex:1;min-width:0;font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.pu-date{font-size:11px;color:#94a3b8;white-space:nowrap;}
.pu-dots{width:32px;height:32px;border-radius:9px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.05);color:#cbd5e1;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0;}
.pu-dots:hover{background:rgba(255,255,255,.12);}
.pu-modal{display:none;position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.75);backdrop-filter:blur(4px);align-items:center;justify-content:center;padding:16px;}
.pu-modal.open{display:flex;}
.pu-box{background:#141b2c;border:1px solid rgba(255,255,255,.1);border-radius:18px;width:min(720px,calc(100vw - 32px));max-height:88vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 24px 70px rgba(0,0,0,.6);}
.pu-head{display:flex;align-items:center;gap:10px;padding:16px 20px;border-bottom:1px solid rgba(255,255,255,.08);}
.pu-body{padding:20px;overflow-y:auto;font-size:14px;line-height:1.7;color:#e2e8f0;}
.pu-body img{max-width:100%;border-radius:8px;}
.pu-body a{color:<?= e($accent) ?>;}
.pu-x{margin-left:auto;width:32px;height:32px;border-radius:9px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.05);color:#94a3b8;cursor:pointer;font-size:15px;}
.pu-x:hover{background:#ef4444;border-color:#ef4444;color:#fff;}
@media(max-width:560px){.pu-sum{white-space:normal;} .pu-date{display:none;}}
</style>
<div>
<?php foreach ($versions as $i => $v): ?>
<div class="pu-row">
<span class="pu-ver">v<?= e($v['version'] !== '' ? $v['version'] : '?') ?></span>
<span class="pu-sum"><?= e($v['summary'] !== '' ? $v['summary'] : 'Sürüm güncellemesi') ?></span>
<span class="pu-date"><?= date('d.m.Y', strtotime($v['created_at'])) ?></span>
<button type="button" class="pu-dots" onclick="puOpen(<?= $i ?>)" title="Detay"><i class="fa-solid fa-ellipsis-vertical"></i></button>
</div>
<?php endforeach; ?>
</div>
<div class="pu-modal" id="puModal" onclick="if(event.target===this)puClose()">
<div class="pu-box">
<div class="pu-head">
<span class="pu-ver" id="puVer">v?</span>
<span style="font-size:13px;font-weight:700;" id="puSum"></span>
<button type="button" class="pu-x" onclick="puClose()"><i class="fa-solid fa-xmark"></i></button>
</div>
<div style="padding:4px 20px 0;font-size:11px;color:#94a3b8;" id="puDate"></div>
<div class="pu-body" id="puBody"></div>
</div>
</div>
<script>
var _puData = <?= json_encode(array_map(fn($v)=>['version'=>$v['version'],'summary'=>$v['summary'],'changelog'=>$v['changelog'],'created_at'=>date('d.m.Y H:i',strtotime($v['created_at']))], $versions), JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
function puOpen(i){ var d=_puData[i]; if(!d) return; document.getElementById('puVer').textContent='v'+(d.version||'?'); document.getElementById('puSum').textContent=d.summary||'Sürüm güncellemesi'; document.getElementById('puDate').textContent=d.created_at; document.getElementById('puBody').innerHTML=d.changelog||'<p style="color:#94a3b8;">Detaylı açıklama eklenmemiş.</p>'; document.getElementById('puModal').classList.add('open'); document.body.style.overflow='hidden'; }
function puClose(){ document.getElementById('puModal').classList.remove('open'); document.body.style.overflow=''; }
document.addEventListener('keydown',function(e){ if(e.key==='Escape') puClose(); });
</script>
<?php
}
