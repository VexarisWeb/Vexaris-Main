<?php
function _chat_lock_enabled(string $provider): string {
    $db = nexus_db();
    if (!$db) return '';
    try {
        $st = $db->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('int_tawkto_enabled','int_jivochat_enabled','int_crisp_enabled')");
        $st->execute();
        $vals = [];
        foreach ($st->fetchAll() as $r) $vals[$r['key']] = $r['value'];
        $order = ['tawkto' => 0, 'jivochat' => 1, 'crisp' => 2];
        $target = $order[$provider] ?? -1;
        if ($target < 0 || ($vals['int_'.$provider.'_enabled'] ?? '0') !== '1') return '';
        foreach ($order as $name => $rank) {
            if ($rank >= $target) break;
            if (($vals['int_'.$name.'_enabled'] ?? '0') === '1') return '';
        }
        return $provider;
    } catch (\Exception $e) {
        error_log('[NS] _chat_lock_enabled: ' . $e->getMessage());
        return '';
    }
}

function tawkto_widget_code(): string {
    if (_chat_lock_enabled('tawkto') !== 'tawkto') return '';
    $db = nexus_db();
    if (!$db) return '';
    try {
        $st = $db->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('int_tawkto_enabled','int_tawkto_widget_code')");
        $st->execute();
        $vals = [];
        foreach ($st->fetchAll() as $r) $vals[$r['key']] = $r['value'];
        if (($vals['int_tawkto_enabled'] ?? '0') !== '1') return '';
        return trim((string)($vals['int_tawkto_widget_code'] ?? ''));
    } catch (\Exception $e) {
        error_log('[NS] tawkto_widget_code: ' . $e->getMessage());
        return '';
    }
}

function jivochat_widget_code(): string {
    if (_chat_lock_enabled('jivochat') !== 'jivochat') return '';
    $db = nexus_db();
    if (!$db) return '';
    try {
        $st = $db->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('int_jivochat_enabled','int_jivochat_widget_code')");
        $st->execute();
        $vals = [];
        foreach ($st->fetchAll() as $r) $vals[$r['key']] = $r['value'];
        if (($vals['int_jivochat_enabled'] ?? '0') !== '1') return '';
        return trim((string)($vals['int_jivochat_widget_code'] ?? ''));
    } catch (\Exception $e) {
        error_log('[NS] jivochat_widget_code: ' . $e->getMessage());
        return '';
    }
}

function crisp_widget_code(): string {
    if (_chat_lock_enabled('crisp') !== 'crisp') return '';
    $db = nexus_db();
    if (!$db) return '';
    try {
        $st = $db->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('int_crisp_enabled','int_crisp_widget_code')");
        $st->execute();
        $vals = [];
        foreach ($st->fetchAll() as $r) $vals[$r['key']] = $r['value'];
        if (($vals['int_crisp_enabled'] ?? '0') !== '1') return '';
        return trim((string)($vals['int_crisp_widget_code'] ?? ''));
    } catch (\Exception $e) {
        error_log('[NS] crisp_widget_code: ' . $e->getMessage());
        return '';
    }
}

function analytics_widget_code(): string {    $db = nexus_db();
    if (!$db) return '';
    try {
        $st = $db->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('int_analytics_enabled','int_analytics_analytics_code')");
        $st->execute();
        $vals = [];
        foreach ($st->fetchAll() as $r) $vals[$r['key']] = $r['value'];
        if (($vals['int_analytics_enabled'] ?? '0') !== '1') return '';
        return trim((string)($vals['int_analytics_analytics_code'] ?? ''));
    } catch (\Exception $e) {
        error_log('[NS] analytics_widget_code: ' . $e->getMessage());
        return '';
    }
}
