<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
function markdown_inline(string $t): string {
    $t = htmlspecialchars($t, ENT_QUOTES, 'UTF-8');
    $t = preg_replace_callback('/!\[([^\]]*)\]\(([^)\s]+)\)/', function ($m) {
        $u = trim($m[2]);
        if (!preg_match('~^(https?://|/)~i', $u)) return $m[1];
        return '<img src="' . $u . '" alt="' . $m[1] . '" loading="lazy" style="max-width:100%;border-radius:10px;">';
    }, $t);
    $t = preg_replace_callback('/\[([^\]]+)\]\(([^)\s]+)\)/', function ($m) {
        $u = trim($m[2]);
        if (!preg_match('~^(https?://|mailto:|/|#)~i', $u)) $u = '#';
        return '<a href="' . $u . '">' . $m[1] . '</a>';
    }, $t);
    $t = preg_replace('/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $t);
    $t = preg_replace('/(^|[\s(>])_(.+?)_([\s).,;:!?]|$)/s', '$1<em>$2</em>$3', $t);
    return $t;
}
function markdown_render(string $md): string {
    $md = str_replace(["\r\n", "\r"], "\n", trim($md));
    if ($md === '') return '';
    $lines = explode("\n", $md);
    $html = '';
    $para = [];
    $list = [];
    $listType = '';
    $flushPara = function () use (&$html, &$para) {
        if (count($para) === 0) return;
        $html .= '<p>' . implode(' ', array_map('markdown_inline', $para)) . '</p>';
        $para = [];
    };
    $flushList = function () use (&$html, &$list, &$listType) {
        if (count($list) === 0) return;
        $tag = $listType === 'ol' ? 'ol' : 'ul';
        $html .= '<' . $tag . '>';
        foreach ($list as $li) $html .= '<li>' . markdown_inline($li) . '</li>';
        $html .= '</' . $tag . '>';
        $list = [];
        $listType = '';
    };
    foreach ($lines as $line) {
        $t = trim($line);
        if ($t === '') { $flushPara(); $flushList(); continue; }
        if (preg_match('/^(#{1,3})\s+(.+)$/', $t, $m)) {
            $flushPara(); $flushList();
            $lvl = strlen($m[1]);
            $tag = $lvl === 1 ? 'h2' : ($lvl === 2 ? 'h3' : 'h4');
            $html .= '<' . $tag . '>' . markdown_inline($m[2]) . '</' . $tag . '>';
            continue;
        }
        if (preg_match('/^>\s?(.*)$/', $t, $m)) {
            $flushPara(); $flushList();
            $html .= '<blockquote>' . markdown_inline($m[1]) . '</blockquote>';
            continue;
        }
        if (preg_match('/^\d+\.\s+(.+)$/', $t, $m)) {
            $flushPara();
            if ($listType !== 'ol') { $flushList(); $listType = 'ol'; }
            $list[] = $m[1];
            continue;
        }
        if (preg_match('/^[-*]\s+(.+)$/', $t, $m)) {
            $flushPara();
            if ($listType !== 'ul') { $flushList(); $listType = 'ul'; }
            $list[] = $m[1];
            continue;
        }
        $flushList();
        $para[] = $t;
    }
    $flushPara(); $flushList();
    return $html;
}
function legal_body_html(string $content, string $siteName = ''): string {
    $raw = ($siteName !== '') ? str_replace('{site_name}', $siteName, $content) : $content;
    if (strip_tags($raw) !== $raw) {
        if (function_exists('nx_clean_html')) return nx_clean_html($raw, 'rich');
        return htmlspecialchars($raw, ENT_QUOTES, 'UTF-8');
    }
    if (function_exists('markdown_render')) return markdown_render($raw);
    return htmlspecialchars($raw, ENT_QUOTES, 'UTF-8');
}
