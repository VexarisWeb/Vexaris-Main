<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

function paddle_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_paddle_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[paddle] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function paddle_test_mode(\PDO $db): bool {
    $cfg = paddle_settings($db);
    return ($cfg['payment_paddle_test_mode'] ?? '0') === '1';
}

function paddle_api_base(\PDO $db): string {
    return paddle_test_mode($db) ? 'https://sandbox-api.paddle.com' : 'https://api.paddle.com';
}

function paddle_api_key(\PDO $db): string {
    $cfg = paddle_settings($db);
    return trim((string)($cfg['payment_paddle_api_key'] ?? ''));
}

function paddle_webhook_secret(\PDO $db): string {
    $cfg = paddle_settings($db);
    return trim((string)($cfg['payment_paddle_webhook_secret'] ?? ''));
}

function paddle_currency(\PDO $db): string {
    $cfg = paddle_settings($db);
    $c = strtoupper(trim((string)($cfg['payment_paddle_currency'] ?? 'TRY')));
    return in_array($c, ['TRY', 'USD', 'EUR'], true) ? $c : 'TRY';
}

function paddle_is_ready(\PDO $db): bool {
    $s = paddle_settings($db);
    return !empty($s['payment_paddle_api_key']) && !empty($s['payment_paddle_webhook_secret']) && ($s['payment_paddle_active'] ?? '0') === '1';
}

function paddle_api_version(): string {
    return '1';
}

function paddle_request(\PDO $db, string $method, string $path, $body = null): array {
    $key = paddle_api_key($db);
    if ($key === '') throw new \RuntimeException('Paddle API anahtarı yapılandırılmamış.');
    $headers = ['Authorization: Bearer ' . $key, 'Accept: application/json', 'Paddle-Version: ' . paddle_api_version()];
    $payload = null;
    if ($body !== null) {
        $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($payload === false) throw new \RuntimeException('Paddle isteği hazırlanamadı.');
        $headers[] = 'Content-Type: application/json';
    }
    $ch = curl_init(paddle_api_base($db) . $path);
    $opts = [CURLOPT_CUSTOMREQUEST => strtoupper($method), CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_HTTPHEADER => $headers];
    if ($payload !== null) $opts[CURLOPT_POSTFIELDS] = $payload;
    curl_setopt_array($ch, $opts);
    $resp = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) throw new \RuntimeException('Paddle bağlantı hatası: ' . $err);
    $data = json_decode((string)$resp, true);
    if ($code < 200 || $code >= 300) {
        $msg = is_array($data) ? (string)(($data['error']['detail'] ?? '') !== '' ? $data['error']['detail'] : json_encode($data, JSON_UNESCAPED_UNICODE)) : substr((string)$resp, 0, 200);
        throw new \RuntimeException('Paddle API hatası (HTTP ' . $code . '): ' . mb_substr($msg, 0, 200));
    }
    if (!is_array($data) || !isset($data['data'])) throw new \RuntimeException('Paddle yanıtı çözümlenemedi (HTTP ' . $code . ').');
    return $data['data'];
}

function paddle_minor(float $total, string $cur): string {
    $minor = (int)round($total * 100);
    if ($minor <= 0) throw new \RuntimeException('Paddle ile en az 1,00 tutarında ödeme alınabilir.');
    return (string)$minor;
}

function paddle_min_check(float $total, string $cur): void {
    $mins = ['TRY' => 27.0, 'USD' => 1.0, 'EUR' => 1.0];
    $floor = $mins[$cur] ?? 27.0;
    if ($total < $floor) throw new \RuntimeException('Paddle minimum tutarın altında: ' . $cur . ' ' . $floor);
}

function paddle_create_checkout(\PDO $db, float $total, string $orderId, string $title): array {
    if (!paddle_is_ready($db)) throw new \RuntimeException('Paddle aktif değil.');
    if ($orderId === '') throw new \RuntimeException('Sipariş numarası boş olamaz.');
    $total = round($total, 2);
    $cur = paddle_currency($db);
    paddle_min_check($total, $cur);
    $body = [
        'items' => [[
            'quantity' => 1,
            'price' => [
                'description' => mb_substr($title, 0, 200),
                'name' => mb_substr($title, 0, 100),
                'unit_price' => ['amount' => paddle_minor($total, $cur), 'currency_code' => $cur],
                'product' => ['name' => mb_substr($title, 0, 100), 'tax_category' => 'standard'],
            ],
        ]],
        'currency_code' => $cur,
        'custom_data' => ['order_id' => mb_substr($orderId, 0, 100)],
    ];
    $txn = paddle_request($db, 'POST', '/transactions', $body);
    $txnId = (string)($txn['id'] ?? '');
    $url = (string)($txn['checkout']['url'] ?? '');
    if ($txnId === '' || $url === '') throw new \RuntimeException('Paddle ödeme bağlantısı oluşturulamadı.');
    return ['checkout_url' => $url, 'txn_id' => $txnId];
}

function paddle_verify_webhook(\PDO $db, string $raw, array $headers) {
    $secret = paddle_webhook_secret($db);
    if ($secret === '' || $raw === '') return false;
    $h = [];
    foreach ($headers as $k => $v) $h[strtolower((string)$k)] = $v;
    $sigHeader = (string)($h['paddle-signature'] ?? '');
    if ($sigHeader === '') return false;
    $ts = '';
    $sigs = [];
    foreach (explode(';', $sigHeader) as $part) {
        $kv = explode('=', trim($part), 2);
        if (count($kv) !== 2) continue;
        if ($kv[0] === 'ts') $ts = $kv[1];
        elseif ($kv[0] === 'h1') $sigs[] = $kv[1];
    }
    if ($ts === '' || !$sigs) return false;
    if (abs(time() - (int)$ts) > 300) return false;
    $calc = hash_hmac('sha256', $ts . ':' . $raw, $secret);
    $ok = false;
    foreach ($sigs as $s) {
        if ($s !== '' && hash_equals($calc, $s)) { $ok = true; break; }
    }
    if (!$ok) return false;
    $event = json_decode($raw, true);
    if (!is_array($event) || !isset($event['event_id'], $event['event_type'], $event['data'])) return false;
    return $event;
}

function paddle_complete_intent(\PDO $db, array $intent, string $transactionId = ''): void {
    if ($transactionId !== '') {
        $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
           ->execute([substr($transactionId, 0, 40), $intent['id']]);
    } else {
        $db->prepare("UPDATE payment_intents SET status='completed' WHERE id=?")->execute([$intent['id']]);
    }

    $uid       = (int)$intent['user_id'];
    $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);
    $orderId   = (string)$intent['order_id'];
    $cur       = strtoupper((string)($intent['currency'] ?? 'TRY'));

    if (strncmp($orderId, 'TOPUP-', 6) === 0) {
        $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
        $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'Paddle']) . '",NOW())')->execute([$uid, $creditAmt, 'topup']);
        $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
        $uStmt->execute([$uid]);
        $uInfo = $uStmt->fetch();
        discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body'), [
            __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
            __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
            __('bsupp.f_method')    => 'Paddle',
        ], 16766720);
        return;
    }

    require_once ROOT_PATH . '/core/purchase.php';
    [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);
    if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);

    $done = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
    purchase_finish($db, $uid, $done['total_paid'], 'Paddle', 'payment', $snapCoupon, $done['product_ids'] ?? null);

    $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
    $uStmt->execute([$uid]);
    $uInfo = $uStmt->fetch();
    discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body'), [
        __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
        __('bsupp.f_products')   => implode(', ', $done['product_names']),
        __('bsupp.f_amount')     => number_format($done['total_paid'], 2, ',', '.') . ' ' . $cur,
        __('bsupp.f_method')    => 'Paddle',
    ], 5763719);
}

function paddle_test_connection(\PDO $db): void {
    if (!paddle_is_ready($db)) throw new \RuntimeException('API anahtarı yapılandırılmamış.');
    paddle_request($db, 'GET', '/transactions?per_page=1');
}
