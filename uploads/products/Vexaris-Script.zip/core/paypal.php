<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

function paypal_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_paypal_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[paypal] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function paypal_is_ready(\PDO $db): bool {
    $cfg = paypal_settings($db);
    return ($cfg['payment_paypal_active'] ?? '0') === '1'
        && !empty($cfg['payment_paypal_client_id'] ?? '')
        && !empty($cfg['payment_paypal_secret'] ?? '');
}

function paypal_is_test_mode(\PDO $db): bool {
    $cfg = paypal_settings($db);
    return ((string)($cfg['payment_paypal_test_mode'] ?? '0')) === '1';
}

function paypal_base_url(): string {
    if (function_exists('site_base_url')) {
        try {
            $b = site_base_url(function_exists('nexus_db') ? nexus_db() : null);
            if ($b !== '') return rtrim($b, '/');
        } catch (\Throwable $e) {}
    }
    $scheme = function_exists('request_is_https') ? (request_is_https() ? 'https://' : 'http://') : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://');
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    if (!preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) $host = 'localhost';
    return rtrim($scheme . $host, '/');
}

function paypal_api_base(\PDO $db): string {
    return paypal_is_test_mode($db) ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';
}

function paypal_currency(\PDO $db): string {
    $cfg = paypal_settings($db);
    $siteCurrency = trim((string)($cfg['payment_paypal_currency'] ?? 'USD'));
    $map = ['USD' => 'USD', 'EUR' => 'EUR', 'GBP' => 'GBP', 'TRY' => 'TRY'];
    return $map[$siteCurrency] ?? 'USD';
}

function paypal_access_token(\PDO $db): string {
    $cfg = paypal_settings($db);
    $id  = trim((string)($cfg['payment_paypal_client_id'] ?? ''));
    $sec = trim((string)($cfg['payment_paypal_secret'] ?? ''));
    if ($id === '' || $sec === '') {
        throw new \RuntimeException('PayPal Client ID ve Secret eksik.');
    }
    $ch = curl_init(paypal_api_base($db) . '/v1/oauth2/token');
    curl_setopt_array($ch, [
        CURLOPT_POST            => true,
        CURLOPT_RETURNTRANSFER  => true,
        CURLOPT_TIMEOUT         => 20,
        CURLOPT_HTTPHEADER      => ['Accept: application/json', 'Content-Type: application/x-www-form-urlencoded', 'Authorization: Basic ' . base64_encode($id . ':' . $sec)],
        CURLOPT_POSTFIELDS      => 'grant_type=client_credentials',
        CURLOPT_SSL_VERIFYPEER  => true,
    ]);
    $body = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err || $code >= 400) {
        throw new \RuntimeException('PayPal token alınamadı (HTTP ' . $code . '): ' . substr((string)$body, 0, 300));
    }
    $json = json_decode((string)$body, true);
    if (empty($json['access_token'] ?? '')) {
        throw new \RuntimeException('PayPal token yanıtında access_token bulunamadı.');
    }
    return (string)$json['access_token'];
}

function paypal_request_id(): string {
    try {
        return bin2hex(random_bytes(16));
    } catch (\Throwable $e) {
        return uniqid('pp', true);
    }
}

function paypal_http(\PDO $db, string $method, string $path, $body, string $token = '', array $extraHeaders = []): array {
    $headers = ['Content-Type: application/json', 'Accept: application/json', 'Prefer: return=representation'];
    if ($token !== '') $headers[] = 'Authorization: Bearer ' . $token;
    foreach ($extraHeaders as $h) $headers[] = $h;
    $opts = [
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_SSL_VERIFYPEER => true,
    ];
    if ($body !== null) {
        $opts[CURLOPT_POSTFIELDS] = is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE);
    }
    $ch = curl_init(paypal_api_base($db) . $path);
    curl_setopt_array($ch, $opts);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) {
        throw new \RuntimeException('PayPal istek hatası: ' . $err);
    }
    $json = json_decode((string)$resp, true);
    if (!is_array($json)) {
        throw new \RuntimeException('PayPal yanıtı çözümlenemedi.');
    }
    return ['code' => $code, 'json' => $json];
}

function paypal_create_order(\PDO $db, string $orderId, string $brand, float $total): array {
    $token = paypal_access_token($db);
    $body = [
        'intent' => 'CAPTURE',
        'purchase_units' => [[
            'reference_id' => $orderId,
            'custom_id' => mb_substr($orderId, 0, 127),
            'amount' => [
                'currency_code' => paypal_currency($db),
                'value'         => number_format($total, 2, '.', ''),
            ],
        ]],
        'payment_source' => [
            'paypal' => [
                'experience_context' => [
                    'brand_name'          => mb_substr(trim($brand), 0, 127),
                    'return_url'          => paypal_base_url() . '/callback/paypal.php?order_id=' . urlencode($orderId),
                    'cancel_url'          => paypal_base_url() . '/payment/cancel?order_id=' . urlencode($orderId),
                    'user_action'         => 'PAY_NOW',
                    'shipping_preference' => 'GET_FROM_FILE',
                ],
            ],
        ],
    ];
    $res = paypal_http($db, 'POST', '/v2/checkout/orders', $body, $token, ['PayPal-Request-Id: ' . paypal_request_id()]);
    if (($res['code'] ?? 0) >= 400) {
        throw new \RuntimeException('PayPal sipariş oluşturulamadı (HTTP ' . $res['code'] . '): ' . json_encode($res['json'] ?? [], JSON_UNESCAPED_UNICODE));
    }
    $approve = '';
    foreach (($res['json']['links'] ?? []) as $link) {
        if (in_array($link['rel'] ?? '', ['approve', 'payer-action'], true)) { $approve = (string)($link['href'] ?? ''); break; }
    }
    if ($approve === '') {
        throw new \RuntimeException('PayPal onay (approve) URL bulunamadı.');
    }
    return ['id' => (string)($res['json']['id'] ?? ''), 'approve' => $approve];
}

function paypal_capture_order(\PDO $db, string $ppOrderId): array {
    $token = paypal_access_token($db);
    $res = paypal_http($db, 'POST', '/v2/checkout/orders/' . rawurlencode($ppOrderId) . '/capture', new \stdClass(), $token, ['PayPal-Request-Id: ' . paypal_request_id()]);
    if (($res['code'] ?? 0) >= 400) {
        throw new \RuntimeException('PayPal tahsilat başarısız (HTTP ' . $res['code'] . '): ' . json_encode($res['json'] ?? [], JSON_UNESCAPED_UNICODE));
    }
    $captureId = '';
    $paid      = 0.0;
    $paidCur   = '';
    $refId     = '';
    $customId  = '';
    $pu = ($res['json']['purchase_units'][0] ?? []);
    $refId = (string)($pu['reference_id'] ?? '');
    $customId = (string)($pu['custom_id'] ?? '');
    foreach (($pu['payments']['captures'] ?? []) as $cap) {
        if (($cap['status'] ?? '') === 'COMPLETED') {
            $captureId = (string)($cap['id'] ?? '');
            $paid      = (float)($cap['amount']['value'] ?? 0);
            $paidCur   = strtoupper((string)($cap['amount']['currency_code'] ?? ''));
            break;
        }
    }
    return ['status' => (string)($res['json']['status'] ?? ''), 'capture_id' => $captureId, 'paid' => $paid, 'currency' => $paidCur, 'reference_id' => $refId, 'custom_id' => $customId, 'order_id' => (string)($res['json']['id'] ?? '')];
}

function paypal_test_connection(\PDO $db): void {
    paypal_access_token($db);
}

function paypal_webhook_id(\PDO $db): string {
    $cfg = paypal_settings($db);
    return trim((string)($cfg['payment_paypal_webhook_id'] ?? ''));
}

function paypal_server_headers(): array {
    if (function_exists('getallheaders')) {
        $h = getallheaders();
        if (is_array($h) && $h) return $h;
    }
    $h = [];
    foreach ($_SERVER as $k => $v) {
        if (strncmp($k, 'HTTP_', 5) === 0) $h[str_replace('_', '-', substr($k, 5))] = $v;
    }
    return $h;
}

function paypal_verify_webhook(\PDO $db, string $raw, array $headers) {
    $webhookId = paypal_webhook_id($db);
    if ($webhookId === '' || $raw === '') return false;
    $h = [];
    foreach ($headers as $k => $v) $h[strtoupper(str_replace('_', '-', (string)$k))] = $v;
    $body = [
        'transmission_id'   => (string)($h['PAYPAL-TRANSMISSION-ID'] ?? ''),
        'transmission_time' => (string)($h['PAYPAL-TRANSMISSION-TIME'] ?? ''),
        'cert_url'          => (string)($h['PAYPAL-CERT-URL'] ?? ''),
        'auth_algo'         => (string)($h['PAYPAL-AUTH-ALGO'] ?? ''),
        'transmission_sig'  => (string)($h['PAYPAL-TRANSMISSION-SIG'] ?? ''),
        'webhook_id'        => $webhookId,
        'webhook_event'     => json_decode($raw, true),
    ];
    if ($body['transmission_id'] === '' || $body['transmission_sig'] === '' || !is_array($body['webhook_event'])) return false;
    try {
        $token = paypal_access_token($db);
        $res = paypal_http($db, 'POST', '/v1/notifications/verify-webhook-signature', $body, $token);
        if ((string)($res['json']['verification_status'] ?? '') !== 'SUCCESS') return false;
    } catch (\Throwable $e) {
        error_log('[paypal] webhook verify: ' . $e->getMessage());
        return false;
    }
    return $body['webhook_event'];
}
