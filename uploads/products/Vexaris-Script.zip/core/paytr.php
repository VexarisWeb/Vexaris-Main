<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

function paytr_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_paytr_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[PayTR] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function paytr_is_ready(\PDO $db): bool {
    $cfg = paytr_settings($db);
    return ($cfg['payment_paytr_active'] ?? '0') === '1'
        && !empty($cfg['payment_paytr_merchant_id'] ?? '')
        && !empty($cfg['payment_paytr_merchant_key'] ?? '')
        && !empty($cfg['payment_paytr_merchant_salt'] ?? '');
}

function paytr_hash(string $merchantKey, string $merchantSalt, string $data): string {
    return base64_encode(hash_hmac('sha256', $data . $merchantSalt, $merchantKey, true));
}

function paytr_callback_hash(string $merchantKey, string $merchantSalt, string $merchantOid, string $status, string $totalAmount): string {
    return base64_encode(hash_hmac('sha256', $merchantOid . $merchantSalt . $status . $totalAmount, $merchantKey, true));
}

function paytr_http_post(string $url, array $data): string {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $data,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_FRESH_CONNECT  => true,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $body = curl_exec($ch);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($body === false || $body === '') {
        throw new \RuntimeException('PayTR bağlantı hatası: ' . $err);
    }
    return (string)$body;
}

function paytr_base_url(): string {
    if (function_exists('site_base_url')) {
        try {
            $b = site_base_url(function_exists('nexus_db') ? nexus_db() : null);
            if ($b !== '') return rtrim($b, '/');
        } catch (\Throwable $e) {}
    }
    $scheme = function_exists('request_is_https') ? (request_is_https() ? 'https://' : 'http://') : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://');
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    if (!preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) $host = 'localhost';
    return rtrim($scheme . $host, '/');
}

function paytr_sanitize_email(string $email): string {
    $email = mb_substr(preg_replace('/[^\x20-\x7E]/', '', $email) ?? '', 0, 100);
    return $email;
}

function paytr_sanitize_ip(string $ip): string {
    $ip = trim($ip);
    if (strlen($ip) > 39) $ip = substr($ip, 0, 39);
    return $ip;
}

function paytr_sanitize_phone(string $phone): string {
    return mb_substr(preg_replace('/[^\d\s+\-()]/', '', $phone) ?? '', 0, 20);
}

function paytr_normalize_currency(string $currency): string {
    $c = strtoupper(trim($currency));
    if (!in_array($c, ['TRY', 'TL', 'EUR', 'USD', 'GBP', 'RUB'], true)) $c = 'TRY';
    return $c === 'TRY' ? 'TL' : $c;
}

function paytr_create_payment(\PDO $db, string $orderId, string $email, string $userName, string $userPhone, float $totalTL, array $basket): string {
    $cfg = paytr_settings($db);
    $merchantId   = trim((string)($cfg['payment_paytr_merchant_id'] ?? ''));
    $merchantKey  = trim((string)($cfg['payment_paytr_merchant_key'] ?? ''));
    $merchantSalt = trim((string)($cfg['payment_paytr_merchant_salt'] ?? ''));
    if ($merchantId === '' || $merchantKey === '' || $merchantSalt === '') {
        throw new \RuntimeException('PayTR yapılandırması eksik.');
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    }
    $ip = paytr_sanitize_ip($ip);

    $email = paytr_sanitize_email($email);
    if ($email === '') throw new \RuntimeException('Geçerli bir e-posta adresi gerekli.');

    $userName = mb_substr(trim($userName), 0, 60);
    $userPhone = paytr_sanitize_phone($userPhone);

    $currency = paytr_normalize_currency((string)($cfg['payment_paytr_currency'] ?? 'TRY'));
    $testMode     = ((string)($cfg['payment_paytr_test_mode'] ?? '0')) === '1' ? 1 : 0;

    $paymentAmount  = (int)round($totalTL * 100);
    $userBasket     = base64_encode(json_encode(array_values($basket), JSON_UNESCAPED_UNICODE));
    $noInstallment  = 0;
    $maxInstallment = 0;

    $hashStr    = $merchantId . $ip . $orderId . $email . $paymentAmount . $userBasket . $noInstallment . $maxInstallment . $currency . $testMode;
    $paytrToken = paytr_hash($merchantKey, $merchantSalt, $hashStr);

    $base = paytr_base_url();
    $post = [
        'merchant_id'       => $merchantId,
        'user_ip'           => $ip,
        'merchant_oid'      => $orderId,
        'email'             => $email,
        'payment_amount'    => $paymentAmount,
        'paytr_token'       => $paytrToken,
        'user_basket'       => $userBasket,
        'debug_on'          => $testMode,
        'no_installment'    => $noInstallment,
        'max_installment'   => $maxInstallment,
        'user_name'         => $userName,
        'user_address'      => 'Belirtilmedi',
        'user_phone'        => $userPhone,
        'merchant_ok_url'   => $base . '/payment/success?order_id=' . urlencode($orderId),
        'merchant_fail_url' => $base . '/payment/cancel?order_id=' . urlencode($orderId),
        'timeout_limit'     => '30',
        'currency'          => $currency,
        'test_mode'         => $testMode,
    ];

    $resp = paytr_http_post('https://www.paytr.com/odeme/api/get-token', $post);
    $data = json_decode($resp, true);
    if (!is_array($data) || ($data['status'] ?? '') !== 'success' || empty($data['token'] ?? '')) {
        error_log('[PayTR] Token alınamadı: ' . ($data['reason'] ?? 'JSON bozuk') . ' | ham: ' . substr($resp, 0, 300));
        throw new \RuntimeException('PayTR ödeme başlatılamadı.');
    }
    return 'https://www.paytr.com/odeme/guvenli/' . $data['token'];
}
