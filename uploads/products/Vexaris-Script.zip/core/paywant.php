<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

function paywant_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_paywant_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[paywant] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function paywant_is_ready(\PDO $db): bool {
    $cfg = paywant_settings($db);
    return ($cfg['payment_paywant_active'] ?? '0') === '1'
        && !empty($cfg['payment_paywant_api_key'] ?? '')
        && !empty($cfg['payment_paywant_api_secret'] ?? '');
}

function paywant_api_key(\PDO $db): string {
    $cfg = paywant_settings($db);
    return trim((string)($cfg['payment_paywant_api_key'] ?? ''));
}

function paywant_api_secret(\PDO $db): string {
    $cfg = paywant_settings($db);
    return trim((string)($cfg['payment_paywant_api_secret'] ?? ''));
}

function paywant_base_url(\PDO $db): string {
    try {
        $st = $db->prepare("SELECT value FROM settings WHERE `key`='site_url' LIMIT 1");
        $st->execute();
        $base = trim((string)($st->fetchColumn() ?? ''));
        if ($base !== '') {
            if (strpos($base, '://') === false) $base = 'https://' . $base;
            return rtrim($base, '/');
        }
    } catch (\Throwable $e) {}
    $scheme = function_exists('request_is_https') ? (request_is_https() ? 'https://' : 'http://') : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://');
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    if (!preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) $host = 'localhost';
    return rtrim($scheme . $host, '/');
}

function paywant_client_ip(): string {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    }
    return trim((string)$ip);
}

function paywant_hash(string $apiKey, string $apiSecret, string $userAccountName, string $userEmail, $userID): string {
    return base64_encode(hash_hmac('sha256', $userAccountName . '|' . $userEmail . '|' . $userID . $apiKey, $apiSecret, true));
}

function paywant_http_post(string $path, array $body): array {
    $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $ch = curl_init('https://secure.paywant.com' . $path);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST  => 'POST',
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Content-Length: ' . strlen((string)$payload)],
    ]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) throw new \RuntimeException('Paywant bağlantı hatası: ' . $err);
    $data = json_decode((string)$resp, true);
    if (!is_array($data)) throw new \RuntimeException('Paywant yanıtı çözümlenemedi (HTTP ' . $code . ').');
    $data['_http_code'] = $code;
    return $data;
}

function paywant_create_payment(\PDO $db, int $intentId, int $userId, string $username, string $email, float $totalTL, string $title): string {
    $apiKey = paywant_api_key($db);
    $apiSecret = paywant_api_secret($db);
    if ($apiKey === '' || $apiSecret === '') throw new \RuntimeException('Paywant API bilgileri eksik.');
    $amount = (int)round($totalTL * 100);
    if ($amount < 100) throw new \RuntimeException('Paywant minimum tutar 1,00 ₺.');
    if ($username === '') $username = $email;
    $base = paywant_base_url($db);
    $body = [
        'apiKey'          => $apiKey,
        'userAccountName' => mb_substr($username, 0, 100),
        'userEmail'       => mb_substr($email, 0, 100),
        'userID'          => $userId,
        'userIPAddress'   => paywant_client_ip(),
        'hash'            => paywant_hash($apiKey, $apiSecret, mb_substr($username, 0, 100), mb_substr($email, 0, 100), $userId),
        'proApi'          => true,
        'productData'     => [
            'name'           => mb_substr($title, 0, 150),
            'amount'         => $amount,
            'extraData'      => $intentId,
            'paymentChannel' => '0',
            'commissionType' => '2',
        ],
        'redirect_url'      => $base . '/payment/success',
        'fail_redirect_url' => $base . '/payment/cancel',
        'callback_url'      => $base . '/callback/paywant',
        'language'          => 'tr',
    ];
    $res = paywant_http_post('/payment/token', $body);
    if (($res['_http_code'] ?? 0) !== 200 || ($res['status'] ?? false) !== true || empty($res['message'])) {
        $msg = is_string($res['message'] ?? null) ? $res['message'] : json_encode($res, JSON_UNESCAPED_UNICODE);
        error_log('[paywant] Token alınamadı: ' . substr((string)$msg, 0, 300));
        throw new \RuntimeException('Paywant ödeme başlatılamadı: ' . substr((string)$msg, 0, 200));
    }
    return (string)$res['message'];
}

function paywant_verify_ipn(\PDO $db, array $post): bool {
    $apiKey = paywant_api_key($db);
    $apiSecret = paywant_api_secret($db);
    if ($apiKey === '' || $apiSecret === '') return false;
    $sig = (string)($post['hash'] ?? '');
    if ($sig === '') return false;
    $raw = (string)($post['transactionID'] ?? '') . '|' . (string)($post['extraData'] ?? '') . '|'
         . (string)($post['userID'] ?? '') . '|' . (string)($post['userAccountName'] ?? '') . '|'
         . (string)($post['status'] ?? '') . '|' . (string)($post['paymentChannel'] ?? '') . '|'
         . (string)($post['paymentTotal'] ?? '') . '|' . (string)($post['netProfit'] ?? '') . $apiKey;
    return hash_equals(base64_encode(hash_hmac('sha256', $raw, $apiSecret, true)), $sig);
}

function paywant_ipn_is_paid($status): bool {
    return (int)$status === 100;
}

function paywant_complete_intent(\PDO $db, array $intent, string $transactionId = ''): void {
    if ($transactionId !== '') {
        $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
           ->execute([substr($transactionId, 0, 40), $intent['id']]);
    } else {
        $db->prepare("UPDATE payment_intents SET status='completed' WHERE id=?")->execute([$intent['id']]);
    }

    $uid       = (int)$intent['user_id'];
    $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);
    $orderId   = (string)$intent['order_id'];

    if (strncmp($orderId, 'TOPUP-', 6) === 0) {
        $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
        $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'Paywant']) . '",NOW())')->execute([$uid, $creditAmt, 'topup']);
        $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
        $uStmt->execute([$uid]);
        $uInfo = $uStmt->fetch();
        discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body'), [
            __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
            __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ₺',
            __('bsupp.f_method')    => 'Paywant',
        ], 16766720);
        return;
    }

    require_once ROOT_PATH . '/core/purchase.php';
    [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);
    if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);

    $done = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
    purchase_finish($db, $uid, $done['total_paid'], 'Paywant', 'payment', $snapCoupon, $done['product_ids'] ?? null);

    $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
    $uStmt->execute([$uid]);
    $uInfo = $uStmt->fetch();
    discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body'), [
        __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
        __('bsupp.f_products')   => implode(', ', $done['product_names']),
        __('bsupp.f_amount')     => number_format($done['total_paid'], 2, ',', '.') . ' ₺',
        __('bsupp.f_method')    => 'Paywant',
    ], 5763719);
}

function paywant_test_connection(\PDO $db): void {
    $apiKey = paywant_api_key($db);
    $apiSecret = paywant_api_secret($db);
    if ($apiKey === '' || $apiSecret === '') throw new \RuntimeException('API Key ve API Secret yapılandırılmamış.');
    $hash = base64_encode(hash_hmac('sha256', $apiKey, $apiSecret, true));
    $url = 'https://secure.paywant.com/store/products?apiKey=' . rawurlencode($apiKey) . '&hash=' . rawurlencode($hash);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_SSL_VERIFYPEER => true]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) throw new \RuntimeException('Paywant bağlantı hatası: ' . $err);
    if ($code === 401) throw new \RuntimeException('Geçersiz Paywant API bilgileri (401).');
    if ($code < 200 || $code >= 300) throw new \RuntimeException('Paywant yanıt vermiyor (HTTP ' . $code . ').');
}
