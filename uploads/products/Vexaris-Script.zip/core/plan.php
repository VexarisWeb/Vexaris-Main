<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
function plan_setting_get(?PDO $db, string $key, string $default = ''): string {
    static $c = [];
    if (array_key_exists($key, $c)) return $c[$key];
    $c[$key] = $default;
    if (!$db) return $c[$key];
    try {
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`=? LIMIT 1");
        $st->execute([$key]);
        $v = $st->fetchColumn();
        if ($v !== false && $v !== null) $c[$key] = (string)$v;
    } catch (Throwable $e) {}
    return $c[$key];
}
function plan_setting_set(?PDO $db, string $key, string $value): void {
    if (!$db) return;
    try {
        $st = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        $st->execute([$key, $value]);
    } catch (Throwable $e) {}
}
function plan_defaults(): array {
    return [
        'free' => ['slug' => 'free', 'product_limit' => 7, 'revenue_limit_usd' => 100.0, 'revenue_reset' => 'never', 'seats' => 0, 'modules' => 'none', 'ai' => null],
        'starter' => ['slug' => 'starter', 'product_limit' => 35, 'revenue_limit_usd' => 1000.0, 'revenue_reset' => 'monthly', 'seats' => 3, 'modules' => 'basic', 'ai' => ['per_window' => 12, 'window_h' => 8]],
        'professional' => ['slug' => 'professional', 'product_limit' => 75, 'revenue_limit_usd' => 5000.0, 'revenue_reset' => 'monthly', 'seats' => 10, 'modules' => 'advanced', 'ai' => ['per_window' => 30, 'window_h' => 6]],
        'enterprise' => ['slug' => 'enterprise', 'product_limit' => -1, 'revenue_limit_usd' => -1.0, 'revenue_reset' => 'monthly', 'seats' => 30, 'modules' => 'advanced', 'ai' => ['per_window' => 70, 'window_h' => 4]],
    ];
}
function plan_sanitize(?array $p): ?array {
    if (!is_array($p)) return null;
    $d = plan_defaults();
    $slug = strtolower(trim((string)($p['slug'] ?? '')));
    if (!isset($d[$slug])) return null;
    $out = $d[$slug];
    $out['slug'] = $slug;
    if (isset($p['product_limit']) && is_numeric($p['product_limit'])) $out['product_limit'] = (int)$p['product_limit'];
    if (isset($p['revenue_limit_usd']) && is_numeric($p['revenue_limit_usd'])) $out['revenue_limit_usd'] = (float)$p['revenue_limit_usd'];
    if (in_array(($p['revenue_reset'] ?? ''), ['never', 'monthly'], true)) $out['revenue_reset'] = $p['revenue_reset'];
    if (isset($p['seats']) && is_numeric($p['seats'])) $out['seats'] = max(0, (int)$p['seats']);
    if (in_array(($p['modules'] ?? ''), ['none', 'basic', 'advanced'], true)) $out['modules'] = $p['modules'];
    if (array_key_exists('ai', $p)) {
        $out['ai'] = null;
        if (is_array($p['ai']) && isset($p['ai']['per_window'], $p['ai']['window_h'])) {
            $pw = max(1, (int)$p['ai']['per_window']);
            $wh = (int)$p['ai']['window_h'];
            if ($wh >= 1 && $wh <= 24) $out['ai'] = ['per_window' => $pw, 'window_h' => $wh];
        }
    }
    return $out;
}
function plan_synced(): ?array {
    if (!function_exists('config_sync_state')) return null;
    try {
        $st = config_sync_state();
    } catch (Throwable $e) { return null; }
    if (!is_array($st) || empty($st['plan']) || !is_array($st['plan'])) return null;
    return plan_sanitize($st['plan']);
}
function plan_current(): array {
    $s = plan_synced();
    if ($s !== null) {
        $s['source'] = 'synced';
        return $s;
    }
    $d = plan_defaults()['free'];
    $d['source'] = 'local';
    return $d;
}
function plan_product_limit(): int {
    return (int)plan_current()['product_limit'];
}
function plan_revenue_limit_usd(): float {
    return (float)plan_current()['revenue_limit_usd'];
}
function plan_seats(): int {
    return (int)plan_current()['seats'];
}
function plan_modules_mode(): string {
    return (string)plan_current()['modules'];
}
function plan_module_allowed(string $slug, ?array $manifest = null): bool {
    $mode = plan_modules_mode();
    if ($mode === 'advanced') return true;
    if ($mode !== 'basic') return false;
    if ($manifest === null && function_exists('module_manifest')) {
        try { $manifest = module_manifest($slug); } catch (Throwable $e) { $manifest = null; }
    }
    if (!is_array($manifest)) return true;
    return empty($manifest['gateway']);
}
function plan_ai(): ?array {
    $a = plan_current()['ai'];
    return is_array($a) ? $a : null;
}
function plan_product_count(?PDO $db = null): int {
    $db = $db ?: (function_exists('nexus_db') ? nexus_db() : null);
    if (!$db) return 0;
    $raw = null;
    try {
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='plan_product_count' LIMIT 1");
        $st->execute();
        $raw = $st->fetchColumn();
    } catch (Throwable $e) { $raw = null; }
    if ($raw === false || $raw === null) return plan_product_resync($db);
    return max(0, (int)$raw);
}
function plan_product_resync(?PDO $db = null): int {
    $db = $db ?: (function_exists('nexus_db') ? nexus_db() : null);
    if (!$db) return 0;
    try {
        $n = (int)$db->query("SELECT COUNT(*) FROM products")->fetchColumn();
        plan_setting_set($db, 'plan_product_count', (string)max(0, $n));
        return max(0, $n);
    } catch (Throwable $e) { return 0; }
}
function plan_product_bump(?PDO $db = null, int $delta = 1): int {
    $db = $db ?: (function_exists('nexus_db') ? nexus_db() : null);
    if (!$db) return 0;
    $n = plan_product_count($db) + $delta;
    if ($n < 0) $n = 0;
    plan_setting_set($db, 'plan_product_count', (string)$n);
    return $n;
}
function plan_revenue_sum(?PDO $db = null): float {
    $db = $db ?: (function_exists('nexus_db') ? nexus_db() : null);
    if (!$db) return 0.0;
    $p = plan_current();
    try {
        if (($p['revenue_reset'] ?? 'monthly') === 'never') {
            $st = $db->query("SELECT COALESCE(SUM(price_paid),0) FROM sales");
            return (float)$st->fetchColumn();
        }
        $st = $db->prepare("SELECT COALESCE(SUM(price_paid),0) FROM sales WHERE YEAR(purchased_at)=YEAR(CURDATE()) AND MONTH(purchased_at)=MONTH(CURDATE())");
        $st->execute();
        return (float)$st->fetchColumn();
    } catch (Throwable $e) { return 0.0; }
}
function plan_revenue_state(?PDO $db = null): string {
    $lim = plan_revenue_limit_usd();
    if ($lim < 0) return 'ok';
    $sum = plan_revenue_sum($db);
    if ($sum >= $lim) return 'locked';
    if ($lim > 0 && $sum >= $lim * 0.8) return 'warning';
    return 'ok';
}
function plan_payments_allowed(?PDO $db = null): bool {
    return plan_revenue_state($db) !== 'locked';
}
function plan_ai_window(): ?array {
    $a = plan_ai();
    if ($a === null) return null;
    $h = max(1, min(24, (int)$a['window_h']));
    $start = (int)(floor(time() / ($h * 3600)) * ($h * 3600));
    return ['limit' => max(1, (int)$a['per_window']), 'window_h' => $h, 'start' => $start, 'end' => $start + $h * 3600];
}
function plan_ai_used(?PDO $db = null, int $since = 0): int {
    $db = $db ?: (function_exists('nexus_db') ? nexus_db() : null);
    if (!$db || $since <= 0) return 0;
    try {
        $st = $db->prepare("SELECT COUNT(*) FROM audit_logs WHERE `resource`='ai_assistant' AND created_at >= FROM_UNIXTIME(?)");
        $st->execute([$since]);
        return max(0, (int)$st->fetchColumn());
    } catch (Throwable $e) { return 0; }
}
function plan_ai_check(?PDO $db = null): ?string {
    $w = plan_ai_window();
    if ($w === null) return function_exists('__') ? __('plan.ai_locked') : 'AI unavailable on this plan.';
    $used = plan_ai_used($db, (int)$w['start']);
    if ($used >= (int)$w['limit']) return function_exists('__') ? __('plan.ai_window_full', ['h' => (int)$w['window_h']]) : 'AI quota exhausted.';
    return null;
}
function plan_seats_used(?PDO $db = null): int {
    $db = $db ?: (function_exists('nexus_db') ? nexus_db() : null);
    if (!$db) return 0;
    try {
        $st = $db->query("SELECT COUNT(*) FROM users WHERE `role` NOT IN ('user','superadmin')");
        return max(0, (int)$st->fetchColumn());
    } catch (Throwable $e) { return 0; }
}
