<?php
defined('NEXUS_BOOT') or die('Direct access denied.');

/**
 * Ortak ödeme sonrası tamamlama mantığı.
 * Sepet satın alımlarını tek tek satırlara çevirir: her adet için AYRI
 * bir sales + orders kaydı ve AYRI bir lisans tüketilir.
 */

/** Sepeti kullanıcı için çeker. */
function purchase_cart_items(\PDO $db, int $uid): array {
    $s = $db->prepare(
        'SELECT c.product_id,c.quantity,p.name,p.price,p.discount_percent,p.license_prefix
         FROM cart c JOIN products p ON p.id=c.product_id
         WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"'
    );
    $s->execute([$uid]);
    return $s->fetchAll();
}

/**
 * Sepeti adam başına çevirir.
 * Her ürün adedi için ayrı sales + orders satırı oluşturur ve stok kaydını
 * tek tek tüketir. Dönüş: ['sale_ids'=>..., 'names'=>..., 'total_paid'=>float]
 * Parçalı işlem YOKTUR; çağıran kendi transaction'ında çalıştırmalıdır.
 */
function purchase_consume_cart(\PDO $db, int $uid, array $cartItems, ?float $chargedTotal = null, ?string $chargedCur = null): array {
    if ($chargedTotal !== null && $chargedCur !== null && $chargedCur !== '' && function_exists('fx_to_store')) $chargedTotal = fx_to_store($chargedTotal, $chargedCur);
    $saleCur = function_exists('store_currency') ? store_currency() : 'TRY';
    $saleStmt  = $db->prepare('INSERT INTO sales (user_id,product_id,price_paid,currency,purchased_at) VALUES (?,?,?,?,NOW())');
    $orderStmt = $db->prepare('INSERT INTO orders (user_id,product_id,price,status,created_at) VALUES (?,?,?,"completed",NOW())');
    $licStmt   = $db->prepare('UPDATE sales SET license_key=? WHERE id=?');
    $ownStmt   = $db->prepare('SELECT id FROM sales WHERE user_id=? AND product_id=? LIMIT 1');

    $units = [];
    foreach ($cartItems as $item) {
        $qty = max(1, (int)$item['quantity']);
        $dsc = min(90, max(0, (int)($item['discount_percent'] ?? 0)));
        $unit = round((float)$item['price'] * (1 - $dsc / 100), 2);
        if ($unit <= 0) $qty = 1;
        $ownStmt->execute([$uid, (int)$item['product_id']]);
        if ($ownStmt->fetch()) continue;
        for ($i = 0; $i < $qty; $i++) {
            $units[] = ['product_id' => (int)$item['product_id'], 'name' => (string)($item['name'] ?? ''), 'gross' => $unit];
        }
    }

    $gross = 0.0;
    foreach ($units as $u) $gross = round($gross + $u['gross'], 2);
    $scale = 1.0;
    if ($chargedTotal !== null && $chargedTotal >= 0 && $gross > 0 && $chargedTotal < $gross - 0.005) {
        $scale = $chargedTotal / $gross;
    }
    $n = count($units);
    $netSum = 0.0;
    for ($i = 0; $i < $n; $i++) {
        if ($scale < 1.0 && $i === $n - 1) {
            $units[$i]['net'] = max(0.0, round((float)$chargedTotal - $netSum, 2));
        } else {
            $units[$i]['net'] = round($units[$i]['gross'] * $scale, 2);
        }
        $netSum = round($netSum + $units[$i]['net'], 2);
    }

    $saleCount = 0;
    $totalPaid = 0.0;
    $productNames = [];
    $seenNames = [];
    foreach ($units as $u) {
        $key = $u['product_id'];
        if (!isset($seenNames[$key])) {
            $seenNames[$key] = true;
            $cnt = 0;
            foreach ($units as $v) if ($v['product_id'] === $key) $cnt++;
            $productNames[] = $u['name'] . ' x' . $cnt;
        }
        $lic = stock_consume($db, $u['product_id'], 1, $uid);
        if ($lic === null && !stock_is_unlimited($db, $u['product_id'])) {
            throw new \RuntimeException(__('bshop.stock_out', ['v' => ($u['name'] !== '' ? $u['name'] : ('#' . $u['product_id']))]));
        }
        $saleStmt->execute([$uid, $u['product_id'], $u['net'], $saleCur]);
        $sid = (int)$db->lastInsertId();
        try { $orderStmt->execute([$uid, $u['product_id'], $u['net']]); } catch (\Exception $e) {}
        if ($lic !== null) $licStmt->execute([$lic, $sid]);
        $totalPaid = round($totalPaid + $u['net'], 2);
        $saleCount++;
    }

    $result = ['sale_count' => $saleCount, 'product_names' => $productNames, 'total_paid' => round($totalPaid, 2), 'product_ids' => array_values(array_unique(array_map(function ($u) { return (int)$u['product_id']; }, $units)))];
    if (function_exists('audit_log')) {
        try {
            $auSt = $db->prepare('SELECT username,role FROM users WHERE id=? LIMIT 1');
            $auSt->execute([$uid]);
            $auRow = $auSt->fetch() ?: [];
            $auUser = ['id' => $uid, 'username' => (string)($auRow['username'] ?? ''), 'role' => (string)($auRow['role'] ?? '')];
            $auSeen = [];
            foreach ($units as $auU) {
                $auPid = (int)$auU['product_id'];
                if (isset($auSeen[$auPid])) continue;
                $auSeen[$auPid] = true;
                audit_log($db, 'create', 'sales', $auPid, (string)($auU['name'] !== '' ? $auU['name'] : '#' . $auPid), '/products?product=' . $auPid, $auUser);
            }
        } catch (\Throwable $e) {}
    }
    if (function_exists('do_action')) do_action('order_created', array_merge(['user_id' => $uid], $result));
    return $result;
}

function purchase_filter_owned(\PDO $db, int $uid, array $items): array {
    if (empty($items)) return [];
    $st = $db->prepare('SELECT product_id FROM sales WHERE user_id=?');
    $st->execute([$uid]);
    $owned = array_map('intval', $st->fetchAll(\PDO::FETCH_COLUMN));
    if (empty($owned)) return array_values($items);
    return array_values(array_filter($items, function ($it) use ($owned) {
        return is_array($it) && !in_array((int)($it['product_id'] ?? 0), $owned, true);
    }));
}

function purchase_snapshot_build(array $items, $coupon): string {
    $norm = [];
    foreach ($items as $it) {
        if (!is_array($it)) continue;
        $pid = (int)($it['product_id'] ?? 0);
        if ($pid <= 0) continue;
        $norm[] = [
            'product_id'       => $pid,
            'quantity'         => max(1, (int)($it['quantity'] ?? 1)),
            'name'             => mb_substr((string)($it['name'] ?? ''), 0, 160),
            'price'            => round((float)($it['price'] ?? 0), 2),
            'discount_percent' => min(90, max(0, (int)($it['discount_percent'] ?? 0))),
            'license_prefix'   => mb_substr((string)($it['license_prefix'] ?? ''), 0, 20),
        ];
    }
    $cid = (is_array($coupon) && !empty($coupon['id'])) ? (int)$coupon['id'] : 0;
    $snap = json_encode(['v' => 1, 'coupon_id' => $cid, 'items' => $norm], JSON_UNESCAPED_UNICODE);
    return is_string($snap) ? $snap : '{"v":1,"coupon_id":0,"items":[]}';
}

function purchase_snapshot_read(array $intent): array {
    $out = ['items' => [], 'coupon_id' => 0];
    $raw = (string)($intent['items_snapshot'] ?? '');
    if ($raw === '') return $out;
    try {
        $d = json_decode($raw, true);
        if (!is_array($d) || empty($d['items']) || !is_array($d['items'])) return $out;
        $items = [];
        foreach ($d['items'] as $it) {
            if (!is_array($it) || (int)($it['product_id'] ?? 0) <= 0) continue;
            $items[] = [
                'product_id'       => (int)$it['product_id'],
                'quantity'         => max(1, (int)($it['quantity'] ?? 1)),
                'name'             => mb_substr((string)($it['name'] ?? ''), 0, 160),
                'price'            => round((float)($it['price'] ?? 0), 2),
                'discount_percent' => min(90, max(0, (int)($it['discount_percent'] ?? 0))),
                'license_prefix'   => mb_substr((string)($it['license_prefix'] ?? ''), 0, 20),
            ];
        }
        if (empty($items)) return $out;
        $out['items'] = $items;
        $out['coupon_id'] = max(0, (int)($d['coupon_id'] ?? 0));
        return $out;
    } catch (\Throwable $e) {
        return $out;
    }
}

function purchase_items_for_intent(\PDO $db, int $uid, array $intent): array {
    $snap = purchase_snapshot_read($intent);
    if (!empty($snap['items'])) return [$snap['items'], $snap['coupon_id']];
    return [purchase_cart_items($db, $uid), 0];
}

/** Sepet tamamlama sonrası ortak temizlik + bakiye kaydı + kupon harcaması. */
function purchase_finish(\PDO $db, int $uid, float $totalPaid, string $methodLabel, string $logType = 'payment', int $couponId = 0, ?array $deliveredIds = null): void {
    $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,?,NOW())')
       ->execute([$uid, -$totalPaid, $logType, $methodLabel . ' ile satın alma']);
    $deliveredIds = is_array($deliveredIds) ? array_values(array_unique(array_map('intval', $deliveredIds))) : [];
    $deliveredIds = array_values(array_filter($deliveredIds, function ($v) { return $v > 0; }));
    if (!empty($deliveredIds)) {
        $in = implode(',', array_fill(0, count($deliveredIds), '?'));
        $db->prepare('DELETE FROM cart WHERE user_id=? AND product_id IN (' . $in . ')')->execute(array_merge([$uid], $deliveredIds));
    } else {
        $db->prepare('DELETE FROM cart WHERE user_id=?')->execute([$uid]);
    }
    $cid = $couponId > 0 ? $couponId : (int)($_SESSION['applied_coupon']['id'] ?? 0);
    if ($cid > 0) {
        require_once ROOT_PATH . '/core/coupons.php';
        $couponAlert = '';
        try {
            $db->prepare('SELECT id FROM coupons WHERE id=? FOR UPDATE')->execute([$cid]);
            $dup = $db->prepare('SELECT id FROM coupon_usages WHERE user_id=? AND coupon_id=?');
            $dup->execute([$uid, $cid]);
            if ($dup->fetch()) {
                $couponAlert = 'kupon tekrar teslimatta yakalandi';
            } elseif (!coupon_consume($db, $cid, $uid)) {
                $couponAlert = 'kupon tuketilemedi (kota dolmus olabilir)';
            }
        } catch (\Throwable $e) {
            $couponAlert = 'kupon finalize hatasi: ' . $e->getMessage();
        }
        if ($couponAlert !== '') {
            error_log('[Vexaris] ' . $couponAlert . ': coupon=' . $cid . ' user=' . $uid . ' total=' . $totalPaid);
            try {
                require_once ROOT_PATH . '/core/discord.php';
                if (function_exists('discord_notify')) discord_notify($db, 'coupon', __('bsupp.coupon_fail_title'), __('bsupp.coupon_fail_body'), [__('bsupp.f_coupon') => $cid, __('bsupp.f_user_ascii') => $uid, __('bsupp.f_amount') => $totalPaid], '16711680');
            } catch (\Throwable $e) {}
        }
    }
    unset($_SESSION['applied_coupon']);
    if (function_exists('do_action')) do_action('purchase_after', $uid, $totalPaid, $methodLabel, $logType);
}