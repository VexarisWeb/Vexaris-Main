<?php
defined('NEXUS_BOOT') or die('Direct access denied.');

function nx_safe_url(string $url): string {
    $u = trim($url);
    if ($u === '') return '';
    if (preg_match('#^(https?://|/)#i', $u)) return $u;
    return '';
}

function nx_safe_href($url, string $fallback = '#'): string {
    $u = trim((string)$url);
    if ($u === '') return $fallback;
    $t = (string)preg_replace('/[\x00-\x20]+/', '', $u);
    if (preg_match('/^(javascript|vbscript|data):/i', $t)) return $fallback;
    return $u;
}

function nx_gateway_redirect(string $url, array $hosts): ?string {
    $u = trim($url);
    if ($u === '' || strlen($u) > 2048) return null;
    if (preg_match('/[\x00-\x1f\x7f]/', $u)) return null;
    $t = $u;
    if (!preg_match('~^https://~i', $t)) return null;
    $parts = parse_url($t);
    if (!is_array($parts) || empty($parts['host'])) return null;
    $host = strtolower((string)$parts['host']);
    foreach ($hosts as $h) {
        $h = strtolower(ltrim(trim((string)$h), '.'));
        if ($h === '') continue;
        if ($host === $h) return $t;
        if (substr($host, -1 * (strlen($h) + 1)) === '.' . $h) return $t;
    }
    return null;
}

function nx_gateway_redirect_or_fail(string $url, array $hosts): string {
    $safe = nx_gateway_redirect($url, $hosts);
    if ($safe === null) {
        error_log('[gateway] blocked redirect to untrusted host: ' . substr((string)$url, 0, 200));
        header('Location: /shop/payment?flash=' . urlencode('error:' . __('bshop.pay_page_fail')), true, 302);
        exit;
    }
    return $safe;
}

function request_is_https(): bool {
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') return true;
    $proto = strtolower(trim((string)(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0] ?? '')));
    if ($proto === 'https') return true;
    if (strpos(strtolower((string)($_SERVER['HTTP_CF_VISITOR'] ?? '')), 'https') !== false) return true;
    return (string)($_SERVER['SERVER_PORT'] ?? '') === '443';
}

function site_base_url(?PDO $db = null): string {
    try {
        if ($db) {
            $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='site_url' LIMIT 1");
            $st->execute();
            $base = trim((string)($st->fetchColumn() ?? ''));
            if ($base !== '') {
                if (strpos($base, '://') === false) $base = 'https://' . $base;
                return rtrim($base, '/');
            }
        }
    } catch (\Throwable $e) {}
    try {
        if (defined('LOCK_FILE') && is_file(LOCK_FILE)) {
            $lockRaw = @file_get_contents(LOCK_FILE);
            $lock = is_string($lockRaw) ? json_decode($lockRaw, true) : null;
            $lockDomain = strtolower(trim((string)(is_array($lock) ? ($lock['domain'] ?? '') : '')));
            if ($lockDomain !== '' && preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $lockDomain)) {
                return 'https://' . rtrim($lockDomain, '/');
            }
        }
    } catch (\Throwable $e) {}
    $scheme = request_is_https() ? 'https' : 'http';
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
    if ($host === '' || !preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) return '';
    return rtrim($scheme . '://' . $host, '/');
}

function site_abs_url(?PDO $db, string $path): string {
    $path = trim($path);
    if ($path === '') return '';
    if (preg_match('#^https?://#i', $path)) return $path;
    $base = site_base_url($db);
    if ($base === '') return '';
    return $base . '/' . ltrim(preg_replace('#^(\./)+#', '', $path), '/');
}

function site_og_data(?PDO $db): array {
    $out = ['site' => 'Vexaris', 'desc' => '', 'image' => '', 'w' => 0, 'h' => 0];
    try {
        if ($db) {
            $st = $db->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('site_name','site_logo','footer_copyright') LIMIT 3");
            $st->execute();
            foreach ($st->fetchAll() as $r) {
                if ($r['key'] === 'site_name' && trim((string)$r['value']) !== '') $out['site'] = mb_substr(trim((string)$r['value']), 0, 80);
                if ($r['key'] === 'site_logo') $logo = trim((string)$r['value']);
                if ($r['key'] === 'footer_copyright') $out['desc'] = trim((string)$r['value']);
            }
            if (!empty($logo ?? '')) {
                $abs = site_abs_url($db, $logo);
                if ($abs !== '' && preg_match('#\.(jpe?g|png|webp|gif)(\?.*)?$#i', (string)parse_url($abs, PHP_URL_PATH))) {
                    $out['image'] = $abs;
                    if (!preg_match('#^https?://#i', (string)$logo) && defined('ROOT_PATH')) {
                        $local = rtrim(ROOT_PATH, '/\\') . '/' . ltrim(preg_replace('#^(\./)+#', '', (string)$logo), '/');
                        if (is_file($local)) {
                            $size = @getimagesize($local);
                            if (is_array($size) && $size[0] > 0 && $size[1] > 0) {
                                $out['w'] = (int)$size[0];
                                $out['h'] = (int)$size[1];
                            }
                        }
                    }
                }
            }
        }
    } catch (\Throwable $e) {}
    $out['desc'] = mb_substr(trim(strip_tags(html_entity_decode($out['desc'], ENT_QUOTES, 'UTF-8'))), 0, 200);
    if ($out['desc'] === '' && function_exists('__')) {
        try { $out['desc'] = mb_substr(trim(strip_tags(__('footer.desc_default'))), 0, 200); } catch (\Throwable $e) {}
    }
    return $out;
}

function site_og_tags(?PDO $db, string $title = '', string $desc = ''): string {
    $og = site_og_data($db);
    if ($title === '') $title = $og['site'];
    if ($desc === '') $desc = $og['desc'];
    $t = htmlspecialchars(mb_substr($title, 0, 120), ENT_QUOTES, 'UTF-8');
    $d = htmlspecialchars(mb_substr($desc, 0, 200), ENT_QUOTES, 'UTF-8');
    $h = '<meta property="og:type" content="website">' . "\n"
        . '    <meta property="og:site_name" content="' . htmlspecialchars($og['site'], ENT_QUOTES, 'UTF-8') . '">' . "\n"
        . '    <meta property="og:title" content="' . $t . '">' . "\n";
    if ($d !== '') $h .= '    <meta property="og:description" content="' . $d . '">' . "\n";
    $url = site_base_url($db);
    $req = (string)($_SERVER['REQUEST_URI'] ?? '/');
    if ($url !== '') $h .= '    <meta property="og:url" content="' . htmlspecialchars($url . $req, ENT_QUOTES, 'UTF-8') . '">' . "\n";
    if ($og['image'] !== '') {
        $h .= '    <meta property="og:image" content="' . htmlspecialchars($og['image'], ENT_QUOTES, 'UTF-8') . '">' . "\n";
        if ($og['w'] > 0 && $og['h'] > 0) {
            $h .= '    <meta property="og:image:width" content="' . $og['w'] . '">' . "\n"
                . '    <meta property="og:image:height" content="' . $og['h'] . '">' . "\n";
        }
        $h .= '    <meta name="twitter:card" content="summary_large_image">' . "\n";
    } else {
        $h .= '    <meta name="twitter:card" content="summary">' . "\n";
    }
    $h .= '    <meta name="twitter:title" content="' . $t . '">' . "\n";
    if ($d !== '') $h .= '    <meta name="twitter:description" content="' . $d . '">' . "\n";
    return $h;
}

function nx_clean_html(string $html, string $level = 'rich'): string {
    $html = (string)preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $html);
    if ($level === 'inline') {
        $allowed = ['b', 'strong', 'i', 'em', 'u', 'span', 'br'];
    } elseif ($level === 'basic') {
        $allowed = ['b', 'strong', 'i', 'em', 'u', 'a', 'span', 'font', 'br', 'p', 'div'];
    } else {
        $allowed = ['b', 'strong', 'i', 'em', 'u', 'a', 'span', 'font', 'br', 'p', 'div', 'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'img', 'table', 'thead', 'tbody', 'tr', 'td', 'th', 'blockquote', 'pre', 'code', 'hr'];
    }
    if (!class_exists('DOMDocument')) return nx_clean_html_regex($html, $allowed);
    $prev = libxml_use_internal_errors(true);
    $doc = new DOMDocument('1.0', 'UTF-8');
    $doc->loadHTML('<?xml encoding="utf-8"?><div>' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();
    libxml_use_internal_errors($prev);
    $wraps = $doc->getElementsByTagName('div');
    $wrap = ($wraps->length > 0) ? $wraps->item(0) : $doc->documentElement;
    if (!$wrap) return '';
    nx_clean_html_walk($wrap, $allowed);
    $out = '';
    foreach ($wrap->childNodes as $child) {
        $h = $doc->saveHTML($child);
        if (is_string($h)) $out .= $h;
    }
    return $out;
}

function nx_clean_html_walk(DOMNode $node, array $allowed): void {
    $drop = ['script', 'style', 'iframe', 'object', 'embed', 'applet', 'form', 'input', 'button', 'select', 'textarea', 'option', 'link', 'meta', 'base', 'title', 'frame', 'frameset', 'noembed', 'noframes', 'noscript', 'template', 'slot', 'xmp', 'plaintext', 'listing', 'marquee', 'blink'];
    $kids = [];
    foreach ($node->childNodes as $c) $kids[] = $c;
    foreach ($kids as $c) {
        if ($c->nodeType === XML_ELEMENT_NODE) {
            $tag = strtolower($c->nodeName);
            if (!in_array($tag, $allowed, true)) {
                if (in_array($tag, $drop, true)) {
                    $node->removeChild($c);
                } else {
                    nx_clean_html_walk($c, $allowed);
                    while ($c->firstChild) $node->insertBefore($c->firstChild, $c);
                    $node->removeChild($c);
                }
                continue;
            }
            if ($c instanceof DOMElement) nx_clean_html_attrs($c);
            nx_clean_html_walk($c, $allowed);
        } elseif ($c->nodeType === XML_COMMENT_NODE || $c->nodeType === XML_PI_NODE) {
            $node->removeChild($c);
        }
    }
}

function nx_clean_html_attrs(DOMElement $el): void {
    $urlAttrs = ['href', 'src', 'srcset', 'xlink:href', 'cite', 'action', 'formaction', 'poster', 'background'];
    $remove = [];
    foreach ($el->attributes as $a) {
        $name = strtolower($a->nodeName);
        $val = (string)$a->nodeValue;
        if (strncmp($name, 'on', 2) === 0 || $name === 'xmlns' || strncmp($name, 'xmlns:', 6) === 0) {
            $remove[] = $a->nodeName;
            continue;
        }
        if (in_array($name, $urlAttrs, true)) {
            $v = trim($val);
            if ($name === 'href') {
                if (!preg_match('#^(https?://|mailto:|/|\#)#i', $v)) $el->setAttribute($a->nodeName, '#');
            } elseif (!preg_match('#^(https?://|/|data:image/(png|jpeg|gif|webp);)#i', $v)) {
                $remove[] = $a->nodeName;
            }
            continue;
        }
        if ($name === 'style') {
            $low = strtolower($val);
            if (strpos($low, 'expression') !== false || strpos($low, 'javascript:') !== false || strpos($low, 'vbscript:') !== false || strpos($low, 'behavior') !== false || strpos($low, '-moz-binding') !== false) $remove[] = $a->nodeName;
        }
    }
    foreach ($remove as $n) $el->removeAttribute($n);
}

function nx_clean_html_regex(string $html, array $allowed): string {
    $s = strip_tags($html, '<' . implode('><', $allowed) . '>');
    $s = (string)preg_replace('/[\s\/]\son\w+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $s);
    $s = (string)preg_replace('/\son\w+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $s);
    $s = (string)preg_replace('/\sxmlns(:\w+)?\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $s);
    $s = (string)preg_replace_callback('/\sstyle\s*=\s*("[^"]*"|\'[^\']*\')/i', function ($m) {
        $v = strtolower($m[1]);
        if (strpos($v, 'expression') !== false || strpos($v, 'javascript:') !== false || strpos($v, 'vbscript:') !== false || strpos($v, 'behavior') !== false || strpos($v, '-moz-binding') !== false) return '';
        return $m[0];
    }, $s);
    $s = (string)preg_replace_callback('/(href|src|srcset|xlink:href|cite|action|formaction|poster|background)\s*=\s*("[^"]*"|\'[^\']*\')/i', function ($m) {
        $attr = strtolower($m[1]);
        $q = $m[2][0];
        $u = trim(substr($m[2], 1, -1));
        if ($attr === 'href') {
            if (!preg_match('#^(https?://|mailto:|/|\#)#i', $u)) $u = '#';
        } else {
            if (!preg_match('#^(https?://|/|data:image/(png|jpeg|gif|webp);)#i', $u)) return '';
        }
        return $m[1] . '=' . $q . $u . $q;
    }, $s);
    $s = (string)preg_replace_callback('/\s(href|src|srcset|xlink:href|cite|action|formaction|poster|background)\s*=\s*([^\s>"\']+)/i', function ($m) {
        $attr = strtolower($m[1]);
        $u = trim($m[2]);
        if ($attr === 'href') {
            if (!preg_match('#^(https?://|mailto:|/|\#)#i', $u)) return ' href="#"';
        } else {
            if (!preg_match('#^(https?://|/|data:image/(png|jpeg|gif|webp);)#i', $u)) return '';
        }
        return $m[0];
    }, $s);
    $s = (string)preg_replace('/<(script|style|iframe|object|embed|applet|form|input|button|select|textarea|option|link|meta|base|title|frame|frameset|noembed|noframes|noscript|template|slot|svg|math|xmp|plaintext|listing|marquee|blink)[^>]*>.*?<\/\1\s*>/is', '', $s);
    $s = (string)preg_replace('/<(script|style|iframe|object|embed|applet|form|input|button|select|textarea|option|link|meta|base|title|frame|frameset|noembed|noframes|noscript|template|slot|svg|math|xmp|plaintext|listing|marquee|blink)[^>]*\/?>/i', '', $s);
    return $s;
}