<?php
function shopier_cfg(PDO $db): array {
    $rows = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_shopier_%'")->fetchAll();
    $cfg=[]; foreach($rows as $r) $cfg[$r['key']]=$r['value'];
    return $cfg;
}

function shopier_setting(PDO $db, string $key): string {
    try {
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`=? LIMIT 1");
        $st->execute([$key]);
        return (string)($st->fetchColumn() ?? '');
    } catch (\Throwable $e) {
        return '';
    }
}

function shopier_osb_verify(string $res, string $hash, string $username, string $key): ?array {
    if ($res === '') return null;
    if ($username === '' || $key === '') return null;
    $expected = hash_hmac('sha256', $res . $username, $key, false);
    if ($hash === '' || !hash_equals($expected, $hash)) return null;
    $payload = json_decode(base64_decode($res), true);
    return is_array($payload) ? $payload : null;
}

function shopier_pat_request(string $pat, string $method, string $path, ?array $body=null): array {
    if ($pat === '') throw new RuntimeException('Shopier Personal Access Token eksik.');
    $ch=curl_init('https://api.shopier.com/v1'.(str_starts_with($path,'/')?$path:'/'. $path));
    $headers=['Accept: application/json','Authorization: Bearer '.$pat];
    if($body!==null){$headers[]='Content-Type: application/json'; $payload=json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>strtoupper($method),CURLOPT_HTTPHEADER=>$headers,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>30]);
    if($body!==null) curl_setopt($ch,CURLOPT_POSTFIELDS,$payload);
    $raw=curl_exec($ch); $errno=curl_errno($ch); $err=curl_error($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
    if($errno) throw new RuntimeException('Shopier bağlantı hatası: '.$err);
    $json=json_decode((string)$raw,true);
    if($code<200 || $code>=300) {
        $detail=is_array($json)?($json['message']??$json['error']??$json['detail']??''):'';
        throw new RuntimeException('Shopier API HTTP '.$code.($detail?' - '.$detail:''));
    }
    return is_array($json)?$json:[];
}

function shopier_test_connection(PDO $db): array {
    $cfg=shopier_cfg($db); $pat=trim($cfg['payment_shopier_pat']??'');
    if($pat==='') throw new RuntimeException('Personal Access Token girilmemiş.');
    return shopier_pat_request($pat,'GET','/shop/owner');
}

function shopier_base_url(PDO $db): string {
    try {
        $st=$db->prepare("SELECT value FROM settings WHERE `key`='site_url' LIMIT 1");
        $st->execute();
        $base=trim((string)($st->fetchColumn() ?? ''));
        if($base!=='') {
            if(strpos($base,'://')===false) $base='https://'.$base;
            return rtrim($base,'/');
        }
    } catch (\Throwable $e) {}
    $scheme=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off')?'https':'http';
    $host=$_SERVER['HTTP_HOST']??'';
    if($host==='') throw new RuntimeException('Site adresi belirlenemedi.');
    return rtrim($scheme.'://'.$host,'/');
}

function shopier_base_url_strict(PDO $db): string {
    try {
        $st=$db->prepare("SELECT value FROM settings WHERE `key`='site_url' LIMIT 1");
        $st->execute();
        $base=trim((string)($st->fetchColumn() ?? ''));
        if($base!=='') {
            if(strpos($base,'://')===false) $base='https://'.$base;
            return rtrim($base,'/');
        }
    } catch (\Throwable $e) {}
    throw new RuntimeException('Site adresi (site_url) yapılandırılmamış.');
}

function shopier_currency(PDO $db): string {
    $cfg=shopier_cfg($db);
    $c=strtoupper(trim($cfg['payment_shopier_currency'] ?? 'TRY'));
    return in_array($c, ['TRY','USD','EUR'], true) ? $c : 'TRY';
}

function shopier_image_ext_ok(string $filename): bool {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, ['jpg','jpeg','png','bmp','webp','gif'], true);
}

function shopier_image_abs(PDO $db, string $img): string {
    $img = trim($img);
    if ($img === '') return '';
    if (filter_var($img, FILTER_VALIDATE_URL)) {
        $abs = $img;
    } else {
        $rel = ltrim((string)preg_replace('#^(\./)+#', '', $img), '/');
        if ($rel === '') return '';
        $abs = shopier_base_url($db) . '/' . $rel;
    }
    $path = parse_url($abs, PHP_URL_PATH) ?? '';
    if (!shopier_image_ext_ok((string)$path)) return '';
    return $abs;
}

function shopier_store_logo(PDO $db): string {
    $abs = shopier_image_abs($db, shopier_setting($db, 'site_logo'));
    if ($abs !== '') return $abs;
    try {
        if (defined('ROOT_PATH')) {
            $dir = rtrim(ROOT_PATH, '/\\') . '/uploads/logo';
            if (is_dir($dir)) {
                $files = scandir($dir);
                if (is_array($files)) {
                    foreach ($files as $f) {
                        if ($f === '.' || $f === '..') continue;
                        if (!shopier_image_ext_ok($f)) continue;
                        $full = $dir . '/' . $f;
                        if (is_file($full)) return shopier_base_url($db) . '/uploads/logo/' . $f;
                    }
                }
            }
        }
    } catch (\Throwable $e) {}
    return '';
}

function shopier_payment_image(PDO $db, ?string $productImage = null): string {    $baseUrl = shopier_base_url($db);
    $abs = shopier_image_abs($db, (string)$productImage);
    if ($abs !== '') return $abs;
    $logo = shopier_store_logo($db);
    if ($logo !== '') return $logo;
    return $baseUrl.'/images/payments/shopier.png';
}

function shopier_create_checkout(PDO $db, float $amount, string $orderId, string $title, ?string $productImage = null): array {
    $cfg=shopier_cfg($db); $pat=trim($cfg['payment_shopier_pat']??''); $slug=trim($cfg['payment_shopier_shop_slug']??'');
    if($pat==='') throw new RuntimeException('Personal Access Token girilmemiş.');
    if($slug==='') throw new RuntimeException('Shopier mağaza adresi (shop slug) girilmemiş.');
    if($amount<=0) throw new RuntimeException('Geçersiz ödeme tutarı.');
    $baseUrl = shopier_base_url_strict($db);
    $image = shopier_payment_image($db, $productImage);
    $currency = shopier_currency($db);

    $isTopup = strncmp($orderId, 'TOPUP-', 6) === 0;
    $returnUrl = $baseUrl . ($isTopup ? '/user/dashboard?tab=balance&shopier_return=1' : '/user/my-products?shopier_return=1');
    $notifyUrl = $baseUrl . '/callback/shopier_osb.php';

    $productBody = [
        'title'        => mb_substr($title, 0, 120),
        'description'  => store_name($db) . ' ödeme - ' . $orderId,
        'type'         => 'digital',
        'shippingPayer'=> 'sellerPays',
        'priceData'    => ['currency' => $currency, 'price' => number_format($amount, 2, '.', '')],
        'media'        => [['type' => 'image', 'url' => $image, 'placement' => 1]],
        'stockQuantity'=> 1,
        'customListing'=> true,
        'customNote'   => $orderId,
    ];

    foreach (['notifyUrl', 'notify_url', 'webhookUrl', 'webhook_url', 'callbackUrl', 'callback_url'] as $urlField) {
        $productBody[$urlField] = $notifyUrl;
    }

    $product = shopier_pat_request($pat, 'POST', '/products', $productBody);
    $productId=(string)($product['id']??$product['data']['id']??'');
    $productUrl=(string)($product['url']??$product['data']['url']??'');
    if($productId==='') throw new RuntimeException('Shopier ürün oluşturuldu ancak ürün ID dönmedi.');

    if($productUrl !== '') {
        $checkout='<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Shopier Ödeme</title>'
            .'<script>window.location.href='.json_encode($productUrl, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).';</script>'
            .'</head><body></body></html>';
    } else {
        $checkout='<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Shopier Ödeme</title></head><body>'
            .'<form id="shopier-checkout" method="POST" action="https://www.shopier.com/s/shipping/'.htmlspecialchars(rawurlencode($slug),ENT_QUOTES,'UTF-8').'">'
            .'<input type="hidden" name="product_id" value="'.htmlspecialchars($productId,ENT_QUOTES,'UTF-8').'">'
            .'<input type="hidden" name="quantity" value="1">'
            .'</form><script>document.getElementById("shopier-checkout").submit();</script>'
            .'</body></html>';
    }
    return ['product_id'=>$productId,'product_url'=>$productUrl,'checkout_html'=>$checkout];
}
