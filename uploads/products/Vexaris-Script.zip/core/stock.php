<?php
defined('NEXUS_BOOT') or die('Direct access denied.');

/**
 * Ürün stok yardımcıları.
 * stock_type = 'unlimited' → sonsuz stok (satışla azalmaz, "bir stok herkese yeter").
 * stock_type = 'limited'   → sınırlı stok; her satışta 1 stok kaydı tüketilir.
 *
 * Kayıt-bazlı stok: her stok kaydı (product_stocks) ayrı bir içerik taşır
 * (ör. lisans anahtarı). Satışta bir kayıt kullanılmış (used=1) işaretlenir ve
 * içeriği sales.license_key sütununa yazılır. products.stock/total_stock yalnızca
 * hızlı sayım için aynadan ibarettir (sıralama/rozet amacıyla).
 */

/** Kullanılmamış stok kaydı sayısı. */
function stock_items_available(PDO $db, int $pid): int {
    $s = $db->prepare('SELECT COUNT(*) FROM product_stocks WHERE product_id=? AND used=0');
    $s->execute([$pid]);
    return (int)$s->fetchColumn();
}

/** Stok kaydı ekler; products sayacını da günceller. */
function stock_item_add(PDO $db, int $pid, array $contents): int {
    $added = 0;
    $ins = $db->prepare('INSERT INTO product_stocks (product_id,content) VALUES (?,?)');
    foreach ($contents as $c) {
        $c = trim((string)$c);
        if ($c === '') continue;
        $ins->execute([$pid, $c]);
        $added++;
    }
    if ($added > 0) {
        $db->prepare('UPDATE products SET total_stock=total_stock+?, stock=stock+? WHERE id=?')->execute([$added,$added,$pid]);
    }
    return $added;
}

/** Bir stok kaydını kaldırır (kullanılmamışsa sayacı düşürür). */
function stock_item_delete(PDO $db, int $stockId): void {
    $row = $db->prepare('SELECT product_id, used FROM product_stocks WHERE id=?');
    $row->execute([$stockId]);
    $r = $row->fetch();
    if (!$r) return;
    $db->prepare('DELETE FROM product_stocks WHERE id=?')->execute([$stockId]);
    if (!$r['used']) {
        $db->prepare('UPDATE products SET stock=GREATEST(stock-1,0), total_stock=GREATEST(total_stock-1,0) WHERE id=?')->execute([$r['product_id']]);
    }
}

/**
 * Satışta stok kaydı tüketir. Kullanılmamış kayıt(lar)ı used=1 yapar ve
 * içeriklerini yeni satıra ayrılmış olarak döndürür. Kayıt yoksa null döner
 * (sonsuz stokta / kayıt yoksa boş). products.stock sayacını düşürür.
 */
function stock_consume(PDO $db, int $pid, int $qty = 1, int $userId = 0): ?string {
    $records = [];
    $sel = $db->prepare('SELECT id, content FROM product_stocks WHERE product_id=? AND used=0 ORDER BY id ASC LIMIT ? FOR UPDATE');
    $sel->bindValue(1, $pid, PDO::PARAM_INT);
    $sel->bindValue(2, max(1,$qty), PDO::PARAM_INT);
    $sel->execute();
    $records = $sel->fetchAll();
    if (!empty($records)) {
        $ids = array_column($records, 'id');
        $content = implode("\n", array_map(function($r){ return trim((string)$r['content']); }, $records));
        $in  = implode(',', array_fill(0, count($ids), '?'));
        $sql = "UPDATE product_stocks SET used=1, used_by_user=?, used_at=NOW() WHERE id IN ($in)";
        $stmt = $db->prepare($sql);
        $stmt->bindValue(1, $userId ?: null, PDO::PARAM_INT);
        $i = 2; foreach ($ids as $id) $stmt->bindValue($i++, $id, PDO::PARAM_INT);
        $stmt->execute();
        $db->prepare('UPDATE products SET stock=GREATEST((SELECT COUNT(*) FROM product_stocks WHERE product_id=? AND used=0),0), total_stock=GREATEST((SELECT COUNT(*) FROM product_stocks WHERE product_id=?),total_stock) WHERE id=?')->execute([$pid,$pid,$pid]);
        return $content === '' ? null : $content;
    }
    $info = stock_info($db, $pid);
    if (($info['stock_type'] ?? 'unlimited') === 'unlimited') {
        $pr = $db->prepare('SELECT digital_file FROM products WHERE id=?');
        $pr->execute([$pid]);
        $df = $pr->fetchColumn();
        return $df !== false && trim((string)$df) !== '' ? (string)$df : null;
    }
    return null;
}

/** Mevcut (kalan) adet. Sonsuz stokta her zaman yeterli kabul edilir. */
function stock_available(PDO $db, int $pid, int $qty = 1): bool {
    if (stock_is_unlimited($db, $pid)) return true;
    return stock_items_available($db, $pid) >= $qty;
}

function stock_info(PDO $db, int $pid): array {
    $st = $db->prepare('SELECT stock_type, stock, total_stock FROM products WHERE id=?');
    $st->execute([$pid]);
    $row = $st->fetch();
    return $row ?: ['stock_type' => 'unlimited', 'stock' => 0, 'total_stock' => 0];
}

function stock_available_locked(PDO $db, int $pid, int $qty = 1): bool {
    $qty = max(1, $qty);
    $db->prepare('SELECT id FROM products WHERE id=? FOR UPDATE')->execute([$pid]);
    $info = stock_info($db, $pid);
    if (($info['stock_type'] ?? 'unlimited') === 'unlimited') return true;
    $s = $db->prepare('SELECT COUNT(*) FROM product_stocks WHERE product_id=? AND used=0 FOR UPDATE');
    $s->execute([$pid]);
    return ((int)$s->fetchColumn() >= $qty);
}

function stock_is_unlimited(PDO $db, int $pid): bool {
    return (stock_info($db, $pid)['stock_type'] ?? 'unlimited') === 'unlimited';
}