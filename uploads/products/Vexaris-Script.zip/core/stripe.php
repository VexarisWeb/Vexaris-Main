<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

function stripe_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_stripe_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[stripe] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function stripe_is_ready(\PDO $db): bool {
    $cfg = stripe_settings($db);
    return ($cfg['payment_stripe_active'] ?? '0') === '1'
        && !empty($cfg['payment_stripe_api_key'] ?? '')
        && strncmp(trim((string)($cfg['payment_stripe_api_key'] ?? '')), 'sk_', 3) === 0;
}

function stripe_is_test_mode(\PDO $db): bool {
    $cfg = stripe_settings($db);
    return ((string)($cfg['payment_stripe_test_mode'] ?? '0')) === '1';
}

function stripe_base_url(): string {
    if (function_exists('site_base_url')) {
        try {
            $b = site_base_url(function_exists('nexus_db') ? nexus_db() : null);
            if ($b !== '') return rtrim($b, '/');
        } catch (\Throwable $e) {}
    }
    $scheme = function_exists('request_is_https') ? (request_is_https() ? 'https://' : 'http://') : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://');
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    if (!preg_match('/^[a-z0-9.-]+(?::[0-9]{1,5})?$/', $host)) $host = 'localhost';
    return rtrim($scheme . $host, '/');
}

function stripe_client(\PDO $db): \Stripe\StripeClient {
    require_once ROOT_PATH . '/vendor/autoload.php';
    $cfg = stripe_settings($db);
    $secret = trim((string)($cfg['payment_stripe_api_key'] ?? ''));
    if ($secret === '') {
        throw new \RuntimeException('Stripe gizli anahtarı eksik.');
    }
    return new \Stripe\StripeClient($secret);
}

function stripe_currency(\PDO $db): string {
    $cfg = stripe_settings($db);
    $siteCurrency = trim((string)($cfg['payment_stripe_currency'] ?? 'TRY'));
    $map = ['TRY' => 'try', 'EUR' => 'eur', 'USD' => 'usd', 'GBP' => 'gbp', 'JPY' => 'jpy'];
    return $map[$siteCurrency] ?? 'try';
}

function stripe_currency_is_zero_decimal(string $currency): bool {
    return in_array(strtolower($currency), ['jpy', 'krw', 'vnd', 'clp', 'isk', 'pyg', 'ugx', 'jod', 'kmf', 'mga', 'vuv', 'xaf', 'xof'], true);
}

function stripe_amount_to_minor(\PDO $db, float $amount): int {
    $currency = stripe_currency($db);
    if (stripe_currency_is_zero_decimal($currency)) {
        return (int)round($amount);
    }
    return (int)round($amount * 100);
}

/**
 * Stripe Checkout Session oluşturur ve tarayıcının yönlendirileceği URL'i döner.
 */
function stripe_create_checkout(\PDO $db, string $orderId, string $email, float $total, bool $isTopup): string {
    $client = stripe_client($db);
    $currency = stripe_currency($db);
    $amountMinor = stripe_amount_to_minor($db, $total);

    $success = stripe_base_url() . '/payment/success?order_id=' . urlencode($orderId) . '&session_id={CHECKOUT_SESSION_ID}';
    $cancel  = stripe_base_url() . '/payment/cancel?order_id=' . urlencode($orderId);
    $product = $isTopup ? gateway_topup_title($db, $total, stripe_currency($db)) : __('bshop.order_default', ['store' => store_name($db)]);

    try {
        $session = $client->checkout->sessions->create([
            'mode'                      => 'payment',
            'payment_method_types'      => ['card'],
            'line_items'                => [[
                'price_data' => [
                    'currency'     => $currency,
                    'product_data' => ['name' => $product . ' #' . $orderId],
                    'unit_amount'  => $amountMinor,
                ],
                'quantity' => 1,
            ]],
            'customer_email'            => $email,
            'metadata'                  => ['order_id' => $orderId],
            'client_reference_id'       => $orderId,
            'success_url'               => $success,
            'cancel_url'                => $cancel,
        ]);
    } catch (\Stripe\Exception\ApiErrorException $e) {
        error_log('[Vexaris] stripe create checkout: ' . $e->getMessage());
        throw new \RuntimeException('Stripe oturumu oluşturulamadı: ' . $e->getMessage());
    }

    return (string)$session->url;
}

function stripe_parse_webhook(\PDO $db): \Stripe\Event {
    $cfg = stripe_settings($db);
    $secret = trim((string)($cfg['payment_stripe_webhook_secret'] ?? ''));
    if ($secret === '') {
        throw new \RuntimeException('Stripe webhook secret eksik.');
    }
    require_once ROOT_PATH . '/vendor/autoload.php';
    $payload = file_get_contents('php://input');
    $sig = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
    return \Stripe\Webhook::constructEvent($payload, $sig, $secret);
}