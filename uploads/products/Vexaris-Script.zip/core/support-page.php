<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
if (!defined('ROOT_PATH')) define('ROOT_PATH', dirname(__DIR__));
function support_page_flash(): array {
    $t = $x = '';
    if (isset($_GET['flash'])) {
        [$t, $x] = explode(':', urldecode($_GET['flash']), 2) + ['', ''];
    }
    return [$t, $x];
}
function support_page_defaults(): array {
    return ['activeTicket' => null, 'ticketReplies' => [], 'myTickets' => [], 'hasOpen' => false, 'categories' => ['Genel', 'Teknik Sorun', 'Lisans', 'Ödeme', 'Diğer']];
}
function support_page_data(\PDO $db, int $uid, int $tid): array {
    $out = support_page_defaults();
    $out['categories'] = [];
    if ($tid > 0) {
        $st = $db->prepare('SELECT t.*, u.username FROM tickets t LEFT JOIN users u ON u.id=t.user_id WHERE t.id=? AND t.user_id=?');
        $st->execute([$tid, $uid]);
        $activeTicket = $st->fetch();
        if ($activeTicket) {
            $rs = $db->prepare('SELECT r.*, u.username, u.avatar FROM ticket_replies r LEFT JOIN users u ON u.id=r.user_id WHERE r.ticket_id=? ORDER BY r.created_at ASC, r.id ASC');
            $rs->execute([$tid]);
            $ticketReplies = $rs->fetchAll();
            try {
                $db->prepare('UPDATE ticket_replies SET is_seen=1 WHERE ticket_id=? AND is_admin=1')->execute([$tid]);
                foreach ($ticketReplies as &$trow) { if ((int)$trow['is_admin'] === 1) $trow['is_seen'] = 1; }
                unset($trow);
            } catch (\PDOException $e) {}
            $out['activeTicket'] = $activeTicket;
            $out['ticketReplies'] = $ticketReplies;
        }
    }
    $st = $db->prepare('SELECT * FROM tickets WHERE user_id=? ORDER BY COALESCE(updated_at,created_at) DESC, id DESC');
    $st->execute([$uid]);
    $myTickets = $st->fetchAll();
    $hasOpen = false;
    foreach ($myTickets as $ht) {
        if (($ht['status'] ?? '') === 'closed') continue;
        if (mb_strtolower(trim((string)($ht['category'] ?? ''))) === 'havale talebi') continue;
        $hasOpen = true;
        break;
    }
    $out['myTickets'] = $myTickets;
    $out['hasOpen'] = $hasOpen;
    try {
        $cs = $db->query('SELECT name FROM ticket_categories ORDER BY sort_order ASC, name ASC');
        $categories = $cs->fetchAll(\PDO::FETCH_COLUMN);
    } catch (\Throwable $e) { $categories = []; }
    $categories = array_values(array_filter(array_map('trim', (array)$categories), function ($c) {
        return $c !== '' && mb_strtolower($c) !== 'havale talebi';
    }));
    if (!empty($categories)) $out['categories'] = $categories;
    return $out;
}
