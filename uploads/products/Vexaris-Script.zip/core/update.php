<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

require_once ROOT_PATH . '/core/config-sync.php';

define('UPDATE_CHECK_TTL', 43200);
define('UPDATE_MAX_DELAY', 6);

function update_origin(): string {
    $p = parse_url(CONFIG_SYNC_ORIGIN);
    if (!is_array($p) || empty($p['scheme']) || empty($p['host'])) return CONFIG_SYNC_ORIGIN;
    $u = $p['scheme'] . '://' . $p['host'];
    if (!empty($p['port'])) $u .= ':' . $p['port'];
    return $u;
}

function update_http_post(string $url, array $payload, int $timeout): string {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_FOLLOWLOCATION => false,
        ]);
        $out = curl_exec($ch);
        curl_close($ch);
        return is_string($out) ? $out : '';
    }
    $body = http_build_query($payload);
    $ctx  = stream_context_create(['http' => [
        'method'        => 'POST',
        'header'        => "Content-Type: application/x-www-form-urlencoded\r\nContent-Length: " . strlen($body),
        'content'       => $body,
        'timeout'       => $timeout,
        'ignore_errors' => true,
    ]]);
    $out = @file_get_contents($url, false, $ctx);
    return is_string($out) ? $out : '';
}

function update_sig(string $domain, int $ts, string $nonce): string {
    return hash_hmac('sha256', $domain . '|' . $ts . '|' . $nonce, config_sync_key());
}

function update_domain(): string {
    return strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
}

function update_gate(): bool {
    if (!function_exists('feature_active')) return false;
    return feature_active('updates');
}

function update_state(?\PDO $db = null, bool $reload = false): array {
    static $c = null;
    if ($reload || $c === null) {
        $c = ['ts' => 0, 'version' => '', 'description' => '', 'file_size' => '', 'file_name' => '', 'available' => false];
        $db = $db ?: (function_exists('nexus_db') ? nexus_db() : null);
        if ($db) {
            try {
                $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='_vx_update' LIMIT 1");
                $st->execute();
                $raw = $st->fetchColumn();
                if ($raw) {
                    $d = json_decode((string)$raw, true);
                    if (is_array($d)) {
                        $c['ts']          = (int)($d['ts'] ?? 0);
                        $c['version']     = (string)($d['version'] ?? '');
                        $c['description'] = (string)($d['description'] ?? '');
                        $c['file_size']   = (string)($d['file_size'] ?? '');
                        $c['file_name']   = (string)($d['file_name'] ?? '');
                        $c['available']   = (bool)($d['available'] ?? false);
                    }
                }
            } catch (\Throwable $e) {}
        }
    }
    return $c;
}

function update_store(\PDO $db, array $state): void {
    try {
        $st = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('_vx_update',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        $st->execute([json_encode($state)]);
    } catch (\Throwable $e) {}
}

function update_check_remote(\PDO $db, string $domain): ?array {
    if ($domain === '') return null;
    $nonce = bin2hex(random_bytes(32));
    $ts    = time();
    $sig   = update_sig($domain, $ts, $nonce);
    $raw   = update_http_post(update_origin() . '/api/check-update.php', [
        'domain'    => $domain,
        'timestamp' => $ts,
        'nonce'     => $nonce,
        'signature' => $sig,
    ], 10);
    if ($raw === '') return null;
    $j = json_decode($raw, true);
    if (!is_array($j)) return null;
    if (!isset($j['timestamp'], $j['signature'])) return null;
    $tsR = (int)$j['timestamp'];
    if ($tsR <= 0 || abs(time() - $tsR) > 300) return null;
    $body = !empty($j['version']) && is_array($j['version']) ? json_encode($j['version']) : '{}';
    $exp  = hash_hmac('sha256', $body . '|' . $tsR, config_sync_key());
    if (!is_string($j['signature']) || !hash_equals($exp, $j['signature'])) return null;
    return [
        'available'   => !empty($j['ok']) && is_array($j['version']),
        'version'     => (string)($j['version']['version'] ?? ''),
        'description' => (string)($j['version']['description'] ?? ''),
        'file_size'   => (string)($j['version']['file_size'] ?? ''),
        'file_name'   => (string)($j['version']['file_name'] ?? ''),
        'published'   => (string)($j['version']['published'] ?? ''),
        'ts'          => $tsR,
    ];
}

function update_maybe(?\PDO $db = null): void {
    if (PHP_SAPI === 'cli') return;
    if (!update_gate()) return;
    $db = $db ?: (function_exists('nexus_db') ? nexus_db() : null);
    if (!$db) return;
    $st = update_state($db);
    if ($st['ts'] > 0 && time() - $st['ts'] < UPDATE_CHECK_TTL) return;
    $res = update_check_remote($db, update_domain());
    if ($res === null) return;
    update_store($db, [
        'ts'          => $res['ts'],
        'version'     => $res['version'],
        'description' => $res['description'],
        'file_size'   => $res['file_size'],
        'file_name'   => $res['file_name'],
        'available'   => $res['available'],
    ]);
}

function update_available(\PDO $db): bool {
    if (!update_gate()) return false;
    $st = update_state($db);
    if (!$st['available'] || $st['version'] === '') return false;
    return version_compare($st['version'], vexaris_current_version($db), '>');
}

function update_delay_state(\PDO $db): array {
    $out = ['count' => 0, 'until' => 0];
    try {
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='_vx_update_delay' LIMIT 1");
        $st->execute();
        $raw = $st->fetchColumn();
        if ($raw) {
            $d = json_decode((string)$raw, true);
            if (is_array($d)) {
                $out['count'] = (int)($d['count'] ?? 0);
                $out['until'] = (int)($d['until'] ?? 0);
            }
        }
    } catch (\Throwable $e) {}
    return $out;
}

function update_delay_save(\PDO $db, array $state): void {
    try {
        $st = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('_vx_update_delay',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        $st->execute([json_encode($state)]);
    } catch (\Throwable $e) {}
}

function update_delay_next(int $current): int {
    $n = $current + 1;
    return $n > UPDATE_MAX_DELAY ? 1 : $n;
}

function update_delay_apply(\PDO $db): array {
    $st = update_delay_state($db);
    $n  = update_delay_next($st['count']);
    update_delay_save($db, ['count' => $n, 'until' => time() + ($n * 86400)]);
    return ['count' => $n, 'until' => time() + ($n * 86400)];
}

function update_delay_blocked(\PDO $db): bool {
    $st = update_delay_state($db);
    return $st['until'] > 0 && time() < $st['until'];
}

function update_parse_size(string $s): int {
    $s = trim($s);
    if ($s === '') return 0;
    if (preg_match('/^(\d+(?:[.,]\d+)?)\s*(b|bytes?|kb|mb|gb)?$/i', $s, $m)) {
        $n = (float)str_replace(',', '.', $m[1]);
        $u = strtolower($m[2] ?? '');
        if ($u === '' || $u === 'b' || $u === 'byte' || $u === 'bytes') return (int)$n;
        if ($u === 'kb') return (int)round($n * 1024);
        if ($u === 'mb') return (int)round($n * 1048576);
        if ($u === 'gb') return (int)round($n * 1073741824);
    }
    if (preg_match('/^\d+$/', $s)) return (int)$s;
    return 0;
}

function update_is_zip(string $path): bool {
    if (!is_file($path)) return false;
    $size = @filesize($path);
    if (!is_int($size) && !is_float($size)) return false;
    if ((int)$size < 4) return false;
    $fh = @fopen($path, 'rb');
    if (!$fh) return false;
    $magic = fread($fh, 4);
    fclose($fh);
    if (!is_string($magic) || strlen($magic) < 4) return false;
    if (substr($magic, 0, 2) !== 'PK') return false;
    return $magic[2] === "\x03" || $magic[2] === "\x05" || $magic[2] === "\x07";
}

function update_error_snippet(string $path): string {
    $raw = @file_get_contents($path, false, null, 0, 512);
    if (!is_string($raw) || $raw === '') return '';
    if (substr(ltrim($raw), 0, 1) === '{') {
        $j = json_decode($raw, true);
        if (is_array($j)) {
            foreach (['msg', 'error', 'message', 'reason'] as $k) {
                if (isset($j[$k]) && is_string($j[$k]) && trim($j[$k]) !== '') return mb_substr(trim($j[$k]), 0, 160);
            }
        }
    }
    $txt = trim((string)preg_replace('/\s+/', ' ', strip_tags($raw)));
    return mb_substr($txt, 0, 160);
}

function update_fail(\PDO $db, string $version, string $dest, string $msg): array {
    @unlink($dest);
    update_progress_set($db, ['phase' => 'error', 'percent' => 0, 'msg' => $msg, 'total' => 0, 'done' => 0, 'version' => $version]);
    return ['ok' => false, 'msg' => $msg];
}

function vexaris_current_version(\PDO $db, bool $reload = false): string {
    static $v = null;
    if ($reload || $v === null) {
        $v = '1.0.0';
        try {
            $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='_vx_installed_version' LIMIT 1");
            $st->execute();
            $raw = $st->fetchColumn();
            if ($raw !== false && $raw !== null && (string)$raw !== '') $v = (string)$raw;
        } catch (\Throwable $e) {}
    }
    return $v;
}

function update_progress_get(\PDO $db): array {
    $out = ['phase' => 'idle', 'percent' => 0, 'msg' => '', 'total' => 0, 'done' => 0, 'version' => ''];
    try {
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='_vx_upd_progress' LIMIT 1");
        $st->execute();
        $raw = $st->fetchColumn();
        if ($raw) {
            $d = json_decode((string)$raw, true);
            if (is_array($d)) $out = array_merge($out, $d);
        }
    } catch (\Throwable $e) {}
    return $out;
}

function update_progress_set(\PDO $db, array $state): void {
    try {
        $st = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('_vx_upd_progress',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        $st->execute([json_encode($state)]);
    } catch (\Throwable $e) {}
}

function update_auto_enabled(\PDO $db): bool {
    try {
        $st = $db->prepare("SELECT `value` FROM settings WHERE `key`='auto_update' LIMIT 1");
        $st->execute();
        return (string)$st->fetchColumn() === '1';
    } catch (\Throwable $e) {
        return false;
    }
}

function update_auto_enable(\PDO $db, bool $on): void {
    try {
        $st = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('auto_update',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        $st->execute([$on ? '1' : '0']);
    } catch (\Throwable $e) {}
}

function update_download_and_install(\PDO $db, string $version): array {
    if (!update_gate()) return ['ok' => false, 'msg' => 'Güncelleme sistemi bu lisansta kapalı.'];
    if (PHP_SAPI !== 'cli' && function_exists('session_status') && session_status() === PHP_SESSION_ACTIVE) {
        @session_write_close();
    }
    $domain = update_domain();
    if ($domain === '') return ['ok' => false, 'msg' => 'Domain algılanamadı.'];
    $safeVer = preg_replace('/[^A-Za-z0-9.\-]/', '', $version);
    if (!is_string($safeVer) || $safeVer === '') return ['ok' => false, 'msg' => 'Geçersiz sürüm.'];
    $nonce = bin2hex(random_bytes(32));
    $ts    = time();
    $sig   = update_sig($domain, $ts, $nonce);
    $url   = update_origin() . '/api/download-update.php';
    $dest  = ROOT_PATH . '/uploads/_vx_update_' . $safeVer . '.zip';
    if (is_file($dest)) @unlink($dest);
    $fp = @fopen($dest, 'wb');
    if (!$fp) return ['ok' => false, 'msg' => 'Geçici dosya açılamadı.'];
    $ok  = false;
    $err = '';
    $code = 0;
    $lastPct = -1;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => ['domain' => $domain, 'timestamp' => $ts, 'nonce' => $nonce, 'signature' => $sig, 'version' => $version],
            CURLOPT_TIMEOUT        => 900,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_FILE           => $fp,
            CURLOPT_NOPROGRESS     => false,
            CURLOPT_PROGRESSFUNCTION => function ($ch, $dSize, $dNow, $uSize, $uNow) use ($db, $version, &$lastPct) {
                if ($dSize > 0) {
                    $pct = (int)floor(($dNow / $dSize) * 100);
                    if ($pct !== $lastPct) {
                        $lastPct = $pct;
                        update_progress_set($db, ['phase' => 'download', 'percent' => $pct, 'msg' => 'İndiriliyor: ' . $pct . '%', 'total' => $dSize, 'done' => $dNow, 'version' => $version]);
                    }
                }
                return 0;
            },
        ]);
        $exec = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $err  = (string)curl_error($ch);
        curl_close($ch);
        $ok = $exec !== false && $code >= 200 && $code < 300 && is_file($dest) && (int)@filesize($dest) > 1024;
    } else {
        $body = http_build_query(['domain' => $domain, 'timestamp' => $ts, 'nonce' => $nonce, 'signature' => $sig, 'version' => $version]);
        $ctx  = stream_context_create(['http' => [
            'method'  => 'POST',
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\nContent-Length: " . strlen($body),
            'timeout' => 900,
            'ignore_errors' => true,
        ]]);
        $src = @fopen($url, 'rb', false, $ctx);
        if ($src) {
            $total = 0;
            while (!feof($src)) {
                $chunk = fread($src, 65536);
                if ($chunk === false) break;
                fwrite($fp, $chunk);
                $total += strlen($chunk);
                if ($total % 262144 === 0) {
                    update_progress_set($db, ['phase' => 'download', 'percent' => 50, 'msg' => 'İndiriliyor… (' . number_format($total / 1048576, 1) . ' MB)', 'total' => 0, 'done' => $total, 'version' => $version]);
                }
            }
            fclose($src);
            if (isset($http_response_header) && is_array($http_response_header)) {
                foreach ($http_response_header as $h) {
                    if (preg_match('#^HTTP/\S+\s+(\d{3})#i', (string)$h, $m)) $code = (int)$m[1];
                }
            }
            if ($code === 0) $code = 200;
            $ok = $code >= 200 && $code < 300 && is_file($dest) && (int)@filesize($dest) > 1024;
        }
    }
    fclose($fp);
    if (!$ok) {
        if ($code > 0 && ($code < 200 || $code >= 300)) {
            $snip = update_error_snippet($dest);
            return update_fail($db, $version, $dest, 'Sunucu indirmeyi reddetti (HTTP ' . $code . ').' . ($snip !== '' ? ' ' . $snip : ''));
        }
        if ($err !== '') return update_fail($db, $version, $dest, 'İndirme hatası: ' . $err);
        if (is_file($dest) && (int)@filesize($dest) > 0 && !update_is_zip($dest)) {
            $snip = update_error_snippet($dest);
            return update_fail($db, $version, $dest, 'Sunucu paket yerine hata döndürdü.' . ($snip !== '' ? ' ' . $snip : ''));
        }
        return update_fail($db, $version, $dest, 'İndirme başarısız.');
    }
    $actual = (int)@filesize($dest);
    $expSize = update_parse_size((string)(update_state($db)['file_size'] ?? ''));
    if ($expSize > 0) {
        $tol = max(16384, (int)($expSize * 0.03));
        if (abs($actual - $expSize) > $tol) {
            return update_fail($db, $version, $dest, 'İndirilen dosya doğrulanamadı.');
        }
    }
    if (!update_is_zip($dest)) {
        $snip = update_error_snippet($dest);
        return update_fail($db, $version, $dest, 'İndirilen paket zip arşivi değil.' . ($snip !== '' ? ' ' . $snip : ''));
    }
    $inst = update_install_zip($db, $dest, $version);
    @unlink($dest);
    if (empty($inst['ok'])) {
        update_progress_set($db, ['phase' => 'error', 'percent' => 0, 'msg' => (string)($inst['msg'] ?? ''), 'total' => 0, 'done' => 0, 'version' => $version]);
    }
    return $inst;
}

function update_install_zip(\PDO $db, string $zip, string $version): array {
    if (!is_file($zip) || !update_is_zip($zip)) {
        return ['ok' => false, 'msg' => 'İndirilen paket zip arşivi değil.'];
    }
    if (!class_exists('ZipArchive')) {
        return ['ok' => false, 'msg' => 'ZipArchive eklentisi gerekli.'];
    }
    $z = new ZipArchive();
    if ($z->open($zip) !== true) {
        return ['ok' => false, 'msg' => 'Zip açılamadı.'];
    }
    $total = (int)$z->numFiles;
    if ($total < 1 || $total > 5000) {
        $z->close();
        return ['ok' => false, 'msg' => 'Geçersiz arşiv içeriği.'];
    }
    $dest  = ROOT_PATH;
    for ($i = 0; $i < $total; $i++) {
        $name = (string)$z->getNameIndex($i);
        if (strpos($name, '..') !== false || strpos($name, '\\') !== false || strpos($name, ':') !== false || strncmp($name, '/', 1) === 0) {
            $z->close();
            return ['ok' => false, 'msg' => 'Geçersiz arşiv içeriği.'];
        }
        $stat = $z->statIndex($i);
        if (is_array($stat) && (int)($stat['size'] ?? 0) > 134217728) {
            $z->close();
            return ['ok' => false, 'msg' => 'Geçersiz arşiv içeriği.'];
        }
        if (method_exists($z, 'getExternalAttributesIndex')) {
            $opsys = 0; $xattr = 0;
            if ($z->getExternalAttributesIndex($i, $opsys, $xattr) && ((($xattr >> 16) & 0170000) === 0120000)) {
                $z->close();
                return ['ok' => false, 'msg' => 'Geçersiz arşiv içeriği.'];
            }
        }
        if (!$z->extractTo($dest, $name)) {
            $z->close();
            return ['ok' => false, 'msg' => 'Dosya yazılamadı: ' . $name];
        }
        $pct = $total > 0 ? (int)floor((($i + 1) / $total) * 100) : 100;
        update_progress_set($db, ['phase' => 'install', 'percent' => $pct, 'msg' => 'Kuruluyor: ' . $pct . '%', 'total' => $total, 'done' => $i + 1, 'version' => $version]);
    }
    $z->close();
    try {
        $st = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('_vx_installed_version',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        $st->execute([$version]);
        $st2 = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('_vx_update_delay',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        $st2->execute([json_encode(['count' => 0, 'until' => 0])]);
        $st3 = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('_vx_update',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        $st3->execute([json_encode(['ts' => time(), 'version' => $version, 'description' => '', 'file_size' => '', 'file_name' => '', 'available' => false])]);
    } catch (\Throwable $e) {}
    update_progress_set($db, ['phase' => 'done', 'percent' => 100, 'msg' => 'Güncelleme tamamlandı.', 'total' => $total, 'done' => $total, 'version' => $version]);
    return ['ok' => true, 'msg' => 'Güncelleme başarıyla kuruldu.', 'version' => $version];
}