<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));

function whop_settings(\PDO $db): array {
    $cfg = [];
    try {
        $raw = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_whop_%'")->fetchAll();
        foreach ($raw as $r) $cfg[$r['key']] = $r['value'];
    } catch (\PDOException $e) {
        error_log('[whop] settings: ' . $e->getMessage());
    }
    return $cfg;
}

function whop_test_mode(\PDO $db): bool {
    $cfg = whop_settings($db);
    return ($cfg['payment_whop_test_mode'] ?? '0') === '1';
}

function whop_api_base(\PDO $db): string {
    return whop_test_mode($db) ? 'https://sandbox-api.whop.com/api/v1' : 'https://api.whop.com/api/v1';
}

function whop_api_key(\PDO $db): string {
    $cfg = whop_settings($db);
    return trim((string)($cfg['payment_whop_api_key'] ?? ''));
}

function whop_account_id(\PDO $db): string {
    $cfg = whop_settings($db);
    return trim((string)($cfg['payment_whop_account_id'] ?? ''));
}

function whop_product_id(\PDO $db): string {
    $cfg = whop_settings($db);
    return trim((string)($cfg['payment_whop_product_id'] ?? ''));
}

function whop_currency(\PDO $db): string {
    $cfg = whop_settings($db);
    $c = strtolower(trim((string)($cfg['payment_whop_currency'] ?? 'try')));
    return preg_match('/^[a-z]{3,5}$/', $c) ? $c : 'try';
}

function whop_webhook_secret(\PDO $db): string {
    $cfg = whop_settings($db);
    return trim((string)($cfg['payment_whop_webhook_secret'] ?? ''));
}

function whop_is_ready(\PDO $db): bool {
    $cfg = whop_settings($db);
    return ($cfg['payment_whop_active'] ?? '0') === '1'
        && !empty($cfg['payment_whop_api_key'] ?? '')
        && !empty($cfg['payment_whop_account_id'] ?? '');
}

function whop_api_version(): string {
    return '2026-09-15';
}

function whop_request(\PDO $db, string $method, string $path, $body = null, string $idempotencyKey = ''): array {
    $key = whop_api_key($db);
    if ($key === '') throw new \RuntimeException('Whop API anahtarı yapılandırılmamış.');
    $headers = ['Authorization: Bearer ' . $key, 'Accept: application/json', 'Api-Version-Date: ' . whop_api_version()];
    $payload = null;
    if ($body !== null) {
        $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($payload === false) throw new \RuntimeException('Whop isteği hazırlanamadı.');
        $headers[] = 'Content-Type: application/json';
    }
    if ($idempotencyKey !== '') $headers[] = 'Idempotency-Key: ' . mb_substr($idempotencyKey, 0, 255);
    $ch = curl_init(whop_api_base($db) . $path);
    $opts = [CURLOPT_CUSTOMREQUEST => strtoupper($method), CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_HTTPHEADER => $headers];
    if ($payload !== null) $opts[CURLOPT_POSTFIELDS] = $payload;
    curl_setopt_array($ch, $opts);
    $resp = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) throw new \RuntimeException('Whop bağlantı hatası: ' . $err);
    $data = json_decode((string)$resp, true);
    if ($code < 200 || $code >= 300) {
        $msg = is_array($data) ? (string)($data['message'] ?? $data['error'] ?? json_encode($data, JSON_UNESCAPED_UNICODE)) : substr((string)$resp, 0, 200);
        throw new \RuntimeException('Whop API hatası (HTTP ' . $code . '): ' . mb_substr($msg, 0, 200));
    }
    if (!is_array($data)) throw new \RuntimeException('Whop yanıtı çözümlenemedi (HTTP ' . $code . ').');
    return $data;
}

function whop_create_checkout(\PDO $db, float $total, string $orderId, string $title): array {
    if (!whop_is_ready($db)) throw new \RuntimeException('Whop aktif değil.');
    $amount = round($total, 2);
    if ($amount < 1) throw new \RuntimeException('Whop ile en az 1,00 tutarında ödeme alınabilir.');
    $body = [
        'initial_price' => $amount,
        'currency' => whop_currency($db),
        'plan_type' => 'one_time',
        'title' => mb_substr($title, 0, 30),
        'description' => mb_substr($title, 0, 200),
        'visibility' => 'hidden',
        'metadata' => ['order_id' => mb_substr($orderId, 0, 100)],
    ];
    $accountId = whop_account_id($db);
    if ($accountId !== '') $body['account_id'] = $accountId;
    $productId = whop_product_id($db);
    if ($productId !== '') $body['product_id'] = $productId;
    $plan = whop_request($db, 'POST', '/plans', $body, $orderId);
    $url = (string)($plan['purchase_url'] ?? '');
    $planId = (string)($plan['id'] ?? '');
    if ($url === '' || $planId === '') throw new \RuntimeException('Whop ödeme bağlantısı oluşturulamadı.');
    return ['purchase_url' => $url, 'plan_id' => $planId];
}

function whop_verify_webhook(\PDO $db, string $raw, array $headers) {
    $secret = whop_webhook_secret($db);
    if ($secret === '' || $raw === '') return false;
    $h = [];
    foreach ($headers as $k => $v) $h[strtolower((string)$k)] = $v;
    $id = (string)($h['webhook-id'] ?? '');
    $ts = (string)($h['webhook-timestamp'] ?? '');
    $sig = (string)($h['webhook-signature'] ?? '');
    if ($id === '' || $ts === '' || $sig === '') return false;
    if (abs(time() - (int)$ts) > 300) return false;
    $calc = base64_encode(hash_hmac('sha256', $id . '.' . $ts . '.' . $raw, $secret, true));
    $ok = false;
    foreach (explode(' ', $sig) as $part) {
        if (strncmp($part, 'v1,', 3) === 0 && hash_equals('v1,' . $calc, $part)) $ok = true;
    }
    if (!$ok) return false;
    $event = json_decode($raw, true);
    if (!is_array($event) || ($event['id'] ?? '') !== $id) return false;
    return $event;
}

function whop_complete_intent(\PDO $db, array $intent, string $transactionId = ''): void {
    if ($transactionId !== '') {
        $db->prepare("UPDATE payment_intents SET status='completed',payment_id=? WHERE id=?")
           ->execute([substr($transactionId, 0, 40), $intent['id']]);
    } else {
        $db->prepare("UPDATE payment_intents SET status='completed' WHERE id=?")->execute([$intent['id']]);
    }

    $uid       = (int)$intent['user_id'];
    $totalPaid = (float)$intent['total_amount'];
    $creditAmt = function_exists('fx_to_store') ? fx_to_store($totalPaid, (string)($intent['currency'] ?? 'TRY')) : round($totalPaid, 2);
    $orderId   = (string)$intent['order_id'];
    $cur       = strtoupper((string)($intent['currency'] ?? 'TRY'));

    if (strncmp($orderId, 'TOPUP-', 6) === 0) {
        $db->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$creditAmt, $uid]);
        $db->prepare('INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?,?,"' . __('bshop.topup_log', ['method' => 'Whop']) . '",NOW())')->execute([$uid, $creditAmt, 'topup']);
        $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
        $uStmt->execute([$uid]);
        $uInfo = $uStmt->fetch();
        discord_notify($db, 'topup', __('bsupp.topup_title'), __('bsupp.topup_body'), [
            __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
            __('bsupp.f_amount')     => number_format($totalPaid, 2, ',', '.') . ' ' . $cur,
            __('bsupp.f_method')    => 'Whop',
        ], 16766720);
        return;
    }

    require_once ROOT_PATH . '/core/purchase.php';
    [$cartItems, $snapCoupon] = purchase_items_for_intent($db, $uid, $intent);
    if (empty($cartItems)) throw new \RuntimeException('Teslim edilecek ürün bulunamadı. user_id=' . $uid);

    $done = purchase_consume_cart($db, $uid, $cartItems, (float)($intent['total_amount'] ?? 0), (string)($intent['currency'] ?? 'TRY'));
    purchase_finish($db, $uid, $done['total_paid'], 'Whop', 'payment', $snapCoupon, $done['product_ids'] ?? null);

    $uStmt = $db->prepare('SELECT username,email FROM users WHERE id=?');
    $uStmt->execute([$uid]);
    $uInfo = $uStmt->fetch();
    discord_notify($db, 'order', __('bsupp.order_title'), __('bsupp.order_body'), [
        __('bsupp.f_user') => ($uInfo['username'] ?? '#' . $uid),
        __('bsupp.f_products')   => implode(', ', $done['product_names']),
        __('bsupp.f_amount')     => number_format($done['total_paid'], 2, ',', '.') . ' ' . $cur,
        __('bsupp.f_method')    => 'Whop',
    ], 5763719);
}

function whop_test_connection(\PDO $db): void {
    if (!whop_is_ready($db)) throw new \RuntimeException('API anahtarı ve hesap ID yapılandırılmamış.');
    $chk = whop_create_checkout($db, 1.0, 'vexaris-test-' . time() . '-' . bin2hex(random_bytes(4)), store_name($db) . ' Test');
    try {
        whop_request($db, 'DELETE', '/plans/' . rawurlencode($chk['plan_id']));
    } catch (\Throwable $e) {
        error_log('[whop] test planı silinemedi: ' . $e->getMessage());
        throw new \RuntimeException('Bağlantı başarılı ancak test planı silinemedi (' . $chk['plan_id'] . ').');
    }
}
