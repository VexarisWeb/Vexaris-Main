<?php
/**
 * download.php — Vexaris Güvenli Dijital Dosya Teslimatı
 *
 * Kullanım: /download.php?sale_id=X
 * - Session kontrolü
 * - Satın alım kaydı doğrulaması (sale_id + user_id eşleşmesi)
 * - Dosyanın sunucu yolu gizlenerek force-download
 */

define('NEXUS_BOOT', true);
define('ROOT_PATH', __DIR__);
require_once __DIR__ . '/core/db.php';
require_once __DIR__ . '/core/managers/auth-man.php';

/* ── Giriş kontrolü ── */
if (!auth_check()) {
    header('Location: /login?flash=' . urlencode('error:İndirmek için giriş yapmalısınız.'));
    exit;
}

$saleId = (int)($_GET['sale_id'] ?? 0);
if (!$saleId) {
    http_response_code(400);
    die('Geçersiz istek.');
}

$db  = nexus_db();
$uid = (int)auth_user()['id'];

if (!$db) {
    http_response_code(503);
    die('Sunucu geçici olarak kullanılamıyor.');
}

/* ── Satın alım kaydını doğrula ── */
$stmt = $db->prepare(
    'SELECT s.id, s.license_key, p.file_path, p.name
     FROM sales s
     JOIN products p ON p.id = s.product_id
     WHERE s.id = ? AND s.user_id = ?
     LIMIT 1'
);
$stmt->execute([$saleId, $uid]);
$sale = $stmt->fetch();

if (!$sale) {
    http_response_code(403);
    die('Bu dosyayı indirme yetkiniz yok.');
}

if (empty($sale['file_path'])) {
    http_response_code(404);
    die('Bu ürün için indirilebilir dosya bulunmuyor.');
}

/* ── Fiziksel dosyayı bul ── */
$rawPath = (string)($sale['file_path'] ?? '');
if ($rawPath === '' || strpos($rawPath, "\0") !== false) {
    http_response_code(404);
    die('Dosya sunucuda bulunamadı.');
}
$physicalPath = realpath(ROOT_PATH . $rawPath);
$baseDir = realpath(ROOT_PATH . '/uploads');
if ($physicalPath === false || $baseDir === false || strncmp($physicalPath, $baseDir . DIRECTORY_SEPARATOR, strlen($baseDir) + 1) !== 0) {
    http_response_code(404);
    die('Dosya sunucuda bulunamadı.');
}

if (!file_exists($physicalPath) || !is_file($physicalPath)) {
    http_response_code(404);
    die('Dosya sunucuda bulunamadı. Lütfen destek ekibiyle iletişime geçin.');
}

/* ── MIME türünü tespit et ── */
$finfo    = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $physicalPath) ?: 'application/octet-stream';
finfo_close($finfo);

/* ── Güvenli dosya adı: gerçek yolu gizle ── */
$ext = strtolower((string)pathinfo($physicalPath, PATHINFO_EXTENSION));
$ext = preg_replace('/[^a-z0-9]/', '', $ext) ?? '';
$lic = preg_replace('/[^a-zA-Z0-9_\-]/', '_', (string)($sale['license_key'] ?? ''));
$safeFileName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', (string)$sale['name'])
              . ($lic !== '' ? '_' . $lic : '')
              . ($ext !== '' ? '.' . $ext : '');
$safeFileName = str_replace(['"', "\r", "\n"], '', $safeFileName);

/* ── Force download header'ları ── */
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $safeFileName . '"');
$dlSize = filesize($physicalPath);
if ($dlSize === false) {
    http_response_code(404);
    die('Dosya sunucuda bulunamadı.');
}
header('Content-Length: ' . $dlSize);
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
header('X-Content-Type-Options: nosniff');

/* ── Dosyayı oku ve gönder (bellek dostu) ── */
$fp = fopen($physicalPath, 'rb');
if ($fp === false) {
    http_response_code(404);
    die('Dosya sunucuda bulunamadı.');
}
while (!feof($fp)) {
    echo fread($fp, 8192);
    flush();
}
fclose($fp);
exit;
