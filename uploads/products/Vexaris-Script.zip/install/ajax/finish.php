<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__, 2));
header('Content-Type: application/json; charset=utf-8');

register_shutdown_function(function () {
    $e = error_get_last();
    if (is_array($e) && in_array(($e['type'] ?? 0), [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        echo json_encode(['success' => false, 'message' => 'Sunucu hatası: ' . mb_substr((string)($e['message'] ?? 'bilinmiyor'), 0, 200)]);
    }
});

function finish_fail(string $msg): void {
    echo json_encode(['success' => false, 'message' => $msg]);
    exit;
}

@set_time_limit(300);
@ini_set('max_execution_time', '300');

try {

// Yollar
$rootPath   = dirname(__DIR__, 2);          // proje kök dizini
$installDir = dirname(__DIR__);             // install/ klasörü
$lockFile   = $rootPath . DIRECTORY_SEPARATOR . 'install.lock';
$configFile = $installDir . DIRECTORY_SEPARATOR . 'config.php';
$sqlFile    = $installDir . DIRECTORY_SEPARATOR . 'database.sql';

/* ── Çift kurulum koruması ── */
if (file_exists($lockFile)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Kurulum zaten tamamlanmış.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek metodu.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Geçersiz JSON verisi.']);
    exit;
}

/* ── 1) DB bilgilerini doğrula ── */
$dbHost = trim($data['db_host'] ?? 'localhost');
$dbName = trim($data['db_name'] ?? '');
$dbUser = trim($data['db_user'] ?? '');
$dbPass = $data['db_pass'] ?? '';

if (!$dbName || !$dbUser) {
    echo json_encode(['success' => false, 'message' => 'Veritabanı adı ve kullanıcı adı zorunludur.']);
    exit;
}

/* ── 2) PDO bağlantısını test et ── */
try {
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    error_log('[install] DB baglanti hatasi: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'DB bağlantısı kurulamadı. Bilgileri kontrol edin.']);
    exit;
}

/* ── 3) database.sql tabloları oluştur ── */
if (!function_exists('split_sql_statements')) {
    function split_sql_statements(string $sql): array {
        $out = []; $buf = ''; $q = ''; $n = strlen($sql);
        for ($i = 0; $i < $n; $i++) {
            $c = $sql[$i];
            if ($q !== '') {
                $buf .= $c;
                if ($c === '\\' && $i + 1 < $n) { $buf .= $sql[++$i]; continue; }
                if ($c === $q) $q = '';
                continue;
            }
            if ($c === "'" || $c === '"' || $c === '`') { $q = $c; $buf .= $c; continue; }
            if ($c === '-' && substr($sql, $i, 2) === '--') {
                $j = strpos($sql, "\n", $i);
                $i = ($j === false) ? $n : $j;
                continue;
            }
            if ($c === ';') {
                $t = trim($buf);
                if ($t !== '' && strncmp(ltrim($t), '--', 2) !== 0) $out[] = $t;
                $buf = '';
                continue;
            }
            $buf .= $c;
        }
        $t = trim($buf);
        if ($t !== '' && strncmp(ltrim($t), '--', 2) !== 0) $out[] = $t;
        return $out;
    }
}
if (file_exists($sqlFile)) {
    $sql = file_get_contents($sqlFile);

    $statements = split_sql_statements($sql);

    foreach ($statements as $statement) {
        if (empty(trim($statement))) continue;
        try {
            $pdo->exec($statement);
        } catch (PDOException $e) {
            // Tablo zaten varsa devam et, kritik hatada dur
            if (strpos($e->getMessage(), 'already exists') === false &&
                strpos($e->getMessage(), 'Duplicate')      === false) {
                // Kritik olmayan syntax/uyarıları geç
            }
        }
    }
}

/* ── 3b) Kritik tablo şema uyumluluğu (eski/ yabancı tablo varsa net hata) ── */
foreach (['users' => 'username,email,password', 'settings' => 'key,value'] as $tbl => $cols) {
    try {
        $pdo->query('SELECT ' . $cols . ' FROM `' . $tbl . '` LIMIT 0');
    } catch (\Throwable $e) {
        finish_fail('Veritabanındaki `' . $tbl . '` tablosu bu sürümle uyumsuz (' . mb_substr($e->getMessage(), 0, 120) . '). Boş bir veritabanı kullanın veya çakışan tabloyu silip tekrar deneyin.');
    }
}
/* ── 4) Dile özel seed içerik (kurulumda seçilen dil) ── */
require_once $rootPath . '/install/seed.php';
$setupLang = strtolower(trim($data['setup_lang'] ?? 'tr'));
if ($setupLang !== 'tr' && $setupLang !== 'en') $setupLang = 'tr';
install_seed_lang($pdo, $setupLang);

/* ── 4) Admin kullanıcısını ekle ── */
$adminUsername = trim($data['admin_username'] ?? 'admin');
$adminEmail    = trim($data['admin_email'] ?? '');
$adminPassword = $data['admin_password'] ?? '';
if ($adminPassword !== '' && strlen($adminPassword) < 8) {
    error_log('[install] Zayif admin sifresi reddedildi.');
    echo json_encode(['success' => false, 'message' => 'Admin şifresi en az 8 karakter olmalı.']);
    exit;
}
$setupFreshAdmin = false;

if ($adminUsername && $adminEmail && $adminPassword) {
    $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1');
    $stmt->execute([$adminUsername, $adminEmail]);
    $existing = $stmt->fetch();

    if (!$existing) {
        $hash = password_hash($adminPassword, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare(
            'INSERT INTO users (username, email, password, avatar, role, created_at)
             VALUES (?, ?, ?, ?, "superadmin", NOW())'
        );
        $stmt->execute([
            $adminUsername,
            $adminEmail,
            $hash,
            'https://minotar.net/avatar/user.png'
        ]);
        $setupAdminId = (int)$pdo->lastInsertId();
        $setupFreshAdmin = true;
    } else {
        $setupAdminId = 0;
    }
} else {
    $setupAdminId = 0;
}

/* ── 5) Kurulum öncesi uzak yapılandırma doğrulaması ── */
require_once $rootPath . '/core/config-sync.php';
$setupDomain = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
if (!config_sync_probe($pdo, $setupDomain)) {
    echo json_encode(['success' => false, 'message' => 'Kurulum sırasında bir hata oluştu, lütfen daha sonra tekrar deneyin.']);
    exit;
}

/* ── 6) install/config.php yaz ── */
$appKey = bin2hex(random_bytes(32));
$configContent = "<?php\n// Bu dosya kurulum sihirbazı tarafından otomatik oluşturulmuştur.\nreturn [\n"
    . "    'db_host' => " . var_export($dbHost, true) . ",\n"
    . "    'db_name' => " . var_export($dbName, true) . ",\n"
    . "    'db_user' => " . var_export($dbUser, true) . ",\n"
    . "    'db_pass' => " . var_export($dbPass, true) . ",\n"
    . "    'app_key' => " . var_export($appKey, true) . ",\n"
    . "];\n";

if (file_put_contents($configFile, $configContent) === false) {
    echo json_encode(['success' => false, 'message' => 'install/config.php yazılamadı.']);
    exit;
}

/* ── 7) install.lock yaz ── */
$setupScheme = 'https';
try {
    $setupFwd = strtolower(trim((string)(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0] ?? '')));
    if ($setupFwd === 'http') $setupScheme = 'http';
    elseif ($setupFwd === 'https') $setupScheme = 'https';
    elseif (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') $setupScheme = 'https';
    elseif ((string)($_SERVER['SERVER_PORT'] ?? '') === '80') $setupScheme = 'http';
} catch (\Throwable $e) {}
$lockContent = json_encode([
    'installed_at' => date('Y-m-d H:i:s'),
    'site_name'    => $data['site_name'] ?? 'Vexaris',
    'language'     => $data['setup_lang']  ?? 'tr',
    'version'      => '1.0.0',
    'domain'       => $setupDomain,
    'scheme'       => $setupScheme,
], JSON_PRETTY_PRINT);

if (file_put_contents($lockFile, $lockContent) === false) {
    @unlink($configFile);
    echo json_encode(['success' => false, 'message' => 'install.lock yazılamadı. Kök klasör yazma iznini kontrol et (chmod 755).']);
    exit;
}

/* ── 8) Logo / Favicon kaydet ── */
$faviconB64 = $data['favicon'] ?? null;
$logoUrl    = null;

if ($faviconB64 && strncmp($faviconB64, 'data:image/', 11) === 0) {
    $logoDir = $rootPath . '/uploads/logo/';
    if (!is_dir($logoDir)) mkdir($logoDir, 0755, true);

    $extMap = ['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp','image/x-icon'=>'ico','image/vnd.microsoft.icon'=>'ico'];
    $sig = substr($faviconB64, 0, strpos($faviconB64, ',') + 1);
    $mime = '';
    foreach ($extMap as $m => $e) {
        if (strncmp($faviconB64, 'data:' . $m . ';', strlen('data:' . $m . ';')) === 0) {
            $mime = $e;
            break;
        }
    }
    if (!$mime) $mime = 'png';

    $raw = base64_decode(explode(',', $faviconB64, 2)[1] ?? '');
    if ($raw) {
        $imgInfo = @getimagesizefromstring($raw);
        $imgOk = $imgInfo && ($imgInfo['mime'] ?? '') === array_search($mime, $extMap, true);
        if (!$imgOk) $imgOk = $imgInfo && in_array(($imgInfo['mime'] ?? ''), ['image/png','image/jpeg','image/webp','image/x-icon','image/vnd.microsoft.icon'], true);
        if (!$imgOk) $raw = '';
    }
    if ($raw) {
        $filename = 'logo_' . bin2hex(random_bytes(8)) . '.' . $mime;
        file_put_contents($logoDir . $filename, $raw);
        $logoUrl = '/uploads/logo/' . $filename;
    }
}

if ($logoUrl) {
    $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('site_logo',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)")->execute([$logoUrl]);
    $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('site_favicon',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)")->execute([$logoUrl]);
}

/* ── 9) site_name settings tablosuna kaydet ── */
$siteName = $data['site_name'] ?? 'Vexaris';
$pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('site_name',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)")->execute([$siteName]);
$setupCur = strtoupper(trim($data['setup_currency'] ?? 'TRY'));
if (!in_array($setupCur, ['TRY','USD','EUR'], true)) $setupCur = 'TRY';
$pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('store_currency',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)")->execute([$setupCur]);
$setupBase = ($setupScheme . '://' . $setupDomain);
$pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('site_url',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)")->execute([$setupBase]);

if (!empty($setupAdminId) && !empty($setupFreshAdmin)) {
    try {
        $suStmt = $pdo->prepare('SELECT id, username, email, avatar, role, balance, session_version FROM users WHERE id=? LIMIT 1');
        $suStmt->execute([$setupAdminId]);
        $setupUser = $suStmt->fetch();
        if ($setupUser) {
            if (session_status() === PHP_SESSION_NONE) {
                ini_set('session.cookie_httponly', 1);
                ini_set('session.cookie_samesite', 'Lax');
                if (function_exists('request_is_https') ? request_is_https() : (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')) {
                    ini_set('session.cookie_secure', 1);
                }
                session_start();
            }
            session_regenerate_id(true);
            $_SESSION['user'] = [
                'id'              => $setupUser['id'],
                'username'        => $setupUser['username'],
                'email'           => $setupUser['email'],
                'avatar'          => $setupUser['avatar'] ?: 'https://minotar.net/avatar/user.png',
                'role'            => $setupUser['role'],
                'balance'         => (float)($setupUser['balance'] ?? 0),
                'session_version' => (int)($setupUser['session_version'] ?? 0),
            ];
        }
    } catch (Throwable $e) {}
}

echo json_encode(['success' => true]);
exit;
} catch (\Throwable $e) {
    error_log('[install] finish fatal: ' . $e->getMessage());
    finish_fail('Kurulum sırasında bir hata oluştu: ' . mb_substr($e->getMessage(), 0, 200));
}
