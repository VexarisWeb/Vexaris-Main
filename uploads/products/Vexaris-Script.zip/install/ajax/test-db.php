<?php
header('Content-Type: application/json; charset=utf-8');

$lockFile = __DIR__ . '/../../install.lock';
if (file_exists($lockFile)) {
    echo json_encode(['success' => false, 'message' => 'Kurulum tamamlanmış.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$host = trim($data['host'] ?? '');
$name = trim($data['name'] ?? '');
$user = trim($data['user'] ?? '');
$pass = $data['pass'] ?? '';

if (!$host || !$name || !$user) {
    echo json_encode(['success' => false, 'message' => 'Host, veritabanı adı ve kullanıcı adı zorunludur.']);
    exit;
}

try {
    $pdo = new PDO(
        "mysql:host={$host};dbname={$name};charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE        => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT        => 5,   // 5 saniye timeout
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4",
        ]
    );

    // MySQL versiyonunu al — bağlantının gerçekten çalıştığını doğrular
    $version = $pdo->query('SELECT VERSION()')->fetchColumn();

    echo json_encode([
        'success' => true,
        'message' => 'Bağlantı başarılı! MySQL ' . $version,
    ]);

} catch (PDOException $e) {
    $code = $e->getCode();
    $raw  = $e->getMessage();

    // Kullanıcı dostu hata açıklamaları
    if ($code === 2002 || strpos($raw, 'timed out') !== false || strpos($raw, 'Connection refused') !== false) {
        $friendly = "Host adresine ulaşılamadı ({$host}). Kontrol edilecekler:\n"
                  . "• DB Host alanını 'localhost' veya '127.0.0.1' olarak dene\n"
                  . "• Hosting sağlayıcının verdiği özel host adresini kullan (cPanel → MySQL Databases)";
    } elseif ($code === 1045 || strpos($raw, 'Access denied') !== false) {
        $friendly = "Kullanıcı adı veya şifre hatalı.\n"
                  . "• cPanel → MySQL Users bölümünden şifreyi kontrol et/sıfırla\n"
                  . "• Kullanıcının bu veritabanına yetkisi olduğundan emin ol";
    } elseif ($code === 1049 || strpos($raw, 'Unknown database') !== false) {
        $friendly = "'{$name}' adında bir veritabanı bulunamadı.\n"
                  . "• cPanel → MySQL Databases'ten veritabanını oluştur\n"
                  . "• Veritabanı adını doğru yazdığından emin ol (genelde önek ekli olur: user_dbname)";
    } else {
        $friendly = $raw;
    }

    echo json_encode(['success' => false, 'message' => $friendly]);
}
exit;
