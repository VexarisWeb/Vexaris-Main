var CS=1,TS=5,DBC=false,WD={},CK=[];

window.setupPickLang=function(code){
 if(code!=='tr'&&code!=='en')code='tr';
 var h=document.getElementById('setupLang');if(h)h.value=code;
 document.querySelectorAll('#setupLangCards button').forEach(function(b){
  var on=b.getAttribute('data-lang')===code;
  b.style.borderColor=on?'var(--accent-primary)':'transparent';
  b.style.background=on?'rgba(255,255,255,.04)':'rgba(255,255,255,.02)';
 });
};
window.setupPickCur=function(code){
 if(code!=='TRY'&&code!=='USD'&&code!=='EUR')code='TRY';
 var h=document.getElementById('setupCur');if(h)h.value=code;
 document.querySelectorAll('#setupCurCards button').forEach(function(b){
  var on=b.getAttribute('data-cur')===code;
  b.style.borderColor=on?'var(--accent-primary)':'transparent';
  b.style.background=on?'rgba(255,255,255,.04)':'rgba(255,255,255,.02)';
 });
};
(function(){
try{
 var ctl=new AbortController();var to=setTimeout(function(){ctl.abort()},3000);
 fetch('https://ip-api.com/json/?fields=status,countryCode',{signal:ctl.signal}).then(function(r){return r.json()}).then(function(j){
  clearTimeout(to);
  if(j&&j.status==='success'){window.setupPickLang(j.countryCode==='TR'?'tr':'en');return;}
  throw 0;
 }).catch(function(){
  clearTimeout(to);
  var bl=(navigator.language||'tr').toLowerCase();
  window.setupPickLang(bl.indexOf('tr')===0?'tr':'en');
 });
}catch(e){}
})();

(function(){
var d=document;
function q(s){return d.querySelector(s)}
function qa(s){return d.querySelectorAll(s)}

var titles={1:'Sistem Kontrolü',2:'Genel Ayarlar',3:'Veritabanı',4:'Yönetici Hesabı',5:'Tamamlandı'};
var btnN=d.getElementById('btnNext'),btnP=d.getElementById('btnPrev'),nf=d.getElementById('navFooter');
var pf=d.getElementById('progressFill'),st=d.getElementById('stepTitle'),sc=d.getElementById('stepCount');

function go(n){
 var cur=d.getElementById('step-'+CS);
 if(cur&&n!==CS){cur.classList.remove('active')}
 CS=n;
 var nxt=d.getElementById('step-'+CS);
 if(nxt){nxt.classList.add('active')}
 var pct=((CS-1)/(TS-1))*100;
 pf.style.width=pct+'%';
 st.textContent=titles[CS];
 sc.textContent='Adım '+CS+' / '+TS;
 if(CS===1){btnP.style.visibility='hidden';btnP.style.opacity='0'}else{btnP.style.visibility='visible';btnP.style.opacity='1'}
 if(CS===TS){nf.style.display='none'}else{nf.style.display='flex'}
 if(CS===3&&!DBC){btnN.disabled=true;btnN.innerHTML='<i class="fa-solid fa-plug"></i> Bağlantıyı Onayla'}else if(CS===4){btnN.innerHTML='<i class="fa-solid fa-rocket"></i> Kurulumu Tamamla';btnN.disabled=false}else{btnN.innerHTML='İleri <i class="fa-solid fa-chevron-right"></i>';btnN.disabled=false}
}

window.goStep=go;

btnN.addEventListener('click',function(){
 if(CS===3&&!DBC){d.getElementById('btnCheckDb').click();return}
 if(CS===4){finishInstall();return}
 if(CS<TS)go(CS+1);
});

btnP.addEventListener('click',function(){if(CS>1)go(CS-1)});

d.addEventListener('keydown',function(e){
 if(e.key==='Enter'){
  e.preventDefault();
  var a=d.querySelector('.step-content.active');
  if(a){
   var s=a.id.replace('step-','');
   if(s==3&&!DBC){d.getElementById('btnCheckDb').click();return}
   if(s==4){finishInstall();return}
   if(parseInt(s)<TS)go(parseInt(s)+1);
  }
 }
});

// Step 1: PHP checks
CK=window.__sysChecks||[];
CK.forEach(function(c){
 var el=d.getElementById('ck-'+c.id);
 if(!el)return;
 var nm=el.querySelector('.check-name'),ds=el.querySelector('.check-desc'),ic=el.querySelector('.check-icon');
 if(nm)nm.textContent=c.label;
 if(ds)ds.textContent=c.detail;
 if(ic){ic.innerHTML=c.pass?'<i class="fa-solid fa-check"></i>':'<i class="fa-solid fa-xmark"></i>'}
 el.className='check-item '+(c.pass?'pass':'fail');
});
var allPass=CK.length>0&&CK.every(function(c){return c.pass});
if(allPass&&d.getElementById('step-1')){d.getElementById('btnNext').disabled=false}

// Step 2: Logo upload
var fi=d.getElementById('faviconInput'),fz=d.getElementById('faviconDrop');
if(fz&&fi){
 fz.addEventListener('click',function(){fi.click()});
 fi.addEventListener('change',function(){
  var f=fi.files[0];if(!f)return;
  WD.favicon=f;
  var fn=d.getElementById('faviconName');if(fn)fn.textContent='✓ '+f.name;
  var pv=d.getElementById('faviconPreview');
  if(pv){var rd=new FileReader();rd.onload=function(e){pv.src=e.target.result;pv.style.display='block'};rd.readAsDataURL(f)}
 });
 ['dragenter','dragover'].forEach(function(e){fz.addEventListener(e,function(ev){ev.preventDefault();fz.classList.add('dragover')})});
 ['dragleave','drop'].forEach(function(e){fz.addEventListener(e,function(){fz.classList.remove('dragover')})});
 fz.addEventListener('drop',function(e){
  e.preventDefault();var f=e.dataTransfer.files[0];if(!f)return;
  WD.favicon=f;
  var fn=d.getElementById('faviconName');if(fn)fn.textContent='✓ '+f.name;
  var pv=d.getElementById('faviconPreview');
  if(pv){var rd=new FileReader();rd.onload=function(ev){pv.src=ev.target.result;pv.style.display='block'};rd.readAsDataURL(f)}
 });
}

// Step 3: DB test
d.getElementById('btnCheckDb')&&d.getElementById('btnCheckDb').addEventListener('click',function(){
 var btn=this,box=d.getElementById('dbResultBox'),txt=d.getElementById('dbResultText');
 var host=d.getElementById('dbHost').value.trim(),name=d.getElementById('dbName').value.trim();
 var user=d.getElementById('dbUser').value.trim(),pass=d.getElementById('dbPass').value;
 if(!host||!name||!user){txt.innerHTML='Lütfen tüm zorunlu alanları doldurun.';box.className='db-result err';box.style.display='block';return}
 btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-circle-notch spin"></i> Bağlanıyor...';box.style.display='none';DBC=false;goStep(3);
 fetch('/install/ajax/test-db.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({host:host,name:name,user:user,pass:pass})})
 .then(function(r){return r.json()})
 .then(function(data){
   box.style.display='block';
   if(data.success){
     box.className='db-result ok';txt.innerHTML='<div class="db-result-title"><i class="fa-solid fa-circle-check"></i> Bağlantı Başarılı!</div><div class="db-result-text">'+data.message+'</div>';
     DBC=true;window.goStep(3);
  }else{
   box.className='db-result err';txt.innerHTML='<div class="db-result-title"><i class="fa-solid fa-circle-xmark"></i> Bağlantı Hatası</div><div class="db-result-text">'+data.message+'</div>';
  }
 })
 .catch(function(err){box.style.display='block';box.className='db-result err';txt.innerHTML='<div class="db-result-title"><i class="fa-solid fa-circle-xmark"></i> Sunucu Hatası</div><div class="db-result-text">'+err.message+'</div>'})
 .finally(function(){btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-plug"></i> Bağlantıyı Kontrol Et'});
});

// Step 4: Password strength
function pwCheck(v){
 var bar=d.getElementById('pwBar'),lbl=d.getElementById('pwLabel');
 if(!v){bar.className='pw-bar';lbl.textContent='';return}
 var s=0;if(v.length>=8)s++;if(v.length>=12)s++;if(/[A-Z]/.test(v)&&/[a-z]/.test(v))s++;if(/[0-9]/.test(v))s++;if(/[^A-Za-z0-9]/.test(v))s++;
 var l=[{c:'weak',t:'Çok Zayıf'},{c:'weak',t:'Zayıf'},{c:'medium',t:'Orta'},{c:'good',t:'İyi'},{c:'strong',t:'Güçlü'}];
 var i=Math.min(s,l.length-1),lv=l[i];
 bar.className='pw-bar';var sp=bar.querySelectorAll('span');
 sp.forEach(function(el,idx){if(idx<=s-1)el.style.background=lv.c==='weak'?'#ef4444':lv.c==='medium'?'#f59e0b':lv.c==='good'?'#22d3ee':'#22c55e'});
 lbl.textContent=lv.t;lbl.className='pw-label '+lv.c;
}
window.pwCheck=pwCheck;
function pwMatch(){
 var p=d.getElementById('adminPass'),c=d.getElementById('adminPassConfirm'),h=d.getElementById('pwMatch');
 if(!c.value){h.textContent='';return}
 h.textContent=p.value===c.value?'✔ Şifreler eşleşiyor':'✕ Şifreler eşleşmiyor';
 h.className='pw-match '+(p.value===c.value?'ok':'no');
}
window.pwMatch=pwMatch;

// Finish
window.finishInstall=function(){
 var un=d.getElementById('adminUser').value.trim(),em=d.getElementById('adminEmail').value.trim();
 var pw=d.getElementById('adminPass').value,pc=d.getElementById('adminPassConfirm').value;
 if(!un||!em||!pw||!pc){showMsg('Lütfen tüm alanları doldurun.');return}
 if(pw!==pc){showMsg('Şifreler eşleşmiyor.');return}
 if(pw.length<8){showMsg('Şifre en az 8 karakter olmalı.');return}
 WD.admin_username=un;WD.admin_email=em;WD.admin_password=pw;
 WD.site_name=d.getElementById('siteName').value.trim()||'Vexaris';
 var sl=d.getElementById('setupLang');WD.setup_lang=(sl&&sl.value==='en')?'en':'tr';
 var sc=d.getElementById('setupCur');WD.setup_currency=(sc&&['TRY','USD','EUR'].indexOf(sc.value)!==-1)?sc.value:'TRY';
 WD.db_host=d.getElementById('dbHost').value.trim()||'localhost';
 WD.db_name=d.getElementById('dbName').value.trim();
 WD.db_user=d.getElementById('dbUser').value.trim();
 WD.db_pass=d.getElementById('dbPass').value;
 if(!WD.db_name||!WD.db_user){showMsg('Veritabanı adı ve kullanıcı adı zorunludur.');if(btn){btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-rocket"></i> Kurulumu Tamamla'}return}
 var btn=d.getElementById('btnNext');
 if(btn){btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-circle-notch spin"></i> Kuruluyor...'}
 var sd=function(){
  fetch('/install/ajax/finish.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(WD)})
  .then(function(r){return r.json()})
  .then(function(data){
   if(data.success){goStep(5);pf.style.width='100%'}else{showMsg('Kurulum hatası: '+data.message);if(btn){btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-rocket"></i> Kurulumu Tamamla'}}
  })
  .catch(function(err){showMsg('Sunucu hatası: '+err.message);if(btn){btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-rocket"></i> Kurulumu Tamamla'}})
 };
 if(WD.favicon instanceof File){
  var rd=new FileReader();
  rd.onload=function(e){WD.favicon=e.target.result;sd()};
  rd.onerror=function(){WD.favicon=null;sd()};
  rd.readAsDataURL(WD.favicon)
 }else{WD.favicon=null;sd()}
};
function showMsg(m){
 var el=d.getElementById('finishMsg');
 if(!el){el=d.createElement('div');el.id='finishMsg';el.style.cssText='position:fixed;top:20px;left:50%;transform:translateX(-50%);background:rgba(239,68,68,0.95);color:#fff;padding:12px 24px;border-radius:12px;font-weight:700;font-size:13px;z-index:9999;box-shadow:0 8px 24px rgba(0,0,0,0.4);transition:opacity 0.3s';d.body.appendChild(el)}
 el.textContent=m;el.style.opacity='1';
 setTimeout(function(){el.style.opacity='0'},4000)
}

go(1);
})();
