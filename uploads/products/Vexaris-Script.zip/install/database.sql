SET NAMES utf8mb4;

SET FOREIGN_KEY_CHECKS = 0;



CREATE TABLE IF NOT EXISTS `users` (

  `id`         INT UNSIGNED    NOT NULL AUTO_INCREMENT,

  `username`   VARCHAR(32)     NOT NULL,

  `email`      VARCHAR(255)    NOT NULL,

  `password`   VARCHAR(255)    NOT NULL,

  `avatar`     VARCHAR(512)    NOT NULL DEFAULT 'https://minotar.net/avatar/user.png',

  `role`       VARCHAR(30)     NOT NULL DEFAULT 'user',

  `balance`           DECIMAL(12,2)   NOT NULL DEFAULT 0.00,

  `cookie_consent`    TINYINT(1)      NOT NULL DEFAULT 0,

  `cookie_pref`       VARCHAR(10)     NOT NULL DEFAULT 'pending',

  `email_verified`    TINYINT(1)      NOT NULL DEFAULT 0,

  `oauth_google_id`    VARCHAR(255)    DEFAULT NULL,

  `oauth_discord_id`   VARCHAR(255)    DEFAULT NULL,

  `oauth_microsoft_id` VARCHAR(255)    DEFAULT NULL,

  `oauth_github_id`    VARCHAR(255)    DEFAULT NULL,

  `session_version`    INT UNSIGNED    NOT NULL DEFAULT 0,

  `created_at`         DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_users_username`   (`username`),

  UNIQUE KEY `uq_users_email`      (`email`),

  KEY `idx_oauth_google`    (`oauth_google_id`),

  KEY `idx_oauth_discord`   (`oauth_discord_id`),

  KEY `idx_oauth_microsoft` (`oauth_microsoft_id`),

  KEY `idx_oauth_github`    (`oauth_github_id`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `products` (

  `id`                INT UNSIGNED  NOT NULL AUTO_INCREMENT,

  `name`              VARCHAR(120)  NOT NULL,

  `slug`              VARCHAR(140)  NOT NULL DEFAULT '',

  `short_description` VARCHAR(300)  DEFAULT NULL,

  `user_notice`       TEXT,

  `description`       TEXT,

  `price`             DECIMAL(10,2) NOT NULL DEFAULT 0.00,

  `discount_percent`  TINYINT UNSIGNED NOT NULL DEFAULT 0,

  `stock_type`        VARCHAR(10)   NOT NULL DEFAULT 'unlimited',

  `stock`             INT UNSIGNED  NOT NULL DEFAULT 0,

  `total_stock`       INT UNSIGNED  NOT NULL DEFAULT 0,

  `version`           VARCHAR(20)   NOT NULL DEFAULT '1.0.0',

  `download_link`     VARCHAR(512)  DEFAULT NULL,

  `category`          VARCHAR(60)   DEFAULT NULL,

  `image_url`         VARCHAR(512)  DEFAULT NULL,

  `digital_file`      VARCHAR(512)  DEFAULT NULL,

  `file_path`         VARCHAR(512)  DEFAULT NULL,

  `license_prefix`    VARCHAR(20)   DEFAULT NULL,

  `is_active`         TINYINT(1)    NOT NULL DEFAULT 1,

  `status`            ENUM('active','draft','hidden') NOT NULL DEFAULT 'draft',

  `is_hidden`         TINYINT(1)    NOT NULL DEFAULT 0,

  `created_at`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_products_slug`  (`slug`),

  KEY `idx_products_status`      (`status`),

  KEY `idx_products_category`    (`category`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `licenses` (

  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `product_id`  INT UNSIGNED NOT NULL,

  `user_id`     INT UNSIGNED NOT NULL,

  `license_key` VARCHAR(64)  NOT NULL,

  `ip_address`  VARCHAR(45)  DEFAULT NULL,

  `discord_id`  VARCHAR(32)  DEFAULT NULL,

  `status`      ENUM('active','suspended') NOT NULL DEFAULT 'active',

  `expires_at`  DATETIME     DEFAULT NULL,

  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_license_key`    (`license_key`),

  KEY `idx_licenses_user`        (`user_id`),

  KEY `idx_licenses_product`     (`product_id`),

  CONSTRAINT `fk_licenses_product`

    FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,

  CONSTRAINT `fk_licenses_user`

    FOREIGN KEY (`user_id`)    REFERENCES `users`    (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `cart` (

  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `user_id`    INT UNSIGNED NOT NULL,

  `product_id` INT UNSIGNED NOT NULL,

  `quantity`   INT UNSIGNED NOT NULL DEFAULT 1,

  `added_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_cart_user_product` (`user_id`,`product_id`),

  KEY `idx_cart_user` (`user_id`),

  CONSTRAINT `fk_cart_user`    FOREIGN KEY (`user_id`)    REFERENCES `users`    (`id`) ON DELETE CASCADE,

  CONSTRAINT `fk_cart_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `sales` (

  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,

  `user_id`      INT UNSIGNED  NOT NULL,

  `product_id`   INT UNSIGNED  NOT NULL,

  `price_paid`   DECIMAL(12,2) NOT NULL,

  `currency`     VARCHAR(4) NOT NULL DEFAULT 'TRY',

  `license_key`  TEXT,

  `purchased_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_sales_user`    (`user_id`),

  KEY `idx_sales_product` (`product_id`),

  KEY `idx_sales_purchased` (`purchased_at`),

  CONSTRAINT `fk_sales_user`    FOREIGN KEY (`user_id`)    REFERENCES `users`    (`id`) ON DELETE CASCADE,

  CONSTRAINT `fk_sales_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `product_stocks` (

  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `product_id`   INT UNSIGNED NOT NULL,

  `content`      TEXT         NOT NULL,

  `used`         TINYINT(1)   NOT NULL DEFAULT 0,

  `used_by_user` INT UNSIGNED DEFAULT NULL,

  `used_at`      DATETIME     DEFAULT NULL,

  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_ps_product_used` (`product_id`,`used`),

  CONSTRAINT `fk_ps_product`

    FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `remember_tokens` (

  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `user_id`      INT UNSIGNED NOT NULL,

  `token_hash`   VARCHAR(64)  NOT NULL,

  `expires_at`   DATETIME     NOT NULL,

  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_token_hash` (`token_hash`),

  KEY `idx_rt_user` (`user_id`),

  CONSTRAINT `fk_rt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mail_templates` (

  `id`           INT               NOT NULL AUTO_INCREMENT,

  `slug`         VARCHAR(64)       NOT NULL,

  `subject`      VARCHAR(255)      NOT NULL,

  `header_title` VARCHAR(160)      NOT NULL DEFAULT '',

  `body_html`    MEDIUMTEXT        NOT NULL,

  `accent_color` VARCHAR(7)        DEFAULT '#4f46e5',

  `logo_url`     VARCHAR(255)      DEFAULT NULL,

  `updated_at`   DATETIME          DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_mt_slug` (`slug`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `password_resets` (

  `id`         INT            NOT NULL AUTO_INCREMENT,

  `email`      VARCHAR(255)   NOT NULL,

  `token`      VARCHAR(64)    NOT NULL,

  `expires_at` DATETIME       NOT NULL,

  `used`       TINYINT(1)     NOT NULL DEFAULT 0,

  `created_at` DATETIME       DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_pr_token` (`token`),

  KEY `idx_pr_email` (`email`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `faqs` (

  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `question`     VARCHAR(255) NOT NULL,

  `answer`       TEXT         NOT NULL,

  `sort_order`   INT          NOT NULL DEFAULT 0,

  `is_active`    TINYINT(1)   NOT NULL DEFAULT 1,

  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_faqs_sort` (`sort_order`,`id`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `comments` (

  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `product_id`   INT UNSIGNED NOT NULL,

  `user_id`      INT UNSIGNED NOT NULL,

  `comment_text` TEXT         NOT NULL,

  `rating`       TINYINT      NOT NULL DEFAULT 0,

  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_comments_product` (`product_id`),

  CONSTRAINT `fk_comments_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,

  CONSTRAINT `fk_comments_user`    FOREIGN KEY (`user_id`)    REFERENCES `users`    (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `news` (

  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `title`      VARCHAR(255) NOT NULL,

  `content`    LONGTEXT,

  `image`      VARCHAR(512) DEFAULT NULL,

  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `announcements` (

  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `title`      VARCHAR(255) NOT NULL,

  `slug`       VARCHAR(280) NOT NULL,

  `content`    TEXT         NOT NULL,

  `image_url`  VARCHAR(255) DEFAULT NULL,

  `status`     VARCHAR(20)  NOT NULL DEFAULT 'draft',

  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_announcements_slug` (`slug`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `tickets` (

  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `user_id`    INT UNSIGNED NOT NULL,

  `title`      VARCHAR(255) NOT NULL,

  `category`   VARCHAR(60)  NOT NULL DEFAULT 'Genel',

  `message`    TEXT,

  `status`     ENUM('open','replied','closed') NOT NULL DEFAULT 'open',

  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  `updated_at` DATETIME     NULL DEFAULT NULL,

  PRIMARY KEY (`id`),

  KEY `idx_tickets_user`   (`user_id`),

  KEY `idx_tickets_status` (`status`),

  CONSTRAINT `fk_tickets_user`

    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `ticket_replies` (

  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `ticket_id`  INT UNSIGNED NOT NULL,

  `user_id`    INT UNSIGNED NOT NULL,

  `is_admin`   TINYINT(1)   NOT NULL DEFAULT 0,

  `is_seen`    TINYINT(1)   NOT NULL DEFAULT 0,

  `image_url`  VARCHAR(512) DEFAULT NULL,

  `message`    TEXT         NOT NULL,

  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_reply_ticket` (`ticket_id`),

  CONSTRAINT `fk_reply_ticket`

    FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,

  CONSTRAINT `fk_reply_user`

    FOREIGN KEY (`user_id`)   REFERENCES `users`   (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `coupons` (

  `id`           INT UNSIGNED    NOT NULL AUTO_INCREMENT,

  `code`         VARCHAR(50)     NOT NULL,

  `type`         ENUM('percent','flat_tl','flat_usd','flat_eur') NOT NULL DEFAULT 'percent',

  `reward_type`  ENUM('discount','product_grant','license_grant') NOT NULL DEFAULT 'discount',

  `reward_value` DECIMAL(10,2)   NOT NULL DEFAULT 0.00,

  `grant_product_ids` TEXT NULL,

  `max_uses`     INT UNSIGNED    NOT NULL DEFAULT 1,

  `used_count`   INT UNSIGNED    NOT NULL DEFAULT 0,

  `is_active`    TINYINT(1)      NOT NULL DEFAULT 1,

  `expires_at`   TIMESTAMP       NULL DEFAULT NULL,

  `created_at`   TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_coupon_code` (`code`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `balance_log` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `user_id` INT UNSIGNED NOT NULL,

  `amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,

  `type` ENUM('payment','purchase','topup','coupon','refund','admin') NOT NULL DEFAULT 'purchase',

  `description` VARCHAR(255) DEFAULT NULL,

  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_bl_user` (`user_id`),

  KEY `idx_bl_created` (`created_at`),

  CONSTRAINT `fk_bl_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `coupon_usages` (

  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `user_id`    INT UNSIGNED NOT NULL,

  `coupon_id`  INT UNSIGNED NOT NULL,

  `used_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_usage_user_coupon` (`user_id`,`coupon_id`),

  KEY `idx_usage_coupon` (`coupon_id`),

  CONSTRAINT `fk_usage_user`   FOREIGN KEY (`user_id`)   REFERENCES `users`   (`id`) ON DELETE CASCADE,

  CONSTRAINT `fk_usage_coupon` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `product_images` (

  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `product_id`  INT UNSIGNED NOT NULL,

  `image_url`   VARCHAR(512) NOT NULL,

  `sort_order`  INT UNSIGNED NOT NULL DEFAULT 0,

  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_pi_product` (`product_id`),

  CONSTRAINT `fk_pi_product`

    FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `categories` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `name` VARCHAR(60) NOT NULL,

  `slug` VARCHAR(80) NOT NULL,

  `icon` VARCHAR(512) DEFAULT NULL,

  `description` VARCHAR(300) DEFAULT NULL,

  `sort_order` INT UNSIGNED NOT NULL DEFAULT 0,

  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_categories_slug` (`slug`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `subcategories` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `category_id` INT UNSIGNED NOT NULL,

  `name` VARCHAR(60) NOT NULL,

  `slug` VARCHAR(80) NOT NULL,

  `description` VARCHAR(300) DEFAULT NULL,

  `sort_order` INT UNSIGNED NOT NULL DEFAULT 0,

  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_subcat_category` (`category_id`),

  CONSTRAINT `fk_subcat_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `category_options` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `category_id` INT UNSIGNED NOT NULL,

  `name` VARCHAR(60) NOT NULL,

  `type` VARCHAR(20) NOT NULL DEFAULT 'text',

  `options` TEXT DEFAULT NULL,

  `required` TINYINT(1) NOT NULL DEFAULT 0,

  `sort_order` INT UNSIGNED NOT NULL DEFAULT 0,

  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_catopt_category` (`category_id`),

  CONSTRAINT `fk_catopt_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `admin_recent_pages` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `user_id` INT UNSIGNED NOT NULL,

  `page_key` VARCHAR(80) NOT NULL,

  `page_label` VARCHAR(120) NOT NULL,

  `page_url` VARCHAR(255) NOT NULL,

  `page_icon` VARCHAR(60) DEFAULT NULL,

  `viewed_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_arp_user_page` (`user_id`,`page_key`),

  KEY `idx_arp_user_viewed` (`user_id`,`viewed_at`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `settings` (

  `key`        VARCHAR(80) NOT NULL,

  `value`      TEXT,

  `updated_at` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (`key`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



INSERT IGNORE INTO `settings` (`key`, `value`) VALUES

  ('site_name',      'NexusSetups'),

  ('site_url',       ''),

  ('site_language',  'tr'),

  ('site_favicon',   ''),

  ('site_logo',      ''),

  ('active_theme',   'default'),

  ('maintenance_mode','0'),

  ('email_verify_required','0'),

  ('store_currency','TRY'),

  ('social_discord', ''),

  ('discord_widget_enabled', '1'),

  ('social_youtube', ''),

  ('social_github',  ''),

  ('social_twitter', ''),

  ('_vx_installed_version', '1.0.0'),

  ('auto_update', '0');



CREATE TABLE IF NOT EXISTS `orders` (

  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,

  `user_id`     INT UNSIGNED  NOT NULL,

  `product_id`  INT UNSIGNED  NOT NULL,

  `price`       DECIMAL(10,2) NOT NULL DEFAULT 0.00,

  `license_key` VARCHAR(255)  DEFAULT NULL,

  `status`      VARCHAR(50)   NOT NULL DEFAULT 'completed',

  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_orders_user` (`user_id`),

  KEY `idx_orders_product` (`product_id`),

  CONSTRAINT `fk_orders_user`    FOREIGN KEY (`user_id`)    REFERENCES `users`    (`id`) ON DELETE CASCADE,

  CONSTRAINT `fk_orders_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `legal_pages` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `slug` VARCHAR(60) NOT NULL,

  `title` VARCHAR(120) NOT NULL,

  `content` TEXT,

  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_legal_slug` (`slug`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT IGNORE INTO `legal_pages` (`slug`,`title`,`content`) VALUES ('cookie-policy','Çerez Politikası','# Çerez Politikası

**{site_name}** olarak gizliliğinize saygı duyuyoruz. Bu sayfa hangi çerezleri kullandığımızı ve bunları nasıl yönetebileceğinizi açıklar.

## 1. Çerez Nedir?

Çerez, ziyaretiniz sırasında tarayıcınıza kaydedilen küçük metin dosyalarıdır. Oturumunuzu hatırlamak ve güvenliğinizi sağlamak için kullanılır.

## 2. Kullandığımız Çerezler

- **Zorunlu Çerezler:** Oturum (vexaris_sess), güvenlik doğrulaması ve yük dengeleme için şarttır. Bunlar olmadan site çalışmaz.
- **Tercih Çerezleri:** Çerez tercihiniz (nx_cc_*) ve tema seçiminiz gibi ayarları hatırlar.
- **Analitik Çerezler:** Yalnızca izninizle çalışır, sayfa görüntüleme sayılarını anonim olarak toplar.
- **Beni Hatırla:** İsteğe bağlı giriş kalıcılığı (remember_token) için kullanılır.

## 3. Üçüncü Taraf Çerezleri

Ödeme adımında yönlendiğiniz ödeme kuruluşları ile spam koruması (Cloudflare Turnstile / reCAPTCHA) kendi çerezlerini kullanabilir. Bu çerezlerden ilgili kuruluşlar sorumludur.

## 4. Çerezleri Kontrol Etme

- Sitedeki çerez bandından **Tümünü Kabul Et** veya **Sadece Zorunlu** seçimini dilediğiniz zaman değiştirebilirsiniz.
- Tarayıcı ayarlarından çerezleri silebilir veya engelleyebilirsiniz. Zorunlu çerezleri engellerseniz giriş ve satın alma çalışmayabilir.

## 5. KVKK Aydınlatma

Çerezlerle işlenen veriler 6698 sayılı KVKK kapsamında korunur. Detay için Gizlilik Politikamıza bakın.');
INSERT IGNORE INTO `legal_pages` (`slug`,`title`,`content`) VALUES ('privacy-policy','Gizlilik Politikası','# Gizlilik Politikası

**{site_name}** olarak kişisel verilerinizin güvenliğine önem veriyoruz. Bu metin 6698 sayılı KVKK uyarınca aydınlatma metni niteliğindedir.

## 1. Toplanan Veriler

- **Hesap verileri:** kullanıcı adı, e-posta adresi, parola (şifreli saklanır).
- **Sipariş verileri:** satın alınan ürün, tutar, tarih ve teslim edilen lisans kayıtları.
- **Teknik kayıtlar:** IP adresi, tarayıcı bilgisi, giriş denemeleri ve hata günlükleri.
- **Destek kayıtları:** açtığınız biletler ve mesajlaşmalar.

## 2. İşleme Amaçları ve Hukuki Sebepler

Verileriniz, hesabınızı yönetmek, siparişlerinizi teslim etmek, teknik destek sağlamak ve dolandırıcılığı önlemek için işlenir (KVKK m.5: sözleşmenin kurulması ve ifası, veri sorumlusunun hukuki yükümlülüğü ve meşru menfaati).

## 3. Kart Bilgileri

Kredi kartı bilgileriniz **sunucularımıza hiçbir zaman yazılmaz**. Tüm tahsilat lisanslı ödeme kuruluşları üzerinden gerçekleşir.

## 4. Saklama Süreleri

Hesap verileri üyeliğiniz sürdükçe, sipariş ve fatura kayıtları yasal zamanaşımı süreleri boyunca saklanır. Hesabınızı kapattığınızda kişisel verileriniz anonimleştirilir veya silinir.

## 5. Paylaşım

Verileriniz pazarlama amacıyla üçüncü kişilerle paylaşılmaz. Yalnızca ödeme tahsilatı ve yasal zorunluluklar (mahkeme kararı gibi) kapsamında gerekli taraflarla paylaşılır.

## 6. Haklarınız

KVKK m.11 uyarınca verilerinize erişme, düzeltme, silme, işlenmeye itiraz etme ve zararın giderilmesini talep etme haklarına sahipsiniz. Taleplerinizi destek sistemi üzerinden iletebilirsiniz.

## 7. Güvenlik

Veriler SSL şifreleme ile taşınır, parolalar tek yönlü şifreleme ile saklanır ve yönetim paneli rol bazlı yetkilendirme ile korunur.');
INSERT IGNORE INTO `legal_pages` (`slug`,`title`,`content`) VALUES ('terms-of-service','Kullanım Şartları','# Kullanım Şartları

**{site_name}** platformunu kullanarak aşağıdaki şartları kabul etmiş sayılırsınız.

## 1. Hizmetin Kapsamı

Platform, e-pin, lisans anahtarı, e-kitap ve yazılım paketi gibi dijital ürünlerin satıldığı bir pazaryeridir. Tüm ürünler dijital olarak, anında teslim edilir.

## 2. Hesap

- Kayıt sırasında doğru bilgi vermekle yükümlüsünüz.
- Hesabınızın güvenliğinden siz sorumlusunuz, şifrenizi kimseyle paylaşmayın.
- 18 yaşından küçükler veli izni olmadan işlem yapamaz.

## 3. Lisans Kullanımı

- Satın aldığınız lisans **size özeldir**, yeniden satılamaz, kiralanamaz veya herkese açık paylaşılamaz.
- Aksi belirtilmedikçe her lisans tek kullanım / tek alıcı içindir.
- Lisansın kötüye kullanıldığı tespit edilirse erişiminiz askıya alınabilir.

## 4. Fiyat ve Ödeme

- Fiyatlar Türk Lirasıdır ve KDV dahildir.
- Ödeme anında tahsil edilir, ödeme onaylanmadan teslimat başlamaz.

## 5. Teslimat

- Ödeme onayı sonrası ürün **otomatik ve anında** hesabınıza tanımlanır.
- Teslimat gecikmesi yaşanırsa destek talebi açmanız yeterlidir.

## 6. Yasak Kullanım

Platformu dolandırıcılık, tersine mühendislikle koruma atlatma, spam veya yasa dışı amaçlarla kullanmak yasaktır. İhlalde hesap kapatılır ve ödenmiş tutarlar iade edilmez.

## 7. Sorumluluk Sınırı

Platform, mücbir sebepler ve üçüncü taraf hizmet kesintilerinden doğan zararlardan sorumlu tutulamaz. Sorumluluk, ilgili sipariş tutarıyla sınırlıdır.

## 8. Değişiklik ve Yürürlük

Bu şartlar güncellenebilir, güncel metin her zaman bu sayfada yayınlanır. Uyuşmazlıklarda Türkiye Cumhuriyeti kanunları uygulanır.');
INSERT IGNORE INTO `legal_pages` (`slug`,`title`,`content`) VALUES ('refund-policy','İade Politikası','# İade Politikası

**{site_name}** olarak müşteri memnuniyetini ön planda tutuyoruz. Dijital ürünlerin doğası gereği iade koşulları aşağıda tanımlanmıştır.

## 1. Temel İlke

Dijital teslimat ödeme onayı anında gerçekleştiği için, **kullanılmış lisans ve indirilmiş dosyalarda cayma hakkı teknik olarak uygulanamaz**. Yine de aşağıdaki durumlarda iade yapılır.

## 2. İade Koşulları

- Lisans anahtarının **hiç kullanılmamış** olması,
- Satın alma tarihinden itibaren **14 gün** içinde başvuru yapılması,
- Ürünün teknik olarak çalışmaması ve destek ekibinin sorunu **çözememesi**.

## 3. İade Süreci

1. Destek sistemi üzerinden iade talebi oluşturun.
2. Sipariş numaranızı ve iade sebebinizi yazın.
3. Ekibimiz talebi **48 saat** içinde değerlendirir.
4. Onaylanan iadeler önce **bakiyenize**, isterseniz 3 iş günü içinde ödeme yönteminize yansıtılır.

## 4. İstisnalar

- Kullanılmış veya süresi başlatılmış lisanslar iade edilmez.
- Size özel hazırlanan ürünler iade edilmez.
- Kampanyalı paketlerde kısmi iade yapılmaz, paket bütün olarak değerlendirilir.

## 5. Ödeme Kuruluşu İadeleri

Karta iade işlemleri bankanıza bağlı olarak 2-10 iş günü içinde ekstrelere yansır. Bu süre bankalardan kaynaklanır.');





CREATE TABLE IF NOT EXISTS `ticket_categories` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `name` VARCHAR(60) NOT NULL,

  `icon` VARCHAR(512) DEFAULT NULL,

  `sort_order` INT UNSIGNED NOT NULL DEFAULT 0,

  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `permissions` (

  `id`       INT UNSIGNED    NOT NULL AUTO_INCREMENT,

  `role`     VARCHAR(30)     NOT NULL,

  `resource` VARCHAR(60)     NOT NULL,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_perm_role_resource` (`role`,`resource`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `roles` (

  `slug`      VARCHAR(30)  NOT NULL,

  `name_tr`   VARCHAR(60)  NOT NULL DEFAULT '',

  `name_en`   VARCHAR(60)  NOT NULL DEFAULT '',

  `color`     VARCHAR(7)   NOT NULL DEFAULT '#818cf8',

  `icon`      VARCHAR(512) NOT NULL DEFAULT 'fa-solid fa-user',

  `rank`      INT          NOT NULL DEFAULT 0,

  `is_system` TINYINT(1)   NOT NULL DEFAULT 0,

  PRIMARY KEY (`slug`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



INSERT IGNORE INTO `roles` (`slug`,`name_tr`,`name_en`,`color`,`icon`,`rank`,`is_system`) VALUES

('superadmin','Süper Admin','Super Admin','#7c3aed','fa-solid fa-user-shield',200,1),

('admin','Admin','Admin','#f43f5e','fa-solid fa-crown',100,1),

('yonetici','Yönetici','Manager','#eab308','fa-solid fa-user-tie',30,1),

('moderator','Moderatör','Moderator','#818cf8','fa-solid fa-shield-halved',20,1),

('destek_ekibi','Destek Ekibi','Support Team','#22d3ee','fa-solid fa-headset',10,1),

('user','Üye','Member','#4ade80','fa-solid fa-user',0,1);



CREATE TABLE IF NOT EXISTS `audit_logs` (

  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `user_id`     INT UNSIGNED NOT NULL DEFAULT 0,

  `username`    VARCHAR(32)  NOT NULL DEFAULT '',

  `user_role`   VARCHAR(30)  NOT NULL DEFAULT '',

  `action`      VARCHAR(20)  NOT NULL DEFAULT 'update',

  `resource`    VARCHAR(60)  NOT NULL DEFAULT '',

  `resource_id` INT UNSIGNED NOT NULL DEFAULT 0,

  `label`       VARCHAR(255) NOT NULL DEFAULT '',

  `url`         VARCHAR(255) NOT NULL DEFAULT '',

  `ip`          VARCHAR(45)  NOT NULL DEFAULT '',

  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_al_user` (`user_id`),

  KEY `idx_al_res` (`resource`,`resource_id`),

  KEY `idx_al_time` (`created_at`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES

('superadmin','dashboard'),('superadmin','users'),('superadmin','products'),('superadmin','categories'),('superadmin','licenses'),

('superadmin','coupons'),('superadmin','themes'),('superadmin','announcements'),('superadmin','support'),('superadmin','ticket_categories'),('superadmin','settings'),

('superadmin','permissions'),('superadmin','legal'),('superadmin','ai_assistant'),

('admin','dashboard'),('admin','users'),('admin','products'),('admin','categories'),('admin','licenses'),

('admin','coupons'),('admin','themes'),('admin','announcements'),('admin','support'),('admin','ticket_categories'),('admin','settings'),

('admin','permissions'),('admin','legal'),

('yonetici','dashboard'),('yonetici','users'),('yonetici','products'),('yonetici','categories'),

('yonetici','licenses'),('yonetici','coupons'),('yonetici','themes'),('yonetici','announcements'),

('yonetici','support'),('yonetici','ticket_categories'),('yonetici','settings'),('yonetici','legal'),('yonetici','custom_pages'),

('moderator','dashboard'),('moderator','users'),('moderator','support'),('moderator','licenses'),

('destek_ekibi','dashboard'),('destek_ekibi','support'),

('admin','custom_pages'),('superadmin','custom_pages'),('superadmin','reviews'),('superadmin','references'),('superadmin','slider'),('superadmin','seo'),('superadmin','modules'),('superadmin','integrations'),('superadmin','audit-logs'),('superadmin','stats'),('superadmin','purchases'),('superadmin','discord-webhook');


CREATE TABLE IF NOT EXISTS `modules` (

  `slug`         VARCHAR(64) NOT NULL,

  `enabled`      TINYINT(1)  NOT NULL DEFAULT 0,

  `version`      VARCHAR(16) NOT NULL DEFAULT '1.0.0',

  `settings`     TEXT,

  `sidebar`      TINYINT(1)  NOT NULL DEFAULT 1,

  `installed_at` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,

  `updated_at`   DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (`slug`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES

('admin','modules'),('yonetici','modules');



CREATE TABLE IF NOT EXISTS `payment_intents` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `user_id` INT UNSIGNED NOT NULL,

  `order_id` VARCHAR(40) NOT NULL,

  `total_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,

  `currency` VARCHAR(4) NOT NULL DEFAULT 'TRY',

  `status` ENUM('pending','completed','failed','cancelled') NOT NULL DEFAULT 'pending',

  `payment_method` VARCHAR(20) NOT NULL DEFAULT 'shopier',

  `payment_id` VARCHAR(40) DEFAULT NULL,

  `items_snapshot` MEDIUMTEXT NULL,

  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_pi_order` (`order_id`),

  KEY `idx_pi_user` (`user_id`),

  KEY `idx_pi_status` (`status`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `license_check_attempts` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `ip` VARCHAR(45) NOT NULL,

  `attempted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_lca_ip` (`ip`),

  KEY `idx_lca_time` (`attempted_at`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `license_nonces` (

  `nonce` VARCHAR(64) NOT NULL,

  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`nonce`),

  KEY `idx_ln_time` (`created_at`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `login_attempts` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `ip` VARCHAR(45) NOT NULL,

  `attempted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_la_ip` (`ip`),

  KEY `idx_la_time` (`attempted_at`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `rate_limits` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `scope` VARCHAR(40) NOT NULL,

  `ip` VARCHAR(45) NOT NULL,

  `attempted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_rl_scope_ip` (`scope`,`ip`),

  KEY `idx_rl_time` (`attempted_at`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_shopier_active','0'),('payment_shopier_title','Shopier'),('payment_shopier_currency','TRY'),('payment_shopier_priority','0'),('payment_shopier_fee','0'),('payment_shopier_pat',''),('payment_shopier_shop_slug',''),('payment_shopier_osb_username',''),('payment_shopier_osb_password','');

INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paywant_active','0'),('payment_paywant_title','Paywant'),('payment_paywant_priority','0'),('payment_paywant_fee','0'),('payment_paywant_api_key',''),('payment_paywant_api_secret','');

INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_paytr_active','1'),('payment_paytr_title','PayTR'),('payment_paytr_currency','TRY'),('payment_paytr_priority','0'),('payment_paytr_fee','0'),('payment_paytr_api_key',''),('payment_paytr_secret_key',''),('payment_paytr_merchant_id',''),('payment_paytr_merchant_key',''),('payment_paytr_merchant_salt',''),('payment_paytr_test_mode','0');

INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_iyzico_active','0'),('payment_iyzico_title','iyzico'),('payment_iyzico_currency','TRY'),('payment_iyzico_priority','0'),('payment_iyzico_fee','0'),('payment_iyzico_api_key',''),('payment_iyzico_secret_key',''),('payment_iyzico_test_mode','0');

INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('payment_stripe_active','0'),('payment_stripe_title','Stripe'),('payment_stripe_currency','TRY'),('payment_stripe_priority','0'),('payment_stripe_fee','0'),('payment_stripe_api_key',''),('payment_stripe_webhook_secret',''),('payment_stripe_test_mode','0');

INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('int_discord_webhook_url',''),('int_discord_register','0'),('int_discord_order','0'),('int_discord_topup','0'),('int_discord_review','0');



CREATE TABLE IF NOT EXISTS `custom_pages` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `slug` VARCHAR(140) NOT NULL,

  `title` VARCHAR(120) NOT NULL,

  `meta_description` VARCHAR(300) DEFAULT NULL,

  `content` MEDIUMTEXT,

  `status` ENUM('published','draft') NOT NULL DEFAULT 'published',

  `page_type` ENUM('blog','html') NOT NULL DEFAULT 'blog',

  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `uq_custom_pages_slug` (`slug`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `custom_page_views` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `page_id` INT UNSIGNED NOT NULL,

  `session_key` VARCHAR(80) NOT NULL,

  `user_id` INT UNSIGNED DEFAULT NULL,

  `ip` VARCHAR(45) DEFAULT NULL,

  `duration_sec` INT UNSIGNED NOT NULL DEFAULT 0,

  `entered_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  `left_at` DATETIME DEFAULT NULL,

  PRIMARY KEY (`id`),

  KEY `idx_cpv_page` (`page_id`),

  KEY `idx_cpv_session` (`session_key`),

  CONSTRAINT `fk_cpv_page` FOREIGN KEY (`page_id`) REFERENCES `custom_pages` (`id`) ON DELETE CASCADE,

  CONSTRAINT `fk_cpv_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `references` (

  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,

  `name` VARCHAR(120) NOT NULL,

  `title` VARCHAR(160) NOT NULL DEFAULT '',

  `photo_url` VARCHAR(512) DEFAULT NULL,

  `rating` TINYINT NOT NULL DEFAULT 5,

  `message` TEXT,

  `sort_order` INT UNSIGNED NOT NULL DEFAULT 0,

  `is_active` TINYINT(1) NOT NULL DEFAULT 1,

  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  KEY `idx_ref_active` (`is_active`,`sort_order`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('references_mode','grid');

INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('references_autoplay','0');

INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES ('admin','references'),('yonetici','references');

INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES ('admin','audit-logs'),('yonetici','audit-logs');

INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('ai_system_prompt','');

INSERT IGNORE INTO `permissions` (`role`,`resource`) VALUES ('admin','ai_assistant'),('yonetici','ai_assistant');



CREATE TABLE IF NOT EXISTS `email_verifications` (

  `id` INT AUTO_INCREMENT PRIMARY KEY,

  `email` VARCHAR(255) NOT NULL,

  `token` VARCHAR(64) NOT NULL,

  `expires_at` DATETIME NOT NULL,

  `used` TINYINT(1) NOT NULL DEFAULT 0,

  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY `uq_ev_token` (`token`),

  KEY `idx_ev_email` (`email`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `sliders` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `content`    MEDIUMTEXT   NOT NULL,
  `bg_color`   VARCHAR(7)   NOT NULL DEFAULT '#6366f1',
  `link_url`   VARCHAR(512) DEFAULT NULL,
  `marquee`    TINYINT(1)   NOT NULL DEFAULT 0,
  `speed`      INT UNSIGNED NOT NULL DEFAULT 20,
  `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
  `sort_order` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sliders_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `product_versions` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` INT UNSIGNED NOT NULL,
  `version`    VARCHAR(20)  NOT NULL DEFAULT '',
  `summary`    VARCHAR(255) NOT NULL DEFAULT '',
  `changelog`  MEDIUMTEXT,
  `has_file`   TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pv_product` (`product_id`,`id`),
  CONSTRAINT `fk_pv_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `product_update_reads` (
  `user_id`              INT UNSIGNED NOT NULL,
  `product_id`           INT UNSIGNED NOT NULL,
  `last_seen_version_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at`           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`product_id`),
  CONSTRAINT `fk_pur_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `theme_settings` (
  `theme`                VARCHAR(32)  NOT NULL,
  `setting_key`          VARCHAR(80)  NOT NULL,
  `setting_value`        MEDIUMTEXT,
  `updated_at`           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`theme`,`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

