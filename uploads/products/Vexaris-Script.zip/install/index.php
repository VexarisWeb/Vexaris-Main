<?php
if (file_exists(dirname(__DIR__) . '/install.lock')) {
    header('Location: /');
    exit;
}
$sysChecks = [];
$rootW = is_writable(dirname(__DIR__)) && is_writable(dirname(__DIR__) . '/install');
$phpVer = PHP_VERSION;
$phpOk = PHP_VERSION_ID >= 80000;
$pdoOk = extension_loaded('pdo') && extension_loaded('pdo_mysql');
$curlOk = extension_loaded('curl');
$sysChecks[] = ['id'=>'php','label'=>'PHP Sürümü','detail'=>"Mevcut: PHP $phpVer (Gereksinim: 8.0+)",'pass'=>$phpOk];
$sysChecks[] = ['id'=>'pdo','label'=>'PDO & MySQL','detail'=>'Veritabanı bağlantısı için gerekli','pass'=>$pdoOk];
$sysChecks[] = ['id'=>'curl','label'=>'cURL','detail'=>'API ve uzak kaynak erişimi için gerekli','pass'=>$curlOk];
$sysChecks[] = ['id'=>'writable','label'=>'Dosya İzinleri','detail'=>'Kök dizin ve install/ klasörü yazılabilir','pass'=>$rootW];
$allPass = $phpOk && $pdoOk && $curlOk && $rootW;
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Vexaris — Kurulum Sihirbazı</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="/install/assets/style.css">
</head>
<body>
<div class="setup-modal">
  <div class="modal-header">
    <div class="modal-title-wrap">
      <div class="modal-title-icon"><i class="fa-solid fa-cube"></i></div>
      <div>
        <h2 class="modal-title">Vexaris</h2>
        <div class="modal-subtitle">E-Ticaret Script Kurulumu</div>
      </div>
    </div>
  </div>
  <div class="progress-container">
    <div class="progress-header">
      <span id="stepTitle">Sistem Kontrolü</span>
      <span id="stepCount">Adım 1 / 5</span>
    </div>
    <div class="progress-track"><div class="progress-fill" id="progressFill"></div></div>
  </div>
  <div class="steps-wrapper">

    <!-- STEP 1 -->
    <div class="step-content active" id="step-1">
      <div class="step-head">
        <div class="step-head-title">Sistem Gereksinimleri</div>
        <div class="step-head-desc">Sunucunuzun platformu çalıştırmak için gereken koşulları sağladığından emin olalım.</div>
      </div>
      <div class="check-list">
        <?php foreach ($sysChecks as $c): ?>
        <div class="check-item <?= $c['pass']?'pass':'fail' ?>" id="ck-<?= $c['id'] ?>">
          <div class="check-info">
            <span class="check-name"><?= $c['label'] ?></span>
            <span class="check-desc"><?= $c['detail'] ?></span>
          </div>
          <div class="check-icon"><i class="fa-solid fa-<?= $c['pass']?'check':'xmark' ?>"></i></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- STEP 2 -->
    <div class="step-content" id="step-2">
      <div class="step-head">
        <div class="step-head-title">Genel Ayarlar</div>
        <div class="step-head-desc">Platformun temel kimliğini belirle. Bu bilgiler daha sonra değiştirilebilir.</div>
      </div>
      <div class="form-group">
        <label class="form-label"><i class="fa-solid fa-store"></i> Mağaza Adı</label>
        <input type="text" class="form-control" id="siteName" placeholder="Vexaris" value="Vexaris" maxlength="80">
      </div>
      <div class="form-group">
        <label class="form-label"><i class="fa-solid fa-language"></i> Site Dili</label>
        <input type="hidden" id="setupLang" value="tr">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;" id="setupLangCards">
          <button type="button" data-lang="tr" onclick="setupPickLang('tr')" style="display:flex;align-items:center;gap:12px;padding:14px;border-radius:12px;border:2px solid var(--accent-primary);background:rgba(255,255,255,.04);color:inherit;font-family:inherit;cursor:pointer;text-align:left;">
            <img src="/assets/images/flags/tr.svg" alt="TR" style="width:38px;height:26px;border-radius:4px;object-fit:cover;">
            <span><b style="display:block;">Türkçe</b><small style="opacity:.65;" id="setupLangHintTr">Varsayılan</small></span>
          </button>
          <button type="button" data-lang="en" onclick="setupPickLang('en')" style="display:flex;align-items:center;gap:12px;padding:14px;border-radius:12px;border:2px solid transparent;background:rgba(255,255,255,.02);color:inherit;font-family:inherit;cursor:pointer;text-align:left;">
            <img src="/assets/images/flags/en.svg" alt="EN" style="width:38px;height:26px;border-radius:4px;object-fit:cover;">
            <span><b style="display:block;">English</b><small style="opacity:.65;" id="setupLangHintEn">Default</small></span>
          </button>
        </div>
        <p class="file-drop-hint" id="setupLangNote">İçerikler (yasal sayfalar, kategoriler) seçilen dilde kurulur. Sonradan değiştirilebilir.</p>
      </div>
      <div class="form-group">
        <label class="form-label"><i class="fa-solid fa-coins"></i> Mağaza Para Birimi</label>
        <input type="hidden" id="setupCur" value="TRY">
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;" id="setupCurCards">
          <button type="button" data-cur="TRY" onclick="setupPickCur('TRY')" style="display:flex;align-items:center;gap:12px;padding:14px;border-radius:12px;border:2px solid var(--accent-primary);background:rgba(255,255,255,.04);color:inherit;font-family:inherit;cursor:pointer;text-align:left;">
            <span style="width:38px;height:26px;border-radius:4px;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:15px;background:rgba(255,255,255,.07);">₺</span>
            <span><b style="display:block;">Türk Lirası</b><small style="opacity:.65;">TRY</small></span>
          </button>
          <button type="button" data-cur="USD" onclick="setupPickCur('USD')" style="display:flex;align-items:center;gap:12px;padding:14px;border-radius:12px;border:2px solid transparent;background:rgba(255,255,255,.02);color:inherit;font-family:inherit;cursor:pointer;text-align:left;">
            <span style="width:38px;height:26px;border-radius:4px;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:15px;background:rgba(255,255,255,.07);">$</span>
            <span><b style="display:block;">ABD Doları</b><small style="opacity:.65;">USD</small></span>
          </button>
          <button type="button" data-cur="EUR" onclick="setupPickCur('EUR')" style="display:flex;align-items:center;gap:12px;padding:14px;border-radius:12px;border:2px solid transparent;background:rgba(255,255,255,.02);color:inherit;font-family:inherit;cursor:pointer;text-align:left;">
            <span style="width:38px;height:26px;border-radius:4px;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:15px;background:rgba(255,255,255,.07);">€</span>
            <span><b style="display:block;">Euro</b><small style="opacity:.65;">EUR</small></span>
          </button>
        </div>
        <p class="file-drop-hint">Fiyatlar bu birimde girilir ve tahsil edilir. Sonradan değiştirilebilir.</p>
      </div>
      <div class="form-group">
        <label class="form-label"><i class="fa-regular fa-image"></i> Site Logosu <span style="color:var(--text-muted);font-weight:400;font-size:11px;">(isteğe bağlı)</span></label>
        <div class="file-drop" id="faviconDrop">
          <input type="file" id="faviconInput" accept=".ico,.png,.jpg,.jpeg,.webp,.svg">
          <div class="file-drop-icon"><i class="fa-regular fa-image"></i></div>
          <p class="file-drop-text">Logo seç veya sürükle bırak</p>
          <p class="file-drop-hint">.png, .jpg, .webp, .svg, .ico — maks. 512 KB</p>
          <p class="file-drop-name" id="faviconName"></p>
          <img id="faviconPreview" alt="logo preview">
        </div>
      </div>
    </div>

    <!-- STEP 3 -->
    <div class="step-content" id="step-3">
      <div class="step-head">
        <div class="step-head-title">Veritabanı Bağlantısı</div>
        <div class="step-head-desc">MySQL veritabanı bilgilerini gir. Hosting panelinde bu bilgilere ulaşabilirsin.</div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
        <div class="form-group" style="margin-bottom:14px;">
          <label class="form-label"><i class="fa-solid fa-server"></i> Host</label>
          <input type="text" class="form-control" id="dbHost" placeholder="localhost" value="localhost">
        </div>
        <div class="form-group" style="margin-bottom:14px;">
          <label class="form-label"><i class="fa-solid fa-database"></i> Veritabanı</label>
          <input type="text" class="form-control" id="dbName" placeholder="vexaris_db">
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
        <div class="form-group">
          <label class="form-label"><i class="fa-solid fa-user"></i> Kullanıcı</label>
          <input type="text" class="form-control" id="dbUser" placeholder="root">
        </div>
        <div class="form-group">
          <label class="form-label"><i class="fa-solid fa-key"></i> Şifre</label>
          <input type="password" class="form-control" id="dbPass" placeholder="••••••••">
        </div>
      </div>
      <button class="btn btn-full" id="btnCheckDb" style="background:var(--card-bg);color:var(--text-main);border:1px solid var(--border-color);margin-top:8px;">
        <i class="fa-solid fa-plug"></i> Bağlantıyı Kontrol Et
      </button>
      <div class="db-result" id="dbResultBox">
        <div class="db-result-text" id="dbResultText"></div>
      </div>
    </div>

    <!-- STEP 4 -->
    <div class="step-content" id="step-4">
      <div class="step-head">
        <div class="step-head-title">Yönetici Hesabı</div>
        <div class="step-head-desc">Yönetim paneline erişmek için kullanacağın hesabı oluştur.</div>
      </div>
      <div class="form-group">
        <label class="form-label"><i class="fa-solid fa-at"></i> Kullanıcı Adı</label>
        <input type="text" class="form-control" id="adminUser" placeholder="admin" value="admin" maxlength="32">
      </div>
      <div class="form-group">
        <label class="form-label"><i class="fa-solid fa-envelope"></i> E-posta</label>
        <input type="email" class="form-control" id="adminEmail" placeholder="admin@siteniz.com">
      </div>
      <div class="form-group">
        <label class="form-label"><i class="fa-solid fa-lock"></i> Şifre</label>
        <input type="password" class="form-control" id="adminPass" placeholder="Güçlü bir şifre belirleyin" oninput="pwCheck(this.value)" minlength="8">
        <div class="pw-bar" id="pwBar"><span></span><span></span><span></span><span></span></div>
        <p class="pw-label" id="pwLabel"></p>
      </div>
      <div class="form-group">
        <label class="form-label"><i class="fa-solid fa-lock"></i> Şifre Tekrar</label>
        <input type="password" class="form-control" id="adminPassConfirm" placeholder="Şifrenizi doğrulayın" oninput="pwMatch()">
        <p class="pw-match" id="pwMatch"></p>
      </div>
    </div>

    <!-- STEP 5 -->
    <div class="step-content" id="step-5">
      <div class="finish-screen">
        <div class="finish-icon"><i class="fa-solid fa-check-double"></i></div>
        <h3 class="finish-title">Kurulum Tamamlandı!</h3>
        <p class="finish-desc">Vexaris başarıyla yapılandırıldı. Muhteşem mağazanızı yönetmeye hemen başlayabilirsiniz.</p>
        <ul class="finish-check">
          <li><i class="fa-solid fa-circle-check"></i> Sistem gereksinimleri doğrulandı</li>
          <li><i class="fa-solid fa-circle-check"></i> Genel ayarlar kaydedildi</li>
          <li><i class="fa-solid fa-circle-check"></i> Veritabanı tabloları oluşturuldu</li>
          <li><i class="fa-solid fa-circle-check"></i> Yönetici hesabı oluşturuldu</li>
          <li><i class="fa-solid fa-circle-check"></i> Kurulum dosyası kilitlendi</li>
        </ul>
        <div class="finish-actions">
          <a href="/admin/dashboard.php" class="btn btn-primary btn-full" style="margin:0;">
            Yönetim Paneline Git <i class="fa-solid fa-arrow-right-to-bracket"></i>
          </a>
          <a href="/" class="btn btn-secondary btn-full" style="margin:0;">
            <i class="fa-solid fa-house"></i> Ana Sayfaya Git
          </a>
        </div>
      </div>
    </div>

  </div>
  <div class="modal-footer" id="navFooter">
    <button class="btn btn-secondary" id="btnPrev"><i class="fa-solid fa-chevron-left"></i> Geri</button>
    <button class="btn btn-primary" id="btnNext"<?= $allPass?'':' disabled' ?>>İleri <i class="fa-solid fa-chevron-right"></i></button>
  </div>
</div>
<script>window.__sysChecks=<?= json_encode($sysChecks) ?>;</script>
<script src="/install/assets/script.js"></script>
</body>
</html>
