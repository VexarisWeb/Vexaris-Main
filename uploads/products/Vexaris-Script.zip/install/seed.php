<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
function install_seed_lang(\PDO $db, string $lang): array {
    $lang = strtolower(trim($lang));
    if (!preg_match('/^[a-z]{2}$/', $lang)) $lang = 'tr';
    $dir = __DIR__ . '/seeds/' . $lang;
    if (!is_dir($dir)) $dir = __DIR__ . '/seeds/tr';
    $done = ['legal' => 0, 'categories' => 0, 'ticket_categories' => 0];
    try {
        $f = $dir . '/legal.php';
        if (is_file($f)) {
            $rows = require $f;
            if (is_array($rows)) {
                $st = $db->prepare("INSERT IGNORE INTO `legal_pages` (`slug`,`title`,`content`) VALUES (?,?,?)");
                foreach ($rows as $r) {
                    if (!is_array($r) || empty($r['slug'])) continue;
                    $st->execute([(string)$r['slug'], mb_substr((string)($r['title'] ?? ''), 0, 120), (string)($r['content'] ?? '')]);
                    $done['legal'] += $st->rowCount();
                }
            }
        }
        $f = $dir . '/categories.php';
        if (is_file($f)) {
            $rows = require $f;
            if (is_array($rows)) {
                $st = $db->prepare("INSERT IGNORE INTO `categories` (`id`,`name`,`slug`,`icon`,`description`,`sort_order`) VALUES (?,?,?,?,?,?)");
                foreach ($rows as $r) {
                    if (!is_array($r) || empty($r['name'])) continue;
                    $st->execute([(int)($r['id'] ?? 0) > 0 ? (int)$r['id'] : null, (string)$r['name'], (string)($r['slug'] ?? ''), (string)($r['icon'] ?? ''), (string)($r['description'] ?? ''), (int)($r['sort_order'] ?? 0)]);
                    $done['categories'] += $st->rowCount();
                }
            }
        }
        $f = $dir . '/ticket_categories.php';
        if (is_file($f)) {
            $rows = require $f;
            if (is_array($rows)) {
                $st = $db->prepare("INSERT IGNORE INTO `ticket_categories` (`id`,`name`,`icon`,`sort_order`) VALUES (?,?,?,?)");
                foreach ($rows as $r) {
                    if (!is_array($r) || empty($r['name'])) continue;
                    $st->execute([(int)($r['id'] ?? 0) > 0 ? (int)$r['id'] : null, (string)$r['name'], (string)($r['icon'] ?? ''), (int)($r['sort_order'] ?? 0)]);
                    $done['ticket_categories'] += $st->rowCount();
                }
            }
        }
        $st = $db->prepare("INSERT INTO settings (`key`,`value`) VALUES ('primary_lang',?),('seed_lang',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        $st->execute([$lang, $lang]);
    } catch (\Throwable $e) {}
    return $done;
}
