<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
return [
    ['id' => 1, 'name' => 'Plugin', 'slug' => 'plugin', 'icon' => 'fa-solid fa-puzzle-piece', 'description' => 'Minecraft server plugins', 'sort_order' => 1],
    ['id' => 2, 'name' => 'Theme', 'slug' => 'theme', 'icon' => 'fa-solid fa-palette', 'description' => 'Website themes', 'sort_order' => 2],
    ['id' => 3, 'name' => 'Package', 'slug' => 'package', 'icon' => 'fa-solid fa-boxes-stacked', 'description' => 'Campaign packages', 'sort_order' => 3],
];
