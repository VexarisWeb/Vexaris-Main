<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
return [
    [
        'slug' => 'cookie-policy',
        'title' => 'Cookie Policy',
        'content' => '# Cookie Policy

We respect your privacy. This page explains which cookies we use and how you can manage them.

## 1. What Are Cookies?

Cookies are small text files stored in your browser during your visit. They are used to remember your session and keep you secure.

## 2. Cookies We Use

- **Strictly Necessary Cookies:** Required for sessions (vexaris_sess), security verification and load balancing. The site does not work without them.
- **Preference Cookies:** Remember your settings such as cookie choice (nx_cc_*) and theme selection.
- **Analytics Cookies:** Only run with your consent, collecting page view counts anonymously.
- **Remember Me:** Optional login persistence (remember_token).

## 3. Third-Party Cookies

Payment providers you are redirected to at checkout and spam protection (Cloudflare Turnstile / reCAPTCHA) may use their own cookies. Those organizations are responsible for their cookies.

## 4. Controlling Cookies

- You can change **Accept All** or **Essential Only** from the cookie banner at any time.
- You can delete or block cookies in your browser settings. Blocking essential cookies may break login and purchases.

## 5. Data Protection Notice

Data processed through cookies is protected under applicable privacy laws. See our Privacy Policy for details.',
    ],
    [
        'slug' => 'privacy-policy',
        'title' => 'Privacy Policy',
        'content' => '# Privacy Policy

**{site_name}** values your privacy. This policy explains how we collect, use and protect your personal data.

## 1. Data We Collect

- Username and email address you provide when creating an account.
- Records of your purchase transactions.
- Site usage statistics (anonymous).

## 2. How We Use Data

Collected data is used to:
- Manage your account and provide our service.
- Generate licenses for products you purchase.
- Provide technical support.
- Inform you about platform updates.

## 3. Data Sharing

Your personal data is not shared with third parties and is not disclosed unless legally required.

## 4. Data Security

Your data is protected with SSL encryption and secure server infrastructure.

## 5. Your Rights

You have the right to access, correct and delete your data under applicable privacy laws.',
    ],
    [
        'slug' => 'terms-of-service',
        'title' => 'Terms of Service',
        'content' => '# Terms of Service

By using the **{site_name}** platform you accept the terms below.

## 1. Account

- You must provide accurate information when creating an account.
- You are responsible for your account security.
- Users under 13 may not create accounts.

## 2. Purchases

- All purchases are one-time and apply to digital products.
- Refunds are only issued for inactive licenses.
- License keys may only be used on a single server.

## 3. Usage

- You may not resell or redistribute purchased products.
- Abusing the platform is prohibited.
- Copyright violations are taken seriously.

## 4. Liability

The platform cannot be held responsible for server outages or data loss.',
    ],
    [
        'slug' => 'refund-policy',
        'title' => 'Refund Policy',
        'content' => '# Refund Policy

**{site_name}** prioritizes customer satisfaction. Due to the nature of digital products, refund terms are defined below.

## 1. Core Principle

Since digital delivery happens at the moment of payment confirmation, right of withdrawal technically cannot apply to **used licenses and downloaded files**. Refunds are still issued in the following cases.

## 2. Refund Conditions

- The license key has **never been used**,
- Application is made within **14 days** of purchase,
- The product does not work technically and our support team **cannot resolve** the issue.

## 3. Refund Process

1. Open a support ticket,
2. State your refund reason,
3. Our team reviews the request within 48 hours,
4. If approved, credit is reflected to your account within 3 business days.

## 4. Exceptions

- Custom-made products cannot be refunded.
- No partial refunds on campaign/bundle products.',
    ],
];
