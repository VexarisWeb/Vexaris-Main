<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
return [
    ['id' => 1, 'name' => 'General', 'icon' => 'fa-solid fa-tag', 'sort_order' => 1],
    ['id' => 2, 'name' => 'Technical Issue', 'icon' => 'fa-solid fa-wrench', 'sort_order' => 2],
    ['id' => 3, 'name' => 'License', 'icon' => 'fa-solid fa-key', 'sort_order' => 3],
    ['id' => 4, 'name' => 'Payment', 'icon' => 'fa-solid fa-credit-card', 'sort_order' => 4],
    ['id' => 5, 'name' => 'Other', 'icon' => 'fa-solid fa-ellipsis', 'sort_order' => 5],
];
