<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
return [
    ['id' => 1, 'name' => 'Plugin', 'slug' => 'plugin', 'icon' => 'fa-solid fa-puzzle-piece', 'description' => 'Minecraft sunucu eklentileri', 'sort_order' => 1],
    ['id' => 2, 'name' => 'Tema', 'slug' => 'tema', 'icon' => 'fa-solid fa-palette', 'description' => 'Web sitesi temaları', 'sort_order' => 2],
    ['id' => 3, 'name' => 'Paket', 'slug' => 'paket', 'icon' => 'fa-solid fa-boxes-stacked', 'description' => 'Kampanya paketleri', 'sort_order' => 3],
];
