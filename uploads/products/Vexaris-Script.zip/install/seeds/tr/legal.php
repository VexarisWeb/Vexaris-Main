<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
return [
    [
        'slug' => 'cookie-policy',
        'title' => 'Çerez Politikası',
        'content' => '# Çerez Politikası

**{site_name}** olarak gizliliğinize saygı duyuyoruz. Bu sayfa hangi çerezleri kullandığımızı ve bunları nasıl yönetebileceğinizi açıklar.

## 1. Çerez Nedir?

Çerez, ziyaretiniz sırasında tarayıcınıza kaydedilen küçük metin dosyalarıdır. Oturumunuzu hatırlamak ve güvenliğinizi sağlamak için kullanılır.

## 2. Kullandığımız Çerezler

- **Zorunlu Çerezler:** Oturum (vexaris_sess), güvenlik doğrulaması ve yük dengeleme için şarttır. Bunlar olmadan site çalışmaz.
- **Tercih Çerezleri:** Çerez tercihiniz (nx_cc_*) ve tema seçiminiz gibi ayarları hatırlar.
- **Analitik Çerezler:** Yalnızca izninizle çalışır, sayfa görüntüleme sayılarını anonim olarak toplar.
- **Beni Hatırla:** İsteğe bağlı giriş kalıcılığı (remember_token) için kullanılır.

## 3. Üçüncü Taraf Çerezleri

Ödeme adımında yönlendiğiniz ödeme kuruluşları ile spam koruması (Cloudflare Turnstile / reCAPTCHA) kendi çerezlerini kullanabilir. Bu çerezlerden ilgili kuruluşlar sorumludur.

## 4. Çerezleri Kontrol Etme

- Sitedeki çerez bandından **Tümünü Kabul Et** veya **Sadece Zorunlu** seçimini dilediğiniz zaman değiştirebilirsiniz.
- Tarayıcı ayarlarından çerezleri silebilir veya engelleyebilirsiniz. Zorunlu çerezleri engellerseniz giriş ve satın alma çalışmayabilir.

## 5. KVKK Aydınlatma

Çerezlerle işlenen veriler 6698 sayılı KVKK kapsamında korunur. Detay için Gizlilik Politikamıza bakın.',
    ],
    [
        'slug' => 'privacy-policy',
        'title' => 'Gizlilik Politikası',
        'content' => '# Gizlilik Politikası

**{site_name}** olarak kişisel verilerinizin güvenliğine önem veriyoruz. Bu metin 6698 sayılı KVKK uyarınca aydınlatma metni niteliğindedir.

## 1. Toplanan Veriler

- **Hesap verileri:** kullanıcı adı, e-posta adresi, parola (şifreli saklanır).
- **Sipariş verileri:** satın alınan ürün, tutar, tarih ve teslim edilen lisans kayıtları.
- **Teknik kayıtlar:** IP adresi, tarayıcı bilgisi, giriş denemeleri ve hata günlükleri.
- **Destek kayıtları:** açtığınız biletler ve mesajlaşmalar.

## 2. İşleme Amaçları ve Hukuki Sebepler

Verileriniz, hesabınızı yönetmek, siparişlerinizi teslim etmek, teknik destek sağlamak ve dolandırıcılığı önlemek için işlenir (KVKK m.5: sözleşmenin kurulması ve ifası, veri sorumlusunun hukuki yükümlülüğü ve meşru menfaati).

## 3. Kart Bilgileri

Kredi kartı bilgileriniz **sunucularımıza hiçbir zaman yazılmaz**. Tüm tahsilat lisanslı ödeme kuruluşları üzerinden gerçekleşir.

## 4. Saklama Süreleri

Hesap verileri üyeliğiniz sürdükçe, sipariş ve fatura kayıtları yasal zamanaşımı süreleri boyunca saklanır. Hesabınızı kapattığınızda kişisel verileriniz anonimleştirilir veya silinir.

## 5. Paylaşım

Verileriniz pazarlama amacıyla üçüncü kişilerle paylaşılmaz. Yalnızca ödeme tahsilatı ve yasal zorunluluklar (mahkeme kararı gibi) kapsamında gerekli taraflarla paylaşılır.

## 6. Haklarınız

KVKK m.11 uyarınca verilerinize erişme, düzeltme, silme, işlenmeye itiraz etme ve zararın giderilmesini talep etme haklarına sahipsiniz. Taleplerinizi destek sistemi üzerinden iletebilirsiniz.

## 7. Güvenlik

Veriler SSL şifreleme ile taşınır, parolalar tek yönlü şifreleme ile saklanır ve yönetim paneli rol bazlı yetkilendirme ile korunur.',
    ],
    [
        'slug' => 'terms-of-service',
        'title' => 'Kullanım Şartları',
        'content' => '# Kullanım Şartları

**{site_name}** platformunu kullanarak aşağıdaki şartları kabul etmiş sayılırsınız.

## 1. Hizmetin Kapsamı

Platform, e-pin, lisans anahtarı, e-kitap ve yazılım paketi gibi dijital ürünlerin satıldığı bir pazaryeridir. Tüm ürünler dijital olarak, anında teslim edilir.

## 2. Hesap

- Kayıt sırasında doğru bilgi vermekle yükümlüsünüz.
- Hesabınızın güvenliğinden siz sorumlusunuz, şifrenizi kimseyle paylaşmayın.
- 18 yaşından küçükler veli izni olmadan işlem yapamaz.

## 3. Lisans Kullanımı

- Satın aldığınız lisans **size özeldir**, yeniden satılamaz, kiralanamaz veya herkese açık paylaşılamaz.
- Aksi belirtilmedikçe her lisans tek kullanım / tek alıcı içindir.
- Lisansın kötüye kullanıldığı tespit edilirse erişiminiz askıya alınabilir.

## 4. Fiyat ve Ödeme

- Fiyatlar Türk Lirasıdır ve KDV dahildir.
- Ödeme anında tahsil edilir, ödeme onaylanmadan teslimat başlamaz.

## 5. Teslimat

- Ödeme onayı sonrası ürün **otomatik ve anında** hesabınıza tanımlanır.
- Teslimat gecikmesi yaşanırsa destek talebi açmanız yeterlidir.

## 6. Yasak Kullanım

Platformu dolandırıcılık, tersine mühendislikle koruma atlatma, spam veya yasa dışı amaçlarla kullanmak yasaktır. İhlalde hesap kapatılır ve ödenmiş tutarlar iade edilmez.

## 7. Sorumluluk Sınırı

Platform, mücbir sebepler ve üçüncü taraf hizmet kesintilerinden doğan zararlardan sorumlu tutulamaz. Sorumluluk, ilgili sipariş tutarıyla sınırlıdır.

## 8. Değişiklik ve Yürürlük

Bu şartlar güncellenebilir, güncel metin her zaman bu sayfada yayınlanır. Uyuşmazlıklarda Türkiye Cumhuriyeti kanunları uygulanır.',
    ],
    [
        'slug' => 'refund-policy',
        'title' => 'İade Politikası',
        'content' => '# İade Politikası

**{site_name}** olarak müşteri memnuniyetini ön planda tutuyoruz. Dijital ürünlerin doğası gereği iade koşulları aşağıda tanımlanmıştır.

## 1. Temel İlke

Dijital teslimat ödeme onayı anında gerçekleştiği için, **kullanılmış lisans ve indirilmiş dosyalarda cayma hakkı teknik olarak uygulanamaz**. Yine de aşağıdaki durumlarda iade yapılır.

## 2. İade Koşulları

- Lisans anahtarının **hiç kullanılmamış** olması,
- Satın alma tarihinden itibaren **14 gün** içinde başvuru yapılması,
- Ürünün teknik olarak çalışmaması ve destek ekibinin sorunu **çözememesi**.

## 3. İade Süreci

1. Destek sistemi üzerinden iade talebi oluşturun.
2. Sipariş numaranızı ve iade sebebinizi yazın.
3. Ekibimiz talebi **48 saat** içinde değerlendirir.
4. Onaylanan iadeler önce **bakiyenize**, isterseniz 3 iş günü içinde ödeme yönteminize yansıtılır.

## 4. İstisnalar

- Kullanılmış veya süresi başlatılmış lisanslar iade edilmez.
- Size özel hazırlanan ürünler iade edilmez.
- Kampanyalı paketlerde kısmi iade yapılmaz, paket bütün olarak değerlendirilir.

## 5. Ödeme Kuruluşu İadeleri

Karta iade işlemleri bankanıza bağlı olarak 2-10 iş günü içinde ekstrelere yansır. Bu süre bankalardan kaynaklanır.',
    ],
];
