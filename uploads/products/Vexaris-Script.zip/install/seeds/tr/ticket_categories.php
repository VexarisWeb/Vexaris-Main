<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
return [
    ['id' => 1, 'name' => 'Genel', 'icon' => 'fa-solid fa-tag', 'sort_order' => 1],
    ['id' => 2, 'name' => 'Teknik Sorun', 'icon' => 'fa-solid fa-wrench', 'sort_order' => 2],
    ['id' => 3, 'name' => 'Lisans', 'icon' => 'fa-solid fa-key', 'sort_order' => 3],
    ['id' => 4, 'name' => 'Ödeme', 'icon' => 'fa-solid fa-credit-card', 'sort_order' => 4],
    ['id' => 5, 'name' => 'Diğer', 'icon' => 'fa-solid fa-ellipsis', 'sort_order' => 5],
];
