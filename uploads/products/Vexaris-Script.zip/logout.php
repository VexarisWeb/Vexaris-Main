<?php
include 'core/init.php';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Location: /', true, 302);
    exit;
}
csrf_verify();
auth_logout();
header('Location: /', true, 302);
exit;
