<?php
include 'core/init.php';
http_response_code(503);
theme_load('maintenance');
