<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
$havaleMsg = null;
$havaleAdminId = (int)($adminUser['id'] ?? 0);
$havaleCanFinance = (($adminUser['role'] ?? '') === 'admin') || (function_exists('has_permission') && has_permission('purchases'));
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['havale_intent'], $_POST['havale_islem'])) {
    if (!$havaleCanFinance) {
        $havaleMsg = ['type' => 'error', 'text' => __('bshop.havale_op_fail')];
    } else {
    $intentId = mb_substr(trim((string)$_POST['havale_intent']), 0, 40);
    $islem = trim((string)$_POST['havale_islem']);
    try {
        $chk = $adminDb->prepare("SELECT * FROM payment_intents WHERE order_id=? AND payment_method='havale' AND status='pending' LIMIT 1");
        $chk->execute([$intentId]);
        $row = $chk->fetch();
        if (!$row) {
            $havaleMsg = ['type' => 'error', 'text' => __('bshop.havale_no_pending')];
        } elseif ($islem === 'tanimla') {
            $tutar = round((float)($row['total_amount'] ?? 0), 2);
            $alc = (int)($row['user_id'] ?? 0);
            if ($alc <= 0 || $tutar <= 0) {
                $havaleMsg = ['type' => 'error', 'text' => __('bshop.havale_bad_amount')];
            } else {
                $adminDb->beginTransaction();
                $adminDb->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$tutar, $alc]);
                $adminDb->prepare("INSERT INTO balance_log (user_id,amount,type,description,created_at) VALUES (?,?, 'admin',?,NOW())")->execute([$alc, $tutar, __('bshop.havale_log', ['oid' => $intentId])]);
                $adminDb->prepare("UPDATE payment_intents SET status='completed',payment_id='manuel-bakiye' WHERE order_id=?")->execute([$intentId]);
                $tk = $adminDb->prepare("SELECT * FROM tickets WHERE user_id=? AND status!='closed' AND (title LIKE ? OR message LIKE ?) ORDER BY id DESC LIMIT 1");
                $tk->execute([$alc, '%' . $intentId . '%', '%' . $intentId . '%']);
                $trow = $tk->fetch();
                if ($trow && $havaleAdminId > 0) {
                    $adminDb->prepare('INSERT INTO ticket_replies (ticket_id,user_id,is_admin,message,created_at) VALUES (?,?,1,?,NOW())')->execute([(int)$trow['id'], $havaleAdminId, __('bshop.havale_approved', ['m' => number_format($tutar, 2, ',', '.'), 'oid' => $intentId])]);
                    $adminDb->prepare("UPDATE tickets SET status='closed' WHERE id=?")->execute([(int)$trow['id']]);
                }
                $adminDb->commit();
                $havaleMsg = ['type' => 'success', 'text' => __('bshop.havale_granted', ['m' => number_format($tutar, 2, ',', '.')])];
            }
        } elseif ($islem === 'iptal') {
            $adminDb->beginTransaction();
            $adminDb->prepare("UPDATE payment_intents SET status='cancelled' WHERE order_id=?")->execute([$intentId]);
            $tk = $adminDb->prepare("SELECT * FROM tickets WHERE user_id=? AND status!='closed' AND (title LIKE ? OR message LIKE ?) ORDER BY id DESC LIMIT 1");
            $tk->execute([(int)($row['user_id'] ?? 0), '%' . $intentId . '%', '%' . $intentId . '%']);
            $trow = $tk->fetch();
            if ($trow && $havaleAdminId > 0) {
                $adminDb->prepare('INSERT INTO ticket_replies (ticket_id,user_id,is_admin,message,created_at) VALUES (?,?,1,?,NOW())')->execute([(int)$trow['id'], $havaleAdminId, 'Havale talebiniz iptal edildi (' . $intentId . '). Sorunuz varsa bu talepten yazmaya devam edebilirsiniz.']);
                $adminDb->prepare("UPDATE tickets SET status='closed' WHERE id=?")->execute([(int)$trow['id']]);
            }
            $adminDb->commit();
            $havaleMsg = ['type' => 'success', 'text' => __('bshop.havale_cancelled')];
        } else {
            $havaleMsg = ['type' => 'error', 'text' => __('bshop.havale_op_fail')];
        }
    } catch (Throwable $e) {
        try { if ($adminDb->inTransaction()) $adminDb->rollBack(); } catch (Throwable $e2) {}
        $havaleMsg = ['type' => 'error', 'text' => __('bshop.havale_op_fail')];
    }
    }
}
try {
    $bekleyen = $adminDb->query("SELECT pi.`order_id`,pi.`user_id`,pi.`total_amount`,pi.`created_at`,u.`username` FROM payment_intents pi LEFT JOIN users u ON u.id=pi.user_id WHERE pi.payment_method='havale' AND pi.status='pending' ORDER BY pi.`id` DESC LIMIT 50")->fetchAll();
    $gecmis = $adminDb->query("SELECT pi.`order_id`,pi.`user_id`,pi.`total_amount`,pi.`status`,pi.`created_at`,u.`username` FROM payment_intents pi LEFT JOIN users u ON u.id=pi.user_id WHERE pi.payment_method='havale' AND pi.status IN ('completed','cancelled') ORDER BY pi.`id` DESC LIMIT 20")->fetchAll();
} catch (Throwable $e) { $bekleyen = []; $gecmis = []; }
function havale_ticket_id(PDO $db, int $uid, string $orderId): int {
    try {
        $st = $db->prepare("SELECT id FROM tickets WHERE user_id=? AND status!='closed' AND (title LIKE ? OR message LIKE ?) ORDER BY id DESC LIMIT 1");
        $st->execute([$uid, '%' . $orderId . '%', '%' . $orderId . '%']);
        return (int)($st->fetchColumn() ?: 0);
    } catch (Throwable $e) { return 0; }
}
?>
<?php if (function_exists('module_enabled') && module_enabled('ornek-havale')): ?>
<div style="background:rgba(234,179,8,.08);border:1px solid rgba(234,179,8,.3);color:#facc15;padding:12px 18px;border-radius:12px;font-size:13px;font-weight:600;margin-bottom:20px;">
    <i class="fa-solid fa-triangle-exclamation"></i> <?= __('bshop.havale_dup_warn', ['code' => '<code>havale</code>', 'link' => '<a href="/admin/modules.php?open=ornek-havale" style="color:#facc15;font-weight:800;">' . __('amenu.modules') . '</a>']) ?>
</div>
<?php endif; ?>
<?php if ($havaleMsg): ?>
<div style="background:<?= $havaleMsg['type']==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;border:1px solid <?= $havaleMsg['type']==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;color:<?= $havaleMsg['type']==='success'?'#4ade80':'#f87171' ?>;padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;margin-bottom:20px;">
    <?= e($havaleMsg['text']) ?>
</div>
<?php endif; ?>
<div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-hourglass-half" style="color:#0ea5e9;margin-right:8px;"></i> <?= __('bshop.havale_pending') ?> (<?= count($bekleyen) ?>)</span>
    </div>
    <p style="font-size:11px;color:var(--muted);margin-bottom:12px;"><i class="fa-solid fa-circle-info"></i> <?= __('bshop.havale_info') ?></p>
    <?php if (empty($bekleyen)): ?>
    <p style="font-size:13px;color:var(--muted);"><?= __('bshop.havale_none') ?></p>
    <?php else: ?>
    <div style="display:grid;gap:10px;">
        <?php foreach ($bekleyen as $b): $bTid = havale_ticket_id($adminDb, (int)$b['user_id'], (string)$b['order_id']); ?>
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:12px 16px;">
            <div style="flex:1;min-width:180px;">
                <div style="font-size:13px;font-weight:800;font-family:monospace;"><?= e($b['order_id']) ?></div>
                <div style="font-size:11px;color:var(--muted);"><?= e((string)($b['username'] ?? ('#' . (int)$b['user_id']))) ?> · <?= e($b['created_at']) ?><?php if ($bTid > 0): ?> · <a href="/admin/support.php?id=<?= $bTid ?>" style="color:#7dd3fc;font-weight:800;"><?= __('bshop.havale_ticket_link', ['n' => $bTid]) ?></a><?php endif; ?></div>
            </div>
            <div style="font-size:15px;font-weight:900;"><?= fmt_money((float)$b['total_amount'], 'TRY') ?></div>
            <form method="POST" style="display:flex;gap:8px;">
                <?= csrf_field() ?>
                <input type="hidden" name="havale_intent" value="<?= e($b['order_id']) ?>">
                <button type="submit" name="havale_islem" value="tanimla" class="btn-admin btn-primary-admin" style="padding:8px 14px;font-size:12px;" onclick="return confirm(<?= json_encode(__('bshop.havale_confirm')) ?>);"><i class="fa-solid fa-coins"></i> <?= __('bshop.havale_grant') ?></button>
                <button type="submit" name="havale_islem" value="iptal" class="btn-admin btn-ghost-admin" style="padding:8px 14px;font-size:12px;" onclick="return confirm(<?= json_encode(__('bshop.havale_cancel_confirm')) ?>);"><?= __('bshop.havale_cancel') ?></button>
            </form>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-clock-rotate-left" style="color:#0ea5e9;margin-right:8px;"></i> <?= __('bshop.havale_past') ?></span>
    </div>
    <?php if (empty($gecmis)): ?>
    <p style="font-size:13px;color:var(--muted);"><?= __('bshop.havale_no_hist') ?></p>
    <?php else: ?>
    <div style="overflow-x:auto;">
    <table style="width:100%;font-size:12px;border-collapse:collapse;">
        <thead><tr style="color:var(--muted);text-align:left;border-bottom:1px solid var(--border);">
            <th style="padding:8px;"><?= module_lang('havale', 'th_order') ?></th><th style="padding:8px;"><?= module_lang('havale', 'th_user') ?></th><th style="padding:8px;"><?= module_lang('havale', 'th_amount') ?></th><th style="padding:8px;"><?= module_lang('havale', 'th_status') ?></th><th style="padding:8px;"><?= module_lang('havale', 'th_date') ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($gecmis as $g): ?>
        <tr style="border-bottom:1px solid var(--border);">
            <td style="padding:8px;font-family:monospace;"><?= e($g['order_id']) ?></td>
            <td style="padding:8px;"><?= e((string)($g['username'] ?? ('#' . (int)$g['user_id']))) ?></td>
            <td style="padding:8px;"><?= fmt_money((float)$g['total_amount'], 'TRY') ?></td>
            <td style="padding:8px;"><?= e($g['status']) ?></td>
            <td style="padding:8px;"><?= e($g['created_at']) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>
