<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
function havale_recognized(PDO $db, int $uid): bool {
    if ($uid <= 0) return false;
    $mode = trim((string)module_setting('havale', 'banka_kosulu', 'satis_gecmisi'));
    if ($mode === 'herkes') return true;
    try {
        if ($mode === 'kayit_suresi') {
            $gun = (int)module_setting('havale', 'kayit_gun', '7');
            if ($gun < 1) $gun = 7;
            if ($gun > 3650) $gun = 3650;
            $st = $db->prepare('SELECT created_at FROM users WHERE id=? LIMIT 1');
            $st->execute([$uid]);
            $ca = $st->fetchColumn();
            if (!$ca) return false;
            $ts = strtotime((string)$ca);
            if (!$ts) return false;
            return $ts <= time() - $gun * 86400;
        }
        $st = $db->prepare('SELECT COUNT(*) FROM sales WHERE user_id=?');
        $st->execute([$uid]);
        return (int)$st->fetchColumn() > 0;
    } catch (Throwable $e) { return false; }
}
function havale_ensure_category(PDO $db): void {
    try {
        $st = $db->prepare("SELECT id FROM ticket_categories WHERE name='Havale Talebi' LIMIT 1");
        $st->execute();
        if ($st->fetch()) return;
        $mx = 6;
        try { $mx = (int)$db->query('SELECT COALESCE(MAX(sort_order),0)+1 FROM ticket_categories')->fetchColumn(); } catch (Throwable $e2) {}
        if ($mx < 1) $mx = 6;
        $db->prepare('INSERT INTO ticket_categories (name,icon,sort_order) VALUES (?,?,?)')->execute(['Havale Talebi', 'fa-solid fa-building-columns', $mx]);
    } catch (Throwable $e) {}
}
function havale_find_ticket(PDO $db, int $uid, string $orderId): ?array {
    if ($uid <= 0 || $orderId === '') return null;
    try {
        $like = '%' . $orderId . '%';
        $st = $db->prepare("SELECT * FROM tickets WHERE user_id=? AND status!='closed' AND (title LIKE ? OR message LIKE ?) ORDER BY id DESC LIMIT 1");
        $st->execute([$uid, $like, $like]);
        $row = $st->fetch();
        return $row ?: null;
    } catch (Throwable $e) { return null; }
}
function havale_open_ticket(PDO $db, array $user, string $orderId, float $total, bool $isTopup, string $cur = ''): ?array {
    if ($cur === '' && function_exists('store_currency')) $cur = store_currency();
    if ($cur === '') $cur = 'TRY';
    $uid = (int)($user['id'] ?? 0);
    if ($uid <= 0 || $orderId === '') return null;
    $hit = havale_find_ticket($db, $uid, $orderId);
    if ($hit) return $hit;
    try {
        $cnt = $db->prepare("SELECT id FROM tickets WHERE user_id=? AND category='Havale Talebi' AND status!='closed' ORDER BY id DESC LIMIT 10");
        $cnt->execute([$uid]);
        $open = $cnt->fetchAll();
        if (count($open) >= 3) {
            $st = $db->prepare('SELECT * FROM tickets WHERE id=? LIMIT 1');
            $st->execute([(int)$open[0]['id']]);
            $row = $st->fetch();
            return $row ?: null;
        }
    } catch (Throwable $e) {}
    $title = mb_substr('[Havale Talebi] ' . $orderId . ' - ' . (function_exists('fmt_money') ? fmt_money($total, $cur) : number_format($total, 2, ',', '.') . ' ' . $cur), 0, 255);
    $uname = (string)($user['username'] ?? ('#' . $uid));
    $msg = __('bshop.havale_ticket_note') . "\n"
        . __('bsupp.field_order') . ': ' . $orderId . "\n"
        . __('bshop.havale_type') . ': ' . ($isTopup ? __('bshop.havale_type_topup') : __('bshop.havale_type_cart')) . "\n"
        . __('bsupp.field_amount') . ': ' . (function_exists('fmt_money') ? fmt_money($total, $cur) : number_format($total, 2, ',', '.') . ' ' . $cur) . "\n"
        . __('bsupp.field_user') . ': ' . $uname . ' (#' . $uid . ")\n"
        . __('bshop.havale_wait');
    try {
        $db->prepare('INSERT INTO tickets (user_id,title,category,message,status,created_at) VALUES (?,?,?,?,?,NOW())')->execute([$uid, $title, 'Havale Talebi', $msg, 'open']);
        $tid = (int)$db->lastInsertId();
        if ($tid <= 0) return null;
        try {
            if (!function_exists('discord_notify') && is_file(ROOT_PATH . '/core/discord.php')) require_once ROOT_PATH . '/core/discord.php';
            if (function_exists('discord_notify')) discord_notify($db, 'ticket', __('bsupp.ticket_new'), __('bsupp.havale_ticket_body'), [__('bsupp.field_user') => $uname, __('bsupp.field_order') => $orderId, __('bsupp.field_amount') => (function_exists('fmt_money') ? fmt_money($total, $cur) : number_format($total, 2, ',', '.') . ' ' . $cur)], '16268780');
        } catch (Throwable $e2) {}
        $st = $db->prepare('SELECT * FROM tickets WHERE id=? LIMIT 1');
        $st->execute([$tid]);
        $row = $st->fetch();
        return $row ?: null;
    } catch (Throwable $e) { return null; }
}
function havale_render_pay($intent, $items = [], $total = 0, $isTopup = false): void {
    $db = function_exists('nexus_db') ? nexus_db() : null;
    $me = (function_exists('auth_check') && auth_check()) ? auth_user() : null;
    if (!$db || !$me) {
        echo '<div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:12px;padding:20px;text-align:center;color:#f87171;font-size:13px;font-weight:600;">' . __('bshop.havale_nosession') . '</div>';
        return;
    }
    $uid = (int)($me['id'] ?? 0);
    $orderId = (string)(is_array($intent) ? ($intent['order_id'] ?? '') : '');
    $total = round((float)$total, 2);
    $intentCur = strtoupper((string)(is_array($intent) ? ($intent['currency'] ?? '') : ''));
    $dispCur = store_currency();
    if ($intentCur !== '' && $intentCur !== $dispCur) { $total = (float)($intent['total_amount'] ?? $total); $dispCur = $intentCur; }
    havale_ensure_category($db);
    $ticket = havale_open_ticket($db, $me, $orderId, $total, (bool)$isTopup, $dispCur);
    $ok = havale_recognized($db, $uid);
    $iban = trim((string)module_setting('havale', 'iban', ''));
    $alici = trim((string)module_setting('havale', 'alici', ''));
    $not = trim((string)module_setting('havale', 'aciklama', ''));
    if ($ok && $iban !== '') {
        echo '<div style="background:#0f1520;border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:24px;display:flex;flex-direction:column;gap:12px;font-size:14px;">';
        echo '<div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#94a3b8;">Alıcı</span><strong>' . ($alici !== '' ? e($alici) : '<span style="color:#f87171;">' . __('bshop.havale_undef') . '</span>') . '</strong></div>';
        echo '<div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#94a3b8;">IBAN</span><strong style="font-family:monospace;">' . e($iban) . '</strong></div>';
        $hvTotal = function_exists('fmt_money') ? fmt_money($total, $dispCur) : (e($dispCur === 'TRY' ? '₺' : $dispCur) . number_format($total, 2, ',', '.'));
        if ($dispCur !== store_currency() && function_exists('fx_convert')) $hvTotal .= '<br><span style="font-size:12px;color:#94a3b8;">≈ ' . e(fmt_money($total)) . '</span>';
        echo '<div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#94a3b8;">Tutar</span><strong style="color:#fbbf24;">' . $hvTotal . '</strong></div>';
        echo '<div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#94a3b8;">' . __('aprod.desc_label') . '</span><strong style="font-family:monospace;">' . e($orderId) . '</strong></div>';
        if ($not !== '') echo '<p style="color:#94a3b8;font-size:12px;margin:4px 0 0;">' . e($not) . '</p>';
        echo '<p style="color:#4ade80;font-size:12px;font-weight:700;margin:4px 0 0;">' . __('bshop.havale_done') . '</p>';
        echo '</div>';
    } elseif ($ok) {
        echo '<div style="background:rgba(234,179,8,.08);border:1px solid rgba(234,179,8,.3);border-radius:12px;padding:20px;text-align:center;color:#facc15;font-size:13px;font-weight:600;">' . __('bshop.havale_nobank') . '</div>';
    } else {
        echo '<div style="background:rgba(234,179,8,.08);border:1px solid rgba(234,179,8,.3);border-radius:12px;padding:20px;text-align:center;color:#facc15;font-size:13px;font-weight:600;">' . __('bshop.havale_private') . '</div>';
    }
    if ($ticket) {
        $tid = (int)($ticket['id'] ?? 0);
        echo '<a href="/support?id=' . $tid . '" style="display:flex;align-items:center;justify-content:center;gap:8px;margin-top:12px;background:rgba(14,165,233,.12);border:1px solid rgba(14,165,233,.35);border-radius:12px;padding:13px;font-size:13px;font-weight:800;color:#7dd3fc;text-decoration:none;"><i class="fa-solid fa-ticket"></i> ' . __('bshop.havale_opened', ['n' => $tid]) . '</a>';
    } else {
        echo '<div style="margin-top:12px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:12px;padding:13px;text-align:center;color:#f87171;font-size:13px;font-weight:600;">' . __('bshop.havale_fail') . '</div>';
    }
}
add_action('gateway_pay_havale', function ($intent, $items = [], $total = 0, $isTopup = false) {
    havale_render_pay($intent, $items, $total, $isTopup);
});
