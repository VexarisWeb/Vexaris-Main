# Vexaris Modül Geliştirme Kuralları (Kademe 3)

Bu belgeyi okuyan bir geliştirici, `core/` veya `themes/` dosyalarına dokunmadan kendi modülünü yazıp Admin > Ayarlar > Modüller ekranında açıp kapatabilmelidir. Takıldığın yerde `modules/ornek-duyuru` (bant + tam admin sayfası), `modules/ornek-komisyon` (sepet komisyonu + sipariş logu) ve `modules/ornek-havale` (kodla ödeme gateway'i + admin onay) klasörlerini referans al.

## 1. Felsefe: Neden Modül Var?

Vexaris güncelleme aldığında `core/`, `themes/`, `admin/`, `action.php` dosyaları ezilir. Özelliğini bu dosyalara yazarsan güncellemede gider. Modül bunun çözümüdür:

- Senin kodun yalnızca `modules/senin-modulun/` altında yaşar. Güncelleme bu klasöre dokunmaz.
- Core sana kanca (hook) verir: `add_action` / `add_filter`. Sen core dosyasını değiştirmezsin, core senin fonksiyonunu çağırır.
- Kural kısaca: **core modülü çağırır, modül core dosyasını asla değiştirmez.**

## 2. Klasör Yapısı

```
/modules
  modul-gelistirme-kurallari.md   bu dosya
  ornek-duyuru/                   örnek modül (bant + tam admin sayfası)
    module.json                   ZORUNLU: kimlik + ayar şeması
    module.php                    ZORUNLU: hook kayıtları (açıkken her istekte yüklenir)
    admin.php                     OPSİYONEL: tam admin sayfası (admin_page:true ister)
    lang/tr.json                  OPSİYONEL: Türkçe sözlük (bölüm 7f)
    lang/en.json                  OPSİYONEL: İngilizce sözlük (bölüm 7f)
    install.sql                   OPSİYONEL: ilk açılışta koşan tablo kurulumu
    assets/css/style.css          OPSİYONEL: açıksa otomatik yüklenir
    assets/js/app.js              OPSİYONEL: açıksa otomatik yüklenir
  ornek-komisyon/                 örnek modül (checkout_total + order_created)
    module.json
    module.php
    admin.php                     log özeti (özet + tablo)
    install.sql
  ornek-havale/                   örnek modül (manuel gateway + admin onay)
    module.json                   gateway beyanı içerir
    module.php                    gateway_pay_havale işleyicisi
    admin.php                     bekleyen intent listesi (onayla/iptal)
```

Dosya ve klasör adları: yalnızca küçük harf, rakam ve tire. SlugRegex: `^[a-z0-9][a-z0-9-]*[a-z0-9]$` (tek karaktere de izin var). Örnek slug: `ornek-duyuru`, `fatura-pdf`, `toplu-lisans`. Klasör adı = slug, ikisi birebir aynı olmak zorundadır.

## 3. module.json Referansı

Tüm alanlar ve kuralları:

| Alan | Zorunlu | Kural |
|---|---|---|
| `name` | evet | En fazla 80 karakter. Kartta görünen ad. |
| `description` | hayır | En fazla 300 karakter. Kartta görünen açıklama. |
| `version` | evet | `1.0.0` formatında olmak zorunda. Asset önbelleği (`?v=`) buradan üretilir. |
| `author` | hayır | En fazla 80 karakter. |
| `icon` | hayır | Font Awesome sınıfı, varsayılan `fa-puzzle-piece`. Örn: `fa-bullhorn`. |
| `iconPrefix` | hayır | Varsayılan `fa-solid`. Marka ikonuysa `fa-brands`. |
| `color` | hayır | `#8b5cf6` formatında hex. Kart ikonunun rengi. Bozuksa mora düşer. |
| `type` | hayır | Filtre çipi olur. Önerilenler: `marketing`, `payment`, `notification`, `security`, `analytics`, `shipping`, `other`. Yeni tip yazarsan çip otomatik çıkar. |
| `fields` | hayır | Ayar formu alanları. Boş dizi veya yoksa kartta "Yapılandırma gerektirmez" yazar, modal açılmaz. |
| `admin_page` | hayır | `true` ise `admin.php` dosyan tam admin sayfası olarak açılır. Dosya yoksa yok sayılır. |
| `admin_menu` | hayır | Sidebar linki: `{"label": "Duyuru Bandı", "icon": "fa-bullhorn"}`. `admin_page:true` olmadan görünmez. |
| `admin_section` | hayır | Özel sidebar kategorisi: `{"key": "ornekler", "label": "Örnek Modüller", "icon": "fa-flask"}`. Yazmazsan "Modüller" grubuna düşer. `key` yalnızca `^[a-z0-9_]{1,30}$`. |
| `gateway` | hayır | Ödeme yöntemi beyanı: `{"code": "havale", "label": "Havale / EFT", "color": "#0ea5e9"}`. `code` yalnızca `^[a-z0-9_]{1,20}$`, 8 yerleşik kodla çakışamaz. Beyan varsa yöntem ödeme ekranında otomatik listelenir (bölüm 7c). |

### 3.1. Field Tipleri

Her field: `key` (zorunlu, `^[a-z0-9_]{1,40}$`), `label` (zorunlu), `type` (varsayılan `text`).

- `text`: tek satır. `placeholder` verebilirsin (en fazla 200 karakter).
- `number`: sayı. `step` verebilirsin (örn: `"0.01"`). Sayı olmayan değer kaydedilmez, `mod_save` hata döner.
- `textarea`: çok satır. `placeholder` verebilirsin.
- `select`: `options` zorunludur. İki yazım da geçerlidir: `["a","b"]` veya `[{"value":"ust","label":"Üstte sabit"}]`. Kayıtta value listede yoksa reddedilir.

Örnek:

```json
"fields": [
  {"key": "duyuru_metni", "label": "Duyuru Metni", "type": "text", "placeholder": "Örn: İndirim başladı!"},
  {"key": "oran", "label": "İndirim Oranı", "type": "number", "placeholder": "20"},
  {"key": "konum", "label": "Konum", "type": "select", "options": [{"value": "ust", "label": "Üstte"}, {"value": "alt", "label": "Altta"}]},
  {"key": "ozel_js", "label": "Özel Kod", "type": "textarea", "placeholder": "<script>...</script>"}
]
```

Dikkat: `module.json` bozuksa (JSON hatası, `name`/`version` eksik, field kural ihlali) modül listede hiç görünmez. Önce JSON'u doğrula, sonra "neden çıkmıyor" diye panele bak.

## 4. module.php ve Hook API

`module.php` yalnızca modül **açıkken** her istekte `require_once` ile yüklenir. Kapalı modülün kodu çalışmaz, bu bir performans garantisidir. Dosyanın ilk satırı şu guard olmalıdır:

```php
defined('NEXUS_BOOT') or die('Direct access denied.');
```

### 4.1. Hook Fonksiyonları (`core/hooks.php`)

```php
add_action('mod_footer', function () { echo '...'; });
do_action('mod_footer');
add_filter('ornek_fiyat', function ($fiyat) { return $fiyat; });
$fiyat = apply_filters('ornek_fiyat', $fiyat);
```

- `add_action($kanca, $fonksiyon, $oncelik = 10)`: kanca çağrılınca fonksiyonun çalışsın. Küçük öncelik önce çalışır.
- `do_action($kanca, ...$args)`: kancayı tetikler. Modül tarafında nadiren lazım olur.
- `add_filter($kanca, $fonksiyon, $oncelik = 10)` + `apply_filters($kanca, $deger, ...)`: bir değeri zincirleme dönüştürür. Fonksiyon mutlaka değeri `return` etmelidir, yoksa zincir bozulur.
- Hook içinde patlayan hata yakalanır ve loga yazılır, site çökmez. Yine de `try` gerektiren riskli işleri hook dışına taşıma, hata ayıklaması zorlaşır.

### 4.2. Hazır Kancalar (Kademe 3)

| Kanca | Tip | Nerede tetiklenir |
|---|---|---|
| `mod_head` | action | Üç temanın `header.php` dosyasında `</head>` öncesinde. `<style>`, `<meta>`, izleme kodu için. |
| `body_top` | action | Üç temanın `header.php` dosyasında `<body>` açılıp slider basıldıktan hemen sonra. Sayfa üstü bant, karşılama çubuğu için. |
| `mod_footer` | action | Üç temanın `footer.php` dosyasında `</body>` öncesinde. Banner, popup, `<script>` çıktısı için. |
| `header_menu_after` | action | Üç temanın ana menüsünün sonunda. Ek menü linki için. Temaya göre markup değişir, `theme_active()` ile dal yap (bölüm 4.3). |
| `payment_methods` | filter | `shop/payment.php` ödeme listesi kurulduktan sonra. Yöntem gizleme, etiket değiştirme, sıralama için. Yeni gateway enjeksiyonu Kademe 3 işidir. |
| `checkout_total` | filter | Sepet ham toplamı hesaplanınca: `shop/payment.php` (2 nokta), 6 gateway `*-pay.php`, `action.php` bakiye ödemesi. İmza: `($toplam, $sepetSatirlari)`. Sıra sabittir: ham toplam -> modül filtresi -> kupon indirimi. Mutlaka sayı `return` et. |
| `checkout_before` | action | `action.php` bakiye ödemesinde stok kontrolünden önce. İmza: `($uid, $sepetSatirlari, $toplam)`. Sadece bildirim/izleme için, toplamı değiştiremezsin. |
| `order_created` | action | `core/purchase.php` içinde sipariş satırları yazılınca. Tüm gateway'leri tek noktada yakalar. İmza: tek dizi `['user_id', 'sale_count', 'product_names', 'total_paid']`. |
| `purchase_after` | action | Sepet temizlenip bakiye logu yazılınca. Kredi yükleme (topup) akışında da tetiklenir. İmza: `($uid, $toplam, $yontemEtiketi, $logTipi)`. |
| `admin_menu` | action | Admin sidebar'ının sonunda. Kodla özel menü basmak için. Manifest beyanı yetmiyorsa bunu kullan. |
| `product_card_before` | action | Üç temanın `products.php` + `index.php` ürün kartlarından hemen önce. İmza: `($urunDizisi)`. Kart üstü rozet/şerit için. Blok element basılabilir. |
| `product_card_after` | action | Üç temanın `products.php` + `index.php` ürün kartlarının hemen altında. İmza: `($urunDizisi)`. Rozet/ikon için. Yalnızca satır içi `<span>` bas, `<div>` veya iç içe `<a>` koyma (kartın kendisi linktir). |
| `gateway_pay_{kod}` | action | `shop/module-pay` sayfasında. İmza: `($intent, $sepetSatirlari, $toplam, $topupMu)`. Ödeme arayüzünü sen çizersin (bölüm 7c). |
| `gateway_callback_{kod}` | action | `callback/module.php?gateway={kod}` adresinde. API doğrulaması yapıp `modules_gateway_complete()` çağırırsın (bölüm 7c). |
| `gateway_redirect` | filter | `gateway_cart_redirect()` sonunda. Tek yöntem seninkiyse yönlendirmeyi devralmak için. İmza: `($url, $db)`, boş string `return` edersen core mantığı çalışır. |

Örnek (`ornek-duyuru/module.php` dosyasından):

```php
add_action('mod_footer', function () {
    $metin = trim((string)module_setting('ornek-duyuru', 'duyuru_metni', ''));
    if ($metin === '') return;
    echo '<div class="vx-duyuru">' . e($metin) . '</div>';
});
```

Kademe 3 yol haritası (henüz yok): `product_card_after`, tam gateway enjeksiyonu. Bu isimlere kendi kafana göre `do_action` yazma, core tetiklemedikçe çalışmazlar.

### 4.3. Menü Linki Örneği (Tema Farkı)

Üç temanın menü HTML'i farklıdır (default/azure `ul > li`, ember çıplak `a`). Aktif temayı sor, ona göre bas:

```php
add_action('header_menu_after', function () {
    $tema = function_exists('theme_active') ? theme_active() : 'default';
    $url = '/kampanya';
    $icerik = '<i class="fa-solid fa-tag"></i> Kampanya';
    if ($tema === 'ember') echo '<a href="' . e($url) . '">' . $icerik . '</a>';
    else echo '<li><a href="' . e($url) . '">' . $icerik . '</a></li>';
});
```

### 4.4. Komisyon Örneği (Filter + Action Birlikte)

`ornek-komisyon/module.php` dosyasından:

```php
add_filter('checkout_total', function ($total, $items = []) {
    $oran = trim((string)module_setting('ornek-komisyon', 'oran', '0'));
    if ($oran !== '' && is_numeric($oran) && (float)$oran > 0)
        $total = (float)$total * (1 + (float)$oran / 100);
    return round((float)$total, 2);
});
add_action('order_created', function ($order) {
    $db = nexus_db();
    if (!$db) return;
    try {
        $st = $db->prepare("INSERT INTO mod_ornek_komisyon_log (`sale_count`,`total_paid`) VALUES (?,?)");
        $st->execute([(int)$order['sale_count'], (float)$order['total_paid']]);
    } catch (\Throwable $e) {}
});
```

`checkout_total` tüm sepet akışlarında (ödeme ekranı, 6 gateway sayfası, bakiye ödemesi, `buy_now` tekli alım) aynı mantıkla koşar, ekrandaki tutarla çekilen tutar tutarlı kalır.

## 5. Assets: CSS ve JS Otomatik Yükleme

- `assets/css/style.css` varsa ve modül açıksa, her sayfanın `<head>` bölümüne otomatik `<link>` olarak eklenir.
- `assets/js/app.js` varsa ve modül açıksa, her sayfanın `</body>` öncesine otomatik `<script>` olarak eklenir.
- URL'e `?v=1.0.0` eklenir, sürümü `module.json` içindeki `version` belirler. CSS/JS değiştirince `version` artır, ziyaretçiler eski dosyayı önbellekten çekmeye devam etmesin.
- Başka dosya adı kullanma (`main.css`, `custom.js` yüklenmez). Sadece bu iki yol tanınır.
- Tema seçimi fark etmez: default, azure ve ember hepsinde çalışır, çünkü kanca üç temaya da eklidir.

## 6. install.sql: Kendi Tablonu Kurmak

Modül ilk kez **açıldığında** `install.sql` dosyası koşar. Kurallar:

- İzinli ifadeler yalnızca: `CREATE TABLE IF NOT EXISTS ...` ve `INSERT IGNORE ...`. Diğer her şey (`DROP`, `DELETE`, `UPDATE`, `ALTER`) atlanır, sayılmaz.
- Noktalı virgülle ayrılır, `core/db.php` dosyasındaki migration mantığıyla aynı şekilde çalışır. Hatalı ifade atlanır, modül yine de açılır.
- Modül **kapatılınca tablolar silinmez.** Verin güvende kalır, tekrar açınca devam edersin. Buna "safe migrate" denir.
- Tablo adlarına modül ön eki koy: `mod_senin_slug_...`. Core tablolarıyla (`users`, `products`, `sales`) çakışma, başka modülle çakışma.
- Örnek:

```sql
CREATE TABLE IF NOT EXISTS `mod_benim_log` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

## 7. Admin Paneli: Toggle ve Modal

Admin > Ayarlar > Modüller sayfası, Entegrasyonlar sayfasının birebir klonudur:

- Karta tıklamak = aç/kapa (`mod_toggle`). Sayfa yenilenmez, rozet `Aktif`/`Pasif` döner.
- `Yapılandır` butonu = `module.json` içindeki `fields` dizisinden üretilen modal (`mod_save`). Kaydet de AJAX'tır.
- Tüm alanlar dolu değilse kartta `Yapılandırılmamış` rozeti çıkar. Zorunlu-olmayan bir alanın varsa bunu bil: boş bırakan kullanıcıda rozet görünür, bu normaldir.
- `fields` boşsa modal üretilmez, kartta "Yapılandırma gerektirmez" yazar.
- Arama kutusu ad + açıklama + slug içinde arar. Tip çipleri `type` alanından otomatik üretilir.
- `?open=slug` ile panele doğrudan modal açık girebilirsin: `/admin/modules.php?open=ornek-duyuru`.
- Yetki: sayfa `modules` kaynağına bağlıdır. Admin ve yönetici rollerinde varsayılan olarak açıktır (`permissions` seed). Diğer roller İzinler ekranından verilir.

## 7b. Tam Admin Sayfası ve Sidebar Kategorisi (Kademe 2)

Modal yetmezse modülün kendi sayfasını açar:

1. `module.json` dosyasına `"admin_page": true` yaz ve `admin.php` dosyası oluştur.
2. Menü linki için `"admin_menu": {"label": "...", "icon": "fa-..."}` ekle.
3. Özel kategori için `"admin_section": {"key": "...", "label": "...", "icon": "..."}` ekle. Yazmazsan link varsayılan "Modüller" grubuna düşer. Aynı `key` kullanan modüller aynı grupta toplanır.

Sayfan `/admin/module.php?module=senin-slug` adresinde panel temasıyla açılır. Kapalı modülün sayfası 404 verir. Yetki `modules` kaynağına bağlıdır.

`admin.php` dosyan `layout.php` ile `layout-end.php` arasına gömülür. Elinde hazır değişkenler: `$module` (manifest + `enabled` + `settings`), `$adminDb` (PDO), `$adminUser`. İlk satır guard olmalıdır:

```php
defined('NEXUS_BOOT') or die('Direct access denied.');
```

Formunu kendin işlersin, `action.php` gerekmez: POST sana geri gelir (`guard.php` CSRF'i zaten doğrular, formuna `<?= csrf_field() ?>` koyman yeter). Kaydetmek için `modules_save_settings($adminDb, 'senin-slug', $degerler)` kullan, kendi tablona yazarken prepared statement kullan. Canlı örnek: `ornek-duyuru/admin.php` (önizleme + form), `ornek-komisyon/admin.php` (özet + log tablosu).

Manifest beyanının yetmediği özel durumlarda `admin_menu` action'ına kendi HTML'ini basabilirsin, ama URL'lerin hep `/admin/module.php?module=...` formatında olsun, sidebar dışına link verme.

## 7d. Kapsam: Sidebar Görünürlüğü (Modül Sayfasından Düzenlenir)

Tam admin sayfası olan (`admin_page:true`) her modülün sidebar'da görünüp görünmeyeceği, kod dosyasına dokunmadan **Admin > Ayarlar > Modüller** ekranındaki göz ikonuyla açılıp kapatılır. Değer `modules.sidebar` kolonunda durur (`1`=göster, `0`=gizle), kapalıyken sayfan `/admin/module.php?module=...` adresinden çalışmaya devam eder, yalnızca menü linki basılmaz.

Kural: örnek ve yardımcı modüller varsayılan olarak sidebar'a çıkmaz; sayfalarına Modüller kartındaki dışa-aktar ikonundan gidilir. Sidebar, müşterinin her gün kullandığı modüllere ayrılmıştır. Kapsam değişikliği `mod_sidebar` üzerinden yürür ve `modules` yetkisi ister.

## 7e. Sistem Kaydına Yazma (Kapsam Genişletme)

`install.sql` yasağı aynen durur (yalnızca `mod_` önekli tablolar). Buna karşılık modül KODU, kendi iş akışı için çekirdek kayda yazabilir:

- Destek talebi açma/kapatma (`tickets` + `ticket_replies`): havale akışı gibi manuel onay gerektiren işlerde, Öde/Bakiye Yükle anında otomatik talep açılır. Kategori adı sabittir (`Havale Talebi` gibi), başlıkta sipariş numarası taşınır.
- Seçenek listesine get-or-create satırı: `ticket_categories` gibi seçenek tablolarında önce `name` ile `SELECT` yap, yoksa tek `INSERT` at. Aynı satırı ikinci kez yazma, DDL (`ALTER`/`DROP`) yapma.
- Kurallar: prepared statement zorunlu; sayfa yenilemede kopya kayıt çıkmaz (sipariş numarasıyla varlık kontrolü); kullanıcıya gösterilen her metin `e()` ile kaçar; otomatik ödeme tamamlama yoktur (manuel onay kuralı bölüm 7c madde 253 aynen geçerlidir).
- Aynı gateway `code` değerini iki modül beyan edemez: listede son yazan kazanır, sessiz çakışma olur. Üretim modülü varken aynı kodlu örnek modül kapalı tutulur.
- Örnek modül politikası: örnek modüller (`ornek-*`) dosyada durur ama üretimde kapalı tutulur; sayfalarına Modüller kartındaki dışa-aktar ikonundan gidilir.

## 7c. Kodla Ödeme Gateway'i (Kademe 3)

Yeni bir ödeme yöntemi için artık 10 core dosyasına dokunmuyorsun. Akış:

1. `module.json` dosyasına beyan yaz:
```json
"gateway": {"code": "havale", "label": "Havale / EFT", "color": "#0ea5e9"}
```
Modül açıkken yöntem `shop/payment` ekranında otomatik listelenir (ikonun manifest `icon` alanından gelir). Tek aktif yöntem seninkiyse müşteri direkt ödeme sayfana yönlendirilir.

2. Ödeme arayüzü: müşteri `/shop/module-pay?gateway=havale` adresine gelir. Core sepeti okur, `checkout_total` filtresini ve kuponu uygular, `payment_intents` kaydını `pending` açar, sonra `gateway_pay_havale` kancanı tetikler. Sen IBAN/form/karekod çizersin. İmza: `($intent, $sepetSatirlari, $toplam, $topupMu)`.

3. Tamamlama: iki yol var.
   - Otomatik (API'li): `callback/module.php?gateway=havale` adresine `gateway_callback_havale` işleyicisi yaz. İmzayı/tutarı doğrula, sonra `modules_gateway_complete($db, $siparisNo, $odemeNo)` çağır ve yanıtı kendin bas (`echo 'OK';` gibi, dosya senin yerine yanıt yazmaz). Bu helper intent'i `completed` yapar, kredi yüklemesiyse bakiyeyi işler, sepetse `purchase_consume_cart` + `purchase_finish` koşar (yani `order_created` dahil tüm kancalar ateşlenir). Çift tamamlama güvenlidir, ikinci çağrı "zaten tamamlanmış" döner.
   - Manuel (Havale/EFT gibi): callback yazma. Kendi `admin.php` sayfanda `payment_method='{kod}' AND status='pending'` intentleri listele, Onayla butonunda `modules_gateway_complete()`, İptal butonunda `status='cancelled'` yaz. Canlı örnek: `ornek-havale/admin.php`.

4. API anahtarı gerektiren gateway'lerde `payment_methods` filtresiyle `active=false` bas, anahtar yokken yöntemi gizle. Modal `fields` alanların anahtar formu olarak hazır gelir.

Kurallar: `code` yerleşik 8 kodla çakışamaz, `payment_intents.payment_method` 20 karakterdir. Asla ödemeyi doğrulamadan `modules_gateway_complete()` çağırma (manuel onayda doğrulama sensin, dekontu gözünle gör).

## 7f. Çoklu Dil: lang/ Sözlükleri ve Manifest Metinleri (Dil Kuralı)

Modülün iki ayrı metin katmanı vardır, ikisi de `modules/senin-slug/lang/tr.json` ve `lang/en.json` dosyalarından beslenir. Dosyalar yoksa her şey manifestteki ham haliyle (Türkçe) gösterilir, modül çalışmaya devam eder. Bozuk JSON yoksayılır.

Kural 1 — çalışma zamanı metinleri (`module_lang`): `module.php` ve `admin.php` içinde kullanıcıya basılan her metin `module_lang('senin-slug', 'anahtar', ['degisken' => $deger])` ile okunur. Zincir: aktif dil → `tr` → çekirdek `__()` → anahtar. `{degisken}` yer tutucuları `vars` dizisinden dolar. Örnek:

```php
$kapat = function_exists('module_lang') ? module_lang('ornek-duyuru', 'kapat') : 'Kapat';
echo '<button aria-label="' . e($kapat) . '">×</button>';
```

Kural 2 — manifest metinleri (`module_text`, alt çizgili anahtarlar): `module.json` içindeki ad, açıklama, alan etiketi/placeholder, seçenek etiketi, gateway etiketi, menü/bölüm etiketi çekirdek tarafından basılır. Bunları çevirmek için sözlüğe alt çizgiyle başlayan ayrılmış anahtarlar yazılır, `module.json` dosyasına dokunulmaz:

| Sözlük anahtarı | Basılan yer |
|---|---|
| `_name`, `_description` | Modüller kartındaki ad ve açıklama (arama dahil) |
| `_field_{alan}_label`, `_field_{alan}_placeholder` | Yapılandır modalındaki alan etiketi ve placeholder |
| `_option_{alan}_{deger}_label` | `select` seçenek etiketi (`{deger}` içindeki harf/rakam dışı karakter `_` olur) |
| `_gateway_label` | Ödeme ekranındaki yöntem etiketi |
| `_menu_label`, `_section_label` | Admin sidebar menü ve bölüm etiketi |

Çekirdek bu anahtarları `module_text('senin-slug', '_name', $manifestHamDeger)` kalıbıyla okur; zincir: aktif dil → `tr` → manifest ham değeri. Yani `_name` yazmazsan kartta manifest `name` aynen çıkar, hiçbir şey bozulmaz.

Kural 3 — isim çakışması yasaktır: alt çizgili anahtarları yalnızca yukarıdaki tablo için kullan. Kendi çalışma zamanı metinlerin asla `_` ile başlamasın, yoksa çekirdek onu manifest metni sanır.

Kural 4 — ayar DEĞERLERİ çevrilmez: `module_setting` ile okunan kullanıcı verisi (duyuru metni, IBAN, oran) olduğu gibi saklanır ve basılır. Çevrilen yalnızca arayüz etiketleridir, içerik değil.

Canlı örnek: `ornek-duyuru/lang/tr.json` + `en.json` dosyaları (ad, açıklama, 4 alan, 2 seçenek, `kapat` metni) ve `module.php` içindeki `module_lang('ornek-duyuru', 'kapat')` kullanımı.

## 8. Ayar Okuma: module_setting ve module_enabled

Modül kodun içinde ayarlarını `modules` tablosundan okursun:

```php
$metin = module_setting('ornek-duyuru', 'duyuru_metni', 'varsayılan');
$acikMi = module_enabled('ornek-duyuru');
```

- `module_setting($slug, $anahtar, $varsayılan = '')`: ayar yoksa varsayılanı döner. Dönen değer stringdir, kullanmadan önce `trim` + tip kontrolü yap.
- `module_enabled($slug)`: bool döner. Genelde gerekmez çünkü kapalı modülün `module.php` dosyası hiç yüklenmez. Çapraz modül kontrolü (bir modül diğerini okuyorsa) için vardır.
- Ayarlar `modules.settings` JSON kolonunda durur. Elle DB kurcalama, panelden kaydet.

## 9. Güvenlik Kuralları (Zorunlu)

1. Ekrana basılan her kullanıcı verisi `e()` ile kaçar: `echo e($metin);`. İstisnası yok.
2. Tüm DB sorguları PDO prepared statement ile yazılır: `$db->prepare(...)->execute([...])`. String birleştirme ile SQL kurma.
3. `module.php` dosyanda `$_GET`/`$_POST` ile state değiştirme. Form işlerin varsa `action.php` içine `case` açılır (core kuralı), modül dosyasından değil.
4. Dış URL'ye veri gönderiyorsan (webhook, API) `curl` zaman aşımı koy (`CURLOPT_TIMEOUT`), yanıtı logla.
5. `../../../` ile klasör dışına çıkma, `ROOT_PATH` dışına yazma, `eval` kullanma.
6. PHP dosyalarında yorum satırı yazılmaz (proje kuralı). Anlatman gerekeni `module.json` açıklamasına veya bu belgeye yaz.
7. DB erişiminde `nexus_db()` yerine `module_db($slug)` kullan. Koruma katmanı şunları zorlar: `DELETE`/`UPDATE` yalnızca `mod_` tablolarında ve `WHERE` koşullu; `INSERT` yalnızca `mod_` tablolarına; `DROP/ALTER/TRUNCATE/CREATE` ve çoklu ifade yasaktır. İhlal `ModuleGuardViolation` fırlatır.
8. `eval`, `exec`, `shell_exec`, `system`, backtick, `DROP/ALTER`, core tabloya `DELETE` yazma: güvenli mod açıkken (varsayılan) bu kalıpları içeren modül etkinleştirilemez. Risk rozeti modül kartında görünür.
9. Hook içine ağır iş koyma: 2 saniyeyi aşan hook `Yavaş hook` olarak loglanır. Ağır işleri kuyruğa böl veya önbelleğe al.
10. Ödeme callback uçların (`gateway_callback_*`) başına `module_ratelimit('odeme:'.$kod.':'.$ip, 120, 60)` koy.

## 10. Adım Adım: Kendi Modülünü Yap

1. `modules/ornek-duyuru` klasörünü kopyala, adını slug yap: `modules/fiyat-roz` gibi. Gateway yapacaksan `ornek-havale`, sepet matematiği için `ornek-komisyon` daha iyi şablondur.
2. `module.json` dosyasını düzenle: `name`, `description`, `version: 1.0.0`, `fields`.
3. `install.sql` dosyasını sil (tablona ihtiyacın yoksa) veya kendi tablonu yaz.
4. `module.php` dosyasını yaz: `add_action('mod_footer', ...)` veya `add_action('mod_head', ...)` ile çıktını üret.
5. `assets/` altındaki CSS/JS dosyalarını kendi kodunla değiştir veya sil (dosya yoksa yüklenmez, hata vermez).
6. Admin > Ayarlar > Modüller ekranını aç. Modülün listede görünmüyorsa: klasör adı = slug mı, `module.json` geçerli JSON mı, `version` formatı `x.y.z` mi kontrol et.
7. Kartta modüle tıkla (aktif et), `Yapılandır` ile alanları doldur, siteyi ziyaret et.
8. `version` alanını her yayınladığında artır (`1.0.0` -> `1.1.0`). DB'deki sürüm otomatik eşitlenir.

## 11. SSS ve Hata Ayıklama

- **Modül listede yok:** `module.json` kural ihlali vardır (bölüm 3). JSON'u bir doğrulayıcıdan geçir, `name` ve `version` alanlarını kontrol et.
- **Açtım ama çalışmıyor:** modül açık mı (yeşil `Aktif` rozeti), `module.php` dosyasında hook adı doğru mu (`mod_head`/`mod_footer`), ayar boş mu (boş metinle banner basılmaz)?
- **CSS/JS yüklenmiyor:** yol birebir `assets/css/style.css` ve `assets/js/app.js` mı, modül açık mı, `version` artırıldı mı (önbellek)?
- **Ayar kaydedilmiyor:** `select` alanına listede olmayan değer mi gönderiyorsun, `number` alana yazı mı yazıyorsun? `mod_save` bunları reddeder.
- **Tablo kurulmadı:** `install.sql` dosyasında yalnızca `CREATE TABLE IF NOT EXISTS` ve `INSERT IGNORE` koşar, üstelik hedef tablo `mod_` ile başlamak zorundadır (core tablolarına yazma yasaktır). Noktalı virgül ayraçtır, değerlerin içinde `;` kullanma.
- **Site hata veriyor:** hook içindeki hata loga yazılır, site çalışmaya devam eder. Önce modülü kapat, sonra kodunu düzelt. Suçlu modülü bulmak için hepsini kapatıp tek tek aç.
- **Admin sayfam 404:** modül açık mı, `admin_page:true` mi, `admin.php` dosyası var mı? Üçü de gerekli.
- **Sidebar linki yok:** `admin_menu.label` boş mu? Link yalnızca `admin_page:true` + `admin.php` varsa basılır.
- **Komisyon ekranda var ama çekimde yok:** `checkout_total` tüm akışlarda koşar (`buy_now` dahil). Fark görürsen modülün kapalı olduğu bir akışa bakıyorsundur.
- **Gateway'im listede yok:** `gateway.code` 8 yerleşik kodla çakışıyor mu, modül açık mı? `modules_gateway_find()` yalnızca açık modülleri listeler.
- **Kartta ad/açıklama çevrilmiyor:** `lang/en.json` dosyasında `_name` / `_description` anahtarı var mı? Manifest `name` ham basılır, çevirisi yalnızca alt çizgili anahtarla gelir (bölüm 7f kural 2).
- **Alan etiketi İngilizce'de Türkçe kalıyor:** anahtar formatı `_field_{alan}_{label|placeholder}` mı, alan `key` ile birebir eşleşiyor mu? `select` seçenekleri `_option_{alan}_{deger}_label` ister.
- **Kendi metnim `module_lang` ile gelmiyor:** anahtarın `_` ile başlamasın (o önek manifest metinlerine ayrılmıştır), dosya yolu `lang/{tr,en}.json` birebir olsun.
- **module-pay "arayüz sağlamıyor" diyor:** `gateway_pay_{kod}` işleyicinin adı kodla birebir eşleşmeli. Kodda büyük harf/boşluk olamaz.

## 12. Durum ve Sonraki Adımlar

Kademe 3 tamamlanan sistem: modal ayar + tam admin sayfası + sidebar kategorisi + `mod_head`/`mod_footer`/`header_menu_after`/`product_card_after` + `payment_methods`/`checkout_total`/`checkout_before`/`gateway_redirect` + `order_created`/`purchase_after` + `gateway_pay_*`/`gateway_callback_*` + asset + `install.sql` + çoklu dil (`lang/` sözlükleri, `module_lang`/`module_text`, bölüm 7f). Olası devam: modül pazarı (zip yükleme), modül bazında yetki (`module_{slug}` kaynağı), sürüm güncelleme bildirimi.
