<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
$duyuruMsg = null;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['ornek_duyuru_save'])) {
    $duyuruValues = [];
    foreach ($module['fields'] as $df) $duyuruValues[$df['key']] = $_POST['ornek-duyuru_' . $df['key']] ?? '';
    if (modules_save_settings($adminDb, 'ornek-duyuru', $duyuruValues)) {
        $duyuruMsg = ['type' => 'success', 'text' => 'Duyuru ayarları kaydedildi.'];
        $allModules = modules_all($adminDb);
        $module = $allModules['ornek-duyuru'] ?? $module;
    } else {
        $duyuruMsg = ['type' => 'error', 'text' => 'Kayıt başarısız. Alanları kontrol edin.'];
    }
}
$duyuruMetin = trim((string)($module['settings']['duyuru_metni'] ?? ''));
$duyuruBaglanti = trim((string)($module['settings']['baglanti'] ?? ''));
$duyuruRenk = trim((string)($module['settings']['arka_plan'] ?? ''));
if (!preg_match('/^#[0-9a-fA-F]{6}$/', $duyuruRenk)) $duyuruRenk = '#8b5cf6';
$duyuruKonum = ($module['settings']['konum'] ?? 'ust') === 'alt' ? 'alt' : 'ust';
?>
<?php if ($duyuruMsg): ?>
<div style="background:<?= $duyuruMsg['type']==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;border:1px solid <?= $duyuruMsg['type']==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;color:<?= $duyuruMsg['type']==='success'?'#4ade80':'#f87171' ?>;padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;margin-bottom:20px;">
    <?= e($duyuruMsg['text']) ?>
</div>
<?php endif; ?>
<div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-eye" style="color:#8b5cf6;margin-right:8px;"></i> Canlı Önizleme</span>
    </div>
    <?php if ($duyuruMetin !== ''): ?>
    <div style="background:<?= e($duyuruRenk) ?>;border-radius:10px;padding:10px 16px;color:#fff;font-size:13px;font-weight:700;text-align:center;">
        <?php if ($duyuruBaglanti !== ''): ?><a href="<?= e($duyuruBaglanti) ?>" style="color:#fff;text-decoration:underline;"><?= e($duyuruMetin) ?></a><?php else: ?><?= e($duyuruMetin) ?><?php endif; ?>
        <span style="display:block;font-size:10px;font-weight:600;opacity:.8;margin-top:4px;">Konum: <?= $duyuruKonum === 'ust' ? 'Üstte sabit' : 'Altta sabit' ?></span>
    </div>
    <?php else: ?>
    <p style="font-size:13px;color:var(--muted);">Duyuru metni boş. Aşağıdaki formu doldurup kaydedin, bant sitede görünecektir.</p>
    <?php endif; ?>
</div>
<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-sliders" style="color:#8b5cf6;margin-right:8px;"></i> Bant Ayarları</span>
    </div>
    <form method="POST">
        <?= csrf_field() ?>
        <div style="display:grid;gap:16px;">
            <?php foreach ($module['fields'] as $df): ?>
            <?php $dfVal = $module['settings'][$df['key']] ?? ''; ?>
            <div>
                <label style="display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= e($df['label']) ?></label>
                <?php if (($df['type'] ?? '') === 'select'): ?>
                <select name="ornek-duyuru_<?= e($df['key']) ?>" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                    <?php foreach ($df['options'] as $dopt): ?>
                    <option value="<?= e($dopt['value']) ?>" <?= $dfVal === $dopt['value'] ? 'selected' : '' ?>><?= e($dopt['label']) ?></option>
                    <?php endforeach; ?>
                </select>
                <?php else: ?>
                <input type="text" name="ornek-duyuru_<?= e($df['key']) ?>" value="<?= e($dfVal) ?>" placeholder="<?= e($df['placeholder'] ?? '') ?>" style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;color:var(--text);font-size:13px;outline:none;">
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <button type="submit" name="ornek_duyuru_save" value="1" class="btn-admin btn-primary-admin" style="margin-top:18px;">
            <i class="fa-solid fa-floppy-disk"></i> Kaydet
        </button>
    </form>
</div>
