(function(){document.addEventListener('click',function(ev){var b=ev.target.closest?ev.target.closest('.vx-duyuru-kapat'):null;if(!b)return;var bar=b.closest('.vx-duyuru');if(bar)bar.remove();});})();
