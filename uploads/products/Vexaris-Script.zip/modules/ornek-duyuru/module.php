<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
add_action('mod_footer', function () {
    $metin = trim((string)module_setting('ornek-duyuru', 'duyuru_metni', ''));
    if ($metin === '') return;
    $baglanti = trim((string)module_setting('ornek-duyuru', 'baglanti', ''));
    $renk = trim((string)module_setting('ornek-duyuru', 'arka_plan', ''));
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $renk)) $renk = '#8b5cf6';
    $konum = module_setting('ornek-duyuru', 'konum', 'ust');
    if ($konum !== 'alt') $konum = 'ust';
    $icerik = e($metin);
    if ($baglanti !== '') $icerik = '<a href="' . e($baglanti) . '" class="vx-duyuru-link">' . e($metin) . '</a>';
    $kapat = function_exists('module_lang') ? module_lang('ornek-duyuru', 'kapat') : 'Kapat';
    echo '<div class="vx-duyuru vx-duyuru-' . $konum . '" style="background:' . e($renk) . ';"><span>' . $icerik . '</span><button type="button" class="vx-duyuru-kapat" aria-label="' . e($kapat) . '">×</button></div>';
});
