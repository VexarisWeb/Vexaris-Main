<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
$havaleMsg = null;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['havale_intent'], $_POST['havale_islem'])) {
    $intentId = trim((string)$_POST['havale_intent']);
    $islem = trim((string)$_POST['havale_islem']);
    try {
        $chk = $adminDb->prepare("SELECT * FROM payment_intents WHERE order_id=? AND payment_method='havale' AND status='pending' LIMIT 1");
        $chk->execute([$intentId]);
        $row = $chk->fetch();
        if (!$row) {
            $havaleMsg = ['type' => 'error', 'text' => 'Bekleyen sipariş bulunamadı.'];
        } elseif ($islem === 'onayla') {
            [$ok, $msg] = modules_gateway_complete($adminDb, $intentId, 'manuel-onay');
            $havaleMsg = ['type' => $ok ? 'success' : 'error', 'text' => $msg];
        } elseif ($islem === 'iptal') {
            $adminDb->prepare("UPDATE payment_intents SET status='cancelled' WHERE order_id=?")->execute([$intentId]);
            $havaleMsg = ['type' => 'success', 'text' => 'Sipariş iptal edildi.'];
        }
    } catch (\Throwable $e) {
        $havaleMsg = ['type' => 'error', 'text' => 'İşlem hatası.'];
    }
}
try {
    $bekleyen = $adminDb->query("SELECT `order_id`,`user_id`,`total_amount`,`created_at` FROM payment_intents WHERE payment_method='havale' AND status='pending' ORDER BY `id` DESC LIMIT 50")->fetchAll();
    $gecmis = $adminDb->query("SELECT `order_id`,`user_id`,`total_amount`,`status`,`created_at` FROM payment_intents WHERE payment_method='havale' AND status IN ('completed','cancelled') ORDER BY `id` DESC LIMIT 20")->fetchAll();
} catch (\Throwable $e) { $bekleyen = []; $gecmis = []; }
?>
<?php if ($havaleMsg): ?>
<div style="background:<?= $havaleMsg['type']==='success'?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)' ?>;border:1px solid <?= $havaleMsg['type']==='success'?'rgba(34,197,94,.3)':'rgba(239,68,68,.3)' ?>;color:<?= $havaleMsg['type']==='success'?'#4ade80':'#f87171' ?>;padding:12px 18px;border-radius:12px;font-size:14px;font-weight:600;margin-bottom:20px;">
    <?= e($havaleMsg['text']) ?>
</div>
<?php endif; ?>
<div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-hourglass-half" style="color:#0ea5e9;margin-right:8px;"></i> Onay Bekleyenler (<?= count($bekleyen) ?>)</span>
    </div>
    <?php if (empty($bekleyen)): ?>
    <p style="font-size:13px;color:var(--muted);">Bekleyen havale siparişi yok.</p>
    <?php else: ?>
    <div style="display:grid;gap:10px;">
        <?php foreach ($bekleyen as $b): ?>
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:12px 16px;">
            <div style="flex:1;min-width:180px;">
                <div style="font-size:13px;font-weight:800;font-family:monospace;"><?= e($b['order_id']) ?></div>
                <div style="font-size:11px;color:var(--muted);">Kullanıcı #<?= (int)$b['user_id'] ?> · <?= e($b['created_at']) ?></div>
            </div>
            <div style="font-size:15px;font-weight:900;">₺<?= e(number_format((float)$b['total_amount'], 2, ',', '.')) ?></div>
            <form method="POST" style="display:flex;gap:8px;">
                <?= csrf_field() ?>
                <input type="hidden" name="havale_intent" value="<?= e($b['order_id']) ?>">
                <button type="submit" name="havale_islem" value="onayla" class="btn-admin btn-primary-admin" style="padding:8px 14px;font-size:12px;"><i class="fa-solid fa-check"></i> Onayla</button>
                <button type="submit" name="havale_islem" value="iptal" class="btn-admin btn-ghost-admin" style="padding:8px 14px;font-size:12px;">İptal</button>
            </form>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-clock-rotate-left" style="color:#0ea5e9;margin-right:8px;"></i> Geçmiş</span>
    </div>
    <?php if (empty($gecmis)): ?>
    <p style="font-size:13px;color:var(--muted);">Henüz işlem yok.</p>
    <?php else: ?>
    <div style="overflow-x:auto;">
    <table style="width:100%;font-size:12px;border-collapse:collapse;">
        <thead><tr style="color:var(--muted);text-align:left;border-bottom:1px solid var(--border);">
            <th style="padding:8px;">Sipariş</th><th style="padding:8px;">Tutar</th><th style="padding:8px;">Durum</th><th style="padding:8px;">Tarih</th>
        </tr></thead>
        <tbody>
        <?php foreach ($gecmis as $g): ?>
        <tr style="border-bottom:1px solid var(--border);">
            <td style="padding:8px;font-family:monospace;"><?= e($g['order_id']) ?></td>
            <td style="padding:8px;">₺<?= e(number_format((float)$g['total_amount'], 2, ',', '.')) ?></td>
            <td style="padding:8px;"><?= e($g['status']) ?></td>
            <td style="padding:8px;"><?= e($g['created_at']) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>
