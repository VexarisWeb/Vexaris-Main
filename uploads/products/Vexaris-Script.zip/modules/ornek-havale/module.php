<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
add_action('gateway_pay_havale', function ($intent, $items = [], $total = 0, $isTopup = false) {
    $iban = trim((string)module_setting('ornek-havale', 'iban', ''));
    $alici = trim((string)module_setting('ornek-havale', 'alici', ''));
    $not = trim((string)module_setting('ornek-havale', 'aciklama', ''));
    $orderId = (string)($intent['order_id'] ?? '');
    echo '<div style="background:#0f1520;border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:24px;display:flex;flex-direction:column;gap:12px;font-size:14px;">';
    echo '<div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#94a3b8;">Alıcı</span><strong>' . ($alici !== '' ? e($alici) : '<span style="color:#f87171;">Tanımlanmadı (modül ayarları)</span>') . '</strong></div>';
    echo '<div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#94a3b8;">IBAN</span><strong style="font-family:monospace;">' . ($iban !== '' ? e($iban) : '<span style="color:#f87171;">Tanımlanmadı</span>') . '</strong></div>';
    echo '<div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#94a3b8;">Tutar</span><strong style="color:#fbbf24;">₺' . e(number_format((float)$total, 2, ',', '.')) . '</strong></div>';
    echo '<div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#94a3b8;">Açıklama</span><strong style="font-family:monospace;">' . e($orderId) . '</strong></div>';
    if ($not !== '') echo '<p style="color:#94a3b8;font-size:12px;margin:4px 0 0;">' . e($not) . '</p>';
    echo '<p style="color:#4ade80;font-size:12px;font-weight:700;margin:4px 0 0;">Transferi tamamladıktan sonra siparişiniz admin onayıyla otomatik tanımlanır.</p>';
    echo '</div>';
});
