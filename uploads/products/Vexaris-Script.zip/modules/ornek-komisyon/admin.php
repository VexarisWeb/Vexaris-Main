<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
$komRows = [];
$komTotal = 0;
$komSum = 0.0;
try {
    $komRows = $adminDb->query("SELECT `id`,`sale_count`,`total_paid`,`created_at` FROM mod_ornek_komisyon_log ORDER BY `id` DESC LIMIT 50")->fetchAll();
    $komAgg = $adminDb->query("SELECT COUNT(*) AS c, COALESCE(SUM(`total_paid`),0) AS s FROM mod_ornek_komisyon_log")->fetch();
    $komTotal = (int)($komAgg['c'] ?? 0);
    $komSum = (float)($komAgg['s'] ?? 0);
} catch (\Throwable $e) {}
$komOran = trim((string)($module['settings']['oran'] ?? '0'));
$komSabit = trim((string)($module['settings']['sabit_ucret'] ?? '0'));
?>
<div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-chart-line" style="color:#f59e0b;margin-right:8px;"></i> Özet</span>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;">
        <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:14px;text-align:center;">
            <div style="font-size:20px;font-weight:900;"><?= e($komOran === '' ? '0' : $komOran) ?>%</div>
            <div style="font-size:11px;color:var(--muted);">Oran + ₺<?= e($komSabit === '' ? '0' : $komSabit) ?> sabit</div>
        </div>
        <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:14px;text-align:center;">
            <div style="font-size:20px;font-weight:900;"><?= $komTotal ?></div>
            <div style="font-size:11px;color:var(--muted);">Loglanan sipariş</div>
        </div>
        <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:14px;text-align:center;">
            <div style="font-size:20px;font-weight:900;">₺<?= e(number_format($komSum, 2, ',', '.')) ?></div>
            <div style="font-size:11px;color:var(--muted);">Toplam ciro</div>
        </div>
    </div>
    <p style="font-size:11px;color:var(--dim);margin-top:12px;">Oran ve sabit ücret Admin &gt; Ayarlar &gt; Modüller &gt; Örnek Komisyon &gt; Yapılandır penceresinden değiştirilir.</p>
</div>
<div class="admin-card">
    <div class="admin-card-header">
        <span class="admin-card-title"><i class="fa-solid fa-list" style="color:#f59e0b;margin-right:8px;"></i> Son Siparişler</span>
    </div>
    <?php if (empty($komRows)): ?>
    <p style="font-size:13px;color:var(--muted);">Henüz sipariş loglanmadı. Bir test siparişi tamamlayın.</p>
    <?php else: ?>
    <div style="overflow-x:auto;">
    <table style="width:100%;font-size:12px;border-collapse:collapse;">
        <thead><tr style="color:var(--muted);text-align:left;border-bottom:1px solid var(--border);">
            <th style="padding:8px;">#</th><th style="padding:8px;">Satır</th><th style="padding:8px;">Tutar</th><th style="padding:8px;">Tarih</th>
        </tr></thead>
        <tbody>
        <?php foreach ($komRows as $kr): ?>
        <tr style="border-bottom:1px solid var(--border);">
            <td style="padding:8px;"><?= (int)$kr['id'] ?></td>
            <td style="padding:8px;"><?= (int)$kr['sale_count'] ?></td>
            <td style="padding:8px;">₺<?= e(number_format((float)$kr['total_paid'], 2, ',', '.')) ?></td>
            <td style="padding:8px;"><?= e($kr['created_at']) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>
