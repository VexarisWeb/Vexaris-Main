<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
add_filter('checkout_total', function ($total, $items = []) {
    $oran = trim((string)module_setting('ornek-komisyon', 'oran', '0'));
    $sabit = trim((string)module_setting('ornek-komisyon', 'sabit_ucret', '0'));
    if ($oran !== '' && is_numeric($oran) && (float)$oran > 0) $total = (float)$total * (1 + (float)$oran / 100);
    if ($sabit !== '' && is_numeric($sabit) && (float)$sabit > 0) $total = (float)$total + (float)$sabit;
    return round((float)$total, 2);
});
add_action('order_created', function ($order) {
    try {
        $db = module_db('ornek-komisyon');
    } catch (\Throwable $e) { return; }
    try {
        $st = $db->prepare("INSERT INTO mod_ornek_komisyon_log (`sale_count`,`total_paid`) VALUES (?,?)");
        $st->execute([(int)($order['sale_count'] ?? 0), (float)($order['total_paid'] ?? 0)]);
    } catch (\Throwable $e) {}
});
