<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
license_gate_require('core');

$siteName = 'Mağaza';
$db = nexus_db();
if ($db) {
    try {
        $snStmt = $db->prepare("SELECT value FROM settings WHERE `key`='site_name' LIMIT 1");
        $snStmt->execute();
        $snVal = $snStmt->fetchColumn();
        if ($snVal) $siteName = $snVal;
    } catch (\Exception $e) {}
}
$pageTitle = 'Ödeme Başarısız';
$vxTailwind = true;
theme_header();
?>
<main class="flex-1 max-w-7xl mx-auto px-4 py-16 w-full text-center">
    <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-red-900/30 border border-red-700 mb-6">
        <i class="fa-solid fa-xmark text-4xl text-red-400"></i>
    </div>
    <h1 class="text-3xl font-black mb-2">Ödeme Başarısız</h1>
    <p class="text-slate-400 mb-2">Ödeme işlemi tamamlanamadı veya iptal edildi.</p>
    <p class="text-slate-500 text-sm mb-8">Tekrar denemek için mağazaya dönün.</p>
    <a href="/products" class="btn-shop-indigo inline-flex items-center gap-2 font-bold px-6 py-3 rounded-xl transition" style="box-shadow:0 4px 0 #3730a3;">
        <i class="fa-solid fa-store"></i> Mağazaya Dön
    </a>
</main>
<?php theme_footer(); ?>
