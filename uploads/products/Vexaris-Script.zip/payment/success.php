<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
license_gate_require('core');

$db   = nexus_db();
$me   = auth_check() ? auth_user() : null;
$orderId = trim($_GET['order_id'] ?? '');

$success = false;
if ($db && $orderId && $me) {
    $st = $db->prepare("SELECT status FROM payment_intents WHERE order_id=? AND user_id=? LIMIT 1");
    $st->execute([$orderId, (int)$me['id']]);
    $row = $st->fetch();
    if ($row && $row['status'] === 'completed') {
        $success = true;
    }
}

$siteName = 'Mağaza';
if ($db) {
    try {
        $snStmt = $db->prepare("SELECT value FROM settings WHERE `key`='site_name' LIMIT 1");
        $snStmt->execute();
        $snVal = $snStmt->fetchColumn();
        if ($snVal) $siteName = $snVal;
    } catch (\Exception $e) {}
}
$pageTitle = 'Ödeme Başarılı';
$vxTailwind = true;
theme_header();
?>
<main class="flex-1 max-w-7xl mx-auto px-4 py-16 w-full text-center">
    <?php if ($success): ?>
    <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-900/30 border border-green-700 mb-6">
        <i class="fa-solid fa-check text-4xl text-green-400"></i>
    </div>
    <h1 class="text-3xl font-black mb-2">Ödeme Başarılı!</h1>
    <p class="text-slate-400 mb-8">Satın alma işleminiz tamamlandı. Lisans anahtarlarınızı <strong>Satın Aldıklarım</strong> sayfasından görebilirsiniz.</p>
    <a href="/products?tab=purchases" class="btn-shop-indigo inline-flex items-center gap-2 font-bold px-6 py-3 rounded-xl transition" style="box-shadow:0 4px 0 #3730a3;">
        <i class="fa-solid fa-box-archive"></i> Satın Aldıklarım
    </a>
    <?php else: ?>
    <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-yellow-900/30 border border-yellow-700 mb-6">
        <i class="fa-solid fa-clock text-4xl text-yellow-400"></i>
    </div>
    <h1 class="text-3xl font-black mb-2">İşlem Beklemede</h1>
    <p class="text-slate-400 mb-8">Ödemeniz alındı ancak işlemin tamamlanması birkaç saniye sürebilir. Sayfayı yenileyin veya Satın Aldıklarım sayfasını kontrol edin.</p>
    <a href="/products?tab=purchases" class="btn-shop-indigo inline-flex items-center gap-2 font-bold px-6 py-3 rounded-xl transition" style="box-shadow:0 4px 0 #3730a3;">
        <i class="fa-solid fa-rotate"></i> Kontrol Et
    </a>
    <?php endif; ?>
</main>
<?php theme_footer(); ?>
