<?php
include 'core/init.php';
theme_load('reset-password');