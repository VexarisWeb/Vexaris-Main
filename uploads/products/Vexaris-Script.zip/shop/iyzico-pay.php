<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/actions/bootstrap-action.php';
require_once ROOT_PATH . '/core/iyzico.php';

$db = nexus_db();
$me = auth_check() ? auth_user() : null;
if (!$me) { header('Location: /login', true, 302); exit; }
license_gate_require('core');
if (!iyzico_is_ready($db)) {
    header('Location: /shop/payment?flash=' . urlencode('error:'.__('bshop.iyzico_off')), true, 302);
    exit;
}

$uid = (int)$me['id'];

$iyCur = strtoupper(iyzico_currency($db));

$topupAmount = (float)($_GET['topup'] ?? 0);
$topupAmount = is_finite($topupAmount) ? round($topupAmount, 2) : 0;
if ($topupAmount > 100000) $topupAmount = 100000;
$isTopup     = $topupAmount >= topup_min_amount();

if ($isTopup && !plan_payments_allowed($db)) { header('Location: /shop/payment?flash=' . urlencode('error:'.__('plan.payments_paused')), true, 302); exit; }
if ($isTopup) {
    $total   = round($topupAmount, 2);
    $chTotal = $iyCur === store_currency() ? $total : fx_convert($total, store_currency(), $iyCur);
    $orderId = 'TOPUP-' . $uid . '-' . time() . '-' . bin2hex(random_bytes(4));
    $basket  = [[__('panel.tx_topup'), number_format($chTotal, 2, '.', ''), 1]];
    try {
        $db->prepare('INSERT INTO payment_intents (user_id,order_id,total_amount,currency,status,payment_method) VALUES (?,?,?,?,"pending","iyzico")')
           ->execute([$uid, $orderId, $chTotal, $iyCur]);
    } catch (\PDOException $e) {
        error_log('[iyzico] topup intent: ' . $e->getMessage());
        header('Location: /shop/payment?flash=' . urlencode('error:'.__('bshop.pay_fail')), true, 302);
        exit;
    }
} else {
    $cartStmt = $db->prepare(
        'SELECT c.product_id,c.quantity,p.name,p.price,p.discount_percent FROM cart c
         JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"'
    );
    $cartStmt->execute([$uid]);
    $items = $cartStmt->fetchAll();
    if (empty($items)) {
        header('Location: /products?flash=' . urlencode('error:'.__('cart.empty_short')), true, 302);
        exit;
    }
    require_once ROOT_PATH . '/core/purchase.php';
    foreach ($items as $balChk) {
        $freeQtyB = product_effective_price($balChk['price'] ?? 0, $balChk['discount_percent'] ?? 0) <= 0 ? 1 : (int)($balChk['quantity'] ?? 1);
        if (!stock_available($db, (int)$balChk['product_id'], $freeQtyB)) {
            header('Location: /products?flash=' . urlencode('error:'.__('bshop.out_of_stock', ['name' => ($balChk['name'] ?? '')])), true, 302);
            exit;
        }
    }

    $items = purchase_filter_owned($db, $uid, $items);
    if (empty($items)) {
        header('Location: /products?flash=' . urlencode('error:'.__('bshop.already_owned')), true, 302);
        exit;
    }
    $total = cart_effective_total($items);
    if (function_exists('apply_filters')) $total = (float)apply_filters('checkout_total', $total, $items);
    if ($total <= 0) {
        header('Location: /products?flash=' . urlencode('error:'.__('bshop.free_no_pay')), true, 302);
        exit;
    }
    $appliedCoupon = coupon_resolve_for_pay($db, $_SESSION['applied_coupon'] ?? null, $uid);
    if ($appliedCoupon) {
        $total = max(0, $total - coupon_discount_for_total($appliedCoupon, $total));
    }
    if ($total <= 0) {
        header('Location: /products?flash=' . urlencode('error:'.__('bshop.free_no_pay')), true, 302);
        exit;
    }
    if (!plan_payments_allowed($db)) { header('Location: /shop/payment?flash=' . urlencode('error:'.__('plan.payments_paused')), true, 302); exit; }
    $orderId = 'SP-' . $uid . '-' . time() . '-' . bin2hex(random_bytes(4));
    require_once ROOT_PATH . '/core/purchase.php';
    $intentSnapshot = purchase_snapshot_build($items, $appliedCoupon);
    $chTotal = $iyCur === store_currency() ? $total : fx_convert($total, store_currency(), $iyCur);
    try {
        $db->prepare('INSERT INTO payment_intents (user_id,order_id,total_amount,currency,items_snapshot,status,payment_method) VALUES (?,?,?,?,?,"pending","iyzico")')
           ->execute([$uid, $orderId, $chTotal, $iyCur, $intentSnapshot]);
    } catch (\PDOException $e) {
        error_log('[iyzico] cart intent: ' . $e->getMessage());
        header('Location: /shop/payment?flash=' . urlencode('error:'.__('bshop.pay_fail')), true, 302);
        exit;
    }
    $basket = [];
    foreach ($items as $it) $basket[] = [$it['name'], number_format(fx_convert(product_effective_price($it['price'], $it['discount_percent'] ?? 0), store_currency(), $iyCur), 2, '.', ''), (int)$it['quantity']];
}

try {
    $form = iyzico_create_payment($db, $orderId, $me['email'], $me['username'], $chTotal, $basket);
} catch (\Exception $e) {
    error_log('[iyzico] Form oluşturulamadı: ' . $e->getMessage());
    header('Location: /shop/payment?flash=' . urlencode('error:'.__('bshop.pay_page_fail')), true, 302);
    exit;
}

$pageTitle = 'Ödeme';
$vxTailwind = true;
theme_header();
?>
<style>
.iyzico-wrap{max-width:760px;margin:0 auto;background:#0f1520;border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:24px;}
.iyzico-wrap .responsive{width:100%;}
#iyzipay-checkout-form iframe{width:100%!important;height:850px!important;border:0;min-height:850px;}
</style>

<main class="flex-1 max-w-3xl mx-auto px-4 py-8 w-full">
    <div class="mb-8" style="text-align:center;">
        <h1 class="text-2xl font-black" style="display:flex;align-items:center;justify-content:center;gap:10px;">
            <i class="fa-solid fa-credit-card text-orange-500"></i><span><?= __('bshop.gateway_pay', ['label' => 'iyzico']) ?></span>
        </h1>
        <p class="text-slate-500 text-sm mt-1" style="text-align:center;">Toplam: <strong class="text-yellow-400"><?= fmt_money($total) ?></strong></p>
    </div>

    <div class="iyzico-wrap">
        <div id="iyzipay-checkout-form" class="responsive"><?= $form['content'] ?></div>
    </div>

    <div style="text-align:center;margin-top:24px;">
        <a href="/products" class="text-slate-500 hover:text-slate-300 text-sm" style="display:inline-flex;align-items:center;gap:6px;">
            <i class="fa-solid fa-arrow-left"></i> Mağazaya Dön
        </a>
    </div>
</main>

<?php theme_footer(); ?>
