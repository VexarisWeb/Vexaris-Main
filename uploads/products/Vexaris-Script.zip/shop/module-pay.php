<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/actions/bootstrap-action.php';

$db = nexus_db();
$me = auth_check() ? auth_user() : null;
if (!$me) { header('Location: /login', true, 302); exit; }
license_gate_require('core');

$gwCode = trim($_GET['gateway'] ?? '');
$gw = function_exists('modules_gateway_find') ? modules_gateway_find($gwCode, $db) : null;
if (!$gw) {
    header('Location: /shop/payment?flash=' . urlencode('error:'.__('bshop.unknown_method')), true, 302);
    exit;
}

$uid = (int)$me['id'];
$topupAmount = (float)($_GET['topup'] ?? 0);
$topupAmount = is_finite($topupAmount) ? round($topupAmount, 2) : 0;
if ($topupAmount > 100000) $topupAmount = 100000;
$isTopup = $topupAmount >= topup_min_amount();
$items = [];

if ($isTopup && !plan_payments_allowed($db)) { header('Location: /shop/payment?flash=' . urlencode('error:'.__('plan.payments_paused')), true, 302); exit; }
if ($isTopup) {
    $total = round($topupAmount, 2);
    $orderId = 'TOPUP-' . $uid . '-' . time() . '-' . bin2hex(random_bytes(4));
    $intentCur = store_currency();
    $intentTotal = $total;
    if ($gwCode === 'havale' && $intentCur !== 'TRY') { $intentTotal = fx_convert($total, $intentCur, 'TRY'); $intentCur = 'TRY'; }
    try {
        $db->prepare('INSERT INTO payment_intents (user_id,order_id,total_amount,currency,status,payment_method) VALUES (?,?,?,?,"pending",?)')
           ->execute([$uid, $orderId, $intentTotal, $intentCur, $gwCode]);
    } catch (\PDOException $e) {
        error_log('[modpay] topup intent: ' . $e->getMessage());
        header('Location: /shop/payment?flash=' . urlencode('error:'.__('bshop.pay_fail')), true, 302);
        exit;
    }
} else {
    $cartStmt = $db->prepare('SELECT c.product_id,c.quantity,p.name,p.price,p.discount_percent FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"');
    $cartStmt->execute([$uid]);
    $items = $cartStmt->fetchAll();
    if (empty($items)) {
        header('Location: /products?flash=' . urlencode('error:'.__('cart.empty_short')), true, 302);
        exit;
    }
    require_once ROOT_PATH . '/core/purchase.php';
    foreach ($items as $balChk) {
        $freeQtyB = product_effective_price($balChk['price'] ?? 0, $balChk['discount_percent'] ?? 0) <= 0 ? 1 : (int)($balChk['quantity'] ?? 1);
        if (!stock_available($db, (int)$balChk['product_id'], $freeQtyB)) {
            header('Location: /products?flash=' . urlencode('error:'.__('bshop.out_of_stock', ['name' => ($balChk['name'] ?? '')])), true, 302);
            exit;
        }
    }

    $items = purchase_filter_owned($db, $uid, $items);
    if (empty($items)) {
        header('Location: /products?flash=' . urlencode('error:'.__('bshop.already_owned')), true, 302);
        exit;
    }
    $total = cart_effective_total($items);
    if (function_exists('apply_filters')) $total = (float)apply_filters('checkout_total', $total, $items);
    $appliedCoupon = coupon_resolve_for_pay($db, $_SESSION['applied_coupon'] ?? null, $uid);
    if ($appliedCoupon) {
        $total = max(0, $total - coupon_discount_for_total($appliedCoupon, $total));
    }
    if ($total <= 0) {
        header('Location: /shop/payment', true, 302);
        exit;
    }
    if (!plan_payments_allowed($db)) { header('Location: /shop/payment?flash=' . urlencode('error:'.__('plan.payments_paused')), true, 302); exit; }
    $orderId = 'SP-' . $uid . '-' . time() . '-' . bin2hex(random_bytes(4));
    require_once ROOT_PATH . '/core/purchase.php';
    $intentSnapshot = purchase_snapshot_build($items, $appliedCoupon);
    $intentCur = store_currency();
    $intentTotal = $total;
    if ($gwCode === 'havale' && $intentCur !== 'TRY') { $intentTotal = fx_convert($total, $intentCur, 'TRY'); $intentCur = 'TRY'; }
    try {
        $db->prepare('INSERT INTO payment_intents (user_id,order_id,total_amount,currency,items_snapshot,status,payment_method) VALUES (?,?,?,?,?,"pending",?)')
           ->execute([$uid, $orderId, $intentTotal, $intentCur, $intentSnapshot, $gwCode]);
    } catch (\PDOException $e) {
        error_log('[modpay] cart intent: ' . $e->getMessage());
        header('Location: /shop/payment?flash=' . urlencode('error:'.__('bshop.pay_fail')), true, 302);
        exit;
    }
}

$piStmt = $db->prepare("SELECT * FROM payment_intents WHERE order_id=? LIMIT 1");
$piStmt->execute([$orderId]);
$intent = $piStmt->fetch();

$activePage = 'payment';
$pageTitle = __('bshop.gateway_pay', ['label' => $gw['label']]);
$vxTailwind = true;
theme_header();
?>
<main class="flex-1 max-w-2xl mx-auto px-4 py-8 w-full">
    <div class="mb-6 text-center">
        <h1 class="text-2xl font-black flex items-center justify-center gap-2">
            <i class="<?= e($gw['iconPrefix']) ?> <?= e($gw['icon']) ?>" style="color:<?= e($gw['color']) ?>;"></i>
            <?= __('bshop.gateway_pay', ['label' => e($gw['label'])]) ?>
        </h1>
        <p class="text-slate-500 text-sm mt-1">Sipariş: <strong><?= e($orderId) ?></strong> · Toplam: <strong class="text-yellow-400"><?= fmt_money($total) ?></strong></p>
    </div>
    <?php if (function_exists('has_action') && has_action('gateway_pay_' . $gwCode)): ?>
        <?php do_action('gateway_pay_' . $gwCode, $intent, $items, $total, $isTopup); ?>
    <?php else: ?>
        <div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:12px;padding:20px;text-align:center;color:#f87171;font-size:13px;font-weight:600;">
            <?= __('bshop.no_iface', ['hook' => '<code>gateway_pay_' . e($gwCode) . '</code>']) ?>
        </div>
    <?php endif; ?>
    <div class="text-center mt-6">
        <a href="/shop/payment" class="text-slate-500 hover:text-slate-300 text-sm transition"><?= __('bshop.other_method') ?></a>
    </div>
</main>
<?php theme_footer(); ?>
