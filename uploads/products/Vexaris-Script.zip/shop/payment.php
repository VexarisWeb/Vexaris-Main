<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/actions/bootstrap-action.php';

$db = nexus_db();
$me = auth_check() ? auth_user() : null;
if (!$me) { header('Location: /login', true, 302); exit; }
license_gate_require('core');

$uid = (int)$me['id'];
$planLocked = !plan_payments_allowed($db);

/* Sepet kontrol */
$cartStmt = $db->prepare(
    'SELECT c.product_id,c.quantity,p.name,p.price,p.discount_percent,p.image_url,p.license_prefix
     FROM cart c JOIN products p ON p.id=c.product_id
     WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"'
);
$cartStmt->execute([$uid]);
$cartItems = $cartStmt->fetchAll();

if (empty($cartItems)) {
    header('Location: /products?flash=' . urlencode('error:Sepetiniz boş.'), true, 302);
    exit;
}

require_once ROOT_PATH . '/core/purchase.php';
$cartItems = purchase_filter_owned($db, $uid, $cartItems);

if (empty($cartItems)) {
    header('Location: /products?flash=' . urlencode('error:Bu ürünleri zaten satın aldınız.'), true, 302);
    exit;
}

/* Bedava sepet: odeme yontemi sormadan dogrudan tanimla */
$freeTotal = function_exists('cart_effective_total') ? (float)cart_effective_total($cartItems) : 0.0;
$freeCoupon = coupon_resolve_for_pay($db, $_SESSION['applied_coupon'] ?? null, $uid);
if ($freeCoupon && $freeTotal > 0) {
    $freeTotal = max(0, $freeTotal - coupon_discount_for_total($freeCoupon, $freeTotal));
}
if ($freeTotal <= 0) {
    foreach ($cartItems as $freeItem) {
        $freeQty = product_effective_price($freeItem['price'], $freeItem['discount_percent'] ?? 0) <= 0 ? 1 : (int)$freeItem['quantity'];
        if (!stock_available($db, (int)$freeItem['product_id'], $freeQty)) {
            header('Location: /products?flash=' . urlencode('error:' . __('bshop.out_of_stock', ['name' => (string)$freeItem['name']])), true, 302);
            exit;
        }
    }
    require_once ROOT_PATH . '/core/purchase.php';
    $db->beginTransaction();
    try {
        purchase_consume_cart($db, $uid, $cartItems);
        $db->prepare('DELETE FROM cart WHERE user_id=?')->execute([$uid]);
        if (!empty($freeCoupon['id'])) {
            require_once ROOT_PATH . '/core/coupons.php';
            if (!coupon_consume($db, (int)$freeCoupon['id'], $uid)) throw new RuntimeException('Kupon kullanılamadı.');
        }
        unset($_SESSION['applied_coupon']);
        $db->commit();
    } catch (\Throwable $eFree) {
        if ($db->inTransaction()) $db->rollBack();
        error_log('[NS] payment free cart: ' . $eFree->getMessage());
        header('Location: /products?flash=' . urlencode('error:'.__('bshop.free_grant_fail')), true, 302);
        exit;
    }
    header('Location: /products?tab=purchases&flash=' . urlencode('success:'.__('bshop.free_granted')), true, 302);
    exit;
}

/* Ödeme yöntemlerini oku */
$paymentMethods = [];
$rawCfg = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'payment_%'")->fetchAll();
$cfg = [];
foreach ($rawCfg as $r) $cfg[$r['key']] = $r['value'];

$methods = ['shopier', 'paytr', 'iyzico', 'stripe', 'paypal', 'bitpay', 'crypt', 'paywant', 'whop', 'paddle', 'lemonsqueezy', 'dodopayments'];
$methodNames = ['shopier' => 'Shopier', 'paytr' => 'PayTR', 'iyzico' => 'iyzico', 'stripe' => 'Stripe', 'paypal' => 'PayPal', 'bitpay' => 'BitPay', 'crypt' => 'Kripto', 'paywant' => 'Paywant', 'whop' => 'Whop', 'paddle' => 'Paddle', 'lemonsqueezy' => 'Lemon Squeezy', 'dodopayments' => 'DodoPayments'];
$methodColors = ['shopier' => '#F7931A', 'paytr' => '#2E7D32', 'iyzico' => '#FF6B00', 'stripe' => '#635BFF', 'paypal' => '#003087', 'bitpay' => '#0F6373', 'crypt' => '#8B5CF6', 'paywant' => '#0d9d8f', 'whop' => '#ff4d00', 'paddle' => '#FDDD35', 'lemonsqueezy' => '#FFC233', 'dodopayments' => '#6D5CFF'];
$methodReq = [
    'shopier' => ['pat', 'shop_slug', 'osb_username', 'osb_password'],
    'paytr' => ['merchant_id', 'merchant_key', 'merchant_salt'],
    'iyzico' => ['api_key', 'secret_key'],
    'stripe' => ['api_key'],
    'paypal' => ['client_id', 'secret'],
    'bitpay' => ['token'],
    'crypt' => ['merchant_id', 'api_key'],
    'paywant' => ['api_key', 'api_secret'],
    'whop' => ['api_key', 'account_id'],
    'paddle' => ['api_key'],
    'lemonsqueezy' => ['api_key'],
    'dodopayments' => ['api_key'],
];
$payLogos = [
    'shopier' => 'shopier.png', 'paytr' => 'paytr.png', 'iyzico' => 'iyzico.png',
    'stripe' => 'stripe.png', 'paypal' => 'paypal.png', 'bitpay' => 'bitpay.jpeg',
    'crypt' => 'cryptomus.png', 'paywant' => 'paywant.png', 'whop' => 'whop.png',
    'paddle' => 'Paddle.jpeg', 'lemonsqueezy' => 'lemonsquezy.jpeg', 'dodopayments' => 'Dodopayments.jpeg',
];
function pay_logo_file(string $m): string {
    global $payLogos;
    $f = $payLogos[$m] ?? '';
    if ($f !== '' && is_file(ROOT_PATH . '/images/payments/' . $f)) return '/images/payments/' . $f;
    return '';
}

$activeCount = 0;
$activeMethod = null;
foreach ($methods as $m) {
    $ac = ($cfg['payment_' . $m . '_active'] ?? '0') === '1';
    $hasKey = true;
    foreach ($methodReq[$m] ?? [] as $rk) {
        if (empty($cfg['payment_' . $m . '_' . $rk] ?? '')) { $hasKey = false; break; }
    }
    $paymentMethods[$m] = [
        'active' => $ac && $hasKey,
        'label' => $methodNames[$m],
        'color' => $methodColors[$m],
        'api_key' => $cfg['payment_' . $m . '_api_key'] ?? '',
        'secret_key' => $cfg['payment_' . $m . '_secret_key'] ?? '',
        'pat' => $cfg['payment_' . $m . '_pat'] ?? '',
    ];
    if ($paymentMethods[$m]['active']) {
        $activeCount++;
        $activeMethod = $m;
    }
}
$modGateways = function_exists('modules_gateways') ? modules_gateways($db) : [];
$modGatewayCodes = [];
foreach ($modGateways as $gwCode => $gw) {
    if (in_array($gwCode, $methods, true)) continue;
    $modGatewayCodes[] = $gwCode;
    $methodNames[$gwCode] = $gw['label'];
    $methodColors[$gwCode] = $gw['color'];
    $paymentMethods[$gwCode] = ['active' => true, 'label' => $gw['label'], 'color' => $gw['color'], 'module' => $gw['module']];
    $activeCount++;
    $activeMethod = $gwCode;
}
$allMethods = array_merge($methods, $modGatewayCodes);
if (function_exists('apply_filters')) $paymentMethods = apply_filters('payment_methods', $paymentMethods);
/* Tek dogruluk kaynagi gateway_ready_list'tir: yari yapilandirilmis yontem (eksik anahtar)
   grid'de gorunmez, tekli oto-yonlendirmeye girmez. Filtreyle eklenen bilinmeyen kodlara dokunulmaz. */
if (function_exists('gateway_ready_list')) {
    $readySet = array_flip(gateway_ready_list($db));
    foreach ($methods as $m) {
        if (isset($paymentMethods[$m])) $paymentMethods[$m]['active'] = !empty($paymentMethods[$m]['active']) && isset($readySet[$m]);
    }
    foreach ($modGatewayCodes as $gc) {
        if (isset($paymentMethods[$gc])) $paymentMethods[$gc]['active'] = !empty($paymentMethods[$gc]['active']) && isset($readySet['mod:' . $gc]);
    }
}
$activeCount = 0;
$activeMethod = null;
foreach ($allMethods as $m) {
    if (!empty($paymentMethods[$m]['active'])) {
        $activeCount++;
        $activeMethod = $m;
    }
}

/* Bakiye kapsiyorsa bakiye butonu gosterilir; kapsamiyorsa dogrudan asagidaki gateway secimine dusulur. Kupon indirimi payTotal icindedir. */
$payTotal = function_exists('cart_effective_total') ? (float)cart_effective_total($cartItems) : array_sum(array_map(fn($i) => $i['price'] * $i['quantity'], $cartItems));
if (function_exists('apply_filters')) $payTotal = (float)apply_filters('checkout_total', $payTotal, $cartItems);
$payCoupon = coupon_resolve_for_pay($db, $_SESSION['applied_coupon'] ?? null, $uid);
if ($payCoupon) $payTotal = max(0, $payTotal - coupon_discount_for_total($payCoupon, $payTotal));
$payTotal = round($payTotal, 2);
$payBalStmt = $db->prepare('SELECT balance FROM users WHERE id=?');
$payBalStmt->execute([$uid]);
$payBalance = (float)($payBalStmt->fetchColumn() ?? 0);
$lowBalanceMode = ($payTotal > 0 && $payBalance < $payTotal);
$balanceCovers = (!$lowBalanceMode && $payTotal > 0);
/* Bakiye kapsiyorsa bakiye butonu gosterilir; kapsamiyorsa dogrudan asagidaki gateway secimine dusulur. */

/* Tek aktif yontem varsa direkt yonlendir: shopier/paytr oto-POST, digerleri gateway sayfasina.
   Not: modul gatewaylerde $activeMethod prefix'siz tutulur, gateway_method_url 'mod:' bekler. */
$singleKey = (!$balanceCovers && $activeCount === 1 && $activeMethod !== null)
    ? (in_array($activeMethod, $modGatewayCodes ?? [], true) ? 'mod:' . $activeMethod : $activeMethod)
    : '';
$singleUrl = ($singleKey !== '') ? gateway_method_url($singleKey) : '';
if ($singleUrl !== '' && $activeMethod !== 'shopier' && $activeMethod !== 'paytr') {
    header('Location: ' . $singleUrl, true, 302);
    exit;
}
if (!$balanceCovers && $activeCount === 1 && ($activeMethod === 'shopier' || $activeMethod === 'paytr')) {
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>Yonlendiriliyor...</title></head><body>'
        . '<form id="nx-shopier-once" method="POST" action="/action.php">'
        . csrf_field()
        . '<input type="hidden" name="action" value="' . ($activeMethod === 'paytr' ? 'paytr_pay' : 'shopier_pay') . '">'
        . '</form><script>document.getElementById("nx-shopier-once").submit();</script></body></html>';
    exit;
}

$siteName = 'Mağaza';
try {
    $snStmt = $db->prepare("SELECT value FROM settings WHERE `key`='site_name' LIMIT 1");
    $snStmt->execute();
    $snVal = $snStmt->fetchColumn();
    if ($snVal) $siteName = $snVal;
} catch (\Exception $e) {}

$flash = $_GET['flash'] ?? '';
[$flashType, $flashText] = $flash ? explode(':', urldecode($flash), 2) + ['',''] : ['', ''];
$activePage = 'payment';
$pageTitle = 'Ödeme';
$vxTailwind = true;
theme_header();
?>
<style>
.pay-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;max-width:700px;margin:0 auto;}@media(max-width:520px){.pay-grid{grid-template-columns:repeat(2,1fr);gap:10px}.pay-card{padding:16px 8px}.pay-card .pay-img{height:34px}}
.pay-card{position:relative;background:#0f1520;border:2px solid rgba(255,255,255,0.08);border-radius:16px;padding:24px 16px;cursor:pointer;text-align:center;transition:all .35s cubic-bezier(.34,1.56,.64,1);}
.pay-card:hover{border-color:#545454;transform:translateY(-3px);box-shadow:0 12px 30px rgba(0,0,0,.25);}
.pay-card.available{cursor:pointer;}
.pay-card .pay-img{height:48px;display:flex;align-items:center;justify-content:center;margin-bottom:12px;}
.pay-card .pay-img img{height:48px;width:auto;max-width:140px;object-fit:contain;transition:all .35s cubic-bezier(.34,1.56,.64,1);}
.pay-img-filter{filter:grayscale(1) brightness(.75);}
.pay-card.available:hover .pay-img-filter{filter:none;}
.pay-card .pay-name{font-size:14px;font-weight:800;color:#f1f5f9;margin-bottom:4px;}
.pay-card .pay-badge{font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;display:inline-block;}
.pay-badge-active{background:rgba(34,197,94,.15);color:#4ade80;}
.btn-pay{background:linear-gradient(180deg,#6366f1 0%,#4f46e5 100%);color:#fff;border:1px solid #3730a3;transition:transform .05s ease,box-shadow .05s ease,filter .2s ease;}
.btn-pay:hover{filter:brightness(1.1);}
.btn-pay:active{transform:translateY(4px)!important;box-shadow:0 1px 0 0 #3730a3!important;}
</style>

<main class="flex-1 max-w-3xl mx-auto px-4 py-8 w-full">
    <?php if ($flashText): ?>
    <div class="<?= $flashType==='success'?'bg-green-900/30 border-green-700 text-green-300':'bg-red-900/30 border-red-700 text-red-300' ?> border rounded-xl px-4 py-3 text-sm font-semibold mb-6 flex items-center gap-2">
        <i class="fa-solid fa-<?= $flashType==='success'?'circle-check':'circle-xmark' ?>"></i>
        <?= e($flashText) ?>
    </div>
    <?php endif; ?>

    <div class="mb-8 text-center" style="text-align:center;">
        <h1 class="text-2xl font-black flex items-center justify-center gap-2">
            <i class="fa-solid fa-credit-card text-indigo-400"></i> <?= __('pay.select') ?>
        </h1>
        <p class="text-slate-500 text-sm mt-1"><?= __('pay.total') ?> <strong class="text-yellow-400"><?= fmt_money($payTotal) ?></strong></p>
    </div>

    <?php if ($planLocked): ?>
    <div class="text-center text-sm font-semibold rounded-xl px-4 py-4 mb-6" style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#fca5a5;">
        <?= e(__('plan.payments_paused')) ?>
    </div>
    <?php endif; ?>

    <?php if ($payTotal > 0 && $payBalance >= $payTotal && !$planLocked): ?>
    <div class="text-center mb-6">
        <button type="button" onclick="payWithBalance()" class="btn-pay" style="padding:13px 26px;border-radius:12px;font-size:14px;font-weight:900;cursor:pointer;">
            <i class="fa-solid fa-wallet"></i> <?= __('cart.pay_balance_btn', ['total' => fmt_money($payTotal)]) ?>
        </button>
        <p class="text-slate-500 text-xs mt-2"><?= __('cart.balance') ?> <strong class="text-slate-300"><?= fmt_money($payBalance) ?></strong></p>
    </div>
    <?php endif; ?>

    <div class="pay-grid">
        <?php if ($activeCount === 0 && !$balanceCovers): ?>
        <div class="col-span-full text-center text-sm font-semibold rounded-xl px-4 py-4" style="grid-column:1/-1;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#fca5a5;">
            <?= e(__('cart.low_nogateway', ['need' => sprintf('%.2f', $payTotal), 'have' => sprintf('%.2f', $payBalance)])) ?>
        </div>
        <?php endif; ?>
        <?php foreach ($allMethods as $m):
            $pm = $paymentMethods[$m] ?? null;
            if (!$pm || empty($pm['active']) || $planLocked) continue;
            $cc = $methodColors[$m] ?? '#6366f1';
            $isModGw = in_array($m, $modGatewayCodes, true);
        ?>
        <div class="pay-card available" style="--pm-color:<?= $cc ?>;" onclick="payWith('<?= $isModGw ? 'mod:' . $m : $m ?>')">
            <div class="pay-img">
                <?php if ($isModGw): ?>
                <i class="<?= e($modGateways[$m]['iconPrefix'] ?? 'fa-solid') ?> <?= e($modGateways[$m]['icon'] ?? 'fa-puzzle-piece') ?>" style="font-size:32px;color:<?= $cc ?>;"></i>
                <?php else: ?>
                <?php $payLogo = pay_logo_file($m); ?>
                <?php if ($payLogo !== ''): ?>
                <img src="<?= $payLogo ?>" alt="<?= e($pm['label']) ?>" class="pay-img-filter" loading="lazy" decoding="async" width="140" height="48">
                <?php else: ?>
                <i class="fa-solid fa-credit-card pay-img-filter" style="font-size:32px;color:<?= $cc ?>;"></i>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="pay-name"><?= e($pm['label']) ?></div>
            <div>
                <span class="pay-badge pay-badge-active">
                    <?= __('pay.available') ?>
                </span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="text-center mt-6">
        <a href="/products" class="text-slate-500 hover:text-slate-300 text-sm transition flex items-center justify-center gap-1">
            <i class="fa-solid fa-arrow-left"></i> Mağazaya Dön
        </a>
    </div>
</main>

<script>
function payWithBalance() {
    if (typeof window.nxCartPay === 'function') { window.nxCartPay(); return; }
    var fail = '<?= e(__('cart.pay_balance_fail')) ?>';
    var fd = new FormData();
    fd.append('action', 'checkout');
    fetch('/action.php', {method: 'POST', body: fd}).then(function (r) { return r.json(); }).then(function (d) {
        if (d.ok) { window.location.href = '/products?tab=purchases&flash=' + encodeURIComponent('success:' + (d.msg || '')); return; }
        alert(d.msg || fail);
    }).catch(function () { alert(fail); });
}
function payWith(method) {
    if (method.indexOf('mod:') === 0) { window.location.href = '/shop/module-pay?gateway=' + encodeURIComponent(method.slice(4)); return; }
    var map = {iyzico:'/shop/iyzico-pay',stripe:'/shop/stripe-pay',paypal:'/shop/paypal-pay',bitpay:'/shop/bitpay-pay',crypt:'/shop/crypt-pay',paywant:'/shop/paywant-pay',whop:'/shop/whop-pay',paddle:'/shop/paddle-pay',lemonsqueezy:'/shop/lemonsqueezy-pay',dodopayments:'/shop/dodopayments-pay'};
    if (map[method]) { window.location.href = map[method]; return; }
    var f = document.getElementById('payForm');
    f.querySelector('input[name="action"]').value = method === 'paytr' ? 'paytr_pay' : 'shopier_pay';
    f.submit();
}
</script>
<form id="payForm" method="POST" action="/action.php" style="display:none;">
    <input type="hidden" name="action" value="shopier_pay">
    <?= csrf_field() ?>
</form>

<?php theme_footer(); ?>
