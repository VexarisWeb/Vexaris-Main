<?php
defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);
defined('ROOT_PATH')  or define('ROOT_PATH',  dirname(__DIR__));
require_once ROOT_PATH . '/core/init.php';
require_once ROOT_PATH . '/actions/bootstrap-action.php';
require_once ROOT_PATH . '/core/paywant.php';

$db = nexus_db();
$me = auth_check() ? auth_user() : null;
if (!$me) { header('Location: /login', true, 302); exit; }
license_gate_require('core');
if (!paywant_is_ready($db)) {
    header('Location: /shop/payment?flash=' . urlencode('error:'.__('bshop.paywant_off')), true, 302);
    exit;
}

$uid = (int)$me['id'];

$topupAmount = (float)($_GET['topup'] ?? 0);
$topupAmount = is_finite($topupAmount) ? round($topupAmount, 2) : 0;
if ($topupAmount > 100000) $topupAmount = 100000;
$isTopup     = $topupAmount >= topup_min_amount();

if ($isTopup && !plan_payments_allowed($db)) { header('Location: /shop/payment?flash=' . urlencode('error:'.__('plan.payments_paused')), true, 302); exit; }
if ($isTopup) {
    $total = round($topupAmount, 2);
    $totalTry = fx_convert($total, store_currency(), 'TRY');
    $orderId = 'TOPUP-' . $uid . '-' . time() . '-' . bin2hex(random_bytes(4));
    $title = gateway_topup_title($db, (float)$totalTry, 'TRY');
    try {
        $db->prepare('INSERT INTO payment_intents (user_id,order_id,total_amount,currency,status,payment_method) VALUES (?,?,?,?,"pending","paywant")')
           ->execute([$uid, $orderId, $totalTry, 'TRY']);
        $intentId = (int)$db->lastInsertId();
    } catch (\PDOException $e) {
        error_log('[paywant] topup intent: ' . $e->getMessage());
        header('Location: /shop/payment?flash=' . urlencode('error:'.__('bshop.pay_fail')), true, 302);
        exit;
    }
} else {
    $cartStmt = $db->prepare(
        'SELECT c.product_id,c.quantity,p.name,p.price,p.discount_percent FROM cart c
         JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active"'
    );
    $cartStmt->execute([$uid]);
    $items = $cartStmt->fetchAll();
    if (empty($items)) {
        header('Location: /products?flash=' . urlencode('error:'.__('cart.empty_short')), true, 302);
        exit;
    }
    require_once ROOT_PATH . '/core/purchase.php';
    foreach ($items as $balChk) {
        $freeQtyB = product_effective_price($balChk['price'] ?? 0, $balChk['discount_percent'] ?? 0) <= 0 ? 1 : (int)($balChk['quantity'] ?? 1);
        if (!stock_available($db, (int)$balChk['product_id'], $freeQtyB)) {
            header('Location: /products?flash=' . urlencode('error:'.__('bshop.out_of_stock', ['name' => ($balChk['name'] ?? '')])), true, 302);
            exit;
        }
    }

    $items = purchase_filter_owned($db, $uid, $items);
    if (empty($items)) {
        header('Location: /products?flash=' . urlencode('error:'.__('bshop.already_owned')), true, 302);
        exit;
    }
    $total = cart_effective_total($items);
    if (function_exists('apply_filters')) $total = (float)apply_filters('checkout_total', $total, $items);
    $totalTry = fx_convert($total, store_currency(), 'TRY');
    if ($totalTry <= 0) {
        header('Location: /products?flash=' . urlencode('error:'.__('bshop.free_no_pay')), true, 302);
        exit;
    }
    $appliedCoupon = coupon_resolve_for_pay($db, $_SESSION['applied_coupon'] ?? null, $uid);
    if ($appliedCoupon) {
        $total = max(0, $total - coupon_discount_for_total($appliedCoupon, $total));
    }
    $totalTry = fx_convert($total, store_currency(), 'TRY');
    if ($totalTry <= 0) {
        header('Location: /products?flash=' . urlencode('error:'.__('bshop.free_no_pay')), true, 302);
        exit;
    }
    $names = array_map(fn($i) => $i['name'], $items);
    $title = count($names) > 1 ? (__('bshop.cart_title', ['n' => count($names)])) : ($names[0] ?? __('bshop.order_default', ['store' => store_name($db)]));
    if (!plan_payments_allowed($db)) { header('Location: /shop/payment?flash=' . urlencode('error:'.__('plan.payments_paused')), true, 302); exit; }
    $orderId = 'SP-' . $uid . '-' . time() . '-' . bin2hex(random_bytes(4));
    require_once ROOT_PATH . '/core/purchase.php';
    $intentSnapshot = purchase_snapshot_build($items, $appliedCoupon);
    try {
        $db->prepare('INSERT INTO payment_intents (user_id,order_id,total_amount,currency,items_snapshot,status,payment_method) VALUES (?,?,?,?,?,"pending","paywant")')
           ->execute([$uid, $orderId, $totalTry, 'TRY', $intentSnapshot]);
        $intentId = (int)$db->lastInsertId();
    } catch (\PDOException $e) {
        error_log('[paywant] cart intent: ' . $e->getMessage());
        header('Location: /shop/payment?flash=' . urlencode('error:'.__('bshop.pay_fail')), true, 302);
        exit;
    }
}

try {
    $payUrl = paywant_create_payment($db, $intentId, $uid, (string)$me['username'], (string)$me['email'], $totalTry, $title);
} catch (\Exception $e) {
    error_log('[paywant] Ödeme oluşturulamadı: ' . $e->getMessage());
    header('Location: /shop/payment?flash=' . urlencode('error:'.__('bshop.pay_page_fail')), true, 302);
    exit;
}

header('Location: ' . nx_gateway_redirect_or_fail((string)$payUrl, ['paywant.com']), true, 302);
exit;
