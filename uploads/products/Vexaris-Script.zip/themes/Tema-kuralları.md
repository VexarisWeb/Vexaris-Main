# Tema Kuralları (Themes)

Bu doküman, tema sisteminin güncel mimarisini ve tema yazarken/düzenlerken
uyulması gereken kuralları içerir. Tema motoru
`core/managers/theme-man.php` üzerinde çalışır. Aktif temalar:
`default`, `azure`, `ember`.

## 1. Tema Dizini Yapısı

Her tema `themes/{tema-adı}/` klasöründe durur. Aktif tema `settings`
tablosundaki `active_theme` satırından okunur.

```
themes/{tema}/
├── 404.php                 # 404 hata sayfası
├── custom-page.php         # Özel sayfalar
├── index.php               # Ana sayfa
├── legal.php               # Yasal sayfalar
├── login.php               # Giriş
├── maintenance.php         # Bakım modu
├── news.php                # Duyurular
├── products.php            # Mağaza (/products: liste; ?product=ID detay, ?tab=purchases kütüphane — detay/kütüphane için product.php'yi include eder)
├── register.php            # Kayıt
├── product.php             # Ürün detay + kütüphane şablonu (doğrudan route'u yok; products.php include eder)
├── support.php             # Destek (Bölüm 9'daki ortak mimariyi kullanır)
├── editor.php              # Tema Editörü şeması (Bölüm 8)
├── assets/
│   ├── css/style.css       # Tema CSS'i (değişince header.php'de ?v artırılır)
│   └── js/main.js          # Tema JS'i
├── includes/
│   ├── header.php          # Tüm sayfaların <head> + üst kısmı
│   └── footer.php          # Alt kısım + <script> + </body>
└── user/
    ├── connections.php
    ├── dashboard.php
    ├── my-products.php
    ├── my-tickets.php
    ├── redeem-code.php
    ├── settings.php
    └── includes/sidebar.php
```

Ortak (tema-dışı) frontend dosyaları: `assets/js/support-chat.js`
(destek sohbet motoru), `core/support-page.php` (destek veri katmanı).

## 2. Şablon Yükleme Mekanizması

- `theme_header($title)`: `themes/{aktif}/includes/header.php` dosyasını yükler.
  `$pageTitle` boşsa başlığı set eder. Tema dosyası yoksa `default` tema kullanılır.
- `theme_footer()`: `themes/{aktif}/includes/footer.php` dosyasını yükler.
- `theme_load($template)`: `themes/{aktif}/{template}.php` dosyasını yükler.
  Aktif temada yoksa `themes/default/{template}.php` düşer. O da yoksa 404 gönderir.
- Aktif tema adı `theme_active()` ile alınır; `settings.active_theme` değeri
  `[a-z0-9_\-]` dışındaki karakterlerden temizlenir, klasör yoksa `default` döner.
- Lisanslı tema (`ember`): lisans yoksa sessizce `default`'a düşer
  (`feature_active('theme_ember')` çift kontrol: `theme-man.php` + tema header'ı).

## 3. Sayfa Yazım Kuralları

1. Her sayfa `defined('NEXUS_BOOT') or define('NEXUS_BOOT', true);` ve
   `defined('ROOT_PATH') or define('ROOT_PATH', dirname(__DIR__));` ile başlar,
   ardından `require_once ROOT_PATH . '/core/init.php';` çağrılır.
2. Sayfalar kendi iş mantığını üstte çalıştırır, sonra `theme_header()` →
   HTML içeriği → `theme_footer()` sırasını izler.
3. Kullanıcı gerektiren sayfalarda `auth_check()` / `auth_user()` kontrolü yapılır;
   girişsiz kullanıcı `header('Location: /login')` ile yönlendirilir
   (`auth_require('/login')` tercih edilir).
4. Tüm dinamik çıktı `htmlspecialchars()` veya `e()` yardımcısıyla kaçırılır.
5. POST işlemleri yalnızca `action.php` üzerinden yürür ve `csrf_field()` /
   `csrf_verify()` ile korunur.
6. Formlarda `<?= csrf_field() ?>` bulundurulmalıdır.
7. PHP dosyalarında yorum satırı yazılmaz; dosyalar UTF-8 **BOM'suz** ve LF
   satır sonlu olur (BOM session'ı öldürür — bkz. AGENTS.md karakter bölümü).
8. Tüm DB sorguları PDO prepared statement kullanır; `$_GET` ile dosya
   include edilmez, `eval` kullanılmaz.

## 4. Header / Footer Kuralları

- `header.php` içinde `<html>`, `<head>`, `theme_header()` sonrası gelen `<body>` açılır.
- Sayfa özel CSS ihtiyacı için `<style>` bloğu `theme_header()` içinde veya içerik üstünde verilir.
- `footer.php` içinde tema JS'i, `theme_footer()` çağrıları, `<body>` ve `<html>` kapanışı yapılır.
- Sayfaya özel JS, `$extraScripts` değişkenine eklenerek footer'da basılır.
- Footer sosyal linkleri (`social_discord/youtube/github/twitter`) `settings`
  tablosundan okunur, yalnızca **dolu** linkler çizilir ve `href` MUTLAKA
  `nx_safe_href()` içinden geçer (Bölüm 6).
- **Header menüsü dinamik:** `settings.header_links` JSON (`[{label,url,icon}]`)
  admin **Header Editor**'den yönetilir. Tema header başında okur, boşsa
  hardcoded `Ana Sayfa/Mağaza/Duyurular/Destek` fallback basar.
- Footer menü (`footer_links`): `footer_links_data()` ile okunur (scheme
  whitelist'i okuma anında uygulanır), sütun başına max 12 link; boş sütun
  gizlenir.
- Ödeme yöntemi listeleri (header/shop): `payment_{gw}_active` + anahtar
  doluluğuna göre kurulur; Shopier'de ek olarak `osb_username/osb_password`
  şarttır (callback doğrulanamazsa yöntem listelenmez).
- **SSS:** `faqs` tablosu admin **SSS** ekranından yönetilir, `faqs_fetch()`
  ile çekilir, `references` sonrası accordion olarak basılır.

## 5. Dışa Bağımlılık (CDN)

- Font Awesome, Tema CSS/JS'den bağımsız olarak header'da yüklenir.
- Tema yazarken mevcut CSS değişkenlerine sadık kalın; yeni renk sabitleri
  eklenmeyin.
- Ortak JS (`assets/js/support-chat.js`) CDN değil, aynı hosttan
  `?v=` sürümüyle yüklenir.

## 6. Render Güvenliği (Zorunlu)

- Düz metin: `e()` / `htmlspecialchars()`.
- `href` bağlamındaki TÜM URL'ler (`header menü`, `sosyal linkler`, `hero buton
  linkleri`, `download_link`, bilet ekleri): `e(nx_safe_href($url, $fallback))`.
  `htmlspecialchars` tek başına `javascript:` engellemez.
- `src`/kayıtlı URL alanları (`image_url`, logo): `nx_safe_url()` ile
  saklanır (`https?://` veya `/` ile başlamayan reddedilir).
- `<script>` içine PHP verisi gömülürken `json_encode(..., JSON_HEX_TAG |
  JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP)` kullanılır; `addslashes`
  ile JS'e gömme YASAKTIR (`</script>` breakout yapar).
- Zengin HTML alanları (ürün açıklaması, duyuru, SSS, slider) KAYDETME anında
  `nx_clean_html()` ile temizlenir; render'da ham basılır (tasarım kararı).
  Hero başlıkları render'da `nx_clean_html($x, 'inline')` ile sarılır.
- `html` tipi tema-editör alanları render'da `inline` temizlikten geçer;
  `strip_tags`'in attribute'ları koruduğu unutulmaz.

## 7. Mağaza Listeleri (Mobil Kurallar)

- Ürün ızgaraları mobilde **tek sütuna** düşer: default/azure
  `.products-grid` ≤600-640px'te `1fr`; ember `.ember-grid` ≤700px'te `1fr`.
- Kategoriler ürünlerin **üstünde** durur: default `/products` sidebar'ı
  mobilde tam-genişlik yatay chip satırına döner (`.shop-cat-side` /
  `.shop-cat-list`); azure `.shop-side` + `.category-nav` aynı davranır;
  ember çipleri zaten `flex-wrap`'lidir.
- Arama formu + buton mobilde sığar: form tam genişlik, input `flex:1;
  min-width:0` (inline `min-width:240px` gibi sabitler mobilde YASAKTIR).
- Başlık satırları (`justify-content:space-between`) `flex-wrap:wrap` alır.
- Kullanıcı paneli grid'leri (ember `.ember-panel-grid`, detay
  `.ember-detail-grid`) mobilde `1fr` olur; sticky sidebar `static`'e döner.
- Sabit pikselli kart genişlikleri (`width:360px` slider kartı vb.) mobil
  media ile küçültülür (`300px`).
- CSS değişince `header.php`'deki `?v=` artırılır (şu an: default `v10`,
  azure `v16`, ember `v3`).
- Ürün detayda fiyat: `price` + `discount_percent` her zaman birlikte okunur
  (ember index sorgusundaki eksik kolon bug'ı gibi: indirimsiz/stoksuz
  görünüm vermemek için `SELECT *` veya eksiksiz kolon listesi).

## 8. Tema Editörü (`editor.php`)

Temalar, Admin > Görünüm > Tema Editörü ekranında düzenlenebilir alan beyan
edebilir. Beyan `themes/{slug}/editor.php` dosyasından `return` edilen dizidir:

```php
defined('NEXUS_BOOT') or die('Direct access denied.');
return ['sections' => [[
    'key' => 'hero', 'label' => 'Hero Alanı', 'icon' => 'fa-star',
    'fields' => [
        ['key' => 'hero_title', 'label' => 'Başlık', 'type' => 'html',
         'default' => 'Varsayılan başlık'],
        ['key' => 'vurgu', 'label' => 'Vurgu Rengi', 'type' => 'color',
         'var' => '--brand', 'default' => '#2b6eff'],
        ['key' => 'hero_gorsel', 'label' => 'Görsel', 'type' => 'image',
         'default' => ''],
    ],
]]];
```

Alan tipleri: `text`, `textarea`, `html` (kayıtta `strip_tags` +
render'da `inline` temizlik), `color` (hex), `image` (`/uploads/` veya
`https?://`, finfo+MIME+`getimagesize` kontrollü yükleme), `select`
(`options` ister, kayıt dışı değer reddedilir), `number`. `key` kuralı
`^[a-z0-9_]{1,60}$`. `var` yazılan `color` alanları
`theme_vars_css()` ile `:root` üzerine otomatik basılır.

Şablon içinde okuma: `theme_setting('hero_title', 'Varsayılan başlık')`
verir (`theme_visible()` boş-kayıtta `null` döner). Kaydedilmemiş anahtarda
ikinci parametre (mevcut hardcoded metin) basılır, bu yüzden şablon
varsayılanı ile `default` değeri birebir aynı tutulur. Kaydetme/sıfırlama
`action.php` içindeki `theme_editor_save` case üzerinden yürür, değerler
`theme_settings` tablosunda tema bazında durur. Buton/link tipi alanlar
`text` tipiyle tutulur ve Bölüm 6'daki `nx_safe_href` kuralına tabidir.

## 9. Destek Sistemi (Ortak Mimari)

Destek sayfaları (`support.php`) üç temada da AYNI mimariyi kullanır.
**Kural: davranış birleşir, görünüm birleşmez.** Yeni destek mantığı yazarken
üç dosyaya kopyalanmaz, ortak katmana eklenir.

- **Veri katmanı** (`core/support-page.php`):
  `support_page_data($db, $uid, $tid)` (aktif bilet + yanıtlar + taleplerim +
  kategoriler), `support_page_flash()`, `support_page_defaults()`.
  Sayfa başında 8 satırlık include ile kullanılır; sorgular sayfalara
  gömülmez.
- **Sohbet motoru** (`assets/js/support-chat.js`): `SupportChatInit(cfg)`
  gönderme/polling/görüldü/sayaç/dosya-önizlemeyi yönetir. Tema başına
  ~25 satırlık init konfigürasyonu verilir (`optimistic`, `polled`,
  `adminHead`, `metaDone` renderer'ları + element ID'leri + `tickTag`/
  `tickClass`). Balon class'ları, rozet HTML'i, renkler temada kalır.
- **Tik kuralı:** tik SADECE en son *kendi* mesajında görünür. Server
  `$lastOwnRid` ile sonuncuya basar; client `tidyTicks()` her poll/gönderim
  sonrası eskileri gizler (`display:none`).
- **Mobil çekmece:** sidebar mobilde gizlenir, detay başlığındaki hamburger
  (`.nx-drawer-btn`, desktop'ta `display:none`) ile soldan kayan drawer
  olarak açılır (backdrop + `body overflow:hidden`). Kırılımlar: default
  768px, azure 960px, ember 860px. Talep seçilmediyse liste normal görünür.
- **Yükseklik:** sohbet kabı `calc(100dvh - Xpx)` kullanır (`100vh` fallback
  ile birlikte); yazma formu `flex-shrink:0` ile altta sabit kalır.
- **Kategoriler:** yeni-talep menüsü `ticket_categories` tablosundan beslenir;
  `Havale Talebi` kullanıcı menüsünde gösterilmez ve `ticket_create`
  reddeder (sadece havale modülü açar). Açık-talep kilidi (`$hasOpen`)
  havale talebini saymaz.
- **Sıralama:** listeler `COALESCE(updated_at,created_at) DESC, id DESC`
  ile dizilir; her kullanıcı/admin yanıtı `updated_at` tazeler
  (`tickets.updated_at`, NULL ise `created_at` geçerlidir).
- **Kategori görünürlüğü:** liste satırlarında (sidebar, Taleplerim paneli)
  ve detay başlığında kategori rozeti basılır.
- **Captcha:** üç temanın yeni-talep modalında da Turnstile/reCAPTCHA
  widget'ı bulunur; `ticket_create` server-side `verify_captcha()` çağırır.
  Kapalıysa iki taraf da sessizce atlar.
- **Polling:** `ticket_poll` (`after_id` + `viewing`), 2sn aralık, 50+ yanıtta
  hızlı tur; sekmeler `visibilitychange` ile uyanır.

## 10. Birleştirme Kuralı (Kopya Yasağı)

- Aynı davranış üç temaya kopyalanmaz. Yeni ortak ihtiyaç önce
  `core/` yardımcısı veya `assets/js/` modülü olarak yazılır, temalar ince
  konfigürasyonla bağlanır (destek Faz 1+2 örneği: -376 satır).
- Birleştirme sınırı: **görünüm (renk/class/markup) temada kalır**,
  davranış taşınır. Modal tasarımları, rozet HTML'i, buton stilleri
  birleştirilmez.
- Fazlı ilerlenir (veri → JS → CSS iskeleti), her fazda 3 temada duman
  kontrolü yapılır (aç, yaz, dosya ekle, kapat, mobil çekmece).

## 11. Güvenlik

- Temalara `install.lock`, `.env`, `.sql`, `.json` gibi dosyalar koyulmaz.
- Temalarda doğrudan DB bağlantısı yerine `nexus_db()` gibi çekirdek
  yardımcıları kullanılır.
- Kullanıcı girdisi tema dosyalarında asla `eval`, `include $_GET[...]` ile
  işlenmez.
- Admin sayfaları `guard.php` kaynak eşleşmesine tabidir
  (`header-editor`/`footer-editor`/`custom-css` → `themes`;
  `purchases`/`reviews`/`slider` → kendi adları; `faqs` → `products`).
- Yüklenen görseller rastgele ad + ext whitelist + finfo MIME +
  `getimagesize` ile doğrulanır (`theme_image_upload`, ürün kapakları,
  bilet ekleri aynı deseni izler).

## 12. Dil Entegrasyonu (i18n — Zorunlu)

- Tek aktif dil: `settings.primary_lang` (`tr`/`en`). Yardımcı `__($key,
  $vars)` (`core/lang.php`): seçili dil → TR fallback → anahtar. URL
  prefix/cookie/kullanıcı-dili YOK; içerik (ürün adı, duyuru metni) çevrilmez.
- Sözlükler: `lang/tr.json` + `lang/en.json`, bölüm.alt formatı
  (`home.btn1`, `cart.checkout`). **TR ve EN her zaman birebir pariteli
  tutulur** (eksik anahtar render'da anahtarın kendisini basar).
- Tema dosyalarında çıplak Türkçe string YASAKTIR. Kural:
  `theme_visible('x', 'Türkçe')` → `theme_visible('x', __('bölüm.anahtar'))`;
  `theme_setting()` varsayılanları ve `editor.php` `default` değerleri de
  `__()` ile sarılır (şablon varsayılanı = editor varsayılanı = aynı anahtar).
  Admin `label` metinleri hariç (admin panel sözlüğüne aittir).
- `aria-label`, `title`, `placeholder`, `alt` dahil TÜM kullanıcıya dönük
  metin çevrilir. HTML/PHP yorumları ve `||` fallback'leri (ölü kod)
  çevrilmez.
- Sayfa-içi `<script>`'teki metinler: `<?= json_encode(__('bölüm.anahtar')) ?>`
  ile gömülür (Bölüm 6'daki HEX flag'leriyle); `addslashes` YASAK.
  Paylaşılan JS (`support-chat.js` vb.) metni dışarıdan `NX_*_LANG` objesiyle
  alır, içinde Türkçe fallback barındırmaz.
- Backend mesaj eşleşmesi dile gömülmez: CSRF interceptor `d.code ===
  'csrf_fail'` bakar (mesaj-içi `indexOf('Güvenlik...')` YASAK — EN'de
  çalışmaz).
- Tarih: `tr_date()` dile duyarlıdır (EN'de İngilizce ay adı döner);
  yeni tarih formatlayıcı yazılmaz, `tr_date` kullanılır.
- Yeni tema / yeni string checklist'i: önce `lang/tr.json`'da birebir
  karşılığı ara (tekrar anahtar açma); yoksa TR+EN'yi **aynı committe**
  ekle; kapsama taraması yap:
  `grep -rn "[çÇğĞıİöÖşŞüÜ]" themes/{tema} --include="*.php"`
  (çıktıda yalnızca `__()` içi, yorum ve ölü fallback kalmalı).
- **Tema-özel sözlük:** `themes/{tema}/lang/tr.json` + `en.json` (flat
  `edis.*` anahtarlar). Okuma `theme_lang($key, $vars, $theme)` ile yapılır
  (`core/managers/theme-man.php`); zincir: tema-dili → tema-TR → global
  `__()` → anahtar. `$theme` verilmezse aktif tema kullanılır. Tema editörü
  (`admin/theme-editor.php`) düzenlenen temanın dilini kullanır, aktif temayı
  değil.
- **Editör etiketi kuralı:** `editor.php` içinde görünen metin yazılmaz;
  `label` değeri `@edis.<alan-key>` (bölümlerde `@edis.sec_<bölüm-key>`)
  referansı olur. `theme_editor_schema()` `@` önekini tema dilinden çözer.
  Yeni alan eklerken TR+EN karşılığını tema `lang/` dosyalarına ekle.
- **Modül sözlüğü:** `modules/{slug}/lang/tr.json` + `en.json`, okuma
  `module_lang($slug, $key, $vars)` (`core/managers/modules-man.php`);
  zincir tema ile aynı, son fallback global `__()`.
- Para birimi: fiyatlar `fmt_money()` + `fx_convert()` üzerinden basılır
  (`core/fx.php`); çıplak `₺`/`$`/`€` ve `number_format` ile el yapımı fiyat
  YASAKTIR (bkz. Bölüm 7 mobil fiyat kuralı).

## 13. Hata Sayfaları + Bot Disiplini

- **404 semantiği korunur** (SEO için kritik — her şeye 200 dönmek
  soft-404 sayılır ve sıralamayı düşürür; ayrıca yükü azaltmaz çünkü PHP
  her halükarda açılır).
- Bilinmeyen URL'ler PHP çalıştırmadan kapanır: kökteki statik `404.html`
  (`ErrorDocument 404 /404.html`), içinde PHP/DB/lisansineryok. Kökteki
  eski `404.php` silinmiştir (ölü koddu, hiçbir şey çağırmıyordu).
- `themes/{tema}/404.php` şablonları yalnızca `theme_load()` iç fallback
  içindir (eksik şablon), harici 404 akışında kullanılmaz.
- `.htaccess` kenarda bloklar (PHP açılmadan 403): `wp-*`, `xmlrpc`,
  `phpmyadmin`, `server-status`, `.env`, `composer.json/lock` ve benzeri
  probe kalıpları. Kuralda sonek şartı (`/|$|\.`) vardır ki normal
  slug'lar (örn. `pma-hosting`) etkilenmesin. `TRACE`/`TRACK` metodları
  kapalı, `Options -Indexes` ile dizin listeleme kapalı.
- `robots.txt`: `/admin`, `/action.php`, `/callback`, `/api`, `/install`,
  `/payment`, `/user`, `*-pay`, arama (`?q=`, `?ajax=`) taramaya kapalıdır;
  içerik (ürün/duyuru/yasal) açıktır. Yeni bot-ağır uç eklenirse buraya
  `Disallow` satırı eklenir.
- Hız limiti (rate-limit) `.htaccess` ile yapılamaz; LiteSpeed/Cloudflare
  katmanında kurulur. Bot yükü şüphesinde önce error_log'daki 403/404
  desenine bakılır.
