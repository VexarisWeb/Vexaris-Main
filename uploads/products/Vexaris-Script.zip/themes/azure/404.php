<?php
$pageTitle  = __('err.e404_title');
$activePage = '';
$seoKey     = '404';
include __DIR__ . '/includes/header.php';
?>
<main class="auth-shell">
  <div class="auth-card" style="max-width:480px;text-align:center;padding:48px 40px;">

    <div class="auth-card-icon" style="background:linear-gradient(135deg,var(--danger),#f7a3b1);box-shadow:0 8px 20px rgba(228,87,107,.3);">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 2 20h20L12 3z"/><path d="M12 10v4m0 3h.01"/></svg>
    </div>

    <p style="font-family:var(--font-title);font-size:64px;font-weight:900;line-height:1;letter-spacing:-2px;margin-bottom:4px;background:linear-gradient(135deg,var(--danger),var(--warn));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;">404</p>
    <h1 class="auth-card-title" style="font-size:20px;"><?= __('err.e404_title') ?></h1>
    <p class="auth-card-subtitle" style="margin-top:8px;"><?= __('err.e404_sub') ?></p>

    <div style="display:flex;gap:12px;justify-content:center;margin-top:28px;flex-wrap:wrap;">
      <a href="/" class="btn btn-primary">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11.5 12 4l9 7.5"/><path d="M5 10.5V20h5v-6h4v6h5v-9.5"/></svg>
        <?= __('err.e404_home') ?>
      </a>
      <a href="/products" class="btn btn-ghost">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M12 24V15"/></svg>
        <?= __('err.e404_store') ?>
      </a>
    </div>

  </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>