/**
 * themes/azure/assets/js/main.js
 * Azure teması — ana sayfa ve genel etkileşimler.
 */
(function () {
    'use strict';

    var ACTIONS_URL = '/action.php';

    /* ================== mobil menü ================== */
    var toggle = document.getElementById('navToggle');
    var links = document.getElementById('navLinks');
    if (toggle && links) {
        toggle.addEventListener('click', function (e) {
            e.stopPropagation();
            var open = links.classList.toggle('open');
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            var icon = document.getElementById('navToggleIcon');
            if (icon) icon.innerHTML = open
                ? '<path d="M6 6l12 12M18 6 6 18"/>'
                : '<path d="M4 7h16M4 12h16M4 17h16"/>';
        });
        document.addEventListener('click', function (e) {
            if (!toggle.contains(e.target) && !links.contains(e.target)) {
                links.classList.remove('open');
                toggle.setAttribute('aria-expanded', 'false');
                var icon = document.getElementById('navToggleIcon');
                if (icon) icon.innerHTML = '<path d="M4 7h16M4 12h16M4 17h16"/>';
            }
        });
    }

    /* ================== navbar scroll: köşe yuvarlama + gölge ================== */
    var navbar = document.querySelector('.navbar');
    if (navbar) {
        var updateShadow = function () {
            document.body.classList.toggle('az-scrolled', window.scrollY > 24);
        };
        updateShadow();
        window.addEventListener('scroll', updateShadow, { passive: true });
    }

    /* ================== kullanıcı dropdown ================== */
    var uBtn = document.getElementById('userDropdownBtn');
    var uMenu = document.getElementById('userDropdownMenu');
    if (uBtn && uMenu) {
        uBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            uMenu.classList.toggle('open');
        });
        document.addEventListener('click', function () { uMenu.classList.remove('open'); });
        uMenu.addEventListener('click', function (e) { e.stopPropagation(); });
    }

    /* ================== toast ================== */
    function showToast(msg, ok) {
        var t = document.getElementById('azToast');
        if (!t) {
            t = document.createElement('div');
            t.id = 'azToast';
            document.body.appendChild(t);
        }
        t.className = (ok ? 'toast-ok' : 'toast-err');
        t.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="' + (ok ? 'm5 13 4 4 10-11' : 'M18 6 6 18M6 6l12 12') + '"/></svg>';
        t.appendChild(document.createTextNode(msg));
        t.classList.add('show');
        clearTimeout(t._t);
        t._t = setTimeout(function () { t.classList.remove('show'); }, 3400);
    }
    window.showToast = showToast;

    function nxAzCloseConfirm() {
        var b = document.getElementById('nxConfirm');
        if (b) b.style.display = 'none';
    }

    window.nxCloseConfirm = nxAzCloseConfirm;

    function nxAzMoney(v) {
        if (window.nxFmt) return window.nxFmt(v);
        var n = parseFloat(v || 0);
        if (!isFinite(n)) n = 0;
        return '₺' + n.toFixed(2).replace('.', ',');
    }

    function nxCartConfirmDialog(total, onOk) {
        var L = window.NX_LANG || {};
        var box = document.getElementById('nxConfirm');
        if (!box) {
            box = document.createElement('div');
            box.id = 'nxConfirm';
            box.style.cssText = 'position:fixed;inset:0;z-index:100003;background:rgba(14,42,74,.55);align-items:center;justify-content:center;padding:18px;display:none;';
            box.addEventListener('click', function (e) { if (e.target === box) nxAzCloseConfirm(); });
            document.body.appendChild(box);
        }
        box.innerHTML = '';
        var card = document.createElement('div');
        card.style.cssText = 'width:100%;max-width:400px;background:#fff;border:1px solid rgba(43,110,255,.22);border-radius:18px;padding:24px;text-align:center;font-family:inherit;box-shadow:0 18px 48px rgba(14,42,74,.18);';
        var title = document.createElement('div');
        title.style.cssText = 'font-size:16px;font-weight:900;color:#1e4fd6;margin-bottom:10px;';
        title.textContent = L.confirm_title || 'Ödeme Onayı';
        var msg = document.createElement('div');
        msg.style.cssText = 'font-size:13px;color:#41536b;font-weight:600;line-height:1.6;margin-bottom:18px;';
        msg.textContent = (L.confirm_text || 'Bakiyenizden {total} düşecek. Onaylıyor musunuz?').split('{total}').join(nxAzMoney(total));
        var yes = document.createElement('button');
        yes.type = 'button';
        yes.style.cssText = 'width:100%;background:#0fae7c;color:#fff;border:none;border-radius:12px;padding:13px;font-size:14px;font-weight:800;cursor:pointer;font-family:inherit;';
        yes.textContent = L.confirm_yes || 'Onaylıyorum';
        yes.onclick = function () { nxAzCloseConfirm(); if (onOk) onOk(); };
        var no = document.createElement('button');
        no.type = 'button';
        no.style.cssText = 'width:100%;margin-top:8px;background:transparent;border:none;color:#6b7f99;font-size:12px;font-weight:700;cursor:pointer;padding:8px;font-family:inherit;';
        no.textContent = L.confirm_no || 'Vazgeç';
        no.onclick = nxAzCloseConfirm;
        card.appendChild(title);
        card.appendChild(msg);
        card.appendChild(yes);
        card.appendChild(no);
        box.appendChild(card);
        box.style.display = 'flex';
    }

    window.nxCartConfirmDialog = nxCartConfirmDialog;

    function nxAzCloseCartUi() {
        if (cartPanel) { cartPanel.classList.remove('show'); document.body.style.overflow = ''; }
        var cm = document.getElementById('cartModal');
        if (cm) cm.classList.add('hidden');
    }

    async function nxCartPayNow() {
        var fail = (window.NX_LANG && window.NX_LANG.error) || 'Bir hata oluştu.';
        try {
            var fd = new FormData(); fd.append('action', 'checkout');
            var r = await fetch(ACTIONS_URL, { method: 'POST', body: fd });
            var d = await r.json();
            if (d && d.redirect) { nxAzCloseCartUi(); vxGo(d.redirect); return; }
            if (d.ok) {
                nxAzCloseCartUi();
                showToast(d.msg, true);
                setTimeout(function () { window.location.reload(); }, 1100);
                return;
            }
            showToast(d.msg || fail, false);
        } catch (e) { showToast(fail, false); }
    }

    async function nxCartPay() {
        var L = window.NX_LANG || {};
        var fail = L.error || 'Bir hata oluştu.';
        try {
            var fd = new FormData(); fd.append('action', 'cart_state');
            var r = await fetch(ACTIONS_URL, { method: 'POST', body: fd });
            var s = await r.json();
            if (!s || !s.ok) { showToast((s && s.msg) || fail, false); return; }
            if (s.empty) { showToast(L.cart_empty || 'Sepetiniz boş.', false); return; }
            if (s.low_balance) { nxAzCloseCartUi(); vxGo('/shop/payment'); return; }
            nxCartConfirmDialog(s.total, function () { nxCartPayNow(); });
        } catch (e) { showToast(fail, false); }
    }

    window.nxCartPay = nxCartPay;
    window.nxCartPayNow = nxCartPayNow;

    /* ================== sepet paneli ================== */
    var cartPanel = document.getElementById('cartPanel');
    var cartClose = document.getElementById('cartCloseBtn');
    if (cartPanel) {
        window.toggleCartPanel = function (e) {
            if (e) e.stopPropagation();
            if (uMenu) uMenu.classList.remove('open');
            var isOpen = cartPanel.classList.contains('show');
            if (isOpen) {
                cartPanel.classList.remove('show');
                document.body.style.overflow = '';
                return;
            }
            cartPanel.classList.add('show');
            document.body.style.overflow = 'hidden';
        };
        if (cartClose) cartClose.addEventListener('click', function (e) { e.stopPropagation(); window.toggleCartPanel(); });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && cartPanel.classList.contains('show')) window.toggleCartPanel();
        });

        /* sepet açıkken dışarı tıklayınca kapat */
        var cartToggleBtn = document.getElementById('cartToggleBtn');
        document.addEventListener('click', function (e) {
            if (!cartPanel.classList.contains('show')) return;
            if (cartPanel.contains(e.target)) return;
            if (cartToggleBtn && cartToggleBtn.contains(e.target)) return;
            window.toggleCartPanel();
        });
    }

    async function refreshCartPanel() {
        var panel = document.getElementById('cartPanel');
        if (!panel) return;
        var fd = new FormData();
        fd.append('action', 'cart_panel_html');
        try {
            var r = await fetch(ACTIONS_URL, { method: 'POST', body: fd });
            var d = await r.json();
            if (!d.ok || !d.html) return;
            var tmp = document.createElement('div');
            tmp.innerHTML = d.html;
            var body = document.getElementById('cartPanelBody');
            var foot = document.getElementById('cartPanelFooter');
            var nb = tmp.querySelector('#cartPanelBody');
            var nf = tmp.querySelector('#cartPanelFooter');
            if (nb && body) body.replaceWith(nb); else if (nb) panel.appendChild(nb);
            if (nf && foot) foot.replaceWith(nf); else if (nf) panel.appendChild(nf); else if (foot) foot.remove();
            var badge = document.getElementById('navCartBadge');
            if (badge && d.cart_count !== undefined) {
                if (d.cart_count > 0) badge.textContent = d.cart_count; else badge.remove();
            }
        } catch (e) {}
    }

    window._cartPending = window._cartPending || {};
    window._cartBusy = window._cartBusy || {};

    function cartUpdateQty(pid, delta) {
        window._cartPending[pid] = window._cartPending[pid] || { d: 0, r: false };
        if (delta === 0) { window._cartPending[pid].r = true; window._cartPending[pid].d = 0; }
        else window._cartPending[pid].d += delta;
        if (window._cartBusy[pid]) return;
        cartProcessQty(pid);
    }

    async function cartProcessQty(id) {
        window._cartBusy[id] = true;
        var p = window._cartPending[id] || { d: 0, r: false };
        window._cartPending[id] = null;
        var doRemove = p.r;
        var delta = p.d;

        var item = document.getElementById('cartPanelItem-' + id) || document.getElementById('cartItem-' + id);
        var qtyEl = document.getElementById('panelQty-' + id) || document.getElementById('qty-' + id);
        var prevQty = parseInt(qtyEl ? qtyEl.textContent : '1', 10);
        var newQty = doRemove ? 0 : Math.max(1, prevQty + delta);
        if (!doRemove && newQty === prevQty) {
            window._cartBusy[id] = false;
            if (window._cartPending[id]) cartProcessQty(id);
            return;
        }
        if (qtyEl) qtyEl.textContent = newQty;

        var fd = new FormData();
        fd.append('action', 'cart_update_qty');
        fd.append('product_id', id);
        fd.append('quantity', newQty);
        try {
            var r = await fetch(ACTIONS_URL, { method: 'POST', body: fd });
            var d = await r.json();
            if (d.ok) {
                var totalEl = document.getElementById('cartPanelTotalPrice');
                if (totalEl && d.cart_total !== undefined) totalEl.textContent = window.nxFmt(d.cart_total);
                if (newQty < 1 && item) {
                    item.style.transition = 'opacity .3s';
                    item.style.opacity = '0';
                    setTimeout(function () { if (item.parentNode) item.parentNode.removeChild(item); checkCartEmpty(); }, 300);
                }
                if (d.empty) {
                    var body = document.getElementById('cartPanelBody');
                    if (body) body.innerHTML = '<div class="cart-empty"><span class="cart-empty-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2l2.5 12.5A2 2 0 0 0 9.5 18h8a2 2 0 0 0 2-1.6L21.5 8H6"/><path d="M10 22a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm8 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/></svg></span><p>'+((window.NX_LANG&&window.NX_LANG.cart_empty)||'Sepetiniz şu anda boş.')+'</p></div>';
                    var foot = document.getElementById('cartPanelFooter');
                    if (foot) foot.remove();
                }
                var badge = document.getElementById('navCartBadge');
                if (badge && d.cart_count !== undefined) {
                    if (d.cart_count > 0) badge.textContent = d.cart_count; else badge.remove();
                }
            } else {
                if (qtyEl) qtyEl.textContent = prevQty;
            }
        } catch (e) {
            if (qtyEl) qtyEl.textContent = prevQty;
            showToast('Bir hata oluştu.', false);
        } finally {
            window._cartBusy[id] = false;
            if (window._cartPending[id]) cartProcessQty(id);
        }
    }

    function checkCartEmpty() {
        var items = document.getElementById('cartPanelItems');
        if (!items) return;
        if (!items.querySelector('.cart-item')) {
            var body = document.getElementById('cartPanelBody');
            if (body) body.innerHTML = '<div class="cart-empty"><span class="cart-empty-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2l2.5 12.5A2 2 0 0 0 9.5 18h8a2 2 0 0 0 2-1.6L21.5 8H6"/><path d="M10 22a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm8 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/></svg></span><p>'+((window.NX_LANG&&window.NX_LANG.cart_empty)||'Sepetiniz şu anda boş.')+'</p></div>';
            var foot = document.getElementById('cartPanelFooter');
            if (foot) foot.remove();
        }
    }

    async function cartCheckout() {
        return nxCartPay();
    }

    window.cartUpdateQty = cartUpdateQty;
    window.cartCheckout = cartCheckout;

    /* ================== tek ürün sepete ekleme + hemen satın alma ================== */
    async function cartAdd(pid) {
        var fd = new FormData();
        fd.append('action', 'cart_add');
        fd.append('product_id', pid);
        try {
            var r = await fetch(ACTIONS_URL, { method: 'POST', body: fd });
            var d = await r.json();
            if (d.ok && d.cart_count !== undefined) {
                var badge = document.getElementById('navCartBadge');
                if (badge) { if (d.cart_count > 0) badge.textContent = d.cart_count; else badge.remove(); }
                refreshCartPanel();
            }
            showToast(d.msg, d.ok);
        } catch (e) { showToast('Bir hata oluştu.', false); }
    }

    var _buyNowPid = null;
    var buyNowModal = document.getElementById('buyNowModal');

    function openBuyNowModal() {
        if (!buyNowModal) return;
        buyNowModal.style.display = 'flex';
        requestAnimationFrame(function () { buyNowModal.classList.add('show'); });
    }
    window.closeBuyNowModal = function () {
        if (!buyNowModal) return;
        buyNowModal.classList.remove('show');
        setTimeout(function () { buyNowModal.style.display = 'none'; }, 200);
    };
    window.buyNow = function (pid) {
        _buyNowPid = pid;
        window._buyNowMethod = 'balance';
        var picker = document.getElementById('buyNowMethods');
        if (picker) {
            var btns = picker.querySelectorAll('[data-bn-method]');
            for (var i = 0; i < btns.length; i++) btns[i].classList.remove('is-active');
            var bal = picker.querySelector('[data-bn-method="balance"]');
            if (bal) bal.classList.add('is-active');
        }
        openBuyNowModal();
    };
    window.buyNowPick = function (method, el) {
        window._buyNowMethod = method || 'balance';
        var picker = document.getElementById('buyNowMethods');
        if (picker) {
            var btns = picker.querySelectorAll('[data-bn-method]');
            for (var i = 0; i < btns.length; i++) btns[i].classList.remove('is-active');
        }
        if (el) el.classList.add('is-active');
    };
    window.confirmBuyNow = async function () {
        if (!_buyNowPid) return;
        var btn = document.getElementById('buyNowConfirmBtn');
        var pid = _buyNowPid;
        var method = window._buyNowMethod || 'balance';
        closeBuyNowModal();
        if (btn) btn.disabled = false;
        var fd = new FormData();
        fd.append('action', 'buy_now');
        fd.append('product_id', pid);
        if (method && method !== 'balance') fd.append('method', method);
        try {
            var r = await fetch(ACTIONS_URL, { method: 'POST', body: fd });
            var d = await r.json();
            if (d.ok && d.html) {
                document.open();
                document.write(d.html);
                document.close();
            } else if (d && d.redirect) {
                vxGo(d.redirect);
            } else if (d.ok) {
                showToast(d.msg, true);
                var menu = document.getElementById('userDropdownMenu');
                if (menu) menu.classList.remove('open');
                setTimeout(function () { window.location.reload(); }, 1200);
            } else {
                showToast(d.msg, false);
            }
        } catch (e) { showToast('Bir hata oluştu.', false); }
    };

    if (buyNowModal) {
        buyNowModal.addEventListener('click', function (e) { if (e.target === buyNowModal) window.closeBuyNowModal(); });
    }

    window.cartAdd = cartAdd;

    /* ================== kredi yükleme ================== */
    var topupModal = document.getElementById('topupModal');
    var topupPayLabels = (window.NX_PAY_LABELS || { shopier: 'Shopier', paytr: 'PayTR', iyzico: 'iyzico', stripe: 'Stripe', paypal: 'PayPal', bitpay: 'BitPay', crypt: 'Kripto', paywant: 'Paywant', whop: 'Whop' });
    var topupPayDefault = (window.NX_PAY_DEFAULT || 'Shopier');

    window.openTopupModal = function (e) {
        if (e) e.preventDefault();
        if (uMenu) uMenu.classList.remove('open');
        if (topupModal) { topupModal.style.display = 'flex'; requestAnimationFrame(function () { topupModal.classList.add('show'); }); }
    };
    window.azCloseTopup = function () {
        if (!topupModal) return;
        topupModal.classList.remove('show');
        setTimeout(function () { topupModal.style.display = 'none'; }, 200);
    };
    window.closeTopupModal = window.azCloseTopup;

    window.setTopupAmount = function (val) {
        var inp = document.getElementById('topupAmount');
        if (inp) inp.value = val;
        document.querySelectorAll('.topup-chip[data-va]').forEach(function (b) {
            b.classList.toggle('active', parseInt(b.getAttribute('data-va'), 10) === val);
        });
    };
    window.setTopupMethod = function (m) {
        var hid = document.getElementById('topupMethod');
        if (hid) hid.value = m;
        document.querySelectorAll('.topup-chip[data-method]').forEach(function (b) {
            b.classList.toggle('active', b.getAttribute('data-method') === m);
        });
        var btn = document.getElementById('topupSubmitBtn');
        if (btn) btn.textContent = (topupPayLabels[m] || topupPayDefault) + ' ile Öde';
    };

function nxPayAzure(m){ var t=(window.NX_LANG&&window.NX_LANG.pay_with)||'{m} ile Öde'; return t.replace('{m}',m).replace('{method}',m); }
    window.submitTopup = async function () {
        var amount = parseFloat(document.getElementById('topupAmount').value);
        if (!amount || amount < ((window.NX_LANG&&window.NX_LANG.min_topup_val)||10)) { showToast((window.NX_LANG&&window.NX_LANG.min_topup)||'Minimum ₺10 yükleyebilirsin.', false); return; }
        var method = (document.getElementById('topupMethod') || {}).value || 'shopier';
        if (method.indexOf('mod:') === 0) { window.location.href = '/shop/module-pay?gateway=' + encodeURIComponent(method.slice(4)) + '&topup=' + encodeURIComponent(amount); return; }
        var btn = document.getElementById('topupSubmitBtn');
        btn.disabled = true; btn.innerHTML = '<span class="az-spin"></span> '+((window.NX_LANG&&window.NX_LANG.redirecting)||'Yönlendiriliyor...');
        var fd = new FormData();
        fd.append('action', 'balance_topup');
        fd.append('amount', amount);
        fd.append('method', method);
        try {
            var r = await fetch(ACTIONS_URL, { method: 'POST', body: fd });
            var d = await r.json();
            if (d.ok && d.html) { document.open(); document.write(d.html); document.close(); }
            else if (d.ok && d.redirect) { vxGo(d.redirect); }
            else { showToast(d.msg || ((window.NX_LANG&&window.NX_LANG.error)||'Hata oluştu.'), false); btn.disabled = false; btn.textContent = nxPayAzure(method); }
        } catch (e) { showToast(((window.NX_LANG&&window.NX_LANG.error)||'Hata oluştu.'), false); btn.disabled = false; btn.textContent = nxPayAzure(method); }
    };

    if (topupModal) {
        topupModal.addEventListener('click', function (e) { if (e.target === topupModal) window.azCloseTopup(); });
    }
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && topupModal && topupModal.style.display !== 'none') window.azCloseTopup();
    });

    /* ================== scroll reveal ================== */
    var reveals = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window && reveals.length) {
        var ro = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) {
                    en.target.classList.add('in');
                    ro.unobserve(en.target);
                }
            });
        }, { threshold: 0.12 });
        reveals.forEach(function (el) { ro.observe(el); });
    } else {
        reveals.forEach(function (el) { el.classList.add('in'); });
    }

    /* ================== hero chart dolgu animasyonu ================== */
    var fills = document.querySelectorAll('.hero-chart-fill');
    if (fills.length) {
        var doFill = function () {
            fills.forEach(function (f) {
                var w = f.getAttribute('data-w');
                if (w) f.style.width = w;
            });
        };
        if ('IntersectionObserver' in window) {
            var chartCard = document.querySelector('.hero-card');
            if (chartCard) {
                var ho = new IntersectionObserver(function (entries) {
                    entries.forEach(function (en) {
                        if (en.isIntersecting) { doFill(); ho.disconnect(); }
                    });
                }, { threshold: 0.3 });
                ho.observe(chartCard);
            } else doFill();
        } else doFill();
    }

    /* ================== sayaç animasyonu (hero istatistik) ================== */
    var stats = document.querySelectorAll('.stat-count');
    if (stats.length) {
        var animateCount = function (el) {
            var target = parseInt(el.getAttribute('data-count') || '0', 10);
            var dur = 1200, t0 = null;
            if (target === 0) return;
            var fmt = function (v) {
                return v >= 1000000 ? (v / 1000000).toFixed(1).replace('.', ',') + 'M+'
                     : v >= 1000    ? (v / 1000).toFixed(1).replace('.', ',') + 'B+'
                     : String(Math.round(v));
            };
            var step = function (ts) {
                if (!t0) t0 = ts;
                var p = Math.min((ts - t0) / dur, 1);
                var eased = 1 - Math.pow(1 - p, 3);
                el.textContent = fmt(target * eased);
                if (p < 1) requestAnimationFrame(step);
                else el.textContent = fmt(target);
            };
            requestAnimationFrame(step);
        };
        if ('IntersectionObserver' in window) {
            var statTarget = stats[0].closest('.hero-stats');
            var so = new IntersectionObserver(function (entries) {
                entries.forEach(function (en) {
                    if (en.isIntersecting) { stats.forEach(animateCount); so.disconnect(); }
                });
            }, { threshold: 0.3 });
            if (statTarget) so.observe(statTarget); else stats.forEach(animateCount);
        } else stats.forEach(animateCount);
    }

    /* ================== sepet ikonu pop animasyonu ================== */
    var cartBtn = document.getElementById('cartToggleBtn');
    if (cartBtn) {
        cartBtn.addEventListener('click', function () {
            cartBtn.classList.remove('pop');
            void cartBtn.offsetWidth;
            cartBtn.classList.add('pop');
        });
    }

})();