<?php
$pageTitle  = __('cart.title');
$activePage = 'cart';
$seoKey     = 'cart';
include ROOT_PATH . '/themes/default/includes/cart-state.php';
$cpShowCoupon = !function_exists('feature_active') || feature_active('coupons');
include __DIR__ . '/includes/header.php';
?>
<main style="max-width:1100px;margin:0 auto;padding:28px 18px 60px;">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:10px;">
        <h1 style="font-size:24px;font-weight:900;color:var(--text);display:flex;align-items:center;gap:10px;">
            <svg style="width:26px;height:26px;color:var(--brand)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2l2.5 12.5A2 2 0 0 0 9.5 18h8a2 2 0 0 0 2-1.6L21.5 8H6"/><path d="M10 22a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm8 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/></svg> <?= __('cart.title') ?>
            <span id="cpCountBadge" style="font-size:12px;font-weight:800;background:var(--brand-soft);color:var(--brand);border-radius:999px;padding:3px 12px;"><?= __('cart.count', ['n' => (int)$cartPageCount]) ?></span>
        </h1>
        <a href="/products" style="font-size:13px;font-weight:700;color:var(--muted);text-decoration:none;">← <?= __('cart.continue') ?></a>
    </div>

    <div id="cartPageEmpty" style="<?= empty($cartPageItems) ? '' : 'display:none;' ?>text-align:center;padding:70px 20px;background:var(--bg-soft);border:1px solid var(--line);border-radius:18px;color:var(--muted);">
        <p style="font-size:16px;font-weight:800;color:var(--text);margin-bottom:6px;"><?= __('cart.empty_page') ?></p>
        <p style="font-size:13px;margin-bottom:20px;"><?= __('cart.empty_hint') ?></p>
        <a href="/products" class="btn btn-primary"><?= __('cart.goto_store') ?></a>
    </div>

    <div id="cartPageWrap" class="cart-page-wrap" style="<?= empty($cartPageItems) ? 'display:none;' : '' ?>">
        <div id="cartPageList" class="cart-page-list">
            <?php foreach ($cartPageItems as $_cp): ?>
            <div id="cprow-<?= (int)$_cp['product_id'] ?>" class="cart-page-row" style="display:flex;align-items:center;gap:14px;background:var(--bg-soft);border:1px solid var(--line);border-radius:14px;padding:12px 14px;">
                <?php if (!empty($_cp['image_url'])): ?>
                <img src="<?= e($_cp['image_url']) ?>" alt="" style="width:56px;height:56px;border-radius:10px;object-fit:cover;flex-shrink:0;">
                <?php else: ?>
                <span style="width:56px;height:56px;border-radius:10px;background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center;font-weight:900;flex-shrink:0;">?</span>
                <?php endif; ?>
                <div style="flex:1;min-width:0;">
                    <div style="font-weight:800;font-size:14px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e($_cp['name']) ?></div>
                    <div style="font-size:12px;color:var(--muted);margin-top:2px;"><?= !empty($_cp['is_free']) ? __('cart.free_limit') : (fmt_money((float)$_cp['price']) . __('cart.per_item')) ?></div>
                </div>
                <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
                    <button type="button" onclick="cpQty(<?= (int)$_cp['product_id'] ?>,-1)" aria-label="<?= __('cart.decrease') ?>" class="btn btn-ghost btn-sm" style="min-width:32px;">−</button>
                    <span id="cqty-<?= (int)$_cp['product_id'] ?>" data-free="<?= !empty($_cp['is_free']) ? '1' : '0' ?>" style="min-width:24px;text-align:center;font-weight:900;font-size:14px;color:var(--text);"><?= (int)$_cp['quantity'] ?></span>
                    <button type="button" onclick="cpQty(<?= (int)$_cp['product_id'] ?>,1)" aria-label="<?= __('cart.increase') ?>" class="btn btn-primary btn-sm" <?= !empty($_cp['is_free']) ? 'disabled' : '' ?> style="min-width:32px;<?= !empty($_cp['is_free']) ? 'opacity:.4;cursor:not-allowed;' : '' ?>">+</button>
                </div>
                <div id="cline-<?= (int)$_cp['product_id'] ?>" style="font-weight:900;font-size:14px;color:var(--text);min-width:86px;text-align:right;flex-shrink:0;"><?= fmt_money((float)$_cp['price']*(int)$_cp['quantity']) ?></div>
                <button type="button" onclick="cpRemove(<?= (int)$_cp['product_id'] ?>)" title="<?= __('cart.remove') ?>" aria-label="<?= __('cart.remove') ?>" class="btn btn-ghost btn-sm" style="color:#e11d48;">×</button>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="cart-page-side" style="background:var(--bg-soft);border:1px solid var(--line);border-radius:16px;padding:18px;display:flex;flex-direction:column;gap:12px;position:sticky;top:76px;">
            <?php if ($cpShowCoupon): ?>
            <div>
                <label style="font-size:11px;font-weight:800;color:var(--muted);display:block;margin-bottom:6px;letter-spacing:.05em;"><?= __('cart.coupon_title') ?></label>
                <div style="display:flex;gap:8px;">
                    <input type="text" id="cpCoupon" placeholder="<?= __('cart.coupon_ph') ?>" autocomplete="off" class="modal-input" style="font-size:13px;text-transform:uppercase;" onkeydown="if(event.key==='Enter'){event.preventDefault();cpCoupon();}">
                    <button type="button" onclick="cpCoupon()" class="btn btn-primary btn-sm"><?= __('cart.coupon_apply') ?></button>
                </div>
                <div id="cpCouponMsg" style="display:none;font-size:11px;font-weight:700;margin-top:8px;"></div>
            </div>
            <?php endif; ?>
            <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--muted);font-weight:600;">
                <span><?= __('cart.subtotal') ?></span><span id="cpSub"><?= fmt_money((float)$cartPageSubtotal) ?></span>
            </div>
            <div id="cpDiscRow" style="<?= $cartPageCoupon ? '' : 'display:none;' ?>display:flex;justify-content:space-between;font-size:13px;font-weight:700;color:#16a34a;">
                <span><span id="cpDiscLabel"><?= $cartPageCoupon ? e($cartPageCoupon['label'] . ' (' . $cartPageCoupon['code'] . ')') : __('cart.discount') ?></span></span>
                <span id="cpDiscAmt">-<?= fmt_money((float)$cartPageDiscount) ?></span>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--line);padding-top:12px;">
                <span style="font-size:14px;font-weight:800;color:var(--text);"><?= __('cart.payable') ?></span>
                <span id="cpTotal" style="font-size:20px;font-weight:900;color:var(--text);"><?= fmt_money((float)$cartPageTotal) ?></span>
            </div>
            <a href="/shop/payment" id="cpPay" class="btn btn-primary btn-block btn-lg" style="text-decoration:none;justify-content:center;"><?= __('cart.checkout') ?></a>
        </div>
    </div>
</main>

<script>
(function(){
    var NX_CART = <?= json_encode(['count' => __('cart.count', ['n' => '%n%']), 'free_limit' => __('cart.free_limit'), 'per_item' => __('cart.per_item'), 'decrease' => __('cart.decrease'), 'increase' => __('cart.increase'), 'remove' => __('cart.remove'), 'free_toast' => __('cart.free_limit_toast'), 'update_fail' => __('cart.update_fail'), 'conn_err' => __('cart.conn_err'), 'remove_fail' => __('cart.remove_fail'), 'removed' => __('cart.removed_toast'), 'coupon_enter' => __('msg.coupon_enter'), 'applied' => __('cart.coupon_applied')]) ?>;
    window._cpBusy = window._cpBusy || {};
    function cpToast(m, ok){ if (window.showToast) showToast(m, ok); }
    function cpEsc(s){ return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
    function cpMoney(v){ return window.nxFmt(v); }
    async function cpPost(action, extra){
        var fd = new FormData();
        fd.append('action', action);
        if (extra) for (var k in extra) fd.append(k, extra[k]);
        var r = await fetch('/action.php', {method:'POST', body:fd});
        return r.json();
    }
    function cpRowHtml(it){
        var img = it.image_url
            ? '<img src="' + cpEsc(it.image_url) + '" alt="" style="width:56px;height:56px;border-radius:10px;object-fit:cover;flex-shrink:0;">'
            : '<span style="width:56px;height:56px;border-radius:10px;background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center;font-weight:900;flex-shrink:0;">?</span>';
        return '<div id="cprow-' + it.product_id + '" class="cart-page-row" style="display:flex;align-items:center;gap:14px;background:var(--bg-soft);border:1px solid var(--line);border-radius:14px;padding:12px 14px;">'
            + img
            + '<div style="flex:1;min-width:0;"><div style="font-weight:800;font-size:14px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + cpEsc(it.name) + '</div>'
            + '<div style="font-size:12px;color:var(--muted);margin-top:2px;">' + (it.is_free ? NX_CART.free_limit : cpMoney(it.price) + NX_CART.per_item) + '</div></div>'
            + '<div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">'
            + '<button type="button" onclick="cpQty(' + it.product_id + ',-1)" aria-label="' + NX_CART.decrease + '" class="btn btn-ghost btn-sm" style="min-width:32px;">−</button>'
            + '<span id="cqty-' + it.product_id + '" data-free="' + (it.is_free ? '1' : '0') + '" style="min-width:24px;text-align:center;font-weight:900;font-size:14px;color:var(--text);">' + it.quantity + '</span>'
            + '<button type="button" onclick="cpQty(' + it.product_id + ',1)" aria-label="' + NX_CART.increase + '" class="btn btn-primary btn-sm"' + (it.is_free ? ' disabled' : '') + ' style="min-width:32px;' + (it.is_free ? 'opacity:.4;cursor:not-allowed;' : '') + '">+</button></div>'
            + '<div id="cline-' + it.product_id + '" style="font-weight:900;font-size:14px;color:var(--text);min-width:86px;text-align:right;flex-shrink:0;">' + cpMoney(it.line_total) + '</div>'
            + '<button type="button" onclick="cpRemove(' + it.product_id + ')" title="' + NX_CART.remove + '" aria-label="' + NX_CART.remove + '" class="btn btn-ghost btn-sm" style="color:#e11d48;">×</button></div>';
    }
    async function cpRefresh(){
        var d;
        try { d = await cpPost('cart_state'); } catch(e){ return; }
        if (!d || !d.ok) return;
        var badge = document.getElementById('navCartBadge');
        if (badge) { if (d.count > 0) badge.textContent = d.count; else badge.remove(); }
        var wrap = document.getElementById('cartPageWrap');
        var empty = document.getElementById('cartPageEmpty');
        var cb = document.getElementById('cpCountBadge');
        if (cb) cb.textContent = NX_CART.count.replace('%n%', d.count);
        if (d.empty) {
            if (wrap) wrap.style.display = 'none';
            if (empty) empty.style.display = '';
            return;
        }
        if (wrap) wrap.style.display = 'grid';
        if (empty) empty.style.display = 'none';
        var list = document.getElementById('cartPageList');
        if (list && Array.isArray(d.items)) list.innerHTML = d.items.map(cpRowHtml).join('');
        var sub = document.getElementById('cpSub');
        if (sub) sub.textContent = cpMoney(d.subtotal);
        var dr = document.getElementById('cpDiscRow');
        if (dr) {
            if (d.coupon && d.discount > 0) {
                dr.style.display = 'flex';
                var dl = document.getElementById('cpDiscLabel');
                if (dl) dl.textContent = d.coupon.label + ' (' + d.coupon.code + ')';
                var da = document.getElementById('cpDiscAmt');
                if (da) da.textContent = '-' + cpMoney(d.discount);
            } else {
                dr.style.display = 'none';
            }
        }
        var tot = document.getElementById('cpTotal');
        if (tot) tot.textContent = cpMoney(d.total);
    }
    window.cpQty = async function(pid, delta){
        pid = parseInt(pid, 10);
        if (window._cpBusy[pid]) return;
        var qel = document.getElementById('cqty-' + pid);
        var prev = qel ? (parseInt(qel.textContent, 10) || 1) : 1;
        if (delta > 0 && qel && qel.dataset && qel.dataset.free === '1') { cpToast(NX_CART.free_toast, false); return; }
        if (delta < 0 && prev <= 1) return;
        window._cpBusy[pid] = true;
        try {
            var m = await cpPost('cart_update_qty', {product_id: pid, quantity: prev + delta});
            if (!m.ok) { cpToast(m.msg || NX_CART.update_fail, false); return; }
            await cpRefresh();
        } catch(e) { cpToast(NX_CART.conn_err, false); }
        finally { window._cpBusy[pid] = false; }
    };
    window.cpRemove = async function(pid){
        pid = parseInt(pid, 10);
        if (window._cpBusy[pid]) return;
        window._cpBusy[pid] = true;
        try {
            var m = await cpPost('cart_remove', {product_id: pid});
            if (!m.ok) { cpToast(m.msg || NX_CART.remove_fail, false); return; }
            await cpRefresh();
            cpToast(NX_CART.removed, true);
        } catch(e) { cpToast(NX_CART.conn_err, false); }
        finally { window._cpBusy[pid] = false; }
    };
    window.cpCoupon = async function(){
        var inp = document.getElementById('cpCoupon');
        var code = inp ? inp.value.trim() : '';
        var msg = document.getElementById('cpCouponMsg');
        if (!code) { cpToast(NX_CART.coupon_enter, false); return; }
        try {
            var d = await cpPost('apply_coupon', {code: code});
            if (msg) {
                msg.style.display = 'block';
                msg.style.color = d.ok ? '#16a34a' : '#e11d48';
                msg.textContent = d.ok ? (d.label ? d.label + NX_CART.applied : d.msg) : d.msg;
            }
            cpToast(d.msg, d.ok);
            if (d.ok) { if (inp) inp.value = ''; await cpRefresh(); }
        } catch(e) { cpToast(NX_CART.conn_err, false); }
    };
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
