<?php
defined('NEXUS_BOOT') or die;

$cpSlug = trim((string)($GLOBALS['custom_page_slug'] ?? ''));
$pageRow = null;
$nxViewId = 0;
$pdb = nexus_db();

if ($cpSlug !== '' && $pdb) {
    try {
        $st = $pdb->prepare('SELECT * FROM custom_pages WHERE slug=? AND status="published" LIMIT 1');
        $st->execute([$cpSlug]);
        $pageRow = $st->fetch();
    } catch (\PDOException $e) {
        error_log('[NS] custom-page: ' . $e->getMessage());
    }
}

if (function_exists('feature_active') && !feature_active('custom_pages')) $pageRow = null;

if (!$pageRow) {
    http_response_code(404);
    include __DIR__ . '/includes/header.php';
    ?>
    <main class="auth-shell">
      <div class="auth-card" style="max-width:480px;text-align:center;padding:48px 40px;">
        <div class="auth-card-icon" style="background:linear-gradient(135deg,var(--danger),#f7a3b1);box-shadow:0 8px 20px rgba(228,87,107,.3);">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M9 14h6m-6 4h4"/></svg>
        </div>
        <h1 class="auth-card-title"><?= __('page.notfound') ?></h1>
        <p class="auth-card-subtitle" style="margin-top:8px;"><?= __('page.notfound_sub') ?></p>
        <div style="margin-top:26px;"><a href="/" class="btn btn-primary"><?= __('page.home') ?></a></div>
      </div>
    </main>
    <?php
    include __DIR__ . '/includes/footer.php';
    exit;
}

$pageTitle = $pageRow['title'];
$_headerMetaDescription = (string)($pageRow['meta_description'] ?? '');
$activePage = '';

$nxSessionKey = session_id() ?: (md5(($_SERVER['REMOTE_ADDR'] ?? '') . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? '')));
$nxUserId = auth_check() ? (int)auth_user()['id'] : null;
$nxIp = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
$nxUa = strtolower(trim((string)($_SERVER['HTTP_USER_AGENT'] ?? '')));
$nxIsBot = $nxUa !== '' && preg_match('/bot|crawl|spider|slurp|mediapartners|baidu|sogou|exabot|facebot|ia_archiver|semrush|ahrefs|mj12|dotbot|petal|bytespider|gptbot|ccbot|claude|anthropic|yandex|duckduckbot|bingpreview|facebookexternalhit|twitterbot|linkedinbot|embedly|quora|pinterest|slackbot|telegrambot|discordbot|whatsapp|archive|fetch|monitor|uptime|pingdom/i', $nxUa);

try {
    if (!$nxIsBot) {
        $nxDup = $pdb->prepare('SELECT id FROM custom_page_views WHERE page_id=? AND session_key=? AND entered_at > DATE_SUB(NOW(), INTERVAL 30 MINUTE) ORDER BY id DESC LIMIT 1');
        $nxDup->execute([(int)$pageRow['id'], $nxSessionKey]);
        $nxViewId = (int)($nxDup->fetchColumn() ?: 0);
        if ($nxViewId === 0) {
            $vi = $pdb->prepare('INSERT INTO custom_page_views (page_id,session_key,user_id,ip,entered_at) VALUES (?,?,?,?,NOW())');
            $vi->execute([(int)$pageRow['id'], $nxSessionKey, $nxUserId, $nxIp]);
            $nxViewId = (int)$pdb->lastInsertId();
        }
    }
} catch (\PDOException $e) {
    error_log('[NS] custom-page view: ' . $e->getMessage());
}

include __DIR__ . '/includes/header.php';
?>
<?php $_cpIsHtml = (($pageRow['page_type'] ?? 'blog') === 'html'); ?>
<?php if ($_cpIsHtml): ?>
<main>
    <div style="width:100%;"><?= $pageRow['content'] ?></div>
</main>
<?php else: ?>
<main>
  <section class="section">
    <div class="container" style="max-width:900px;">
      <div style="margin-bottom:22px;">
        <a href="/" class="btn btn-ghost btn-sm">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 18l-6-6 6-6"/></svg>
          Ana Sayfa
        </a>
      </div>

      <div class="panel-card" style="padding:40px 44px;">
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:26px;padding-bottom:18px;border-bottom:1px solid var(--line);flex-wrap:wrap;">
          <span style="width:44px;height:44px;border-radius:13px;background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/></svg>
          </span>
          <div style="flex:1;min-width:200px;">
            <h2 style="font-family:var(--font-title);font-size:22px;font-weight:800;"><?= e($pageRow['title']) ?></h2>
            <p style="font-size:11.5px;color:var(--muted);"><?= __('page.updated') ?> <?= e($pageRow['updated_at']) ?></p>
          </div>
        </div>
        <div style="color:var(--text-2);font-size:15px;line-height:1.85;width:100%;"><?= $pageRow['content'] ?></div>
      </div>
    </div>
  </section>
</main>
<?php endif; ?>

<script>
(function(){
    var viewId = <?= (int)$nxViewId ?>;
    if (!viewId) return;
    var t0 = Date.now();
    function send() {
        var d = Math.round((Date.now() - t0) / 1000);
        if (navigator.sendBeacon) {
            var fd = new FormData();
            fd.append('action','page_leave');
            fd.append('view_id', String(viewId));
            fd.append('duration', String(d));
            var ct = document.querySelector('meta[name="csrf-token"]');
            if (ct) fd.append('_csrf_token', ct.getAttribute('content'));
            navigator.sendBeacon('/action.php', fd);
        }
    }
    window.addEventListener('pagehide', send);
    document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') send(); });
    setInterval(send, 20000);
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>