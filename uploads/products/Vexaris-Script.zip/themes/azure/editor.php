<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
return [
    'sections' => [
        [
            'key' => 'hero',
            'label' => '@edis.sec_hero',
            'icon' => 'fa-star',
            'fields' => [
                ['key' => 'hero_title', 'label' => '@edis.hero_title', 'type' => 'html', 'default' => __('home.hero_title')],
                ['key' => 'hero_desc', 'label' => '@edis.hero_desc', 'type' => 'textarea', 'default' => __('home.hero_desc')],
                ['key' => 'hero_btn1_text', 'label' => '@edis.hero_btn1_text', 'type' => 'text', 'default' => __('home.btn1')],
                ['key' => 'hero_btn1_url', 'label' => '@edis.hero_btn1_url', 'type' => 'text', 'default' => '/products'],
                ['key' => 'hero_btn2_text', 'label' => '@edis.hero_btn2_text', 'type' => 'text', 'default' => __('home.btn_support')],
                ['key' => 'hero_btn2_url', 'label' => '@edis.hero_btn2_url', 'type' => 'text', 'default' => '/support'],
                ['key' => 'hero_stat4_value', 'label' => '@edis.hero_stat4_value', 'type' => 'text', 'default' => '7/24'],
                ['key' => 'hero_stat4_label', 'label' => '@edis.hero_stat4_label', 'type' => 'text', 'default' => __('home.stat4label')],
                ['key' => 'hero_image', 'label' => '@edis.hero_image', 'type' => 'image', 'default' => ''],
            ],
        ],
        [
            'key' => 'ozellikler',
            'label' => '@edis.sec_ozellikler',
            'icon' => 'fa-cubes',
            'fields' => [
                ['key' => 'feat_title', 'label' => '@edis.feat_title', 'type' => 'text', 'default' => __('home.feat_title')],
                ['key' => 'feat_desc', 'label' => '@edis.feat_desc', 'type' => 'textarea', 'default' => __('home.feat_desc')],
                ['key' => 'feat1_title', 'label' => '@edis.feat1_title', 'type' => 'text', 'default' => __('home.feat1t')],
                                ['key' => 'feat1_desc', 'label' => '@edis.feat1_desc', 'type' => 'textarea', 'default' => __('home.feat1d')],
                ['key' => 'feat2_title', 'label' => '@edis.feat2_title', 'type' => 'text', 'default' => __('home.feat2t')],
                ['key' => 'feat2_desc', 'label' => '@edis.feat2_desc', 'type' => 'textarea', 'default' => __('home.feat2d')],
                ['key' => 'feat3_title', 'label' => '@edis.feat3_title', 'type' => 'text', 'default' => __('home.feat3t')],
                ['key' => 'feat3_desc', 'label' => '@edis.feat3_desc', 'type' => 'textarea', 'default' => __('home.feat3d')],
                ['key' => 'feat4_title', 'label' => '@edis.feat4_title', 'type' => 'text', 'default' => __('home.feat4t')],
                ['key' => 'feat4_desc', 'label' => '@edis.feat4_desc', 'type' => 'textarea', 'default' => __('home.feat4d')],
            ],
        ],
        [
            'key' => 'bolumler',
            'label' => '@edis.sec_bolumler',
            'icon' => 'fa-layer-group',
            'fields' => [
                ['key' => 'news_title', 'label' => '@edis.news_title', 'type' => 'text', 'default' => __('home.news_title')],
                ['key' => 'news_desc', 'label' => '@edis.news_desc', 'type' => 'textarea', 'default' => __('home.news_desc')],
                ['key' => 'shop_title', 'label' => '@edis.shop_title', 'type' => 'text', 'default' => __('home.shop_title')],
                ['key' => 'shop_desc', 'label' => '@edis.shop_desc', 'type' => 'textarea', 'default' => __('home.shop_desc_top')],
                ['key' => 'refs_title', 'label' => '@edis.refs_title', 'type' => 'text', 'default' => __('home.refs_title')],
                ['key' => 'refs_desc', 'label' => '@edis.refs_desc', 'type' => 'textarea', 'default' => __('home.refs_desc')],
                ['key' => 'faq_title', 'label' => '@edis.faq_title', 'type' => 'text', 'default' => __('home.faq_title')],
                ['key' => 'cta_title', 'label' => '@edis.cta_title', 'type' => 'text', 'default' => __('home.cta_title')],
                ['key' => 'cta_desc', 'label' => '@edis.cta_desc', 'type' => 'textarea', 'default' => __('home.cta_desc')],
                ['key' => 'cta_btn', 'label' => '@edis.cta_btn', 'type' => 'text', 'default' => __('home.cta_btn')],
            ],
        ],
        [
            'key' => 'renkler',
            'label' => '@edis.sec_renkler',
            'icon' => 'fa-palette',
            'fields' => [
                ['key' => 'color_brand', 'label' => '@edis.color_brand', 'type' => 'color', 'var' => '--brand', 'default' => '#2b6eff'],
                ['key' => 'color_brand2', 'label' => '@edis.color_brand2', 'type' => 'color', 'var' => '--brand-2', 'default' => '#17a8f5'],
                ['key' => 'color_brand_deep', 'label' => '@edis.color_brand_deep', 'type' => 'color', 'var' => '--brand-deep', 'default' => '#1e4fd6'],
            ],
        ],
    ],
];
