<?php
auth_redirect_if_logged_in('/');

$pageTitle  = __('auth.forgot_title');
$activePage = 'login';
$seoKey     = 'login';
$msg        = '';
$error      = '';

csrf_verify();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_captcha()) {
        $error = __('auth.captcha_fail');
    } else {
        $result = auth_request_password_reset($_POST['email'] ?? '');
        if ($result['ok']) {
            $msg = $result['msg'];
        } else {
            $error = $result['msg'];
        }
    }
}

$intSettings = [];
try {
    $intDb = nexus_db();
    $intSt = $intDb->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'");
    while ($intR = $intSt->fetch()) $intSettings[$intR['key']] = $intR['value'];
} catch (\PDOException $e) { error_log('[NS] forgot int: '.$e->getMessage()); }
$cfCaptcha    = ($intSettings['int_cf_captcha_enabled'] ?? '0')    === '1' && !empty($intSettings['int_cf_captcha_site_key']);
$recaptcha    = ($intSettings['int_recaptcha_enabled'] ?? '0')     === '1' && !empty($intSettings['int_recaptcha_site_key']);

include __DIR__ . '/includes/header.php';
?>
<main class="auth-shell">
  <div class="auth-card">

    <div class="auth-card-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
    </div>

    <h1 class="auth-card-title"><?= __('auth.forgot_h1') ?></h1>
    <p class="auth-card-subtitle"><?= __('auth.forgot_sub') ?></p>

    <?php if ($error): ?>
    <div class="auth-alert auth-alert--error">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v6m0 4h.01"/></svg>
      <?= e($error) ?>
    </div>
    <?php endif; ?>

    <?php if ($msg): ?>
    <div class="auth-alert auth-alert--success">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>
      <?= e($msg) ?>
    </div>
    <?php else: ?>

    <form method="POST" action="/forgot-password" autocomplete="on" novalidate>
    <?= csrf_field() ?>

      <div class="form-group">
        <label for="email" class="form-label">E-posta Adresi</label>
        <div class="form-input-icon-wrap">
          <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 7l-10 7L2 7"/></svg>
          <input type="email" id="email" name="email" class="form-input"
              placeholder="kullanici@ornek.com" autocomplete="email" required maxlength="255"
              value="<?= e($_POST['email'] ?? '') ?>">
        </div>
      </div>

      <?php if ($cfCaptcha): ?>
        <div class="cf-turnstile" data-sitekey="<?= e($intSettings['int_cf_captcha_site_key']) ?>" data-theme="light" style="margin-top:4px;"></div>
        <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
      <?php elseif ($recaptcha): ?>
        <div class="g-recaptcha" data-sitekey="<?= e($intSettings['int_recaptcha_site_key']) ?>" data-theme="light" style="margin-top:4px;"></div>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
      <?php endif; ?>

      <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top:22px;">
        <?= __('auth.forgot_btn') ?>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/></svg>
      </button>

    </form>

    <?php endif; ?>

    <p class="auth-links">
      <?= __('auth.forgot_remember') ?> <a href="/login"><?= __('auth.do_login') ?></a>
    </p>

  </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>