<footer class="footer">
<?php
$_footerSiteName = 'Vexaris';
$_footerDesc = __('footer.desc_azure');
$_footerLogo   = null;
$_footerLegal  = __('footer.rights');
$_socialLinks = ['discord'=>'','youtube'=>'','github'=>'','twitter'=>''];
$_fdb = nexus_db();
if ($_fdb) {
    try {
        $_r = $_fdb->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('site_name','site_logo','social_discord','social_youtube','social_github','social_twitter','footer_copyright','footer_copyright_line')");
        $_r->execute();
        foreach ($_r->fetchAll() as $row) {
            if ($row['key']==='site_name' && $row['value']) $_footerSiteName = $row['value'];
            if ($row['key']==='site_logo' && $row['value']) $_footerLogo = $row['value'];
            if ($row['key']==='footer_copyright' && $row['value']) $_footerDesc = $row['value'];
            if ($row['key']==='footer_copyright_line' && $row['value']) $_footerLegal = $row['value'];
            if (strncmp($row['key'],'social_',7)===0) $_socialLinks[substr($row['key'],7)] = $row['value'];
        }
    } catch (\Exception $e) {}
}
$__soc = $_socialLinks;
foreach ($__soc as $sk => $sv) { $__soc[$sk] = nx_safe_href($sv, ''); }
$_fcols = function_exists('footer_links_data') ? footer_links_data($_fdb) : [];
?>
  <div class="container footer-inner">

    <div class="footer-grid">

      <div class="footer-brand">
        <a href="/" class="footer-logo">
          <?php if ($_footerLogo): ?>
          <img src="<?= e($_footerLogo) ?>" alt="<?= e($_footerSiteName) ?>" style="height:40px;width:auto;max-width:200px;object-fit:contain;max-height:50px;">
          <?php else: ?>
          <span class="navbar-logo-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="14" rx="3"/><path d="M9 7h6"/></svg></span>
          <?= e(strtoupper($_footerSiteName)) ?>
          <?php endif; ?>
        </a>
        <p><?= e($_footerDesc) ?></p>
<div class="footer-socials">
          <?php foreach (['discord','youtube','github','twitter'] as $s): if (empty($__soc[$s])) continue; ?>
            <?php if ($s==='discord'): ?>
            <a href="<?= e($__soc[$s]) ?>" class="footer-social" title="Discord" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.3 4.4A19.8 19.8 0 0 0 15.9 3l-.24.48c1.3.4 2.4.9 3.44 1.6a18 18 0 0 0-12.2 0c1-.5 2.1-1.2 3.4-1.6L9.6 3a19.8 19.8 0 0 0-4.4 1.4C2.4 8.2 1.7 11.8 2 16.2c1.6 1.2 4 2.2 4 2.2l1.6-2.4c-.8-.3-1.6-.8-2.3-1.4l.6-.4c2 1.8 5.3 1.9 5.3 1.9h.8s3.3-.1 5.3-1.9l.6.4c-.7.6-1.5 1.1-2.3 1.4l1.6 2.4s2.4-1 4-2.2c.3-4.4-1.5-7.9-3.5-11.8zM8.5 13.6c-.7 0-1.3-.7-1.3-1.5s.6-1.5 1.3-1.5 1.3.7 1.3 1.5-.6 1.5-1.3 1.5zm7 0c-.7 0-1.3-.7-1.3-1.5s.6-1.5 1.3-1.5 1.3.7 1.3 1.5-.6 1.5-1.3 1.5z"/></svg></a>
            <?php elseif ($s==='youtube'): ?>
            <a href="<?= e($__soc[$s]) ?>" class="footer-social" title="YouTube" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M23.5 7.2s-.2-1.6-.9-2.3c-.9-.9-1.9-.9-2.4-1C16.8 3.6 12 3.6 12 3.6h-.5s-4.8 0-7.3.3c-.5.1-1.5.1-2.4 1-.7.7-.9 2.3-.9 2.3S.5 9.1.5 11v1.7c0 1.9.2 3.7.2 3.7s.2 1.6.9 2.3c.9.9 2 .9 2.5 1 1.8.2 7.9.3 7.9.3s4.8 0 7.3-.3c.5-.1 1.5-.1 2.4-1 .7-.7.9-2.3.9-2.3s.2-1.9.2-3.7V11c0-1.9-.2-3.8-.2-3.8zM9.7 14.9V8.7l6.4 3.1z"/></svg></a>
            <?php elseif ($s==='github'): ?>
            <a href="<?= e($__soc[$s]) ?>" class="footer-social" title="GitHub" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5A11.5 11.5 0 0 0 .5 12c0 5.1 3.3 9.4 7.9 10.9.6.1.8-.2.8-.6v-2c-3.2.7-3.9-1.4-3.9-1.4-.5-1.3-1.3-1.7-1.3-1.7-1-.7.1-.7.1-.7 1.2.1 1.8 1.2 1.8 1.2 1 1.8 2.7 1.3 3.4 1 .1-.8.4-1.3.7-1.6-2.6-.3-5.3-1.3-5.3-5.7 0-1.3.5-2.3 1.2-3.1-.1-.3-.5-1.5.1-3.1 0 0 1-.3 3.2 1.2a11 11 0 0 1 5.8 0C17 4.7 18 5 18 5c.6 1.6.2 2.8.1 3.1.8.8 1.2 1.8 1.2 3.1 0 4.4-2.7 5.4-5.3 5.7.4.4.8 1.1.8 2.2v3.3c0 .4.2.7.8.6A11.5 11.5 0 0 0 23.5 12 11.5 11.5 0 0 0 12 .5z"/></svg></a>
            <?php else: ?>
            <a href="<?= e($__soc[$s]) ?>" class="footer-social" title="X" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.2 2H21l-6.3 7.2L22 22h-5.8l-4.6-6-5.2 6H3.4l6.7-7.7L2.4 2h5.9l4.1 5.5zm-1 18h1.6L7.2 3.7H5.5z"/></svg></a>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>
      </div>

      <?php $_fpc = $_fcols['platform'] ?? null; if ($_fpc === null || !empty($_fpc['links'])): ?>
      <div>
        <p class="footer-col-title"><?= e(($_fpc['title'] ?? '') !== '' ? $_fpc['title'] : __('footer.col_platform')) ?></p>
        <ul class="footer-links">
          <?php if ($_fpc !== null): foreach ($_fpc['links'] as $_fl): $_flExt = preg_match('#^https?://#', $_fl['url']); ?>
          <li><a href="<?= e($_fl['url']) ?>" <?= $_flExt ? 'target="_blank" rel="noopener noreferrer"' : '' ?>><?php if ($_fl['icon'] !== ''): ?><i class="<?= e($_fl['icon']) ?>" style="width:16px;text-align:center;margin-right:2px;"></i><?php endif; ?><?= e($_fl['label']) ?></a></li>
          <?php endforeach; else: ?>
          <li><a href="/"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 11.5 12 4l9 7.5M5 10v9h14v-9"/></svg><?= __('nav.home') ?></a></li>
          <li><a href="/products"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/></svg><?= __('footer.products') ?></a></li>
          <li><a href="/news"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 4h16v12H7a3 3 0 0 0-3 3z"/></svg><?= __('nav.news') ?></a></li>
          <li><a href="/support"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13a8 8 0 0 1 16 0"/><rect x="2.5" y="13" width="5" height="6" rx="2"/><rect x="16.5" y="13" width="5" height="6" rx="2"/></svg><?= __('nav.support') ?></a></li>
          <?php endif; ?>
        </ul>
      </div>
      <?php endif; ?>

      <?php $_fac = $_fcols['account'] ?? null; if ($_fac === null || !empty($_fac['links'])): ?>
      <div>
        <p class="footer-col-title"><?= e(($_fac['title'] ?? '') !== '' ? $_fac['title'] : __('footer.col_account')) ?></p>
        <ul class="footer-links">
          <?php if ($_fac !== null): foreach ($_fac['links'] as $_fl): $_flExt = preg_match('#^https?://#', $_fl['url']); ?>
          <li><a href="<?= e($_fl['url']) ?>" <?= $_flExt ? 'target="_blank" rel="noopener noreferrer"' : '' ?>><?php if ($_fl['icon'] !== ''): ?><i class="<?= e($_fl['icon']) ?>" style="width:16px;text-align:center;margin-right:2px;"></i><?php endif; ?><?= e($_fl['label']) ?></a></li>
          <?php endforeach; else: ?>
          <li><a href="/login"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg><?= __('nav.login') ?></a></li>
          <li><a href="/register"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg><?= __('nav.register') ?></a></li>
          <li><a href="/user/dashboard"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="4" width="7" height="9" rx="2"/><rect x="13" y="4" width="7" height="5" rx="2"/><rect x="13" y="15" width="7" height="5" rx="2"/></svg><?= __('footer.dashboard') ?></a></li>
          <li><a href="/user/my-products"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M12 24V15"/></svg><?= __('footer.my_products') ?></a></li>
          <?php endif; ?>
        </ul>
      </div>
      <?php endif; ?>

      <?php $_flc = $_fcols['legal'] ?? null; if ($_flc === null || !empty($_flc['links'])): ?>
      <div>
        <p class="footer-col-title"><?= e(($_flc['title'] ?? '') !== '' ? $_flc['title'] : __('footer.col_legal')) ?></p>
        <ul class="footer-links">
          <?php if ($_flc !== null): foreach ($_flc['links'] as $_fl): $_flExt = preg_match('#^https?://#', $_fl['url']); ?>
          <li><a href="<?= e($_fl['url']) ?>" <?= $_flExt ? 'target="_blank" rel="noopener noreferrer"' : '' ?>><?php if ($_fl['icon'] !== ''): ?><i class="<?= e($_fl['icon']) ?>" style="width:16px;text-align:center;margin-right:2px;"></i><?php endif; ?><?= e($_fl['label']) ?></a></li>
          <?php endforeach; else: ?>
          <li><a href="/legal?p=privacy-policy"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3 4 6v5c0 5 3.4 8 8 10 4.6-2 8-5 8-10V6z"/></svg><?= __('legal.privacy') ?></a></li>
          <li><a href="/legal?p=terms-of-service"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 3h6l3 3v15H6V6z"/></svg><?= __('legal.terms') ?></a></li>
          <li><a href="/legal?p=refund-policy"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 3v5h5"/></svg><?= __('legal.refund') ?></a></li>
          <li><a href="/legal?p=cookie-policy"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2a10 10 0 1 0 10 10c0-1.5-1-2-2-2a2 2 0 0 1-2-2c0-1.5-1-2-2-2a2 2 0 0 1-2-2z"/></svg><?= __('legal.cookies') ?></a></li>
          <?php endif; ?>
        </ul>
      </div>
      <?php endif; ?>

    </div>

    <div class="footer-bottom">
      <p class="footer-copy">
        <span class="footer-copy-text">&copy; <?= date('Y') ?> <a href="/"><?= e($_footerSiteName) ?></a>. <?= e($_footerLegal) ?></span>
        <span class="footer-made"><?= function_exists('nx_brand_mark') ? nx_brand_mark() : 'Powered by <a href="https://' . strrev('rt.moc.siraxev') . '" rel="noopener">Vexaris</a>' ?></span>
      </p>
    </div>

  </div>
</footer>

<script src="/themes/azure/assets/js/main.js?v=4"></script>

<?php
/* --- Çerez onayı köprüsü: aktif tema yardımcılarıyla aynı işi yapar, görsel bu temaya özel --- */
$_showCookieBar = true;
$_cookiePref = 'pending';
$_cookieDb = nexus_db();
if ($_cookieDb && auth_check()) {
    try {
        $_ck = $_cookieDb->prepare('SELECT cookie_consent, cookie_pref FROM users WHERE id=?');
        $_ck->execute([(int)auth_user()['id']]);
        $_row2 = $_ck->fetch();
        if ($_row2 && (int)$_row2['cookie_consent']) {
            $_showCookieBar = false;
            $_cookiePref = in_array($_row2['cookie_pref'], ['all','essential'], true) ? $_row2['cookie_pref'] : 'essential';
        }
    } catch (\Exception $e) {}
} elseif (!auth_check()) {
    $_g = 'nx_cc_' . md5('vexaris_cookie_guest');
    if (isset($_COOKIE[$_g]) && in_array($_COOKIE[$_g], ['all','essential'], true)) {
        $_showCookieBar = false;
        $_cookiePref = $_COOKIE[$_g];
    }
}
if (isset($extraScripts)) echo $extraScripts;
if ($_cookiePref === 'all' && function_exists('tawkto_widget_code')) { $w = tawkto_widget_code(); if ($w) echo $w; }
if ($_cookiePref === 'all' && function_exists('jivochat_widget_code')) { $w = jivochat_widget_code(); if ($w) echo $w; }
if ($_cookiePref === 'all' && function_exists('crisp_widget_code')) { $w = crisp_widget_code(); if ($w) echo $w; }
if (($_cookiePref === 'all' || $_cookiePref === 'essential') && function_exists('analytics_widget_code')) { $w = analytics_widget_code(); if ($w) echo $w; }
?>

<?php if ($_showCookieBar): ?>
<div id="nexCookieBar" style="position:fixed;bottom:22px;left:50%;transform:translate(-50%,0);z-index:99999;width:min(560px,calc(100vw - 32px));background:#0d2038;border:1px solid rgba(255,255,255,.14);border-radius:18px;padding:22px;box-shadow:0 24px 60px rgba(4,16,32,.35);">
  <div style="display:flex;gap:14px;align-items:flex-start;">
    <span style="width:38px;height:38px;min-width:38px;border-radius:11px;background:rgba(43,110,255,.25);display:flex;align-items:center;justify-content:center;color:#8cb8ff;">
      <svg style="width:18px;height:18px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2a10 10 0 1 0 10 10c0-1.5-1-2-2-2a2 2 0 0 1-2-2c0-1.5-1-2-2-2a2 2 0 0 1-2-2z"/></svg>
    </span>
    <div style="flex:1;">
      <p style="font-size:15px;font-weight:800;color:#fff;margin:0;"><?= __('cookie.title_azure') ?></p>
      <p style="font-size:12.5px;color:#9db3ce;line-height:1.6;margin:6px 0 0;"><?= __('cookie.text_azure') ?> <a href="/legal?p=cookie-policy" style="color:#8cb8ff;text-decoration:underline;font-weight:600;"><?= __('cookie.policy_link_azure') ?></a> <?= __('cookie.text_d') ?></p>
      <div style="display:flex;gap:9px;margin-top:14px;flex-wrap:wrap;">
        <button onclick="acceptCookies('all')" class="btn btn-primary btn-sm"><?= __('cookie.accept_all') ?></button>
        <button onclick="acceptCookies('essential')" class="btn btn-ghost btn-sm" style="background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.16);color:#cfdff2;"><?= __('cookie.essential_azure') ?></button>
      </div>
    </div>
  </div>
</div>
<?php
$vxWidgets = [];
if (function_exists('analytics_widget_code')) $vxWidgets['analytics'] = analytics_widget_code();
if (function_exists('tawkto_widget_code')) $vxWidgets['tawkto'] = tawkto_widget_code();
if (function_exists('jivochat_widget_code')) $vxWidgets['jivo'] = jivochat_widget_code();
if (function_exists('crisp_widget_code')) $vxWidgets['crisp'] = crisp_widget_code();
$vxWidgets = array_filter($vxWidgets);
?>
<script type="application/json" id="vxWidgets"><?= json_encode($vxWidgets, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?></script>
<script>
window.__ccPref = <?= json_encode($_cookiePref) ?>;
function vxInjectWidgets(pref) {
  try {
    var el = document.getElementById('vxWidgets');
    var data = JSON.parse((el && el.textContent) || '{}');
    if (window.__vxWDone === pref) { window.__ccPref = pref; return; }
    var run = function(html) {
      if (!html) return;
      var tmp = document.createElement('div');
      tmp.innerHTML = html;
      var scripts = tmp.querySelectorAll('script');
      for (var i = 0; i < scripts.length; i++) {
        var s = scripts[i], ns = document.createElement('script');
        for (var j = 0; j < s.attributes.length; j++) ns.setAttribute(s.attributes[j].name, s.attributes[j].value);
        if (s.text) ns.text = s.text;
        document.body.appendChild(ns);
      }
    };
    if (pref === 'all' || pref === 'essential') run(data.analytics);
    if (pref === 'all') { run(data.tawkto); run(data.jivo); run(data.crisp); }
    window.__vxWDone = pref;
    window.__ccPref = pref;
  } catch (e) { window.__ccPref = pref; }
}
function vxCsrfToken() {
  var m = document.querySelector('meta[name="csrf-token"]');
  return m ? m.getAttribute('content') : '';
}
function acceptCookies(pref) {
  pref = (pref === 'essential') ? 'essential' : 'all';
  var hide = function() {
    vxInjectWidgets(pref);
    var bar = document.getElementById('nexCookieBar');
    if (bar) { bar.style.transition = 'transform .4s ease, opacity .4s ease'; bar.style.transform = 'translate(-50%,140%)'; bar.style.opacity='0'; setTimeout(function(){ bar.style.display='none'; },450); }
  };
  <?php if (auth_check()): ?>
  var fd = new FormData(); fd.append('action','cookie_consent'); fd.append('pref', pref);
  fetch('/action.php',{method:'POST',headers:{'X-CSRF-TOKEN':vxCsrfToken()},body:fd}).then(hide, hide);
  <?php else: ?>
  document.cookie = 'nx_cc_<?= md5('vexaris_cookie_guest') ?>=' + pref + '; path=/; max-age=' + (365*24*60*60);
  hide();
  <?php endif; ?>
}
</script>
<?php endif; ?>
<?php if (function_exists('do_action')) do_action('mod_footer'); ?>
</body>
</html>