<?php
/* azure teması — üst menü. SEO/meta ve oturum bağımlılıklarını korur. */

$_headerSiteName = 'Vexaris';
$_headerSite     = $_headerSiteName;
$_headerFavicon = null;
$_headerLogo    = null;
$_headerLoader  = '1';
$_headerCartCount = 0;
$_headerCartItems = [];
$_headerCartTotal = 0;
$_headerBalance   = 0;
$_headerPayLabel  = 'Shopier';
$_headerPayLabels = ['shopier'=>'Shopier','paytr'=>'PayTR','iyzico'=>'iyzico','stripe'=>'Stripe','paypal'=>'PayPal','bitpay'=>'BitPay','crypt'=>'Kripto','paywant'=>'Paywant','whop'=>'Whop','paddle'=>'Paddle','lemonsqueezy'=>'Lemon Squeezy','dodopayments'=>'DodoPayments'];
$_headerPayReady = [];
$vxTailwind = $vxTailwind ?? false;
$_hdb2 = nexus_db();
$_headerLinks = [];
if ($_hdb2) {
    try {
        $_hl = $_hdb2->prepare("SELECT `value` FROM settings WHERE `key`='header_links' LIMIT 1");
        $_hl->execute(); $_hv = $_hl->fetchColumn();
        if ($_hv) { $_dec = json_decode($_hv, true); if (is_array($_dec)) $_headerLinks = $_dec; }
    } catch (\Exception $e) {}
}
if ($_hdb2) {
    try {
        $_hs = $_hdb2->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('site_name','site_favicon','site_logo','loader_enabled')");
        $_hs->execute();
        foreach ($_hs->fetchAll() as $_r) {
            if ($_r['key'] === 'site_name')    $_headerSite = $_r['value'];
            if ($_r['key'] === 'site_favicon') $_headerFavicon = $_r['value'];
            if ($_r['key'] === 'site_logo')    $_headerLogo = $_r['value'];
            if ($_r['key'] === 'loader_enabled') $_headerLoader = $_r['value'] === '0' ? '0' : '1';
        }
        $_pp = $_hdb2->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('payment_shopier_active','payment_shopier_pat','payment_shopier_shop_slug','payment_shopier_osb_username','payment_shopier_osb_password','payment_paytr_active','payment_paytr_merchant_id','payment_paytr_merchant_key','payment_paytr_merchant_salt','payment_iyzico_active','payment_iyzico_api_key','payment_iyzico_secret_key','payment_stripe_active','payment_stripe_api_key','payment_paypal_active','payment_paypal_client_id','payment_paypal_secret','payment_bitpay_active','payment_bitpay_token','payment_crypt_active','payment_crypt_merchant_id','payment_crypt_api_key','payment_paywant_active','payment_paywant_api_key','payment_paywant_api_secret','payment_whop_active','payment_whop_api_key','payment_whop_account_id','payment_lemonsqueezy_active','payment_lemonsqueezy_api_key','payment_lemonsqueezy_signing_secret','payment_lemonsqueezy_store_id','payment_lemonsqueezy_variant_id','payment_dodopayments_active','payment_dodopayments_api_key','payment_dodopayments_webhook_secret','payment_dodopayments_product_id','payment_paddle_active','payment_paddle_api_key','payment_paddle_webhook_secret')");
        $_pp->execute();
        $_pm = [];
        foreach ($_pp->fetchAll() as $_pr) $_pm[$_pr['key']] = $_pr['value'];
        if (($_pm['payment_shopier_active'] ?? '0')==='1' && !empty($_pm['payment_shopier_pat'] ?? '') && !empty($_pm['payment_shopier_shop_slug'] ?? '') && !empty($_pm['payment_shopier_osb_username'] ?? '') && !empty($_pm['payment_shopier_osb_password'] ?? '')) $_headerPayReady[] = 'shopier';
        if (($_pm['payment_paytr_active'] ?? '0')==='1' && !empty($_pm['payment_paytr_merchant_id'] ?? '') && !empty($_pm['payment_paytr_merchant_key'] ?? '') && !empty($_pm['payment_paytr_merchant_salt'] ?? '')) $_headerPayReady[] = 'paytr';
        if (($_pm['payment_iyzico_active'] ?? '0')==='1' && !empty($_pm['payment_iyzico_api_key'] ?? '') && !empty($_pm['payment_iyzico_secret_key'] ?? '')) $_headerPayReady[] = 'iyzico';
        if (($_pm['payment_stripe_active'] ?? '0')==='1' && !empty($_pm['payment_stripe_api_key'] ?? '') && strncmp(trim((string)($_pm['payment_stripe_api_key'] ?? '')),'sk_',3)===0) $_headerPayReady[] = 'stripe';
        if (($_pm['payment_paypal_active'] ?? '0')==='1' && !empty($_pm['payment_paypal_client_id'] ?? '') && !empty($_pm['payment_paypal_secret'] ?? '')) $_headerPayReady[] = 'paypal';
        if (($_pm['payment_bitpay_active'] ?? '0')==='1' && !empty($_pm['payment_bitpay_token'] ?? '')) $_headerPayReady[] = 'bitpay';
        if (($_pm['payment_crypt_active'] ?? '0')==='1' && !empty($_pm['payment_crypt_merchant_id'] ?? '') && !empty($_pm['payment_crypt_api_key'] ?? '')) $_headerPayReady[] = 'crypt';
        if (($_pm['payment_paywant_active'] ?? '0')==='1' && !empty($_pm['payment_paywant_api_key'] ?? '') && !empty($_pm['payment_paywant_api_secret'] ?? '')) $_headerPayReady[] = 'paywant';
        if (($_pm['payment_whop_active'] ?? '0')==='1' && !empty($_pm['payment_whop_api_key'] ?? '') && !empty($_pm['payment_whop_account_id'] ?? '')) $_headerPayReady[] = 'whop';
        if (($_pm['payment_paddle_active'] ?? '0')==='1' && !empty($_pm['payment_paddle_api_key'] ?? '') && !empty($_pm['payment_paddle_webhook_secret'] ?? '')) $_headerPayReady[] = 'paddle';
        if (($_pm['payment_lemonsqueezy_active'] ?? '0')==='1' && !empty($_pm['payment_lemonsqueezy_api_key'] ?? '') && !empty($_pm['payment_lemonsqueezy_signing_secret'] ?? '') && !empty($_pm['payment_lemonsqueezy_store_id'] ?? '') && !empty($_pm['payment_lemonsqueezy_variant_id'] ?? '')) $_headerPayReady[] = 'lemonsqueezy';
        if (($_pm['payment_dodopayments_active'] ?? '0')==='1' && !empty($_pm['payment_dodopayments_api_key'] ?? '') && !empty($_pm['payment_dodopayments_webhook_secret'] ?? '') && !empty($_pm['payment_dodopayments_product_id'] ?? '')) $_headerPayReady[] = 'dodopayments';
        if (function_exists('modules_gateways')) {
            try {
                foreach (modules_gateways($_hdb2) as $gwCode => $gw) {
                    if (isset($_headerPayLabels[$gwCode])) continue;
                    $_headerPayLabels['mod:' . $gwCode] = $gw['label'];
                    $_headerPayReady[] = 'mod:' . $gwCode;
                }
            } catch (\Throwable $e) {}
        }
        if ($_headerPayReady) $_headerPayLabel = $_headerPayLabels[$_headerPayReady[0]];
        if (auth_check()) {
            $_uid = (int)auth_user()['id'];
            $_cs = $_hdb2->prepare('SELECT COUNT(*) FROM cart WHERE user_id=?'); $_cs->execute([$_uid]); $_headerCartCount = (int)$_cs->fetchColumn();
            $_ci = $_hdb2->prepare('SELECT c.product_id,c.quantity,p.name,p.price,p.image_url FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? ORDER BY c.added_at DESC'); $_ci->execute([$_uid]); $_headerCartItems = $_ci->fetchAll();
            $_headerCartTotal = array_sum(array_map(fn($i)=>$i['price']*$i['quantity'], $_headerCartItems));
            $_bs = $_hdb2->prepare('SELECT balance FROM users WHERE id=?'); $_bs->execute([$_uid]); $_headerBalance = (float)($_bs->fetchColumn() ?? 0);
        }
    } catch (\Exception $e) {}
}

/* SEO */
$_seoT = null; $_seoD = null; $_seoK = $seoKey ?? '';
if ($_seoK !== '' && $_hdb2) {
    try {
        $_sk = 'seo_'.$_seoK.'_title'; $_sd = 'seo_'.$_seoK.'_description';
        $_s = $_hdb2->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN (?,?)");
        $_s->execute([$_sk,$_sd]);
        foreach ($_s->fetchAll() as $_r) {
            if ($_r['key']===$_sk && trim((string)$_r['value'])!=='') $_seoT = trim((string)$_r['value']);
            if ($_r['key']===$_sd && trim((string)$_r['value'])!=='') $_seoD = trim((string)$_r['value']);
        }
    } catch (\Exception $e) {}
}
?>
<!DOCTYPE html>
<html lang="<?= lang_active() ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= htmlspecialchars($_seoD !== null && $_seoD !== '' ? $_seoD : __('seo.default_description_azure', ['site' => $_headerSite])) ?>">
<meta name="theme-color" content="#2b6eff">
<meta name="csrf-token" content="<?= csrf_token() ?>">
<?php if ($_headerFavicon): ?>
<link rel="icon" type="image/x-icon" href="<?= e($_headerFavicon) ?>">
<link rel="shortcut icon" href="<?= e($_headerFavicon) ?>">
<?php endif; ?>
<title><?php
    $_titles = ['home'=>__('seo.home'),'products'=>__('seo.products'),'news'=>__('seo.news_azure'),'support'=>__('seo.support'),'login'=>__('seo.login'),'register'=>__('seo.register'),'404'=>__('seo.notfound')];
    if ($_seoT) $__ogTitle = $_seoT;
    elseif ($_seoK !== '' && isset($_titles[$_seoK])) $__ogTitle = $_headerSite.' | '.$_titles[$_seoK];
    elseif (isset($pageTitle)) $__ogTitle = $pageTitle.' — '.$_headerSite;
    else $__ogTitle = $_headerSite.' — '.__('seo.default_suffix');
    echo e($__ogTitle);
?></title>
<?= site_og_tags($_hdb2 ?? null, $__ogTitle ?? '', ($_seoD !== null && $_seoD !== '' ? $_seoD : (isset($_headerMetaDescription) && $_headerMetaDescription !== '' ? $_headerMetaDescription : ''))) ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Outfit:wght@600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
<?php if (!empty($vxTailwind)): ?>
<script src="https://cdn.tailwindcss.com"></script>
<script>try{tailwind.config={corePlugins:{preflight:false}};}catch(e){}</script>
<?php endif; ?>
<link rel="stylesheet" href="/themes/azure/assets/css/style.css?v=21">
<?php if (function_exists('theme_vars_css')) theme_vars_css('azure'); ?>
<script>
(function(){
  var meta = document.querySelector('meta[name="csrf-token"]');
  var token = meta ? meta.getAttribute('content') : '';
  window.vxGo = function(u){
    var s = String(u == null ? '' : u);
    if (!s) return false;
    if (s.charAt(0) !== '/') return false;
    if (s.charAt(1) === '/' || s.charAt(1) === '\\') return false;
    window.location.href = s;
    return true;
  };
  if (!meta) return;
  var origFetch = window.fetch;
  window.fetch = function(url, opts){
    opts = opts || {};
    if ((opts.method || 'GET').toUpperCase() === 'POST') {
      var headers = new Headers(opts.headers || {});
      if (!headers.has('X-CSRF-Token')) headers.set('X-CSRF-Token', token);
      if (!headers.has('X-Requested-With')) headers.set('X-Requested-With', 'XMLHttpRequest');
      opts.headers = headers;
    }
    return origFetch.call(this, url, opts).then(function(r){
      try {
        var ct = (r.headers && r.headers.get('content-type')) || '';
        if (ct.indexOf('application/json') === -1) return r;
        return r.clone().json().then(function(d){
          if (d && d.ok === false && (d.code === 'csrf_fail' || (typeof d.msg === 'string' && (d.msg.indexOf('Güvenlik doğrulaması') !== -1 || d.msg.indexOf('Security verification') !== -1)))) {
            try {
              if (!sessionStorage.getItem('_vx_csrf_reload')) {
                sessionStorage.setItem('_vx_csrf_reload', '1');
                location.reload();
                return new Promise(function(){});
              }
            } catch(e){}
          } else {
            try { sessionStorage.removeItem('_vx_csrf_reload'); } catch(e){}
          }
          return r;
        }, function(){ return r; });
      } catch(e){ return r; }
    });
  };
})();
</script>
<?php if (isset($extraHead)) echo $extraHead; ?>
<script>
window.NX_PAY_LABELS = <?= json_encode($_headerPayLabels, JSON_UNESCAPED_UNICODE) ?>;
window.NX_PAY_DEFAULT = <?= json_encode($_headerPayLabel, JSON_UNESCAPED_UNICODE) ?>;
window.NX_LANG = <?= json_encode(['min_topup'=>__('topup.min_error_azure', ['m' => fmt_money_short(topup_min_amount())]),'min_topup_val'=>topup_min_amount(),'redirecting'=>__('topup.redirecting'),'error'=>__('topup.error'),'verifying'=>__('topup.verifying'),'approved'=>__('topup.approved'),'processing'=>__('topup.processing'),'pay_with'=>__('topup.pay_with'),'cart_empty'=>__('cart.empty'),'confirm_title'=>__('cart.balance_confirm_title'),'confirm_text'=>__('cart.balance_confirm', ['total' => '{total}']),'confirm_yes'=>__('cart.balance_confirm_yes'),'confirm_no'=>__('cart.balance_confirm_no')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
window.NX_MONEY = <?= json_encode(fx_js_config(), JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
window.nxFmt = function(v){var m=window.NX_MONEY||{sym:'₺',pre:true,dec:',',thou:'.',sp:''};var n=parseFloat(v||0);if(!isFinite(n))n=0;var ng=n<0;n=Math.abs(n);var s=n.toFixed(2).split('.');s[0]=s[0].replace(/\B(?=(\d{3})+(?!\d))/g,m.thou);var t=s.join(m.dec);if(ng)t='-'+t;return m.pre?m.sym+t:t+m.sp+m.sym;};
function nxPayWith(m){ return (window.NX_LANG.pay_with||'{m} ile Öde').replace('{m}',m).replace('{method}',m); }
</script>
<script>
(function(){
  try { if (localStorage.getItem('az-theme') === 'dark') document.documentElement.classList.add('az-dark'); } catch (e) {}
  function bindAzTheme(){
    var b = document.getElementById('azThemeToggle');
    if (!b) return;
    b.addEventListener('click', function(){
      var h = document.documentElement;
      h.classList.toggle('az-dark');
      try { localStorage.setItem('az-theme', h.classList.contains('az-dark') ? 'dark' : 'light'); } catch (e) {}
      h.classList.remove('theme-switch');
      void h.offsetWidth;
      h.classList.add('theme-switch');
      setTimeout(function(){ h.classList.remove('theme-switch'); }, 700);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bindAzTheme);
  else bindAzTheme();
})();
</script>
<?php if (function_exists('do_action')) do_action('mod_head'); ?>
</head>
<body class="az">
<?php if (function_exists('slider_render')) slider_render(); ?>
<?php if (function_exists('do_action')) do_action('body_top'); ?>
<?php if ($_headerLoader === '1'): ?>
<div id="az-boot" aria-hidden="true">
  <div class="az-boot-center">
    <?php if ($_headerLogo): ?>
    <img src="<?= e($_headerLogo) ?>" alt="<?= e($_headerSite) ?>" class="az-boot-logo">
    <?php else: ?>
    <div class="az-boot-logo-ph"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="14" rx="3"/><path d="M9 7h6M12 7v10" stroke-linecap="round"/></svg></div>
    <?php endif; ?>
    <div class="az-boot-title"><?= e($_headerSite) ?></div>
    <div class="az-boot-loader"><span></span></div>
  </div>
  <a href="https://vexaris.com.tr" target="_blank" rel="noopener" class="az-boot-powered">Powered by <span>Vexaris</span></a>
</div>
<style>
#az-boot{position:fixed;inset:0;z-index:99999;background:var(--bg);display:none;flex-direction:column;justify-content:space-between;align-items:center;padding:44px 20px 28px;transition:opacity .7s,visibility .7s;}
#az-boot.is-hidden{opacity:0;visibility:hidden;pointer-events:none;}
.az-boot-center{display:flex;flex-direction:column;align-items:center;text-align:center;margin:auto;}
.az-boot-logo{width:84px;height:84px;border-radius:22px;object-fit:cover;box-shadow:var(--shadow-lg);}
.az-boot-logo-ph{width:84px;height:84px;border-radius:22px;background:linear-gradient(135deg,var(--brand),var(--brand-2));display:flex;align-items:center;justify-content:center;color:#fff;box-shadow:0 12px 32px var(--brand-glow);}
.az-boot-logo-ph svg{width:38px;height:38px;}
.az-boot-title{font-family:var(--font-title);font-size:1.35rem;font-weight:800;margin:16px 0 22px;color:var(--text);}
.az-boot-loader{width:180px;height:4px;border-radius:999px;background:var(--line);overflow:hidden;}
.az-boot-loader span{display:block;height:100%;width:40%;border-radius:999px;background:linear-gradient(90deg,var(--brand),var(--brand-2));animation:azBootSlide 1.1s ease-in-out infinite;}
@keyframes azBootSlide{0%{transform:translateX(-100%);}100%{transform:translateX(450%);}}
.az-boot-powered{font-size:.82rem;color:var(--dim);text-decoration:none;display:inline-flex;align-items:center;gap:4px;}
.az-boot-powered span{color:var(--brand);font-weight:700;}
</style>
<script>
(function(){
  var boot=document.getElementById('az-boot');
  if(!boot) return;
  var path=window.location.pathname;
  var isIndex=(path==='/'||path==='/index.php'||path==='/index');
  var seen=false;
  try{ seen=sessionStorage.getItem('az_boot_seen')==='1'; }catch(e){}
  var external=true;
  try{
    var r=document.referrer;
    if(r) external=(new URL(r).host!==location.host);
  }catch(e){}
  if(!isIndex||(seen&&!external)){ boot.style.display='none'; return; }
  boot.style.display='flex';
  setTimeout(function(){
    boot.classList.add('is-hidden');
    try{ sessionStorage.setItem('az_boot_seen','1'); }catch(e){}
    setTimeout(function(){ boot.style.display='none'; },700);
  },1200);
})();
</script>
<?php endif; ?>
<?php $authUser = auth_check() ? auth_user() : null; ?>

<nav class="navbar">
  <div class="container navbar-inner">

    <a href="/" class="navbar-logo">
      <?php if ($_headerLogo): ?>
      <img src="<?= e($_headerLogo) ?>" alt="<?= e($_headerSite) ?>" style="height:42px;width:auto;max-width:210px;object-fit:contain;max-height:52px;">
      <?php else: ?>
      <span class="navbar-logo-icon" aria-hidden="true">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="14" rx="3"/><path d="M9 7h6M12 7v10" stroke-linecap="round"/></svg>
      </span>
      <span><?= e($_headerSite) ?></span>
      <?php endif; ?>
    </a>

    <button class="navbar-toggle" id="navToggle" aria-label="<?= e(__('nav.menu_toggle')) ?>" aria-expanded="false">
      <svg id="navToggleIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
    </button>

    <ul class="navbar-links" id="navLinks">
      <?php if (!empty($_headerLinks)): foreach ($_headerLinks as $hl): $_hlUrl = nx_safe_href($hl['url'] ?? '', '/'); $isExt = preg_match('#^https?://#', $_hlUrl); ?>
        <li><a href="<?= e($_hlUrl) ?>" <?= $isExt ? 'target="_blank" rel="noopener"' : '' ?>><?php if (!empty($hl['icon'])): ?><i class="<?= e($hl['icon']) ?>" style="margin-right:6px"></i><?php endif; ?><?= e($hl['label']) ?></a></li>
      <?php endforeach; else: ?>
        <li><a href="/" <?= ($activePage??'')==='home' ? 'class="active"' : '' ?>><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11.5 12 4l9 7.5"/><path d="M5 10.5V20h5v-6h4v6h5v-9.5"/></svg><?= __('nav.home') ?></a></li>
        <li><a href="/products" <?= ($activePage??'')==='products' ? 'class="active"' : '' ?>><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M3 9.5 12 15l9-5.5M12 24V15"/></svg><?= __('nav.shop') ?></a></li>
        <li><a href="/news" <?= ($activePage??'')==='news' ? 'class="active"' : '' ?>><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v12H7a3 3 0 0 0-3 3z"/><path d="M8 8h8M8 11h5"/></svg><?= __('nav.news') ?></a></li>
        <li><a href="/support" <?= ($activePage??'')==='support' ? 'class="active"' : '' ?>><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13a8 8 0 0 1 16 0"/><rect x="2.5" y="13" width="5" height="6" rx="2"/><rect x="16.5" y="13" width="5" height="6" rx="2"/><path d="M20 19a3 3 0 0 1-3 3h-4"/></svg><?= __('nav.support') ?></a></li>
      <?php endif; ?>
      <?php if (function_exists('do_action')) do_action('header_menu_after'); ?>
    </ul>

    <div class="navbar-actions" id="navActions">
      <button class="nav-theme-toggle" id="azThemeToggle" aria-label="<?= e(__('nav.theme_toggle')) ?>" title="<?= e(__('nav.theme_title_azure')) ?>">
        <svg class="ic-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/></svg>
        <svg class="ic-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
      </button>
      <?php if ($authUser): ?>
        <button id="cartToggleBtn" class="nav-cart-btn" aria-label="<?= e(__('nav.cart')) ?>" onclick="toggleCartPanel(event)">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2l2.5 12.5A2 2 0 0 0 9.5 18h8a2 2 0 0 0 2-1.6L21.5 8H6"/><path d="M10 22a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm8 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/></svg>
          <?php if ($_headerCartCount > 0): ?><span class="nav-cart-badge" id="navCartBadge"><?= $_headerCartCount ?></span><?php endif; ?>
        </button>
        <div class="nav-user">
          <button class="nav-user-btn" id="userDropdownBtn" aria-haspopup="true">
            <span class="nav-balance"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="8"/><path d="M12 7v10M9 9.5h6"/></svg><?= fmt_money($_headerBalance) ?></span>
            <img src="<?= e($authUser['avatar']) ?>" alt="" class="nav-user-avatar">
            <span class="nav-user-name"><?= e($authUser['username']) ?></span>
            <svg class="nav-user-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
          </button>
          <div class="nav-dropdown" id="userDropdownMenu">
            <a href="/user/dashboard" class="nav-dropdown-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="4" width="7" height="9" rx="2"/><rect x="13" y="4" width="7" height="5" rx="2"/><rect x="13" y="15" width="7" height="5" rx="2"/><rect x="4" y="19" width="7" height="1" rx="1"/></svg><?= __('nav.dashboard') ?></a>
            <a href="/user/redeem-code" class="nav-dropdown-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h16v12H4z"/><path d="M12 8V4m0 0h-2m2 0h2"/><path d="M9 13h6m-6 4h6"/></svg><?= __('nav.redeem') ?></a>
            <a href="/user/settings" class="nav-dropdown-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M4.2 6.5l2.6 1.5m10.4 6 2.6 1.5M4.2 17.5l2.6-1.5m10.4-6 2.6-1.5"/></svg><?= __('nav.settings') ?></a>
            <button onclick="openTopupModal(event)" class="nav-dropdown-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="8"/><path d="M12 7v10M9 9.5h6"/></svg><?= __('nav.topup') ?></button>
            <?php if (($authUser['role'] ?? 'user') !== 'user'): ?>
            <a href="/admin/dashboard.php" class="nav-dropdown-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 6v5c0 5 3.4 8 8 10 4.6-2 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/></svg><?= __('nav.admin') ?></a>
            <?php endif; ?>
            <div class="nav-dropdown-divider"></div>
            <form method="POST" action="/logout" style="margin:0;">
                <?= csrf_field() ?>
                <button type="submit" class="nav-dropdown-item nav-dropdown-item--danger" style="width:100%;background:none;border:none;cursor:pointer;font:inherit;text-align:left;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/></svg><?= __('nav.logout') ?></button>
            </form>
          </div>
        </div>
      <?php else: ?>
        <a href="/login" class="btn btn-ghost btn-sm btn--login"><?= __('nav.login') ?></a>
        <a href="/register" class="btn btn-primary btn-sm btn--signup"><?= __('nav.register') ?></a>
      <?php endif; ?>
    </div>

  </div>
</nav>

<!-- Sepet paneli -->
<?php
$aItems = $_headerCartItems;
$aTotal = $_headerCartTotal;
?>
<div id="cartPanel" class="cart-panel" aria-hidden="true">
  <div class="cart-panel-head">
    <span class="cart-panel-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2l2.5 12.5A2 2 0 0 0 9.5 18h8a2 2 0 0 0 2-1.6L21.5 8H6"/><path d="M10 22a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm8 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/></svg><?= __('cart.title') ?></span>
    <button class="cart-close" id="cartCloseBtn" aria-label="<?= e(__('modal.close')) ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
  </div>
  <div class="cart-panel-body" id="cartPanelBody">
    <?php if (empty($aItems)): ?>
    <div class="cart-empty">
      <span class="cart-empty-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2l2.5 12.5A2 2 0 0 0 9.5 18h8a2 2 0 0 0 2-1.6L21.5 8H6"/><path d="M10 22a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm8 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/></svg></span>
      <p><?= __('cart.empty') ?></p>
    </div>
    <?php else: ?>
    <div class="cart-items" id="cartPanelItems">
      <?php foreach ($aItems as $_ci1k): ?>
      <div class="cart-item" id="cartPanelItem-<?= (int)$_ci1k['product_id'] ?>">
        <?php if (!empty($_ci1k['image_url'])): ?>
         <img src="<?= e($_ci1k['image_url']) ?>" class="cart-item-img" width="80" height="80" alt="">
        <?php else: ?>
        <span class="cart-item-img-ph"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="4" y="3" width="16" height="14" rx="3"/><path d="M9 7h6"/></svg></span>
        <?php endif; ?>
        <div class="cart-item-info">
          <p class="cart-item-name"><?= e($_ci1k['name']) ?></p>
          <p class="cart-item-price"><?= fmt_money((float)$_ci1k['price']) ?></p>
        </div>
        <div class="cart-item-qty">
          <button onclick="cartUpdateQty(<?= (int)$_ci1k['product_id'] ?>,-1)" class="cart-qty-btn" aria-label="<?= e(__('cart.decrease')) ?>">−</button>
          <span class="cart-qty-val" id="panelQty-<?= (int)$_ci1k['product_id'] ?>"><?= (int)$_ci1k['quantity'] ?></span>
          <button onclick="cartUpdateQty(<?= (int)$_ci1k['product_id'] ?>,1)" class="cart-qty-btn" aria-label="<?= e(__('cart.increase')) ?>">+</button>
        </div>
        <button onclick="cartUpdateQty(<?= (int)$_ci1k['product_id'] ?>,0)" class="cart-remove" aria-label="<?= e(__('cart.remove')) ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2m-9 0 1 14h8l1-14"/></svg></button>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
  <?php if (!empty($aItems)): ?>
  <div class="cart-panel-foot" id="cartPanelFooter">
    <div class="cart-total">
      <span class="cart-total-label"><?= __('cart.total') ?></span>
      <span class="cart-total-price" id="cartPanelTotalPrice"><?= fmt_money((float)$aTotal) ?></span>
    </div>
    <a href="/cart" class="btn btn-primary btn-block btn-lg" style="text-decoration:none;justify-content:center;">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2l2.5 12.5A2 2 0 0 0 9.5 18h8a2 2 0 0 0 2-1.6L21.5 8H6"/><path d="M10 22a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm8 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/></svg><?= __('cart.go') ?>
    </a>
  </div>
  <?php endif; ?>
</div>

<!-- Kredi Yükleme kutusu -->
<div id="topupModal" class="modal-shade" style="display:none;">
  <div class="modal-box">
    <div class="modal-box-head">
      <span class="modal-box-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="8"/><path d="M12 7v10M9 9.5h6"/></svg><?= __('topup.title') ?></span>
      <button class="cart-close" onclick="window.closeTopupModal()" aria-label="<?= __('modal.close') ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
    </div>
    <div class="modal-box-body">
      <div class="modal-field">
        <label><?= __('topup.amount_azure') ?></label>
        <div class="topup-presets" style="margin-bottom:12px;">
          <button type="button" onclick="setTopupAmount(50)"  class="topup-chip" data-va="50"><?= fmt_money_short(50) ?></button>
          <button type="button" onclick="setTopupAmount(100)" class="topup-chip" data-va="100"><?= fmt_money_short(100) ?></button>
          <button type="button" onclick="setTopupAmount(200)" class="topup-chip" data-va="200"><?= fmt_money_short(200) ?></button>
          <button type="button" onclick="setTopupAmount(500)" class="topup-chip" data-va="500"><?= fmt_money_short(500) ?></button>
        </div>
        <input type="number" class="modal-input" id="topupAmount" min="<?= topup_min_amount() ?>" step="1" value="100" placeholder="<?= __('topup.min_placeholder', ['m' => fmt_money_short(topup_min_amount())]) ?>">
      </div>
      <p class="modal-hint"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="8"/><path d="M12 8v4m0 4h.01"/></svg><?= __('topup.balance_info_azure') ?></p>
      <?php if (count($_headerPayReady) > 1): ?>
      <div class="modal-field">
        <label><?= __('topup.method') ?></label>
        <div class="topup-presets">
          <?php foreach ($_headerPayReady as $m): ?>
          <button type="button" class="topup-chip <?= $m === $_headerPayReady[0] ? 'active' : '' ?>" data-method="<?= e($m) ?>" onclick="setTopupMethod('<?= e($m) ?>')"><?= e($_headerPayLabels[$m]) ?></button>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>
      <input type="hidden" id="topupMethod" value="<?= htmlspecialchars($_headerPayReady[0] ?? 'shopier', ENT_QUOTES) ?>">
    </div>
    <div class="modal-box-foot">
      <button class="btn btn-ghost" onclick="window.azCloseTopup()"><?= __('topup.cancel') ?></button>
      <button class="btn btn-primary" id="topupSubmitBtn" onclick="submitTopup()"><?= htmlspecialchars(__('topup.pay_with', ['method' => $_headerPayLabel])) ?></button>
    </div>
  </div>
</div>