<?php
$pageTitle  = 'Ana Sayfa';
$activePage = 'home';
$seoKey     = 'home';

$db = nexus_db();

/* ── gerçek istatistikler (DB) ── */
$statProducts = 0;
$statUsers    = 0;
$statSales    = 0;
if ($db) {
    try {
        $statProducts = (int)$db->query("SELECT COUNT(*) FROM products WHERE is_active = 1 AND is_hidden = 0 AND status='active'")->fetchColumn();
        $statUsers    = (int)$db->query('SELECT COUNT(*) FROM users')->fetchColumn();
        $statSales    = (int)$db->query('SELECT COUNT(*) FROM sales')->fetchColumn();
    } catch (\PDOException $e) { error_log('[NS] home stats: '.$e->getMessage()); }
}
function stat_fmt(int $n): string {
    if ($n >= 1000000) return number_format($n / 1000000, 1, ',', '.') . 'M+';
    if ($n >= 1000)    return number_format($n / 1000, 1, ',', '.') . 'B+';
    return (string)$n;
}

$news = [];
if ($db) {
    $stmt = $db->prepare('SELECT id, title, slug, content, image_url, created_at FROM announcements WHERE status="published" ORDER BY id DESC LIMIT 3');
    $stmt->execute();
    $news = $stmt->fetchAll();
}

$products = [];
if ($db) {
    $stmt = $db->prepare(
        "SELECT p.id, p.name, p.slug, p.short_description, p.description, p.price, p.image_url, p.discount_percent, p.version,
                p.stock_type, p.stock,
                COALESCE(c.name, p.category) AS category
         FROM products p
         LEFT JOIN categories c ON c.name = p.category
         WHERE p.is_active = 1 AND p.is_hidden = 0 AND p.status = 'active'
         ORDER BY p.created_at DESC
         LIMIT 6"
    );
    $stmt->execute();
    $products = $stmt->fetchAll();
}

$refMode = 'grid';
$references = [];
if ($db) {
    try {
        $refMode = $db->query("SELECT `value` FROM settings WHERE `key`='references_mode'")->fetchColumn() ?: 'grid';
        $refStmt = $db->query('SELECT * FROM `references` WHERE is_active=1 ORDER BY sort_order ASC, id DESC');
        $references = $refStmt->fetchAll();
    } catch (\PDOException $e) {}
}
$useSlider = ($refMode === 'slider' && is_array($references) && count($references) >= 3);

function ref_stars(int $r): string {
    $out = '';
    for ($i = 1; $i <= 5; $i++) $out .= $i <= $r
        ? '<svg viewBox="0 0 24 24" fill="currentColor"><path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg>'
        : '<svg class="far" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg>';
    return $out;
}

include __DIR__ . '/includes/header.php';
?>

<main>

<!-- ================= HERO ================= -->
<section class="hero">
  <div class="container hero-inner">

<?php
$azHeroTitle = theme_visible('hero_title', __('home.hero_title'));
$azHeroDesc = theme_visible('hero_desc', __('home.hero_desc'));
$azBtn1 = theme_visible('hero_btn1_text', __('home.btn1'));
$azBtn1Url = theme_visible('hero_btn1_url', '/products');
$azBtn2 = theme_visible('hero_btn2_text', __('home.btn_support'));
$azBtn2Url = theme_visible('hero_btn2_url', '/support');
$azStat4v = theme_visible('hero_stat4_value', '7/24');
$azStat4l = theme_visible('hero_stat4_label', __('home.stat4label'));
?>
    <div class="hero-copy">
      </span>
      <?php if ($azHeroTitle !== null && trim((string)$azHeroTitle) !== ''): ?>
      <h1 class="hero-title"><?= nx_clean_html($azHeroTitle, 'inline') ?></h1>
      <?php endif; ?>
      <?php if ($azHeroDesc !== null && trim((string)$azHeroDesc) !== ''): ?>
      <p class="hero-subtitle"><?= e($azHeroDesc) ?></p>
      <?php endif; ?>
      <?php if ($azBtn1 !== null || $azBtn2 !== null): ?>
      <div class="hero-actions">
        <?php if ($azBtn1 !== null && trim((string)$azBtn1) !== ''): ?>
        <a href="<?= e(nx_safe_href(($azBtn1Url !== null && trim((string)$azBtn1Url) !== '') ? $azBtn1Url : '/products', '/products')) ?>" class="btn btn-primary btn-lg">
          <?= e($azBtn1) ?>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        </a>
        <?php endif; ?>
        <?php if ($azBtn2 !== null && trim((string)$azBtn2) !== ''): ?>
        <a href="<?= e(nx_safe_href(($azBtn2Url !== null && trim((string)$azBtn2Url) !== '') ? $azBtn2Url : '/support', '/support')) ?>" class="btn btn-ghost btn-lg">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 12h8M12 4v4"/><path d="M4 13a8 8 0 0 1 16 0"/><rect x="2.5" y="13" width="5" height="6" rx="2"/><rect x="16.5" y="13" width="5" height="6" rx="2"/></svg>
          <?= e($azBtn2) ?>
        </a>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <div class="hero-stats">
        <div class="hero-stat"><span class="hero-stat-number stat-count" data-count="<?= $statProducts ?>"><?= stat_fmt($statProducts) ?></span><span class="hero-stat-label"><?= __('home.stat_products') ?></span></div>
        <div class="hero-stat"><span class="hero-stat-number stat-count" data-count="<?= $statUsers ?>"><?= stat_fmt($statUsers) ?></span><span class="hero-stat-label"><?= __('home.stat_members') ?></span></div>
        <div class="hero-stat"><span class="hero-stat-number stat-count" data-count="<?= $statSales ?>"><?= stat_fmt($statSales) ?></span><span class="hero-stat-label"><?= __('home.stat_sales') ?></span></div>
        <?php if ($azStat4v !== null && trim((string)$azStat4v) !== ''): ?>
        <div class="hero-stat"><span class="hero-stat-number"><?= e($azStat4v) ?></span><?php if ($azStat4l !== null && trim((string)$azStat4l) !== ''): ?><span class="hero-stat-label"><?= e($azStat4l) ?></span><?php endif; ?></div>
        <?php endif; ?>
      </div>
    </div>

    <?php $azHeroImg = trim((string)theme_setting('hero_image', '')); ?>
    <?php if ($azHeroImg !== ''): ?>
    <div class="hero-visual">
      <img src="<?= e($azHeroImg) ?>" alt="Hero" loading="lazy" style="width:100%;border-radius:20px;border:1px solid var(--line);">
    </div>
    <?php elseif (!empty($products)): $spot = $products[0]; $spp = (float)$spot['price']; $spd = (int)($spot['discount_percent'] ?? 0); $spn = $spd > 0 && $spp > 0 ? $spp * (1 - $spd / 100) : $spp; ?>
    <div class="hero-visual">
      <a href="/products?product=<?= (int)$spot['id'] ?>" class="hero-card az-spot-card">
        <?php if (!empty($spot['image_url'])): ?>
        <img src="<?= e($spot['image_url']) ?>" alt="" loading="lazy">
        <?php else: ?>
        <span class="az-spot-noimg"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><rect x="4" y="3" width="16" height="14" rx="3"/><path d="M9 7h6M12 7v10"/></svg></span>
        <?php endif; ?>
        <span class="az-spot-eyebrow"><?= __('home.spot_featured') ?></span>
        <b class="az-spot-name"><?= e($spot['name']) ?></b>
        <span class="az-spot-cat"><?= e($spot['category'] ?? __('shop.general')) ?></span>
        <span class="az-spot-price"><?php if ($spp > 0 && $spd > 0): ?><s><?= fmt_money($spp) ?></s> <?= fmt_money($spn) ?><?php elseif ($spp > 0): ?><?= fmt_money($spp) ?><?php else: ?><?= __('shop.free') ?><?php endif; ?></span>
        <span class="btn btn-primary btn-sm az-spot-btn"><?= __('home.spot_cta') ?></span>
      </a>
    </div>
    <?php endif; ?>
    <style>
    .az-spot-card{padding:0;overflow:hidden;display:flex;flex-direction:column;gap:0;text-decoration:none;}
    .az-spot-card img{width:100%;height:210px;object-fit:cover;display:block;}
    .az-spot-noimg{width:100%;height:180px;display:flex;align-items:center;justify-content:center;background:var(--bg-soft);color:var(--brand);}
    .az-spot-noimg svg{width:44px;height:44px;opacity:.7;}
    .az-spot-eyebrow{margin:18px 20px 0;font-size:10.5px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--brand-deep);}
    .az-spot-name{margin:6px 20px 0;font-family:var(--font-title);font-size:20px;font-weight:800;color:var(--text);line-height:1.3;}
    .az-spot-cat{margin:4px 20px 0;font-size:11px;font-weight:800;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;}
    .az-spot-price{margin:10px 20px 0;font-size:17px;font-weight:800;color:var(--brand);}
    .az-spot-price s{font-size:12.5px;color:var(--muted);font-weight:600;margin-right:6px;}
    .az-spot-btn{margin:14px 20px 20px;align-self:flex-start;}
    </style>

  </div>
</section>

<!-- ================= GÜVEN / ÖZELLİKLER ================= -->
<section class="section">
  <div class="container">
    <div class="section-head section-head--center reveal">
      <?php $featTitle = theme_visible('feat_title', __('home.feat_title')); if ($featTitle !== null && trim((string)$featTitle) !== ''): ?>
      <h2 class="section-title"><?= e($featTitle) ?></h2>
      <?php endif; ?>
      <?php $featDesc = theme_visible('feat_desc', __('home.feat_desc')); if ($featDesc !== null && trim((string)$featDesc) !== ''): ?>
      <p class="section-sub"><?= e($featDesc) ?></p>
      <?php endif; ?>
    </div>
    <?php
    $features = [
        ['i'=>'shield','tkey'=>'feat1_title','dkey'=>'feat1_desc','tdef'=>__('home.feat1t'),'ddef'=>__('home.feat1d')],
        ['i'=>'bolt','tkey'=>'feat2_title','dkey'=>'feat2_desc','tdef'=>__('home.feat2t'),'ddef'=>__('home.feat2d')],
        ['i'=>'headset','tkey'=>'feat3_title','dkey'=>'feat3_desc','tdef'=>__('home.feat3t'),'ddef'=>__('home.feat3d')],
        ['i'=>'refresh','tkey'=>'feat4_title','dkey'=>'feat4_desc','tdef'=>__('home.feat4t'),'ddef'=>__('home.feat4d')],
    ];
    ?>
    <div class="feature-grid">
      <?php foreach ($features as $f):
        $ft = theme_visible($f['tkey'], $f['tdef']);
        $fd = theme_visible($f['dkey'], $f['ddef']);
        if ($ft === null || trim((string)$ft) === '') continue;
      ?>
      <div class="feature-card reveal">
        <span class="feature-icon">
          <?php if ($f['i']==='shield'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 6v5c0 5 3.4 8 8 10 4.6-2 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/></svg>
          <?php elseif ($f['i']==='bolt'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m13 2-9 11h8l-1 9 9-11h-8l1-9z"/></svg>
          <?php elseif ($f['i']==='headset'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13a8 8 0 0 1 16 0"/><rect x="2.5" y="13" width="5" height="6" rx="2"/><rect x="16.5" y="13" width="5" height="6" rx="2"/><path d="M20 19a3 3 0 0 1-3 3h-4"/></svg>
          <?php else: ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-2.6-6.3"/><path d="M21 3v6h-6"/></svg>
          <?php endif; ?>
        </span>
        <h3 class="feature-title"><?= e($ft) ?></h3>
        <?php if ($fd !== null && trim((string)$fd) !== ''): ?><p class="feature-desc"><?= e($fd) ?></p><?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>


<?php if (feature_active('announcements')): ?>
<!-- ================= DUYURULAR ================= -->
<section class="section section--soft">
  <div class="container">
    <div class="section-head reveal" style="display:flex;align-items:flex-end;justify-content:space-between;gap:18px;flex-wrap:wrap;">
      <div>
        <?php $newsT = theme_visible('news_title', __('home.news_title')); if ($newsT !== null && trim((string)$newsT) !== ''): ?>
        <h2 class="section-title"><?= e($newsT) ?></h2>
        <?php endif; ?>
        <?php $newsD = theme_visible('news_desc', __('home.news_desc')); if ($newsD !== null && trim((string)$newsD) !== ''): ?>
        <p class="section-sub"><?= e($newsD) ?></p>
        <?php endif; ?>
      </div>
      <a href="/news" class="btn btn-soft btn-sm">
        <?= __('home.view_all') ?>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
      </a>
    </div>

    <div class="news-grid">
      <?php if (empty($news)): ?>
      <p class="news-empty"><?= __('home.empty_news') ?></p>
      <?php else: foreach ($news as $item): ?>
      <article class="news-card reveal">
        <div class="news-card-media">
          <?php if (!empty($item['image_url'])): ?>
          <img src="<?= e($item['image_url']) ?>" alt="">
          <?php else: ?>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M22 5H2v14h20z"/><path d="m2 7 7 5 5-3 8 5"/></svg>
          <?php endif; ?>
        </div>
        <div class="news-card-body">
          <div class="news-card-meta">
            <span class="news-pill">Duyuru</span>
            <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4m8-4v4M3 10h18"/></svg><?= tr_date('d M Y', strtotime($item['created_at'])) ?></span>
          </div>
          <h3 class="news-card-title"><?= e($item['title']) ?></h3>
          <p class="news-card-desc"><?= e(truncate_text($item['content'])) ?></p>
          <div class="news-card-foot">
            <a href="/news?slug=<?= urlencode($item['slug'] ?? '') ?>" class="btn btn-soft btn-sm"><?= __('home.read_more') ?></a>
          </div>
        </div>
      </article>
      <?php endforeach; endif; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ================= ÜRÜNLER ================= -->
<section class="section">
  <div class="container">
    <div class="section-head reveal" style="display:flex;align-items:flex-end;justify-content:space-between;gap:18px;flex-wrap:wrap;">
      <div>
        <span class="section-eyebrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M3 9.5 12 15l9-5.5M12 24V15"/></svg><?= __('home.store_badge') ?></span>
        <?php $shopT = theme_visible('shop_title', __('home.shop_title')); if ($shopT !== null && trim((string)$shopT) !== ''): ?>
        <h2 class="section-title"><?= e($shopT) ?></h2>
        <?php endif; ?>
        <?php $shopD = theme_visible('shop_desc', __('home.shop_desc_top')); if ($shopD !== null && trim((string)$shopD) !== ''): ?>
        <p class="section-sub"><?= e($shopD) ?></p>
        <?php endif; ?>
      </div>
      <a href="/products" class="btn btn-soft btn-sm">
        <?= __('home.all_products') ?>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
      </a>
    </div>

    <div class="products-grid">
      <?php if (empty($products)): ?>
      <p class="products-empty"><?= __('home.empty_products') ?></p>
      <?php else: foreach ($products as $product):
          $soldOut = (($product['stock_type'] ?? 'unlimited') === 'limited') && ((int)($product['stock'] ?? 0)) < 1;
          $pp = (float)$product['price'];
          $pd = (int)($product['discount_percent'] ?? 0);
          $pn = $pd > 0 && $pp > 0 ? $pp * (1 - $pd / 100) : $pp;
      ?>
      <?php if (function_exists('do_action')) do_action('product_card_before', $product); ?>
      <a href="<?= $soldOut ? 'javascript:void(0)' : '/products?product='.(int)$product['id'] ?>" class="product-card <?= $soldOut ? 'is-soldout' : '' ?> reveal">

                <div class="product-media">
                    <?php if (!empty($product['image_url'])): ?>
                     <img src="<?= e($product['image_url']) ?>" width="360" height="225" alt="<?= e($product['name'] ?? '') ?>" style="width:100%;height:100%;object-fit:cover;">
                    <?php else: ?>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><rect x="4" y="3" width="16" height="14" rx="3"/><path d="M9 7h6M12 7v10"/></svg>
                    <?php endif; ?>
                    <?php if ($soldOut): ?>
                    <span class="product-badge product-badge--soldout"><?= __('product.soldout') ?></span>
                    <?php elseif ($pd > 0): ?>
                    <span class="product-badge" style="background:#ff4757;color:#fff;font-weight:800;"><?= __('product.discount_pct', ['n' => $pd]) ?></span>
                    <?php endif; ?>
                </div>

                <div class="product-body">
                    <p class="product-cat">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"/><path d="M3 8h18M8 3v5"/></svg>
                        <?= e($product['category'] ?? '') ?>
                    </p>
                    <h3 class="product-title"><?= e($product['name']) ?></h3>
                    <p class="product-desc"><?= htmlspecialchars(truncate_text($product['short_description'] ?? $product['description'] ?? '', 120)) ?></p>

                    <div class="product-foot">
                        <div class="product-price">
                            <?php $pp=(float)$product['price']; $pd=(int)($product['discount_percent']??0); $pn=$pd>0&&$pp>0?$pp*(1-$pd/100):$pp; if($pp>0): if($pd>0): ?>
                            <div style="display:flex;flex-direction:column;gap:2px"><div style="display:flex;align-items:center;gap:6px"><span style="font-size:11px;color:var(--muted);text-decoration:line-through"><?= fmt_money($pp) ?></span><span style="background:#ff4757;color:#fff;font-size:10px;font-weight:800;padding:2px 6px;border-radius:50px">%<?= $pd ?></span></div><span class="product-price-current"><?= fmt_money($pn) ?></span></div>
                            <?php else: ?><span class="product-price-current"><?= fmt_money($pp) ?></span><span class="product-price-label"><?= __('product.onetime') ?></span><?php endif; else: ?><span class="product-price-current product-price-free"><i class="fa-solid fa-gift"></i><?= __('shop.free') ?></span><?php endif; ?>
                        </div>
                        <?php if ($soldOut): ?>
                        <span class="btn btn-ghost btn-sm" style="pointer-events:auto;opacity:.5;">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m5.6 5.6 12.8 12.8"/></svg>
                            <?= __('product.soldout') ?>
                        </span>
                        <?php else: ?>
                        <span class="btn btn-primary btn-sm" onclick="event.stopPropagation();window.location='/products?product=<?= (int)$product['id'] ?>'" style="pointer-events:auto;">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2l2.5 12.5A2 2 0 0 0 9.5 18h8a2 2 0 0 0 2-1.6L21.5 8H6"/></svg>
                            <?= __('cart.buy') ?>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

            </a>
      <?php if (function_exists('do_action')) do_action('product_card_after', $product); ?>
      <?php endforeach; endif; ?>
    </div>
  </div>
</section>

<?php if (feature_active('references')): ?>
<!-- ================= REFERANSLAR ================= -->
<section class="section section--refs">
  <div class="container">
    <div class="section-head section-head--center reveal">
      <span class="section-eyebrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 17c-2.5 0-4-2-4-4.5S3.5 8 6 8c.5 0 1 0 1.5.2C6.5 10 6.5 12 8 13.5c.6.6 1.3 1 2.2 1.2 0 0-.3 2.3-3.7 2.3zM18 17c-2.5 0-4-2-4-4.5S15.5 8 18 8c.5 0 1 0 1.5.2C18.5 7 18.5 9 20 10.5c.6.6 1.3 1 2.2 1.2 0 0-.3 2.3-3.7 2.3z"/></svg><?= __('home.refs_tag') ?></span>
      <?php $refsT = theme_visible('refs_title', __('home.refs_title')); if ($refsT !== null && trim((string)$refsT) !== ''): ?>
      <h2 class="section-title"><?= e($refsT) ?></h2>
      <?php endif; ?>
      <?php $refsD = theme_visible('refs_desc', __('home.refs_desc')); if ($refsD !== null && trim((string)$refsD) !== ''): ?>
      <p class="section-sub"><?= e($refsD) ?></p>
      <?php endif; ?>
    </div>

    <?php if (empty($references)): ?>
    <p style="text-align:center;color:var(--muted);padding:32px 0;"><?= __('home.empty_refs') ?></p>

    <?php elseif ($useSlider): ?>
    <style>
    .az-ref-slider-wrap{position:relative;overflow:hidden;margin-top:8px;}
    .az-ref-slider-viewport{overflow:hidden;border-radius:22px;}
    .az-ref-slider-track{display:flex;gap:16px;width:max-content;will-change:transform;}
    .az-ref-slider-card{flex:0 0 auto;box-sizing:border-box;width:360px;}
    @media(max-width:480px){.az-ref-slider-card{width:300px;}}
    .az-ref-slider-card .ref-card{height:100%;}
    </style>
    <div class="az-ref-slider-wrap">
      <div class="az-ref-slider-viewport" id="azRefViewport">
        <div class="az-ref-slider-track" id="azRefTrack">
          <?php foreach ($references as $ref): ?>
          <div class="az-ref-slider-card">
            <div class="ref-card">
              <svg class="ref-quote" viewBox="0 0 24 24" fill="currentColor"><path d="M6 17c-2.5 0-4-2-4-4.5S3.5 8 6 8c.5 0 1 0 1.5.2C6.5 7 6.5 5 10 4.2 8.5 6.2 8.5 9 7 10.5c.6.6 1.3 1 2.2 1.2 0 0-.3 5.3-3.2 6.3zM21 17c-2.5 0-4-2-4-4.5S18.5 7 21 7c.5 0 1 0 1.5.2C21.5 9 21.5 7 20 8.5c.6.6 1.3 1 2.2 1.2 0 0-.3 5.3-3.2 6.3z" transform="translate(0 -1) scale(1)"/></svg>
              <p class="ref-msg">“<?= nl2br(e($ref['message'] ?? 'Yorum bulunmuyor.')) ?>”</p>
              <div class="ref-person">
                <?php if (!empty($ref['photo_url'])): ?>
                <img src="<?= e($ref['photo_url']) ?>" class="ref-avatar" alt="<?= e($ref['name'] ?? $ref['username'] ?? '') ?>">
                <?php else: ?>
                <span class="ref-avatar"><?= htmlspecialchars(mb_strtoupper(mb_substr($ref['name'],0,1))) ?></span>
                <?php endif; ?>
                <div style="flex:1;">
                  <div class="ref-name"><?= e($ref['name']) ?></div>
                  <?php if (!empty($ref['title'])): ?><div class="ref-title"><?= e($ref['title']) ?></div><?php endif; ?>
                </div>
                <div class="ref-stars"><?= ref_stars((int)$ref['rating']) ?></div>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <script>
    (function(){
      var vp=document.getElementById('azRefViewport');
      var track=document.getElementById('azRefTrack');
      if(!vp||!track) return;
      var cards=Array.prototype.slice.call(track.querySelectorAll('.az-ref-slider-card'));
      var n=cards.length; if(n===0) return;
      cards.forEach(function(c){ track.appendChild(c.cloneNode(true)); });
      var step=0, setW=0, offset=0, speed=32, running=true, last=0;
      function layout(){
        var w=track.children[0]?track.children[0].getBoundingClientRect().width:360;
        step=w+16;
        setW=step*n;
      }
      layout(); window.addEventListener('resize', layout);
      vp.addEventListener('mouseenter',function(){running=false;});
      vp.addEventListener('mouseleave',function(){running=true; last=performance.now();});
      vp.addEventListener('touchstart',function(){running=false;},{passive:true});
      vp.addEventListener('touchend',function(){running=true; last=performance.now();});
      function tick(now){
        if(!last) last=now;
        var dt=now-last; last=now;
        if(running){
          offset-=(speed*dt/1000);
          if(offset <= -setW) offset+=setW;
          if(offset > 0) offset-=setW;
          track.style.transform='translateX('+offset+'px)';
        }
        requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    })();
    </script>

    <?php else: ?>
    <div class="refs-grid">
      <?php foreach ($references as $ref): ?>
      <div class="ref-card reveal">
        <svg class="ref-quote" viewBox="0 0 24 24" fill="currentColor"><path d="M9.6 4C5.9 5.4 3.8 8 3.5 11.4c-.2 2.2.6 4.6 2.8 5-.2-1.4-.3-2.7.4-3.7.9-1.2 3-1.6 4.4-.8 1.5.8 1.7 2.9.6 4.4-1.4 1.8-4.5 2-6.3.3.8.2 1.6.2 2.4.2C14.2 19.6 18.5 16 18.5 11c0-2.7-.8-4.9-3-6l0 0H9.6zM22 4c0 1-1 2-2 2s-2-1-2-2 1-2 2-2 2 1 2 2z"/></svg>
        <p class="ref-msg">“<?= nl2br(e($ref['message'] ?? 'Yorum bulunmuyor.')) ?>”</p>
        <div class="ref-person">
          <?php if (!empty($ref['photo_url'])): ?>
          <img src="<?= e($ref['photo_url']) ?>" class="ref-avatar" alt="<?= e($ref['name'] ?? $ref['username'] ?? '') ?>">
          <?php else: ?>
          <span class="ref-avatar"><?= htmlspecialchars(mb_strtoupper(mb_substr($ref['name'],0,1))) ?></span>
          <?php endif; ?>
          <div style="flex:1;">
            <div class="ref-name"><?= e($ref['name']) ?></div>
            <?php if (!empty($ref['title'])): ?><div class="ref-title"><?= e($ref['title']) ?></div><?php endif; ?>
          </div>
          <div class="ref-stars"><?= ref_stars((int)$ref['rating']) ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>
<?php endif; ?>

<?php $faqs = function_exists('faqs_fetch') ? faqs_fetch($db ?? null) : []; if (!empty($faqs)): ?>
<section class="section section--faq" id="sss">
  <div class="container">
    <div class="section-head" style="text-align:center;margin-bottom:2rem">
      <span class="section-eyebrow"><i class="fa-solid fa-circle-question"></i> SSS</span>
      <?php $faqT = theme_visible('faq_title', __('home.faq_title')); if ($faqT !== null && trim((string)$faqT) !== ''): ?>
      <h2 class="section-title"><?= e($faqT) ?></h2>
      <?php endif; ?>
    </div>
    <div class="faq-grid" style="max-width:760px;margin:0 auto;display:flex;flex-direction:column;gap:10px">
      <?php foreach ($faqs as $f): ?>
      <div class="faq-item">
        <button type="button" class="faq-q"><span><?= e($f['question']) ?></span><i class="fa-solid fa-chevron-down faq-chevron"></i></button>
        <div class="faq-a"><div class="faq-a-inner"><?= nx_clean_html((string)($f['answer'] ?? ''), 'rich') ?></div></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<style>
.faq-item{border:1px solid var(--line);border-radius:14px;overflow:hidden;background:var(--surface);transition:border-color .2s;}
.faq-item.open{border-color:var(--brand);}
.faq-q{width:100%;display:flex;justify-content:space-between;align-items:center;padding:14px 18px;font-weight:700;background:none;border:none;color:var(--text);cursor:pointer;font-family:inherit;font-size:inherit;text-align:left;gap:12px;}
.faq-q:focus{outline:none;}
.faq-q .faq-chevron{transition:transform .3s;flex-shrink:0;}
.faq-item.open .faq-chevron{transform:rotate(180deg);}
.faq-a-inner{padding:0 18px 14px;color:var(--muted);font-size:.92rem;line-height:1.7;}
</style>
<script>
(function(){
  var items = document.querySelectorAll('.faq-item');
  items.forEach(function(item){
    var btn = item.querySelector('.faq-q');
    var body = item.querySelector('.faq-a');
    if(!btn || !body) return;
    body.style.overflow = 'hidden';
    body.style.height = '0px';
    body.style.transition = 'height .35s ease';
    btn.addEventListener('click', function(){
      var isOpen = item.classList.contains('open');
      items.forEach(function(el){
        el.classList.remove('open');
        var b = el.querySelector('.faq-a');
        if(b) b.style.height = '0px';
      });
      if(!isOpen){
        item.classList.add('open');
        body.style.height = 'auto';
        var h = body.scrollHeight;
        body.style.height = '0px';
        requestAnimationFrame(function(){
          requestAnimationFrame(function(){
            body.style.height = h + 'px';
          });
        });
      }
    });
  });
})();
</script>
<?php endif; ?>
<!-- ================= CTA ================= -->
<section class="section" style="padding-top:0;">
  <div class="container">
    <div class="cta-band reveal">
      <div>
        <?php $ctaT = theme_visible('cta_title', __('home.cta_title')); $ctaD = theme_visible('cta_desc', __('home.cta_desc')); $ctaB = theme_visible('cta_btn', __('home.cta_btn')); ?>
        <?php if ($ctaT !== null && trim((string)$ctaT) !== ''): ?>
        <h2 class="cta-band-title"><?= e($ctaT) ?></h2>
        <?php endif; ?>
        <?php if ($ctaD !== null && trim((string)$ctaD) !== ''): ?>
        <p class="cta-band-sub"><?= e($ctaD) ?></p>
        <?php endif; ?>
      </div>
      <?php if ($ctaB !== null && trim((string)$ctaB) !== ''): ?>
      <a href="/register" class="btn btn-white btn-lg">
        <?= e($ctaB) ?>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
      </a>
      <?php endif; ?>
    </div>
  </div>
</section>

</main>

<?php include __DIR__ . '/includes/footer.php'; ?>

