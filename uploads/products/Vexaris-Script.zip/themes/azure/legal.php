<?php
$p = trim($_GET['p'] ?? '');
$allowed = ['cookie-policy','privacy-policy','terms-of-service','refund-policy'];
$titles = [
    'cookie-policy'    => [__('legal.cookies'),    'cookie'],
    'privacy-policy'   => [__('legal.privacy'), 'shield'],
    'terms-of-service' => [__('legal.terms'),   'doc'],
    'refund-policy'    => [__('legal.refund'),      'refresh'],
];
$legalIcons = [
    'cookie' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2a10 10 0 1 0 10 10c0-1.5-1-2-2-2a2 2 0 0 1-2-2c0-1.5-1-2-2-2a2 2 0 0 1-2-2z"/></svg>',
    'shield' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 6v5c0 5 3.4 8 8 10 4.6-2 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/></svg>',
    'doc'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3h6l3 3v15H6V6z"/><path d="M9 9h6m-6 4h6m-6 4h4"/></svg>',
    'refresh'=> '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 3v5h5"/></svg>',
];

$legalContent = null;
$db = nexus_db();
if ($p && in_array($p, $allowed, true) && $db) {
    $st = $db->prepare('SELECT * FROM legal_pages WHERE slug=?');
    $st->execute([$p]);
    $legalContent = $st->fetch();
    if (!$legalContent) {
        $legalContent = ['title' => ($titles[$p][0] ?? $p), 'content' => '', 'updated_at' => ''];
    }
    $pageTitle = $legalContent['title'];
}

$seoKey    = ($p && in_array($p, $allowed, true)) ? 'legal_' . $p : '';
$pageTitle = $pageTitle ?? __('legal.index_title');
$activePage = '';

include __DIR__ . '/includes/header.php';
$siteName = $_headerSiteName ?? ($_headerSite ?? 'Vexaris');
?>
<main>
  <section class="section">
    <div class="container" style="max-width:880px;">
      <div class="section-head">
        <span class="section-eyebrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3 4 6v5c0 5 3.4 8 8 10 4.6-2 8-5 8-10V6z"/></svg>Yasal</span>
        <h1 class="section-title"><?= __('legal.index_title') ?></h1>
        <p class="section-sub"><?= __('legal.sub') ?></p>
      </div>

      <?php if ($legalContent && $p && in_array($p, $allowed, true)): ?>
      <?php
      $iconKey = $titles[$p][1] ?? 'doc';
      $displayTitle = $legalContent['title'] ?: ($titles[$p][0] ?? $p);
      $body = function_exists('legal_body_html') ? legal_body_html((string)($legalContent['content'] ?? ''), $siteName) : e((string)($legalContent['content'] ?? ''));
      ?>
      <style>
      .md-body{color:var(--text-2);font-size:15px;line-height:1.85;}
      .md-body h2{font-family:var(--font-title);font-size:21px;font-weight:800;margin:28px 0 12px;color:var(--text);}
      .md-body h2:first-child{margin-top:0;}
      .md-body h3{font-family:var(--font-title);font-size:17px;font-weight:800;margin:22px 0 10px;color:var(--text);}
      .md-body h4{font-size:15px;font-weight:800;margin:16px 0 8px;color:var(--text);}
      .md-body p{margin:0 0 14px;}
      .md-body ul,.md-body ol{margin:0 0 16px;padding-left:22px;display:grid;gap:8px;}
      .md-body li::marker{color:var(--brand);font-weight:800;}
      .md-body strong{color:var(--text);}
      .md-body a{color:var(--brand);font-weight:600;}
      .md-body blockquote{border-left:3px solid var(--brand);padding:6px 14px;background:var(--brand-soft);border-radius:0 10px 10px 0;margin:0 0 14px;}
      </style>
      <div style="margin-bottom:22px;">
        <a href="/legal" class="btn btn-ghost btn-sm">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 18l-6-6 6-6"/></svg>
          <?= __('legal.all_pages') ?>
        </a>
      </div>

      <div class="panel-card">
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:22px;padding-bottom:18px;border-bottom:1px solid var(--line);flex-wrap:wrap;">
          <span style="width:44px;height:44px;border-radius:13px;background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center;flex-shrink:0;"><?= $legalIcons[$iconKey] ?></span>
          <div style="flex:1;min-width:200px;">
            <h2 style="font-family:var(--font-title);font-size:18px;font-weight:800;"><?= e($displayTitle) ?></h2>
            <?php if ($legalContent['updated_at']): ?>
            <p style="font-size:11.5px;color:var(--muted);"><?= __('legal.updated') ?> <?= e($legalContent['updated_at']) ?></p>
            <?php endif; ?>
          </div>
        </div>
        <div class="md-body"><?= $body ?></div>
      </div>

      <?php else: ?>

      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px;">
        <?php foreach ($allowed as $slug): $info = $titles[$slug]; ?>
        <a href="/legal?p=<?= urlencode($slug) ?>" class="panel-card" style="padding:24px;display:block;transition:transform .2s ease,border-color .2s ease,box-shadow .2s ease;">
          <span style="width:44px;height:44px;border-radius:13px;background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center;margin-bottom:14px;"><?= $legalIcons[$info[1]] ?></span>
          <h3 style="font-family:var(--font-title);font-size:14.5px;font-weight:800;margin-bottom:4px;"><?= e($info[0]) ?></h3>
          <p style="font-size:11.5px;color:var(--muted);"><?= __('legal.click_detail') ?></p>
        </a>
        <?php endforeach; ?>
      </div>

      <?php endif; ?>
    </div>
  </section>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>