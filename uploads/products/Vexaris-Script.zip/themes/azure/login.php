<?php
auth_redirect_if_logged_in('/');

$pageTitle  = __('nav.login');
$activePage = 'login';
$seoKey     = 'login';
$error      = '';

if (isset($_GET['flash'])) {
    $flashParts = explode(':', urldecode($_GET['flash']), 2);
    if (($flashParts[0] ?? '') === 'error') $error = $flashParts[1] ?? '';
}

csrf_verify();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_captcha()) {
        $error = __('auth.captcha_fail');
    } else {
        $remember = !empty($_POST['remember']);
        $result = auth_login(
            $_POST['identifier'] ?? '',
            $_POST['password']   ?? '',
            $remember
        );
        if ($result['ok']) {
            header('Location: /', true, 302);
            exit;
        }
        $error = $result['msg'];
    }
}

$intSettings = [];
try {
    $intDb = nexus_db();
    $intSt = $intDb->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'");
    while ($intR = $intSt->fetch()) $intSettings[$intR['key']] = $intR['value'];
} catch (\PDOException $e) { error_log('[NS] login int: '.$e->getMessage()); }

$googleAuth   = ($intSettings['int_google_auth_enabled'] ?? '0')   === '1' && !empty($intSettings['int_google_auth_client_id']);
$discordAuth  = ($intSettings['int_discord_auth_enabled'] ?? '0')  === '1' && !empty($intSettings['int_discord_auth_client_id']);
$microsoftAuth= ($intSettings['int_microsoft_auth_enabled'] ?? '0')=== '1' && !empty($intSettings['int_microsoft_auth_client_id']);
$githubAuth   = ($intSettings['int_github_auth_enabled'] ?? '0')   === '1' && !empty($intSettings['int_github_auth_client_id']);
$cfCaptcha    = ($intSettings['int_cf_captcha_enabled'] ?? '0')    === '1' && !empty($intSettings['int_cf_captcha_site_key']);
$recaptcha    = ($intSettings['int_recaptcha_enabled'] ?? '0')     === '1' && !empty($intSettings['int_recaptcha_site_key']);

include __DIR__ . '/includes/header.php';
?>
<style>
.remember-container input{position:absolute;opacity:0;cursor:pointer;height:0;width:0}
.remember-container{display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none}
.remember-container .checkmark{--clr:#0B6E4F;position:relative;height:1.3em;width:1.3em;background-color:#ccc;border-radius:50%;transition:300ms;flex-shrink:0}
.remember-container input:checked ~ .checkmark{background-color:var(--clr);border-radius:.5rem;animation:rememberPulse 500ms ease-in-out}
.checkmark:after{content:"";position:absolute;display:none}
.remember-container input:checked ~ .checkmark:after{display:block}
.remember-container .checkmark:after{left:0.45em;top:0.25em;width:0.25em;height:0.5em;border:solid #E0E0E2;border-width:0 0.15em 0.15em 0;transform:rotate(45deg)}
@keyframes rememberPulse{0%{box-shadow:0 0 0 #0B6E4F90;rotate:20deg}50%{rotate:-20deg}75%{box-shadow:0 0 0 10px #0B6E4F60}100%{box-shadow:0 0 0 13px #0B6E4F30;rotate:0}}
</style>
<main class="auth-shell">
  <div class="auth-card">

    <div class="auth-card-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="m10 17 5-5-5-5M15 12H3"/></svg>
    </div>

    <h1 class="auth-card-title"><?= __('auth.welcome_back') ?></h1>
    <p class="auth-card-subtitle"><?= __('auth.login_sub') ?></p>

    <?php if ($error): ?>
    <div class="auth-alert auth-alert--error">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v6m0 4h.01"/></svg>
      <?= e($error) ?>
    </div>
    <?php endif; ?>

    <form method="POST" action="/login" autocomplete="on" novalidate>
    <?= csrf_field() ?>

      <div class="form-group">
        <label for="identifier" class="form-label"><?= __('auth.identifier') ?></label>
        <div class="form-input-icon-wrap">
          <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          <input type="text" id="identifier" name="identifier" class="form-input"
              placeholder="kullanici@ornek.com" autocomplete="username" required maxlength="255"
              value="<?= e($_POST['identifier'] ?? '') ?>">
        </div>
      </div>

      <div class="form-group">
        <div class="form-label-row">
          <label for="password" class="form-label"><?= __('auth.password') ?></label>
          <a href="/forgot-password" class="auth-links" style="margin:0;font-size:12px;"><?= __('auth.forgot') ?></a>
        </div>
        <div class="form-input-icon-wrap">
          <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
          <input type="password" id="password" name="password" class="form-input"
              placeholder="••••••••" autocomplete="current-password" required maxlength="128">
        </div>
      </div>

      <?php if ($cfCaptcha): ?>
      <div class="form-group">
        <div class="cf-turnstile" data-sitekey="<?= e($intSettings['int_cf_captcha_site_key']) ?>" data-theme="light" style="margin-top:4px;"></div>
        <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
      </div>
      <?php elseif ($recaptcha): ?>
      <div class="form-group">
        <div class="g-recaptcha" data-sitekey="<?= e($intSettings['int_recaptcha_site_key']) ?>" data-theme="light" style="margin-top:4px;"></div>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
      </div>
      <?php endif; ?>

      <label class="remember-container" style="display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none;margin-top:10px">
        <input type="checkbox" name="remember" value="1" checked>
        <div class="checkmark"></div>
        <span style="font-size:14px;color:var(--text);"><?= __('auth.remember') ?></span>
      </label>

      <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top:22px;">
        <?= __('nav.login') ?>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
      </button>

    </form>

    <?php if ($googleAuth || $discordAuth || $microsoftAuth || $githubAuth): ?>
    <div class="auth-social">
      <div class="auth-social-label">veya</div>
      <div class="auth-social-btns">
        <?php if ($googleAuth): ?>
        <a href="/api/auth/google_auth" class="btn btn-ghost auth-social-btn">
          <i class="fa-brands fa-google" style="font-size:18px"></i>
          <?= __('auth.oauth_login', ['brand' => 'Google']) ?>
        </a>
        <?php endif; ?>
        <?php if ($discordAuth): ?>
        <a href="/api/auth/discord_auth" class="btn btn-ghost auth-social-btn">
          <i class="fa-brands fa-discord" style="font-size:18px"></i>
          <?= __('auth.oauth_login', ['brand' => 'Discord']) ?>
        </a>
        <?php endif; ?>
        <?php if ($microsoftAuth): ?>
        <a href="/api/auth/microsoft_auth" class="btn btn-ghost auth-social-btn">
          <i class="fa-brands fa-microsoft" style="font-size:18px"></i>
          <?= __('auth.oauth_login', ['brand' => 'Microsoft']) ?>
        </a>
        <?php endif; ?>
        <?php if ($githubAuth): ?>
        <a href="/api/auth/github_auth" class="btn btn-ghost auth-social-btn">
          <i class="fa-brands fa-github" style="font-size:18px"></i>
          <?= __('auth.oauth_login', ['brand' => 'GitHub']) ?>
        </a>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>

    <p class="auth-links">
      <?= __('auth.no_account') ?> <a href="/register"><?= __('nav.register') ?></a>
    </p>

  </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>