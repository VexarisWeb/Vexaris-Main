<?php
$mSiteName = 'Vexaris';
$mFavicon  = null;
$mDb = nexus_db();
if ($mDb) {
    try {
        $mStmt = $mDb->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('site_name','site_favicon')");
        $mStmt->execute();
        foreach ($mStmt->fetchAll() as $mRow) {
            if ($mRow['key'] === 'site_name')    $mSiteName = $mRow['value'];
            if ($mRow['key'] === 'site_favicon') $mFavicon  = $mRow['value'];
        }
    } catch (\Exception $e) {}
}
http_response_code(503);
?><!DOCTYPE html>
<html lang="<?= lang_active() ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex,nofollow">
<?php if ($mFavicon): ?><link rel="icon" href="<?= e($mFavicon) ?>"><?php endif; ?>
<title><?= __('maint.title') ?> — <?= e($mSiteName) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Outfit:wght@600;700;800;900&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{
  font-family:'Inter',system-ui,sans-serif;background:linear-gradient(180deg,#f0f6ff 0%,#e6f0fd 100%);
  color:#0e2a4a;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:40px 24px;text-align:center;
}
.m-wrap{display:flex;flex-direction:column;align-items:center;gap:18px;max-width:440px;}
.m-gear{width:68px;height:68px;color:#2b6eff;animation:m-spin 3s linear infinite;}
@keyframes m-spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
.m-site{
  font-family:'Outfit',sans-serif;font-size:20px;font-weight:900;letter-spacing:.08em;text-transform:uppercase;
  background:linear-gradient(135deg,#2b6eff,#17a8f5);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;
}
.m-title{font-family:'Outfit',sans-serif;font-size:30px;font-weight:800;letter-spacing:-.5px;}
.m-desc{font-size:14px;color:#6b7f99;font-weight:500;line-height:1.7;}
.m-btn{
  display:inline-flex;align-items:center;gap:8px;margin-top:14px;padding:13px 38px;font-family:'Inter',sans-serif;
  font-size:15px;font-weight:800;border-radius:14px;border:none;
  background:linear-gradient(135deg,#2b6eff 0%,#17a8f5 100%);color:#fff;text-decoration:none;cursor:pointer;
  box-shadow:0 12px 26px rgba(43,110,255,.35);transition:transform .18s ease,box-shadow .18s ease;
}
.m-btn:hover{transform:translateY(-2px);box-shadow:0 16px 32px rgba(43,110,255,.42);}
</style>
</head>
<body>
<div class="m-wrap">
    <svg class="m-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.5"/><path d="M12 2v3m0 14v3M4.9 4.9l2.1 2.1m10 10 2.1 2.1M2 12h3m14 0h3M4.9 19.1l2.1-2.1m10-10 2.1-2.1"/></svg>
    <span class="m-site"><?= e($mSiteName) ?></span>
    <h1 class="m-title"><?= __('maint.heading') ?></h1>
    <p class="m-desc"><?= __('maint.desc2') ?></p>
    <a href="/login" class="m-btn">
      <svg style="width:16px;height:16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="m10 17 5-5-5-5M15 12H3"/></svg>
      <?= __('auth.do_login') ?>
    </a>
</div>
<?php
if (function_exists('tawkto_widget_code')) { $twkWidget = tawkto_widget_code(); if ($twkWidget) echo $twkWidget; }
if (function_exists('jivochat_widget_code')) { $jvWidget = jivochat_widget_code(); if ($jvWidget) echo $jvWidget; }
if (function_exists('crisp_widget_code')) { $crWidget = crisp_widget_code(); if ($crWidget) echo $crWidget; }
?>
</body>
</html>