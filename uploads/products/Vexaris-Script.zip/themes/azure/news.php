<?php
$pageTitle  = 'Duyurular';
$activePage = 'news';

if (!feature_active('announcements')) {
    http_response_code(404);
    theme_load('404');
    exit;
}

$db = nexus_db();

$slug   = trim($_GET['slug'] ?? '');
$single = null;

if ($slug && $db) {
    $st = $db->prepare('SELECT * FROM announcements WHERE slug = ? AND status="published" LIMIT 1');
    $st->execute([$slug]);
    $single = $st->fetch() ?: null;
    if ($single) $pageTitle = e($single['title']) . ' — Duyurular';
}

$seoKey = $single ? '' : 'news';

$news = [];
if (!$single && $db) {
    $st = $db->prepare('SELECT id, title, slug, content, image_url, created_at FROM announcements WHERE status="published" ORDER BY id DESC');
    $st->execute();
    $news = $st->fetchAll();
}

include __DIR__ . '/includes/header.php';
?>
<main>
  <section class="section">
    <div class="container">

      <?php if ($single): ?>

      <div style="max-width:800px;margin:0 auto;">
        <div style="margin-bottom:24px;">
          <a href="/news" class="btn btn-ghost btn-sm">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 18l-6-6 6-6"/></svg>
            <?= __('news.all') ?>
          </a>
        </div>

        <article class="panel-card reveal" style="padding:0;overflow:hidden;">
          <?php if (!empty($single['image_url'])): ?>
          <div style="width:100%;aspect-ratio:16/9;overflow:hidden;">
            <img src="<?= e($single['image_url']) ?>" alt="<?= e($single['title']) ?>" style="width:100%;height:100%;object-fit:cover;">
          </div>
          <?php endif; ?>
          <div style="padding:30px 34px;">

            <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap;">
              <span class="badge badge-answered">Duyuru</span>
              <span style="font-size:12px;color:var(--muted);display:flex;align-items:center;gap:5px;">
                <svg style="width:13px;height:13px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4m8-4v4M3 10h18"/></svg>
                <?= tr_date('d M Y', strtotime($single['created_at'])) ?>
              </span>
            </div>

            <h1 style="font-family:var(--font-title);font-size:clamp(22px,4vw,32px);font-weight:800;line-height:1.25;letter-spacing:-.4px;margin-bottom:20px;">
              <?= e($single['title']) ?>
            </h1>

            <div style="font-size:15px;line-height:1.85;color:var(--text-2);" class="ann-body">
              <?= $single['content'] ?>
            </div>

          </div>
        </article>
      </div>

      <?php else: ?>

      <div class="section-head reveal">
        <span class="section-eyebrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v12H7a3 3 0 0 0-3 3z"/><path d="M8 8h8M8 11h5"/></svg>Duyurular</span>
        <h1 class="section-title"><?= __('news.page_title') ?></h1>
        <p class="section-sub"><?= __('news.sub') ?></p>
      </div>

      <?php if (empty($news)): ?>
      <div class="news-empty" style="background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-lg);padding:60px 20px;text-align:center;color:var(--muted);">
        <svg style="width:44px;height:44px;color:var(--dim);margin:0 auto 14px;display:block;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4h16v12H7a3 3 0 0 0-3 3z"/><path d="M8 8h8M8 11h5"/></svg>
        <p style="font-size:15px;font-weight:700;"><?= __('news.empty') ?></p>
      </div>
      <?php else: ?>
      <div class="news-grid">
        <?php foreach ($news as $item): ?>
        <article class="news-card reveal">
          <div class="news-card-media">
            <?php if (!empty($item['image_url'])): ?>
            <img src="<?= e($item['image_url']) ?>" alt="">
            <?php else: ?>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M22 5H2v14h20z"/><path d="m2 7 7 5 5-3 8 5"/></svg>
            <?php endif; ?>
          </div>
          <div class="news-card-body">
            <div class="news-card-meta">
              <span class="badge badge-answered">Duyuru</span>
              <span><svg style="width:12px;height:12px;vertical-align:-1px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4m8-4v4M3 10h18"/></svg> <?= tr_date('d M Y', strtotime($item['created_at'])) ?></span>
            </div>
            <h3 class="news-card-title"><?= e($item['title']) ?></h3>
            <p class="news-card-desc"><?= e(truncate_text($item['content'])) ?></p>
            <div class="news-card-foot">
              <a href="/news?slug=<?= urlencode($item['slug'] ?? '') ?>" class="btn btn-soft btn-sm">
                <?= __('home.read_more') ?>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
              </a>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <?php endif; ?>

    </div>
  </section>
</main>

<style>
.ann-body h1,.ann-body h2,.ann-body h3{color:var(--text);margin-bottom:10px;margin-top:22px;font-family:var(--font-title);}
.ann-body strong{color:var(--text);}
.ann-body code{background:var(--bg-soft);padding:2px 7px;border-radius:5px;font-size:13px;color:var(--brand-deep);}
.ann-body pre{background:var(--bg-soft);border:1px solid var(--line);border-radius:10px;padding:16px;overflow-x:auto;margin:14px 0;}
.ann-body ul{padding-left:20px;margin:10px 0;}
.ann-body li{margin-bottom:4px;}
.ann-body a{color:var(--brand);text-decoration:underline;}
</style>

<?php include __DIR__ . '/includes/footer.php'; ?>