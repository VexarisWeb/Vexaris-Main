<?php
/* azure teması — Mağaza (shop) görünümü
   Tüm sorgular bu şablonda yapılır (diğer tema şablonlarıyla aynı model). */

$db  = nexus_db();
$me  = auth_check() ? auth_user() : null;
$pid = isset($_GET['product']) ? (int)$_GET['product'] : 0;

$viewTab = $_GET['tab'] ?? 'shop';   // 'shop' | 'purchases'

/* Flash mesajı */
$flash = $_GET['flash'] ?? '';
[$flashType, $flashText] = $flash ? explode(':', urldecode($flash), 2) + ['',''] : ['', ''];

/* Mağaza detayı /products üzerinden servis edilir (products.php bu şablonu include eder);
   /shop rotası 404 verir. Bu şablon yalnızca ürün detayı (?product) ve Satın Aldıklarım (?tab=purchases) içindir. */
if (!$pid && $viewTab !== 'purchases') {
    $redir = ['cat' => trim($_GET['cat'] ?? ''), 'q' => trim($_GET['q'] ?? '')];
    if ($flash) $redir['flash'] = $flash;
    $redir = array_filter($redir, fn($v) => $v !== '');
    header('Location: /products' . ($redir ? '?' . http_build_query($redir) : ''), true, 302);
    exit;
}

/* Kullanıcı bakiyesi */
$balance = 0.00;
if ($me && $db) {
    $bRow = $db->prepare('SELECT balance FROM users WHERE id=?');
    $bRow->execute([$me['id']]);
    $balance = (float)($bRow->fetchColumn() ?? 0);
}

/* Ürün listesi */
$selCat  = trim($_GET['cat'] ?? '');
$products = [];
$allCats  = [];
if ($db) {
    try {
        $allCats = $db->query("SELECT name,icon,description FROM categories ORDER BY sort_order ASC, name ASC")->fetchAll();
    } catch (\Exception $e) { $allCats = []; }
    $avgSub = '(SELECT COALESCE(ROUND(AVG(c.rating),1),0) FROM comments c WHERE c.product_id=p.id AND c.rating>0)';
    try {
        if ($selCat) {
            $pSt = $db->prepare("SELECT p.*, $avgSub AS avg_rating FROM products p WHERE p.is_active=1 AND p.is_hidden=0 AND p.status='active' AND p.category=? ORDER BY p.created_at DESC");
            $pSt->execute([$selCat]);
            $products = $pSt->fetchAll();
        } else {
            $products = $db->query("SELECT p.*, $avgSub AS avg_rating FROM products p WHERE p.is_active=1 AND p.is_hidden=0 AND p.status='active' ORDER BY p.created_at DESC")->fetchAll();
        }
    } catch (\Exception $e) { $products = []; }
}

/* Aktif ürün detayı */
$activeProduct = null;
$comments      = [];
$userCart      = [];
$ownedIds      = [];

if ($db) {
    try {
        if ($pid) {
            $avgSub = '(SELECT COALESCE(ROUND(AVG(c.rating),1),0) FROM comments c WHERE c.product_id=p.id AND c.rating>0)';
            $cntSub = '(SELECT COUNT(*) FROM comments c WHERE c.product_id=p.id AND c.rating>0)';
            $stmt = $db->prepare("SELECT p.*, $avgSub AS avg_rating, $cntSub AS rating_count FROM products p WHERE p.id=? AND p.is_hidden=0 AND p.is_active=1 AND p.status='active'");
            $stmt->execute([$pid]);
            $activeProduct = $stmt->fetch();
            if ($activeProduct) {
                if (feature_active('reviews')) {
                $cStmt = $db->prepare(
                    'SELECT c.*,u.username,u.avatar FROM comments c
                     LEFT JOIN users u ON u.id=c.user_id
                     WHERE c.product_id=? ORDER BY c.created_at ASC'
                );
                $cStmt->execute([$pid]);
                $comments = $cStmt->fetchAll();
                }
            }
        }
        if ($me) {
            $cartStmt = $db->prepare(
                'SELECT c.*,p.name,p.price,p.image_url FROM cart c
                 JOIN products p ON p.id=c.product_id WHERE c.user_id=?'
            );
            $cartStmt->execute([$me['id']]);
            $userCart = $cartStmt->fetchAll();

            $ownedStmt = $db->prepare('SELECT product_id FROM sales WHERE user_id=?');
            $ownedStmt->execute([$me['id']]);
            $ownedIds = $ownedStmt->fetchAll(PDO::FETCH_COLUMN);
        }
    } catch (\Exception $e) {}
}

/* Satın alınan ürünler (Satın Aldıklarım sekmesi) */
$purchases = [];
if ($me && $db && $viewTab === 'purchases') {
    try {
        $pStmt = $db->prepare(
            'SELECT s.id AS sale_id, s.license_key, s.price_paid, s.purchased_at,
                    p.id AS product_id, p.name, p.image_url, p.file_path, p.category, p.version
             FROM sales s
             JOIN products p ON p.id = s.product_id
             WHERE s.user_id = ?
             ORDER BY s.purchased_at DESC'
        );
        $pStmt->execute([$me['id']]);
        $purchases = $pStmt->fetchAll();
    } catch (\Exception $e) { $purchases = []; }
}

$cartTotal = array_sum(array_map(fn($i) => $i['price'] * $i['quantity'], $userCart));
$cartCount = array_sum(array_map(fn($i) => $i['quantity'], $userCart));

$ownComment = null;
if ($me && !empty($comments)) {
    foreach ($comments as $comment) {
        if ((int)$comment['user_id'] === (int)$me['id']) { $ownComment = $comment; break; }
    }
}

$pageTitle  = __('nav.shop');
$activePage = 'products';
$seoKey     = $activeProduct ? '' : 'products';

$productVersions = [];
if ($db && $activeProduct && function_exists('product_versions_list')) {
    $productVersions = product_versions_list($db, (int)$activeProduct['id']);
}

include __DIR__ . '/includes/header.php';

?>
<style>
.az-notice{display:flex;align-items:center;gap:10px;padding:14px 18px;border-radius:var(--radius-lg);font-size:14px;font-weight:600;border:1px solid var(--line);}
.az-notice svg{width:18px;height:18px;flex-shrink:0;}
.az-notice--ok{background:rgba(34,197,94,.1);border-color:rgba(34,197,94,.35);color:#15803d;}
.az-notice--err{background:rgba(228,87,107,.1);border-color:rgba(228,87,107,.35);color:var(--danger);}

.az-cat-chip{display:inline-flex;align-items:center;gap:7px;padding:8px 14px;border-radius:10px;border:1px solid var(--line);background:var(--surface);font-size:13px;font-weight:600;color:var(--text-2);transition:all .14s;}
.az-cat-chip svg{width:14px;height:14px;}
.az-cat-chip:hover{border-color:var(--brand-2);color:var(--brand-deep);transform:translateY(-1px);}
.az-cat-chip.active{background:var(--brand-soft);border-color:transparent;color:var(--brand-deep);font-weight:800;}

.product-badge{position:absolute;top:10px;left:10px;z-index:2;}
.product-badge--owned{background:var(--success);}

.az-empty{color:var(--muted);}

/* satın aldıklarım */
.az-purchase-list{display:flex;flex-direction:column;gap:16px;}
.az-purchase{overflow:hidden;}
.az-purchase-main{display:flex;gap:18px;align-items:flex-start;}
.az-purchase-thumb{width:68px;height:68px;border-radius:14px;object-fit:cover;border:1px solid var(--line);flex-shrink:0;background:var(--surface);}
.az-purchase-thumb--ph{display:flex;align-items:center;justify-content:center;color:var(--dim);}
.az-purchase-thumb--ph svg{width:26px;height:26px;}
.az-purchase-body{flex:1;min-width:0;}
.az-purchase-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;flex-wrap:wrap;}
.az-purchase-info{min-width:0;}
.az-cat-label{font-size:10.5px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--brand);}
.az-purchase-name{margin:4px 0 2px;font-family:var(--font-title);font-size:17px;font-weight:800;color:var(--text);}
.az-purchase-meta{font-size:12.5px;color:var(--muted);}
.az-purchase-actions{display:flex;gap:8px;flex-shrink:0;}
.az-btn-dl{background:linear-gradient(135deg,#22c55e,#16a34a);color:#fff;border:1px solid #15803d;}
.az-btn-dl:hover{filter:brightness(1.08);transform:translateY(-2px);}
.az-license{display:flex;gap:8px;align-items:center;margin-top:14px;}
.az-license-box{flex:1;min-width:0;display:flex;align-items:center;gap:8px;background:var(--bg-soft);border:1px solid var(--line);border-radius:9px;padding:9px 12px;}
.az-license-box svg{width:14px;height:14px;color:var(--brand);flex-shrink:0;}
.az-license-box code{font-family:ui-monospace,Consolas,monospace;font-size:12.5px;font-weight:700;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:.04em;}
.az-chip{display:inline-flex;align-items:center;gap:8px;font-weight:800;border-radius:var(--radius-lg);padding:12px 16px;font-size:14px;}
.az-chip svg{width:18px;height:18px;}
.az-chip--mini{font-size:10.5px;padding:3px 8px;border-radius:20px;gap:4px;}
.az-chip--mini svg{width:11px;height:11px;}
.az-chip{background:rgba(34,197,94,.12);color:#16a34a;border:1px solid rgba(34,197,94,.35);}
.az-chip--err{background:rgba(228,87,107,.1);color:var(--danger);border:1px solid rgba(228,87,107,.35);}

/* yıldızlar */
.az-st{display:inline-flex;gap:2px;}
.az-st svg{width:15px;height:15px;color:var(--dim);}
.az-st span.on svg{color:#f7b731;fill:currentColor;}

/* yorum */
.az-comment{background:var(--bg-soft);border:1px solid var(--line);border-radius:var(--radius-lg);padding:16px;}
.az-comment--own{border-color:rgba(43,110,255,.3);}
.az-comment-head{display:flex;align-items:center;gap:10px;}
.az-avatar{width:32px;height:32px;border-radius:10px;object-fit:cover;image-rendering:pixelated;background:var(--brand-soft);}
.az-avatar-ph{width:32px;height:32px;border-radius:10px;background:linear-gradient(135deg,var(--brand) 0%,var(--brand-2) 100%);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-weight:800;font-size:15px;flex-shrink:0;}
.az-comment-name{font-size:14px;font-weight:700;color:var(--text);}
.az-comment-text{font-size:14px;line-height:1.7;color:var(--text-2);}
.az-comment-actions{display:flex;gap:8px;margin-top:12px;}

.az-comment-form{margin-top:20px;background:var(--bg-soft);border:1px dashed var(--line-strong);border-radius:var(--radius-lg);padding:18px;display:flex;flex-direction:column;}
.az-com-label{font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);}
.az-star-btn{width:38px;height:38px;background:var(--surface);border:1px solid var(--line);border-radius:10px;display:inline-flex;align-items:center;justify-content:center;color:var(--dim);cursor:pointer;transition:all .15s;}
.az-star-btn svg{width:18px;height:18px;}
.az-star-btn:hover{color:#f7b731;border-color:#f7b731;}
.az-star-btn.on{color:#f7b731;border-color:#f7b731;background:rgba(247,183,49,.08);}
.az-star-btn.on svg{fill:currentColor;}

.az-prose{font-size:15px;line-height:1.8;color:var(--text-2);}
.az-prose h1,.az-prose{font-size:15px;}
.az-prose h1,.az-prose h2,.az-prose h3{color:var(--text);margin:18px 0 8px;font-family:var(--font-title);}
.az-prose strong{color:var(--text);}
.az-prose code{background:var(--bg-soft);padding:2px 7px;border-radius:5px;font-size:13px;color:var(--brand-deep);}
.az-prose pre{background:var(--bg-soft);border:1px solid var(--line);border-radius:10px;padding:16px;overflow-x:auto;margin:12px 0;}
.az-prose ul,.az-prose ol{padding-left:20px;margin:10px 0;}
.az-prose li{margin-bottom:4px;}
.az-prose a{color:var(--brand);font-weight:600;}
.az-prose blockquote{border-left:3px solid var(--brand-2);padding:4px 14px;color:var(--muted);margin:12px 0;}

@media(max-width:820px){
  .az-detail-grid{grid-template-columns:1fr!important;}
  .az-detail{grid-template-columns:1fr!important;}
  .az-purchase-main{flex-direction:column;}
  .az-purchase-actions{width:100%;}
}
</style>
<style>.bn-method-btn.is-active{border-color:var(--brand)!important;color:var(--brand)!important;}</style>
<main>

  <?php if ($flashText): ?>
  <div class="container" style="padding:24px 22px 0;">
    <div class="az-notice az-notice--<?= $flashType === 'success' ? 'ok' : 'err' ?>" role="status">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="<?= $flashType === 'success' ? 'm5 13 4 4 10-11' : 'M18 6 6 18M6 6l12 12' ?>"/></svg>
      <span><?= e($flashText) ?></span>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($viewTab === 'purchases'): ?>
  <!-- ============ SATIN ALDIKLARIM ============ -->
  <section class="section">
    <div class="container" style="max-width:880px;">

      <div class="section-head reveal" style="display:flex;align-items:flex-end;justify-content:space-between;gap:16px;flex-wrap:wrap;">
        <div>
          <span class="section-eyebrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h16v12H4z"/><path d="M12 8V4m0 0h-2m2 0h2"/><path d="M9 13h6m-6 4h6"/></svg><?= __('library.tag') ?></span>
          <h1 class="section-title"><?= __('library.title') ?></h1>
        </div>
        <a href="/products" class="btn btn-ghost btn-sm">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 18l-6-6 6-6"/></svg>
          <?= __('library.back') ?>
        </a>
      </div>

      <?php if (empty($purchases)): ?>
      <div class="panel-card az-empty reveal">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h16v12H4z"/><path d="M12 8V4m0 0h-2m2 0h2"/><path d="M9 13h6m-6 4h6"/></svg>
        <p><?= __('library.empty_azure') ?></p>
        <a href="/products" class="btn btn-primary btn-sm"><?= __('library.explore') ?></a>
      </div>
      <?php else: ?>
      <div class="az-purchase-list reveal">
        <?php foreach ($purchases as $pur): ?>
        <article class="panel-card az-purchase" style="position:relative;">
          <div class="az-purchase-main">

            <?php if (!empty($pur['image_url'])): ?>
            <img src="<?= e($pur['image_url']) ?>" width="64" height="64" class="az-purchase-thumb" alt="<?= e($pur['name']) ?>">
            <?php else: ?>
            <span class="az-purchase-thumb az-purchase-thumb--ph"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="4" y="3" width="16" height="14" rx="3"/><path d="M9 7h6"/></svg></span>
            <?php endif; ?>

            <div class="az-purchase-body">
              <div class="az-purchase-head">
                <div class="az-purchase-info">
                  <?php if ($pur['category']): ?>
                  <span class="az-cat-label"><?= e($pur['category']) ?></span>
                  <?php endif; ?>
                  <h3 class="az-purchase-name"><?= e($pur['name']) ?></h3>
                  <p class="az-purchase-meta">
                    <?php if ($pur['version']): ?>v<span><?= e($pur['version']) ?></span> · <?php endif; ?>
                    <?= __('library.purchased_on') ?> <?= date('d.m.Y H:i', strtotime($pur['purchased_at'])) ?>
                    · <strong style="color:#f7b731;"><?= fmt_money((float)$pur['price_paid']) ?></strong>
                  </p>
                </div>
                <div class="az-purchase-actions">
                  <?php if ($pur['file_path']): ?>
                  <a href="/download.php?sale_id=<?= (int)$pur['sale_id'] ?>" class="btn btn-sm az-btn-dl">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>
                    <?= __('library.download') ?>
                  </a>
                  <?php endif; ?>
                  <a href="/products?product=<?= (int)$pur['product_id'] ?>" class="btn btn-ghost btn-sm">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v4m0 4h.01"/></svg>
                    <?= __('panel.detail') ?>
                  </a>
                </div>
              </div>

              <?php if ($pur['license_key']): ?>
              <div class="az-license">
                <div class="az-license-box">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="15" r="4"/><path d="m10.85 12.15 8.5-8.5"/><path d="M17.5 4.5 20 7"/></svg>
                  <code id="lic-<?= (int)$pur['sale_id'] ?>"><?= e($pur['license_key']) ?></code>
                </div>
                <button onclick="copyLicense('lic-<?= (int)$pur['sale_id'] ?>')" class="btn btn-ghost btn-sm" title="Kopyala">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>
                  Kopyala
                </button>
              </div>
              <?php endif; ?>

            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

    </div>
  </section>

  <?php elseif ($activeProduct): ?>
  <section class="section">
    <div class="container" style="max-width:1120px;">

      <a href="/products" class="btn btn-ghost btn-sm reveal" style="margin-bottom:20px;display:inline-flex;align-items:center;gap:8px;">
        <i class="fa-solid fa-arrow-left"></i>
        <span><?= __('library.back') ?></span>
      </a>

      <div class="az-product-hero reveal" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(min(280px,100%), 1fr));gap:32px;align-items:start;">

        <div style="display:flex;flex-direction:column;gap:16px;min-width:0;">
          <?php if (!empty($activeProduct['image_url'])): ?>
          <div style="width:100%;aspect-ratio:16/10;border-radius:var(--radius-lg);overflow:hidden;border:1px solid var(--line);background:var(--surface);box-shadow:var(--shadow-sm);">
            <img src="<?= e($activeProduct['image_url']) ?>" width="800" height="500" alt="<?= e($activeProduct['name']) ?>" style="width:100%;height:100%;object-fit:cover;">
          </div>
          <?php else: ?>
          <div style="width:100%;aspect-ratio:16/10;border-radius:var(--radius-lg);border:1px solid var(--line);background:var(--surface);display:flex;align-items:center;justify-content:center;color:var(--dim);box-shadow:var(--shadow-sm);">
            <i class="fa-solid fa-cube" style="font-size:56px;color:var(--dim);"></i>
          </div>
          <?php endif; ?>

          <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;">
            <div style="display:flex;align-items:center;gap:10px;padding:12px 14px;background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-sm);font-size:12px;font-weight:700;color:var(--text-2);">
              <i class="fa-solid fa-bolt" style="color:var(--brand);font-size:15px;"></i>
              <span><?= __('product.delivery_instant') ?></span>
            </div>
            <div style="display:flex;align-items:center;gap:10px;padding:12px 14px;background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-sm);font-size:12px;font-weight:700;color:var(--text-2);">
              <i class="fa-solid fa-shield-halved" style="color:var(--ok);font-size:15px;"></i>
              <span><?= __('product.secure') ?></span>
            </div>
            <div style="display:flex;align-items:center;gap:10px;padding:12px 14px;background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-sm);font-size:12px;font-weight:700;color:var(--text-2);">
              <i class="fa-solid fa-rotate" style="color:var(--brand-2);font-size:15px;"></i>
              <span><?= __('product.free_updates') ?></span>
            </div>
            <div style="display:flex;align-items:center;gap:10px;padding:12px 14px;background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-sm);font-size:12px;font-weight:700;color:var(--text-2);">
              <i class="fa-solid fa-headset" style="color:var(--warn);font-size:15px;"></i>
              <span>7/24 Destek</span>
            </div>
          </div>
        </div>

        <div class="panel-card" style="padding:28px;display:flex;flex-direction:column;gap:18px;">
          <div>
            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px;flex-wrap:wrap;">
              <?php if (!empty($activeProduct['category'])): ?>
              <span style="font-size:11px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--brand);background:var(--brand-soft);padding:4px 10px;border-radius:6px;"><?= e($activeProduct['category']) ?></span>
              <?php endif; ?>
              <?php if (!empty($activeProduct['version'])): ?>
              <span style="font-size:12px;font-weight:800;background:var(--bg-soft);color:var(--text-2);padding:4px 10px;border-radius:8px;border:1px solid var(--line);">v<?= e($activeProduct['version']) ?></span>
              <?php endif; ?>
            </div>

            <h1 style="font-family:var(--font-title);font-size:clamp(22px,3vw,30px);font-weight:800;letter-spacing:-.4px;line-height:1.25;margin:0 0 10px;color:var(--text);"><?= e($activeProduct['name']) ?></h1>

            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
              <div class="az-st" style="display:flex;gap:3px;">
                <?php $avgVal = (float)($activeProduct['avg_rating'] ?? 0); ?>
                <?php for ($s = 1; $s <= 5; $s++): ?>
                <i class="fa-solid fa-star" style="font-size:13px;color:<?= $s <= round($avgVal) ? '#f59e0b' : 'var(--line-strong)' ?>;"></i>
                <?php endfor; ?>
              </div>
              <a href="javascript:void(0)" onclick="scrollToReviews()" style="font-size:13px;font-weight:700;color:var(--muted);display:inline-flex;align-items:center;gap:4px;text-decoration:none;">
                <span style="color:var(--text);font-weight:800;"><?= number_format($avgVal, 1, ',', '.') ?></span>
                <span><?= __('product.reviews_n', ['n' => (int)($activeProduct['rating_count'] ?? count($comments))]) ?></span>
                <i class="fa-solid fa-angle-right" style="font-size:11px;"></i>
              </a>
            </div>
          </div>

          <?php if (!empty($activeProduct['short_description'])): ?>
          <p style="font-size:14px;color:var(--text-2);line-height:1.6;margin:0;"><?= e($activeProduct['short_description']) ?></p>
          <?php endif; ?>

          <?php if (!empty($activeProduct['user_notice'])): ?>
          <div class="az-notice az-notice--info" style="padding:12px 14px;border-radius:var(--radius-sm);background:rgba(43,110,255,.07);border:1px solid rgba(43,110,255,.2);display:flex;align-items:flex-start;gap:10px;font-size:13px;color:var(--text);">
            <i class="fa-solid fa-circle-info" style="color:var(--brand);margin-top:2px;"></i>
            <span><?= e($activeProduct['user_notice']) ?></span>
          </div>
          <?php endif; ?>

          <div style="padding:16px 20px;background:var(--bg-soft);border:1px solid var(--line);border-radius:var(--radius);display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;">
            <div>
              <div style="font-size:11px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);margin-bottom:2px;">Fiyat</div>
              <?php $ap = (float)$activeProduct['price']; $ad = (int)($activeProduct['discount_percent'] ?? 0); $an = $ad>0 && $ap>0 ? $ap*(1-$ad/100) : $ap; if ($ap > 0): ?>
                <?php if ($ad>0): ?>
                  <div style="display:flex;align-items:baseline;gap:8px;flex-wrap:wrap">
                    <span style="font-size:14px;color:var(--muted);text-decoration:line-through"><?= fmt_money($ap) ?></span>
                    <span style="background:#ff4757;color:#fff;font-size:11px;font-weight:800;padding:2px 7px;border-radius:50px"><?= __('product.discount_pct', ['n' => $ad]) ?></span>
                  </div>
                  <span style="font-family:var(--font-title);font-size:30px;font-weight:800;color:var(--brand);"><?= fmt_money($an) ?></span>
                <?php else: ?>
                  <span style="font-family:var(--font-title);font-size:30px;font-weight:800;color:var(--text);"><?= fmt_money($ap) ?></span>
                <?php endif; ?>
              <?php else: ?>
              <span style="display:inline-flex;align-items:center;gap:6px;font-family:var(--font-title);font-size:24px;font-weight:800;color:var(--brand);"><i class="fa-solid fa-gift" style="font-size:18px"></i><?= __('shop.free') ?></span>
              <?php endif; ?>
            </div>

            <?php if ($activeProduct['stock_type'] === 'limited'): ?>
              <?php if ((int)$activeProduct['stock'] < 1): ?>
              <span style="font-size:12px;font-weight:800;color:#ef4444;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);padding:6px 12px;border-radius:8px;display:inline-flex;align-items:center;gap:6px;">
                <i class="fa-solid fa-ban"></i> <?= __('product.soldout') ?>
              </span>
              <?php elseif ((int)$activeProduct['stock'] <= 5): ?>
              <span style="font-size:12px;font-weight:800;color:#b45309;background:rgba(247,183,49,.12);border:1px solid rgba(247,183,49,.35);padding:6px 12px;border-radius:8px;display:inline-flex;align-items:center;gap:6px;">
                <i class="fa-solid fa-bolt"></i> Son <?= (int)$activeProduct['stock'] ?> adet stokta
              </span>
              <?php else: ?>
              <span style="font-size:12px;font-weight:800;color:var(--text-2);background:var(--surface);border:1px solid var(--line);padding:6px 12px;border-radius:8px;display:inline-flex;align-items:center;gap:6px;">
                <i class="fa-solid fa-box-open" style="color:var(--brand);"></i> <?= (int)$activeProduct['stock'] ?> adet stokta
              </span>
              <?php endif; ?>
            <?php else: ?>
            <span style="font-size:12px;font-weight:800;color:var(--ok);background:rgba(15,174,124,.1);border:1px solid rgba(15,174,124,.25);padding:6px 12px;border-radius:8px;display:inline-flex;align-items:center;gap:6px;">
              <i class="fa-solid fa-infinity"></i> <?= __('product.unlimited') ?>
            </span>
            <?php endif; ?>
          </div>

          <?php if (!$me): ?>
          <a href="/login" class="btn btn-primary btn-block btn-lg" style="display:flex;align-items:center;justify-content:center;gap:8px;font-size:15px;">
            <i class="fa-solid fa-right-to-bracket"></i>
            <span><?= __('product.login_buy') ?></span>
          </a>
          <?php elseif (in_array((int)$activeProduct['id'], array_map('intval', $ownedIds))): ?>
          <div class="detail-buy-row" style="display:flex;gap:12px;">
            <div class="az-chip az-chip-ok" style="flex:1;justify-content:center;padding:14px;font-size:14px;gap:8px;">
              <i class="fa-solid fa-circle-check"></i>
              <span><?= __('product.owned') ?></span>
            </div>
            <a href="/products?tab=purchases" class="btn btn-ghost btn-lg" title="<?= e(__('library.download_go')) ?>" style="display:inline-flex;align-items:center;gap:8px;">
              <i class="fa-solid fa-download"></i>
              <span><?= __('product.library') ?></span>
            </a>
          </div>
          <?php elseif ($activeProduct['stock_type'] === 'limited' && (int)$activeProduct['stock'] < 1): ?>
          <div class="az-chip az-chip--err" style="justify-content:center;padding:14px;font-size:14px;gap:8px;">
            <i class="fa-solid fa-ban"></i>
            <span><?= __('product.soldout') ?></span>
          </div>
          <?php else: ?>
          <div class="detail-buy-row" style="display:flex;gap:12px;">
            <button onclick="cartAdd(<?= (int)$activeProduct['id'] ?>)" class="btn btn-ghost btn-lg" style="flex:1;display:flex;align-items:center;justify-content:center;gap:8px;">
              <i class="fa-solid fa-cart-plus"></i>
              <span><?= __('cart.add') ?></span>
            </button>
            <button id="buyNowBtn" onclick="buyNow(<?= (int)$activeProduct['id'] ?>)" class="btn btn-primary btn-lg" style="flex:1.2;display:flex;align-items:center;justify-content:center;gap:8px;">
              <i class="fa-solid fa-bolt"></i>
              <span><?= __('product.buy_now') ?></span>
            </button>
          </div>
          <?php endif; ?>

        </div>
      </div>

      <div id="productTabsNav" class="panel-card reveal" style="margin-top:32px;padding:0;overflow:hidden;">
        
        <div style="display:flex;align-items:center;gap:6px;padding:8px 12px;background:var(--bg-soft);border-bottom:1px solid var(--line);overflow-x:auto;">
          <button type="button" class="az-tab-nav-btn active" data-target="desc" onclick="switchAzTab('desc', this)" style="display:inline-flex;align-items:center;gap:8px;padding:12px 20px;border-radius:var(--radius-sm);border:none;background:var(--surface);color:var(--brand);box-shadow:var(--shadow-sm);font-weight:800;font-size:14px;cursor:pointer;transition:all .18s ease;white-space:nowrap;">
            <i class="fa-solid fa-align-left" style="color:var(--brand);"></i>
            <span><?= __('product.tab_desc') ?></span>
          </button>
          <button type="button" class="az-tab-nav-btn" data-target="reviews" id="btnTabReviews" onclick="switchAzTab('reviews', this)" style="display:inline-flex;align-items:center;gap:8px;padding:12px 20px;border-radius:var(--radius-sm);border:none;background:transparent;color:var(--text-2);font-weight:800;font-size:14px;cursor:pointer;transition:all .18s ease;white-space:nowrap;">
            <i class="fa-solid fa-star" style="color:#f59e0b;"></i>
            <span><?= __('product.tab_reviews') ?></span>
            <span style="background:rgba(43,110,255,.1);color:var(--brand);font-size:11px;font-weight:800;padding:2px 8px;border-radius:50px;"><?= count($comments) ?></span>
          </button>
          <button type="button" class="az-tab-nav-btn" data-target="specs" onclick="switchAzTab('specs', this)" style="display:inline-flex;align-items:center;gap:8px;padding:12px 20px;border-radius:var(--radius-sm);border:none;background:transparent;color:var(--text-2);font-weight:800;font-size:14px;cursor:pointer;transition:all .18s ease;white-space:nowrap;">
            <i class="fa-solid fa-circle-info" style="color:var(--brand-2);"></i>
            <span>Teknik Bilgiler</span>
          </button>
          <button type="button" class="az-tab-nav-btn" data-target="updates" onclick="switchAzTab('updates', this)" style="display:inline-flex;align-items:center;gap:8px;padding:12px 20px;border-radius:var(--radius-sm);border:none;background:transparent;color:var(--text-2);font-weight:800;font-size:14px;cursor:pointer;transition:all .18s ease;white-space:nowrap;">
            <i class="fa-solid fa-code-branch" style="color:var(--ok);"></i>
            <span><?= __('product.tab_updates') ?></span>
            <span style="background:rgba(43,110,255,.1);color:var(--brand);font-size:11px;font-weight:800;padding:2px 8px;border-radius:50px;"><?= count($productVersions) ?></span>
          </button>
        </div>

        <div style="padding:28px;">
          
          <div id="tab-pane-desc" class="az-tab-pane">
            <div class="az-prose">
              <?= nx_clean_html((string)($activeProduct['description'] ?? ''), 'rich') ?: '<p style="color:var(--muted);">' . e(__('product.no_desc_azure')) . '</p>' ?>
            </div>
          </div>

          <div id="tab-pane-reviews" class="az-tab-pane" style="display:none;">
            <div style="display:flex;flex-direction:column;gap:24px;">

              <div style="display:flex;align-items:center;justify-content:space-between;padding:20px 24px;background:var(--bg-soft);border:1px solid var(--line);border-radius:var(--radius);gap:16px;flex-wrap:wrap;">
                <div style="display:flex;align-items:center;gap:18px;">
                  <div style="font-family:var(--font-title);font-size:38px;font-weight:900;color:var(--text);line-height:1;"><?= number_format((float)($activeProduct['avg_rating'] ?? 0), 1, ',', '.') ?></div>
                  <div>
                    <div class="az-st" style="display:flex;gap:3px;margin-bottom:4px;">
                      <?php for ($s = 1; $s <= 5; $s++): ?>
                      <i class="fa-solid fa-star" style="font-size:15px;color:<?= $s <= round((float)($activeProduct['avg_rating'] ?? 0)) ? '#f59e0b' : 'var(--line-strong)' ?>;"></i>
                      <?php endfor; ?>
                    </div>
                    <div style="font-size:13px;color:var(--muted);font-weight:600;"><?= __('product.users_rated', ['n' => count($comments)]) ?></div>
                  </div>
                </div>
              </div>

              <div id="listComments" style="display:flex;flex-direction:column;gap:14px;">
                <?php foreach ($comments as $comment):
                    $isOwnComment = $me && (int)$comment['user_id'] === (int)$me['id'];
                    $avatarUrl = !empty($comment['avatar']) ? $comment['avatar'] : '';
                ?>
                <div class="az-comment <?= $isOwnComment ? 'az-comment--own' : '' ?>" data-comment-id="<?= (int)$comment['id'] ?>" data-comment-text="<?= htmlspecialchars($comment['comment_text'], ENT_QUOTES) ?>">
                  <div class="az-comment-head">
                    <?php if ($avatarUrl): ?>
                    <img src="<?= e($avatarUrl) ?>" class="az-avatar" alt="">
                    <?php else: ?>
                    <span class="az-avatar raz-avatar-ph"><?= htmlspecialchars(mb_strtoupper(mb_substr($comment['username'] ?? '?', 0, 1, 'UTF-8'))) ?></span>
                    <?php endif; ?>
                    <span class="az-comment-name"><?= e($comment['username'] ?? '?') ?></span>
                    <?php if ($isOwnComment): ?>
                    <span class="az-chip az-chip--mini" style="color:var(--brand);background:var(--brand-soft);">Sen</span>
                    <?php endif; ?>
                    <span style="margin-left:auto;font-size:12px;color:var(--muted);"><?= date('d.m.Y H:i', strtotime($comment['created_at'])) ?></span>
                  </div>
                  <?php if ((int)$comment['rating'] > 0): ?>
                  <div class="az-st" id="cstars-<?= (int)$comment['id'] ?>" style="margin:6px 0 8px;display:flex;gap:2px;">
                    <?php for ($s = 1; $s <= 5; $s++): ?>
                    <i class="fa-solid fa-star" style="font-size:13px;color:<?= $s <= (int)$comment['rating'] ? '#f59e0b' : 'var(--line-strong)' ?>;"></i>
                    <?php endfor; ?>
                  </div>
                  <?php endif; ?>
                  <div class="az-comment-text" id="ctext-<?= (int)$comment['id'] ?>"><?= nl2br(e($comment['comment_text'])) ?></div>
                  <?php if ($isOwnComment): ?>
                  <div class="az-comment-actions">
                    <button onclick="openEditComment(<?= (int)$comment['id'] ?>, <?= (int)$comment['rating'] ?>)" class="btn btn-ghost btn-sm" style="display:inline-flex;align-items:center;gap:6px;">
                      <i class="fa-solid fa-pen" style="font-size:11px;"></i>
                      <?= __('product.edit') ?>
                    </button>
                    <button onclick="deleteComment(<?= (int)$comment['id'] ?>)" class="btn btn-danger btn-sm" style="display:inline-flex;align-items:center;gap:6px;">
                      <i class="fa-solid fa-trash" style="font-size:11px;"></i>
                      <?= __('product.delete') ?>
                    </button>
                  </div>
                  <?php endif; ?>
                </div>
                <?php endforeach; ?>
                <?php if (empty($comments)): ?>
                <div id="commentsEmpty" style="display:flex;flex-direction:column;align-items:center;gap:8px;padding:36px 10px;color:var(--muted);text-align:center;">
                  <i class="fa-solid fa-comments" style="font-size:42px;color:var(--dim);"></i>
                  <p style="font-weight:600;margin:0;"><?= __('product.no_reviews_azure') ?></p>
                  <p style="font-size:13px;margin:0;"><?= __('product.no_reviews_hint') ?></p>
                </div>
                <?php endif; ?>
              </div>

              <?php if ($me): ?>
                <?php if (in_array((int)$activeProduct['id'], array_map('intval', $ownedIds))): ?>
                  <?php if (!$ownComment): ?>
                  <div class="az-comment-form" id="commentFormCard" style="background:var(--bg-soft);padding:24px;border-radius:var(--radius);border:1px solid var(--line);">
                    <label class="az-com-label" style="font-weight:800;color:var(--text);margin-bottom:8px;display:block;"><?= __('product.your_rating') ?></label>
                    <div class="az-rating" id="starRating" style="display:flex;gap:6px;margin-bottom:14px;">
                      <?php for ($star = 1; $star <= 5; $star++): ?>
                      <button type="button" class="az-star-btn" data-star="<?= $star ?>" onclick="setRating(<?= $star ?>)" style="background:none;border:none;cursor:pointer;padding:4px;"><i class="fa-solid fa-star" style="font-size:22px;color:var(--line-strong);"></i></button>
                      <?php endfor; ?>
                    </div>
                    <input type="hidden" id="ratingValue" value="0">
                    <textarea id="commentText" class="form-input" rows="4" style="width:100%;resize:vertical;margin-bottom:14px;" placeholder="<?= e(__('product.comment_ph_azure')) ?>"></textarea>
                    <button id="commentSubmitBtn" onclick="submitComment(<?= (int)$activeProduct['id'] ?>)" class="btn btn-primary btn-block" style="display:flex;align-items:center;justify-content:center;gap:8px;">
                      <i class="fa-solid fa-paper-plane"></i>
                      <?= __('product.send_review') ?>
                    </button>
                  </div>
                  <div id="commentOwnedNotice" style="display:none;text-align:center;padding:18px;color:var(--muted);background:var(--bg-soft);border:1px dashed var(--line-strong);border-radius:var(--radius-lg);">
                    <i class="fa-solid fa-circle-check" style="color:var(--ok);margin-right:6px;"></i>
                    <?= __('product.reviewed_msg_azure') ?>
                  </div>
                  <?php else: ?>
                  <div style="text-align:center;padding:18px;color:var(--muted);background:var(--bg-soft);border:1px dashed var(--line-strong);border-radius:var(--radius-lg);">
                    <i class="fa-solid fa-circle-check" style="color:var(--ok);margin-right:6px;"></i>
                    <?= __('product.reviewed_msg_azure') ?>
                  </div>
                  <?php endif; ?>
                <?php else: ?>
                <div style="text-align:center;padding:18px;color:var(--muted);background:var(--bg-soft);border-radius:var(--radius-lg);font-weight:600;">
                  <i class="fa-solid fa-lock" style="margin-right:6px;color:var(--dim);"></i>
                  <?= __('product.must_own_azure') ?>
                </div>
                <?php endif; ?>
              <?php else: ?>
              <div style="text-align:center;padding:16px;color:var(--muted);background:var(--bg-soft);border-radius:var(--radius-lg);">
                <?= __('product.login_review_a') ?> <a href="/login" style="color:var(--brand);font-weight:800;"><?= __('product.login_review_b') ?></a>.
              </div>
              <?php endif; ?>

            </div>
          </div>

          <div id="tab-pane-specs" class="az-tab-pane" style="display:none;">
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;">
              
              <div style="padding:18px 20px;background:var(--bg-soft);border:1px solid var(--line);border-radius:var(--radius-sm);display:flex;align-items:center;gap:14px;">
                <div style="width:44px;height:44px;border-radius:12px;background:var(--surface);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;color:var(--brand);font-size:18px;flex-shrink:0;">
                  <i class="fa-solid fa-layer-group"></i>
                </div>
                <div>
                  <div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:var(--dim);">Kategori</div>
                  <div style="font-size:14px;font-weight:800;color:var(--text);"><?= e($activeProduct['category'] ?? __('shop.general')) ?></div>
                </div>
              </div>

              <div style="padding:18px 20px;background:var(--bg-soft);border:1px solid var(--line);border-radius:var(--radius-sm);display:flex;align-items:center;gap:14px;">
                <div style="width:44px;height:44px;border-radius:12px;background:var(--surface);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;color:var(--brand-2);font-size:18px;flex-shrink:0;">
                  <i class="fa-solid fa-code-branch"></i>
                </div>
                <div>
                  <div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:var(--dim);"><?= __('product.version') ?></div>
                  <div style="font-size:14px;font-weight:800;color:var(--text);">v<?= e($activeProduct['version'] ?? '1.0.0') ?></div>
                </div>
              </div>

              <div style="padding:18px 20px;background:var(--bg-soft);border:1px solid var(--line);border-radius:var(--radius-sm);display:flex;align-items:center;gap:14px;">
                <div style="width:44px;height:44px;border-radius:12px;background:var(--surface);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;color:var(--ok);font-size:18px;flex-shrink:0;">
                  <i class="fa-solid fa-cloud-arrow-down"></i>
                </div>
                <div>
                  <div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:var(--dim);"><?= __('product.delivery_type') ?></div>
                  <div style="font-size:14px;font-weight:800;color:var(--text);"><?= __('product.instant_auto') ?></div>
                </div>
              </div>

              <div style="padding:18px 20px;background:var(--bg-soft);border:1px solid var(--line);border-radius:var(--radius-sm);display:flex;align-items:center;gap:14px;">
                <div style="width:44px;height:44px;border-radius:12px;background:var(--surface);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;color:var(--warn);font-size:18px;flex-shrink:0;">
                  <i class="fa-solid fa-boxes-stacked"></i>
                </div>
                <div>
                  <div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:var(--dim);">Stok Durumu</div>
                  <div style="font-size:14px;font-weight:800;color:var(--text);"><?= $activeProduct['stock_type'] === 'limited' ? __('product.stock_count', ['n' => (int)$activeProduct['stock']]) : __('product.unlimited_digital') ?></div>
                </div>
              </div>

              <div style="padding:18px 20px;background:var(--bg-soft);border:1px solid var(--line);border-radius:var(--radius-sm);display:flex;align-items:center;gap:14px;">
                <div style="width:44px;height:44px;border-radius:12px;background:var(--surface);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;color:var(--brand);font-size:18px;flex-shrink:0;">
                  <i class="fa-solid fa-key"></i>
                </div>
                <div>
                  <div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:var(--dim);"><?= __('product.license_prot') ?></div>
                  <div style="font-size:14px;font-weight:800;color:var(--text);"><?= !empty($activeProduct['license_prefix']) ? __('product.vex_license_azure') : __('product.standard_digital') ?></div>
                </div>
              </div>

              <div style="padding:18px 20px;background:var(--bg-soft);border:1px solid var(--line);border-radius:var(--radius-sm);display:flex;align-items:center;gap:14px;">
                <div style="width:44px;height:44px;border-radius:12px;background:var(--surface);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;color:var(--text-2);font-size:18px;flex-shrink:0;">
                  <i class="fa-solid fa-calendar-days"></i>
                </div>
                <div>
                  <div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:var(--dim);"><?= __('product.pub_date') ?></div>
                  <div style="font-size:14px;font-weight:800;color:var(--text);"><?= date('d.m.Y', strtotime($activeProduct['created_at'])) ?></div>
                </div>
              </div>

            </div>
          </div>

          <div id="tab-pane-updates" class="az-tab-pane" style="display:none;">
            <?php if (function_exists('render_product_updates')) render_product_updates($productVersions, '#2b6eff'); ?>
          </div>

        </div>
      </div>
    </div>
  </section>

  <?php else: ?>
  <!-- ============ ÜRÜN LİSTESİ ============ -->
  <section class="section">
    <div class="container">

      <div class="section-head reveal" style="display:flex;align-items:flex-end;justify-content:space-between;gap:16px;flex-wrap:wrap;">
        <div>
          <span class="section-eyebrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M12 24V15"/></svg><?= __('nav.shop') ?></span>
          <h1 class="section-title"><?= $selCat ? e($selCat) : __('shop.title_all') ?></h1>
          <p class="section-sub"><?= __('shop.listing', ['n' => count($products)]) ?></p>
        </div>
        <form method="GET" action="/products" style="display:flex;gap:8px;">
          <?php if ($selCat): ?><input type="hidden" name="cat" value="<?= e($selCat) ?>"><?php endif; ?>
          <div style="position:relative;">
            <svg style="position:absolute;left:13px;top:50%;transform:translateY(-50%);width:16px;height:16px;color:var(--dim);" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
            <input type="text" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="<?= __('shop.search_ph') ?>" class="form-input" style="padding-left:38px;width:220px;">
          </div>
          <button type="submit" class="btn btn-primary btn-sm"><?= __('shop.search_btn') ?></button>
        </form>
      </div>

      <?php if (!empty($allCats)): ?>
      <div class="az-cats reveal" style="display:flex;flex-wrap:wrap;gap:8px;margin:20px 0 26px;">
        <a href="/products" class="az-cat-chip <?= !$selCat ? 'active' : '' ?>">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M12 24V15"/></svg>
          <?= __('shop.all') ?>
        </a>
        <?php foreach ($allCats as $ac): ?>
        <a href="/products?cat=<?= urlencode($ac['name']) ?>" class="az-cat-chip <?= $selCat === $ac['name'] ? 'active' : '' ?>">
          <?= cat_icon_html($ac['icon'] ?? '', 'width:14px;height:14px;object-fit:cover;border-radius:4px;') ?>
          <?= e($ac['name']) ?>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <?php if (empty($products)): ?>
      <div class="panel-card az-empty reveal" style="text-align:center;padding:56px 20px;">
        <svg style="width:44px;height:44px;color:var(--dim);margin:0 auto 14px;display:block;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M12 24V15"/><path d="M9 10.5 12 8l3 2.5"/></svg>
        <p style="font-weight:700;color:var(--text);"><?= $selCat ? __('shop.empty_cat') : __('shop.empty_none') ?></p>
      </div>
      <?php else: ?>
      <div class="products-grid reveal">
        <?php foreach ($products as $product):
            $soldOut   = (($product['stock_type'] ?? 'unlimited') === 'limited') && ((int)($product['stock'] ?? 0)) < 1;
            $isOwned   = in_array((int)$product['id'], array_map('intval', $ownedIds));
            $hasRating = (float)($product['avg_rating'] ?? 0) > 0;
        ?>
        <a href="<?= $soldOut ? 'javascript:void(0)' : '/products?product=' . (int)$product['id'] ?>" class="product-card <?= $soldOut ? 'is-soldout' : '' ?>">
          <?php if ($soldOut): ?><span class="product-badge product-badge--soldout"><?= __('product.soldout') ?></span><?php endif; ?>
          <?php if ($isOwned): ?><span class="product-badge product-badge--owned"><?= __('shop.added') ?></span><?php endif; ?>
          <div class="product-media">
            <?php if (!empty($product['image_url'])): ?>
             <img src="<?= e($product['image_url']) ?>" width="360" height="225" alt="<?= e($product['name'] ?? '') ?>">
            <?php else: ?>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="4" y="3" width="16" height="14" rx="3"/><path d="M9 7h6"/></svg>
            <?php endif; ?>
          </div>
          <div class="product-body">
            <p class="product-cat"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"/><path d="M3 8h18M8 3v5"/></svg><?= e($product['category'] ?: '') ?></p>
            <h3 class="product-title"><?= e($product['name']) ?></h3>
            <?php if ($hasRating): ?>
            <div class="az-st" style="margin-bottom:12px;">
              <?php for ($s = 1; $s <= 5; $s++): ?>
              <span class="<?= $s <= round((float)$product['avg_rating']) ? 'on' : '' ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"/></svg></span>
              <?php endfor; ?>
            </div>
            <?php endif; ?>
            <p class="product-desc"><?= htmlspecialchars(truncate_text($product['short_description'] ?? $product['description'] ?? '', 100)) ?></p>
            <div class="product-foot">
              <div class="product-price">
                <?php $pp=(float)$product['price']; $pd=(int)($product['discount_percent']??0); $pn=$pd>0&&$pp>0?$pp*(1-$pd/100):$pp; if($pp>0): if($pd>0): ?>
                <div style="display:flex;flex-direction:column;align-items:flex-start;gap:2px">
                  <div style="display:flex;align-items:center;gap:6px"><span style="font-size:12px;color:var(--muted);text-decoration:line-through"><?= fmt_money($pp) ?></span><span style="background:#ff4757;color:#fff;font-size:10px;font-weight:800;padding:2px 6px;border-radius:50px">%<?= $pd ?></span></div>
                  <span class="product-price-current" style="color:var(--brand)"><?= fmt_money($pn) ?></span>
                </div>
                <?php else: ?><span class="product-price-current"><?= fmt_money($pp) ?></span><?php endif; else: ?><span class="product-price-free"><i class="fa-solid fa-gift"></i><?= __('shop.free') ?></span><?php endif; ?>
              </div>
              <span class="btn btn-primary btn-sm"><?= __('shop.view') ?></span>
            </div>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

    </div>
  </section>
  <?php endif; ?>

</main>

<!-- Yorum düzenleme kutusu -->
<div id="editCommentModal" class="modal-shade" style="display:none;">
  <div class="modal-box">
    <div class="modal-box-head">
      <span class="modal-box-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.8 2.8 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/></svg><?= __('msg.edit_title') ?></span>
      <button class="cart-close" onclick="closeEditComment()" aria-label="<?= __('modal.close') ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
    </div>
    <div class="modal-box-body">
      <label class="az-com-label" style="margin-bottom:10px;display:block;"><?= __('product.rating_short') ?></label>
      <div style="display:flex;gap:8px;margin-bottom:14px;" id="editStars">
        <?php for ($s = 1; $s <= 5; $s++): ?>
        <button type="button" class="az-star-btn" data-star="<?= $s ?>" onclick="setEditRating(<?= $s ?>)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"/></svg></button>
        <?php endfor; ?>
      </div>
      <input type="hidden" id="editCommentRating" value="0">
      <textarea id="editCommentText" rows="4" placeholder="<?= e(__('product.comment_ph_azure')) ?>" class="form-input" style="width:100%;resize:vertical;"></textarea>
    </div>
    <div class="modal-box-foot">
      <button class="btn btn-ghost" onclick="closeEditComment()"><?= __('topup.cancel') ?></button>
      <button class="btn btn-primary" onclick="saveEditComment()"><?= __('msg.save') ?></button>
    </div>
  </div>
</div>

<script>
window.NX_AZURE_LANG = <?= json_encode(['license_copied'=>__('msg.license_copied'),'copy_failed'=>__('msg.copy_failed'),'review_min'=>__('msg.review_min'),'just_now'=>__('msg.just_now'),'you'=>__('review.you'),'edit'=>__('product.edit'),'delete'=>__('product.delete'),'review_delete_confirm'=>__('msg.review_delete_confirm_azure'),'error_generic'=>__('msg.error_generic')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
(function () {
    'use strict';

    function switchAzTab(tabName, btn) {
        document.querySelectorAll('.az-tab-nav-btn').forEach(function (b) {
            b.classList.remove('active');
            b.style.background = 'transparent';
            b.style.color = 'var(--text-2)';
            b.style.boxShadow = 'none';
        });
        if (!btn) {
            btn = document.querySelector('.az-tab-nav-btn[data-target="' + tabName + '"]');
        }
        if (btn) {
            btn.classList.add('active');
            btn.style.background = 'var(--surface)';
            btn.style.color = 'var(--brand)';
            btn.style.boxShadow = 'var(--shadow-sm)';
        }
        document.querySelectorAll('.az-tab-pane').forEach(function (p) {
            p.style.display = 'none';
        });
        var target = document.getElementById('tab-pane-' + tabName);
        if (target) target.style.display = 'block';
    }
    window.switchAzTab = switchAzTab;

    function scrollToReviews() {
        switchAzTab('reviews');
        var el = document.getElementById('productTabsNav');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    window.scrollToReviews = scrollToReviews;

    function copyLicense(id) {
        var el = document.getElementById(id);
        if (!el) return;
        navigator.clipboard.writeText(el.textContent.trim()).then(function () {
            el.style.color = '#22c55e';
            showToast((window.NX_AZURE_LANG&&window.NX_AZURE_LANG.license_copied)||'Lisans anahtarı kopyalandı!', true);
            setTimeout(function () { el.style.color = ''; }, 1600);
        }).catch(function () { showToast((window.NX_AZURE_LANG&&window.NX_AZURE_LANG.copy_failed)||'Kopyalanamadı.', false); });
    }
    window.copyLicense = copyLicense;

    function starSvg(rating) {
        var h = '';
        for (var i = 1; i <= 5; i++) {
            h += '<span class="' + (i <= rating ? 'on' : '') + '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"/></svg></span>';
        }
        return h;
    }

    /* ---- puan seçici (yeni yorum) ---- */
    function paintStars(val) {
        document.querySelectorAll('#starRating .az-star-btn').forEach(function (b) {
            b.classList.toggle('on', parseInt(b.getAttribute('data-star'), 10) <= val);
        });
    }
    function setRating(val) {
        document.getElementById('ratingValue').value = val;
        paintStars(val);
    }
    function resetRating() { setRating(0); }
    window.setRating = setRating;
    window.resetRating = resetRating;

    /* ---- puan seçici (düzenleme) ---- */
    function setEditRating(val) {
        document.getElementById('editCommentRating').value = val;
        document.querySelectorAll('#editStars .az-star-btn').forEach(function (b) {
            b.classList.toggle('on', parseInt(b.getAttribute('data-star'), 10) <= val);
        });
    }
    window.setEditRating = setEditRating;

    /* ---- yorum ekleme ---- */
    function escapeHtml(s) {
        return String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, function (c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }
    async function submitComment(pid) {
        var btn = document.getElementById('commentSubmitBtn');
        if (btn) btn.disabled = true;
        var ta = document.getElementById('commentText');
        var text = ta.value.trim();
        if (text.length < 3) { showToast((window.NX_AZURE_LANG&&window.NX_AZURE_LANG.review_min)||'Yorum en az 3 karakter olmalı.', false); if (btn) btn.disabled = false; return; }
        var rating = parseInt(document.getElementById('ratingValue').value || '0', 10) || 0;
        var fd = new FormData();
        fd.append('action', 'comment_add');
        fd.append('product_id', pid);
        fd.append('rating', rating);
        fd.append('comment_text', text);
        try {
            var r = await fetch('/action.php', { method: 'POST', body: fd });
            var d = await r.json();
            if (d.ok) {
                var form = document.getElementById('commentFormCard');
                if (form) form.style.display = 'none';
                var notice = document.getElementById('commentOwnedNotice');
                if (notice) notice.style.display = 'block';
                var empty = document.getElementById('commentsEmpty');
                if (empty) empty.remove();
                var list = document.getElementById('listComments');
                if (list) {
                    var div = document.createElement('div');
                    div.className = 'az-comment az-comment--own';
                    div.setAttribute('data-comment-id', d.id);
                    div.setAttribute('data-comment-text', text);
                    div.innerHTML =
                        '<div class="az-comment-head">' +
                        '<span class="az-avatar-ph">' + escapeHtml(d.username ? d.username.charAt(0).toUpperCase() : '?') + '</span>' +
                        '<span class="az-comment-name"></span>' +
                        '<span class="az-chip az-chip--mini" style="color:#2b6eff;background:rgba(43,110,255,.09);">' + ((window.NX_AZURE_LANG&&window.NX_AZURE_LANG.you)||'Sen') + '</span>' +
                        '<span style="margin-left:auto;font-size:12px;color:var(--muted);">' + ((window.NX_AZURE_LANG&&window.NX_AZURE_LANG.just_now)||'Az önce') + '</span>' +
                        '</div>' +
                        (d.rating > 0 ? '<div class="az-st" id="cstars-' + d.id + '" style="margin:6px 0 8px;">' : '') +
                        (d.rating > 0 ? starSvg(d.rating) + '</div>' : '') +
                        '<div class="az-comment-text" id="ctext-' + d.id + '">' + d.html + '</div>' +
                        '<div class="az-comment-actions">' +
                        '<button onclick="openEditComment(' + d.id + ',' + d.rating + ')" class="btn btn-ghost btn-sm">' + (window.NX_AZURE_LANG&&window.NX_AZURE_LANG.edit||'Düzenle') + '</button>' +
                        '<button onclick="deleteComment(' + d.id + ')" class="btn btn-danger btn-sm">' + (window.NX_AZURE_LANG&&window.NX_AZURE_LANG.delete||'Sil') + '</button>' +
                        '</div>';
                    var nameEl = div.querySelector('.az-comment-name');
                    if (nameEl) nameEl.textContent = d.username;
                    list.appendChild(div);
                }
                ta.value = '';
                resetRating();
            } else {
                showToast(d.msg, false);
            }
        } catch (e) { showToast((window.NX_AZURE_LANG&&window.NX_AZURE_LANG.error_generic)||'Bir hata oluştu.', false); }
        if (btn) btn.disabled = false;
    }
    window.submitComment = submitComment;

    /* ---- yorum düzenleme ---- */
    var _editId = 0;
    function openEditComment(id, rating) {
        _editId = id;
        var card = document.querySelector('[data-comment-id="' + id + '"]');
        var text = card ? (card.getAttribute('data-comment-text') || '') : '';
        document.getElementById('editCommentText').value = text;
        document.getElementById('editCommentRating').value = rating;
        setEditRating(rating);
        var m = document.getElementById('editCommentModal');
        m.style.display = 'flex';
        requestAnimationFrame(function () { m.classList.add('show'); });
    }
    function closeEditComment() {
        var m = document.getElementById('editCommentModal');
        m.classList.remove('show');
        setTimeout(function () { m.style.display = 'none'; }, 200);
    }
    window.openEditComment = openEditComment;
    window.closeEditComment = closeEditComment;

    async function saveEditComment() {
        var text = document.getElementById('editCommentText').value.trim();
        if (text.length < 3) { showToast((window.NX_AZURE_LANG&&window.NX_AZURE_LANG.review_min)||'Yorum en az 3 karakter olmalı.', false); return; }
        var rating = parseInt(document.getElementById('editCommentRating').value || '0', 10) || 0;
        var fd = new FormData();
        fd.append('action', 'comment_update');
        fd.append('comment_id', _editId);
        fd.append('rating', rating);
        fd.append('comment_text', text);
        try {
            var r = await fetch('/action.php', { method: 'POST', body: fd });
            var d = await r.json();
            if (d.ok) {
                var card = document.querySelector('[data-comment-id="' + _editId + '"]');
                if (card) {
                    card.setAttribute('data-comment-text', text);
                    var t = document.getElementById('ctext-' + _editId);
                    if (t) t.innerHTML = d.html;
                    var s = document.getElementById('cstars-' + _editId);
                    if (s) {
                        s.innerHTML = starSvg(d.rating);
                        s.style.display = d.rating > 0 ? 'block' : 'none';
                    }
                }
                showToast(d.msg, true);
                closeEditComment();
            } else {
                showToast(d.msg, false);
            }
        } catch (e) { showToast((window.NX_AZURE_LANG&&window.NX_AZURE_LANG.error_generic)||'Bir hata oluştu.', false); }
    }
    window.saveEditComment = saveEditComment;

    /* ---- yorum silme ---- */
    async function deleteComment(id) {
        if (!confirm((window.NX_AZURE_LANG&&window.NX_AZURE_LANG.review_delete_confirm)||'Değerlendirmen silinsin mi?')) return;
        var fd = new FormData();
        fd.append('action', 'comment_delete');
        fd.append('comment_id', id);
        try {
            var r = await fetch('/action.php', { method: 'POST', body: fd });
            var d = await r.json();
            showToast(d.msg, d.ok);
            if (d.ok) {
                var card = document.querySelector('[data-comment-id="' + id + '"]');
                if (card) card.remove();
                if (!document.querySelector('#listComments .az-comment--own')) {
                    var form = document.getElementById('commentFormCard');
                    var notice = document.getElementById('commentOwnedNotice');
                    if (form) form.style.display = 'flex';
                    if (notice) notice.style.display = 'none';
                }
            }
        } catch (e) { showToast((window.NX_AZURE_LANG&&window.NX_AZURE_LANG.error_generic)||'Bir hata oluştu.', false); }
    }
    window.deleteComment = deleteComment;
})();
</script>

<!-- Hemen Satın Al onay kutusu -->
<?php if ($activeProduct && $me && !in_array((int)$activeProduct['id'], array_map('intval', $ownedIds)) && !($activeProduct['stock_type'] === 'limited' && (int)$activeProduct['stock'] < 1)): ?>
<div id="buyNowModal" class="modal-shade" style="display:none;">
  <div class="modal-box">
    <div class="modal-box-head">
      <span class="modal-box-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 4 14h6l-1 8 9-12h-6l1-8z"/></svg><?= __('product.buy_now') ?></span>
      <button class="cart-close" onclick="closeBuyNowModal()" aria-label="<?= __('modal.close') ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
    </div>
    <div class="modal-box-body">
      <div style="display:flex;align-items:center;gap:14px;">
        <?php if (!empty($activeProduct['image_url'])): ?>
         <img src="<?= e($activeProduct['image_url']) ?>" width="64" height="64" alt="<?= e($activeProduct['name']) ?>" style="width:64px;height:64px;object-fit:cover;border-radius:12px;border:1px solid var(--line);">
        <?php endif; ?>
        <div style="min-width:0;">
          <div style="font-size:13px;font-weight:800;color:var(--text);line-height:1.35;"><?= e($activeProduct['name']) ?></div>
          <?php $bp=(float)$activeProduct['price']; $bd=(int)($activeProduct['discount_percent']??0); $bn=$bd>0&&$bp>0?$bp*(1-min(90,max(0,$bd))/100):$bp; ?>
          <?php if ($bn > 0): ?>
          <div style="font-family:var(--font-title);font-size:20px;font-weight:800;color:var(--brand);margin-top:4px;"><?= fmt_money($bn) ?></div>
          <?php else: ?>
          <div style="font-family:var(--font-title);font-size:20px;font-weight:800;color:var(--ok);margin-top:4px;"><?= __('shop.free') ?></div>
          <?php endif; ?>
        </div>
      </div>
      <p class="modal-hint" style="border-top:1px solid var(--line);padding-top:14px;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="8"/><path d="M12 8v4m0 4h.01"/></svg><?= __('buy.confirm_text') ?></p>
      <?php $bnReady = function_exists('gateway_ready_list') ? gateway_ready_list($db) : []; ?>
      <?php $bnPlanLocked = function_exists('plan_payments_allowed') && !plan_payments_allowed($db); ?>
      <?php if ($bnPlanLocked): ?>
      <div style="margin-top:14px;font-size:12px;font-weight:700;border-radius:10px;padding:10px 12px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#fca5a5;">
        <?= e(__('plan.payments_paused')) ?>
      </div>
      <?php endif; ?>
      <?php if (count($bnReady) > 0 && !$bnPlanLocked): ?>
      <div id="buyNowMethods" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;">
        <button type="button" data-bn-method="balance" onclick="buyNowPick('balance', this)" class="bn-method-btn is-active" style="display:inline-flex;align-items:center;gap:6px;background:var(--surface);border:1px solid var(--brand);color:var(--brand);border-radius:10px;padding:8px 14px;font-size:13px;font-weight:800;cursor:pointer;font-family:inherit;"><i class="fa-solid fa-wallet"></i> <?= e(__('cart.pay_balance_short')) ?></button>
        <?php foreach ($bnReady as $bnM): $bnLabel = gateway_label_for($bnM); $bnLogo = gateway_logo_url($bnM); ?>
        <button type="button" data-bn-method="<?= e($bnM) ?>" onclick="buyNowPick('<?= e($bnM) ?>', this)" class="bn-method-btn" style="display:inline-flex;align-items:center;gap:6px;background:var(--surface);border:1px solid var(--line);color:var(--text-2);border-radius:10px;padding:8px 14px;font-size:13px;font-weight:800;cursor:pointer;font-family:inherit;"><?php if ($bnLogo !== ''): ?><img src="<?= e($bnLogo) ?>" alt="" width="48" height="32" style="height:18px;width:auto;object-fit:contain;"><?php endif; ?><?= e($bnLabel) ?></button>
        <?php endforeach; ?>
      </div>
      
      <?php endif; ?>
    </div>
    <div class="modal-box-foot">
      <button class="btn btn-ghost" onclick="closeBuyNowModal()"><?= __('buy.cancel') ?></button>
      <button class="btn btn-primary" id="buyNowConfirmBtn" onclick="confirmBuyNow()"><?= __('buy.confirm') ?></button>
    </div>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>