<?php
if (isset($_GET['product']) || ($_GET['tab'] ?? '') === 'purchases') {
    include __DIR__ . '/product.php';
    return;
}
$pageTitle  = __('nav.shop');
$activePage = 'products';
$seoKey     = 'products';

$db       = nexus_db();
$products = [];
$cats     = [];

if ($db) {
    $cat = trim($_GET['cat'] ?? '');
    $q   = trim($_GET['q']   ?? '');

    $where  = ["is_active = 1", "is_hidden = 0", "status = 'active'"];
    $params = [];

    if ($cat) { $where[] = 'category = ?'; $params[] = $cat; }
    if ($q)   { $where[] = '(name LIKE ? OR short_description LIKE ? OR description LIKE ?)'; $esq = '%'.addcslashes($q,'%_').'%'; $params[] = $esq; $params[] = $esq; $params[] = $esq; }

    $stmt = $db->prepare('SELECT * FROM products WHERE ' . implode(' AND ', $where) . ' ORDER BY created_at DESC');
    $stmt->execute($params);
    $products = $stmt->fetchAll();

    $cats = $db->query("SELECT name,slug,icon FROM categories ORDER BY sort_order ASC, name ASC")->fetchAll();
}

$flashType = '';
$flashText = '';
$flashRaw = trim((string)($_GET['flash'] ?? ''));
if ($flashRaw !== '' && strpos($flashRaw, ':') !== false) {
    $flashParts = explode(':', urldecode($flashRaw), 2);
    $flashType = $flashParts[0];
    $flashText = $flashParts[1] ?? '';
}
include __DIR__ . '/includes/header.php';
?>
<main>
  <section class="section">
    <div class="container">
      <?php if ($flashText !== ''): ?>
      <?php if ($flashType === 'success'): ?>
      <div style="margin-bottom:20px;padding:13px 16px;border-radius:12px;font-size:14px;font-weight:600;display:flex;align-items:center;gap:10px;background:#e8f7ee;border:1px solid #bfe6cd;color:#15803d;">
        <i class="fa-solid fa-circle-check"></i>
        <span><?= e($flashText) ?></span>
      </div>
      <?php else: ?>
      <div style="margin-bottom:20px;padding:13px 16px;border-radius:12px;font-size:14px;font-weight:600;display:flex;align-items:center;gap:10px;background:#fdecec;border:1px solid #f5c2c2;color:#c0392b;">
        <i class="fa-solid fa-circle-xmark"></i>
        <span><?= e($flashText) ?></span>
      </div>
      <?php endif; ?>
      <?php endif; ?>

      <div class="shop-head">
        <div>
          <span class="section-eyebrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M12 24V15"/></svg><?= __('nav.shop') ?></span>
          <h1 class="section-title"><?= __('shop.products_title') ?></h1>
          <p class="section-sub"><?= __('shop.listing', ['n' => count($products)]) ?></p>
        </div>
        <form method="GET" class="shop-search">
          <?php if ($cat): ?><input type="hidden" name="cat" value="<?= e($cat) ?>"><?php endif; ?>
          <div class="shop-search-box">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
            <input type="text" name="q" value="<?= e($q) ?>" placeholder="<?= e(__('shop.search_ph')) ?>" class="form-input" >
          </div>
          <button type="submit" class="btn btn-primary btn-sm"><?= __('shop.search_btn') ?></button>
        </form>
      </div>

      <div class="shop-layout">

        <aside class="shop-side">
          <div class="side-card">
            <nav class="category-nav">
              <span class="category-title"><?= __('shop.categories') ?></span>
              <a href="/products<?= $q ? '?q='.urlencode($q) : '' ?>" class="category-link<?= !$cat ? ' is-active' : '' ?>"><?= __('shop.all') ?></a>
              <?php foreach ($cats as $c): ?>
              <a href="/products?cat=<?= urlencode($c['name']) ?><?= $q ? '&amp;q='.urlencode($q) : '' ?>" class="category-link<?= $cat === $c['name'] ? ' is-active' : '' ?>"><?= e($c['name']) ?></a>
              <?php endforeach; ?>
            </nav>
          </div>
        </aside>

        <div class="shop-content">

          <?php if (empty($products)): ?>
          <div class="products-grid">
            <div class="products-empty">
              <span class="empty-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M12 24V15"/></svg></span>
              <h3><?= __('shop.not_found') ?></h3>
              <p><?= __('shop.no_match') ?></p>
              <a href="/products" class="btn btn-ghost btn-sm"><?= __('shop.show_all') ?></a>
            </div>
          </div>
          <?php else: ?>
          <div class="products-grid">
            <?php foreach ($products as $product):
                $soldOut = (($product['stock_type'] ?? 'unlimited') === 'limited') && ((int)($product['stock'] ?? 0)) < 1;
                $pp = (float)$product['price'];
                $pd = (int)($product['discount_percent'] ?? 0);
                $pn = $pd > 0 && $pp > 0 ? $pp * (1 - $pd / 100) : $pp;
            ?>
            <?php if (function_exists('do_action')) do_action('product_card_before', $product); ?>
            <article class="product-card<?= $soldOut ? ' is-soldout' : '' ?>">
              <a class="product-card-link" href="/products?product=<?= (int)$product['id'] ?>" aria-label="<?= e($product['name']) ?>"></a>
              <?php if ($soldOut): ?>
              <span class="product-badge product-badge--soldout"><?= __('product.soldout') ?></span>
              <?php elseif ($pd > 0): ?>
              <span class="product-badge" style="background:#ff4757;color:#fff;font-weight:800;"><?= __('product.discount_pct', ['n' => $pd]) ?></span>
              <?php endif; ?>
              <div class="product-media">
                <?php if (!empty($product['image_url'])): ?>
                <img src="<?= e($product['image_url']) ?>" width="360" height="225" alt="<?= e($product['name'] ?? '') ?>">
                <?php else: ?>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><rect x="4" y="3" width="16" height="14" rx="3"/><path d="M9 7h6"/></svg>
                <?php endif; ?>
              </div>
              <div class="product-body">
                <span class="product-cat"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"/><path d="M3 8h18M8 3v5"/></svg><?= e($product['category'] ?: 'Genel') ?></span>
                <h3 class="product-title"><?= e($product['name']) ?></h3>
                <p class="product-desc"><?= htmlspecialchars(truncate_text($product['short_description'] ?? $product['description'] ?? '', 100)) ?></p>
                <div class="product-foot">
                  <div class="product-price">
                    <?php if ($pp > 0): ?>
                      <?php if ($pd > 0): ?>
                      <div style="display:flex;flex-direction:column;align-items:flex-start;gap:2px">
                        <div style="display:flex;align-items:center;gap:6px"><span style="font-size:12px;color:var(--muted);text-decoration:line-through"><?= fmt_money($pp) ?></span><span style="background:#ff4757;color:#fff;font-size:10px;font-weight:800;padding:2px 6px;border-radius:50px">%<?= $pd ?></span></div>
                        <span class="product-price-current" style="color:var(--brand)"><?= fmt_money($pn) ?></span>
                      </div>
                      <?php else: ?>
                      <span class="product-price-current"><?= fmt_money($pp) ?></span>
                      <?php endif; ?>
                    <?php else: ?>
                    <span class="product-price-free"><i class="fa-solid fa-gift"></i> <?= __('shop.free') ?></span>
                    <?php endif; ?>
                  </div>
                  <span class="btn btn-primary btn-sm"><?= __('shop.view') ?></span>
                </div>
              </div>
            </article>
            <?php if (function_exists('do_action')) do_action('product_card_after', $product); ?>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>

        </div>

      </div>

    </div>
  </section>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>