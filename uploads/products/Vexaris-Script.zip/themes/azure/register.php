<?php
auth_redirect_if_logged_in('/');

$pageTitle  = __('nav.register');
$activePage = 'register';
$seoKey     = 'register';
$error      = '';

csrf_verify();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass     = $_POST['password']         ?? '';
    $passConf = $_POST['password_confirm'] ?? '';

    if ($pass !== $passConf) {
        $error = __('auth.passwords_mismatch');
    } elseif (!verify_captcha()) {
        $error = __('auth.captcha_fail');
    } else {
        $result = auth_register(
            $_POST['username'] ?? '',
            $_POST['email']    ?? '',
            $pass
        );
        if ($result['ok']) {
            $loginRes = auth_login($_POST['username'], $pass);
            if ($loginRes['ok']) {
                header('Location: /', true, 302);
                exit;
            }
            header('Location: /login?flash=' . urlencode('error:' . $loginRes['msg']), true, 302);
            exit;
        }
        $error = $result['msg'];
    }
}

$intSettings = [];
try {
    $intDb = nexus_db();
    $intSt = $intDb->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'");
    while ($intR = $intSt->fetch()) $intSettings[$intR['key']] = $intR['value'];
} catch (\PDOException $e) { error_log('[NS] register int: '.$e->getMessage()); }

$googleAuth   = ($intSettings['int_google_auth_enabled'] ?? '0')   === '1' && !empty($intSettings['int_google_auth_client_id']);
$discordAuth  = ($intSettings['int_discord_auth_enabled'] ?? '0')  === '1' && !empty($intSettings['int_discord_auth_client_id']);
$microsoftAuth= ($intSettings['int_microsoft_auth_enabled'] ?? '0')=== '1' && !empty($intSettings['int_microsoft_auth_client_id']);
$githubAuth   = ($intSettings['int_github_auth_enabled'] ?? '0')   === '1' && !empty($intSettings['int_github_auth_client_id']);
$cfCaptcha    = ($intSettings['int_cf_captcha_enabled'] ?? '0')    === '1' && !empty($intSettings['int_cf_captcha_site_key']);
$recaptcha    = ($intSettings['int_recaptcha_enabled'] ?? '0')     === '1' && !empty($intSettings['int_recaptcha_site_key']);

include __DIR__ . '/includes/header.php';
?>
<main class="auth-shell">
  <div class="auth-card">

    <div class="auth-card-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg>
    </div>

    <h1 class="auth-card-title"><?= __('auth.create_title') ?></h1>
    <p class="auth-card-subtitle"><?= __('auth.create_sub') ?></p>

    <?php if ($error): ?>
    <div class="auth-alert auth-alert--error">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v6m0 4h.01"/></svg>
      <?= e($error) ?>
    </div>
    <?php endif; ?>

    <form method="POST" action="/register" autocomplete="on" novalidate>
    <?= csrf_field() ?>

      <div class="form-group">
        <label for="username" class="form-label"><?= __('auth.username') ?></label>
        <div class="form-input-icon-wrap">
          <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/></svg>
          <input type="text" id="username" name="username" class="form-input"
              placeholder="kullaniciadi" autocomplete="username" required minlength="3" maxlength="32"
              value="<?= e($_POST['username'] ?? '') ?>">
        </div>
        <p class="form-hint">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/></svg>
          3–32 karakter, harf, rakam ve _ izinli.
        </p>
      </div>

      <div class="form-group">
        <label for="email" class="form-label"><?= __('auth.email_address') ?></label>
        <div class="form-input-icon-wrap">
          <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3 7 9 6 9-6"/></svg>
          <input type="email" id="email" name="email" class="form-input"
              placeholder="kullanici@ornek.com" autocomplete="email" required maxlength="255"
              value="<?= e($_POST['email'] ?? '') ?>">
        </div>
      </div>

      <div class="form-group">
        <label for="password" class="form-label"><?= __('auth.password') ?></label>
        <div class="form-input-icon-wrap">
          <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
          <input type="password" id="password" name="password" class="form-input"
              placeholder="••••••••" autocomplete="new-password" required minlength="8" maxlength="128">
        </div>
        <p class="form-hint">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 6v5c0 5 3.4 8 8 10 4.6-2 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/></svg>
          En az 8 karakter.
        </p>
      </div>

      <div class="form-group">
        <label for="password_confirm" class="form-label"><?= __('auth.password_repeat') ?></label>
        <div class="form-input-icon-wrap">
          <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
          <input type="password" id="password_confirm" name="password_confirm" class="form-input"
              placeholder="••••••••" autocomplete="new-password" required maxlength="128">
        </div>
      </div>

      <?php if ($cfCaptcha): ?>
      <div class="form-group">
        <div class="cf-turnstile" data-sitekey="<?= e($intSettings['int_cf_captcha_site_key']) ?>" data-theme="light" style="margin-top:4px;"></div>
        <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
      </div>
      <?php elseif ($recaptcha): ?>
      <div class="form-group">
        <div class="g-recaptcha" data-sitekey="<?= e($intSettings['int_recaptcha_site_key']) ?>" data-theme="light" style="margin-top:4px;"></div>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
      </div>
      <?php endif; ?>

      <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top:22px;">
        <?= __('auth.signup_btn') ?>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
      </button>

    </form>

    <?php if ($googleAuth || $discordAuth || $microsoftAuth || $githubAuth): ?>
    <div class="auth-social">
      <div class="auth-social-label">veya</div>
      <div class="auth-social-btns">
        <?php if ($googleAuth): ?>
        <a href="/api/auth/google_auth" class="btn btn-ghost auth-social-btn">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.35 12.2c0-.7-.07-1.4-.19-2H12v3.8h5.24a4.8 4.8 0 0 1-2.1 3.15v2.6h3.4c2-1.85 3-4.57 3-7.55z"/><path d="M12 22c2.86 0 5.26-.95 7-2.58l-3.4-2.6c-.94.63-2.15 1-3.6 1-2.77 0-5.11-1.9-5.95-4.45H-2.6v2.68A10 10 0 0 0 12 22z"/><path d="M6.05 13.37A6 6 0 0 1 6.05 12V9.32H-2.6a10 10 0 0 0 0 8.36z"/><path d="M12 6c1.56 0 2.96.54 4.06 1.6l3.04-3.04A10 10 0 0 0-2.6 9.34l3.18 2.5C5.94 7.9 8.93 6 12 6z"/></svg>
          <?= __('auth.oauth_signup', ['brand' => 'Google']) ?>
        </a>
        <?php endif; ?>
        <?php if ($discordAuth): ?>
        <a href="/api/auth/discord_auth" class="btn btn-ghost auth-social-btn">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.3 4.4A19.8 19.8 0 0 0 15.9 3l-.24.48c1.3.4 2.4.9 3.44 1.6a18 18 0 0 0-12.2 0c1.04-.7 2.14-1.2 3.4-1.6L9.6 3a19.8 19.8 0 0 0-4.4 1.4C2.5 8.5 1.7 11.9 2.1 16.2c1.6 1.2 3.9 2.3 4 2.3l1.6-2.4c-.8-.3-1.6-.8-2.3-1.4l.6-.4c2 1.8 5.2 1.9 5.2 1.9h.8s3.2-.1 5.2-1.9l.6.4c-.7.6-1.5 1.1-2.3 1.4l1.6 2.4s2.4-1.1 4-2.3c.4-3.1-.5-6.5-1.7-11.8zm-9.2 9.3c-1.1 0-1.9-1-1.9-2.2 0-1.2.8-2.2 1.9-2.2s1.9 1 1.9 2.2c0 1.2-.8 2.2-1.9 2.2zm5.5 0c-1.1 0-1.9-1-1.9-2.2 0-1.2.8-2.2 1.9-2.2s1.9 1 1.9 2.2c0 1.2-.8 2.2-1.9 2.2z"/></svg>
          <?= __('auth.oauth_signup', ['brand' => 'Discord']) ?>
        </a>
        <?php endif; ?>
        <?php if ($microsoftAuth): ?>
        <a href="/api/auth/microsoft_auth" class="btn btn-ghost auth-social-btn">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M2 3h9.5v9.5H2zM12.5 3H22v9.5h-9.5zM2 12.5h9.5V22H2zM12.5 12.5H22V22h-9.5z"/></svg>
          <?= __('auth.oauth_signup', ['brand' => 'Microsoft']) ?>
        </a>
        <?php endif; ?>
        <?php if ($githubAuth): ?>
        <a href="/api/auth/github_auth" class="btn btn-ghost auth-social-btn">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5A11.5 11.5 0 0 0 .5 12c0 5.1 3.3 9.4 7.9 10.9.6.1.9-.3.9-.6v-2.2c-3.2.7-3.9-1.4-3.9-1.4-.5-1.2-1.3-1.6-1.3-1.6-1-.8.1-.8.1-.8 1.2.1 1.8 1.2 1.8 1.2 1 1.8 2.7 1.3 3.4 1 .1-.8.4-1.3.7-1.6-2.5-.3-5-1.3-5-5.7 0-1.3.5-2.3 1.2-3.1-.1-.3-.5-1.5.1-3.1 0 0 1-.3 3.2 1.2a11 11 0 0 1 5.8 0C17 4.8 18 5.1 18 5.1c.6 1.6.2 2.8.1 3.1.8.8 1.2 1.8 1.2 3.1 0 4.4-2.7 5.4-5.3 5.7.4.4.8 1.1.8 2.2v3.2c0 .3.2.7.9.6A11.5 11.5 0 0 0 23.5 12 11.5 11.5 0 0 0 12 .5z"/></svg>
          <?= __('auth.oauth_signup', ['brand' => 'GitHub']) ?>
        </a>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>

    <p class="auth-terms">
      <?= __('auth.signup_a') ?> <a href="/legal?p=terms-of-service"><?= __('legal.terms') ?></a><?= __('auth.signup_b') ?> <a href="/legal?p=privacy-policy"><?= __('legal.privacy') ?></a><?= __('auth.signup_c') ?>
    </p>

    <p class="auth-links">
      <?= __('auth.has_account') ?> <a href="/login"><?= __('auth.do_login') ?></a>
    </p>

  </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>