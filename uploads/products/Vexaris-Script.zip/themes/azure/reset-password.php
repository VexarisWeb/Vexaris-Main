<?php
auth_redirect_if_logged_in('/');

$pageTitle  = __('auth.reset_title');
$activePage = 'login';
$seoKey     = 'login';
$token      = trim($_GET['token'] ?? '');
$msg        = '';
$error      = '';

if ($token === '') {
    $error = __('auth.reset_invalid');
}
csrf_verify();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass     = $_POST['password']         ?? '';
    $passConf = $_POST['password_confirm'] ?? '';
    if (!verify_captcha()) {
        $error = __('auth.captcha_fail');
    } elseif ($pass !== $passConf) {
        $error = __('auth.password_mismatch');
    } else {
        $result = auth_reset_password($token, $pass);
        if ($result['ok']) {
            $msg = $result['msg'];
        } else {
            $error = $result['msg'];
        }
    }
}

$intSettings = [];
try {
    $intDb = nexus_db();
    $intSt = $intDb->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'");
    while ($intR = $intSt->fetch()) $intSettings[$intR['key']] = $intR['value'];
} catch (\PDOException $e) { error_log('[NS] reset int: '.$e->getMessage()); }
$cfCaptcha    = ($intSettings['int_cf_captcha_enabled'] ?? '0')    === '1' && !empty($intSettings['int_cf_captcha_site_key']);
$recaptcha    = ($intSettings['int_recaptcha_enabled'] ?? '0')     === '1' && !empty($intSettings['int_recaptcha_site_key']);

include __DIR__ . '/includes/header.php';
?>
<main class="auth-shell">
  <div class="auth-card">

    <div class="auth-card-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
    </div>

    <h1 class="auth-card-title"><?= __('auth.reset_h1') ?></h1>
    <p class="auth-card-subtitle"><?= __('auth.reset_sub') ?></p>

    <?php if ($error): ?>
    <div class="auth-alert auth-alert--error">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v6m0 4h.01"/></svg>
      <?= e($error) ?>
    </div>
    <?php endif; ?>

    <?php if ($msg): ?>
    <div class="auth-alert auth-alert--success">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>
      <?= e($msg) ?>
    </div>
    <p class="auth-links" style="margin-top:16px;">
      <a href="/login"><?= __('auth.do_login') ?></a>
    </p>
    <?php else: ?>

    <form method="POST" action="/reset-password?token=<?= e($token) ?>" autocomplete="on" novalidate>
    <?= csrf_field() ?>

      <div class="form-group">
        <label for="password" class="form-label"><?= __('auth.reset_new') ?></label>
        <div class="form-input-icon-wrap">
          <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
          <input type="password" id="password" name="password" class="form-input"
              placeholder="••••••••" autocomplete="new-password" required minlength="8" maxlength="128">
        </div>
        <p class="form-hint"><?= __('auth.reset_hint') ?></p>
      </div>

      <div class="form-group">
        <label for="password_confirm" class="form-label"><?= __('auth.reset_new2') ?></label>
        <div class="form-input-icon-wrap">
          <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
          <input type="password" id="password_confirm" name="password_confirm" class="form-input"
              placeholder="••••••••" autocomplete="new-password" required maxlength="128">
        </div>
      </div>

      <?php if ($cfCaptcha): ?>
        <div class="cf-turnstile" data-sitekey="<?= e($intSettings['int_cf_captcha_site_key']) ?>" data-theme="light" style="margin-top:4px;"></div>
        <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
      <?php elseif ($recaptcha): ?>
        <div class="g-recaptcha" data-sitekey="<?= e($intSettings['int_recaptcha_site_key']) ?>" data-theme="light" style="margin-top:4px;"></div>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
      <?php endif; ?>

      <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top:22px;">
        <?= __('auth.reset_btn') ?>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
      </button>

    </form>

    <?php endif; ?>

  </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>