<?php
$pageTitle  = 'Destek';
$activePage = 'support';
$seoKey     = 'support';

$db         = nexus_db();
$isLoggedIn = auth_check();
$me         = $isLoggedIn ? auth_user() : null;

$tid = isset($_GET['id']) ? (int)$_GET['id'] : 0;

require_once ROOT_PATH . '/core/support-page.php';
[$flashType, $flashText] = support_page_flash();
$nxSupport = ($isLoggedIn && $db) ? support_page_data($db, (int)$me['id'], $tid) : support_page_defaults();
$activeTicket  = $nxSupport['activeTicket'];
$ticketReplies = $nxSupport['ticketReplies'];
$myTickets     = $nxSupport['myTickets'];
$hasOpen       = $nxSupport['hasOpen'];
$categories    = $nxSupport['categories'];
$nxIntSettings = [];
try { $nxIntDb = nexus_db(); $nxIntSt = $nxIntDb->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'"); while ($nxIntR = $nxIntSt->fetch()) $nxIntSettings[$nxIntR['key']] = $nxIntR['value']; } catch (\Throwable $e) {}
$nxCfCaptcha = ($nxIntSettings['int_cf_captcha_enabled'] ?? '0') === '1' && !empty($nxIntSettings['int_cf_captcha_site_key']);
$nxRecaptcha = ($nxIntSettings['int_recaptcha_enabled'] ?? '0') === '1' && !empty($nxIntSettings['int_recaptcha_site_key']);
$statusMap  = [
    'open'    => ['badge-open',     __('ticket.open')],
    'replied' => ['badge-answered', __('ticket.replied')],
    'closed'  => ['badge-closed',   __('ticket.closed')],
];

include __DIR__ . '/includes/header.php';
?>
<main>
  <section class="section">
    <div class="container">

      <div class="section-head reveal">
        <span class="section-eyebrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13a8 8 0 0 1 16 0"/><rect x="2.5" y="13" width="5" height="6" rx="2"/><rect x="16.5" y="13" width="5" height="6" rx="2"/><path d="M20 19a3 3 0 0 1-3 3h-4"/></svg>Destek</span>
        <h1 class="section-title">Destek Merkezi</h1>
        <p class="section-sub"><?= __('support.hero_sub') ?></p>
      </div>

      <?php if (!$isLoggedIn): ?>
      <div class="panel-card" style="padding:36px;text-align:center;">
        <div class="auth-card-icon" style="background:linear-gradient(135deg,var(--brand),var(--brand-2));">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13a8 8 0 0 1 16 0"/><rect x="2.5" y="13" width="5" height="6" rx="2"/><rect x="16.5" y="13" width="5" height="6" rx="2"/></svg>
        </div>
        <h2 style="font-family:var(--font-title);font-size:22px;font-weight:800;margin-bottom:8px;"><?= __('support.guest_title') ?></h2>
        <p style="font-size:14px;color:var(--muted);max-width:420px;margin:0 auto 24px;line-height:1.7;"><?= __('support.guest_text') ?></p>
        <a href="/login" class="btn btn-primary btn-lg"><?= __('nav.login') ?></a>
      </div>

      <?php else: ?>

      <div class="ticket-shell">

        <aside class="ticket-sidebar" id="nxTicketSidebar">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 16px 12px;border-bottom:1px solid var(--line);flex-shrink:0;gap:8px;">
            <span style="font-size:14px;font-weight:800;"><?= __('support.my_tickets') ?></span>
            <button onclick="openSupportTicket()" class="btn btn-primary btn-sm"<?= $hasOpen ? ' disabled title="' . e(__('support.open_exists')) . '" style="opacity:.4;pointer-events:none;filter:grayscale(.6);"' : '' ?>>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14m-7-7h14"/></svg>
              Yeni
            </button>
          </div>
          <div class="ticket-list">
            <?php if (empty($myTickets)): ?>
            <p style="text-align:center;color:var(--muted);font-size:13px;padding:24px 0;"><?= __('support.no_tickets_azure') ?></p>
            <?php else: ?>
            <?php foreach ($myTickets as $t): ?>
            <?php [$sb,$sl] = $statusMap[$t['status']] ?? ['badge-closed','?']; ?>
            <a href="/support?id=<?= $t['id'] ?>" class="ticket-item <?= $tid===$t['id']?'active':'' ?>">
              <div class="ticket-item-title"><?= e($t['title']) ?></div>
              <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;margin-top:3px;">
                <span style="font-size:11px;color:var(--muted);"><?= e($t['category']??'Genel') ?></span>
                <span class="badge <?= $sb ?>"><?= $sl ?></span>
              </div>
              <div style="font-size:11px;color:var(--dim);"><?= date('d.m.Y H:i', strtotime($t['created_at'])) ?></div>
            </a>
            <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </aside>

        <div class="ticket-main">
          <?php if (!$tid || !$activeTicket): ?>
          <?php if ($flashType): ?>
          <div class="auth-alert <?= $flashType==='success'?'auth-alert--ok':'auth-alert--error' ?>" style="margin:0 auto 0;padding:10px 14px;max-width:520px;width:100%;text-align:left;">
            <svg style="width:15px;height:15px;flex-shrink:0;vertical-align:-2px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><?= $flashType==='success' ? '<path d="m5 13 4 4 10-11"/>' : '<path d="M18 6 6 18M6 6l12 12"/>' ?></svg>
            <?= e($flashText) ?>
          </div>
          <?php endif; ?>
          <div class="nx-mobile-bar">
            <button type="button" class="nx-drawer-btn" onclick="nxToggleTickets()" title="<?= e(__('support.my_tickets')) ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
            <button onclick="openSupportTicket()" class="btn btn-primary btn-sm" style="flex:1;justify-content:center;"<?= $hasOpen ? ' disabled title="' . e(__('support.open_exists')) . '" style="flex:1;justify-content:center;opacity:.4;pointer-events:none;filter:grayscale(.6);"' : '' ?>>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" style="width:13px;height:13px;"><path d="M12 5v14m-7-7h14"/></svg>
              <?= __('support.new') ?>
            </button>
          </div>
          <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:var(--muted);padding:40px;text-align:center;">
            <svg style="width:52px;height:52px;color:var(--dim);" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 1-9 9c-1.4 0-2.7-.3-3.9-.9L3 21l.9-5.1A9 9 0 1 1 21 12z"/></svg>
            <p style="font-size:15px;font-weight:700;"><?= __('support.pick') ?></p>
            <p style="font-size:13px;max-width:320px;line-height:1.6;"><?= __('support.pick_hint') ?></p>
          </div>
          <?php else: ?>

          <div class="ticket-detail-head">
            <?php [$sb,$sl] = $statusMap[$activeTicket['status']] ?? ['badge-closed','?']; ?>
            <div class="ticket-head-az" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
              <button type="button" class="nx-drawer-btn" onclick="nxToggleTickets()" title="<?= e(__('support.my_tickets')) ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
              <a href="/support" style="color:var(--muted);font-size:14px;"><svg style="width:15px;height:15px;vertical-align:-2px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 18l-6-6 6-6"/></svg></a>
              <h2 style="font-size:15px;font-weight:800;"><?= e($activeTicket['title']) ?></h2>
              <span class="badge <?= $sb ?>"><?= $sl ?></span>
            </div>
            <div style="font-size:12px;color:var(--muted);margin-top:6px;">
              <span style="background:var(--bg-soft);padding:2px 9px;border-radius:6px;margin-right:8px;"><?= e($activeTicket['category']??'Genel') ?></span>
              #<?= $activeTicket['id'] ?> · <?= date('d.m.Y H:i', strtotime($activeTicket['created_at'])) ?>
            </div>
            <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap;">
              <?php if ($activeTicket['status'] !== 'closed'): ?>
              <form method="POST" action="/action.php" onsubmit="return confirm(<?= json_encode(__('support.confirm_close')) ?>);">
                <input type="hidden" name="action" value="ticket_close">
                <input type="hidden" name="ticket_id" value="<?= $activeTicket['id'] ?>">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-ghost btn-sm"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="width:13px;height:13px;"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg> <?= __('support.close') ?></button>
              </form>
              <?php endif; ?>
              <button onclick="openSupportTicket()" class="btn btn-primary btn-sm"<?= $hasOpen ? ' disabled title="' . e(__('support.open_exists')) . '" style="opacity:.4;pointer-events:none;filter:grayscale(.6);"' : '' ?>><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" style="width:13px;height:13px;"><path d="M12 5v14m-7-7h14"/></svg> <?= __('support.new_ticket') ?></button>
            </div>
            <?php if ($flashType): ?>
            <div class="auth-alert <?= $flashType==='success'?'auth-alert--ok':'auth-alert--error' ?>" style="margin-top:12px;padding:10px 14px;">
              <svg style="width:15px;height:15px;flex-shrink:0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><?= $flashType==='success' ? '<path d="m5 13 4 4 10-11"/>' : '<path d="M18 6 6 18M6 6l12 12"/>' ?></svg>
              <?= e($flashText) ?>
            </div>
            <?php endif; ?>
          </div>

          <div class="ticket-messages" id="msgBox">
            <?php $initialSeen = false; foreach ($ticketReplies as $sr) { if ((int)$sr['is_admin'] === 1) { $initialSeen = true; break; } } ?>
            <?php $lastOwnRid = 0; foreach ($ticketReplies as $lr) { if (!(int)$lr['is_admin']) $lastOwnRid = (int)$lr['id']; } ?>
            <div class="msg-bubble mine">
              <div class="msg-text"><?= e($activeTicket['message'] ?? '') ?></div>
              <div class="msg-meta"><svg style="width:11px;height:11px;vertical-align:-1px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg> <?= date('d.m.Y H:i', strtotime($activeTicket['created_at'])) ?> · <?= __('support.you') ?></div>
              <?php if ($lastOwnRid === 0): ?>
              <div class="msg-ticks<?= $initialSeen ? ' tick-seen' : '' ?>" data-tick-init="<?= $initialSeen ? 'seen' : 'sent' ?>"><?= $initialSeen ? __('support.seen') : '✓' ?></div>
              <?php endif; ?>
            </div>
            <?php foreach ($ticketReplies as $r): ?>
            <div class="msg-bubble <?= $r['is_admin']?'admin-msg':'mine' ?>" data-rid="<?= (int)$r['id'] ?>">
              <?php if ($r['is_admin']): ?>
              <div style="display:flex;align-items:center;gap:7px;margin-bottom:5px;">
                <img src="<?= e($r['avatar']??'/images/avatars/default.svg') ?>" style="width:22px;height:22px;border-radius:50%;border:1.5px solid var(--ring);image-rendering:pixelated;background:var(--brand-soft);">
                <span style="font-size:12px;font-weight:700;color:var(--brand-deep);"><?= e($r['username']) ?>
                  <span style="background:var(--brand-soft);padding:1px 7px;border-radius:5px;font-size:10px;"><?= __('support.admin_badge') ?></span>
                </span>
              </div>
              <?php endif; ?>
              <div class="msg-text"><?= e($r['message']) ?></div>
              <?php if (!empty($r['image_url'])): ?>
              <a href="<?= e($r['image_url']) ?>" target="_blank" rel="noopener"><img src="<?= e($r['image_url']) ?>" class="nx-chat-img" alt="" loading="lazy"></a>
              <?php endif; ?>
              <div class="msg-meta"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" style="width:11px;height:11px;vertical-align:-1px"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg> <?= date('d.m.Y H:i', strtotime($r['created_at'])) ?><?= !$r['is_admin']?' · '.__('support.you'):'' ?></div>
              <?php if (!$r['is_admin'] && (int)$r['id'] === $lastOwnRid): ?>
              <?php $seen = (int)($r['is_seen'] ?? 0) === 1; ?>
              <div class="msg-ticks<?= $seen ? ' tick-seen' : '' ?>" data-tick="<?= (int)$r['id'] ?>"><?= $seen ? __('support.seen') : '✓' ?></div>
              <?php endif; ?>
            </div>
            <?php endforeach; ?>
          </div>

          <?php if ($activeTicket['status'] !== 'closed'): ?>
          <div class="ticket-reply-form">
            <div class="nx-attach-preview hidden" id="nxPreview">
              <img id="nxPreviewImg" alt="">
              <button type="button" class="nx-attach-x" id="nxPreviewX" title="<?= e(__('support.remove_attach')) ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" style="width:11px;height:11px;"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
            </div>
            <form id="replyForm" style="margin:0;" data-tid="<?= $activeTicket['id'] ?>">
              <?= csrf_field() ?>
              <div class="nx-composer">
                <button type="button" class="nx-attach-btn" id="nxAttachBtn" title="<?= e(__('support.attach_title')) ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px;"><path d="M21 11.5 12.4 20a4.5 4.5 0 0 1-6.4-6.4l9.2-9.2a3 3 0 0 1 4.2 4.2l-9.2 9.2a1.5 1.5 0 0 1-2.1-2.1l8.5-8.5"/></svg></button>
                <input type="file" id="nxAttachFile" accept=".png,.jpg,.jpeg,.webp" hidden>
                <input type="text" class="nx-chat-input" id="nxChatInput" maxlength="500" placeholder="<?= e(__('support.type_ph')) ?>" autocomplete="off">
                <span class="nx-count" id="nxCount">0/500</span>
                <button type="submit" class="nx-send-btn is-idle" id="nxSendBtn" title="<?= e(__('support.send')) ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:17px;height:17px;"><path d="m22 2-7 20-4-9-9-4z"/></svg></button>
              </div>
            </form>
          </div>
          <?php else: ?>
          <div style="padding:14px 24px;background:var(--bg-soft);border-top:1px solid var(--line);text-align:center;font-size:13px;color:var(--muted);">
            <?= __('support.closed_msg') ?>
          </div>
          <?php endif; ?>

          <?php endif; ?>
        </div>
      </div>

      <div id="ticketModal" class="modal-shade" style="display:none;">
        <div class="modal-box" style="max-width:600px;">
          <div class="modal-box-head">
            <span class="modal-box-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13a8 8 0 0 1 16 0"/><rect x="2.5" y="13" width="5" height="6" rx="2"/><rect x="16.5" y="13" width="5" height="6" rx="2"/></svg><?= __('support.modal_title') ?></span>
            <button class="cart-close" onclick="closeSupportTicket()" aria-label="<?= __('modal.close') ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
          </div>
          <form method="POST" action="/action.php" id="ticketForm">
            <div class="modal-box-body">
              <input type="hidden" name="action" value="ticket_create">
              <?= csrf_field() ?>
              <div class="modal-field">
                <label><?= __('support.title_label') ?></label>
                <input type="text" name="title" class="modal-input" required minlength="3" maxlength="200" placeholder="<?= e(__('support.title_ph_azure')) ?>">
              </div>
              <div class="modal-field">
                <label><?= __('support.category') ?></label>
                <select name="category" class="modal-input" style="font-weight:700;">
                  <?php foreach ($categories as $c): ?>
                  <option value="<?= e($c) ?>"><?= e($c) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="modal-field">
                <label><?= __('support.message_label') ?></label>
                <textarea name="message" class="modal-input" required minlength="10" maxlength="2000" rows="4" placeholder="<?= e(__('support.message_ph')) ?>" style="resize:vertical;"></textarea>
              </div>
              <?php if ($nxCfCaptcha): ?><div class="modal-field"><div class="cf-turnstile" data-sitekey="<?= e($nxIntSettings['int_cf_captcha_site_key']) ?>" data-theme="dark"></div><script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script></div><?php elseif ($nxRecaptcha): ?><div class="modal-field"><div class="g-recaptcha" data-sitekey="<?= e($nxIntSettings['int_recaptcha_site_key']) ?>" data-theme="dark"></div><script src="https://www.google.com/recaptcha/api.js" async defer></script></div><?php endif; ?>
            </div>
            <div class="modal-box-foot">
              <button type="button" class="btn btn-ghost" onclick="closeSupportTicket()"><?= __('support.cancel') ?></button>
              <button type="submit" class="btn btn-primary"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4z"/></svg><?= __('support.send') ?></button>
            </div>
          </form>
        </div>
      </div>

      <?php endif; ?>

      </div>
  </section>
</main>

<script src="/assets/js/support-chat.js?v=2"></script>
<script>
window.openSupportTicket = function (e) {
    if (e) e.preventDefault();
    var m = document.getElementById('ticketModal');
    if (!m) return;
    m.style.display = 'flex';
    requestAnimationFrame(function () { m.classList.add('show'); });
};
window.closeSupportTicket = function () {
    var m = document.getElementById('ticketModal');
    if (!m) return;
    m.classList.remove('show');
    setTimeout(function () { m.style.display = 'none'; }, 200);
};
window.nxToggleTickets = function (force) {
    var sb = document.getElementById('nxTicketSidebar');
    if (!sb) return;
    var open = (typeof force === 'boolean') ? force : !sb.classList.contains('nx-open');
    sb.classList.toggle('nx-open', open);
    var bd = document.getElementById('nxDrawerBackdrop');
    if (open && !bd) {
        bd = document.createElement('div');
        bd.id = 'nxDrawerBackdrop';
        bd.className = 'nx-drawer-backdrop';
        bd.onclick = function(){ window.nxToggleTickets(false); };
        document.body.appendChild(bd);
    }
    if (bd) bd.style.display = open ? 'block' : 'none';
    try { document.body.style.overflow = open ? 'hidden' : ''; } catch(e) {}
};

document.getElementById('ticketModal')?.addEventListener('click', function (e) { if (e.target === this) closeSupportTicket(); });
document.addEventListener('keydown', function (e) {
    var m = document.getElementById('ticketModal');
    if (e.key === 'Escape' && m && m.style.display !== 'none') closeSupportTicket();
});

document.getElementById('ticketForm')?.addEventListener('submit', function () {
    var body = document.getElementById('edBody-ticketMsg');
    var ta = document.getElementById('ticketMsg');
    if (body && ta) ta.value = body.innerHTML;
});

window.NX_SUPPORT_LANG = <?= json_encode(['seen'=>__('support.seen'),'now'=>__('support.now'),'you'=>__('support.you'),'admin_name'=>__('support.admin_name'),'admin_badge'=>__('support.admin_badge')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
SupportChatInit({
  boxId:'msgBox', boxAlt:'.ticket-messages', formId:'replyForm', inputId:'nxChatInput', sendBtnId:'nxSendBtn', countId:'nxCount',
  fileBtnId:'nxAttachBtn', fileInputId:'nxAttachFile', previewId:'nxPreview', previewImgId:'nxPreviewImg', previewXId:'nxPreviewX',
  tickTag:'div', tickClass:'msg-ticks', bubbleMine:'msg-bubble mine msg-in', metaSelect:'.msg-meta',
  metaDone:function(c){ return c + ' · ' + ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.you)||'Siz'); }, metaDoneHtml:false,
  optimistic:function(h, img, txt){
    var s = h.img(img);
    if (txt !== '') s += '<div class="msg-text">' + h.esc(txt) + '</div>';
    s += '<div class="msg-meta">' + ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.now)||'Şimdi') + ' · ' + ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.you)||'Siz') + '</div>';
    return s;
  },
  adminHead:function(esc, m){
    var av = m.avatar || '/images/avatars/default.svg';
    return '<div style="display:flex;align-items:center;gap:7px;margin-bottom:5px;">'
      + '<img src="' + esc(av) + '" style="width:22px;height:22px;border-radius:50%;border:1.5px solid var(--ring);image-rendering:pixelated;background:var(--brand-soft);">'
      + '<span style="font-size:12px;font-weight:700;color:var(--brand-deep);">' + esc(m.username || ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.admin_name)||'Destek'))
      + '<span style="background:var(--brand-soft);padding:1px 7px;border-radius:5px;font-size:10px;">' + ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.admin_badge)||'DESTEK') + '</span></span></div>';
  },
  polled:function(h, m){
    var s = h.img(m.image);
    if (m.admin) s += h.admin(m);
    if (m.message !== '') s += '<div class="msg-text">' + h.esc(m.message) + '</div>';
    s += '<div class="msg-meta">' + h.esc(m.created || '') + (m.admin ? '' : ' · ' + ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.you)||'Siz')) + '</div>';
    if (!m.admin) s += '<div class="msg-ticks" data-tick="' + m.id + '">✓</div>';
    return {cls:'msg-bubble msg-in ' + (m.admin ? 'admin-msg' : 'mine'), html:s};
  },
  onError:function(msg){ if (typeof showToast === 'function') { showToast(msg, false); } }
});
</script>

<style>
.ticket-shell{display:grid;grid-template-columns:300px 1fr;background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-lg);overflow:hidden;box-shadow:var(--shadow-sm);height:min(680px,calc(100vh - 160px),calc(100dvh - 160px));min-height:480px;}
.ticket-sidebar{background:var(--bg-soft);border-right:1px solid var(--line);display:flex;flex-direction:column;overflow:hidden;min-height:0;}
.ticket-main{display:flex;flex-direction:column;overflow:hidden;min-height:0;}
.ticket-list{flex:1;overflow-y:auto;padding:8px 10px 20px;}
.ticket-item{display:flex;flex-direction:column;gap:3px;padding:12px 14px;border-radius:12px;cursor:pointer;border:1px solid transparent;margin-bottom:4px;text-decoration:none;transition:background .13s,border-color .13s;}
.ticket-item:hover{background:var(--surface);}
.ticket-item.active{background:var(--surface);border-color:rgba(43,110,255,.3);}
.ticket-item-title{font-size:13px;font-weight:700;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.ticket-detail-head{padding:18px 24px 14px;border-bottom:1px solid var(--line);flex-shrink:0;}
.ticket-messages{flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:14px;}
.ticket-reply-form{padding:14px 24px;border-top:1px solid var(--line);flex-shrink:0;background:var(--surface);}
.msg-bubble{max-width:78%;display:flex;flex-direction:column;gap:5px;}
.msg-bubble.mine{align-self:flex-end;align-items:flex-end;}
.msg-bubble.admin-msg{align-self:flex-start;align-items:flex-start;}
.msg-text{padding:11px 15px;border-radius:14px;font-size:14px;line-height:1.65;}
.msg-bubble.mine .msg-text{background:linear-gradient(135deg,var(--brand),var(--brand-2));color:#fff;border-bottom-right-radius:4px;}
.msg-bubble.admin-msg .msg-text{background:var(--bg-soft);border:1px solid var(--line);color:var(--text);border-bottom-left-radius:4px;}
.msg-meta{font-size:10px;color:var(--muted);opacity:0;visibility:hidden;transition:opacity .2s;}
.msg-bubble:hover .msg-meta{opacity:1;visibility:visible;}
.msg-ticks{font-size:10px;font-weight:700;color:var(--muted);display:flex;align-items:center;gap:3px;}
.msg-ticks.tick-seen{color:#53bdeb;}
.hidden{display:none!important;}
@keyframes nxTickPop{0%{transform:scale(.4);opacity:0}60%{transform:scale(1.25)}100%{transform:scale(1);opacity:1}}
.tick-pop{animation:nxTickPop .45s cubic-bezier(.34,1.56,.64,1);}
@keyframes nxMsgIn{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}
.msg-in{animation:nxMsgIn .3s ease;}
@keyframes nxSendFly{0%{transform:translateX(0);opacity:1}100%{transform:translateX(26px);opacity:0}}
.nx-send-fly svg{animation:nxSendFly .35s ease;}
.nx-composer{display:flex;align-items:center;gap:8px;background:var(--surface);border:1px solid var(--line);border-radius:999px;padding:6px 6px 6px 8px;transition:border-color .2s;}
.nx-composer:focus-within{border-color:rgba(43,110,255,.55);}
.nx-attach-btn{flex-shrink:0;width:38px;height:38px;border-radius:50%;border:1px solid var(--line);background:rgba(43,110,255,.06);color:var(--muted);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.15s;}
.nx-attach-btn:hover{color:var(--brand);border-color:rgba(43,110,255,.5);}
.nx-chat-input{flex:1;min-width:0;background:transparent;border:none;outline:none;color:var(--text);font-family:inherit;font-size:14px;padding:8px 2px;}
.nx-chat-input::placeholder{color:var(--dim);}
.nx-count{flex-shrink:0;font-size:10px;color:var(--dim);font-weight:700;min-width:44px;text-align:right;}
.nx-send-btn{flex-shrink:0;width:42px;height:42px;border-radius:50%;border:none;cursor:pointer;background:linear-gradient(135deg,#38bdf8,#2563eb);color:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 14px rgba(37,99,235,.4);transition:transform .12s,filter .15s,opacity .15s;}
.nx-send-btn:hover{filter:brightness(1.1);}
.nx-send-btn:active{transform:scale(.9);}
.nx-send-btn.is-idle{opacity:.55;}
.nx-attach-preview{display:flex;align-items:center;gap:8px;margin-bottom:8px;}
.nx-attach-preview img{width:52px;height:52px;object-fit:cover;border-radius:10px;border:1px solid rgba(43,110,255,.4);}
.nx-attach-x{width:24px;height:24px;border-radius:50%;border:1px solid var(--line);background:rgba(228,87,107,.12);color:var(--danger);cursor:pointer;display:flex;align-items:center;justify-content:center;}
.nx-chat-img{max-width:240px;max-height:180px;border-radius:10px;border:1px solid var(--line);margin-bottom:6px;display:block;cursor:zoom-in;}
.nx-faded{opacity:.4;pointer-events:none;filter:grayscale(.6);}
@media(max-width:560px){.nx-count{display:none;}.nx-chat-input{font-size:13px;}.msg-bubble{max-width:88%;}.nx-chat-img{max-width:180px;}}
@media(max-width:960px){.ticket-shell{grid-template-columns:1fr;min-height:0;height:calc(100dvh - 120px);}
.ticket-sidebar{position:fixed;top:0;left:0;bottom:0;width:min(320px,86vw);z-index:1001;border-right:1px solid var(--line);border-bottom:none;max-height:none;background:var(--bg-soft);transform:translateX(-106%);transition:transform .25s ease;box-shadow:none;border-radius:0;}
.ticket-sidebar.nx-open{transform:none;box-shadow:24px 0 60px rgba(0,0,0,.5);}
.nx-drawer-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:1000;}
.nx-drawer-btn{display:inline-flex!important;}
.ticket-detail-head{padding:14px 14px 10px;}
.ticket-messages{padding:14px;}
.ticket-reply-form{padding:10px 12px;}}
.nx-drawer-btn{display:none;align-items:center;justify-content:center;width:36px;height:36px;border-radius:10px;background:var(--bg-soft);border:1px solid var(--line);color:var(--text);cursor:pointer;flex-shrink:0;}
.nx-drawer-btn svg{width:16px;height:16px;}
.nx-mobile-bar{display:none;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid var(--line);}
@media(max-width:960px){.nx-mobile-bar{display:flex;}}
</style>

<?php include __DIR__ . '/includes/footer.php'; ?>