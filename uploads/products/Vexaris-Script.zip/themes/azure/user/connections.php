<?php
auth_require('/login');

$pageTitle   = __('panel.conn_title');
$activePage  = '';
$activePanel = 'connections';
$u           = auth_user();
$db          = nexus_db();

$flashType = '';
$flashText = '';
if (isset($_GET['flash'])) {
    $parts = explode(':', urldecode($_GET['flash']), 2);
    $flashType = $parts[0] === 'error' ? 'error' : 'success';
    $flashText = $parts[1] ?? '';
}

$providers = [];
$linkedMap = [];
try {
    $st = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'");
    $intSettings = [];
    while ($r = $st->fetch()) $intSettings[$r['key']] = $r['value'];

    $defs = [
        'google_auth'    => ['label'=>'Google','icon'=>'google','color'=>'#4285f4','desc'=>__('panel.conn_google')],
        'discord_auth'   => ['label'=>'Discord','icon'=>'discord','color'=>'#5865f2','desc'=>__('panel.conn_discord')],
        'microsoft_auth' => ['label'=>'Microsoft','icon'=>'microsoft','color'=>'#00a4ef','desc'=>__('panel.conn_microsoft')],
        'github_auth'    => ['label'=>'GitHub','icon'=>'github','color'=>'#24292f','desc'=>__('panel.conn_github')],
    ];
    foreach ($defs as $slug => $def) {
        $enabled = ($intSettings['int_'.$slug.'_enabled'] ?? '0') === '1';
        $clientId = trim($intSettings['int_'.$slug.'_client_id'] ?? '');
        if (!$enabled || $clientId === '') continue;
        $def['slug'] = $slug;
        $providers[] = $def;
    }

    $ust = $db->prepare("SELECT oauth_google_id,oauth_discord_id,oauth_microsoft_id,oauth_github_id FROM users WHERE id=?");
    $ust->execute([$u['id']]);
    $oauthRow = $ust->fetch() ?: [];
    $linkedMap = [
        'google_auth'    => !empty($oauthRow['oauth_google_id'] ?? ''),
        'discord_auth'   => !empty($oauthRow['oauth_discord_id'] ?? ''),
        'microsoft_auth' => !empty($oauthRow['oauth_microsoft_id'] ?? ''),
        'github_auth'    => !empty($oauthRow['oauth_github_id'] ?? ''),
    ];
} catch (\PDOException $e) {
    error_log('[NS] connections: '.$e->getMessage());
}

include __DIR__ . '/../includes/header.php';
$socIcons = [
    'google_auth'    => '<i class="fa-brands fa-google" style="font-size:20px"></i>',
    'discord_auth'   => '<i class="fa-brands fa-discord" style="font-size:20px"></i>',
    'microsoft_auth' => '<i class="fa-brands fa-microsoft" style="font-size:20px"></i>',
    'github_auth'    => '<i class="fa-brands fa-github" style="font-size:20px"></i>',
];
?>
<div class="panel-layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="panel-content">

        <div class="panel-card">
            <h1 class="panel-card-title"><svg style="color:var(--brand)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg><?= __('panel.conn_title') ?></h1>
            <p class="panel-card-desc"><?= __('panel.conn_desc') ?></p>

            <?php if ($flashText): ?>
            <div class="auth-alert <?= $flashType==='success' ? 'auth-alert--ok' : 'auth-alert--error' ?>" style="margin-bottom:18px;">
                <svg style="width:15px;height:15px;flex-shrink:0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><?= $flashType==='success' ? '<path d="m5 13 4 4 10-11"/>' : '<path d="M18 6 6 18M6 6l12 12"/>' ?></svg>
                <?= e($flashText) ?>
            </div>
            <?php endif; ?>

            <?php if (empty($providers)): ?>
            <div style="text-align:center;padding:40px 20px;color:var(--muted);">
                <svg style="width:40px;height:40px;color:var(--dim);margin-bottom:12px;display:block;margin-inline:auto;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg>
                <p style="font-size:14px;font-weight:600;"><?= __('panel.no_providers') ?></p>
            </div>
            <?php else: ?>
            <div style="display:flex;flex-direction:column;gap:14px;margin-top:18px;">
                <?php foreach ($providers as $p):
                    $linked = $linkedMap[$p['slug']] ?? false;
                ?>
                <div style="display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;background:var(--bg-soft);border:1px solid var(--line);border-radius:16px;padding:16px 18px;">
                    <div style="display:flex;align-items:center;gap:14px;min-width:0;">
                        <span style="width:44px;height:44px;border-radius:12px;background:<?= $p['color'] ?>14;display:flex;align-items:center;justify-content:center;color:<?= $p['color'] ?>;flex-shrink:0;"><?= $socIcons[$p['slug']] ?? '' ?></span>
                        <div style="min-width:0;">
                            <div style="font-size:15px;font-weight:800;"><?= $p['label'] ?></div>
                            <div style="font-size:12px;color:var(--muted);margin-top:2px;"><?= $p['desc'] ?></div>
                            <div style="margin-top:6px;">
                                <span class="badge <?= $linked ? 'badge-green' : 'badge-closed' ?>">
                                    <?= $linked ? __('panel.linked') : __('panel.not_linked') ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <?php if ($linked): ?>
                    <form method="POST" action="/action.php" onsubmit="return confirm(<?= htmlspecialchars(json_encode(__('panel.unlink_confirm', ['brand' => $p['label']])), ENT_QUOTES) ?>);">
                        <input type="hidden" name="action" value="oauth_unlink">
                        <?= csrf_field() ?>
                        <input type="hidden" name="slug" value="<?= $p['slug'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm"><?= __('panel.unlink') ?></button>
                    </form>
                    <?php else: ?>
                    <a href="/api/auth/<?= $p['slug'] ?>?connect=1" class="btn btn-primary btn-sm"><?= __('panel.link') ?></a>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

    </main>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>