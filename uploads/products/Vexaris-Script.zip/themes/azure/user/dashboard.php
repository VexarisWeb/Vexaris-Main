<?php
auth_require('/login');

$pageTitle   = __('nav.dashboard');
$activePage  = '';
$activePanel = 'dashboard';
$u = auth_user();
$db = nexus_db();

$purchasedCount = $activeLicCount = $openTicketCount = 0;
$userCart = [];
if ($db) {
    try {
        $st = $db->prepare('SELECT COUNT(*) FROM sales WHERE user_id=?'); $st->execute([$u['id']]); $purchasedCount = (int)$st->fetchColumn();
        $st = $db->prepare('SELECT COUNT(*) FROM licenses WHERE user_id=? AND status="active"'); $st->execute([$u['id']]); $activeLicCount = (int)$st->fetchColumn();
        $st = $db->prepare('SELECT COUNT(*) FROM tickets WHERE user_id=? AND status!="closed"'); $st->execute([$u['id']]); $openTicketCount = (int)$st->fetchColumn();
        $cartStmt = $db->prepare('SELECT c.*,p.name,p.price,p.image_url FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? ORDER BY c.added_at DESC');
        $cartStmt->execute([$u['id']]);
        $userCart = $cartStmt->fetchAll();
    } catch (\Exception $e) { error_log('[NS] dashboard: '.$e->getMessage()); }
}

$balanceLog = [];
if ($db) {
    try {
        $bl = $db->prepare('SELECT amount,type,description,created_at FROM balance_log WHERE user_id=? ORDER BY created_at DESC LIMIT 10');
        $bl->execute([$u['id']]);
        $balanceLog = $bl->fetchAll();
    } catch (\Exception $e) {}
}

include __DIR__ . '/../includes/header.php';
?>
<div class="panel-layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="panel-content">

        <div class="panel-card">
            <h1 class="panel-card-title"><?= __('panel.welcome_a') ?><?= e($u['username']) ?>!</h1>
            <p class="panel-card-desc"><?= __('panel.summary') ?></p>

            <div class="panel-stats">
                <?php
                $stats = [
                    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M12 24V15"/></svg>','color'=>'#2b6eff','label'=>__('panel.products'),'val'=>$purchasedCount],
                    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 6v5c0 5 3.4 8 8 10 4.6-2 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/></svg>','color'=>'#ff9d3d','label'=>__('panel.licenses'),'val'=>$activeLicCount],
                    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13a8 8 0 0 1 16 0"/><rect x="2.5" y="13" width="5" height="6" rx="2"/><rect x="16.5" y="13" width="5" height="6" rx="2"/></svg>','color'=>'#0fae7c','label'=>__('panel.open_tickets'),'val'=>$openTicketCount],
                ];
                foreach ($stats as $s): ?>
                <div class="panel-stat">
                    <span class="panel-stat-icon" style="background:<?= $s['color'] ?>14;color:<?= $s['color'] ?>;"><?= $s['icon'] ?></span>
                    <p class="panel-stat-val"><?= $s['val'] ?></p>
                    <p class="panel-stat-label"><?= $s['label'] ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if (!empty($userCart)): ?>
        <div class="panel-card">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                <h2 style="font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;">
                    <svg style="width:17px;height:17px;color:var(--brand)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2l2.5 12.5A2 2 0 0 0 9.5 18h8a2 2 0 0 0 2-1.6L21.5 8H6"/><path d="M10 22a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm8 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/></svg>
                    <?= __('cart.title') ?>
                </h2>
                <a href="/products" style="font-size:12px;color:var(--brand);font-weight:700;"><?= __('library.go_shop') ?></a>
            </div>
            <?php foreach ($userCart as $ci): ?>
            <div class="dash-row" style="display:flex;align-items:center;gap:12px;background:var(--bg-soft);border:1px solid var(--line);border-radius:12px;padding:12px;margin-bottom:8px;" id="dashCart-<?= $ci['product_id'] ?>">
                <?php if ($ci['image_url']): ?>
                <img src="<?= e($ci['image_url']) ?>" style="width:44px;height:44px;border-radius:9px;object-fit:cover;">
                <?php else: ?>
                <span style="width:44px;height:44px;border-radius:9px;background:var(--brand-soft);display:flex;align-items:center;justify-content:center;color:var(--brand);flex-shrink:0;"><svg style="width:20px;height:20px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="3" width="16" height="14" rx="3"/><path d="M9 7h6M12 7v10"/></svg></span>
                <?php endif; ?>
                <div style="flex:1;min-width:0;">
                    <p style="font-size:13px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e($ci['name']) ?></p>
                    <p style="font-size:12px;font-weight:800;color:var(--brand-deep);"><?= fmt_money($ci['price']) ?></p>
                </div>
                <div style="display:flex;align-items:center;gap:6px;background:var(--surface);border:1px solid var(--line);border-radius:9px;padding:4px 6px;">
                    <button onclick="dashCartQty(<?= $ci['product_id'] ?>,-1)" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:16px;font-weight:700;width:24px;height:24px;display:flex;align-items:center;justify-content:center;border-radius:6px;">−</button>
                    <span style="font-size:13px;font-weight:700;min-width:22px;text-align:center;" id="dashQty-<?= $ci['product_id'] ?>"><?= $ci['quantity'] ?></span>
                    <button onclick="dashCartQty(<?= $ci['product_id'] ?>,1)" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:16px;font-weight:700;width:24px;height:24px;display:flex;align-items:center;justify-content:center;border-radius:6px;">+</button>
                </div>
                <button onclick="dashCartQty(<?= $ci['product_id'] ?>,0)" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:14px;padding:4px;">
                    <svg style="width:16px;height:16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2m-9 0 1 14h8l1-14"/></svg>
                </button>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if (!empty($balanceLog)): ?>
        <div class="panel-card">
            <h2 style="font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;margin-bottom:16px;">
                <svg style="width:17px;height:17px;color:var(--warn)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="8"/><path d="M12 7v10M9 9.5h6"/></svg>
                <?= __('panel.balance_history') ?>
            </h2>
            <div style="display:flex;flex-direction:column;gap:8px;">
                <?php $blTypeLabels = ['payment'=>__('panel.tx_payment'),'purchase'=>__('panel.tx_purchase'),'topup'=>__('panel.tx_topup'),'coupon'=>__('panel.tx_coupon'),'refund'=>__('panel.tx_refund'),'admin'=>__('panel.tx_admin')]; ?>
                <?php foreach ($balanceLog as $bl): ?>
                <div class="dash-row" style="display:flex;align-items:center;gap:12px;background:var(--bg-soft);border:1px solid var(--line);border-radius:12px;padding:12px 14px;">
                    <span class="dash-amount" style="font-size:14px;font-weight:900;color:<?= $bl['amount']>=0?'var(--ok)':'var(--danger)' ?>;min-width:90px;">
                        <?= $bl['amount']>=0?'+':'' ?><?= fmt_money((float)$bl['amount']) ?>
                    </span>
                    <div style="flex:1;min-width:0;">
                        <div style="font-size:12.5px;font-weight:700;">
                            <?= $blTypeLabels[$bl['type']] ?? $bl['type'] ?>
                            <?php if ($bl['description']): ?>
                            <span style="font-weight:500;color:var(--muted);">— <?= e($bl['description']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <span class="dash-date" style="font-size:11px;color:var(--dim);flex-shrink:0;"><?= date('d.m.Y H:i', strtotime($bl['created_at'])) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </main>
</div>

<?php if (!empty($userCart)): ?>
<script>
const DASH_ACTIONS = '/action.php';
async function dashCartQty(pid, delta) {
    const el = document.getElementById('dashCart-'+pid);
    const qtyEl = document.getElementById('dashQty-'+pid);
    const prevQty = parseInt(qtyEl ? qtyEl.textContent : '1');
    let newQty = delta === 0 ? 0 : Math.max(1, prevQty + delta);
    if (delta !== 0 && newQty === prevQty) return;
    if (qtyEl) qtyEl.textContent = newQty;
    const fd = new FormData();
    fd.append('action','cart_update_qty');
    fd.append('product_id', pid);
    fd.append('quantity', newQty);
    const r = await fetch(DASH_ACTIONS, {method:'POST',body:fd});
    const d = await r.json();
    if (d.ok) {
        if (newQty < 1 && el) { el.style.transition = 'opacity .3s'; el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }
        if (!d.cart_count || d.cart_count < 1) setTimeout(() => location.reload(), 400);
    } else if (qtyEl) {
        qtyEl.textContent = prevQty;
    }
}
</script>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>