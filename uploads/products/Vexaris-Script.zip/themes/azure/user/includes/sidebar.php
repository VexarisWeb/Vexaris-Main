<?php
$u = auth_user();
$roleNames = [
    'user'         => __('nav.role_member'),
    'destek_ekibi' => __('nav.role_support'),
    'moderator'    => __('nav.role_mod'),
    'yonetici'     => __('nav.role_manager'),
    'admin'        => __('nav.role_admin')
];
if ($u) {
    try {
        $_db = nexus_db();
        $_rs = $_db->prepare('SELECT role FROM users WHERE id=? LIMIT 1');
        $_rs->execute([$u['id']]);
        $_role = $_rs->fetchColumn();
        if ($_role !== false && $_role !== ($u['role'] ?? '')) {
            $_SESSION['user']['role'] = $_role;
            $u['role'] = $_role;
        }
    } catch (\PDOException $e) { error_log('[NS] sidebar role: '.$e->getMessage()); }
}
$uRoleName = $roleNames[$u['role'] ?? ''] ?? __('nav.role_member');
$_updTotal = 0;
try { if ($u && function_exists('product_update_total')) $_updTotal = product_update_total(null, (int)$u['id']); } catch (Throwable $e) {}
?>
<aside class="panel-sidebar">

    <div class="sidebar-user">
        <img src="<?= e($u['avatar']) ?>"
             alt="<?= e($u['username']) ?>"
             class="sidebar-user-avatar">
        <span class="sidebar-user-name"><?= e($u['username']) ?></span>
        <span class="sidebar-user-email"><?= e($u['email']) ?></span>
        <span class="sidebar-user-role"><?= e($uRoleName) ?></span>
    </div>

    <button type="button" class="panel-nav-toggle" onclick="this.closest('.panel-sidebar').classList.toggle('nav-open')">
        <span class="panel-ham"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg></span>
        <span><?= __('nav.panel') ?></span>
        <svg class="panel-nav-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="m6 9 6 6 6-6"/></svg>
    </button>
    <nav class="sidebar-nav">
        <a href="/user/dashboard" class="<?= ($activePanel??'')==='dashboard' ? 'active':'' ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="4" width="7" height="9" rx="2"/><rect x="13" y="4" width="7" height="5" rx="2"/><rect x="13" y="15" width="7" height="5" rx="2"/></svg>
            <?= __('nav.panel') ?>
        </a>
        <a href="/user/my-products" class="<?= ($activePanel??'')==='products' ? 'active':'' ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M12 24V15"/></svg>
            <?= __('nav.my_products') ?>
            <?php if ($_updTotal > 0): ?><span style="margin-left:auto;display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;border-radius:999px;background:#ef4444;color:#fff;font-size:11px;font-weight:800;"><?= $_updTotal ?></span><?php endif; ?>
        </a>
        <a href="/user/my-tickets" class="<?= ($activePanel??'')==='tickets' ? 'active':'' ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13a8 8 0 0 1 16 0"/><rect x="2.5" y="13" width="5" height="6" rx="2"/><rect x="16.5" y="13" width="5" height="6" rx="2"/></svg>
            <?= __('nav.my_tickets') ?>
        </a>
        <a href="/user/redeem-code" class="<?= ($activePanel??'')==='redeem' ? 'active':'' ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h16v12H4z"/><path d="M12 8V4m0 0h-2m2 0h2"/><path d="M9 13h6m-6 4h6"/></svg>
            <?= __('nav.redeem') ?>
        </a>
        <a href="/user/connections" class="<?= ($activePanel??'')==='connections' ? 'active':'' ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg>
            <?= __('nav.connections') ?>
        </a>
        <a href="/user/settings" class="<?= ($activePanel??'')==='settings' ? 'active':'' ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M4.2 6.5l2.6 1.5m10.4 6 2.6 1.5M4.2 17.5l2.6-1.5m10.4-6 2.6-1.5"/></svg>
            <?= __('nav.settings') ?>
        </a>
        <a href="/logout" class="danger">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/></svg>
            <?= __('nav.logout') ?>
        </a>
    </nav>

</aside>