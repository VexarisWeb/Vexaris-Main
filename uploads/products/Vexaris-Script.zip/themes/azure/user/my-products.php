<?php
auth_require('/login');

$pageTitle   = __('footer.my_products');
$activePage  = '';
$activePanel = 'products';
$u  = auth_user();
$db = nexus_db();

$purchases = [];
if ($db) {
    $stmt = $db->prepare(
        'SELECT s.id AS sale_id, s.product_id, s.license_key, s.price_paid, s.purchased_at, p.name AS product_name, p.version, p.category, p.download_link, p.file_path, p.user_notice
         FROM sales s
         JOIN products p ON p.id = s.product_id
         WHERE s.user_id = ?
         ORDER BY s.purchased_at DESC'
    );
    $stmt->execute([$u['id']]);
    $purchases = $stmt->fetchAll();
}

$updInfo = function_exists('product_update_unread') ? product_update_unread($db, (int)$u['id']) : ['total' => 0, 'by_product' => []];
$unreadByProduct = $updInfo['by_product'] ?? [];
$unreadTotal = (int)($updInfo['total'] ?? 0);

include __DIR__ . '/../includes/header.php';
?>
<div class="panel-layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="panel-content">

        <div class="panel-card">
            <style>@keyframes puGlow{0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,.45);}50%{box-shadow:0 0 0 6px rgba(239,68,68,0);}}.pu-updated{border-color:rgba(239,68,68,.55)!important;animation:puGlow 2s ease-in-out infinite;}.pu-badge{display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;border-radius:999px;background:#ef4444;color:#fff;font-size:11px;font-weight:800;margin-left:6px;}</style>
            <h1 class="panel-card-title"><svg style="color:var(--brand)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M12 24V15"/></svg><?= __('footer.my_products') ?><?php if ($unreadTotal > 0): ?><span class="pu-badge"><?= $unreadTotal ?></span><?php endif; ?></h1>
            <p class="panel-card-desc"><?= __('panel.products_desc') ?></p>

            <?php if (empty($purchases)): ?>
            <div style="text-align:center;padding:48px 20px;color:var(--muted);">
                <svg style="width:44px;height:44px;color:var(--dim);margin:0 auto 14px;display:block;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 9.5 12 4l9 5.5v9L12 24l-9-5.5z"/><path d="M12 24V15"/></svg>
                <p style="font-size:15px;font-weight:700;margin-bottom:8px;"><?= __('panel.no_products') ?></p>
                <a href="/products" class="btn btn-primary btn-sm" style="margin-top:8px;"><?= __('library.go_shop') ?></a>
            </div>
            <?php else: ?>
            <div style="display:flex;flex-direction:column;gap:14px;">
                <?php foreach ($purchases as $l): $up = $unreadByProduct[(int)($l['product_id'] ?? 0)] ?? null; ?>
                <div class="<?= $up ? 'pu-updated' : '' ?>" style="background:var(--bg-soft);border:1px solid var(--line);border-radius:16px;padding:20px 22px;">
                    <?php if ($up): ?>
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:10px;padding:8px 12px;font-size:12px;font-weight:800;color:#ef4444;">
                        <i class="fa-solid fa-bell"></i> <?= __('panel.updates_n', ['n' => (int)$up['count']]) ?>
                        <span style="font-weight:600;color:var(--muted);">v<?= e($up['latest']['version'] !== '' ? $up['latest']['version'] : '?') ?> <?= __('panel.live') ?></span>
                        <a href="/products?product=<?= (int)$l['product_id'] ?>" style="margin-left:auto;color:#ef4444;font-weight:700;"><?= __('panel.detail') ?> <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                    <?php endif; ?>
                    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">
                        <div style="min-width:0;">
                            <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;flex-wrap:wrap;">
                                <span style="font-size:15px;font-weight:800;"><?= e($l['product_name'] ?? __('msg.no_name')) ?></span>
                                <?php if (!empty($l['version'])): ?><span style="font-size:11px;color:var(--muted);font-weight:700;background:var(--bg);padding:2px 8px;border-radius:999px;">v<?= e($l['version']) ?></span><?php endif; ?>
                            </div>
                            <div style="font-size:12px;color:var(--muted);margin-bottom:10px;"><?= e($l['category'] ?? '') ?></div>
                            <?php if (!empty($l['user_notice'])): ?>
                            <div style="display:flex;align-items:flex-start;gap:10px;background:rgba(255,157,61,.08);border:1px solid rgba(255,157,61,.25);border-radius:10px;padding:11px 14px;">
                                <svg style="width:14px;height:14px;color:var(--warn);margin-top:1px;flex-shrink:0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/></svg>
                                <div>
                                    <div style="font-size:12px;font-weight:800;color:var(--warn);"><?= __('panel.buyer_note') ?></div>
                                    <div style="font-size:12px;color:var(--muted);margin-top:2px;line-height:1.5;"><?= nl2br(e($l['user_notice'])) ?></div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px;">
                            <?php
                            $dlHref = '';
                            if ($l['download_link']) $dlHref = nx_safe_href($l['download_link'], '');
                            elseif ($l['file_path'] && $l['sale_id']) $dlHref = '/download.php?sale_id='.(int)$l['sale_id'];
                            ?>
                            <?php if ($dlHref): ?>
                            <a href="<?= e($dlHref) ?>" class="btn btn-primary btn-sm dl-btn" data-dl>
                                <span class="dl-svg"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2M12 3v13m-4-4 4 4 4-4"/></svg></span>
                                <span class="dl-done-svg"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m5 13 4 4 10-11"/></svg></span>
                                <span class="dl-label"><?= __('library.download') ?></span>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if (!empty($l['license_key'])): ?>
                    <?php $licId = (int)$l['sale_id']; ?>
                    <div style="display:flex;align-items:center;gap:10px;margin:16px 0 12px;">
                        <div style="flex:1;display:flex;align-items:center;gap:10px;background:var(--brand-soft);border:1px solid rgba(43,110,255,.25);border-radius:10px;padding:11px 14px;min-width:0;">
                            <svg style="width:13px;height:13px;color:var(--brand-deep);flex-shrink:0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
                            <code id="nxsLic-<?= $licId ?>" style="font-family:ui-monospace,Consolas,monospace;font-size:12px;font-weight:700;color:var(--brand-deep);word-break:break-all;line-height:1.5;"><?= e($l['license_key']) ?></code>
                        </div>
                        <button type="button" onclick="copyNxsLic(<?= $licId ?>)"
                                style="flex-shrink:0;display:inline-flex;align-items:center;gap:7px;background:var(--surface);border:1px solid var(--line);color:var(--text-2);cursor:pointer;border-radius:10px;padding:12px 16px;font-size:12px;font-weight:700;transition:border-color .15s,color .15s;">
                            <svg style="width:14px;height:14px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>
                            Kopyala
                        </button>
                    </div>
                    <?php endif; ?>
                    <div style="margin-top:10px;font-size:11px;color:var(--dim);">
                        <?= __('library.purchased_on') ?> <?= date('d.m.Y', strtotime($l['purchased_at'])) ?>
                        <?php if ((float)$l['price_paid'] > 0): ?>
                         · <?= __('panel.amount') ?> <?= fmt_money((float)$l['price_paid']) ?>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

    </main>
</div>

<script>
window.NX_PANEL_LANG = <?= json_encode(['copied'=>__('panel.copied'),'copied_azure'=>__('panel.copied_azure'),'downloaded'=>__('panel.downloaded')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
function copyNxsLic(id) {
    var el = document.getElementById('nxsLic-' + id);
    if (!el) return;
    var text = el.textContent.trim();
    var done = function(){ var t=(window.NX_PANEL_LANG&&window.NX_PANEL_LANG.copied_azure)||'Lisans kopyalandı'; var a=(window.NX_PANEL_LANG&&window.NX_PANEL_LANG.copied)||'Kopyalandı'; window.showToast ? window.showToast(t, true) : alert(a); };
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done, function(){ fallbackCopy(text, done); });
    } else {
        fallbackCopy(text, done);
    }
}
function fallbackCopy(text, done) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } catch(e) {}
    document.body.removeChild(ta); done();
}

/* İndirme → "İndirildi" tik animasyonu (popup yok) */
document.querySelectorAll('[data-dl]').forEach(function (btn) {
    btn.addEventListener('click', function () {
        if (btn.classList.contains('done')) return;
        var label = btn.querySelector('.dl-label');
        var original = label ? label.textContent : '';
        var done = function () {
            if (label) label.textContent = (window.NX_PANEL_LANG&&window.NX_PANEL_LANG.downloaded)||'İndirildi';
            btn.classList.add('done');
        };
        /* dış bağlantıya devam edebilmesi için birkaç ms sonra tik göster */
        setTimeout(done, 200);
    });
});
</script>

<?php if ($unreadTotal > 0 && function_exists('product_update_mark_seen')) product_update_mark_seen($db, (int)$u['id']); ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>