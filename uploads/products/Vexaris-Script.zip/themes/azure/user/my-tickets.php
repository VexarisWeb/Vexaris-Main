<?php
auth_require('/login');

$pageTitle   = 'Destek Taleplerim';
$activePage  = '';
$activePanel = 'tickets';
$u  = auth_user();
$db = nexus_db();

$tickets = [];

if ($db) {
    $stmt = $db->prepare('SELECT * FROM tickets WHERE user_id = ? ORDER BY COALESCE(updated_at,created_at) DESC, id DESC');
    $stmt->execute([$u['id']]);
    $tickets = $stmt->fetchAll();
}

include __DIR__ . '/../includes/header.php';
?>
<div class="panel-layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="panel-content">

        <div class="panel-card">
            <h2 class="panel-card-title"><svg style="color:var(--warn)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13a8 8 0 0 1 16 0"/><rect x="2.5" y="13" width="5" height="6" rx="2"/><rect x="16.5" y="13" width="5" height="6" rx="2"/></svg>Taleplerim</h2>

            <?php if (empty($tickets)): ?>
            <div style="text-align:center;padding:40px;color:var(--muted);">
                <svg style="width:38px;height:38px;color:var(--dim);margin:0 auto 12px;display:block;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5.1 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6z"/></svg>
                <p><?= __('ticket.empty') ?></p>
            </div>
            <?php else: ?>
            <div style="display:flex;flex-direction:column;gap:10px;">
                <?php foreach ($tickets as $t):
                    $sc = ['open'=>'badge-red','replied'=>'badge-yellow','closed'=>'badge-green'];
                    $sl = ['open'=>__('ticket.open'),'replied'=>__('ticket.replied'),'closed'=>__('ticket.closed')];
                ?>
                <a href="/support?id=<?= (int)$t['id'] ?>"
                   style="text-decoration:none;color:inherit;background:var(--bg-soft);border:1px solid var(--line);border-radius:14px;
                          padding:16px 20px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;
                          transition:border-color .15s,background .15s;">
                    <div>
                        <p style="font-size:14px;font-weight:700;margin-bottom:4px;"><?= e($t['title']) ?></p>
                        <p style="font-size:12px;color:var(--dim);">
                            <?= e($t['category'] ?? __('shop.general')) ?>
                            ·
                            <svg style="width:12px;height:12px;vertical-align:-1px;margin-right:4px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>
                            <?= date('d.m.Y H:i', strtotime($t['created_at'])) ?>
                            · #<?= (int)$t['id'] ?>
                        </p>
                    </div>
                    <span class="badge <?= $sc[$t['status']] ?>"><?= $sl[$t['status']] ?></span>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

    </main>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>