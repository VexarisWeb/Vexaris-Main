<?php
auth_require('/login');

$pageTitle   = __('nav.redeem');
$activePage  = '';
$activePanel = 'redeem';
$u  = auth_user();
$db = nexus_db();

include __DIR__ . '/../includes/header.php';
?>
<div class="panel-layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="panel-content">

        <div class="panel-card" style="max-width:640px;">
            <h1 class="panel-card-title"><svg style="color:var(--brand)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h16v12H4z"/><path d="M12 8V4m0 0h-2m2 0h2"/><path d="M9 13h6m-6 4h6"/></svg><?= __('nav.redeem') ?></h1>
            <p class="panel-card-desc"><?= __('panel.redeem_desc') ?></p>

            <div style="display:flex;gap:10px;margin-top:18px;">
                <input type="text" id="redeemCodeInput" placeholder="<?= e(__('panel.coupon_ph')) ?>" autocomplete="off" maxlength="50"
                       style="flex:1;min-width:0;background:var(--bg-soft);border:1px solid var(--line);border-radius:12px;padding:13px 16px;color:var(--text);font-size:14px;outline:none;font-weight:800;letter-spacing:.06em;text-transform:uppercase;font-family:ui-monospace,Consolas,monospace;">
                <button id="redeemBtn" onclick="redeemCode()" class="btn btn-primary" style="border:none;padding:0 22px;font-size:14px;">
                    <?= __('panel.use') ?>
                </button>
            </div>

            <div id="redeemResult" style="display:none;"></div>
        </div>

    </main>
</div>

<script>
window.NX_REDEEM_LANG = <?= json_encode(['enter_code'=>__('panel.enter_code'),'preparing'=>__('panel.preparing'),'conn_error'=>__('panel.conn_error'),'code_invalid'=>__('panel.code_invalid')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var _redeeming = false;
function redeemCode() {
    if (_redeeming) return;
    var code = document.getElementById('redeemCodeInput').value.trim().toUpperCase();
    if (!code) { showRedeem('err', window.NX_REDEEM_LANG&&window.NX_REDEEM_LANG.enter_code||'Kupon kodu girin.'); return; }
    _redeeming = true;
    var btn = document.getElementById('redeemBtn');
    btn.disabled = true; btn.style.opacity = '.6';
    var fd = new FormData();
    fd.append('action', 'apply_coupon');
    fd.append('code', code);
    fetch('/action.php', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            _redeeming = false;
            btn.disabled = false; btn.style.opacity = '';
            if (!d.ok) { showRedeem('err', d.msg || ((window.NX_REDEEM_LANG&&window.NX_REDEEM_LANG.code_invalid)||'Kod kullanılamadı.')); return; }
            var h = '';
            if (d.products && d.products.length) {
                for (var i = 0; i < d.products.length; i++) {
                    h += '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;background:var(--bg-soft);border:1px solid var(--line);border-radius:10px;padding:12px 14px;flex-wrap:wrap;">';
                    h += '<span style="font-size:13px;font-weight:700;">' + String(d.products[i].product_name).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') + '</span>';
                    var lk = d.products[i].license_key || '';
                    if (lk) {
                        var _lk = String(lk).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
                        h += '<span style="display:flex;align-items:center;gap:8px;"><code style="background:var(--brand-soft);color:var(--brand-deep);padding:5px 10px;border-radius:7px;font-size:11px;letter-spacing:.04em;">' + _lk + '</code><button onclick="copyRedeemKey(this)" style="background:var(--surface);border:1px solid var(--line);color:var(--text-2);border-radius:7px;padding:4px 8px;cursor:pointer;font-size:11px;" title="Kopyala"><svg style="width:12px;height:12px;vertical-align:-2px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 9h12v12H9z"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg></button></span>';
                    } else {
                        h += '<span style="display:flex;align-items:center;gap:8px;"><span style="width:16px;height:16px;border:2px solid rgba(43,110,255,.2);border-top-color:var(--brand);border-radius:50%;display:inline-block;animation:azSpin .8s linear infinite;flex-shrink:0;"></span><span style="font-size:11px;font-weight:700;color:var(--muted);">' + ((window.NX_REDEEM_LANG&&window.NX_REDEEM_LANG.preparing)||'Lisans hazırlanıyor') + '</span></span>';
                    }
                    if (d.products[i].notice) {
                        var _nt = String(d.products[i].notice).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
                        h += '<div style="display:flex;align-items:flex-start;gap:8px;background:rgba(255,157,61,.08);border:1px solid rgba(255,157,61,.22);border-radius:8px;padding:8px 10px;margin-top:6px;width:100%;"><svg style="width:12px;height:12px;color:var(--warn);margin-top:2px;flex-shrink:0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/></svg><span style="font-size:11px;color:var(--muted);line-height:1.5;">' + _nt + '</span></div>';
                    }
                    h += '</div>';
                }
            }
            showRedeem('ok', d.msg, h);
        })
        .catch(function() {
            _redeeming = false;
            btn.disabled = false; btn.style.opacity = '';
            showRedeem('err', window.NX_REDEEM_LANG&&window.NX_REDEEM_LANG.conn_error||'Bağlantı hatası oluştu.');
        });
}
function showRedeem(type, msg, extra) {
    var el = document.getElementById('redeemResult');
    el.style.display = 'block';
    var ic = type === 'ok'
        ? '<svg style="width:15px;height:15px;flex-shrink:0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m5 13 4 4 10-11"/></svg>'
        : '<svg style="width:15px;height:15px;flex-shrink:0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>';
    var _msg = String(msg).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    var h = '<div style="background:' + (type==='ok'?'rgba(15,174,124,.1)':'rgba(228,87,107,.1)') + ';border:1px solid ' + (type==='ok'?'rgba(15,174,124,.3)':'rgba(228,87,107,.3)') + ';border-radius:12px;padding:13px 16px;font-size:13px;font-weight:700;color:' + (type==='ok'?'var(--ok)':'var(--danger)') + ';display:flex;align-items:center;gap:8px;margin-top:16px;">' + ic + ' ' + _msg + '</div>';
    if (extra) h += '<div style="display:flex;flex-direction:column;gap:8px;margin-top:10px;">' + extra + '</div>';
    el.innerHTML = h;
}
function copyRedeemKey(btn) {
    var code = btn.parentElement.querySelector('code');
    navigator.clipboard.writeText(code.textContent.trim())
        .then(function() { btn.style.color = 'var(--ok)'; setTimeout(function() { btn.style.color = ''; }, 1500); });
}
document.getElementById('redeemCodeInput').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') redeemCode();
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>