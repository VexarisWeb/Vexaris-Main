<?php
auth_require('/login');

$pageTitle   = 'Ayarlar';
$activePage  = '';
$activePanel = 'settings';
$u           = auth_user();
$db          = nexus_db();

$flashType = '';
$flashText = '';
if (isset($_GET['flash'])) {
    $parts = explode(':', urldecode($_GET['flash']), 2);
    $flashType = $parts[0] === 'error' ? 'error' : 'success';
    $flashText = $parts[1] ?? '';
}

include __DIR__ . '/../includes/header.php';
?>
<div class="panel-layout">

    <?php include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="panel-content">

        <?php if ($flashText): ?>
        <div class="auth-alert <?= $flashType==='success' ? 'auth-alert--ok' : 'auth-alert--error' ?>">
            <svg style="width:15px;height:15px;flex-shrink:0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><?= $flashType==='success' ? '<path d="m5 13 4 4 10-11"/>' : '<path d="M18 6 6 18M6 6l12 12"/>' ?></svg>
            <?= e($flashText) ?>
        </div>
        <?php endif; ?>

        <!-- ── Avatar ── -->
        <div class="panel-card">
            <h2 class="panel-card-title"><svg style="color:var(--brand)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="4"/><circle cx="12" cy="12" r="4"/></svg><?= __('panel.avatar') ?></h2>
            <p class="panel-card-desc"><?= __('panel.avatar_desc') ?></p>

            <form method="POST" action="/action.php" style="margin-top:18px;">
                <input type="hidden" name="action" value="avatar_preset">
                <?= csrf_field() ?>
                <div style="display:flex;gap:12px;flex-wrap:wrap;">
                    <?php
                    $presets = [
                        '/images/avatars/default.svg',
                        'https://minotar.net/avatar/mustafa8907.png',
                        'https://minotar.net/avatar/MHF_Alex.png',
                    ];
                    foreach ($presets as $i => $p): ?>
                    <label style="cursor:pointer;display:flex;align-items:center;gap:8px;border:1.5px solid <?= $u['avatar']===$p ? 'var(--brand)' : 'var(--line)' ?>;border-radius:14px;padding:10px 12px;background:var(--bg-soft);transition:border-color .15s;">
                        <input type="radio" name="preset_url" value="<?= $p ?>" <?= $u['avatar']===$p ? 'checked' : '' ?> style="accent-color:var(--brand);">
                        <img src="<?= $p ?>" alt="Preset <?= $i+1 ?>" style="width:36px;height:36px;border-radius:10px;image-rendering:pixelated;">
                    </label>
                    <?php endforeach; ?>
                </div>
                <button type="submit" class="btn btn-primary btn-sm" style="margin-top:14px;"><?= __('panel.apply_avatar') ?></button>
            </form>

            <div style="height:1px;background:var(--line);margin:24px 0;"></div>

            <form method="POST" action="/action.php" enctype="multipart/form-data" onsubmit="if(!document.getElementById('avatar_file_input').files.length){alert(window.NX_SETTINGS_LANG&&window.NX_SETTINGS_LANG.pick_file||'Lütfen bir dosya seçin.');return false;}">
                <input type="hidden" name="action" value="avatar_upload">
                <?= csrf_field() ?>
                <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                    <label for="avatar_file_input" style="display:inline-flex;align-items:center;gap:8px;padding:11px 18px;border-radius:11px;background:var(--brand-soft);color:var(--brand-deep);font-size:13px;font-weight:800;cursor:pointer;">
                        <svg style="width:15px;height:15px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2M12 3v13m-4-4 4 4 4-4"/></svg>
                        <?= __('panel.choose_file') ?>
                    </label>
                    <input type="file" id="avatar_file_input" name="avatar_file"
                           accept="image/png,image/jpeg,image/webp" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;opacity:0;"
                           onchange="document.getElementById('avatar-filename').textContent=this.files[0]?.name??'';">
                    <div>
                        <p style="font-size:13px;font-weight:600;color:var(--muted);">PNG, JPG veya WebP — maks. 1 MB</p>
                        <p id="avatar-filename" style="font-size:12px;color:var(--brand);margin-top:3px;"></p>
                    </div>
                </div>
                <button type="submit" class="btn btn-ghost btn-sm" style="margin-top:16px;"><?= __('panel.upload') ?></button>
            </form>
        </div>

        <!-- ── Şifre Değiştir ── -->
        <div class="panel-card">
            <h2 class="panel-card-title"><svg style="color:var(--warn)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><?= __('panel.change_password') ?></h2>
            <p class="panel-card-desc"><?= __('panel.password_desc') ?></p>

            <form method="POST" action="/action.php" novalidate style="margin-top:18px;max-width:420px;">
                <input type="hidden" name="action" value="change_password">
                <?= csrf_field() ?>

                <div class="form-group">
                    <label class="form-label"><?= __('panel.current_password') ?></label>
                    <div class="form-input-icon-wrap">
                        <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
                        <input type="password" name="current_password" class="form-input" placeholder="••••••••" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label"><?= __('panel.new_password') ?></label>
                    <div class="form-input-icon-wrap">
                        <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 6v5c0 5 3.4 8 8 10 4.6-2 8-5 8-10V6z"/></svg>
                        <input type="password" name="new_password" class="form-input" placeholder="••••••••" required minlength="8">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label"><?= __('panel.new_password_repeat') ?></label>
                    <div class="form-input-icon-wrap">
                        <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 6v5c0 5 3.4 8 8 10 4.6-2 8-5 8-10V6z"/></svg>
                        <input type="password" name="confirm_password" class="form-input" placeholder="••••••••" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-sm" style="margin-top:18px;"><?= __('panel.update_password') ?></button>
            </form>
        </div>

        <!-- ── Mail Değiştir ── -->
        <div class="panel-card">
            <h2 class="panel-card-title"><svg style="color:var(--ok)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3 7 9 6 9-6"/></svg><?= __('panel.change_email') ?></h2>
            <p class="panel-card-desc">Mevcut: <strong><?= e($u['email']) ?></strong></p>

            <form method="POST" action="/action.php" novalidate style="margin-top:18px;max-width:420px;">
                <input type="hidden" name="action" value="change_email">
                <?= csrf_field() ?>
                <div class="form-group">
                    <label class="form-label">Yeni E-posta Adresi</label>
                    <div class="form-input-icon-wrap">
                        <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3 7 9 6 9-6"/></svg>
                        <input type="email" name="new_email" class="form-input" placeholder="yeni@mail.com" required maxlength="255">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label"><?= __('panel.email_verify_password') ?></label>
                    <div class="form-input-icon-wrap">
                        <svg class="form-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
                        <input type="password" name="current_password" class="form-input" placeholder="••••••••" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-ghost btn-sm" style="margin-top:18px;"><?= __('panel.update_email') ?></button>
            </form>
        </div>

    </main>
</div>
<script>window.NX_SETTINGS_LANG = <?= json_encode(['pick_file'=>__('panel.pick_file')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>