<?php
$pageTitle  = __('auth.verify_title');
$activePage = 'login';
$seoKey     = 'login';
$notice     = '';

$token = trim($_GET['token'] ?? '');

if ($token !== '') {
    try {
        $db = nexus_db();
        $st = $db->prepare('SELECT email FROM email_verifications WHERE token=? AND used=0 AND expires_at > NOW() LIMIT 1');
        $st->execute([$token]);
        $ver = $st->fetch();
        if (!$ver) {
            $notice = '<h1 class="auth-card-title">'.__('auth.verify_bad').'</h1><p class="auth-card-subtitle">'.__('auth.verify_bad_sub').'</p>';
        } else {
            $st2 = $db->prepare('SELECT id FROM users WHERE email=? LIMIT 1');
            $st2->execute([$ver['email']]);
            $user = $st2->fetch();
            if ($user) {
                $db->prepare('UPDATE users SET email_verified=1 WHERE id=?')->execute([$user['id']]);
                $db->prepare('UPDATE email_verifications SET used=1 WHERE token=?')->execute([$token]);
                $notice = '<h1 class="auth-card-title">'.__('auth.verify_ok').'</h1><p class="auth-card-subtitle">'.__('auth.verify_ok_sub').'</p>';
            } else {
                $db->prepare('UPDATE email_verifications SET used=1 WHERE token=?')->execute([$token]);
                $notice = '<h1 class="auth-card-title">'.__('auth.verify_nouser').'</h1><p class="auth-card-subtitle">'.__('auth.verify_nouser_sub').'</p>';
            }
        }
    } catch (\PDOException $e) {
        error_log('[NS] verify-email: '.$e->getMessage());
        $notice = '<h1 class="auth-card-title">'.__('auth.verify_err').'</h1><p class="auth-card-subtitle">'.__('auth.verify_err_sub').'</p>';
    }
} else {
    $notice = '<h1 class="auth-card-title">'.__('auth.verify_bad').'</h1><p class="auth-card-subtitle">'.__('auth.verify_needlink').'</p>';
}

include __DIR__ . '/includes/header.php';
?>
<main class="auth-shell">
  <div class="auth-card">
    <div class="auth-card-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>
    </div>
    <?= $notice ?>
    <p class="auth-links" style="margin-top:16px;">
      <a href="/login"><?= __('auth.do_login') ?></a>
    </p>
  </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>