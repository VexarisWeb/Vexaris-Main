<?php
$pageTitle  = __('err.e404_title');
$activePage = '';
$seoKey     = '404';
include __DIR__ . '/includes/header.php';
?>
<main style="flex:1;display:flex;align-items:center;justify-content:center;padding:60px 24px;text-align:center;">
    <div style="max-width:480px;">
        <div style="width:72px;height:72px;border-radius:20px;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;font-size:32px;color:#f87171;margin:0 auto 24px;">
            <i class="fa-solid fa-triangle-exclamation"></i>
        </div>
        <h1 style="font-size:56px;font-weight:900;line-height:1;margin-bottom:8px;background:linear-gradient(135deg,#f87171,#fbc853);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">404</h1>
        <p style="font-size:17px;font-weight:700;margin-bottom:6px;"><?= __('err.e404_title') ?></p>
        <p style="font-size:14px;color:var(--text-muted);font-weight:500;margin-bottom:32px;line-height:1.7;"><?= __('err.e404_sub') ?></p>
        <div style="display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;">
            <a href="/" class="btn-custom btn-indigo">
                <i class="fa-solid fa-house btn-icon"></i> <?= __('err.e404_home') ?>
            </a>
            <a href="/products" class="btn-custom btn-yellow">
                <i class="fa-solid fa-store btn-icon"></i> <?= __('err.e404_store') ?>
            </a>
        </div>
    </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
