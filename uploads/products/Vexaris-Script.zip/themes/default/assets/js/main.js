/**
 * themes/default/assets/js/main.js
 * NexusSetups — Tema Ana JavaScript Dosyası
 */

'use strict';

/* ============================================================
   Mobil Navbar Toggle
   ============================================================ */
(function () {
    const toggle   = document.getElementById('navToggle');
    const links    = document.getElementById('navLinks');
    const actions  = document.getElementById('navActions');

    if (!toggle) return;

    toggle.addEventListener('click', function () {
        const isOpen = links.classList.toggle('open');
        actions.classList.toggle('open', isOpen);

        // İkon değiştir
        const icon = toggle.querySelector('i');
        icon.className = isOpen ? 'fa-solid fa-xmark' : 'fa-solid fa-bars';
        toggle.setAttribute('aria-expanded', isOpen.toString());
    });

    // Dışarıya tıklandığında kapat
    document.addEventListener('click', function (e) {
        if (!toggle.contains(e.target) && !links.contains(e.target) && !actions.contains(e.target)) {
            links.classList.remove('open');
            actions.classList.remove('open');
            const icon = toggle.querySelector('i');
            if (icon) icon.className = 'fa-solid fa-bars';
            toggle.setAttribute('aria-expanded', 'false');
        }
    });
})();

/* ============================================================
   Aktif Sayfa Linkini Vurgula (Fallback — PHP aktaramazsa)
   ============================================================ */
(function () {
    const currentPath = window.location.pathname.replace(/\/$/, '') || '/';
    document.querySelectorAll('.navbar-links a').forEach(function (link) {
        const linkPath = new URL(link.href, window.location.origin).pathname.replace(/\/$/, '') || '/';
        if (linkPath === currentPath) {
            link.classList.add('active');
        }
    });
})();

/* ============================================================
   Scroll ile Navbar Gölgesi
   ============================================================ */
(function () {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;

    window.addEventListener('scroll', function () {
        if (window.scrollY > 20) {
            navbar.style.boxShadow = '0 4px 30px rgba(0,0,0,0.4)';
        } else {
            navbar.style.boxShadow = 'none';
        }
    }, { passive: true });
})();

/* ============================================================
   Smooth Scroll (anchor linkleri için)
   ============================================================ */
document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

/* ============================================================
   Navbar Kullanıcı Dropdown
   ============================================================ */
(function () {
    const btn  = document.getElementById('userDropdownBtn');
    const menu = document.getElementById('userDropdownMenu');
    if (!btn || !menu) return;

    btn.addEventListener('click', function (e) {
        e.stopPropagation();
        var cartPanel = document.getElementById('cartPanel');
        if (cartPanel) { cartPanel.style.display = 'none'; cartPanel.classList.remove('open'); }
        const open = menu.classList.toggle('open');
        btn.setAttribute('aria-expanded', open.toString());
    });

    document.addEventListener('click', function (e) {
        if (!btn.contains(e.target) && !menu.contains(e.target)) {
            menu.classList.remove('open');
            btn.setAttribute('aria-expanded', 'false');
        }
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            menu.classList.remove('open');
            btn.setAttribute('aria-expanded', 'false');
        }
    });
})();

/* ============================================================
   Sepet İşlemleri
   ============================================================ */
var ACTIONS_URL = '/action.php';

function showToast(msg, ok) {
    var t = document.getElementById('toast');
    if (!t) {
        t = document.createElement('div');
        t.id = 'toast';
        document.body.appendChild(t);
    }
    t.className = 'toast-show ' + (ok ? 'toast-success' : 'toast-error');
    t.innerHTML = '<i class="fa-solid fa-' + (ok ? 'circle-check' : 'circle-xmark') + '"></i> ';
    t.appendChild(document.createTextNode(msg));
    clearTimeout(t._timer);
    t._timer = setTimeout(function () {
        t.classList.remove('toast-show');
        t.classList.add('toast-hide');
    }, 3500);
}

function nxCloseConfirm() {
    var b = document.getElementById('nxConfirm');
    if (b) b.style.display = 'none';
}

function nxCartConfirmDialog(total, onOk) {
    var L = window.NX_LANG || {};
    var fmt = window.nxFmt ? window.nxFmt(total) : String(total);
    var box = document.getElementById('nxConfirm');
    if (!box) {
        box = document.createElement('div');
        box.id = 'nxConfirm';
        box.style.cssText = 'position:fixed;inset:0;z-index:100003;background:rgba(0,0,0,.78);align-items:center;justify-content:center;padding:18px;display:none;';
        box.addEventListener('click', function (e) { if (e.target === box) nxCloseConfirm(); });
        document.body.appendChild(box);
    }
    box.innerHTML = '';
    var card = document.createElement('div');
    card.style.cssText = 'width:100%;max-width:390px;background:#0f1520;border:1px solid rgba(99,102,241,.45);border-radius:16px;padding:22px;text-align:center;font-family:inherit;';
    var title = document.createElement('div');
    title.style.cssText = 'font-size:16px;font-weight:900;color:#a5b4fc;margin-bottom:10px;';
    title.textContent = L.confirm_title || 'Ödeme Onayı';
    var msg = document.createElement('div');
    msg.style.cssText = 'font-size:13px;color:#c9d1d9;font-weight:600;line-height:1.6;margin-bottom:18px;';
    msg.textContent = (L.confirm_text || 'Bakiyenizden {total} düşecek. Onaylıyor musunuz?').split('{total}').join(fmt);
    var yes = document.createElement('button');
    yes.type = 'button';
    yes.style.cssText = 'width:100%;background:#4ade80;color:#06281a;border:none;border-radius:11px;padding:13px;font-size:14px;font-weight:900;cursor:pointer;font-family:inherit;';
    yes.textContent = L.confirm_yes || 'Onaylıyorum';
    yes.onclick = function () { nxCloseConfirm(); if (onOk) onOk(); };
    var no = document.createElement('button');
    no.type = 'button';
    no.style.cssText = 'width:100%;margin-top:8px;background:transparent;border:none;color:#94a3b8;font-size:12px;font-weight:700;cursor:pointer;padding:8px;font-family:inherit;';
    no.textContent = L.confirm_no || 'Vazgeç';
    no.onclick = nxCloseConfirm;
    card.appendChild(title);
    card.appendChild(msg);
    card.appendChild(yes);
    card.appendChild(no);
    box.appendChild(card);
    box.style.display = 'flex';
}

function nxCloseCartUi() {
    var cp = document.getElementById('cartPanel');
    if (cp) { cp.style.display = 'none'; cp.classList.remove('open'); }
    var cm = document.getElementById('cartModal');
    if (cm) cm.classList.add('hidden');
    document.body.style.overflow = '';
}

async function nxCartPay() {
    var L = window.NX_LANG || {};
    var fail = L.error || 'Hata oluştu.';
    try {
        var fd = new FormData(); fd.append('action', 'cart_state');
        var r = await fetch(ACTIONS_URL, { method: 'POST', body: fd });
        var s = await r.json();
        if (!s || !s.ok) { showToast((s && s.msg) || fail, false); return; }
        if (s.empty) { showToast(L.cart_empty || 'Sepetiniz boş.', false); return; }
        if (s.low_balance) { nxCloseCartUi(); vxGo('/shop/payment'); return; }
        nxCartConfirmDialog(s.total, function () { nxCartPayNow(); });
    } catch (e) { showToast(fail, false); }
}

async function nxCartPayNow() {
    var fail = (window.NX_LANG && window.NX_LANG.error) || 'Hata oluştu.';
    try {
        var fd = new FormData(); fd.append('action', 'checkout');
        var r = await fetch(ACTIONS_URL, { method: 'POST', body: fd });
        var d = await r.json();
        if (d && d.redirect) { nxCloseCartUi(); vxGo(d.redirect); return; }
        if (d.ok) {
            nxCloseCartUi();
            showToast(d.msg, true);
            setTimeout(function () { location.reload(); }, 1200);
            return;
        }
        showToast(d.msg || fail, false);
    } catch (e) { showToast(fail, false); }
}

async function refreshCartPanel() {
    var panel = document.getElementById('cartPanel');
    if (!panel) return;
    var fd = new FormData();
    fd.append('action','cart_panel_html');
    try {
        var r = await fetch(ACTIONS_URL, {method:'POST',body:fd});
        var d = await r.json();
        if (!d.ok || !d.html) return;
        var tmp = document.createElement('div');
        tmp.innerHTML = d.html;
        var newBody = tmp.querySelector('#cartPanelBody');
        var newFooter = tmp.querySelector('#cartPanelFooter');
        var oldBody = document.getElementById('cartPanelBody');
        var oldFooter = document.getElementById('cartPanelFooter');
        var content = document.querySelector('#cartPanel .cart-modal-content');
        if (newBody && oldBody) oldBody.replaceWith(newBody);
        else if (newBody && content) content.appendChild(newBody);
        if (newFooter && oldFooter) oldFooter.replaceWith(newFooter);
        else if (newFooter && content) content.appendChild(newFooter);
        else if (oldFooter) oldFooter.remove();
        if (d.cart_count !== undefined) {
            var badge = document.getElementById('navCartBadge');
            if (badge) {
                if (d.cart_count > 0) badge.textContent = d.cart_count;
                else badge.remove();
            }
        }
    } catch (e) {}
}

async function cartAdd(pid) {
    var fd = new FormData();
    fd.append('action','cart_add');
    fd.append('product_id', pid);
    try {
        var r = await fetch(ACTIONS_URL, {method:'POST',body:fd});
        var d = await r.json();
        if (d.ok && d.cart_count !== undefined) {
            var badge = document.getElementById('navCartBadge');
            if (badge) {
                if (d.cart_count > 0) badge.textContent = d.cart_count;
                else badge.remove();
            }
            refreshCartPanel();
        }
        showToast(d.msg, d.ok);
    } catch (e) { showToast('Hata oluştu.', false); }
}

window._cartPending = window._cartPending || {};
window._cartBusy = window._cartBusy || {};

function cartUpdateQty(pid, delta) {
    var id = pid;
    window._cartPending[id] = window._cartPending[id] || { d: 0, r: false };
    if (delta === 0) { window._cartPending[id].r = true; window._cartPending[id].d = 0; }
    else window._cartPending[id].d += delta;
    if (window._cartBusy[id]) return;
    cartProcessQty(id);
}

async function cartProcessQty(id) {
    window._cartBusy[id] = true;
    var pending = window._cartPending[id] || { d: 0, r: false };
    window._cartPending[id] = null;
    var delta = pending.r ? 0 : pending.d;
    var doRemove = pending.r;

    var item = document.getElementById('cartPanelItem-' + id) || document.getElementById('cartItem-' + id);
    var qtyEl = document.getElementById('panelQty-' + id) || document.getElementById('qty-' + id) || document.getElementById('navQty-' + id);
    var prevQty = parseInt(qtyEl ? qtyEl.textContent : '1');
    var newQty = doRemove ? 0 : Math.max(1, prevQty + delta);
    if (!doRemove && newQty === prevQty) {
        window._cartBusy[id] = false;
        if (window._cartPending[id]) cartProcessQty(id);
        return;
    }
    if (qtyEl) qtyEl.textContent = newQty;
    var fd = new FormData();
    fd.append('action','cart_update_qty');
    fd.append('product_id', id);
    fd.append('quantity', newQty);
    try {
        var r = await fetch(ACTIONS_URL, {method:'POST',body:fd});
        var d = await r.json();
        if (d.ok) {
            var panelTotal = document.getElementById('cartPanelTotalPrice');
            if (panelTotal && d.cart_total !== undefined) panelTotal.textContent = window.nxFmt(d.cart_total);
            var shopTotal = document.getElementById('cartTotal');
            if (shopTotal && d.cart_total !== undefined) shopTotal.textContent = window.nxFmt(d.cart_total);
            var subTotal = document.getElementById('cartSubtotal');
            if (subTotal && d.cart_total !== undefined) subTotal.textContent = window.nxFmt(d.cart_total);
            if (newQty < 1 && item) {
                item.style.transition = 'opacity .3s';
                item.style.opacity = '0';
                setTimeout(function () { if (item.parentNode) item.remove(); checkCartEmpty(); }, 300);
            }
            if (d.empty) {
                var body = document.getElementById('cartPanelBody');
                if (body) body.innerHTML = '<div class="cart-empty"><i class="fa-solid fa-cart-plus"></i><p>Sepetiniz boş.</p></div>';
                var footer = document.getElementById('cartPanelFooter');
                if (footer) footer.remove();
            }
            var modalItems = document.getElementById('cartItems');
            if (modalItems && !modalItems.querySelector('.cart-item')) {
                modalItems.innerHTML = '<p class="text-center text-slate-500 text-sm py-8">Sepetiniz boş.</p>';
                var modalFooter = document.getElementById('cartFooter');
                if (modalFooter) modalFooter.remove();
            }
            if (d.cart_count !== undefined) {
                var badge = document.getElementById('navCartBadge');
                if (badge) {
                    if (d.cart_count > 0) badge.textContent = d.cart_count;
                    else badge.remove();
                }
            }
        } else {
            if (qtyEl) qtyEl.textContent = prevQty;
        }
    } catch (e) {
        if (qtyEl) qtyEl.textContent = prevQty;
        showToast('Hata oluştu.', false);
    } finally {
        window._cartBusy[id] = false;
        if (window._cartPending[id]) cartProcessQty(id);
    }
}

function checkCartEmpty() {
    var container = document.getElementById('cartPanelItems');
    if (!container) return;
    var items = container.querySelectorAll('.cart-item');
    if (items.length < 1) {
        var body = document.getElementById('cartPanelBody');
        if (body) body.innerHTML = '<div class="cart-empty"><i class="fa-solid fa-cart-plus"></i><p>Sepetiniz boş.</p></div>';
        var footer = document.getElementById('cartPanelFooter');
        if (footer) footer.remove();
    }
}

async function cartCheckout() {
    return nxCartPay();
}

var _buyNowPid = 0;
var _buyNowMethod = '';
function buyNow(pid) {
    _buyNowPid = pid;
    _buyNowMethod = '';
    var m = document.getElementById('buyNowModal');
    if (!m) { buyNowDirect(pid, ''); return; }
    var picker = document.getElementById('buyNowMethods');
    if (picker) {
        var btns = picker.querySelectorAll('[data-bn-method]');
        for (var i = 0; i < btns.length; i++) btns[i].classList.remove('active');
        var bal = picker.querySelector('[data-bn-method="balance"]');
        if (bal) bal.classList.add('active');
        _buyNowMethod = 'balance';
    }
    m.classList.remove('hidden');
    m.style.display = 'flex';
}
function buyNowPick(method, el) {
    _buyNowMethod = method || 'balance';
    var picker = document.getElementById('buyNowMethods');
    if (picker) {
        var btns = picker.querySelectorAll('[data-bn-method]');
        for (var i = 0; i < btns.length; i++) btns[i].classList.remove('active');
    }
    if (el) el.classList.add('active');
}
function closeBuyNowModal() {
    var m = document.getElementById('buyNowModal');
    if (!m) return;
    m.style.display = 'none';
    m.classList.add('hidden');
}
async function buyNowDirect(pid, method) {
    var fd = new FormData();
    fd.append('action', 'buy_now');
    fd.append('product_id', pid);
    if (method && method !== 'balance') fd.append('method', method);
    try {
        var r = await fetch(ACTIONS_URL, { method: 'POST', body: fd });
        var d = await r.json();
        if (d.ok && d.html) {
            document.open();
            document.write(d.html);
            document.close();
        } else if (d && d.redirect) {
            nxCloseCartUi();
            vxGo(d.redirect);
        } else {
            showToast(d.msg, d.ok);
            if (d.ok) setTimeout(function () { location.reload(); }, 1200);
        }
    } catch (e) { showToast('Hata oluştu.', false); }
}
async function confirmBuyNow() {
    if (!_buyNowPid) return;
    var btn = document.getElementById('buyNowConfirmBtn');
    if (btn) btn.disabled = true;
    var method = _buyNowMethod || 'balance';
    closeBuyNowModal();
    await buyNowDirect(_buyNowPid, method);
    if (btn) btn.disabled = false;
}
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeBuyNowModal();
});

/* ============================================================
   Sepet Modal (Popup)
   ============================================================ */
(function () {
    var panel = document.getElementById('cartPanel');
    var closeBtn = document.getElementById('cartCloseBtn');
    var backdrop = document.getElementById('cartBackdrop');
    if (!panel) return;

    panel.style.display = 'none';

    window.toggleCartPanel = function (e) {
        if (e) e.stopPropagation();
        var menu = document.getElementById('userDropdownMenu');
        if (menu) menu.classList.remove('open');
        var userBtn = document.getElementById('userDropdownBtn');
        if (userBtn) userBtn.setAttribute('aria-expanded', 'false');
        if (panel.classList.contains('open')) {
            panel.style.display = 'none';
            panel.classList.remove('open');
            document.body.style.overflow = '';
            return;
        }
        panel.style.display = 'flex';
        panel.classList.add('open');
        document.body.style.overflow = 'hidden';
    };

    if (closeBtn) closeBtn.addEventListener('click', function (e) { e.stopPropagation(); if (panel.classList.contains('open')) window.toggleCartPanel(); });
    if (backdrop) backdrop.addEventListener('click', function (e) { e.stopPropagation(); if (panel.classList.contains('open')) window.toggleCartPanel(); });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && panel.classList.contains('open')) window.toggleCartPanel();
    });
})();


