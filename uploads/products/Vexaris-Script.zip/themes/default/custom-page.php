<?php
defined('NEXUS_BOOT') or die;

$cpSlug = trim((string)($GLOBALS['custom_page_slug'] ?? ''));
$pageRow = null;
$nxViewId = 0;
$pdb = nexus_db();

if ($cpSlug !== '' && $pdb) {
    try {
        $st = $pdb->prepare('SELECT * FROM custom_pages WHERE slug=? AND status="published" LIMIT 1');
        $st->execute([$cpSlug]);
        $pageRow = $st->fetch();
    } catch (\PDOException $e) {
        error_log('[NS] custom-page: ' . $e->getMessage());
    }
}

if (function_exists('feature_active') && !feature_active('custom_pages')) $pageRow = null;

if (!$pageRow) {
    http_response_code(404);
    include ROOT_PATH . '/themes/default/includes/header.php';
    ?>
    <main style="min-height:80vh;padding:80px 24px;max-width:860px;margin:0 auto;text-align:center;">
        <div style="font-size:56px;margin-bottom:16px;"><i class="fa-solid fa-file-circle-question" style="color:var(--dim);"></i></div>
        <h1 style="font-size:24px;font-weight:900;margin-bottom:8px;"><?= __('page.notfound') ?></h1>
        <p style="color:var(--muted);font-size:14px;margin-bottom:24px;"><?= __('page.notfound_sub') ?></p>
        <a href="/" class="btn-custom btn-indigo" style="display:inline-flex;"><i class="fa-solid fa-house btn-icon"></i> <?= __('page.home') ?></a>
    </main>
    <?php
    include ROOT_PATH . '/themes/default/includes/footer.php';
    exit;
}

$pageTitle = $pageRow['title'];
$_headerMetaDescription = (string)($pageRow['meta_description'] ?? '');

$nxSessionKey = session_id() ?: (md5(($_SERVER['REMOTE_ADDR'] ?? '') . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? '')));
$nxUserId = auth_check() ? (int)auth_user()['id'] : null;
$nxIp = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
$nxUa = strtolower(trim((string)($_SERVER['HTTP_USER_AGENT'] ?? '')));
$nxIsBot = $nxUa !== '' && preg_match('/bot|crawl|spider|slurp|mediapartners|baidu|sogou|exabot|facebot|ia_archiver|semrush|ahrefs|mj12|dotbot|petal|bytespider|gptbot|ccbot|claude|anthropic|yandex|duckduckbot|bingpreview|facebookexternalhit|twitterbot|linkedinbot|embedly|quora|pinterest|slackbot|telegrambot|discordbot|whatsapp|archive|fetch|monitor|uptime|pingdom/i', $nxUa);

try {
    if (!$nxIsBot) {
        $nxDup = $pdb->prepare('SELECT id FROM custom_page_views WHERE page_id=? AND session_key=? AND entered_at > DATE_SUB(NOW(), INTERVAL 30 MINUTE) ORDER BY id DESC LIMIT 1');
        $nxDup->execute([(int)$pageRow['id'], $nxSessionKey]);
        $nxViewId = (int)($nxDup->fetchColumn() ?: 0);
        if ($nxViewId === 0) {
            $vi = $pdb->prepare('INSERT INTO custom_page_views (page_id,session_key,user_id,ip,entered_at) VALUES (?,?,?,?,NOW())');
            $vi->execute([(int)$pageRow['id'], $nxSessionKey, $nxUserId, $nxIp]);
            $nxViewId = (int)$pdb->lastInsertId();
        }
    }
} catch (\PDOException $e) {
    error_log('[NS] custom-page view: ' . $e->getMessage());
}

include ROOT_PATH . '/themes/default/includes/header.php';
?>

<?php $_cpIsHtml = (($pageRow['page_type'] ?? 'blog') === 'html'); ?>
<?php if ($_cpIsHtml): ?>
<main style="min-height:80vh;padding:0 0 72px;">
    <div style="width:100%;"><?= $pageRow['content'] ?></div>
</main>
<?php else: ?>
<main style="min-height:80vh;padding:48px 24px 72px;max-width:1200px;margin:0 auto;">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:24px;flex-wrap:wrap;">
        <a href="/" style="display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:10px;font-size:13px;font-weight:700;color:var(--muted);background:var(--bg-surface);border:1px solid var(--border);text-decoration:none;">
            <i class="fa-solid fa-arrow-left"></i> Ana Sayfa
        </a>
    </div>

    <div style="width:100%;background:var(--bg-card);border:1px solid var(--border);border-radius:16px;padding:40px 44px;line-height:1.8;box-sizing:border-box;">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:28px;padding-bottom:18px;border-bottom:1px solid var(--border);flex-wrap:wrap;">
            <div style="width:44px;height:44px;border-radius:11px;background:rgba(99,102,241,.12);display:flex;align-items:center;justify-content:center;font-size:18px;color:#818cf8;flex-shrink:0;">
                <i class="fa-solid fa-file-lines"></i>
            </div>
            <div style="flex:1;min-width:200px;">
                <h2 style="font-size:22px;font-weight:900;"><?= e($pageRow['title']) ?></h2>
                <p style="font-size:11px;color:var(--muted);"><?= __('page.updated') ?> <?= e($pageRow['updated_at']) ?></p>
            </div>
        </div>
        <div style="color:var(--text);font-size:15px;width:100%;"><?= $pageRow['content'] ?></div>
    </div>
</main>
<?php endif; ?>

<script>
(function(){
    var viewId = <?= (int)$nxViewId ?>;
    if (!viewId) return;
    var t0 = Date.now();
    function send() {
        var d = Math.round((Date.now() - t0) / 1000);
        if (navigator.sendBeacon) {
            var fd = new FormData();
            fd.append('action','page_leave');
            fd.append('view_id', String(viewId));
            fd.append('duration', String(d));
            var ct = document.querySelector('meta[name="csrf-token"]');
            if (ct) fd.append('_csrf_token', ct.getAttribute('content'));
            navigator.sendBeacon('/action.php', fd);
        }
    }
    window.addEventListener('pagehide', send);
    document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') send(); });
    setInterval(send, 20000);
})();
</script>

<?php include ROOT_PATH . '/themes/default/includes/footer.php'; ?>
