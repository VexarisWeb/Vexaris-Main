<?php
auth_redirect_if_logged_in('/');

$pageTitle  = __('auth.forgot_title');
$activePage = 'login';
$seoKey     = 'login';
$msg        = '';
$error      = '';

csrf_verify();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_captcha()) {
        $error = __('auth.captcha_fail');
    } else {
        $result = auth_request_password_reset($_POST['email'] ?? '');
        if ($result['ok']) {
            $msg = $result['msg'];
        } else {
            $error = $result['msg'];
        }
    }
}

$intSettings = [];
try {
    $intDb = nexus_db();
    $intSt = $intDb->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'");
    while ($intR = $intSt->fetch()) $intSettings[$intR['key']] = $intR['value'];
} catch (\PDOException $e) { error_log('[NS] forgot int: '.$e->getMessage()); }
$cfCaptcha = ($intSettings['int_cf_captcha_enabled'] ?? '0') === '1' && !empty($intSettings['int_cf_captcha_site_key']);
$recaptcha = ($intSettings['int_recaptcha_enabled'] ?? '0') === '1' && !empty($intSettings['int_recaptcha_site_key']);

include __DIR__ . '/includes/header.php';
?>
<main class="auth-wrapper">
    <div class="auth-card">

        <div class="auth-card-icon indigo">
            <i class="fa-solid fa-key"></i>
        </div>

        <h1 class="auth-card-title"><?= __('auth.forgot_h1') ?></h1>
        <p class="auth-card-subtitle"><?= __('auth.forgot_sub') ?></p>

        <?php if ($error): ?>
        <div class="auth-alert-error">
            <i class="fa-solid fa-circle-xmark"></i> <?= e($error) ?>
        </div>
        <?php endif; ?>

        <?php if ($msg): ?>
        <div class="auth-alert-success">
            <i class="fa-solid fa-circle-check"></i> <?= e($msg) ?>
        </div>
        <?php else: ?>

        <form method="POST" action="/forgot-password" autocomplete="on" novalidate>
        <?= csrf_field() ?>

            <div class="form-group">
                <label for="email" class="form-label">E-posta Adresi</label>
                <div class="input-wrapper">
                    <i class="fa-solid fa-envelope input-icon"></i>
                    <input type="email" id="email" name="email" class="form-input"
                        placeholder="kullanici@ornek.com" autocomplete="email" required maxlength="255"
                        value="<?= e($_POST['email'] ?? '') ?>">
                </div>
            </div>

            <?php if ($cfCaptcha): ?>
            <div class="form-group">
                <div class="cf-turnstile" data-sitekey="<?= e($intSettings['int_cf_captcha_site_key']) ?>" data-theme="dark" style="margin-top:4px;"></div>
                <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
            </div>
            <?php elseif ($recaptcha): ?>
            <div class="form-group">
                <div class="g-recaptcha" data-sitekey="<?= e($intSettings['int_recaptcha_site_key']) ?>" data-theme="dark" style="margin-top:4px;"></div>
                <script src="https://www.google.com/recaptcha/api.js" async defer></script>
            </div>
            <?php endif; ?>

            <button type="submit" class="btn-custom btn-indigo btn-full" style="margin-top:8px;">
                <i class="fa-solid fa-paper-plane btn-icon"></i> <?= __('auth.forgot_btn') ?>
            </button>

        </form>

        <?php endif; ?>

        <p class="auth-redirect">
            <?= __('auth.forgot_remember') ?> <a href="/login"><i class="fa-solid fa-right-to-bracket" style="font-size:11px;"></i> <?= __('auth.do_login') ?></a>
        </p>

    </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>