<?php
$panelItems = $panelItems ?? [];
$panelTotal = $panelTotal ?? 0;
?>
<div class="cart-modal-body" id="cartPanelBody">
    <?php if (empty($panelItems)): ?>
    <div class="cart-empty">
        <i class="fa-solid fa-cart-plus"></i>
        <p><?= __('cart.empty_short') ?></p>
    </div>
    <?php else: ?>
    <div class="cart-items" id="cartPanelItems">
        <?php foreach ($panelItems as $_pci): ?>
        <div class="cart-item" id="cartPanelItem-<?= $_pci['product_id'] ?>">
            <?php if ($_pci['image_url']): ?>
             <img src="<?= e($_pci['image_url']) ?>" class="cart-item-img" width="80" height="80" alt="">
            <?php else: ?>
            <div class="cart-item-img-placeholder"><i class="fa-solid fa-cube"></i></div>
            <?php endif; ?>
            <div class="cart-item-info">
                <p class="cart-item-name"><?= e($_pci['name']) ?></p>
                <p class="cart-item-price"><?= fmt_money($_pci['price']) ?></p>
            </div>
            <div class="cart-item-qty">
                <button onclick="cartUpdateQty(<?= (int)$_pci['product_id'] ?>,-1)" class="cart-qty-btn">−</button>
                <span class="cart-qty-val" id="panelQty-<?= (int)$_pci['product_id'] ?>"><?= (int)$_pci['quantity'] ?></span>
                <button onclick="cartUpdateQty(<?= (int)$_pci['product_id'] ?>,1)" class="cart-qty-btn">+</button>
            </div>
            <button onclick="cartUpdateQty(<?= (int)$_pci['product_id'] ?>,0)" class="cart-item-remove"><i class="fa-solid fa-trash"></i></button>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php if (!empty($panelItems)): ?>
<div class="cart-modal-footer" id="cartPanelFooter">
    <div class="cart-modal-total">
        <span><?= __('cart.total') ?></span>
        <span class="cart-total-price" id="cartPanelTotalPrice"><?= fmt_money($panelTotal) ?></span>
    </div>
    <a href="/cart" class="cart-checkout-btn" style="display:flex;align-items:center;justify-content:center;text-decoration:none;">
        <i class="fa-solid fa-cart-shopping"></i> <?= __('cart.go') ?>
    </a>
</div>
<?php endif; ?>
