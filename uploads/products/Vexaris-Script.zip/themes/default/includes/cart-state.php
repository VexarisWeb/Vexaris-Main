<?php
defined('NEXUS_BOOT') or die('Direct access denied.');
if (!function_exists('coupon_discount_for_total')) require_once ROOT_PATH . '/actions/bootstrap-action.php';
$cartPageItems = [];
$cartPageSubtotal = 0.0;
$cartPageDiscount = 0.0;
$cartPageTotal = 0.0;
$cartPageCoupon = null;
$cartPageCount = 0;
try {
    $cpDb = nexus_db();
    if ($cpDb && auth_check()) {
        $cpUid = (int)auth_user()['id'];
        $cpSt = $cpDb->prepare('SELECT c.product_id,c.quantity,p.name,p.price,p.discount_percent,p.image_url FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? AND p.is_hidden=0 AND p.status="active" ORDER BY c.added_at DESC');
        $cpSt->execute([$cpUid]);
        $cartPageItems = $cpSt->fetchAll();
        foreach ($cartPageItems as &$cpIt) $cpIt['is_free'] = product_effective_price($cpIt['price'], $cpIt['discount_percent'] ?? 0) <= 0;
        unset($cpIt);
        $cartPageSubtotal = cart_effective_total($cartPageItems);
        if (function_exists('apply_filters')) $cartPageSubtotal = (float)apply_filters('checkout_total', $cartPageSubtotal, $cartPageItems);
        $cartPageSubtotal = round($cartPageSubtotal, 2);
        $cartPageCount = (int)array_sum(array_map(fn($i) => (int)$i['quantity'], $cartPageItems));
        $cpAp = coupon_resolve_for_pay($cpDb, $_SESSION['applied_coupon'] ?? null, $cpUid);
        if ($cpAp) {
                $cartPageDiscount = round(coupon_discount_for_total($cpAp, $cartPageSubtotal), 2);
                $ctp = $cpAp['type'] ?? ''; $cval = (float)($cpAp['value'] ?? 0);
                $cpLabel = coupon_label($ctp, $cval);
                $cartPageCoupon = ['code' => (string)($cpAp['code'] ?? ''), 'label' => $cpLabel];
        }
        $cartPageTotal = max(0, round($cartPageSubtotal - $cartPageDiscount, 2));
    }
} catch (Throwable $e) {
    $cartPageItems = [];
    $cartPageSubtotal = 0.0;
    $cartPageDiscount = 0.0;
    $cartPageTotal = 0.0;
    $cartPageCoupon = null;
    $cartPageCount = 0;
}
