<footer class="footer">
<?php
$_footerSiteName = 'Vexaris';
$_footerDesc = __('footer.desc_default');
$_footerLegal  = __('footer.rights');
$_socialLinks = ['discord'=>'','youtube'=>'','github'=>'','twitter'=>''];
$_fdb = nexus_db();
if ($_fdb) {
    try {
        $_snRow = $_fdb->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('site_name','social_discord','social_youtube','social_github','social_twitter','footer_copyright','footer_copyright_line')");
        $_snRow->execute();
        foreach ($_snRow->fetchAll() as $_r) {
            if ($_r['key'] === 'site_name' && $_r['value']) $_footerSiteName = $_r['value'];
            if ($_r['key'] === 'footer_copyright' && $_r['value']) $_footerDesc = $_r['value'];
            if ($_r['key'] === 'footer_copyright_line' && $_r['value']) $_footerLegal = $_r['value'];
            if (strncmp($_r['key'], 'social_', 7) === 0) $_socialLinks[substr($_r['key'], 7)] = $_r['value'];
        }
    } catch (\Exception $e) {}
}
$__soc = $_socialLinks;
foreach ($__soc as $sk => $sv) { $__soc[$sk] = nx_safe_href($sv, ''); }
$_fcols = function_exists('footer_links_data') ? footer_links_data($_fdb) : [];
?>
    <div class="footer-inner">

        <div class="footer-top">

            <div class="footer-brand">
                <span class="footer-brand-logo">
                    <i class="fa-solid fa-cube" style="color:#fbc853; margin-right:6px; -webkit-text-fill-color:#fbc853;"></i><?= e(strtoupper($_footerSiteName)) ?>
                </span>
                <p class="footer-brand-desc">
                    <?= e($_footerDesc) ?>
                </p>

                <!-- Sosyal Medya İkonları -->
                <div class="footer-socials">
                    <?php if (!empty($__soc['discord'])): ?>
                    <a href="<?= e($__soc['discord']) ?>" class="footer-social-btn discord" title="<?= e(__('social.discord_title')) ?>" aria-label="Discord" target="_blank" rel="noopener noreferrer">
                        <i class="fa-brands fa-discord"></i>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($__soc['youtube'])): ?>
                    <a href="<?= e($__soc['youtube']) ?>" class="footer-social-btn youtube" title="<?= e(__('social.youtube_title')) ?>" aria-label="YouTube" target="_blank" rel="noopener noreferrer">
                        <i class="fa-brands fa-youtube"></i>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($__soc['github'])): ?>
                    <a href="<?= e($__soc['github']) ?>" class="footer-social-btn github" title="<?= e(__('social.github_title')) ?>" aria-label="GitHub" target="_blank" rel="noopener noreferrer">
                        <i class="fa-brands fa-github"></i>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($__soc['twitter'])): ?>
                    <a href="<?= e($__soc['twitter']) ?>" class="footer-social-btn twitter" title="<?= e(__('social.twitter_title')) ?>" aria-label="Twitter" target="_blank" rel="noopener noreferrer">
                        <i class="fa-brands fa-x-twitter"></i>
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <?php $_fpc = $_fcols['platform'] ?? null; if ($_fpc === null || !empty($_fpc['links'])): ?>
            <div>
                <p class="footer-col-title"><?= e(($_fpc['title'] ?? '') !== '' ? $_fpc['title'] : __('footer.col_platform')) ?></p>
                <ul class="footer-links">
                    <?php if ($_fpc !== null): foreach ($_fpc['links'] as $_fl): $_flExt = preg_match('#^https?://#', $_fl['url']); ?>
                    <li><a href="<?= e($_fl['url']) ?>" <?= $_flExt ? 'target="_blank" rel="noopener noreferrer"' : '' ?>><?php if ($_fl['icon'] !== ''): ?><i class="<?= e($_fl['icon']) ?>"></i> <?php endif; ?><?= e($_fl['label']) ?></a></li>
                    <?php endforeach; else: ?>
                    <li><a href="/"><i class="fa-solid fa-house"></i> <?= __('nav.home') ?></a></li>
                    <li><a href="/products"><i class="fa-solid fa-box-open"></i> <?= __('footer.products') ?></a></li>
                    <li><a href="/news"><i class="fa-solid fa-newspaper"></i> <?= __('nav.news') ?></a></li>
                    <li><a href="/support"><i class="fa-solid fa-headset"></i> <?= __('nav.support') ?></a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <?php endif; ?>

            <?php $_fac = $_fcols['account'] ?? null; if ($_fac === null || !empty($_fac['links'])): ?>
            <div>
                <p class="footer-col-title"><?= e(($_fac['title'] ?? '') !== '' ? $_fac['title'] : __('footer.col_account')) ?></p>
                <ul class="footer-links">
                    <?php if ($_fac !== null): foreach ($_fac['links'] as $_fl): $_flExt = preg_match('#^https?://#', $_fl['url']); ?>
                    <li><a href="<?= e($_fl['url']) ?>" <?= $_flExt ? 'target="_blank" rel="noopener noreferrer"' : '' ?>><?php if ($_fl['icon'] !== ''): ?><i class="<?= e($_fl['icon']) ?>"></i> <?php endif; ?><?= e($_fl['label']) ?></a></li>
                    <?php endforeach; else: ?>
                    <li><a href="/login"><i class="fa-solid fa-right-to-bracket"></i> <?= __('nav.login') ?></a></li>
                    <li><a href="/register"><i class="fa-solid fa-user-plus"></i> <?= __('nav.register') ?></a></li>
                    <li><a href="/user/dashboard"><i class="fa-solid fa-gauge"></i> <?= __('footer.dashboard') ?></a></li>
                    <li><a href="/user/my-products"><i class="fa-solid fa-cubes"></i> <?= __('footer.my_products') ?></a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <?php endif; ?>

            <?php $_flc = $_fcols['legal'] ?? null; if ($_flc === null || !empty($_flc['links'])): ?>
            <div>
                <p class="footer-col-title"><?= e(($_flc['title'] ?? '') !== '' ? $_flc['title'] : __('footer.col_legal')) ?></p>
                <ul class="footer-links">
                    <?php if ($_flc !== null): foreach ($_flc['links'] as $_fl): $_flExt = preg_match('#^https?://#', $_fl['url']); ?>
                    <li><a href="<?= e($_fl['url']) ?>" <?= $_flExt ? 'target="_blank" rel="noopener noreferrer"' : '' ?>><?php if ($_fl['icon'] !== ''): ?><i class="<?= e($_fl['icon']) ?>"></i> <?php endif; ?><?= e($_fl['label']) ?></a></li>
                    <?php endforeach; else: ?>
                    <li><a href="/legal?p=privacy-policy"><i class="fa-solid fa-file-shield"></i><?= __('legal.privacy') ?></a></li>
                    <li><a href="/legal?p=terms-of-service"><i class="fa-solid fa-file-contract"></i><?= __('legal.terms') ?></a></li>
                    <li><a href="/legal?p=refund-policy"><i class="fa-solid fa-rotate"></i><?= __('legal.refund') ?></a></li>
                    <li><a href="/legal?p=cookie-policy"><i class="fa-solid fa-cookie"></i><?= __('legal.cookies') ?></a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <?php endif; ?>

        </div>


        <?php $ftDiscordT = theme_visible('footer_discord_title', __('footer.discord_title')); $ftDiscordD = theme_visible('footer_discord_desc', __('footer.discord_desc')); ?>
        <?php if (($ftDiscordT !== null && trim((string)$ftDiscordT) !== '') || ($ftDiscordD !== null && trim((string)$ftDiscordD) !== '')): ?>
        <div style="
            margin: 32px 0;
            background: linear-gradient(135deg, rgba(88,101,242,0.12) 0%, rgba(71,82,196,0.08) 100%);
            border: 1px solid rgba(88,101,242,0.25);
            border-radius: 18px;
            padding: 24px 32px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
        ">
            <div style="display:flex; align-items:center; gap:16px;">
                <div style="
                    width: 52px; height: 52px;
                    background: rgba(88,101,242,0.2);
                    border-radius: 14px;
                    display: flex; align-items: center; justify-content: center;
                    font-size: 24px; color: #7289da;
                    flex-shrink: 0;
                ">
                    <i class="fa-brands fa-discord"></i>
                </div>
                <div>
                    <?php if ($ftDiscordT !== null && trim((string)$ftDiscordT) !== ''): ?>
                    <p style="font-weight: 800; font-size: 16px; margin-bottom: 3px;"><?= e($ftDiscordT) ?></p>
                    <?php endif; ?>
                    <?php if ($ftDiscordD !== null && trim((string)$ftDiscordD) !== ''): ?>
                    <p style="font-size: 13px; color: var(--text-muted);"><?= e($ftDiscordD) ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <a href="<?= e($__soc['discord'] ?: '#') ?>" class="btn-custom btn-discord btn-sm" <?= $__soc['discord'] ? 'target="_blank" rel="noopener noreferrer"' : '' ?>>
                <i class="fa-brands fa-discord btn-icon"></i>
                <?= __('footer.join_community') ?>
            </a>
        </div>
        <?php endif; ?>

        <div class="footer-bottom">
            <p class="footer-copy" style="font-family:'Poppins',sans-serif;">
                <span style="font-size:13px;color:var(--text-dim);font-weight:500;">&copy; <?= date('Y') ?> <span><?= e($_footerSiteName) ?></span>. <?= e($_footerLegal) ?></span>
            </p>
            <span class="footer-made"><?= function_exists('nx_brand_mark') ? nx_brand_mark() : 'Powered by <a href="https://' . strrev('rt.moc.siraxev') . '" rel="noopener">Vexaris</a>' ?></span>
        </div>

    </div><!-- /.footer-inner -->
</footer>
<script src="/themes/default/assets/js/main.js?v=9"></script>

<?php
$_showCookieBar = true;
$_cookiePref = 'pending';
$_cookieDb = nexus_db();
if ($_cookieDb && auth_check()) {
    try {
        $_ckSt = $_cookieDb->prepare('SELECT cookie_consent, cookie_pref FROM users WHERE id=?');
        $_ckSt->execute([(int)auth_user()['id']]);
        $_ckRow = $_ckSt->fetch();
        if ($_ckRow && (int)$_ckRow['cookie_consent']) {
            $_showCookieBar = false;
            $_cookiePref = in_array($_ckRow['cookie_pref'], ['all','essential'], true) ? $_ckRow['cookie_pref'] : 'essential';
        }
    } catch (\Exception $e) {}
} elseif (!auth_check()) {
    $_guestKey = 'nx_cc_' . md5('vexaris_cookie_guest');
    if (isset($_COOKIE[$_guestKey]) && in_array($_COOKIE[$_guestKey], ['all','essential'], true)) {
        $_showCookieBar = false;
        $_cookiePref = $_COOKIE[$_guestKey];
    }
}
?>

<?php if (isset($extraScripts)) echo $extraScripts; ?>

<?php
if ($_cookiePref === 'all' && function_exists('tawkto_widget_code')) {
    $twkWidget = tawkto_widget_code();
    if ($twkWidget) echo $twkWidget;
}
if ($_cookiePref === 'all' && function_exists('jivochat_widget_code')) {
    $jvWidget = jivochat_widget_code();
    if ($jvWidget) echo $jvWidget;
}
if ($_cookiePref === 'all' && function_exists('crisp_widget_code')) {
    $crWidget = crisp_widget_code();
    if ($crWidget) echo $crWidget;
}
if (($_cookiePref === 'all' || $_cookiePref === 'essential') && function_exists('analytics_widget_code')) {
    $anWidget = analytics_widget_code();
    if ($anWidget) echo $anWidget;
}
?>

<?php if ($_showCookieBar): ?>
<style>
@keyframes nxCookiePulse{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
</style>
<div id="nexCookieBar" style="position:fixed;bottom:24px;right:24px;z-index:99999;width:min(460px,calc(100vw - 32px));background:linear-gradient(180deg,#151b2a 0%,#0d111d 100%);border:1px solid rgba(99,102,241,.3);border-radius:18px;padding:24px;box-shadow:0 12px 50px rgba(0,0,0,.65);">
  <div style="display:flex;flex-direction:column;gap:16px;">
    <div style="display:flex;align-items:center;gap:12px;">
      <div style="width:40px;height:40px;min-width:40px;border-radius:11px;background:linear-gradient(135deg,rgba(251,200,83,.18),rgba(251,200,83,.06));border:1px solid rgba(251,200,83,.25);display:flex;align-items:center;justify-content:center;font-size:17px;color:#fbc853;">
        <i class="fa-solid fa-cookie-bite"></i>
      </div>
      <div>
        <p style="font-size:15px;font-weight:800;color:var(--text);margin:0;"><?= __('cookie.title') ?></p>
        <p style="font-size:11px;color:#9ca3af;margin:2px 0 0 0;"><?= __('cookie.desc') ?></p>
      </div>
    </div>
    <p style="font-size:12.5px;color:#9ca3af;line-height:1.7;margin:0;">
      <?= __('cookie.text') ?> <?= __('cookie.text2') ?>
      <a href="/legal?p=cookie-policy" style="color:#a5b4fc;text-decoration:underline;font-weight:600;"><?= __('cookie.policy_link') ?></a> <?= __('cookie.text_d') ?>
    </p>
    <div style="display:flex;flex-direction:column;gap:8px;">
      <button onclick="acceptCookies('all')" class="btn-custom btn-indigo" style="padding:12px 16px;font-size:13px;width:100%;justify-content:center;">
        <i class="fa-solid fa-check"></i> <?= __('cookie.accept_all') ?>
      </button>
      <button onclick="acceptCookies('essential')" class="btn-custom" style="padding:12px 16px;font-size:13px;width:100%;justify-content:center;background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.12);color:#cbd5e1;text-transform:none;box-shadow:none;">
        <i class="fa-solid fa-cookie"></i> <?= __('cookie.essential_only') ?>
      </button>
    </div>
  </div>
</div>

<?php
$vxWidgets = [];
if (function_exists('analytics_widget_code')) $vxWidgets['analytics'] = analytics_widget_code();
if (function_exists('tawkto_widget_code')) $vxWidgets['tawkto'] = tawkto_widget_code();
if (function_exists('jivochat_widget_code')) $vxWidgets['jivo'] = jivochat_widget_code();
if (function_exists('crisp_widget_code')) $vxWidgets['crisp'] = crisp_widget_code();
$vxWidgets = array_filter($vxWidgets);
?>
<script type="application/json" id="vxWidgets"><?= json_encode($vxWidgets, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?></script>
<script>
window.__ccPref = <?= json_encode($_cookiePref) ?>;
function vxInjectWidgets(pref) {
  try {
    var el = document.getElementById('vxWidgets');
    var data = JSON.parse((el && el.textContent) || '{}');
    if (window.__vxWDone === pref) { window.__ccPref = pref; return; }
    var run = function(html) {
      if (!html) return;
      var tmp = document.createElement('div');
      tmp.innerHTML = html;
      var scripts = tmp.querySelectorAll('script');
      for (var i = 0; i < scripts.length; i++) {
        var s = scripts[i], ns = document.createElement('script');
        for (var j = 0; j < s.attributes.length; j++) ns.setAttribute(s.attributes[j].name, s.attributes[j].value);
        if (s.text) ns.text = s.text;
        document.body.appendChild(ns);
      }
    };
    if (pref === 'all' || pref === 'essential') run(data.analytics);
    if (pref === 'all') { run(data.tawkto); run(data.jivo); run(data.crisp); }
    window.__vxWDone = pref;
    window.__ccPref = pref;
  } catch (e) { window.__ccPref = pref; }
}
function vxCsrfToken() {
  var m = document.querySelector('meta[name="csrf-token"]');
  return m ? m.getAttribute('content') : '';
}
function acceptCookies(pref) {
  pref = (pref === 'essential') ? 'essential' : 'all';
  var hide = function() {
    vxInjectWidgets(pref);
    var bar = document.getElementById('nexCookieBar');
    if (bar) {
      bar.style.transition = 'transform .4s ease, opacity .4s ease';
      bar.style.transform = 'translateY(120%)';
      bar.style.opacity = '0';
      setTimeout(function(){ bar.style.display = 'none'; }, 450);
    }
  };
  <?php if (auth_check()): ?>
  var fd = new FormData();
  fd.append('action', 'cookie_consent');
  fd.append('pref', pref);
  fetch('/action.php', { method: 'POST', headers: { 'X-CSRF-TOKEN': vxCsrfToken() }, body: fd }).then(hide, hide);
  <?php else: ?>
  document.cookie = 'nx_cc_<?= md5('vexaris_cookie_guest') ?>=' + pref + '; path=/; max-age=' + (365*24*60*60);
  hide();
  <?php endif; ?>
}
</script>
<?php endif; ?>
<?php if (function_exists('do_action')) do_action('mod_footer'); ?>

</body>
</html>
