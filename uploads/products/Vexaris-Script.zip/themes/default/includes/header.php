<?php
$_headerSiteName = 'Vexaris';
$_headerFavicon = null;
$_headerLogo    = null;
$_headerLoader  = '1';
$_headerCartCount = 0;
$_headerCartItems = [];
$_headerPayLabel = 'Shopier';
$vxTailwind = $vxTailwind ?? false;
$_hdb = nexus_db();
if ($_hdb) {
    try {
        $_hs = $_hdb->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('site_name','site_favicon','site_logo','loader_enabled')");
        $_hs->execute();
        foreach ($_hs->fetchAll() as $_hr) {
            if ($_hr['key'] === 'site_name')    $_headerSiteName = $_hr['value'];
            if ($_hr['key'] === 'site_favicon') $_headerFavicon  = $_hr['value'];
            if ($_hr['key'] === 'site_logo')    $_headerLogo     = $_hr['value'];
            if ($_hr['key'] === 'loader_enabled') $_headerLoader = $_hr['value'] === '0' ? '0' : '1';
        }
        $_pp = $_hdb->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('payment_shopier_active','payment_shopier_pat','payment_shopier_shop_slug','payment_shopier_osb_username','payment_shopier_osb_password','payment_paytr_active','payment_paytr_merchant_id','payment_paytr_merchant_key','payment_paytr_merchant_salt','payment_iyzico_active','payment_iyzico_api_key','payment_iyzico_secret_key','payment_stripe_active','payment_stripe_api_key','payment_paypal_active','payment_paypal_client_id','payment_paypal_secret','payment_bitpay_active','payment_bitpay_token','payment_crypt_active','payment_crypt_merchant_id','payment_crypt_api_key','payment_paywant_active','payment_paywant_api_key','payment_paywant_api_secret','payment_whop_active','payment_whop_api_key','payment_whop_account_id','payment_paddle_active','payment_paddle_api_key','payment_paddle_webhook_secret','payment_lemonsqueezy_active','payment_lemonsqueezy_api_key','payment_lemonsqueezy_signing_secret','payment_lemonsqueezy_store_id','payment_lemonsqueezy_variant_id','payment_dodopayments_active','payment_dodopayments_api_key','payment_dodopayments_webhook_secret','payment_dodopayments_product_id')");
        $_pp->execute();
        $_pm = [];
        foreach ($_pp->fetchAll() as $_pr) $_pm[$_pr['key']] = $_pr['value'];
        $_headerPayLabels = ['shopier' => 'Shopier', 'paytr' => 'PayTR', 'iyzico' => 'iyzico', 'stripe' => 'Stripe', 'paypal' => 'PayPal', 'bitpay' => 'BitPay', 'crypt' => 'Kripto', 'paywant' => 'Paywant', 'whop' => 'Whop', 'paddle' => 'Paddle', 'lemonsqueezy' => 'Lemon Squeezy', 'dodopayments' => 'DodoPayments'];
        $_headerPayReady = [];
        if (($_pm['payment_shopier_active'] ?? '0') === '1' && !empty($_pm['payment_shopier_pat'] ?? '') && !empty($_pm['payment_shopier_shop_slug'] ?? '') && !empty($_pm['payment_shopier_osb_username'] ?? '') && !empty($_pm['payment_shopier_osb_password'] ?? '')) {
            $_headerPayReady[] = 'shopier';
        }
        if (($_pm['payment_paytr_active'] ?? '0') === '1' && !empty($_pm['payment_paytr_merchant_id'] ?? '') && !empty($_pm['payment_paytr_merchant_key'] ?? '') && !empty($_pm['payment_paytr_merchant_salt'] ?? '')) {
            $_headerPayReady[] = 'paytr';
        }
        if (($_pm['payment_iyzico_active'] ?? '0') === '1' && !empty($_pm['payment_iyzico_api_key'] ?? '') && !empty($_pm['payment_iyzico_secret_key'] ?? '')) {
            $_headerPayReady[] = 'iyzico';
        }
        if (($_pm['payment_stripe_active'] ?? '0') === '1' && !empty($_pm['payment_stripe_api_key'] ?? '') && strncmp(trim((string)($_pm['payment_stripe_api_key'] ?? '')), 'sk_', 3) === 0) {
            $_headerPayReady[] = 'stripe';
        }
        if (($_pm['payment_paypal_active'] ?? '0') === '1' && !empty($_pm['payment_paypal_client_id'] ?? '') && !empty($_pm['payment_paypal_secret'] ?? '')) {
            $_headerPayReady[] = 'paypal';
        }
        if (($_pm['payment_bitpay_active'] ?? '0') === '1' && !empty($_pm['payment_bitpay_token'] ?? '')) {
            $_headerPayReady[] = 'bitpay';
        }
        if (($_pm['payment_crypt_active'] ?? '0') === '1' && !empty($_pm['payment_crypt_merchant_id'] ?? '') && !empty($_pm['payment_crypt_api_key'] ?? '')) {
            $_headerPayReady[] = 'crypt';
        }
        if (($_pm['payment_paywant_active'] ?? '0') === '1' && !empty($_pm['payment_paywant_api_key'] ?? '') && !empty($_pm['payment_paywant_api_secret'] ?? '')) {
            $_headerPayReady[] = 'paywant';
        }
        if (($_pm['payment_whop_active'] ?? '0') === '1' && !empty($_pm['payment_whop_api_key'] ?? '') && !empty($_pm['payment_whop_account_id'] ?? '')) {
            $_headerPayReady[] = 'whop';
        }
        if (($_pm['payment_paddle_active'] ?? '0') === '1' && !empty($_pm['payment_paddle_api_key'] ?? '') && !empty($_pm['payment_paddle_webhook_secret'] ?? '')) {
            $_headerPayReady[] = 'paddle';
        }
        if (($_pm['payment_lemonsqueezy_active'] ?? '0') === '1' && !empty($_pm['payment_lemonsqueezy_api_key'] ?? '') && !empty($_pm['payment_lemonsqueezy_signing_secret'] ?? '') && !empty($_pm['payment_lemonsqueezy_store_id'] ?? '') && !empty($_pm['payment_lemonsqueezy_variant_id'] ?? '')) {
            $_headerPayReady[] = 'lemonsqueezy';
        }
        if (($_pm['payment_dodopayments_active'] ?? '0') === '1' && !empty($_pm['payment_dodopayments_api_key'] ?? '') && !empty($_pm['payment_dodopayments_webhook_secret'] ?? '') && !empty($_pm['payment_dodopayments_product_id'] ?? '')) {
            $_headerPayReady[] = 'dodopayments';
        }
        if (function_exists('modules_gateways')) {
            try {
                foreach (modules_gateways($_hdb) as $gwCode => $gw) {
                    if (isset($_headerPayLabels[$gwCode])) continue;
                    $_headerPayLabels['mod:' . $gwCode] = $gw['label'];
                    $_headerPayReady[] = 'mod:' . $gwCode;
                }
            } catch (\Throwable $e) {}
        }
        $_headerPayLabel = $_headerPayReady ? $_headerPayLabels[$_headerPayReady[0]] : 'Shopier';
        if (auth_check()) {
            $_uid = (int)auth_user()['id'];
            $_cs = $_hdb->prepare('SELECT COUNT(*) FROM cart WHERE user_id=?'); $_cs->execute([$_uid]); $_headerCartCount = (int)$_cs->fetchColumn();
            $_ci = $_hdb->prepare('SELECT c.product_id,c.quantity,p.name,p.price,p.image_url FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? ORDER BY c.added_at DESC'); $_ci->execute([$_uid]); $_headerCartItems = $_ci->fetchAll();
            $_headerCartTotal = array_sum(array_map(fn($i)=>$i['price']*$i['quantity'], $_headerCartItems));
            $_balanceSt = $_hdb->prepare('SELECT balance FROM users WHERE id=?'); $_balanceSt->execute([$_uid]); $_headerBalance = (float)($_balanceSt->fetchColumn() ?? 0);
        } else {
            $_headerBalance = 0;
        }
        try {
            $_hlSt = $_hdb->prepare("SELECT `value` FROM settings WHERE `key`='header_links' LIMIT 1");
            $_hlSt->execute();
            $_hlRaw = $_hlSt->fetchColumn();
            if ($_hlRaw) {
                $_hlDec = json_decode((string)$_hlRaw, true);
                if (is_array($_hlDec)) $_headerLinks = array_values(array_filter($_hlDec, 'is_array'));
            }
        } catch (\Exception $e) {}
    } catch (\Exception $e) {}
}
if (!isset($_headerLinks) || !is_array($_headerLinks)) $_headerLinks = [];

$_seoTitleOverride = null;
$_seoMetaOverride  = null;
$_seoKey = $seoKey ?? '';
if ($_seoKey !== '' && $_hdb) {
    try {
        $_sek = 'seo_'.$_seoKey.'_title';
        $_sed = 'seo_'.$_seoKey.'_description';
        $_ses = $_hdb->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN (?,?)");
        $_ses->execute([$_sek,$_sed]);
        foreach ($_ses->fetchAll() as $_srse) {
            if ($_srse['key'] === $_sek && trim((string)$_srse['value']) !== '') $_seoTitleOverride = trim((string)$_srse['value']);
            if ($_srse['key'] === $_sed && trim((string)$_srse['value']) !== '') $_seoMetaOverride  = trim((string)$_srse['value']);
        }
    } catch (\Exception $e) {}
}
?>
<!DOCTYPE html>
<html lang="<?= lang_active() ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= htmlspecialchars(($_seoMetaOverride !== null && $_seoMetaOverride !== '' ? $_seoMetaOverride : (isset($_headerMetaDescription) && $_headerMetaDescription !== '' ? $_headerMetaDescription : __('seo.default_description', ['site' => $_headerSiteName])))) ?>">
    <meta name="theme-color" content="#0b0f17">
    <meta name="csrf-token" content="<?= csrf_token() ?>">
    <?php if ($_headerFavicon): ?>
    <link rel="icon" type="image/x-icon" href="<?= e($_headerFavicon) ?>">
    <link rel="shortcut icon" href="<?= e($_headerFavicon) ?>">
    <?php endif; ?>
    <title><?php
        $_seoDefaultLabels = ['home'=>__('seo.home'),'products'=>__('seo.products'),'news'=>__('seo.news'),'support'=>__('seo.support'),'login'=>__('seo.login'),'register'=>__('seo.register'),'404'=>__('seo.notfound')];
        if ($_seoTitleOverride !== null && $_seoTitleOverride !== '') {
            $__ogTitle = $_seoTitleOverride;
        } elseif ($_seoKey !== '' && isset($_seoDefaultLabels[$_seoKey])) {
            $__ogTitle = $_headerSiteName . ' | ' . $_seoDefaultLabels[$_seoKey];
        } elseif (isset($pageTitle)) {
            $__ogTitle = $pageTitle . ' — ' . $_headerSiteName;
        } else {
            $__ogTitle = $_headerSiteName . ' — ' . __('seo.default_suffix');
        }
        echo e($__ogTitle);
    ?></title>
    <?= site_og_tags($_hdb ?? null, $__ogTitle ?? '', ($_seoMetaOverride !== null && $_seoMetaOverride !== '' ? $_seoMetaOverride : (isset($_headerMetaDescription) && $_headerMetaDescription !== '' ? $_headerMetaDescription : ''))) ?>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=Poppins:wght@400;600;700&family=Space+Grotesk:wght@500;600;700&display=swap">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=Poppins:wght@400;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet" media="print" onload="this.media='all'">
    <noscript><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=Poppins:wght@400;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet"></noscript>
    <link rel="preload" as="style" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" media="print" onload="this.media='all'">
    <noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"></noscript>
    <?php if (!empty($vxTailwind)): ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>try{tailwind.config={corePlugins:{preflight:false}};}catch(e){}</script>
    <?php endif; ?>
    <script>try{var t=localStorage.getItem('nx-theme');if(t==='light')document.documentElement.setAttribute('data-theme','light');}</script>
    <link rel="stylesheet" href="/themes/default/assets/css/style.css?v=18">
    <style>.hidden{display:none!important;}</style>
    <?php if (function_exists('theme_vars_css')) theme_vars_css('default'); ?>
    <script>
    (function(){
      var meta = document.querySelector('meta[name="csrf-token"]');
      var token = meta ? meta.getAttribute('content') : '';
  window.vxGo = function(u){
    var s = String(u == null ? '' : u);
    if (!s) return false;
    if (s.charAt(0) !== '/') return false;
    if (s.charAt(1) === '/' || s.charAt(1) === '\\') return false;
    window.location.href = s;
    return true;
  };
      if (!meta) return;
      var origFetch = window.fetch;
      window.fetch = function(url, opts){
        opts = opts || {};
        if ((opts.method || 'GET').toUpperCase() === 'POST') {
          var headers = new Headers(opts.headers || {});
          if (!headers.has('X-CSRF-Token')) headers.set('X-CSRF-Token', token);
          if (!headers.has('X-Requested-With')) headers.set('X-Requested-With', 'XMLHttpRequest');
          opts.headers = headers;
        }
        return origFetch.call(this, url, opts).then(function(r){
          try {
            var ct = (r.headers && r.headers.get('content-type')) || '';
            if (ct.indexOf('application/json') === -1) return r;
            return r.clone().json().then(function(d){
              if (d && d.ok === false && (d.code === 'csrf_fail' || (typeof d.msg === 'string' && (d.msg.indexOf('Güvenlik doğrulaması') !== -1 || d.msg.indexOf('Security verification') !== -1)))) {
                try {
                  if (!sessionStorage.getItem('_vx_csrf_reload')) {
                    sessionStorage.setItem('_vx_csrf_reload', '1');
                    location.reload();
                    return new Promise(function(){});
                  }
                } catch(e){}
              } else {
                try { sessionStorage.removeItem('_vx_csrf_reload'); } catch(e){}
              }
              return r;
            }, function(){ return r; });
          } catch(e){ return r; }
        });
      };
    })();
    </script>
    <?php if (isset($extraHead)) echo $extraHead; ?>
    <?php if (function_exists('do_action')) do_action('mod_head'); ?>
</head>
<body>
<?php if (function_exists('slider_render')) slider_render(); ?>
<?php if (function_exists('do_action')) do_action('body_top'); ?>
<?php if ($_headerLoader === '1'): ?>
<div id="nx-boot" aria-hidden="true">
  <div class="nx-boot-center">
    <?php if ($_headerLogo): ?>
    <img src="<?= e($_headerLogo) ?>" alt="<?= e($_headerSiteName) ?>" class="nx-boot-logo" width="84" height="84" decoding="async">
    <?php else: ?>
    <div class="nx-boot-logo-ph"><i class="fa-solid fa-cube"></i></div>
    <?php endif; ?>
    <div class="nx-boot-title"><?= e(strtoupper($_headerSiteName)) ?></div>
    <div class="nx-boot-loader"><span></span></div>
  </div>
  <a href="https://vexaris.com.tr" target="_blank" rel="noopener" class="nx-boot-powered">Powered by <span>Vexaris</span></a>
</div>
<style>
#nx-boot{position:fixed;inset:0;z-index:99999;background:#0b0f17;display:none;flex-direction:column;justify-content:space-between;align-items:center;padding:44px 20px 28px;transition:opacity .7s,visibility .7s;}
#nx-boot.is-hidden{opacity:0;visibility:hidden;pointer-events:none;}
.nx-boot-center{display:flex;flex-direction:column;align-items:center;text-align:center;margin:auto;}
.nx-boot-logo{width:84px;height:84px;border-radius:22px;object-fit:cover;box-shadow:0 12px 32px rgba(0,0,0,.6);}
.nx-boot-logo-ph{width:84px;height:84px;border-radius:22px;background:linear-gradient(135deg,#6366f1,#4f46e5);display:flex;align-items:center;justify-content:center;font-size:34px;color:#fff;box-shadow:0 12px 32px rgba(99,102,241,.35);}
.nx-boot-title{font-family:'Plus Jakarta Sans',sans-serif;font-size:1.35rem;font-weight:800;letter-spacing:.06em;margin:16px 0 22px;color:#f1f5f9;}
.nx-boot-loader{width:180px;height:4px;border-radius:999px;background:rgba(255,255,255,.1);overflow:hidden;}
.nx-boot-loader span{display:block;height:100%;width:40%;border-radius:999px;background:linear-gradient(90deg,#6366f1,#fbc853);animation:nxBootSlide 1.1s ease-in-out infinite;}
@keyframes nxBootSlide{0%{transform:translateX(-100%);}100%{transform:translateX(450%);}}
.nx-boot-powered{font-size:.82rem;color:#64748b;text-decoration:none;display:inline-flex;align-items:center;gap:4px;}
.nx-boot-powered span{color:#6366f1;font-weight:700;}
</style>
<script>
(function(){
  var boot=document.getElementById('nx-boot');
  if(!boot) return;
  var path=window.location.pathname;
  var isIndex=(path==='/'||path==='/index.php'||path==='/index');
  var seen=false;
  try{ seen=sessionStorage.getItem('nx_boot_seen')==='1'; }catch(e){}
  var external=true;
  try{
    var r=document.referrer;
    if(r) external=(new URL(r).host!==location.host);
  }catch(e){}
  if(!isIndex||(seen&&!external)){ boot.style.display='none'; return; }
  boot.style.display='flex';
  setTimeout(function(){
    boot.classList.add('is-hidden');
    try{ sessionStorage.setItem('nx_boot_seen','1'); }catch(e){}
    setTimeout(function(){ boot.style.display='none'; },700);
  },1200);
})();
</script>
<?php endif; ?>

<?php $authUser = auth_check() ? auth_user() : null; ?>

<nav class="navbar">
    <div class="navbar-inner">

        <a href="/" class="navbar-logo" style="display:flex;align-items:center;gap:8px;">
            <?php if ($_headerLogo): ?>
            <img src="<?= e($_headerLogo) ?>" alt="<?= e($_headerSiteName) ?>" style="height:42px;width:auto;max-width:210px;object-fit:contain;max-height:52px;" height="42" fetchpriority="high" decoding="async">
            <?php else: ?>
            <i class="fa-solid fa-cube" style="color:#fbc853;"></i>
            <?php endif; ?>
            <?= e(strtoupper($_headerSiteName)) ?>
        </a>

        <button class="navbar-toggle" id="navToggle" aria-label="<?= e(__('nav.menu_toggle')) ?>">
            <i class="fa-solid fa-bars"></i>
        </button>

        <ul class="navbar-links" id="navLinks">
            <?php if (!empty($_headerLinks)): foreach ($_headerLinks as $hl): $_hlUrl = nx_safe_href($hl['url'] ?? '', '/'); $isExt = preg_match('#^https?://#', $_hlUrl); ?>
                <li><a href="<?= e($_hlUrl) ?>" <?= $isExt ? 'target="_blank" rel="noopener"' : '' ?>><?php if (!empty($hl['icon'])): ?><i class="<?= e($hl['icon']) ?>" style="margin-right:6px"></i><?php endif; ?><?= e($hl['label']) ?></a></li>
            <?php endforeach; else: ?>
                <li><a href="/" <?= ($activePage??'')==='home'    ? 'class="active"':'' ?>><i class="fa-solid fa-house"></i> <?= __('nav.home') ?></a></li>
                <li><a href="/products" <?= ($activePage??'')==='products' ? 'class="active"':'' ?>><i class="fa-solid fa-store"></i> <?= __('nav.shop') ?></a></li>
                <li><a href="/news" <?= ($activePage??'')==='news'     ? 'class="active"':'' ?>><i class="fa-solid fa-newspaper"></i> <?= __('nav.news') ?></a></li>
                <li><a href="/support" <?= ($activePage??'')==='support'  ? 'class="active"':'' ?>><i class="fa-solid fa-headset"></i> <?= __('nav.support') ?></a></li>
            <?php endif; ?>
            <?php if (function_exists('do_action')) do_action('header_menu_after'); ?>
        </ul>

        <div class="navbar-actions" id="navActions">
        <button class="nx-theme-toggle" id="themeToggleBtn" aria-label="<?= e(__('nav.theme_toggle')) ?>" title="<?= e(__('nav.theme_title')) ?>" onclick="toggleNxTheme(event)">
            <i class="fa-solid fa-moon"></i>
            <i class="fa-solid fa-sun"></i>
        </button>
        <?php if ($authUser): ?>
            <?php
            $_hcCount = $_headerCartCount;
            $_hcItems = $_headerCartItems;
            $_hcTotal = $_headerCartTotal;
            ?>
            <div style="display:flex;align-items:center;gap:6px;">
                                    <button id="cartToggleBtn" class="nav-cart-btn" aria-label="<?= e(__('nav.cart')) ?>" onclick="toggleCartPanel(event)" style="display:flex;align-items:center;gap:6px;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:10px;padding:7px 12px;cursor:pointer;color:var(--text-muted);font-size:14px;transition:color .2s,border-color .2s;">
                    <i class="fa-solid fa-cart-shopping"></i>
                    <?php if ($_hcCount > 0): ?>
                    <span id="navCartBadge" style="font-size:10px;font-weight:900;background:#6366f1;color:#fff;border-radius:999px;padding:1px 7px;line-height:1.5;"><?= $_hcCount ?></span>
                    <?php endif; ?>
                </button>
                <div class="nav-user-dropdown" id="userDropdown">
                <button class="nav-user-btn" id="userDropdownBtn" aria-expanded="false" aria-haspopup="true" style="gap:6px;">
                    <span style="font-size:11px;font-weight:800;color:#fbc853;background:rgba(251,200,83,.12);border-radius:6px;padding:2px 8px;line-height:1.5;display:flex;align-items:center;gap:4px;">
                        <i class="fa-solid fa-coins" style="font-size:10px;"></i> <?= fmt_money($_headerBalance) ?>
                    </span>
                    <img src="<?= e($authUser['avatar']) ?>"
                         alt="<?= e($authUser['username']) ?>"
                         class="nav-user-avatar" width="32" height="32">
                    <span style="display:flex;flex-direction:column;align-items:flex-start;line-height:1.2;min-width:0;">
                        <span class="nav-user-name"><?= e($authUser['username']) ?></span>
                    </span>
                    <i class="fa-solid fa-chevron-down nav-user-chevron"></i>
                </button>
                <div class="nav-dropdown-menu" id="userDropdownMenu" role="menu" style="width:220px;padding:8px;">
                    <a href="/user/dashboard" class="nav-dropdown-item" role="menuitem">
                        <i class="fa-solid fa-gauge"></i> <?= __('nav.dashboard') ?>
                    </a>
                    <a href="/user/redeem-code" class="nav-dropdown-item" role="menuitem">
                        <i class="fa-solid fa-ticket"></i> <?= __('nav.redeem') ?>
                    </a>
                    <a href="/user/settings" class="nav-dropdown-item" role="menuitem">
                        <i class="fa-solid fa-gear"></i> <?= __('nav.settings') ?>
                    </a>
                    <button onclick="openTopupModal(event)" class="nav-dropdown-item" role="menuitem" style="width:100%;text-align:left;background:none;border:none;cursor:pointer;">
                        <i class="fa-solid fa-coins" style="color:#fbc853;"></i> <?= __('nav.topup') ?>
                    </button>
                    <?php if (($authUser['role'] ?? 'user') !== 'user'): ?>
                    <a href="/admin/dashboard.php" class="nav-dropdown-item" role="menuitem">
                        <i class="fa-solid fa-shield-halved"></i> <?= __('nav.admin') ?>
                    </a>
                    <?php endif; ?>
                    <div class="nav-dropdown-divider"></div>
                    <form method="POST" action="/logout" style="margin:0;">
                        <?= csrf_field() ?>
                        <button type="submit" class="nav-dropdown-item nav-dropdown-item--danger" role="menuitem" style="width:100%;background:none;border:none;cursor:pointer;font:inherit;text-align:left;">
                            <i class="fa-solid fa-right-from-bracket"></i> <?= __('nav.logout') ?>
                        </button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <a href="/login" class="btn-custom btn-indigo btn-sm">
                <i class="fa-solid fa-right-to-bracket btn-icon"></i> <?= __('nav.login') ?>
            </a>
            <a href="/register" class="btn-custom btn-yellow btn-sm">
                <i class="fa-solid fa-user-plus btn-icon"></i> <?= __('nav.register') ?>
            </a>
        <?php endif; ?>
        </div>

    </div>
</nav>

<div id="cartPanel" class="cart-modal">
    <div class="cart-modal-backdrop" id="cartBackdrop"></div>
    <div class="cart-modal-content">
        <div class="cart-modal-header">
            <span class="cart-modal-title"><i class="fa-solid fa-cart-shopping" style="color:#6366f1;"></i> <?= __('cart.title') ?></span>
            <button id="cartCloseBtn" class="cart-modal-close"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <?php $panelItems = $_hcItems; $panelTotal = $_hcTotal; include __DIR__ . '/cart-panel.php'; ?>
    </div>
</div>

<div id="topupModal" class="modal-overlay" style="display:none;">
    <div class="modal-box" style="max-width:420px;">
        <div class="modal-box-header">
            <span><i class="fa-solid fa-coins" style="color:#fbc853;"></i> <?= __('topup.title') ?></span>
            <button class="modal-box-close" onclick="closeTopupModal()"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="modal-box-body">
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--text-muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;"><?= __('topup.amount', ['sym' => fx_symbol(store_currency())]) ?></label>
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;">
                    <button type="button" onclick="setTopupAmount(50)" class="topup-amount-btn" data-amount="50"><?= fmt_money_short(50) ?></button>
                    <button type="button" onclick="setTopupAmount(100)" class="topup-amount-btn" data-amount="100"><?= fmt_money_short(100) ?></button>
                    <button type="button" onclick="setTopupAmount(200)" class="topup-amount-btn" data-amount="200"><?= fmt_money_short(200) ?></button>
                    <button type="button" onclick="setTopupAmount(500)" class="topup-amount-btn" data-amount="500"><?= fmt_money_short(500) ?></button>
                </div>
                <input type="number" id="topupAmount" min="<?= topup_min_amount() ?>" step="1" value="100" placeholder="<?= htmlspecialchars(__('topup.min_placeholder', ['m' => fmt_money_short(topup_min_amount())])) ?>"
                       style="width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:16px;font-weight:800;outline:none;font-family:inherit;"
                       onfocus="this.style.borderColor='var(--accent)'" onblur="this.style.borderColor=''">
            </div>
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">
                <i class="fa-solid fa-info-circle"></i> <?= __('topup.balance_info') ?>
            </div>
            <?php if (count($_headerPayReady) > 1): ?>
            <div style="margin-top:18px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--text-muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;"><?= __('topup.method') ?></label>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    <?php foreach ($_headerPayReady as $_pmKey): ?>
                    <button type="button" class="topup-method-btn <?= $_pmKey === $_headerPayReady[0] ? 'active' : '' ?>" data-method="<?= $_pmKey ?>" onclick="setTopupMethod('<?= $_pmKey ?>')"><?= e($_headerPayLabels[$_pmKey]) ?></button>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            <input type="hidden" id="topupMethod" value="<?= htmlspecialchars($_headerPayReady[0] ?? 'shopier', ENT_QUOTES) ?>">
        </div>
        <div class="modal-box-footer">
            <button type="button" class="btn-custom" style="background:rgba(255,255,255,.05);border-color:var(--border);color:var(--text-muted);box-shadow:none;" onclick="closeTopupModal()"><?= __('topup.cancel') ?></button>
            <button onclick="submitTopup()" class="btn-custom btn-yellow" id="topupSubmitBtn">
                <i class="fa-solid fa-bolt btn-icon"></i> <?= htmlspecialchars(__('topup.pay_with', ['method' => $_headerPayLabel])) ?>
            </button>
        </div>
    </div>
</div>

<style>
.modal-overlay{position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.8);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:20px;}
.modal-box{background:var(--bg-card);border:1px solid var(--border);border-radius:20px;width:100%;overflow:hidden;}
.modal-box-header{display:flex;align-items:center;justify-content:space-between;padding:18px 22px;border-bottom:1px solid var(--border);font-size:16px;font-weight:800;}
.modal-box-close{background:rgba(255,255,255,.05);border:1px solid var(--border);color:var(--text-muted);width:34px;height:34px;border-radius:10px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:16px;transition:all .2s;}
.modal-box-close:hover{background:#ef4444;color:#fff;border-color:#ef4444;}
.modal-box-body{padding:22px;}
.modal-box-footer{display:flex;gap:10px;padding:16px 22px;border-top:1px solid var(--border);justify-content:flex-end;}@media(max-width:520px){.modal-box-footer{flex-wrap:wrap}.modal-box-footer>button{flex:1;min-width:140px}}
.topup-amount-btn{background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:8px 16px;cursor:pointer;color:var(--text);font-size:13px;font-weight:800;transition:all .2s;font-family:inherit;}
.topup-amount-btn:hover,.topup-amount-btn.active{background:rgba(251,200,83,.12);border-color:#fbc853;color:#fbc853;}
.topup-method-btn{background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:8px 14px;cursor:pointer;color:var(--text);font-size:13px;font-weight:800;transition:all .2s;font-family:inherit;}
.topup-method-btn:hover,.topup-method-btn.active{background:rgba(99,102,241,.12);border-color:var(--accent);color:var(--accent);}
</style>

<script>
window.NX_PAY_LABELS = <?= json_encode($_headerPayLabels, JSON_UNESCAPED_UNICODE) ?>;
window.NX_PAY_DEFAULT = <?= json_encode($_headerPayLabel, JSON_UNESCAPED_UNICODE) ?>;
window.NX_LANG = <?= json_encode(['min_topup'=>__('topup.min_error', ['m' => fmt_money_short(topup_min_amount())]),'min_topup_val'=>topup_min_amount(),'redirecting'=>__('topup.redirecting'),'error'=>__('topup.error'),'verifying'=>__('topup.verifying'),'approved'=>__('topup.approved'),'processing'=>__('topup.processing'),'pay_with'=>__('topup.pay_with'),'confirm_title'=>__('cart.balance_confirm_title'),'confirm_text'=>__('cart.balance_confirm', ['total' => '{total}']),'confirm_yes'=>__('cart.balance_confirm_yes'),'confirm_no'=>__('cart.balance_confirm_no'),'cart_empty'=>__('cart.empty_short')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
window.NX_MONEY = <?= json_encode(fx_js_config(), JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
window.nxFmt = function(v){var m=window.NX_MONEY||{sym:'₺',pre:true,dec:',',thou:'.',sp:''};var n=parseFloat(v||0);if(!isFinite(n))n=0;var ng=n<0;n=Math.abs(n);var s=n.toFixed(2).split('.');s[0]=s[0].replace(/\B(?=(\d{3})+(?!\d))/g,m.thou);var t=s.join(m.dec);if(ng)t='-'+t;return m.pre?m.sym+t:t+m.sp+m.sym;};
function nxPayWith(m){ return (window.NX_LANG.pay_with||'{m} ile Öde').replace('{m}',m).replace('{method}',m); }
function openTopupModal(e) {
    if(e)e.preventDefault();
    var m=document.getElementById('userDropdownMenu');if(m)m.classList.remove('open');
    document.getElementById('topupModal').style.display='flex';
}
function closeTopupModal() {
    document.getElementById('topupModal').style.display='none';
}
function toggleNxTheme(e) {
    if (e) { e.preventDefault(); e.stopPropagation(); }
    var root = document.documentElement;
    var light = root.getAttribute('data-theme') === 'light';
    if (light) root.removeAttribute('data-theme');
    else root.setAttribute('data-theme', 'light');
    try { localStorage.setItem('nx-theme', light ? 'dark' : 'light'); } catch (err) {}
}
function setTopupAmount(val) {
    document.getElementById('topupAmount').value=val;
    document.querySelectorAll('.topup-amount-btn').forEach(function(b){
        b.classList.toggle('active',parseInt(b.dataset.amount)===val);
    });
}
var topupPayLabels=(window.NX_PAY_LABELS||{shopier:'Shopier',paytr:'PayTR',iyzico:'iyzico',stripe:'Stripe',paypal:'PayPal',bitpay:'BitPay',crypt:'Kripto',paywant:'Paywant',whop:'Whop',paddle:'Paddle',lemonsqueezy:'Lemon Squeezy',dodopayments:'DodoPayments'});
var topupPayDefault=(window.NX_PAY_DEFAULT||'Shopier');
var topupMethod=document.getElementById('topupMethod').value;
function topupButtonLabel(){
    return '<i class="fa-solid fa-bolt btn-icon"></i> '+nxPayWith(topupPayLabels[topupMethod]||topupPayDefault);
}
function setTopupMethod(m){
    topupMethod=m;
    document.getElementById('topupMethod').value=m;
    document.querySelectorAll('.topup-method-btn').forEach(function(b){
        b.classList.toggle('active',b.getAttribute('data-method')===m);
    });
}
async function submitTopup() {
    var amount=parseFloat(document.getElementById('topupAmount').value);
    if(!amount||amount<(window.NX_LANG.min_topup_val||10)){showToast(window.NX_LANG.min_topup||'Minimum ₺10 yükleyebilirsiniz.',false);return;}
    if(topupMethod.indexOf('mod:')===0){window.location.href='/shop/module-pay?gateway='+encodeURIComponent(topupMethod.slice(4))+'&topup='+encodeURIComponent(amount);return;}
    var btn=document.getElementById('topupSubmitBtn');
    btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> '+(window.NX_LANG.redirecting||'Yönlendiriliyor...');
    var fd=new FormData();fd.append('action','balance_topup');fd.append('amount',amount);fd.append('method',topupMethod);
    try {
        var r=await fetch('/action.php',{method:'POST',body:fd});
        var d=await r.json();
        if(d.ok&&d.html){document.open();document.write(d.html);document.close();}
        else if(d.ok&&d.redirect){vxGo(d.redirect);}
        else{showToast(d.msg||window.NX_LANG.error||'Hata oluştu.',false);btn.disabled=false;btn.innerHTML=topupButtonLabel();}
    }catch(e){showToast(window.NX_LANG.error||'Hata oluştu.',false);btn.disabled=false;btn.innerHTML=topupButtonLabel();}
}
document.getElementById('topupModal')?.addEventListener('click',function(e){if(e.target===this)closeTopupModal();});
document.addEventListener('keydown',function(e){if(e.key==='Escape')closeTopupModal();});

<?php if (!empty($_GET['shopier_return'])): ?>
(function(){
    var banner = document.createElement('div');
    banner.id = 'shopierReturnBanner';
    banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99999;background:#1e293b;border-bottom:2px solid #fbc853;padding:14px 20px;display:flex;align-items:center;justify-content:space-between;gap:12px;font-family:inherit;';
    banner.innerHTML = '<div style="display:flex;align-items:center;gap:10px;">'
        + '<i class="fa-solid fa-spinner fa-spin" style="color:#fbc853;font-size:16px;"></i>'
        + '<span style="font-size:13px;font-weight:700;color:#f1f5f9;">'+(window.NX_LANG.verifying||'Shopier ödemesi doğrulanıyor... Bakiyeniz birkaç saniye içinde yansıyacak.')+'</span>'
        + '</div>'
        + '<button onclick="document.getElementById(\'shopierReturnBanner\').remove()" style="background:none;border:none;color:#64748b;cursor:pointer;font-size:18px;padding:2px 6px;">×</button>';
    document.body.prepend(banner);

    var attempts = 0;
    var maxAttempts = 12;
    function pollBalance() {
        attempts++;
        fetch('/action.php', {method:'POST', body: (function(){var f=new FormData();f.append('action','get_balance_status');return f;})()})
            .then(function(r){return r.json();})
            .then(function(d){
                if (d.ok && d.paid) {
                    var b = document.getElementById('shopierReturnBanner');
                    if (b) {
                        b.style.background = '#14532d';
                        b.style.borderColor = '#22c55e';
                        b.querySelector('i').className = 'fa-solid fa-circle-check';
                        b.querySelector('i').style.color = '#4ade80';
                        b.querySelector('span').textContent = window.NX_LANG.approved||'✓ Ödemeniz onaylandı! Bakiyeniz güncellendi.';
                        setTimeout(function(){ window.location.href='/user/dashboard?tab=balance'; }, 2000);
                    }
                } else if (attempts < maxAttempts) {
                    setTimeout(pollBalance, 3000);
                } else {
                    var b2 = document.getElementById('shopierReturnBanner');
                    if (b2) {
                        b2.style.background = '#1e1b4b';
                        b2.style.borderColor = '#6366f1';
                        b2.querySelector('i').className = 'fa-solid fa-clock';
                        b2.querySelector('i').style.color = '#818cf8';
                        b2.querySelector('span').textContent = window.NX_LANG.processing||'Ödemeniz işleniyor. Bakiyeniz kısa süre içinde yansıyacak.';
                    }
                }
            })
            .catch(function(){ if (attempts < maxAttempts) setTimeout(pollBalance, 5000); });
    }
    setTimeout(pollBalance, 2000);
})();
<?php endif; ?>
</script>
