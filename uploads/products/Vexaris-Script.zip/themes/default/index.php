<?php
$pageTitle  = 'Ana Sayfa';
$activePage = 'home';
$seoKey     = 'home';

$db = nexus_db();

$siteName = 'Vexaris';
if ($db) {
    try {
        $snVal = $db->query("SELECT `value` FROM settings WHERE `key`='site_name' LIMIT 1")->fetchColumn();
        if (is_string($snVal) && trim($snVal) !== '') $siteName = trim($snVal);
    } catch (\PDOException $e) {}
}

$news = [];
if ($db) {
    $stmt = $db->prepare(
        'SELECT id, title, slug, content, image_url, created_at FROM announcements WHERE status="published" ORDER BY id DESC LIMIT 3'
    );
    $stmt->execute();
    $news = $stmt->fetchAll();
}

$products = [];
if ($db) {
    $stmt = $db->prepare(
        "SELECT p.id, p.name, p.slug, p.short_description, p.price, p.image_url, p.version,
                COALESCE(c.name, p.category) AS category
         FROM products p
         LEFT JOIN categories c ON c.name = p.category
         WHERE p.is_active = 1 AND p.is_hidden = 0 AND p.status = 'active'
         ORDER BY p.created_at DESC
         LIMIT 4"
    );
    $stmt->execute();
    $products = $stmt->fetchAll();
}

$refMode = 'grid';
$refAuto = false;
$references = [];
if ($db) {
    try {
        $refMode = $db->query("SELECT `value` FROM settings WHERE `key`='references_mode'")->fetchColumn() ?: 'grid';
        $refStmt = $db->query('SELECT * FROM `references` WHERE is_active=1 ORDER BY sort_order ASC, id DESC');
        $references = $refStmt->fetchAll();
    } catch (\PDOException $e) {}
}
$useSlider = ($refMode === 'slider' && is_array($references) && count($references) >= 3);

$heroStats = ['products' => 0, 'members' => 0];
$heroDiscord = '';
if ($db) {
    try {
        $r = $db->query("SELECT
            (SELECT COUNT(*) FROM products WHERE is_active=1 AND is_hidden=0 AND status='active') AS products,
            (SELECT COUNT(*) FROM users) AS members
        ")->fetch();
        if ($r) {
            $heroStats['products'] = (int)$r['products'];
            $heroStats['members']  = (int)$r['members'];
        }
        $dRow = $db->query("SELECT `value` FROM settings WHERE `key`='social_discord' LIMIT 1")->fetchColumn();
        if ($dRow) $heroDiscord = (string)$dRow;
    } catch (\PDOException $e) {}
}

function fmt_stat(int $n): string {
    if ($n >= 1000) return number_format(floor($n / 100) * 100, 0, ',', '.') . '+';
    if ($n >= 100)  return number_format(floor($n / 10) * 10, 0, ',', '.') . '+';
    if ($n > 0)     return $n . '+';
    return '0';
}

function ref_stars(int $r): string {
    $out = '';
    for ($i = 1; $i <= 5; $i++) $out .= $i <= $r ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star"></i>';
    return $out;
}

include __DIR__ . '/includes/header.php';
?>

<!-- ====================================================
     HERO SECTION
==================================================== -->
<?php
$heroEyebrow = theme_visible('hero_eyebrow', __('home.eyebrow'));
$heroTitle = theme_visible('hero_title', __('home.title'));
$heroDesc = theme_visible('hero_desc', __('home.desc'));
$heroBtn1 = theme_visible('hero_btn1_text', __('home.btn1'));
$heroBtn1Url = theme_visible('hero_btn1_url', '/products');
$heroBtn2 = theme_visible('hero_btn2_text', __('home.btn2'));
$heroMetas = [];
foreach ([theme_visible('hero_meta1', __('home.meta1')), theme_visible('hero_meta2', __('home.meta2')), theme_visible('hero_meta3', __('home.meta3'))] as $hm) {
    if ($hm !== null && trim((string)$hm) !== '') $heroMetas[] = $hm;
}
$heroStat3v = theme_visible('hero_stat3_value', '99.9%');
$heroStat3l = theme_visible('hero_stat3_label', __('home.stat3label'));
$heroStat4v = theme_visible('hero_stat4_value', '7/24');
$heroStat4l = theme_visible('hero_stat4_label', __('home.stat4label'));
?>
<section class="hero-v2">

    <?php if ($heroEyebrow !== null && trim((string)$heroEyebrow) !== ''): ?>
    <p class="hero-v2-eyebrow"><?= e($heroEyebrow) ?></p>
    <?php endif; ?>

    <?php if ($heroTitle !== null && trim((string)$heroTitle) !== ''): ?>
    <h1 class="hero-v2-title">
        <?= nx_clean_html($heroTitle, 'inline') ?>
    </h1>
    <?php endif; ?>

    <?php if ($heroDesc !== null && trim((string)$heroDesc) !== ''): ?>
    <p class="hero-v2-sub">
        <?= e($heroDesc) ?>
    </p>
    <?php endif; ?>

    <?php if ($heroBtn1 !== null || $heroBtn2 !== null): ?>
    <div class="hero-v2-actions">
        <?php if ($heroBtn1 !== null && trim((string)$heroBtn1) !== ''): ?>
        <a href="<?= e(nx_safe_href(($heroBtn1Url !== null && trim((string)$heroBtn1Url) !== '') ? $heroBtn1Url : '/products', '/products')) ?>" class="btn-custom btn-yellow">
            <span class="btn-icon">➜</span>
            <?= e($heroBtn1) ?>
        </a>
        <?php endif; ?>
        <?php if ($heroBtn2 !== null && trim((string)$heroBtn2) !== ''): ?>
        <?php $_heroDiscordUrl = nx_safe_href($heroDiscord, '#'); ?>
        <a href="<?= e($_heroDiscordUrl) ?>" class="btn-custom btn-discord"<?= $_heroDiscordUrl !== '#' ? ' target="_blank" rel="noopener noreferrer"' : '' ?>>
            <i class="fa-brands fa-discord btn-icon"></i>
            <?= e($heroBtn2) ?>
        </a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if (count($heroMetas) > 0): ?>
    <div class="hero-v2-meta">
        <?php foreach ($heroMetas as $mi => $mv): ?>
        <?php if ($mi > 0): ?><span class="dot"></span><?php endif; ?>
        <span><?= e($mv) ?></span>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php $heroImg = trim((string)theme_setting('hero_image', '')); ?>
    <?php if ($heroImg !== ''): ?>
    <div class="hero-v2-visual">
        <img src="<?= e($heroImg) ?>" alt="<?= e(theme_setting('hero_eyebrow', __('home.eyebrow'))) ?>" loading="lazy" width="1200" height="600">
    </div>
    <?php endif; ?>

    <div class="hero-v2-stats">
        <div class="hero-v2-stat">
            <b><?= $heroStats['products'] > 0 ? fmt_stat($heroStats['products']) : '0' ?></b>
            <span><?= __('home.digital_products') ?></span>
        </div>
        <div class="hero-v2-stat">
            <b><?= $heroStats['members'] > 0 ? fmt_stat($heroStats['members']) : '0' ?></b>
            <span><?= __('home.happy_customer') ?></span>
        </div>
        <?php if ($heroStat3v !== null && trim((string)$heroStat3v) !== ''): ?>
        <div class="hero-v2-stat">
            <b><?= e($heroStat3v) ?></b>
            <?php if ($heroStat3l !== null && trim((string)$heroStat3l) !== ''): ?><span><?= e($heroStat3l) ?></span><?php endif; ?>
        </div>
        <?php endif; ?>
        <?php if ($heroStat4v !== null && trim((string)$heroStat4v) !== ''): ?>
        <div class="hero-v2-stat">
            <b><?= e($heroStat4v) ?></b>
            <?php if ($heroStat4l !== null && trim((string)$heroStat4l) !== ''): ?><span><?= e($heroStat4l) ?></span><?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

</section>
<!-- ====== /HERO ====== -->

<div class="divider"></div>


<!-- ====================================================
     GÜVEN BANDI
==================================================== -->
<section class="section">
    <div class="section-inner">

        <div class="trust-v2-grid">
            <div class="trust-v2-side">
                <p class="trust-v2-index">01 — Güven</p>
                <?php $trustTitle = theme_visible('trust_title', __('home.trust_title')); if ($trustTitle !== null && trim((string)$trustTitle) !== ''): ?>
                <h2 class="section-title" style="margin:12px 0 10px;"><?= e($trustTitle) ?> <?= e($siteName) ?>?</h2>
                <?php endif; ?>
                <?php $trustDesc = theme_visible('trust_desc', __('home.trust_desc')); if ($trustDesc !== null && trim((string)$trustDesc) !== ''): ?>
                <p class="section-desc"><?= e($trustDesc) ?></p>
                <?php endif; ?>
            </div>

            <div class="trust-v2-list">
            <?php
            $features = [
                ['icon'=>'fa-shield-halved', 'tkey'=>'trust1_title', 'dkey'=>'trust1_desc', 'tdef'=>__('home.trust1t'),   'ddef'=>__('home.trust1d'),],
                ['icon'=>'fa-bolt',          'tkey'=>'trust2_title', 'dkey'=>'trust2_desc', 'tdef'=>__('home.trust2t'),       'ddef'=>__('home.trust2d')],
                ['icon'=>'fa-headset',       'tkey'=>'trust3_title', 'dkey'=>'trust3_desc', 'tdef'=>__('home.trust3t'),          'ddef'=>__('home.trust3d')],
                ['icon'=>'fa-rotate',        'tkey'=>'trust4_title', 'dkey'=>'trust4_desc', 'tdef'=>__('home.trust4t'),'ddef'=>__('home.trust4d')],
            ];
            $fi = 0;
            foreach ($features as $f):
                $ft = theme_visible($f['tkey'], $f['tdef']);
                $fd = theme_visible($f['dkey'], $f['ddef']);
                if ($ft === null || trim((string)$ft) === '') continue;
                $fi++;
            ?>
            <div class="trust-v2-row">
                <span class="trust-v2-num">0<?= $fi ?></span>
                <div style="display:flex;gap:16px;align-items:center;">
                    <span class="trust-v2-ic"><i class="fa-solid <?= $f['icon'] ?>"></i></span>
                    <div>
                        <h4><?= e($ft) ?></h4>
                        <?php if ($fd !== null && trim((string)$fd) !== ''): ?><p><?= e($fd) ?></p><?php endif; ?>
                    </div>
                </div>
                <i class="fa-solid fa-arrow-right" style="color:var(--text-dim);font-size:13px;"></i>
            </div>
            <?php endforeach; ?>
            </div>

        </div>
    </div>
</section>
<!-- ====== /GÜVEN BANDI ====== -->

<!-- ====================================================
     ÖNE ÇIKAN ÜRÜNLER
==================================================== -->
<section class="section products-section">
    <div class="section-inner">

        <!-- Başlık -->
        <div class="section-header" style="display:flex; align-items:flex-end; justify-content:space-between; gap:16px; flex-wrap:wrap;">
            <div>
                <?php $shopTag = theme_visible('shop_tag', __('nav.shop')); if ($shopTag !== null && trim((string)$shopTag) !== ''): ?>
                <p class="section-tag"><i class="fa-solid fa-cubes"></i> <?= e($shopTag) ?></p>
                <?php endif; ?>
                <?php $shopTitle = theme_visible('shop_title', __('home.shop_title')); if ($shopTitle !== null && trim((string)$shopTitle) !== ''): ?>
                <h2 class="section-title"><?= e($shopTitle) ?></h2>
                <?php endif; ?>
                <?php $shopDesc = theme_visible('shop_desc', __('home.shop_desc')); if ($shopDesc !== null && trim((string)$shopDesc) !== ''): ?>
                <p class="section-desc"><?= e($shopDesc) ?></p>
                <?php endif; ?>
            </div>
            <a href="/products" class="btn-custom btn-indigo btn-sm" style="margin-bottom: 10px;">
                <?= __('home.all_products') ?>
                <i class="fa-solid fa-arrow-right btn-icon"></i>
            </a>
        </div>

        <!-- Ürün Kartları Grid -->
        <div class="products-grid">
            <?php if (empty($products)): ?>
            <p style="color:var(--text-muted);font-size:14px;grid-column:1/-1;text-align:center;padding:32px 0;"><?= __('home.empty_products') ?></p>
            <?php else: ?>
            <?php foreach ($products as $product):
                $stkSoldOut = (($product['stock_type'] ?? 'unlimited') === 'limited') && ((int)($product['stock'] ?? 0)) < 1;
                $pp = (float)$product['price'];
                $pd = (int)($product['discount_percent'] ?? 0);
                $pn = $pd > 0 && $pp > 0 ? $pp * (1 - $pd / 100) : $pp;
            ?>
            <?php if (function_exists('do_action')) do_action('product_card_before', $product); ?>
            <a href="<?= $stkSoldOut ? 'javascript:void(0)' : '/products?product='.(int)$product['id'] ?>" class="product-card" style="display:flex;flex-direction:column;text-decoration:none;color:inherit;<?= $stkSoldOut?'opacity:.6;':'' ?>">

                <div class="product-card-thumb">
                    <?php if (!empty($product['image_url'])): ?>
                     <img src="<?= e($product['image_url']) ?>"
                          width="360" height="160" style="width:100%;height:100%;object-fit:cover;" alt="<?= e($product['name']) ?>" loading="lazy" decoding="async">
                    <?php else: ?>
                    <i class="fa-solid fa-box" style="font-size:40px;color:var(--text-dim);"></i>
                    <?php endif; ?>
                    <?php if ($stkSoldOut): ?>
                    <span class="product-card-badge" style="bottom:auto;top:12px;background:rgba(239,68,68,.9);"><?= __('product.soldout') ?></span>
                    <?php elseif ($pd > 0): ?>
                    <span class="product-card-badge" style="bottom:auto;top:12px;background:#ff4757;color:#fff;font-weight:800;"><?= __('product.discount_pct', ['n' => $pd]) ?></span>
                    <?php endif; ?>
                </div>

                <div class="product-card-body" style="flex:1;display:flex;flex-direction:column;">
                    <p class="product-card-category">
                        <i class="fa-solid fa-tag" style="margin-right:4px;"></i>
                        <?= e($product['category'] ?? '') ?>
                    </p>
                    <h3 class="product-card-title"><?= e($product['name']) ?></h3>
                    <p class="product-card-desc"><?= htmlspecialchars(truncate_text($product['short_description'] ?? $product['description'] ?? '', 120)) ?></p>

                    <div class="product-card-footer" style="margin-top:auto;">
                        <div class="product-price">
                            <?php $pp=(float)$product['price']; $pd=(int)($product['discount_percent']??0); $pn=$pd>0&&$pp>0?$pp*(1-$pd/100):$pp; if($pp>0): if($pd>0): ?>
                            <div style="display:flex;flex-direction:column;gap:2px"><div style="display:flex;align-items:center;gap:6px"><span style="font-size:11px;color:#6b7280;text-decoration:line-through"><?= fmt_money($pp) ?></span><span style="background:#ff4757;color:#fff;font-size:10px;font-weight:800;padding:2px 6px;border-radius:50px">%<?= $pd ?></span></div><span class="product-price-current" style="color:#4f46e5"><?= fmt_money($pn) ?></span></div>
                            <?php else: ?><span class="product-price-current"><?= fmt_money($pp) ?></span><span class="product-price-label"><?= __('product.onetime') ?></span><?php endif; else: ?><span class="product-price-current" style="display:flex;align-items:center;gap:7px;white-space:nowrap;"><i class="fa-solid fa-gift"></i> <?= __('shop.free') ?></span><?php endif; ?>
                        </div>
                        <?php if ($stkSoldOut): ?>
                        <span class="btn-custom btn-indigo btn-sm" style="pointer-events:auto;opacity:.5;">
                            <i class="fa-solid fa-ban btn-icon"></i>
                            <?= __('product.soldout') ?>
                        </span>
                        <?php else: ?>
                        <span class="btn-custom btn-yellow btn-sm" onclick="event.stopPropagation();window.location='/products?product=<?= (int)$product['id'] ?>'" style="pointer-events:auto;">
                            <i class="fa-solid fa-cart-plus btn-icon"></i>
                            <?= __('cart.buy') ?>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

            </a>
            <?php if (function_exists('do_action')) do_action('product_card_after', $product); ?>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>

    </div>
</section>
<!-- ====== /ÜRÜNLER ====== -->

<?php if (feature_active('announcements')): ?>
<!-- ====================================================
     SON DUYURULAR / HABERLER
==================================================== -->
<section class="section">
    <div class="section-inner">

        <!-- Başlık -->
        <div class="section-header" style="display:flex; align-items:flex-end; justify-content:space-between; gap:16px; flex-wrap:wrap;">
            <div>
                <?php $newsTag = theme_visible('news_tag', __('home.news_tag')); if ($newsTag !== null && trim((string)$newsTag) !== ''): ?>
                <p class="section-tag"><i class="fa-solid fa-newspaper"></i> <?= e($newsTag) ?></p>
                <?php endif; ?>
                <?php $newsTitle = theme_visible('news_title', __('home.news_title')); if ($newsTitle !== null && trim((string)$newsTitle) !== ''): ?>
                <h2 class="section-title"><?= e($newsTitle) ?></h2>
                <?php endif; ?>
                <?php $newsDesc = theme_visible('news_desc', __('home.news_desc')); if ($newsDesc !== null && trim((string)$newsDesc) !== ''): ?>
                <p class="section-desc"><?= e($newsDesc) ?></p>
                <?php endif; ?>
            </div>
            <a href="/news" class="btn-custom btn-indigo btn-sm" style="margin-bottom: 10px;">
                <?= __('home.view_all') ?>
                <i class="fa-solid fa-arrow-right btn-icon"></i>
            </a>
        </div>

        <!-- Kart Grid -->
        <div class="news-grid">
            <?php if (empty($news)): ?>
            <p style="color:var(--text-muted);font-size:14px;grid-column:1/-1;text-align:center;padding:32px 0;"><?= __('home.empty_news') ?></p>
            <?php else: ?>
            <?php foreach ($news as $item): ?>
            <article class="news-card">

                <div class="news-card-img">
                    <?php if (!empty($item['image_url'])): ?>
                    <img src="<?= e($item['image_url']) ?>" style="width:100%;height:100%;object-fit:cover;" alt="<?= e($item['title']) ?>" loading="lazy" decoding="async" width="360" height="180">
                    <?php else: ?>
                    <i class="fa-solid fa-bullhorn" style="font-size:40px;color:var(--text-dim);"></i>
                    <?php endif; ?>
                </div>

                <div class="news-card-body">
                    <div class="news-card-meta">
                        <span class="tag"><?= __('news.announcement') ?></span>
                        <span><i class="fa-regular fa-calendar" style="margin-right:4px;"></i><?= tr_date('d M Y', strtotime($item['created_at'])) ?></span>
                    </div>

                    <h3 class="news-card-title"><?= e($item['title']) ?></h3>
                    <p class="news-card-desc"><?= e(truncate_text($item['content'])) ?></p>

                    <div class="news-card-footer">
                        <a href="/news?slug=<?= urlencode($item['slug'] ?? '') ?>" class="btn-custom btn-yellow btn-sm">
                            <span class="btn-icon">➜</span>
                            <?= __('home.read_more') ?>
                        </a>
                    </div>
                </div>

            </article>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>

    </div>
</section>
<!-- ====== /DUYURULAR ====== -->
<?php endif; ?>

<?php if (feature_active('references')): ?>
<!-- ====================================================
     REFERANSLAR
==================================================== -->
<section class="section" style="background:rgba(var(--accent,99,102,241),.04);">
    <div class="section-inner">

        <div class="section-header" style="text-align:center;">
            <?php $refsTag = theme_visible('refs_tag', __('home.refs_tag')); if ($refsTag !== null && trim((string)$refsTag) !== ''): ?>
            <p class="section-tag" style="justify-content:center;"><i class="fa-solid fa-quote-left"></i> <?= e($refsTag) ?></p>
            <?php endif; ?>
            <?php $refsTitle = theme_visible('refs_title', __('home.refs_title')); if ($refsTitle !== null && trim((string)$refsTitle) !== ''): ?>
            <h2 class="section-title" style="margin-left:auto; margin-right:auto;"><?= e($refsTitle) ?></h2>
            <?php endif; ?>
        </div>

        <?php if (empty($references)): ?>
        <p style="color:var(--text-muted);font-size:14px;text-align:center;padding:32px 0;"><?= __('home.empty_refs') ?></p>

        <?php elseif ($useSlider): ?>

        <style>
        .ref-slider-wrap{position:relative;overflow:hidden;margin-top:8px;}
        .ref-slider-viewport{overflow:hidden;border-radius:20px;}
        .ref-slider-track{display:flex;gap:16px;width:max-content;will-change:transform;}
        .ref-slider-card{flex:0 0 auto;box-sizing:border-box;width:360px;}
        @media(max-width:480px){.ref-slider-card{width:300px;}}
        .ref-slider-card:hover{position:relative;z-index:2;}
        .ref-slider-card:hover .ref-card-inner{border-color:rgba(99,102,241,.45);box-shadow:0 12px 34px rgba(99,102,241,.28);}
        .ref-card-inner{height:100%;background:var(--bg-card, #13131c);border:1px solid rgba(255,255,255,.08);border-radius:18px;padding:28px;display:flex;flex-direction:column;box-sizing:border-box;transition:border-color .3s ease,box-shadow .3s ease;}
        .ref-card-top{display:flex;align-items:center;gap:14px;margin-bottom:18px;}
        .ref-avatar{width:58px;height:58px;border-radius:50%;object-fit:cover;flex-shrink:0;background:rgba(99,102,241,.15);display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:800;color:#a5b4fc;}
        .ref-card-name{font-size:15px;font-weight:800;}
        .ref-card-title{font-size:13px;color:#a5b4fc;font-weight:600;margin-top:2px;}
        .ref-card-stars{color:#facc15;font-size:14px;margin-top:6px;letter-spacing:2px;}
        .ref-card-stars .fa-regular{color:var(--text-dim, #5a6070);}
        .ref-card-msg{font-size:14px;color:var(--text-muted, #9aa0ae);line-height:1.8;font-style:italic;}
        </style>

        <div class="ref-slider-wrap">
            <div class="ref-slider-viewport" id="refViewport">
                <div class="ref-slider-track" id="refTrack">
                    <?php foreach ($references as $ref): ?>
                    <div class="ref-slider-card">
                        <div class="ref-card-inner">
                            <i class="fa-solid fa-quote-left" style="font-size:26px;color:rgba(99,102,241,.35);margin-bottom:14px;"></i>
                            <p class="ref-card-msg"><?= nl2br(e($ref['message'] ?? 'Yorum bulunmuyor.')) ?></p>
                            <div style="margin-top:auto;padding-top:18px;border-top:1px solid rgba(255,255,255,.07);">
                                <div class="ref-card-top">
                                    <?php if (!empty($ref['photo_url'])): ?>
                                    <img src="<?= e($ref['photo_url']) ?>" class="ref-avatar" alt="<?= e($ref['name']) ?>" loading="lazy" decoding="async" width="58" height="58">
                                    <?php else: ?>
                                    <div class="ref-avatar"><?= htmlspecialchars(mb_strtoupper(mb_substr($ref['name'],0,1))) ?></div>
                                    <?php endif; ?>
                                    <div>
                                        <div class="ref-card-name"><?= e($ref['name']) ?></div>
                                        <?php if (!empty($ref['title'])): ?><div class="ref-card-title"><?= e($ref['title']) ?></div><?php endif; ?>
                                    </div>
                                </div>
                                <div class="ref-card-stars"><?= ref_stars((int)$ref['rating']) ?></div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <script>
        (function(){
            var vp=document.getElementById('refViewport');
            var track=document.getElementById('refTrack');
            if(!vp||!track)return;
            var cards=Array.prototype.slice.call(track.querySelectorAll('.ref-slider-card'));
            var n=cards.length; if(n===0)return;
            cards.forEach(function(c){ track.appendChild(c.cloneNode(true)); });
            var step=0, setW=0, offset=0, speed=30, running=true, last=0;
            function layout(){
                var w=track.children[0]?track.children[0].getBoundingClientRect().width:360;
                step=w+16;
                setW=n*step;
            }
            function frame(ts){
                if(last===0)last=ts;
                var dt=(ts-last)/1000;
                last=ts;
                if(running){
                    offset=(offset+speed*dt)%setW;
                    track.style.transform='translateX('+(-offset)+'px)';
                }
                requestAnimationFrame(frame);
            }
            window.addEventListener('resize',layout);
            layout();
            vp.addEventListener('mouseenter',function(){running=false;});
            vp.addEventListener('mouseleave',function(){running=true;});
            requestAnimationFrame(frame);
        })();
        </script>

        <?php else: ?>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,360px));justify-content:center;gap:22px;margin-top:8px;">
            <?php foreach ($references as $ref): ?>
            <div style="background:var(--bg-card);border:1px solid rgba(255,255,255,.08);border-radius:18px;padding:26px;display:flex;flex-direction:column;transition:transform .25s,border-color .25s;"
                 onmouseover="this.style.transform='translateY(-4px)';this.style.borderColor='rgba(99,102,241,.35)';"
                 onmouseout="this.style.transform='translateY(0)';this.style.borderColor='rgba(255,255,255,.08)';">
                <i class="fa-solid fa-quote-left" style="font-size:26px;color:rgba(99,102,241,.35);margin-bottom:14px;"></i>
                <p style="font-size:14px;color:var(--text-muted);line-height:1.8;font-style:italic;"><?= nl2br(e($ref['message'] ?? 'Yorum bulunmuyor.')) ?></p>
                <div style="display:flex;align-items:center;gap:14px;margin-top:auto;padding-top:18px;border-top:1px solid rgba(255,255,255,.07);">
                    <?php if (!empty($ref['photo_url'])): ?>
                    <img src="<?= e($ref['photo_url']) ?>" style="width:54px;height:54px;border-radius:50%;object-fit:cover;flex-shrink:0;" alt="<?= e($ref['name']) ?>" loading="lazy" decoding="async" width="54" height="54">
                    <?php else: ?>
                    <div style="width:54px;height:54px;border-radius:50%;background:rgba(99,102,241,.15);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;color:#a5b4fc;flex-shrink:0;"><?= htmlspecialchars(mb_strtoupper(mb_substr($ref['name'],0,1))) ?></div>
                    <?php endif; ?>
                    <div>
                        <div style="font-size:15px;font-weight:800;"><?= e($ref['name']) ?></div>
                        <?php if (!empty($ref['title'])): ?><div style="font-size:13px;color:#a5b4fc;font-weight:600;margin-top:2px;"><?= e($ref['title']) ?></div><?php endif; ?>
                        <div style="color:#facc15;font-size:13px;margin-top:6px;letter-spacing:2px;"><?= ref_stars((int)$ref['rating']) ?></div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <?php endif; ?>

    </div>
</section>
<!-- ====== /REFERANSLAR ====== -->
<?php endif; ?>

<?php $faqs = function_exists('faqs_fetch') ? faqs_fetch($db ?? null) : []; if (!empty($faqs)): ?>
<section class="section" id="sss" style="padding:60px 0">
  <div class="container" style="max-width:760px;margin:0 auto">
    <div style="text-align:center;margin-bottom:1.5rem">
      <span style="display:inline-flex;align-items:center;gap:8px;background:rgba(99,102,241,.12);border:1px solid rgba(99,102,241,.25);color:#a5b4fc;border-radius:50px;padding:6px 14px;font-size:.8rem;font-weight:700"><i class="fa-solid fa-circle-question"></i> SSS</span>
      <?php $faqTitle = theme_visible('faq_title', __('home.faq_title')); if ($faqTitle !== null && trim((string)$faqTitle) !== ''): ?>
      <h2 style="font-size:1.8rem;font-weight:800;margin-top:.8rem"><?= e($faqTitle) ?></h2>
      <?php endif; ?>
    </div>
    <div style="display:flex;flex-direction:column;gap:10px">
      <?php foreach ($faqs as $f): ?>
      <div class="faq-item" style="background:var(--bg-card);border:1px solid rgba(255,255,255,.08);border-radius:14px;overflow:hidden">
        <button type="button" class="faq-q" style="width:100%;display:flex;justify-content:space-between;align-items:center;padding:14px 18px;font-weight:700;background:none;border:none;color:inherit;cursor:pointer;font-family:inherit;font-size:inherit;text-align:left;gap:12px"><span><?= e($f['question']) ?></span><i class="fa-solid fa-chevron-down faq-chevron" style="transition:transform .3s;flex-shrink:0"></i></button>
        <div class="faq-a"><div style="padding:0 18px 14px;color:var(--text-muted);font-size:.92rem;line-height:1.7"><?= nx_clean_html((string)($f['answer'] ?? ''), 'rich') ?></div></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<style>.faq-item.open{border-color:rgba(99,102,241,.35)} .faq-item.open .faq-chevron{transform:rotate(180deg)} .faq-q:focus{outline:none}</style>
<script>
(function(){
  var items=document.querySelectorAll('.faq-item');
  items.forEach(function(item){
    var btn=item.querySelector('.faq-q');
    var body=item.querySelector('.faq-a');
    if(!btn||!body) return;
    body.style.overflow='hidden';
    body.style.height='0px';
    body.style.transition='height .35s ease';
    btn.addEventListener('click',function(){
      var isOpen=item.classList.contains('open');
      items.forEach(function(el){
        el.classList.remove('open');
        var b=el.querySelector('.faq-a');
        if(b) b.style.height='0px';
      });
      if(!isOpen){
        item.classList.add('open');
        var h=body.scrollHeight;
        body.style.height='0px';
        requestAnimationFrame(function(){requestAnimationFrame(function(){body.style.height=h+'px';});});
      }
    });
  });
})();
</script>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
