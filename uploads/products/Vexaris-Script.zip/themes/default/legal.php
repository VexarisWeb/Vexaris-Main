<?php
defined('NEXUS_BOOT') or die;

$p = trim($_GET['p'] ?? '');
$allowed = ['cookie-policy','privacy-policy','terms-of-service','refund-policy'];
$titles = [
    'cookie-policy'    => [__('legal.cookies'),    'fa-solid fa-cookie-bite'],
    'privacy-policy'   => [__('legal.privacy'), 'fa-solid fa-shield-halved'],
    'terms-of-service' => [__('legal.terms'),   'fa-solid fa-file-contract'],
    'refund-policy'    => [__('legal.refund'),      'fa-solid fa-rotate-left'],
];

$legalContent = null;
$db = nexus_db();
if ($p && in_array($p, $allowed, true) && $db) {
    $st = $db->prepare('SELECT * FROM legal_pages WHERE slug=?');
    $st->execute([$p]);
    $legalContent = $st->fetch();
    if (!$legalContent) {
        $legalContent = ['title' => ($titles[$p][0] ?? $p), 'content' => '', 'updated_at' => ''];
    }
    $pageTitle = $legalContent['title'];
}

$seoKey    = ($p && in_array($p, $allowed, true)) ? 'legal_' . $p : '';
$pageTitle = $pageTitle ?? __('legal.index_title');

include ROOT_PATH . '/themes/default/includes/header.php';

$siteName = $_headerSiteName ?? 'Vexaris';
?>
<main style="min-height:80vh;padding:48px 24px 72px;max-width:960px;margin:0 auto;">
    <div style="margin-bottom:40px;">
        <h1 style="font-size:28px;font-weight:900;margin-bottom:8px;"><?= __('legal.index_title') ?></h1>
        <p style="color:var(--muted);font-size:14px;"><?= __('legal.sub') ?></p>
    </div>

    <?php if ($legalContent && $p && in_array($p, $allowed, true)): ?>
    <?php
    $icon = $titles[$p][1] ?? 'fa-solid fa-file';
    $displayTitle = $legalContent['title'] ?: ($titles[$p][0] ?? $p);
    $body = function_exists('legal_body_html') ? legal_body_html((string)($legalContent['content'] ?? ''), $siteName) : e((string)($legalContent['content'] ?? ''));
    ?>
    <style>
    .md-nav{display:flex;gap:8px;margin-bottom:28px;flex-wrap:wrap;}
    .md-nav a{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:999px;font-size:12px;font-weight:700;color:var(--muted);background:var(--bg-surface);border:1px solid var(--border);text-decoration:none;}
    .md-nav a.on{color:#fff;background:rgba(99,102,241,.16);border-color:rgba(99,102,241,.4);}
    .md-hero{display:flex;align-items:center;gap:16px;margin-bottom:8px;}
    .md-hero-ic{width:52px;height:52px;border-radius:14px;background:rgba(99,102,241,.12);display:flex;align-items:center;justify-content:center;font-size:22px;color:#818cf8;flex-shrink:0;}
    .md-body{color:var(--text);font-size:15px;line-height:1.85;}
    .md-body h2{font-size:21px;font-weight:900;margin:30px 0 12px;letter-spacing:-.01em;}
    .md-body h2:first-child{margin-top:0;}
    .md-body h3{font-size:17px;font-weight:800;margin:24px 0 10px;}
    .md-body h4{font-size:15px;font-weight:800;margin:18px 0 8px;}
    .md-body p{margin:0 0 14px;color:var(--text-muted);}
    .md-body ul,.md-body ol{margin:0 0 16px;padding-left:22px;display:grid;gap:8px;color:var(--text-muted);}
    .md-body li::marker{color:#818cf8;font-weight:800;}
    .md-body strong{color:var(--text);}
    .md-body a{color:#818cf8;font-weight:600;}
    .md-body blockquote{border-left:3px solid rgba(99,102,241,.5);padding:6px 14px;color:var(--text-muted);background:rgba(99,102,241,.06);border-radius:0 10px 10px 0;margin:0 0 14px;}
    </style>
    <div class="md-nav">
        <a href="/legal"><i class="fa-solid fa-arrow-left"></i> <?= __('legal.all_pages') ?></a>
        <?php foreach ($allowed as $slug): ?>
        <a href="/legal?p=<?= urlencode($slug) ?>" class="<?= $slug === $p ? 'on' : '' ?>"><?= e($titles[$slug][0]) ?></a>
        <?php endforeach; ?>
    </div>

    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:18px;padding:40px 44px;">
        <div class="md-hero" style="padding-bottom:20px;border-bottom:1px solid var(--border);margin-bottom:8px;">
            <div class="md-hero-ic">
                <i class="<?= $icon ?>"></i>
            </div>
            <div>
                <h2 style="font-size:22px;font-weight:900;"><?= e($displayTitle) ?></h2>
                <?php if ($legalContent['updated_at']): ?>
                <p style="font-size:12px;color:var(--muted);"><?= __('legal.updated') ?> <?= e($legalContent['updated_at']) ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="md-body">
            <?= $body ?>
        </div>
    </div>

    <?php else: ?>

    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px;">
        <?php foreach ($allowed as $slug):
        $info = $titles[$slug];
        ?>
        <a href="/legal?p=<?= urlencode($slug) ?>" style="display:block;background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:24px 20px;text-decoration:none;transition:border-color .2s;color:inherit;" onmouseover="this.style.borderColor='rgba(99,102,241,.35)'" onmouseout="this.style.borderColor='var(--border)'">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(99,102,241,.12);display:flex;align-items:center;justify-content:center;font-size:18px;color:#818cf8;margin-bottom:14px;">
                <i class="<?= $info[1] ?>"></i>
            </div>
            <h3 style="font-size:14px;font-weight:800;margin-bottom:4px;"><?= e($info[0]) ?></h3>
            <p style="font-size:11px;color:var(--muted);"><?= __('legal.click_detail') ?></p>
        </a>
        <?php endforeach; ?>
    </div>

    <?php endif; ?>
</main>

<?php include ROOT_PATH . '/themes/default/includes/footer.php'; ?>
