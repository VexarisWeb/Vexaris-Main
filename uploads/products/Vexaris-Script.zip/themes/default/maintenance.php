<?php
$mSiteName = 'Vexaris';
$mFavicon  = null;
$mDb = nexus_db();
if ($mDb) {
    try {
        $mStmt = $mDb->prepare("SELECT `key`,`value` FROM settings WHERE `key` IN ('site_name','site_favicon')");
        $mStmt->execute();
        foreach ($mStmt->fetchAll() as $mRow) {
            if ($mRow['key'] === 'site_name')    $mSiteName = $mRow['value'];
            if ($mRow['key'] === 'site_favicon') $mFavicon  = $mRow['value'];
        }
    } catch (\Exception $e) {}
}
http_response_code(503);
?><!DOCTYPE html>
<html lang="<?= lang_active() ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex,nofollow">
<?php if ($mFavicon): ?><link rel="icon" href="<?= e($mFavicon) ?>"><?php endif; ?>
<title><?= __('maint.title') ?> — <?= e($mSiteName) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Plus Jakarta Sans',sans-serif;background:#0b0f17;color:#e8eaf6;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:40px 24px;text-align:center;}
.m-wrap{display:flex;flex-direction:column;align-items:center;gap:16px;max-width:420px;}
.m-gear{font-size:52px;color:rgba(99,102,241,0.3);animation:m-spin 2.5s linear infinite;}
@keyframes m-spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
.m-site{font-size:20px;font-weight:900;letter-spacing:0.08em;text-transform:uppercase;background:linear-gradient(135deg,#a5b4fc,#6366f1,#fbc853);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
.m-title{font-size:28px;font-weight:900;margin-top:8px;}
.m-desc{font-size:14px;color:#7b82a0;font-weight:500;line-height:1.7;}
.m-btn{display:inline-flex;align-items:center;gap:8px;margin-top:16px;padding:12px 36px;font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;font-weight:800;border-radius:14px;border:1px solid #3730a3;background:linear-gradient(180deg,#6366f1,#4f46e5);color:#fff;text-decoration:none;cursor:pointer;box-shadow:0 4px 0 #3730a3,0 8px 20px rgba(0,0,0,0.4);transition:transform 0.05s,box-shadow 0.05s;user-select:none;}
.m-btn:active{transform:translateY(3px);box-shadow:0 1px 0 #3730a3,0 4px 10px rgba(0,0,0,0.4);}
</style>
</head>
<body>
<div class="m-wrap">
    <i class="fa-solid fa-gear m-gear"></i>
    <span class="m-site"><?= e($mSiteName) ?></span>
    <h1 class="m-title"><?= __('maint.heading') ?></h1>
    <p class="m-desc"><?= __('maint.desc') ?></p>
    <a href="/login" class="m-btn"><i class="fa-solid fa-right-to-bracket"></i> <?= __('auth.do_login') ?></a>
</div>
<?php
if (function_exists('tawkto_widget_code')) {
    $twkWidget = tawkto_widget_code();
    if ($twkWidget) echo $twkWidget;
}
if (function_exists('jivochat_widget_code')) {
    $jvWidget = jivochat_widget_code();
    if ($jvWidget) echo $jvWidget;
}
if (function_exists('crisp_widget_code')) {
    $crWidget = crisp_widget_code();
    if ($crWidget) echo $crWidget;
}
?>
</body>
</html>
