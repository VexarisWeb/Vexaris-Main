<?php
$pageTitle  = __('nav.news');
$activePage = 'news';

if (!feature_active('announcements')) {
    http_response_code(404);
    theme_load('404');
    exit;
}

$db = nexus_db();

$slug   = trim($_GET['slug'] ?? '');
$single = null;

if ($slug && $db) {
    $st = $db->prepare('SELECT * FROM announcements WHERE slug = ? AND status="published" LIMIT 1');
    $st->execute([$slug]);
    $single = $st->fetch() ?: null;
    if ($single) $pageTitle = e($single['title']) . ' — ' . __('nav.news');
}

$seoKey = $single ? '' : 'news';

$news = [];
if (!$single && $db) {
    $st = $db->prepare('SELECT id, title, slug, content, image_url, created_at FROM announcements WHERE status="published" ORDER BY id DESC');
    $st->execute();
    $news = $st->fetchAll();
}

include __DIR__ . '/includes/header.php';
?>
<main style="flex:1;">
<section class="section">
<div class="section-inner">

<?php if ($single): ?>

    <div style="margin-bottom:24px;">
        <a href="/news" style="display:inline-flex;align-items:center;gap:6px;font-size:13px;font-weight:700;color:var(--text-muted);text-decoration:none;transition:color .2s;"
           onmouseover="this.style.color='var(--accent)'" onmouseout="this.style.color='var(--text-muted)'">
            <i class="fa-solid fa-arrow-left"></i> <?= __('news.all') ?>
        </a>
    </div>

    <article style="max-width:780px;margin:0 auto;">

        <?php if (!empty($single['image_url'])): ?>
        <div style="width:100%;aspect-ratio:16/9;border-radius:18px;overflow:hidden;margin-bottom:28px;border:1px solid var(--border);">
            <img src="<?= e($single['image_url']) ?>" alt="<?= e($single['title']) ?>"
                 style="width:100%;height:100%;object-fit:cover;" width="560" height="315">
        </div>
        <?php endif; ?>

        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap;">
            <span class="tag"><?= __('news.announcement') ?></span>
            <span style="font-size:12px;color:var(--text-muted);display:flex;align-items:center;gap:4px;">
                <i class="fa-regular fa-calendar"></i>
                <?= tr_date('d M Y', strtotime($single['created_at'])) ?>
            </span>
        </div>

        <h1 style="font-size:clamp(22px,4vw,34px);font-weight:900;line-height:1.25;margin-bottom:20px;">
            <?= e($single['title']) ?>
        </h1>

        <div style="
            font-size:15px;line-height:1.85;color:var(--text-muted);
            background:var(--bg-card);border:1px solid var(--border);
            border-radius:16px;padding:28px 32px;
        " class="ann-body">
            <?= $single['content'] ?>
        </div>

    </article>

<?php else: ?>

    <div class="section-header">
        <p class="section-tag"><i class="fa-solid fa-newspaper"></i> <?= __('nav.news') ?></p>
        <h1 class="section-title"><?= __('news.page_title') ?></h1>
        <p class="section-desc"><?= __('news.sub') ?></p>
    </div>

    <?php if (empty($news)): ?>
    <div style="text-align:center;padding:80px 20px;color:var(--text-muted);">
        <i class="fa-solid fa-newspaper" style="font-size:48px;color:var(--text-dim);margin-bottom:16px;display:block;"></i>
        <p style="font-size:15px;font-weight:600;"><?= __('news.empty') ?></p>
    </div>
    <?php else: ?>
    <div class="news-grid">
        <?php foreach ($news as $item): ?>
        <article class="news-card">

            <div class="news-card-img">
                <?php if (!empty($item['image_url'])): ?>
                <img src="<?= e($item['image_url']) ?>"
                     style="width:100%;height:100%;object-fit:cover;" alt="<?= e($item['title']) ?>" width="320" height="180">
                <?php else: ?>
                <i class="fa-solid fa-bullhorn" style="font-size:40px;color:var(--text-dim);"></i>
                <?php endif; ?>
            </div>

            <div class="news-card-body">
                <div class="news-card-meta">
                    <span class="tag"><?= __('news.announcement') ?></span>
                    <span><i class="fa-regular fa-calendar" style="margin-right:4px;"></i>
                        <?= tr_date('d M Y', strtotime($item['created_at'])) ?>
                    </span>
                </div>
                <h3 class="news-card-title"><?= e($item['title']) ?></h3>
                <p class="news-card-desc"><?= htmlspecialchars(truncate_text($item['content'], 130)) ?></p>
                <div class="news-card-footer">
                    <a href="/news?slug=<?= urlencode($item['slug']) ?>" class="btn-custom btn-yellow btn-sm">
                        <span class="btn-icon">➜</span> <?= __('home.read_more') ?>
                    </a>
                </div>
            </div>

        </article>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

<?php endif; ?>

</div>
</section>

<style>
.ann-body h1,.ann-body h2,.ann-body h3{color:var(--text);margin-bottom:10px;margin-top:22px;}
.ann-body strong{color:var(--text);}
.ann-body code{background:rgba(255,255,255,0.07);padding:2px 7px;border-radius:5px;font-size:13px;}
.ann-body pre{background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:10px;padding:16px;overflow-x:auto;margin:14px 0;}
.ann-body ul{padding-left:20px;margin:10px 0;}
.ann-body li{margin-bottom:4px;}
.ann-body a{color:var(--accent);text-decoration:underline;}
</style>

</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
