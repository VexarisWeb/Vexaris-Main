<?php
$db  = nexus_db();
$me  = auth_check() ? auth_user() : null;
$pid = isset($_GET['product']) ? (int)$_GET['product'] : 0;

$viewTab = $_GET['tab'] ?? 'shop';

$flash = $_GET['flash'] ?? '';
[$flashType, $flashText] = $flash ? explode(':', urldecode($flash), 2) + ['',''] : ['', ''];

$balance = 0.00;
if ($me && $db) {
    $bRow = $db->prepare('SELECT balance FROM users WHERE id=?');
    $bRow->execute([$me['id']]);
    $balance = (float)($bRow->fetchColumn() ?? 0);
}

$selCat  = trim($_GET['cat'] ?? '');
$products = [];
$allCats  = [];
if ($db) {
    try {
        $allCats = $db->query("SELECT name,icon,description FROM categories ORDER BY sort_order ASC, name ASC")->fetchAll();
    } catch (\Exception $e) { $allCats = []; }
    $avgSub = '(SELECT COALESCE(ROUND(AVG(c.rating),1),0) FROM comments c WHERE c.product_id=p.id AND c.rating>0)';
    try {
        if ($selCat) {
            $pSt = $db->prepare("SELECT p.*, $avgSub AS avg_rating FROM products p WHERE p.is_active=1 AND p.is_hidden=0 AND p.status='active' AND p.category=? ORDER BY p.created_at DESC");
            $pSt->execute([$selCat]);
            $products = $pSt->fetchAll();
        } else {
            $products = $db->query("SELECT p.*, $avgSub AS avg_rating FROM products p WHERE p.is_active=1 AND p.is_hidden=0 AND p.status='active' ORDER BY p.created_at DESC")->fetchAll();
        }
    } catch (\Exception $e) { $products = []; }
}

$activeProduct = null;
$comments      = [];
$userCart      = [];
$ownedIds      = [];

if ($db) {
    try {
        if ($pid) {
            $avgSub = '(SELECT COALESCE(ROUND(AVG(c.rating),1),0) FROM comments c WHERE c.product_id=p.id AND c.rating>0)';
            $cntSub = '(SELECT COUNT(*) FROM comments c WHERE c.product_id=p.id AND c.rating>0)';
            $stmt = $db->prepare("SELECT p.*, $avgSub AS avg_rating, $cntSub AS rating_count FROM products p WHERE p.id=? AND p.is_hidden=0 AND p.is_active=1 AND p.status='active'");
            $stmt->execute([$pid]);
            $activeProduct = $stmt->fetch();
            if ($activeProduct) {
                if (feature_active('reviews')) {
                $cStmt = $db->prepare(
                    'SELECT c.*,u.username,u.avatar FROM comments c
                     LEFT JOIN users u ON u.id=c.user_id
                     WHERE c.product_id=? ORDER BY c.created_at ASC'
                );
                $cStmt->execute([$pid]);
                $comments = $cStmt->fetchAll();
                }
            }
        }
        if ($me) {
            $cartStmt = $db->prepare(
                'SELECT c.*,p.name,p.price,p.image_url FROM cart c
                 JOIN products p ON p.id=c.product_id WHERE c.user_id=?'
            );
            $cartStmt->execute([$me['id']]);
            $userCart = $cartStmt->fetchAll();

            $ownedStmt = $db->prepare('SELECT product_id FROM sales WHERE user_id=?');
            $ownedStmt->execute([$me['id']]);
            $ownedIds = $ownedStmt->fetchAll(PDO::FETCH_COLUMN);
        }
    } catch (\Exception $e) {}
}

$purchases = [];
if ($me && $db && $viewTab === 'purchases') {
    try {
        $pStmt = $db->prepare(
            'SELECT s.id AS sale_id, s.license_key, s.price_paid, s.purchased_at,
                    p.id AS product_id, p.name, p.image_url, p.file_path, p.category, p.version
             FROM sales s
             JOIN products p ON p.id = s.product_id
             WHERE s.user_id = ?
             ORDER BY s.purchased_at DESC'
        );
        $pStmt->execute([$me['id']]);
        $purchases = $pStmt->fetchAll();
    } catch (\Exception $e) { $purchases = []; }
}

$cartTotal = array_sum(array_map(fn($i) => $i['price'] * $i['quantity'], $userCart));
$cartCount = array_sum(array_map(fn($i) => $i['quantity'], $userCart));

$ownComment = null;
if ($me && !empty($comments)) {
    foreach ($comments as $comment) {
        if ((int)$comment['user_id'] === (int)$me['id']) { $ownComment = $comment; break; }
    }
}

$productVersions = [];
if ($db && $activeProduct && function_exists('product_versions_list')) {
    $productVersions = product_versions_list($db, (int)$activeProduct['id']);
}

$pageTitle  = __('nav.shop');
$activePage = 'products';
$seoKey     = $activeProduct ? '' : 'products';

$vxTailwind = true;
include ROOT_PATH . '/themes/default/includes/header.php';

?>
<style>
.btn-shop-yellow{background:linear-gradient(180deg,#fbc853 0%,#f7b131 100%);color:#4c3716;border:1px solid #d39522;transition:transform .05s ease,box-shadow .05s ease,filter .2s ease;}
.btn-shop-yellow:hover{filter:brightness(1.08);}
.btn-shop-yellow:active{transform:translateY(4px)!important;box-shadow:0 1px 0 0 #a26e13!important;}
.btn-shop-indigo{background:linear-gradient(180deg,#6366f1 0%,#4f46e5 100%);color:#fff;border:1px solid #3730a3;transition:transform .05s ease,box-shadow .05s ease,filter .2s ease;}
.btn-shop-indigo:hover{filter:brightness(1.1);}
.btn-shop-indigo:active{transform:translateY(4px)!important;box-shadow:0 1px 0 0 #3730a3!important;}
.nx-star-box{width:44px;height:44px;background:#1c2330;border:1px solid rgba(255,255,255,.14);border-radius:9px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background .2s ease,transform .1s ease,border-color .2s ease;}
.nx-star-box:hover{transform:scale(1.05);}
.nx-star-box.active{background:#FFD700;border-color:#FFD700;box-shadow:0 0 12px rgba(255,215,0,.35);}
.nx-star-box i{font-size:1.35rem;color:#fff;transition:color .2s ease;filter:drop-shadow(0 1px 2px rgba(0,0,0,.25));}
.nx-btn-gold{background:linear-gradient(180deg,#fbbf24 0%,#f59e0b 100%);color:#1f2937;border:1px solid #d97706;font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;letter-spacing:.02em;box-shadow:0 3px 0 #b45309;transition:transform .05s ease,box-shadow .05s ease,filter .2s ease;cursor:pointer;}
.nx-btn-gold:hover{filter:brightness(1.06);}
.nx-btn-gold:active{transform:translateY(3px);box-shadow:0 1px 0 #b45309;}
.nx-rating-label{font-size:11px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:#94a3b8;margin-bottom:10px;display:block;}
.nx-modal-overlay{animation:nxFadeIn .18s ease;}
.nx-modal-card{animation:nxModalIn .3s cubic-bezier(.34,1.56,.64,1);}
.nx-modal-close{width:34px;height:34px;flex:none;border-radius:10px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:#94a3b8;display:flex;align-items:center;justify-content:center;font-size:16px;cursor:pointer;padding:0;transition:all .2s;}
.nx-modal-close:hover{background:#ef4444;border-color:#ef4444;color:#fff;}
@keyframes nxFadeIn{from{opacity:0;}to{opacity:1;}}
@keyframes nxModalIn{from{opacity:0;transform:translateY(20px) scale(.96);}to{opacity:1;transform:translateY(0) scale(1);}}
</style>
<style>
<?php readfile(ROOT_PATH . '/themes/default/assets/css/easymde-theme.css'); ?>
.EasyMDEContainer .CodeMirror{min-height:110px;max-height:none;}
.EasyMDEContainer .editor-toolbar button{display:inline-flex;}
</style>
<style>
.purchase-modal-enter{animation:purchaseFadeIn .25s ease;}
@keyframes purchaseFadeIn{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}
</style>
<?php if ($flashText): ?>
<div class="max-w-7xl mx-auto px-4 mt-4">
    <div class="<?= $flashType==='success'?'bg-green-900/30 border-green-700 text-green-300':'bg-red-900/30 border-red-700 text-red-300' ?> border rounded-xl px-4 py-3 text-sm font-semibold flex items-center gap-2">
        <i class="fa-solid fa-<?= $flashType==='success'?'circle-check':'circle-xmark' ?>"></i>
        <?= e($flashText) ?>
    </div>
</div>
<?php endif; ?>

<!-- ── ANA İÇERİK ── -->
<main class="flex-1 max-w-7xl mx-auto px-4 py-8 w-full">

<?php if ($viewTab === 'purchases'): ?>
<!-- ══ SATIN ALDIKLARIM ══ -->
<div>
    <div class="flex items-end justify-between flex-wrap gap-2 mb-6">
        <div>
            <p class="text-xs font-black text-indigo-400 tracking-widest uppercase mb-1"><?= __('library.tag') ?></p>
            <h1 class="text-2xl font-black"><?= __('library.title') ?></h1>
        </div>
        <a href="/products" class="flex items-center gap-2 text-sm text-slate-400 hover:text-white transition">
            <i class="fa-solid fa-arrow-left"></i> <?= __('library.back') ?>
        </a>
    </div>

    <?php if (empty($purchases)): ?>
    <div class="text-center py-20 text-slate-500">
        <i class="fa-solid fa-box-archive text-5xl mb-4 block text-slate-700"></i>
        <p class="font-semibold text-base mb-2"><?= __('library.empty') ?></p>
        <a href="/products" class="btn-shop-indigo inline-flex items-center gap-2 text-sm font-bold px-4 py-2 rounded-xl transition mt-2" style="box-shadow:0 4px 0 #3730a3;">
            <i class="fa-solid fa-store"></i> <?= __('library.go_shop') ?>
        </a>
    </div>
    <?php else: ?>
    <div class="flex flex-col gap-4">
        <?php foreach ($purchases as $pur):
            $purSafe = [
                'sale_id' => $pur['sale_id'],
                'name' => $pur['name'],
                'image_url' => $pur['image_url'],
                'category' => $pur['category'],
                'version' => $pur['version'],
                'purchased_at' => $pur['purchased_at'],
                'price_paid' => $pur['price_paid'],
                'license_key' => $pur['license_key'],
                'has_file' => $pur['file_path'] ? 1 : 0,
            ];
        ?>
        <div class="bg-[#0f1520] border border-white/8 rounded-2xl overflow-hidden hover:border-indigo-500/30 transition cursor-pointer" onclick="openPurchasePopup(<?= htmlspecialchars(json_encode($purSafe, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP)) ?>)">
            <div class="flex items-start gap-4 p-5">

                <!-- Ürün Görseli -->
                <?php if ($pur['image_url']): ?>
                <img src="<?= e($pur['image_url']) ?>"
                     width="64" height="64" class="w-16 h-16 rounded-xl object-cover flex-shrink-0 border border-white/10" style="width:4rem;height:4rem;object-fit:cover;" loading="lazy" decoding="async" alt="<?= e($pur['name']) ?>">
                <?php else: ?>
                <div class="w-16 h-16 rounded-xl bg-white/5 flex items-center justify-center text-3xl text-slate-700 flex-shrink-0 border border-white/8">
                    <i class="fa-solid fa-cube"></i>
                </div>
                <?php endif; ?>

                <div class="flex-1 min-w-0">
                    <div class="flex items-start justify-between gap-3 flex-wrap">
                        <div>
                            <h3 class="font-black text-base"><?= e($pur['name']) ?></h3>
                            <p class="text-xs text-slate-500 mt-0.5">
                                <?= $pur['category'] ? e($pur['category']).' · ' : '' ?>
                                v<?= e($pur['version']) ?>
                                · <?= __('library.purchased_on') ?> <?= date('d.m.Y H:i', strtotime($pur['purchased_at'])) ?>
                                · <span class="text-yellow-500 font-semibold"><?= fmt_money($pur['price_paid']) ?></span>
                            </p>
                        </div>

                        <div class="flex items-center gap-2 flex-shrink-0" onclick="event.stopPropagation()">
                            <?php if ($pur['file_path']): ?>
                            <a href="/download.php?sale_id=<?= $pur['sale_id'] ?>"
                               class="flex items-center gap-1.5 bg-green-600 hover:bg-green-500 text-white text-xs font-bold px-3 py-2 rounded-lg transition" style="box-shadow:0 3px 0 #15803d;">
                                <i class="fa-solid fa-download"></i> <?= __('library.download') ?>
                            </a>
                            <?php endif; ?>
                            <a href="/products?product=<?= $pur['product_id'] ?>"
                               class="flex items-center gap-1.5 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 text-xs font-semibold px-3 py-2 rounded-lg transition">
                                <i class="fa-solid fa-circle-info"></i> <?= __('panel.detail') ?>
                            </a>
                        </div>
                    </div>

                    <?php if ($pur['license_key']): ?>
                    <div class="mt-3 flex items-center gap-2">
                        <div class="flex items-center gap-2 bg-indigo-950/60 border border-indigo-500/20 rounded-lg px-3 py-2 flex-1 min-w-0">
                            <i class="fa-solid fa-key text-indigo-400 text-xs flex-shrink-0"></i>
                            <code id="lic-<?= $pur['sale_id'] ?>" class="text-indigo-300 text-xs font-mono font-bold tracking-wider truncate">
                                <?= e($pur['license_key']) ?>
                            </code>
                        </div>
                        <button onclick="copyLicense('lic-<?= $pur['sale_id'] ?>')"
                                class="flex-shrink-0 flex items-center gap-1.5 bg-indigo-600/20 hover:bg-indigo-600/40 border border-indigo-500/30 text-indigo-300 text-xs font-bold px-3 py-2 rounded-lg transition"
                                title="Kopyala">
                            <i class="fa-regular fa-copy"></i> Kopyala
                        </button>
                    </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<?php elseif ($activeProduct): ?>
<div>
    <a href="/products" class="inline-flex items-center gap-2 text-slate-400 hover:text-white text-sm font-semibold mb-6 transition">
        <i class="fa-solid fa-arrow-left"></i> <?= __('library.back') ?>
    </a>

    <div class="grid md:grid-cols-5 gap-8 items-start">

        <div class="md:col-span-2 flex flex-col gap-4">
            <?php if ($activeProduct['image_url']): ?>
            <img src="<?= e($activeProduct['image_url']) ?>"
                 width="800" height="450" class="w-full rounded-2xl border border-white/10 object-cover aspect-video shadow-lg" style="width:100%;aspect-ratio:16/9;object-fit:cover;display:block;background:#0f1422;" fetchpriority="high" decoding="async" alt="<?= e($activeProduct['name']) ?>">
            <?php else: ?>
            <div class="w-full aspect-video rounded-2xl border border-white/10 bg-white/5 flex items-center justify-center text-5xl">
                <i class="fa-solid fa-cube text-slate-600"></i>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-2 gap-2.5 text-xs font-semibold">
                <div class="flex items-center gap-2.5 rounded-xl p-3" style="background:var(--bg-card);border:1px solid var(--border);color:var(--text);">
                    <i class="fa-solid fa-bolt text-yellow-400 text-sm"></i>
                    <span><?= __('product.delivery_instant') ?></span>
                </div>
                <div class="flex items-center gap-2.5 rounded-xl p-3" style="background:var(--bg-card);border:1px solid var(--border);color:var(--text);">
                    <i class="fa-solid fa-shield-halved text-green-400 text-sm"></i>
                    <span><?= __('product.secure') ?></span>
                </div>
                <div class="flex items-center gap-2.5 rounded-xl p-3" style="background:var(--bg-card);border:1px solid var(--border);color:var(--text);">
                    <i class="fa-solid fa-rotate text-indigo-400 text-sm"></i>
                    <span><?= __('product.free_updates') ?></span>
                </div>
                <div class="flex items-center gap-2.5 rounded-xl p-3" style="background:var(--bg-card);border:1px solid var(--border);color:var(--text);">
                    <i class="fa-solid fa-headset text-amber-400 text-sm"></i>
                    <span>7/24 Destek</span>
                </div>
            </div>
        </div>

        <div class="md:col-span-3 bg-[#0f1520] border border-white/10 rounded-2xl p-6 flex flex-col gap-5">
            <div>
                <div class="flex items-center justify-between gap-3 mb-2 flex-wrap">
                    <?php if ($activeProduct['category']): ?>
                    <span class="text-xs font-black text-indigo-400 tracking-widest uppercase bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-1 rounded-lg"><?= e($activeProduct['category']) ?></span>
                    <?php endif; ?>
                    <?php if ($activeProduct['version']): ?>
                    <span class="text-xs font-bold bg-white/5 border border-white/10 px-2.5 py-1 rounded-lg text-slate-400">v<?= e($activeProduct['version']) ?></span>
                    <?php endif; ?>
                </div>
                <h1 class="text-2xl sm:text-3xl font-black text-white mt-1 mb-3 leading-tight"><?= e($activeProduct['name']) ?></h1>
                
                <div class="flex items-center gap-2 flex-wrap">
                    <div class="flex items-center gap-1">
                        <?php $avgR = round((float)$activeProduct['avg_rating']); ?>
                        <?php for ($s = 1; $s <= 5; $s++): ?>
                        <i class="fa-solid fa-star text-sm <?= $s <= $avgR ? 'text-yellow-400' : 'text-slate-700' ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <a href="javascript:void(0)" onclick="scrollToReviews()" class="text-xs text-slate-400 hover:text-slate-200 transition inline-flex items-center gap-1 font-semibold">
                        <span class="text-slate-200 font-black"><?= number_format((float)$activeProduct['avg_rating'], 1) ?></span>
                        <span><?= __('product.reviews_n', ['n' => (int)$activeProduct['rating_count']]) ?></span>
                        <i class="fa-solid fa-chevron-right text-[10px]"></i>
                    </a>
                </div>
            </div>

            <?php if (!empty($activeProduct['short_description'])): ?>
            <p class="text-sm leading-relaxed" style="color:var(--text-muted);"><?= e($activeProduct['short_description']) ?></p>
            <?php endif; ?>

            <?php if (!empty($activeProduct['user_notice'])): ?>
            <div class="flex items-start gap-2.5 rounded-xl p-3.5 text-xs leading-relaxed" style="background:rgba(99,102,241,.1);border:1px solid rgba(99,102,241,.35);color:var(--text);">
                <i class="fa-solid fa-circle-info text-indigo-400 text-sm flex-shrink-0 mt-0.5"></i>
                <span><?= e($activeProduct['user_notice']) ?></span>
            </div>
            <?php endif; ?>

            <div class="flex items-center justify-between gap-4 p-4 bg-white/3 border border-white/8 rounded-xl flex-wrap">
                <div>
                    <p class="text-xs text-slate-500 font-semibold uppercase tracking-widest mb-1">Fiyat</p>
                    <?php $ap=(float)$activeProduct['price']; $ad=(int)($activeProduct['discount_percent']??0); $an=$ad>0&&$ap>0?$ap*(1-$ad/100):$ap; if($ap>0 && $ad>0): ?>
                    <div style="display:flex;align-items:center;gap:8px">
                        <span style="font-size:14px;color:#94a3b8;text-decoration:line-through"><?= fmt_money($ap) ?></span>
                        <span style="background:#ff4757;color:#fff;font-size:11px;font-weight:800;padding:2px 7px;border-radius:50px"><?= __('product.discount_pct', ['n' => $ad]) ?></span>
                    </div>
                    <p class="text-3xl font-black text-yellow-400"><?= fmt_money($an) ?></p>
                    <?php elseif($ap > 0): ?>
                    <p class="text-3xl font-black text-yellow-400"><?= fmt_money($ap) ?></p>
                    <?php else: ?>
                    <p class="text-2xl font-black text-emerald-400 flex items-center gap-2"><i class="fa-solid fa-gift"></i> <?= __('shop.free') ?></p>
                    <?php endif; ?>
                </div>

                <div>
                    <?php if ($activeProduct['stock_type'] === 'limited'): ?>
                        <?php if ((int)$activeProduct['stock'] < 1): ?>
                        <span class="text-xs font-bold text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-1.5 inline-flex items-center gap-1.5"><i class="fa-solid fa-ban"></i> <?= __('product.soldout') ?></span>
                        <?php elseif ((int)$activeProduct['stock'] <= 5): ?>
                        <span class="text-xs font-bold text-yellow-400 bg-yellow-500/10 border border-yellow-500/20 rounded-lg px-3 py-1.5 inline-flex items-center gap-1.5"><i class="fa-solid fa-bolt"></i> Son <?= (int)$activeProduct['stock'] ?> adet</span>
                        <?php else: ?>
                        <span class="text-xs font-bold text-slate-300 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 inline-flex items-center gap-1.5"><i class="fa-solid fa-box-open text-indigo-400"></i> <?= (int)$activeProduct['stock'] ?> adet stokta</span>
                        <?php endif; ?>
                    <?php else: ?>
                    <span class="text-xs font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-3 py-1.5 inline-flex items-center gap-1.5"><i class="fa-solid fa-infinity"></i> <?= __('product.unlimited') ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (!$me): ?>
            <a href="/login" class="btn-shop-indigo w-full flex items-center justify-center gap-2 font-bold py-3.5 rounded-xl transition" style="box-shadow:0 5px 0 #3730a3;">
                <i class="fa-solid fa-right-to-bracket"></i> <?= __('product.login_buy') ?>
            </a>
            <?php elseif (in_array((int)$activeProduct['id'], array_map('intval', $ownedIds))): ?>
            <div class="flex gap-3 detail-buy-row">
                <div class="flex-1 flex items-center justify-center gap-2 bg-green-900/30 border border-green-700 text-green-400 font-bold py-3.5 rounded-xl">
                    <i class="fa-solid fa-circle-check"></i> <?= __('product.owned') ?>
                </div>
                <a href="/products?tab=purchases" class="flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 font-bold px-5 py-3.5 rounded-xl transition">
                    <i class="fa-solid fa-download"></i> <?= __('product.library') ?>
                </a>
            </div>
            <?php elseif ($activeProduct['stock_type'] === 'limited' && (int)$activeProduct['stock'] < 1): ?>
            <div class="w-full flex items-center justify-center gap-2 bg-red-900/30 border border-red-700 text-red-400 font-bold py-3.5 rounded-xl">
                <i class="fa-solid fa-ban"></i> <?= __('product.soldout') ?>
            </div>
            <?php else: ?>
            <div class="flex gap-3 detail-buy-row">
                <button onclick="cartAdd(<?= $activeProduct['id'] ?>)"
                        class="btn-shop-yellow flex-1 flex items-center justify-center gap-2 font-bold text-sm py-3 px-3 rounded-xl transition" style="box-shadow:0 4px 0 #a26e13;">
                    <i class="fa-solid fa-cart-plus"></i> <?= __('cart.add') ?>
                </button>
                <button id="buyNowBtn" onclick="buyNow(<?= $activeProduct['id'] ?>)"
                        class="btn-shop-indigo flex-[1.2] flex items-center justify-center gap-2 font-bold text-sm py-3 px-3 rounded-xl transition" style="box-shadow:0 4px 0 #3730a3;">
                    <i class="fa-solid fa-bolt"></i> <?= __('product.buy_now') ?>
                </button>
            </div>
            <?php endif; ?>
        </div>

    </div>

    <div id="productTabsNav" class="bg-[#0f1520] border border-white/8 rounded-2xl overflow-hidden mt-8">
        
        <div class="flex items-center gap-2 p-2.5 bg-white/3 border-b border-white/8 overflow-x-auto">
            <button type="button" id="tabBtn-desc" onclick="switchDefaultTab('desc', this)" class="default-tab-btn px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition bg-indigo-600 text-white flex items-center gap-2 whitespace-nowrap cursor-pointer">
                <i class="fa-solid fa-align-left text-indigo-200"></i>
                <span><?= __('product.tab_desc') ?></span>
            </button>
            <button type="button" id="tabBtn-reviews" onclick="switchDefaultTab('reviews', this)" class="default-tab-btn px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition text-slate-400 hover:text-white hover:bg-white/5 flex items-center gap-2 whitespace-nowrap cursor-pointer">
                <i class="fa-solid fa-star text-yellow-400"></i>
                <span><?= __('product.tab_reviews') ?></span>
                <span class="bg-indigo-500/20 text-indigo-300 text-[11px] px-2 py-0.5 rounded-full font-bold"><?= count($comments) ?></span>
            </button>
            <button type="button" id="tabBtn-specs" onclick="switchDefaultTab('specs', this)" class="default-tab-btn px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition text-slate-400 hover:text-white hover:bg-white/5 flex items-center gap-2 whitespace-nowrap cursor-pointer">
                <i class="fa-solid fa-circle-info text-sky-400"></i>
                <span>Teknik Bilgiler</span>
            </button>
            <button type="button" id="tabBtn-updates" onclick="switchDefaultTab('updates', this)" class="default-tab-btn px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition text-slate-400 hover:text-white hover:bg-white/5 flex items-center gap-2 whitespace-nowrap cursor-pointer">
                <i class="fa-solid fa-code-branch text-emerald-400"></i>
                <span><?= __('product.tab_updates') ?></span>
                <span class="bg-emerald-500/20 text-emerald-300 text-[11px] px-2 py-0.5 rounded-full font-bold"><?= count($productVersions) ?></span>
            </button>
        </div>

        <div class="p-6 md:p-8">
            
            <div id="pane-desc" class="default-tab-pane">
                <div class="prose-custom text-slate-300 text-sm leading-relaxed">
                    <?= nx_clean_html((string)($activeProduct['description'] ?? ''), 'rich') ?: e(__('product.no_desc')) ?>
                </div>
            </div>

            <div id="pane-reviews" class="default-tab-pane hidden">
                <div class="flex flex-col gap-6">
                    <?php
                    $ownComment = null;
                    if ($me) {
                        foreach ($comments as $c) {
                            if ((int)$c['user_id'] === (int)$me['id']) { $ownComment = $c; break; }
                        }
                    }
                    ?>

                    <div class="flex items-center justify-between p-5 bg-white/3 border border-white/8 rounded-xl gap-4 flex-wrap">
                        <div class="flex items-center gap-4">
                            <div class="text-4xl font-black text-white"><?= number_format((float)$activeProduct['avg_rating'], 1) ?></div>
                            <div>
                                <div class="flex items-center gap-1 mb-1">
                                    <?php for ($s = 1; $s <= 5; $s++): ?>
                                    <i class="fa-solid fa-star text-sm <?= $s <= round((float)$activeProduct['avg_rating']) ? 'text-yellow-400' : 'text-slate-700' ?>"></i>
                                    <?php endfor; ?>
                                </div>
                                <p class="text-xs text-slate-400 font-semibold"><?= __('product.users_rated', ['n' => count($comments)]) ?></p>
                            </div>
                        </div>
                    </div>

                    <div id="commentsList" class="flex flex-col gap-3">
                        <?php foreach ($comments as $c):
                            $isOwn = $me && (int)$c['user_id'] === (int)$me['id'];
                            $av = $c['avatar'] ?: '/images/avatars/default.svg';
                            $avFallback = 'data:image/svg+xml,' . rawurlencode('<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48"><rect width="48" height="48" fill="#6366f1"/><text x="24" y="31" font-size="22" font-family="Arial, sans-serif" text-anchor="middle" fill="#ffffff">' . htmlspecialchars(strtoupper(mb_substr(($c['username'] ?? '?'),0,1)), ENT_QUOTES) . '</text></svg>');
                        ?>
                        <div class="bg-white/3 border border-white/8 rounded-xl p-4" data-comment-id="<?= (int)$c['id'] ?>" data-comment-text="<?= htmlspecialchars($c['comment_text'], ENT_QUOTES) ?>">
                            <div class="flex items-center gap-2 mb-2">
                                <img src="<?= e($av) ?>" onerror="this.onerror=null;this.src='<?= $avFallback ?>'"
                                     class="w-7 h-7 rounded-full border border-indigo-500/30" style="image-rendering:pixelated;" width="28" height="28">
                                <span class="text-sm font-bold text-slate-200"><?= e($c['username'] ?? '?') ?></span>
                                <?php if ($isOwn): ?>
                                <span class="text-[10px] font-bold text-indigo-300 bg-indigo-500/15 px-2 py-0.5 rounded-full"><?= __('review.you') ?></span>
                                <?php endif; ?>
                                <span class="text-xs text-slate-500 ml-auto"><?= date('d.m.Y H:i', strtotime($c['created_at'])) ?></span>
                            </div>
                            <?php if ((int)$c['rating'] > 0): ?>
                            <div class="flex gap-0.5 mb-2" id="cstars-<?= (int)$c['id'] ?>">
                                <?php for ($s = 1; $s <= 5; $s++): ?>
                                <i class="fa-solid fa-star text-xs <?= $s <= (int)$c['rating'] ? 'text-yellow-400' : 'text-slate-700' ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <?php endif; ?>
                            <div class="text-sm text-slate-300 leading-relaxed" id="ctext-<?= (int)$c['id'] ?>">
                                <?= nl2br(e($c['comment_text'])) ?>
                            </div>
                            <?php if ($isOwn): ?>
                            <div class="flex gap-2 mt-3">
                                <button onclick="openEditComment(<?= (int)$c['id'] ?>, <?= (int)$c['rating'] ?>)" class="text-xs font-bold text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/20 px-3 py-1.5 rounded-lg transition cursor-pointer">
                                    <i class="fa-solid fa-pen mr-1"></i><?= __('product.edit') ?>
                                </button>
                                <button onclick="deleteComment(<?= (int)$c['id'] ?>)" class="text-xs font-bold text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 px-3 py-1.5 rounded-lg transition cursor-pointer">
                                    <i class="fa-solid fa-trash mr-1"></i><?= __('product.delete') ?>
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                        <?php if (empty($comments)): ?>
                        <div class="text-center py-8 text-slate-500">
                            <i class="fa-solid fa-comments text-4xl mb-2 block text-slate-700"></i>
                            <p class="font-semibold"><?= __('product.no_reviews') ?></p>
                            <p class="text-xs mt-1"><?= __('product.no_reviews_hint') ?></p>
                        </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($me): ?>
                        <?php if (in_array((int)$activeProduct['id'], array_map('intval', $ownedIds))): ?>
                            <?php if (!$ownComment): ?>
                            <div class="bg-white/3 border border-white/10 rounded-xl p-5" id="commentForm">
                                <div class="mb-4">
                                    <label class="nx-rating-label mb-2 block text-xs font-bold uppercase tracking-wider text-slate-400"><i class="fa-solid fa-star text-yellow-400 mr-1"></i> <?= __('product.your_rating') ?></label>
                                    <div class="flex gap-1.5" id="starRating">
                                        <?php for ($star = 1; $star <= 5; $star++): ?>
                                        <div class="nx-star-box" data-star="<?= $star ?>" onclick="setRating(<?= $star ?>)">
                                            <i class="fa-solid fa-star"></i>
                                        </div>
                                        <?php endfor; ?>
                                    </div>
                                    <input type="hidden" id="ratingValue" value="0">
                                </div>
                                <textarea id="commentText" rows="3" placeholder="<?= e(__('product.comment_ph')) ?>"
                                          class="w-full bg-[#141d2c] border border-white/15 rounded-xl px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-yellow-400 transition resize-none mb-4 placeholder-slate-600"></textarea>
                                <button onclick="submitComment(<?= $activeProduct['id'] ?>)"
                                        class="nx-btn-gold w-full flex items-center justify-center gap-2 text-sm py-2.5 px-4 rounded-xl cursor-pointer">
                                    <i class="fa-solid fa-paper-plane"></i> <?= __('product.send_review') ?>
                                </button>
                            </div>
                            <?php else: ?>
                            <p class="text-sm text-slate-400 text-center py-3 bg-white/3 border border-white/10 rounded-xl">
                                <i class="fa-solid fa-check-circle text-green-400 mr-1"></i> <?= __('product.reviewed_msg') ?>
                            </p>
                            <?php endif; ?>
                        <?php else: ?>
                        <p class="text-sm text-slate-400 text-center py-3 bg-white/3 border border-white/10 rounded-xl">
                            <i class="fa-solid fa-lock text-slate-500 mr-1"></i> <?= __('product.must_own') ?>
                        </p>
                        <?php endif; ?>
                    <?php else: ?>
                    <p class="text-sm text-slate-400 text-center py-3 bg-white/3 border border-white/10 rounded-xl"><?= __('product.login_review_a') ?> <a href="/login" class="text-indigo-400 font-bold underline"><?= __('product.login_review_b') ?></a>.</p>
                    <?php endif; ?>

                </div>
            </div>

            <div id="pane-specs" class="default-tab-pane hidden">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    
                    <div class="p-4 bg-white/3 border border-white/8 rounded-xl flex items-center gap-3.5">
                        <div class="w-11 h-11 rounded-xl bg-indigo-600/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 text-lg flex-shrink-0">
                            <i class="fa-solid fa-layer-group"></i>
                        </div>
                        <div>
                            <div class="text-[11px] font-black uppercase tracking-wider text-slate-500">Kategori</div>
                            <div class="text-sm font-bold text-slate-200"><?= e($activeProduct['category'] ?? __('shop.general')) ?></div>
                        </div>
                    </div>

                    <div class="p-4 bg-white/3 border border-white/8 rounded-xl flex items-center gap-3.5">
                        <div class="w-11 h-11 rounded-xl bg-sky-600/15 border border-sky-500/30 flex items-center justify-center text-sky-400 text-lg flex-shrink-0">
                            <i class="fa-solid fa-code-branch"></i>
                        </div>
                        <div>
                            <div class="text-[11px] font-black uppercase tracking-wider text-slate-500"><?= __('product.version') ?></div>
                            <div class="text-sm font-bold text-slate-200">v<?= e($activeProduct['version'] ?? '1.0.0') ?></div>
                        </div>
                    </div>

                    <div class="p-4 bg-white/3 border border-white/8 rounded-xl flex items-center gap-3.5">
                        <div class="w-11 h-11 rounded-xl bg-emerald-600/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 text-lg flex-shrink-0">
                            <i class="fa-solid fa-cloud-arrow-down"></i>
                        </div>
                        <div>
                            <div class="text-[11px] font-black uppercase tracking-wider text-slate-500"><?= __('product.delivery_type') ?></div>
                            <div class="text-sm font-bold text-slate-200"><?= __('product.instant_auto') ?></div>
                        </div>
                    </div>

                    <div class="p-4 bg-white/3 border border-white/8 rounded-xl flex items-center gap-3.5">
                        <div class="w-11 h-11 rounded-xl bg-amber-600/15 border border-amber-500/30 flex items-center justify-center text-amber-400 text-lg flex-shrink-0">
                            <i class="fa-solid fa-boxes-stacked"></i>
                        </div>
                        <div>
                            <div class="text-[11px] font-black uppercase tracking-wider text-slate-500">Stok Durumu</div>
                            <div class="text-sm font-bold text-slate-200"><?= $activeProduct['stock_type'] === 'limited' ? __('product.stock_count', ['n' => (int)$activeProduct['stock']]) : __('product.unlimited_digital') ?></div>
                        </div>
                    </div>

                    <div class="p-4 bg-white/3 border border-white/8 rounded-xl flex items-center gap-3.5">
                        <div class="w-11 h-11 rounded-xl bg-purple-600/15 border border-purple-500/30 flex items-center justify-center text-purple-400 text-lg flex-shrink-0">
                            <i class="fa-solid fa-key"></i>
                        </div>
                        <div>
                            <div class="text-[11px] font-black uppercase tracking-wider text-slate-500"><?= __('product.license_prot') ?></div>
                            <div class="text-sm font-bold text-slate-200"><?= !empty($activeProduct['license_prefix']) ? __('product.vex_license') : __('product.standard_digital') ?></div>
                        </div>
                    </div>

                    <div class="p-4 bg-white/3 border border-white/8 rounded-xl flex items-center gap-3.5">
                        <div class="w-11 h-11 rounded-xl bg-slate-700/30 border border-slate-600/30 flex items-center justify-center text-slate-400 text-lg flex-shrink-0">
                            <i class="fa-solid fa-calendar-days"></i>
                        </div>
                        <div>
                            <div class="text-[11px] font-black uppercase tracking-wider text-slate-500"><?= __('product.pub_date') ?></div>
                            <div class="text-sm font-bold text-slate-200"><?= date('d.m.Y', strtotime($activeProduct['created_at'])) ?></div>
                        </div>
                    </div>

                </div>
            </div>

            <div id="pane-updates" class="default-tab-pane hidden">
                <?php if (function_exists('render_product_updates')) render_product_updates($productVersions, '#6366f1'); ?>
            </div>

        </div>
    </div>
</div>

<?php elseif (!$activeProduct): ?>
<!-- ══ ÜRÜN LİSTESİ ══ -->
<div>
    <div class="flex items-end justify-between flex-wrap gap-2 mb-6">
        <div>
            <p class="text-xs font-black text-indigo-400 tracking-widest uppercase mb-1"><?= __('nav.shop') ?></p>
            <h1 class="text-2xl font-black"><?= $selCat ? e($selCat) : __('shop.title_all') ?></h1>
        </div>
        <span class="text-slate-500 text-sm"><?= __('shop.count', ['n' => count($products)]) ?></span>
    </div>

    <?php if (!empty($allCats)): ?>
    <div class="flex flex-wrap gap-2 mb-6">
        <a href="/products"
           class="px-3 py-1.5 rounded-lg text-xs font-bold transition <?= !$selCat ? 'bg-indigo-600 text-white' : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-slate-200' ?>">
           <i class="fa-solid fa-border-all mr-1"></i> <?= __('shop.all') ?>
        </a>
        <?php foreach ($allCats as $ac): ?>
        <a href="/products?cat=<?= urlencode($ac['name']) ?>"
           class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition <?= $selCat===$ac['name'] ? 'bg-indigo-600 text-white' : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-slate-200' ?>">
             <?= cat_icon_html($ac['icon'] ?? '', 'width:14px;height:14px;object-fit:cover;border-radius:4px;') ?>
            <?= e($ac['name']) ?>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (empty($products)): ?>
    <div class="text-center py-20 text-slate-500">
        <i class="fa-solid fa-box-open text-5xl mb-4 block text-slate-700"></i>
        <p class="font-semibold"><?= $selCat ? __('shop.empty_cat') : __('shop.empty_none') ?></p>
    </div>
    <?php else: ?>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        <?php foreach ($products as $p):
            $owned = in_array((int)$p['id'], array_map('intval', $ownedIds));
        ?>
        <a href="/products?product=<?= $p['id'] ?>" class="block group bg-[#0f1520] border border-white/8 rounded-2xl overflow-hidden hover:border-indigo-500/40 hover:-translate-y-1 transition-all duration-200">

            <?php if ($p['image_url']): ?>
             <img src="<?= e($p['image_url']) ?>"
                  width="360" height="144" class="w-full h-36 object-cover" style="width:100%;height:9rem;object-fit:cover;display:block;background:#0f1422;" loading="lazy" decoding="async" alt="<?= e($p['name']) ?>">
            <?php else: ?>
            <div class="w-full h-36 bg-white/3 flex items-center justify-center text-4xl text-slate-700">
                <i class="fa-solid fa-cube"></i>
            </div>
            <?php endif; ?>

            <div class="p-4 flex flex-col gap-3">
                <?php if ($p['category']): ?>
                <span class="text-[10px] font-black text-indigo-400 tracking-widest uppercase"><?= e($p['category']) ?></span>
                <?php endif; ?>

                <p class="font-black text-sm leading-snug line-clamp-2 text-slate-100">
                    <?= e($p['name']) ?>
                </p>

                <?php if ($p['description']): ?>
                <p class="text-xs text-slate-500 line-clamp-2 leading-relaxed"><?= htmlspecialchars(mb_substr(strip_tags($p['short_description'] ?? $p['description']), 0, 100)) ?></p>
                <?php endif; ?>

                <?php if ((float)$p['avg_rating'] > 0): ?>
                <div class="flex items-center gap-1 text-xs">
                    <i class="fa-solid fa-star text-yellow-400"></i>
                    <span class="font-bold text-slate-300"><?= number_format((float)$p['avg_rating'],1) ?></span>
                </div>
                <?php endif; ?>

                <div class="flex items-center justify-between mt-auto pt-1">
                    <?php $pp=(float)$p['price']; $pd=(int)($p['discount_percent']??0); $pn=$pd>0&&$pp>0?$pp*(1-$pd/100):$pp; if($pp>0 && $pd>0): ?>
                    <div style="display:flex;flex-direction:column;gap:2px"><div style="display:flex;gap:6px;align-items:center"><span style="font-size:11px;color:#94a3b8;text-decoration:line-through"><?= fmt_money($pp) ?></span><span style="background:#ff4757;color:#fff;font-size:10px;font-weight:800;padding:2px 6px;border-radius:50px">%<?= $pd ?></span></div><span class="text-lg font-black text-yellow-400"><?= fmt_money($pn) ?></span></div>
                    <?php else: ?><span class="text-lg font-black text-yellow-400"><?= fmt_money($pp) ?></span><?php endif; ?>

                    <?php if ($owned): ?>
                    <span class="flex items-center gap-1 text-xs font-bold text-green-400 bg-green-900/30 px-2 py-1 rounded-lg">
                        <i class="fa-solid fa-check"></i> <?= __('shop.added') ?>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

</main>

<!-- ══ SEPET MODALI ══ -->
<div id="cartModal" class="hidden fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4" style="display:none;">
    <div class="absolute inset-0 bg-black/60 backdrop-blur-sm" onclick="document.getElementById('cartModal').classList.add('hidden')"></div>
    <div class="relative bg-[#0f1520] border border-white/10 rounded-2xl w-full max-w-md max-h-[80vh] flex flex-col shadow-2xl">

        <div class="flex items-center justify-between p-5 border-b border-white/8">
            <h2 class="font-black text-lg flex items-center gap-2">
                <i class="fa-solid fa-cart-shopping text-indigo-400"></i> <?= __('cart.title') ?>
            </h2>
            <button onclick="document.getElementById('cartModal').classList.add('hidden')" class="text-slate-400 hover:text-white text-xl transition">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <div class="flex-1 overflow-y-auto p-4" id="cartItems">
        <?php if (empty($userCart)): ?>
        <p class="text-center text-slate-500 text-sm py-8"><?= __('cart.empty_short') ?></p>
        <?php else: ?>
        <?php foreach ($userCart as $ci): ?>
        <div class="flex items-center gap-3 mb-3 bg-white/3 rounded-xl p-3" id="cartItem-<?= $ci['product_id'] ?>">
            <?php if ($ci['image_url']): ?>
            <img src="<?= e($ci['image_url']) ?>" width="48" height="48" class="w-12 h-12 rounded-lg object-cover" style="width:3rem;height:3rem;object-fit:cover;" loading="lazy" decoding="async" alt="<?= e($ci['name']) ?>">
            <?php else: ?>
            <div class="w-12 h-12 rounded-lg bg-white/8 flex items-center justify-center text-slate-600">
                <i class="fa-solid fa-cube"></i>
            </div>
            <?php endif; ?>
            <div class="flex-1 min-w-0">
                <p class="font-bold text-sm truncate"><?= e($ci['name']) ?></p>
                <p class="text-xs text-yellow-400 font-bold"><?= fmt_money($ci['price']) ?></p>
            </div>
            <div class="flex items-center gap-1.5 bg-white/8 rounded-lg px-1.5 py-1">
                <button onclick="cartUpdateQty(<?= $ci['product_id'] ?>,-1)" class="text-slate-400 hover:text-white text-sm font-bold w-6 h-6 flex items-center justify-center rounded hover:bg-white/10 transition">−</button>
                <span class="text-sm font-bold text-white min-w-[20px] text-center" id="qty-<?= $ci['product_id'] ?>"><?= $ci['quantity'] ?></span>
                <button onclick="cartUpdateQty(<?= $ci['product_id'] ?>,1)" class="text-slate-400 hover:text-white text-sm font-bold w-6 h-6 flex items-center justify-center rounded hover:bg-white/10 transition">+</button>
            </div>
            <button onclick="cartUpdateQty(<?= $ci['product_id'] ?>,0)" class="text-slate-500 hover:text-red-400 text-sm transition p-1">
                <i class="fa-solid fa-trash"></i>
            </button>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
        </div>

        <?php if (!empty($userCart)): ?>
        <div id="cartFooter" class="p-4 border-t border-white/8">

            <?php if (function_exists('feature_active') && feature_active('coupons')): ?>
            <!-- Kupon Kodu Alanı -->
            <div class="flex gap-2 mb-3">
                <input type="text" id="couponInput" placeholder="<?= e(__('cart.coupon_ph')) ?>"
                       class="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-100 outline-none focus:border-indigo-500 transition uppercase placeholder-slate-600">
                <button onclick="applyCoupon()"
                        class="btn-shop-indigo flex items-center gap-1.5 text-sm font-bold px-3 rounded-lg transition" style="box-shadow:0 3px 0 #3730a3;">
                    <i class="fa-solid fa-tag"></i> <?= __('cart.coupon_apply') ?>
                </button>
            </div>
            <!-- Kupon sonuç alanı -->
            <div id="couponResult" class="hidden text-xs rounded-lg px-3 py-2 mb-3 font-semibold"></div>
            <?php endif; ?>

            <div class="flex items-center justify-between mb-1">
                <span class="font-semibold text-slate-400 text-sm"><?= __('cart.subtotal') ?></span>
                <span class="text-slate-300 text-sm" id="cartSubtotal"><?= fmt_money($cartTotal) ?></span>
            </div>
            <div id="discountRow" class="hidden flex items-center justify-between mb-1">
                <span class="font-semibold text-green-400 text-sm flex items-center gap-1">
                    <i class="fa-solid fa-tag"></i> <span id="discountLabel"><?= __('cart.discount') ?></span>
                </span>
                <span class="text-green-400 font-bold text-sm" id="discountAmount">-<?= fmt_money(0) ?></span>
            </div>
            <div class="flex items-center justify-between mb-3 pt-2 border-t border-white/8">
                <span class="font-semibold text-slate-400 text-sm">Toplam</span>
                <span class="font-black text-yellow-400 text-lg" id="cartTotal"><?= fmt_money($cartTotal) ?></span>
            </div>
            <button onclick="checkout()"
                    class="btn-shop-yellow w-full flex items-center justify-center gap-2 font-black py-3 rounded-xl transition" style="box-shadow:0 4px 0 #a26e13;">
                <i class="fa-solid fa-bolt"></i> <?= __('cart.buy') ?>
            </button>
            <p class="text-center text-xs text-slate-500 mt-2"><?= __('cart.balance') ?> <span id="balanceInModal"><?= fmt_money($balance) ?></span></p>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- ── HEMEN SATIN AL ONAY MODALI ── -->
<?php if ($activeProduct && $me && !in_array((int)$activeProduct['id'], array_map('intval', $ownedIds)) && !($activeProduct['stock_type'] === 'limited' && (int)$activeProduct['stock'] < 1)): ?>
<div id="buyNowModal" class="hidden fixed inset-0 z-[100000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" style="display:none;" onclick="if(event.target===this)closeBuyNowModal()">
    <div class="bg-[#0f1520] border border-white/10 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl">
        <div class="flex items-center justify-between p-5 border-b border-white/8">
            <h3 class="font-black text-sm flex items-center gap-2">
                <i class="fa-solid fa-bolt text-yellow-400"></i> <?= __('product.buy_now') ?>
            </h3>
            <button onclick="closeBuyNowModal()" class="nx-modal-close" title="<?= e(__('buy.close')) ?>">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <div class="p-5">
            <div class="flex items-center gap-3 mb-4">
                <?php if (!empty($activeProduct['image_url'])): ?>
                <img src="<?= e($activeProduct['image_url']) ?>" width="56" height="56" class="w-14 h-14 rounded-xl object-cover border border-white/10" style="width:3.5rem;height:3.5rem;object-fit:cover;" decoding="async" alt="<?= e($activeProduct['name']) ?>">
                <?php else: ?>
                <div class="w-14 h-14 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-2xl text-slate-600"><i class="fa-solid fa-cube"></i></div>
                <?php endif; ?>
                <div class="flex-1 min-w-0">
                    <p class="font-black text-sm truncate"><?= e($activeProduct['name']) ?></p>
                    <?php $bp=(float)$activeProduct['price']; $bd=(int)($activeProduct['discount_percent']??0); $bn=$bd>0&&$bp>0?$bp*(1-min(90,max(0,$bd))/100):$bp; ?>
                    <?php if ($bn > 0): ?>
                    <p class="text-yellow-400 font-black mt-1"><?= fmt_money($bn) ?></p>
                    <?php else: ?>
                    <p class="text-emerald-400 font-black mt-1"><?= __('shop.free') ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <p class="text-xs text-slate-400 flex items-start gap-2 leading-relaxed">
                <i class="fa-solid fa-circle-info text-indigo-400 mt-0.5"></i>
                <?= __('buy.confirm_text') ?>
            </p>
            <?php $bnReady = function_exists('gateway_ready_list') ? gateway_ready_list($db) : []; ?>
            <?php $bnPlanLocked = function_exists('plan_payments_allowed') && !plan_payments_allowed($db); ?>
            <?php if ($bnPlanLocked): ?>
            <div style="margin-top:14px;font-size:12px;font-weight:700;border-radius:10px;padding:10px 12px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#fca5a5;">
                <?= e(__('plan.payments_paused')) ?>
            </div>
            <?php endif; ?>
            <?php if (count($bnReady) > 0 && !$bnPlanLocked): ?>
            <div id="buyNowMethods" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;">
                <button type="button" data-bn-method="balance" onclick="buyNowPick('balance', this)" class="topup-method-btn active"><i class="fa-solid fa-wallet"></i> <?= e(__('cart.pay_balance_short')) ?></button>
                <?php foreach ($bnReady as $bnM):
                    $bnKey = $bnM;
                    $bnLabel = gateway_label_for($bnM);
                    $bnLogo = gateway_logo_url($bnM);
                ?>
                <button type="button" data-bn-method="<?= e($bnKey) ?>" onclick="buyNowPick('<?= e($bnKey) ?>', this)" class="topup-method-btn">
                    <?php if ($bnLogo !== ''): ?><img src="<?= e($bnLogo) ?>" alt="" width="48" height="32" style="height:18px;width:auto;object-fit:contain;margin-right:4px;vertical-align:middle;"><?php endif; ?><?= e($bnLabel) ?>
                </button>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <div class="px-5 pb-5 flex gap-2">
            <button onclick="closeBuyNowModal()" class="btn-shop-yellow flex-1 flex items-center justify-center gap-1.5 font-bold text-xs py-2.5 rounded-xl transition" style="box-shadow:0 3px 0 #a26e13;">
                <i class="fa-solid fa-xmark"></i> <?= __('buy.cancel') ?>
            </button>
            <button onclick="confirmBuyNow()" id="buyNowConfirmBtn" class="btn-shop-indigo flex-1 flex items-center justify-center gap-1.5 font-bold text-xs py-2.5 rounded-xl transition" style="box-shadow:0 3px 0 #3730a3;">
                <i class="fa-solid fa-check"></i> <?= __('buy.confirm') ?>
            </button>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ── Toast Bildirimi �� -->
<div id="toast"></div>

<script>
window.NX_SHOP_LANG = <?= json_encode(['license_copied'=>__('msg.license_copied'),'copy_failed'=>__('msg.copy_failed'),'coupon_enter'=>__('msg.coupon_enter'),'review_min'=>__('msg.review_min'),'just_now'=>__('msg.just_now'),'review_delete_confirm'=>__('msg.review_delete_confirm'),'edit_title'=>__('msg.edit_title'),'product_detail'=>__('msg.product_detail'),'no_file'=>__('msg.no_file'),'download_file'=>__('msg.download_file'),'license_key'=>__('msg.license_key'),'applied_suffix'=>__('coupon.applied_suffix'),'edit'=>__('product.edit'),'delete'=>__('product.delete'),'comment_ph'=>__('product.comment_ph'),'you'=>__('review.you'),'no_name'=>__('msg.no_name'),'purchased_on'=>__('library.purchased_on')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
function copyLicense(id) {
    const el = document.getElementById(id);
    if (!el) return;
    navigator.clipboard.writeText(el.textContent.trim()).then(() => {
        el.style.color = '#4ade80';
        showToast(window.NX_SHOP_LANG.license_copied||'Lisans anahtarı kopyalandı!', true);
        setTimeout(() => el.style.color = '', 1500);
    }).catch(() => showToast(window.NX_SHOP_LANG.copy_failed||'Kopyalanamadı.', false));
}

async function applyCoupon() {
    const code = document.getElementById('couponInput').value.trim().toUpperCase();
    const resultEl = document.getElementById('couponResult');
    if (!code) { showToast(window.NX_SHOP_LANG.coupon_enter||'Kupon kodu giriniz.', false); return; }

    const fd = new FormData();
    fd.append('action','apply_coupon');
    fd.append('code', code);
    const r = await fetch(ACTIONS_URL, {method:'POST',body:fd});
    const d = await r.json();

    resultEl.classList.remove('hidden','bg-green-900/30','bg-red-900/30','border-green-700','border-red-700','text-green-300','text-red-300');
    if (d.ok && d.discount !== undefined) {
        // İndirim kuponu
        resultEl.className = 'text-xs rounded-lg px-3 py-2 mb-3 font-semibold bg-green-900/30 border border-green-700 text-green-300 flex items-center gap-2';
        resultEl.innerHTML = `<i class="fa-solid fa-tag"></i> ${escapeHtml(d.label)} ` + (window.NX_SHOP_LANG.applied_suffix||'uygulandı!') + ` -${window.nxFmt(d.discount)}`;

        // Satır göster
        document.getElementById('discountRow').classList.remove('hidden');
        document.getElementById('discountLabel').textContent = d.label;
        document.getElementById('discountAmount').textContent = '-' + window.nxFmt(d.discount);
        document.getElementById('cartTotal').textContent = window.nxFmt(d.new_total);
    } else {
        resultEl.className = 'text-xs rounded-lg px-3 py-2 mb-3 font-semibold bg-red-900/30 border border-red-700 text-red-300 flex items-center gap-2';
        resultEl.innerHTML = `<i class="fa-solid fa-circle-xmark"></i> ${escapeHtml(d.msg)}`;
        // Başarılı product/license grant ise toast yeterli
        if (d.ok) { resultEl.className = resultEl.className.replace('red','green'); showToast(d.msg, true); }
    }
    showToast(d.msg, d.ok);
}

async function checkout() {
    return nxCartPay();
}

function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, function (c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}

function switchDefaultTab(tabName, btn) {
    document.querySelectorAll('.default-tab-btn').forEach(b => {
        b.className = 'default-tab-btn px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition text-slate-400 hover:text-white hover:bg-white/5 flex items-center gap-2 whitespace-nowrap cursor-pointer';
    });
    if (!btn) {
        btn = document.getElementById('tabBtn-' + tabName);
    }
    if (btn) {
        btn.className = 'default-tab-btn px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition bg-indigo-600 text-white flex items-center gap-2 whitespace-nowrap cursor-pointer';
    }
    document.querySelectorAll('.default-tab-pane').forEach(p => {
        p.classList.add('hidden');
    });
    const target = document.getElementById('pane-' + tabName);
    if (target) target.classList.remove('hidden');
}

function scrollToReviews() {
    switchDefaultTab('reviews');
    const el = document.getElementById('productTabsNav');
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function submitComment(pid) {
    const mde = (typeof _commentMde !== 'undefined') ? _commentMde : null;
    const text = mde ? mde.value().trim() : document.getElementById('commentText').value.trim();
    if (text.length < 3) { showToast(window.NX_SHOP_LANG.review_min||'Yorum en az 3 karakter olmalı.', false); return; }
    const rating = parseInt(document.getElementById('ratingValue')?.value ?? '0') || 0;
    const fd = new FormData();
    fd.append('action','comment_add');
    fd.append('product_id', pid);
    fd.append('rating', rating);
    fd.append('comment_text', text);
    const r = await fetch(ACTIONS_URL, {method:'POST',body:fd});
    const d = await r.json();
    showToast(d.msg, d.ok);
    if (d.ok) {
        if (mde) mde.value('');
        else document.getElementById('commentText').value = '';
        resetRating();
        const form = document.getElementById('commentForm');
        if (form) form.style.display = 'none';
        const div = document.createElement('div');
        div.className = 'bg-[#0f1520] border border-white/8 rounded-xl p-4';
        div.setAttribute('data-comment-id', d.id);
        div.setAttribute('data-comment-text', text);
        const starHtml = d.rating > 0 ? `<div class="flex gap-0.5 mb-2">${Array.from({length:5},(_,i)=>`<i class="fa-solid fa-star text-xs ${i < d.rating ? 'text-yellow-400' : 'text-slate-700'}"></i>`).join('')}</div>` : '';
        const safeName = escapeHtml(String(d.username ?? ''));
        const safeInitial = escapeHtml(String(d.username ?? '?').charAt(0).toUpperCase());
        div.innerHTML = `<div class="flex items-center gap-2 mb-2">
            <div class="w-7 h-7 rounded-full bg-indigo-500/25 border border-indigo-500/40 flex items-center justify-center text-xs font-bold text-indigo-300">${safeInitial}</div>
            <span class="text-sm font-bold">${safeName}</span>
            <span class="text-[10px] font-bold text-indigo-300 bg-indigo-500/15 px-2 py-0.5 rounded-full">${window.NX_SHOP_LANG.you||'Sen'}</span>
            <span class="text-xs text-slate-500 ml-auto">${window.NX_SHOP_LANG.just_now||'Az önce'}</span>
        </div>${starHtml}<div class="text-sm text-slate-300">${d.html}</div>
        <div class="flex gap-2 mt-3">
            <button onclick="openEditComment(${d.id}, ${d.rating})" class="text-xs font-bold text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/20 px-3 py-1.5 rounded-lg transition cursor-pointer"><i class="fa-solid fa-pen mr-1"></i><?= __('product.edit') ?></button>
            <button onclick="deleteComment(${d.id})" class="text-xs font-bold text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 px-3 py-1.5 rounded-lg transition cursor-pointer"><i class="fa-solid fa-trash mr-1"></i>${window.NX_SHOP_LANG.delete||'Sil'}</button>
        </div>`;
        document.getElementById('commentsList').appendChild(div);
    }
}

function paintStars(val) {
    document.querySelectorAll('#starRating .nx-star-box').forEach(b => {
        b.classList.toggle('active', parseInt(b.dataset.star) <= val);
    });
}

function setRating(val) {
    document.getElementById('ratingValue').value = val;
    paintStars(val);
}

function resetRating() {
    document.getElementById('ratingValue').value = '0';
    paintStars(0);
}

let _editCommentId = 0;

function paintEditStars(val) {
    document.querySelectorAll('#editCommentStars .nx-star-box').forEach(b => {
        b.classList.toggle('active', parseInt(b.dataset.star) <= val);
    });
}

function openEditComment(id, rating) {
    _editCommentId = id;
    const card = document.querySelector(`[data-comment-id="${id}"]`);
    document.getElementById('editCommentText').value = card ? card.getAttribute('data-comment-text') : '';
    document.getElementById('editCommentRating').value = rating;
    paintEditStars(rating);
    document.getElementById('editCommentModal').style.display = 'flex';
}

function closeEditComment() {
    document.getElementById('editCommentModal').style.display = 'none';
}

async function saveEditComment() {
    const id = _editCommentId;
    const text = document.getElementById('editCommentText').value.trim();
    if (text.length < 3) { showToast(window.NX_SHOP_LANG.review_min||'Yorum en az 3 karakter olmalı.', false); return; }
    const rating = parseInt(document.getElementById('editCommentRating').value || '0') || 0;
    const fd = new FormData();
    fd.append('action','comment_update');
    fd.append('comment_id', id);
    fd.append('rating', rating);
    fd.append('comment_text', text);
    const r = await fetch(ACTIONS_URL, {method:'POST',body:fd});
    const d = await r.json();
    showToast(d.msg, d.ok);
    if (d.ok) {
        const card = document.querySelector(`[data-comment-id="${id}"]`);
        if (card) {
            card.setAttribute('data-comment-text', text);
            const tEl = document.getElementById('ctext-' + id);
            if (tEl) tEl.innerHTML = d.html;
            let sEl = document.getElementById('cstars-' + id);
            const starHtml = d.rating > 0 ? Array.from({length:5},(_,i)=>`<i class="fa-solid fa-star text-xs ${i < d.rating ? 'text-yellow-400' : 'text-slate-700'}"></i>`).join('') : '';
            if (sEl) {
                sEl.innerHTML = starHtml;
                sEl.style.display = d.rating > 0 ? '' : 'none';
            } else if (d.rating > 0) {
                sEl = document.createElement('div');
                sEl.className = 'flex gap-0.5 mb-2';
                sEl.id = 'cstars-' + id;
                sEl.innerHTML = starHtml;
                const tx = document.getElementById('ctext-' + id);
                if (tx) tx.parentNode.insertBefore(sEl, tx);
            }
        }
        closeEditComment();
    }
}

async function deleteComment(id) {
    if (!confirm(window.NX_SHOP_LANG.review_delete_confirm||'Değerlendirmeniz silinsin mi?')) return;
    const fd = new FormData();
    fd.append('action','comment_delete');
    fd.append('comment_id', id);
    const r = await fetch(ACTIONS_URL, {method:'POST',body:fd});
    const d = await r.json();
    showToast(d.msg, d.ok);
    if (d.ok) {
        const card = document.querySelector(`[data-comment-id="${id}"]`);
        if (card) card.remove();
        const form = document.getElementById('commentForm');
        if (form) form.style.display = '';
    }
}

document.addEventListener('DOMContentLoaded', function () {
    const containers = [['#starRating','#ratingValue'], ['#editCommentStars','#editCommentRating']];
    containers.forEach(([sel, inputSel]) => {
        const container = document.querySelector(sel);
        if (!container) return;
        const boxes = container.querySelectorAll('.nx-star-box');
        boxes.forEach(b => {
            b.addEventListener('mouseenter', () => {
                boxes.forEach(x => x.classList.toggle('active', parseInt(x.dataset.star) <= parseInt(b.dataset.star)));
            });
        });
        container.addEventListener('mouseleave', () => {
            const val = parseInt(document.querySelector(inputSel)?.value || '0') || 0;
            boxes.forEach(x => x.classList.toggle('active', parseInt(x.dataset.star) <= val));
        });
    });
});
</script>

<?php if ($activeProduct && $me): ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/easymde/2.18.0/easymde.min.css" crossorigin="anonymous">

<script src="https://cdnjs.cloudflare.com/ajax/libs/easymde/2.18.0/easymde.min.js" crossorigin="anonymous"></script>
<script>
let _commentMde = null;
const _cTa = document.getElementById('commentText');
if (_cTa) {
    _commentMde = new EasyMDE({
        element: _cTa,
        spellChecker: false,
        toolbar: false,
        status: false,
        minHeight: '100px',
        autosave: { enabled: false },
    });
}
</script>
<?php endif; ?>

<div id="editCommentModal" class="nx-modal-overlay fixed inset-0 z-[100000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" style="display:none;">
    <div class="nx-modal-card bg-[#0f1520] border border-white/10 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
        <div class="flex items-center justify-between p-5 border-b border-white/8">
            <h3 class="font-black text-base"><i class="fa-solid fa-pen text-yellow-400 mr-2"></i><?= __('msg.edit_title') ?></h3>
            <button onclick="closeEditComment()" class="nx-modal-close" title="<?= e(__('buy.close')) ?>">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <div class="p-5">
            <label class="nx-rating-label mb-3"><?= __('product.rating_short') ?></label>
            <div class="flex gap-1.5 mb-4" id="editCommentStars">
                <?php for ($s = 1; $s <= 5; $s++): ?>
                <div class="nx-star-box" data-star="<?= $s ?>"><i class="fa-solid fa-star"></i></div>
                <?php endfor; ?>
            </div>
            <input type="hidden" id="editCommentRating" value="0">
            <textarea id="editCommentText" rows="4" placeholder="<?= e(__('product.comment_ph')) ?>"
                      class="w-full bg-[#141d2c] border border-white/15 rounded-xl px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-yellow-400 transition resize-none mb-4 placeholder-slate-600"></textarea>
            <button onclick="saveEditComment()"
                    class="nx-btn-gold w-full flex items-center justify-center gap-2 text-sm py-2.5 px-4 rounded-xl">
                <i class="fa-solid fa-floppy-disk"></i> <?= __('msg.save') ?>
            </button>
        </div>
    </div>
</div>

<div id="purchasePopup" class="fixed inset-0 z-[100000] bg-black/80 backdrop-blur-sm hidden items-center justify-center p-4" onclick="if(event.target===this)closePurchasePopup()">
    <div class="bg-[#0f1520] border border-white/10 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
        <div class="flex items-center justify-between p-5 border-b border-white/8">
            <h2 class="font-black text-lg flex items-center gap-2" id="popupTitle">
                <i class="fa-solid fa-cube text-indigo-400"></i> <?= __('msg.product_detail') ?>
            </h2>
            <button onclick="closePurchasePopup()" class="nx-modal-close" title="<?= e(__('buy.close')) ?>">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <div class="p-5" id="popupBody"></div>
    </div>
</div>

<script>
var purchaseData = {};

function openPurchasePopup(pur) {
    purchaseData = pur;
    var safeName = escapeHtml(pur.name || (window.NX_SHOP_LANG.no_name||'Ürün'));
    var safeCat = escapeHtml(pur.category || '');
    var safeVer = escapeHtml(pur.version || '');
    var safeDate = escapeHtml(pur.purchased_at || '');
    var safeLic = escapeHtml(pur.license_key || '');
    var safeImg = String(pur.image_url || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
    document.getElementById('popupTitle').innerHTML = '<i class="fa-solid fa-cube text-indigo-400"></i> ' + safeName;
    var body = document.getElementById('popupBody');
    var html = '';

    if (pur.image_url) {
        html += '<img src="' + safeImg + '" class="w-full aspect-video object-cover rounded-xl border border-white/10 mb-4" width="560" height="315">';
    } else {
        html += '<div class="w-full aspect-video rounded-xl border border-white/10 bg-white/5 flex items-center justify-center text-5xl mb-4"><i class="fa-solid fa-cube text-slate-600"></i></div>';
    }

    html += '<div class="flex items-center justify-between mb-3">';
    html += '  <div><span class="text-xs font-black text-indigo-400 tracking-widest uppercase">' + safeCat + '</span>';
    html += '  <p class="text-xs text-slate-500 mt-0.5">v' + safeVer + '</p></div>';
    html += '  <span class="text-lg font-black text-yellow-400">' + window.nxFmt(pur.price_paid) + '</span>';
    html += '</div>';

    html += '<div class="text-xs text-slate-500 mb-4">' + (window.NX_SHOP_LANG.purchased_on||'Satın alındı:') + ' ' + safeDate + '</div>';

    if (pur.license_key) {
        html += '<div class="mb-4"><label class="text-xs font-bold text-slate-400 mb-1 block">' + (window.NX_SHOP_LANG.license_key||'Lisans Anahtarı') + '</label>';
        html += '<div class="flex items-center gap-2 bg-indigo-950/60 border border-indigo-500/20 rounded-lg px-3 py-2">';
        html += '  <i class="fa-solid fa-key text-indigo-400 text-xs flex-shrink-0"></i>';
        html += '  <code id="popupLicKey" class="text-indigo-300 text-xs font-mono font-bold tracking-wider flex-1 truncate">' + safeLic + '</code>';
        html += '  <button onclick="copyPopupLic()" class="flex-shrink-0 text-indigo-300 hover:text-indigo-200 text-sm"><i class="fa-regular fa-copy"></i></button>';
        html += '</div></div>';
    }

    if (pur.has_file) {
        html += '<a href="/download.php?sale_id=' + pur.sale_id + '" class="flex items-center justify-center gap-2 bg-green-600 hover:bg-green-500 text-white text-sm font-bold py-3 rounded-xl transition w-full" style="box-shadow:0 4px 0 #15803d;">';
        html += '  <i class="fa-solid fa-download"></i> ' + (window.NX_SHOP_LANG.download_file||'Dosyayı İndir');
        html += '</a>';
    } else {
        html += '<div class="text-center py-4 text-slate-500 text-sm"><i class="fa-solid fa-circle-info"></i> ' + (window.NX_SHOP_LANG.no_file||'Bu ürün için indirilebilir dosya bulunmuyor.') + '</div>';
    }

    body.innerHTML = html;
    var modal = document.getElementById('purchasePopup');
    modal.style.display = 'flex';
    modal.classList.remove('purchase-modal-enter');
    void modal.offsetWidth;
    modal.classList.add('purchase-modal-enter');
}

function closePurchasePopup() {
    var modal = document.getElementById('purchasePopup');
    modal.style.display = 'none';
    modal.classList.remove('purchase-modal-enter');
}

function copyPopupLic() {
    var el = document.getElementById('popupLicKey');
    if (!el) return;
    navigator.clipboard.writeText(el.textContent.trim()).then(function() {
        el.style.color = '#4ade80';
        setTimeout(function() { el.style.color = ''; }, 1500);
    });
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closePurchasePopup();
});
</script>

<?php include ROOT_PATH . '/themes/default/includes/footer.php'; ?>
