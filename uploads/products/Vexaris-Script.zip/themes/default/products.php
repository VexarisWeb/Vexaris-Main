<?php
if (isset($_GET['product']) || ($_GET['tab'] ?? '') === 'purchases') {
    include __DIR__ . '/product.php';
    return;
}
/**
 * themes/default/products.php — Ürün Listeleme Sayfası
 */
$pageTitle  = __('nav.shop');
$activePage = 'products';
$seoKey     = 'products';

$db       = nexus_db();
$products = [];
$cats     = [];

if ($db) {
    $cat = trim($_GET['cat'] ?? '');
    $q   = trim($_GET['q']   ?? '');

    $where  = ["is_active = 1", "is_hidden = 0", "status = 'active'"];
    $params = [];

    if ($cat) { $where[] = 'category = ?'; $params[] = $cat; }
    if ($q)   { $where[] = '(name LIKE ? OR short_description LIKE ? OR description LIKE ?)'; $esq = '%'.addcslashes($q,'%_').'%'; $params[] = $esq; $params[] = $esq; $params[] = $esq; }

    $stmt = $db->prepare('SELECT * FROM products WHERE ' . implode(' AND ', $where) . ' ORDER BY created_at DESC');
    $stmt->execute($params);
    $products = $stmt->fetchAll();

    $cats = $db->query("SELECT name,slug,icon FROM categories ORDER BY sort_order ASC, name ASC")->fetchAll();
}

$flashType = '';
$flashText = '';
$flashRaw = trim((string)($_GET['flash'] ?? ''));
if ($flashRaw !== '' && strpos($flashRaw, ':') !== false) {
    $flashParts = explode(':', urldecode($flashRaw), 2);
    $flashType = $flashParts[0];
    $flashText = $flashParts[1] ?? '';
}
include __DIR__ . '/includes/header.php';
?>
<main style="flex:1;">
<div class="section">
<div class="section-inner">
<?php if ($flashText !== ''): ?>
<?php if ($flashType === 'success'): ?>
<div style="margin-bottom:20px;padding:13px 16px;border-radius:12px;font-size:13.5px;font-weight:600;display:flex;align-items:center;gap:10px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.35);color:#4ade80;">
    <i class="fa-solid fa-circle-check"></i>
    <span><?= e($flashText) ?></span>
</div>
<?php else: ?>
<div style="margin-bottom:20px;padding:13px 16px;border-radius:12px;font-size:13.5px;font-weight:600;display:flex;align-items:center;gap:10px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.35);color:#f87171;">
    <i class="fa-solid fa-circle-xmark"></i>
    <span><?= e($flashText) ?></span>
</div>
<?php endif; ?>
<?php endif; ?>

    <!-- Başlık -->
    <div class="section-header" style="display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:16px;margin-bottom:28px;">
        <div>
            <p class="section-tag"><i class="fa-solid fa-box-open"></i> <?= __('nav.shop') ?></p>
            <h1 class="section-title"><?= __('home.all_products') ?></h1>
            <p class="section-desc"><?= __('shop.listing', ['n' => count($products)]) ?></p>
        </div>
        <!-- Arama -->
        <form method="GET" class="nx-shop-search" style="display:flex;gap:8px;">
            <?php if ($cat): ?><input type="hidden" name="cat" value="<?= e($cat) ?>"><?php endif; ?>
            <div class="input-wrapper nx-shop-search-box" style="width:220px;">
                <i class="fa-solid fa-magnifying-glass input-icon"></i>
                <input type="text" name="q" value="<?= e($q) ?>" placeholder="<?= e(__('shop.search_ph')) ?>"
                       class="form-input" style="padding-left:36px;">
            </div>
            <button type="submit" class="btn-custom btn-indigo btn-sm"><?= __('shop.search_btn') ?></button>
        </form>
    </div>

    <div style="display:flex;gap:24px;align-items:flex-start;flex-wrap:wrap;">

        <!-- Sidebar kategori filtresi (mobilde en üstte yatay chip) -->
        <?php if ($cats): ?>
        <aside class="shop-cat-side">
            <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:16px;padding:16px;">
                <p style="font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text-dim);margin-bottom:12px;"><?= __('shop.categories') ?></p>
                <ul class="shop-cat-list">
                    <li>
                        <a href="/products<?= $q?"?q=".urlencode($q):'' ?>"
                           style="display:block;padding:7px 12px;border-radius:9px;font-size:13px;font-weight:600;
                                  color:<?= !$cat?'#a5b4fc':'var(--text-muted)' ?>;
                                  background:<?= !$cat?'rgba(99,102,241,.1)':'transparent' ?>;">
                            <?= __('shop.all') ?>
                        </a>
                    </li>
                    <?php foreach ($cats as $c): ?>
                    <li>
                        <a href="/products?cat=<?= urlencode($c['name']) ?><?= $q?'&q='.urlencode($q):'' ?>"
                           style="display:block;padding:7px 12px;border-radius:9px;font-size:13px;font-weight:600;
                                  color:<?= $cat===$c['name']?'#a5b4fc':'var(--text-muted)' ?>;
                                  background:<?= $cat===$c['name']?'rgba(99,102,241,.1)':'transparent' ?>;">
                            <?= cat_icon_html($c['icon'] ?? '', 'width:14px;height:14px;object-fit:cover;border-radius:4px;text-align:center;margin-right:4px;') ?>
                            <?= e($c['name']) ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </aside>
        <?php endif; ?>

        <!-- Ürün grid -->
        <div class="shop-grid-wrap" style="flex:1;min-width:0;">
            <?php if (empty($products)): ?>
            <div style="text-align:center;padding:60px 20px;color:var(--text-muted);">
                <i class="fa-solid fa-box-open" style="font-size:48px;color:var(--text-dim);margin-bottom:16px;display:block;"></i>
                <p style="font-size:15px;font-weight:600;"><?= __('shop.not_found') ?></p>
            </div>
            <?php else: ?>
            <div class="products-grid">
                <?php foreach ($products as $p):
                    $stkSoldOut = (($p['stock_type'] ?? 'unlimited') === 'limited') && ((int)($p['stock'] ?? 0)) < 1;
                    $pp = (float)$p['price'];
                    $pd = (int)($p['discount_percent'] ?? 0);
                    $pn = $pd > 0 && $pp > 0 ? $pp * (1 - $pd / 100) : $pp;
                ?>
                <?php if (function_exists('do_action')) do_action('product_card_before', $p); ?>
                <a href="<?= $stkSoldOut ? 'javascript:void(0)' : '/products?product='.(int)$p['id'] ?>" class="product-card" style="display:flex;flex-direction:column;text-decoration:none;color:inherit;<?= $stkSoldOut?'opacity:.6;':'' ?>">
                    <div class="product-card-thumb">
                        <?php if (!empty($p['image_url'])): ?>
                        <img src="<?= e($p['image_url']) ?>" width="360" height="180" style="width:100%;height:100%;object-fit:cover;" alt="<?= e($p['name'] ?? '') ?>">
                        <?php else: ?>
                        <i class="fa-solid fa-box" style="font-size:48px;color:var(--text-dim);"></i>
                        <?php endif; ?>
                        <?php if (!empty($p['category'])): ?><span class="product-card-badge" style="top:auto;bottom:12px;"><?= e($p['category']) ?></span><?php endif; ?>
                        <?php if ($stkSoldOut): ?><span class="product-card-badge" style="bottom:auto;top:12px;background:rgba(239,68,68,.9);"><?= __('product.soldout') ?></span>
                        <?php elseif ($pd > 0): ?><span class="product-card-badge" style="bottom:auto;top:12px;background:#ff4757;color:#fff;font-weight:800;"><?= __('product.discount_pct', ['n' => $pd]) ?></span>
                        <?php elseif (($p['stock_type'] ?? 'unlimited') === 'limited' && (int)($p['stock'] ?? 0) <= 5): ?><span class="product-card-badge" style="bottom:auto;top:12px;background:rgba(251,191,36,.9);color:#4c3716;"><?= __('product.last_units', ['n' => (int)$p['stock']]) ?></span><?php endif; ?>
                    </div>
                    <div class="product-card-body" style="flex:1;display:flex;flex-direction:column;">
                        <p class="product-card-category"><i class="fa-solid fa-tag" style="margin-right:4px;"></i><?= e($p['category'] ?: 'Genel') ?></p>
                        <h3 class="product-card-title"><?= e($p['name']) ?></h3>
                        <p class="product-card-desc"><?= e(truncate_text($p['short_description'] ?? $p['description'] ?? '')) ?></p>
                        <div class="product-card-footer" style="margin-top:auto;">
                            <div class="product-price">
                                <?php if ($pp > 0): ?>
                                    <?php if ($pd > 0): ?>
                                    <div style="display:flex;flex-direction:column;align-items:flex-start;gap:2px">
                                        <div style="display:flex;align-items:center;gap:6px"><span style="font-size:12px;color:var(--text-muted);text-decoration:line-through"><?= fmt_money($pp) ?></span><span style="background:#ff4757;color:#fff;font-size:10px;font-weight:800;padding:1px 6px;border-radius:50px">%<?= $pd ?></span></div>
                                        <span class="product-price-current" style="color:#fbc853"><?= fmt_money($pn) ?></span>
                                    </div>
                                    <?php else: ?>
                                    <span class="product-price-current"><?= fmt_money($pp) ?></span>
                                    <span class="product-price-label">Tek Seferlik</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                <span class="product-price-current" style="display:flex;align-items:center;gap:7px;white-space:nowrap;"><i class="fa-solid fa-gift"></i> <?= __('shop.free') ?></span>
                                <?php endif; ?>
                            </div>
                            <?php if ($stkSoldOut): ?>
                            <span class="btn-custom btn-indigo btn-sm" style="pointer-events:auto;opacity:.5;"><i class="fa-solid fa-ban btn-icon"></i> <?= __('product.soldout') ?></span>
                            <?php elseif (auth_check()): ?>
                            <span class="btn-custom btn-yellow btn-sm" onclick="event.stopPropagation();window.location='/products?product=<?= (int)$p['id'] ?>'" style="pointer-events:auto;">
                                <i class="fa-solid fa-cart-plus btn-icon"></i> <?= __('cart.buy') ?>
                            </span>
                            <?php else: ?>
                            <span class="btn-custom btn-indigo btn-sm" onclick="event.stopPropagation();window.location='/login'" style="pointer-events:auto;">
                                <i class="fa-solid fa-right-to-bracket btn-icon"></i> <?= __('nav.login') ?>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
                <?php if (function_exists('do_action')) do_action('product_card_after', $p); ?>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

</div>
</div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
