<?php
auth_redirect_if_logged_in('/');

$pageTitle  = __('nav.register');
$activePage = 'register';
$seoKey     = 'register';
$error      = '';

csrf_verify();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass     = $_POST['password']         ?? '';
    $passConf = $_POST['password_confirm'] ?? '';

    if ($pass !== $passConf) {
        $error = __('auth.passwords_mismatch');
    } elseif (!verify_captcha()) {
        $error = __('auth.captcha_fail');
    } else {
        $result = auth_register(
            $_POST['username'] ?? '',
            $_POST['email']    ?? '',
            $pass
        );
        if ($result['ok']) {
            $loginRes = auth_login($_POST['username'], $pass);
            if ($loginRes['ok']) {
                header('Location: /', true, 302);
                exit;
            }
            header('Location: /login?flash=' . urlencode('error:' . $loginRes['msg']), true, 302);
            exit;
        }
        $error = $result['msg'];
    }
}

$intSettings = [];
try {
    $intDb = nexus_db();
    $intSt = $intDb->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'");
    while ($intR = $intSt->fetch()) $intSettings[$intR['key']] = $intR['value'];
} catch (\PDOException $e) { error_log('[NS] register int: '.$e->getMessage()); }

$googleAuth = ($intSettings['int_google_auth_enabled'] ?? '0') === '1' && !empty($intSettings['int_google_auth_client_id']);
$discordAuth = ($intSettings['int_discord_auth_enabled'] ?? '0') === '1' && !empty($intSettings['int_discord_auth_client_id']);
$microsoftAuth = ($intSettings['int_microsoft_auth_enabled'] ?? '0') === '1' && !empty($intSettings['int_microsoft_auth_client_id']);
$githubAuth = ($intSettings['int_github_auth_enabled'] ?? '0') === '1' && !empty($intSettings['int_github_auth_client_id']);
$cfCaptcha = ($intSettings['int_cf_captcha_enabled'] ?? '0') === '1' && !empty($intSettings['int_cf_captcha_site_key']);
$recaptcha = ($intSettings['int_recaptcha_enabled'] ?? '0') === '1' && !empty($intSettings['int_recaptcha_site_key']);

include __DIR__ . '/includes/header.php';
?>
<main class="auth-wrapper">
    <div class="auth-card">

        <div class="auth-card-icon yellow">
            <i class="fa-solid fa-user-plus"></i>
        </div>

        <h1 class="auth-card-title"><?= __('auth.create_title') ?></h1>
        <p class="auth-card-subtitle"><?= __('auth.create_sub') ?></p>

        <?php if ($error): ?>
        <div class="auth-alert-error">
            <i class="fa-solid fa-circle-xmark"></i> <?= e($error) ?>
        </div>
        <?php endif; ?>

        <form method="POST" action="/register" autocomplete="on" novalidate>
        <?= csrf_field() ?>

            <div class="form-group">
                <label for="username" class="form-label"><?= __('auth.username') ?></label>
                <div class="input-wrapper">
                    <i class="fa-solid fa-at input-icon"></i>
                    <input type="text" id="username" name="username" class="form-input"
                        placeholder="kullaniciadi" autocomplete="username" required minlength="3" maxlength="32"
                        value="<?= e($_POST['username'] ?? '') ?>">
                </div>
                <p class="password-hint"><i class="fa-solid fa-circle-info"></i> 3–32 karakter, harf, rakam ve _ izinli.</p>
            </div>

            <div class="form-group">
                <label for="email" class="form-label"><?= __('auth.email_address') ?></label>
                <div class="input-wrapper">
                    <i class="fa-solid fa-envelope input-icon"></i>
                    <input type="email" id="email" name="email" class="form-input"
                        placeholder="kullanici@ornek.com" autocomplete="email" required maxlength="255"
                        value="<?= e($_POST['email'] ?? '') ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="password" class="form-label"><?= __('auth.password') ?></label>
                <div class="input-wrapper">
                    <i class="fa-solid fa-lock input-icon"></i>
                    <input type="password" id="password" name="password" class="form-input"
                        placeholder="••••••••" autocomplete="new-password" required minlength="8" maxlength="128">
                </div>
                <p class="password-hint"><i class="fa-solid fa-shield-halved"></i> En az 8 karakter.</p>
            </div>

            <div class="form-group">
                <label for="password_confirm" class="form-label"><?= __('auth.password_repeat') ?></label>
                <div class="input-wrapper">
                    <i class="fa-solid fa-lock input-icon"></i>
                    <input type="password" id="password_confirm" name="password_confirm" class="form-input"
                        placeholder="••••••••" autocomplete="new-password" required maxlength="128">
                </div>
            </div>

            <?php if ($cfCaptcha): ?>
            <div class="form-group">
                <div class="cf-turnstile" data-sitekey="<?= e($intSettings['int_cf_captcha_site_key']) ?>" data-theme="dark" style="margin-top:4px;"></div>
                <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
            </div>
            <?php elseif ($recaptcha): ?>
            <div class="form-group">
                <div class="g-recaptcha" data-sitekey="<?= e($intSettings['int_recaptcha_site_key']) ?>" data-theme="dark" style="margin-top:4px;"></div>
                <script src="https://www.google.com/recaptcha/api.js" async defer></script>
            </div>
            <?php endif; ?>

            <button type="submit" class="btn-custom btn-yellow btn-full" style="margin-top:8px;">
                <?= __('auth.signup_btn') ?> <span class="btn-icon">➜</span>
            </button>

        </form>

        <?php if ($googleAuth || $discordAuth || $microsoftAuth || $githubAuth): ?>
        <div class="auth-divider">veya</div>
        <div style="display:flex;flex-direction:column;gap:10px;">
            <?php if ($googleAuth): ?>
            <a href="/api/auth/google_auth" class="btn-custom btn-full" style="background:#fff;color:#333;border:1px solid #ddd;">
                <i class="fa-brands fa-google" style="margin-right:8px;"></i> <?= __('auth.oauth_signup', ['brand' => 'Google']) ?>
            </a>
            <?php endif; ?>
            <?php if ($discordAuth): ?>
            <a href="/api/auth/discord_auth" class="btn-custom btn-discord btn-full">
                <i class="fa-brands fa-discord btn-icon"></i> <?= __('auth.oauth_signup', ['brand' => 'Discord']) ?>
            </a>
            <?php endif; ?>
            <?php if ($microsoftAuth): ?>
            <a href="/api/auth/microsoft_auth" class="btn-custom btn-full" style="background:#00a4ef;color:#fff;">
                <i class="fa-brands fa-microsoft" style="margin-right:8px;"></i> <?= __('auth.oauth_signup', ['brand' => 'Microsoft']) ?>
            </a>
            <?php endif; ?>
            <?php if ($githubAuth): ?>
            <a href="/api/auth/github_auth" class="btn-custom btn-full" style="background:#181717;color:#fff;">
                <i class="fa-brands fa-github" style="margin-right:8px;"></i> <?= __('auth.oauth_signup', ['brand' => 'GitHub']) ?>
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <p class="auth-terms">
            <?= __('auth.signup_a') ?> <a href="/legal?p=terms-of-service"><?= __('legal.terms') ?></a><?= __('auth.signup_b') ?> <a href="/legal?p=privacy-policy"><?= __('legal.privacy') ?></a><?= __('auth.signup_c') ?>
        </p>

        <p class="auth-redirect">
            <?= __('auth.has_account') ?> <a href="/login"><i class="fa-solid fa-right-to-bracket" style="font-size:11px;"></i> <?= __('auth.do_login') ?></a>
        </p>

    </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
