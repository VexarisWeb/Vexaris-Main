<?php
auth_redirect_if_logged_in('/');

$pageTitle  = __('auth.reset_title');
$activePage = 'login';
$seoKey     = 'login';
$token      = trim($_GET['token'] ?? '');
$msg        = '';
$error      = '';

if ($token === '') {
    $error = __('auth.reset_invalid');
}
csrf_verify();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass     = $_POST['password']         ?? '';
    $passConf = $_POST['password_confirm'] ?? '';
    if (!verify_captcha()) {
        $error = __('auth.captcha_fail');
    } elseif ($pass !== $passConf) {
        $error = __('auth.password_mismatch');
    } else {
        $result = auth_reset_password($token, $pass);
        if ($result['ok']) {
            $msg = $result['msg'];
        } else {
            $error = $result['msg'];
        }
    }
}

$intSettings = [];
try {
    $intDb = nexus_db();
    $intSt = $intDb->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'");
    while ($intR = $intSt->fetch()) $intSettings[$intR['key']] = $intR['value'];
} catch (\PDOException $e) { error_log('[NS] reset int: '.$e->getMessage()); }
$cfCaptcha = ($intSettings['int_cf_captcha_enabled'] ?? '0') === '1' && !empty($intSettings['int_cf_captcha_site_key']);
$recaptcha = ($intSettings['int_recaptcha_enabled'] ?? '0') === '1' && !empty($intSettings['int_recaptcha_site_key']);

include __DIR__ . '/includes/header.php';
?>
<main class="auth-wrapper">
    <div class="auth-card">

        <div class="auth-card-icon indigo">
            <i class="fa-solid fa-lock"></i>
        </div>

        <h1 class="auth-card-title"><?= __('auth.reset_h1') ?></h1>
        <p class="auth-card-subtitle"><?= __('auth.reset_sub') ?></p>

        <?php if ($error): ?>
        <div class="auth-alert-error">
            <i class="fa-solid fa-circle-xmark"></i> <?= e($error) ?>
        </div>
        <?php endif; ?>

        <?php if ($msg): ?>
        <div class="auth-alert-success">
            <i class="fa-solid fa-circle-check"></i> <?= e($msg) ?>
        </div>
        <p class="auth-redirect" style="margin-top:14px;">
            <a href="/login"><i class="fa-solid fa-right-to-bracket" style="font-size:11px;"></i> <?= __('auth.do_login') ?></a>
        </p>
        <?php else: ?>

        <form method="POST" action="/reset-password?token=<?= e($token) ?>" autocomplete="on" novalidate>
        <?= csrf_field() ?>

            <div class="form-group">
                <label for="password" class="form-label"><?= __('auth.reset_new') ?></label>
                <div class="input-wrapper">
                    <i class="fa-solid fa-lock input-icon"></i>
                    <input type="password" id="password" name="password" class="form-input"
                        placeholder="••••••••" autocomplete="new-password" required minlength="8" maxlength="128">
                </div>
                <p class="password-hint"><i class="fa-solid fa-shield-halved"></i> <?= __('auth.reset_hint') ?></p>
            </div>

            <div class="form-group">
                <label for="password_confirm" class="form-label"><?= __('auth.reset_new2') ?></label>
                <div class="input-wrapper">
                    <i class="fa-solid fa-lock input-icon"></i>
                    <input type="password" id="password_confirm" name="password_confirm" class="form-input"
                        placeholder="••••••••" autocomplete="new-password" required maxlength="128">
                </div>
            </div>

            <?php if ($cfCaptcha): ?>
            <div class="form-group">
                <div class="cf-turnstile" data-sitekey="<?= e($intSettings['int_cf_captcha_site_key']) ?>" data-theme="dark" style="margin-top:4px;"></div>
                <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
            </div>
            <?php elseif ($recaptcha): ?>
            <div class="form-group">
                <div class="g-recaptcha" data-sitekey="<?= e($intSettings['int_recaptcha_site_key']) ?>" data-theme="dark" style="margin-top:4px;"></div>
                <script src="https://www.google.com/recaptcha/api.js" async defer></script>
            </div>
            <?php endif; ?>

            <button type="submit" class="btn-custom btn-indigo btn-full" style="margin-top:8px;">
                <i class="fa-solid fa-check btn-icon"></i> <?= __('auth.reset_btn') ?>
            </button>

        </form>

        <?php endif; ?>

    </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>