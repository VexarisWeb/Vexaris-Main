<?php
$pageTitle  = 'Destek';
$activePage = 'support';
$seoKey     = 'support';

$db         = nexus_db();
$isLoggedIn = auth_check();
$me         = $isLoggedIn ? auth_user() : null;

$tid = isset($_GET['id']) ? (int)$_GET['id'] : 0;

require_once ROOT_PATH . '/core/support-page.php';
[$flashType, $flashText] = support_page_flash();
$nxSupport = ($isLoggedIn && $db) ? support_page_data($db, (int)$me['id'], $tid) : support_page_defaults();
$activeTicket  = $nxSupport['activeTicket'];
$ticketReplies = $nxSupport['ticketReplies'];
$myTickets     = $nxSupport['myTickets'];
$hasOpen       = $nxSupport['hasOpen'];
$categories    = $nxSupport['categories'];
$nxIntSettings = [];
try { $nxIntDb = nexus_db(); $nxIntSt = $nxIntDb->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'"); while ($nxIntR = $nxIntSt->fetch()) $nxIntSettings[$nxIntR['key']] = $nxIntR['value']; } catch (\Throwable $e) {}
$nxCfCaptcha = ($nxIntSettings['int_cf_captcha_enabled'] ?? '0') === '1' && !empty($nxIntSettings['int_cf_captcha_site_key']);
$nxRecaptcha = ($nxIntSettings['int_recaptcha_enabled'] ?? '0') === '1' && !empty($nxIntSettings['int_recaptcha_site_key']);
$statusMap  = [
    'open'    => ['badge-open',     __('ticket.open')],
    'replied' => ['badge-answered', __('ticket.replied')],
    'closed'  => ['badge-closed',   __('ticket.closed')],
];

include __DIR__ . '/includes/header.php';
?>
<style>
.hidden{display:none!important}
.ticket-shell{display:grid;grid-template-columns:300px 1fr;min-height:520px;height:calc(100vh - 68px);height:calc(100dvh - 68px);}
.ticket-sidebar{background:var(--bg-card);border-right:1px solid var(--border);display:flex;flex-direction:column;overflow:hidden;min-height:0;}
.ticket-main{display:flex;flex-direction:column;overflow:hidden;min-height:0;}
.ticket-list{flex:1;overflow-y:auto;padding:8px 10px 20px;}
.ticket-item{display:flex;flex-direction:column;gap:3px;padding:11px 13px;border-radius:12px;cursor:pointer;border:1px solid transparent;margin-bottom:3px;text-decoration:none;}
.ticket-item:hover{background:var(--bg-hover);}
.ticket-item.active{background:rgba(99,102,241,.1);border-color:rgba(99,102,241,.3);}
.ticket-item-title{font-size:13px;font-weight:700;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.ticket-detail-head{padding:20px 24px 14px;border-bottom:1px solid var(--border);flex-shrink:0;}
.ticket-messages{flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:14px;}
.ticket-reply-form{padding:14px 24px;border-top:1px solid var(--border);flex-shrink:0;}
.msg-bubble{max-width:76%;display:flex;flex-direction:column;gap:5px;}
.msg-bubble.mine{align-self:flex-end;align-items:flex-end;}
.msg-bubble.admin-msg{align-self:flex-start;align-items:flex-start;}
.msg-text{padding:11px 15px;border-radius:14px;font-size:14px;line-height:1.65;}
.msg-bubble.mine .msg-text{background:rgba(99,102,241,.18);border:1px solid rgba(99,102,241,.3);color:var(--text);border-bottom-right-radius:4px;}
.msg-bubble.admin-msg .msg-text{background:var(--bg-surface);border:1px solid var(--border);color:var(--text);border-bottom-left-radius:4px;}
.msg-meta{font-size:10px;color:var(--muted);opacity:0;visibility:hidden;transition:opacity .2s;}
.msg-bubble:hover .msg-meta{opacity:1;visibility:visible;}
.msg-ticks{font-size:10px;font-weight:700;color:var(--muted);display:flex;align-items:center;gap:3px;}
.msg-ticks.tick-seen{color:#53bdeb;}
@keyframes nxTickPop{0%{transform:scale(.4);opacity:0}60%{transform:scale(1.25)}100%{transform:scale(1);opacity:1}}
.tick-pop{animation:nxTickPop .45s cubic-bezier(.34,1.56,.64,1);}
@keyframes nxMsgIn{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}
.msg-in{animation:nxMsgIn .3s ease;}
@keyframes nxSendFly{0%{transform:translateX(0);opacity:1}100%{transform:translateX(26px);opacity:0}}
.nx-send-fly svg{animation:nxSendFly .35s ease;}
.nx-composer{display:flex;align-items:center;gap:8px;background:var(--bg-surface);border:1px solid var(--border);border-radius:999px;padding:6px 6px 6px 8px;transition:border-color .2s;}
.nx-composer:focus-within{border-color:rgba(99,102,241,.55);}
.nx-attach-btn{flex-shrink:0;width:38px;height:38px;border-radius:50%;border:1px solid var(--border);background:rgba(255,255,255,.04);color:var(--muted);cursor:pointer;font-size:15px;display:flex;align-items:center;justify-content:center;transition:.15s;}
.nx-attach-btn:hover{color:#fff;border-color:rgba(99,102,241,.5);}
.nx-chat-input{flex:1;min-width:0;background:transparent;border:none;outline:none;color:var(--text);font-family:inherit;font-size:14px;padding:8px 2px;}
.nx-chat-input::placeholder{color:var(--dim);}
.nx-count{flex-shrink:0;font-size:10px;color:var(--dim);font-weight:700;min-width:44px;text-align:right;}
.nx-send-btn{flex-shrink:0;width:42px;height:42px;border-radius:50%;border:none;cursor:pointer;background:linear-gradient(135deg,#38bdf8,#2563eb);color:#fff;font-size:16px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 14px rgba(37,99,235,.4);transition:transform .12s,filter .15s,opacity .15s;}
.nx-send-btn:hover{filter:brightness(1.1);}
.nx-send-btn:active{transform:scale(.9);}
.nx-send-btn.is-idle{opacity:.55;}
.nx-attach-preview{display:flex;align-items:center;gap:8px;margin-bottom:8px;}
.nx-attach-preview img{width:52px;height:52px;object-fit:cover;border-radius:10px;border:1px solid rgba(99,102,241,.4);}
.nx-attach-x{width:24px;height:24px;border-radius:50%;border:1px solid var(--border);background:rgba(239,68,68,.15);color:#f87171;cursor:pointer;font-size:12px;}
.nx-chat-img{max-width:240px;max-height:180px;border-radius:10px;border:1px solid rgba(255,255,255,.12);margin-bottom:6px;display:block;cursor:zoom-in;}
.nx-faded{opacity:.4;pointer-events:none;filter:grayscale(.6);}
@media(max-width:560px){.nx-count{display:none;}.nx-chat-input{font-size:13px;}.msg-bubble{max-width:88%;}.nx-chat-img{max-width:180px;}}
.badge-status{display:inline-flex;align-items:center;gap:4px;padding:2px 9px;border-radius:999px;font-size:11px;font-weight:700;}
.badge-open{background:rgba(239,68,68,.12);color:#f87171;}
.badge-answered{background:rgba(99,102,241,.12);color:#a5b4fc;}
.badge-closed{background:rgba(100,116,139,.1);color:#94a3b8;}
.form-field{width:100%;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;
  padding:10px 14px;color:var(--text);font-family:inherit;font-size:14px;outline:none;transition:border-color .2s;}
.form-field:focus{border-color:rgba(99,102,241,.5);}
.btn-send{display:inline-flex;align-items:center;gap:7px;padding:9px 20px;border-radius:10px;
  background:#6366f1;color:#fff;font-weight:700;font-size:13px;border:none;
  box-shadow:0 4px 0 #3730a3;cursor:pointer;transition:transform .05s;}
.btn-send:active{transform:translateY(3px);box-shadow:0 1px 0 #3730a3;}
.flash-ok{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#4ade80;padding:10px 16px;border-radius:10px;font-size:13px;font-weight:600;margin-bottom:12px;}
.flash-err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#f87171;padding:10px 16px;border-radius:10px;font-size:13px;font-weight:600;margin-bottom:12px;}
@media(max-width:768px){.ticket-shell{grid-template-columns:1fr;min-height:0;height:calc(100dvh - 60px);}
  .ticket-sidebar{position:fixed;top:0;left:0;bottom:0;width:min(320px,86vw);z-index:1001;border-right:1px solid var(--border);border-bottom:none;max-height:none;transform:translateX(-106%);transition:transform .25s ease;box-shadow:none;}
  .ticket-sidebar.nx-open{transform:none;box-shadow:24px 0 60px rgba(0,0,0,.5);}
  .nx-drawer-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:1000;}
  .nx-drawer-btn{display:inline-flex!important;}
  .ticket-detail-head{padding:14px 14px 10px;}
  .ticket-messages{padding:14px;}
  .ticket-reply-form{padding:10px 12px;}}
.nx-drawer-btn{display:none;align-items:center;justify-content:center;width:36px;height:36px;border-radius:10px;background:rgba(255,255,255,.05);border:1px solid var(--border);color:var(--text);cursor:pointer;font-size:15px;flex-shrink:0;}
.nx-mobile-bar{display:none;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid var(--border);}
.nx-mobile-bar .btn-send{box-shadow:0 4px 0 #3730a3;}
@media(max-width:768px){.nx-mobile-bar{display:flex;}}
.ticket-head-actions{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap;}
@media(max-width:560px){
  .ticket-head-actions .btn-send{flex:1;justify-content:center;}
  .ticket-head-actions form{flex:1;display:flex;}
  .ticket-head-actions form button{flex:1;justify-content:center;}
  .nx-composer{border-radius:22px;}
}
</style>

<main style="flex:1;">
<?php if (!$isLoggedIn): ?>
<section style="display:flex;align-items:center;justify-content:center;min-height:60vh;padding:40px 24px;">
    <div style="text-align:center;max-width:420px;">
        <div style="width:64px;height:64px;background:rgba(99,102,241,.15);border-radius:18px;display:flex;align-items:center;justify-content:center;font-size:28px;color:#818cf8;margin:0 auto 20px;">
            <i class="fa-solid fa-headset"></i>
        </div>
        <h1 style="font-size:1.8rem;font-weight:900;margin-bottom:10px;"><?= __('support.center') ?></h1>
        <p style="color:var(--text-muted);font-size:14px;line-height:1.7;margin-bottom:24px;"><?= __('support.login_required') ?></p>
        <a href="/login" style="display:inline-flex;align-items:center;gap:8px;padding:10px 24px;background:#fbc853;color:#4c3716;font-weight:800;border-radius:10px;text-decoration:none;box-shadow:0 4px 0 #a26e13;">
            <i class="fa-solid fa-right-to-bracket"></i> <?= __('nav.login') ?>
        </a>
    </div>
</section>
<?php else: ?>

<div class="ticket-shell">

    <aside class="ticket-sidebar" id="nxTicketSidebar">
        <div style="padding:18px 16px 12px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-shrink:0;">
            <span style="font-size:14px;font-weight:800;"><?= __('support.my_tickets') ?></span>
            <button onclick="openTicketModal()" class="btn-send<?= $hasOpen ? ' nx-faded' : '' ?>" style="padding:6px 14px;font-size:12px;"<?= $hasOpen ? ' disabled title="' . e(__('support.open_exists')) . '"' : '' ?>>
                <i class="fa-solid fa-plus"></i> <?= __('support.new') ?>
            </button>
        </div>
        <div class="ticket-list">
            <?php if (empty($myTickets)): ?>
            <p style="text-align:center;color:var(--muted);font-size:13px;padding:24px 0;"><?= __('support.no_tickets') ?></p>
            <?php else: ?>
            <?php foreach ($myTickets as $t): ?>
            <?php [$sb,$sl] = $statusMap[$t['status']] ?? ['badge-closed','?']; ?>
            <a href="/support?id=<?= $t['id'] ?>" class="ticket-item <?= $tid===$t['id']?'active':'' ?>">
                <div class="ticket-item-title"><?= e($t['title']) ?></div>
                <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;margin-top:2px;">
                    <span style="font-size:11px;color:var(--muted);"><?= e($t['category']??'Genel') ?></span>
                    <span class="badge-status <?= $sb ?>"><?= $sl ?></span>
                </div>
                <div style="font-size:11px;color:var(--dim);"><?= date('d.m.Y H:i', strtotime($t['created_at'])) ?></div>
            </a>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </aside>

    <div class="ticket-main">
        <?php if (!$tid || !$activeTicket): ?>
        <?php if ($flashType): ?>
        <div style="margin:0 auto 14px;padding:11px 16px;background:<?= $flashType==='success' ? 'rgba(52,211,153,.12)' : 'rgba(248,113,113,.12)' ?>;border:1px solid <?= $flashType==='success' ? 'rgba(52,211,153,.3)' : 'rgba(248,113,113,.3)' ?>;border-radius:12px;color:<?= $flashType==='success' ? '#34d399' : '#f87171' ?>;font-size:13px;font-weight:600;max-width:520px;width:100%;text-align:left;">
            <i class="fa-solid <?= $flashType==='success' ? 'fa-circle-check' : 'fa-circle-exclamation' ?>" style="margin-right:6px;"></i><?= e($flashText) ?>
        </div>
        <?php endif; ?>
        <div class="nx-mobile-bar">
            <button type="button" class="nx-drawer-btn" onclick="nxToggleTickets()" title="<?= e(__('support.my_tickets')) ?>"><i class="fa-solid fa-bars"></i></button>
            <button onclick="openTicketModal()" class="btn-send<?= $hasOpen ? ' nx-faded' : '' ?>" style="padding:8px 18px;font-size:12px;flex:1;justify-content:center;"<?= $hasOpen ? ' disabled title="' . e(__('support.open_exists')) . '"' : '' ?>>
                <i class="fa-solid fa-plus"></i> <?= __('support.new') ?>
            </button>
        </div>
        <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;color:var(--muted);padding:40px;text-align:center;">
            <i class="fa-solid fa-comments" style="font-size:52px;color:var(--dim);"></i>
            <p style="font-size:15px;font-weight:700;"><?= __('support.pick') ?></p>
            <p style="font-size:13px;max-width:320px;line-height:1.6;"><?= __('support.pick_hint') ?></p>
        </div>
        <?php else: ?>

        <div class="ticket-detail-head">
            <?php [$sb,$sl] = $statusMap[$activeTicket['status']] ?? ['badge-closed','?']; ?>
             <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                <button type="button" class="nx-drawer-btn" onclick="nxToggleTickets()" title="<?= e(__('support.my_tickets')) ?>"><i class="fa-solid fa-bars"></i></button>
                <a href="/support" style="color:var(--muted);font-size:14px;"><i class="fa-solid fa-arrow-left"></i></a>
                <h2 style="font-size:15px;font-weight:800;"><?= e($activeTicket['title']) ?></h2>
                <span class="badge-status <?= $sb ?>"><?= $sl ?></span>
            </div>
            <div style="font-size:12px;color:var(--muted);margin-top:5px;">
                <span style="background:rgba(255,255,255,.05);padding:2px 8px;border-radius:6px;margin-right:8px;"><?= e($activeTicket['category']??'Genel') ?></span>
                #<?= $activeTicket['id'] ?> · <?= date('d.m.Y H:i', strtotime($activeTicket['created_at'])) ?>
            </div>
            <div class="ticket-head-actions">
                <?php if ($activeTicket['status'] !== 'closed'): ?>
                <form method="POST" action="/action.php" onsubmit="return confirm('<?= htmlspecialchars(__('support.confirm_close'), ENT_QUOTES) ?>');">
                    <input type="hidden" name="action" value="ticket_close">
                    <input type="hidden" name="ticket_id" value="<?= $activeTicket['id'] ?>">
                    <?= csrf_field() ?>
                    <button type="submit" style="display:inline-flex;align-items:center;gap:7px;padding:8px 18px;border-radius:10px;background:rgba(255,255,255,.05);border:1px solid var(--border);color:var(--text);font-size:12px;font-weight:800;cursor:pointer;">
                        <i class="fa-solid fa-lock"></i> <?= __('support.close') ?>
                    </button>
                </form>
                <?php endif; ?>
                <button onclick="openTicketModal()"<?= $hasOpen ? ' disabled title="' . e(__('support.open_exists')) . '"' : '' ?> style="display:inline-flex;align-items:center;gap:7px;padding:8px 18px;border-radius:10px;background:#6366f1;border:1px solid #3730a3;color:#fff;font-size:12px;font-weight:800;cursor:pointer;<?= $hasOpen ? 'opacity:.4;pointer-events:none;filter:grayscale(.6);' : '' ?>">
                    <i class="fa-solid fa-plus"></i> <?= __('support.new_ticket') ?>
                </button>
            </div>
            <?php if ($flashType): ?>
            <div class="flash-<?= $flashType==='success'?'ok':'err' ?>" style="margin-top:10px;">
                <i class="fa-solid fa-<?= $flashType==='success'?'circle-check':'circle-xmark' ?>"></i>
                <?= e($flashText) ?>
            </div>
            <?php endif; ?>
        </div>

        <div class="ticket-messages" id="msgBox">
            <?php $initialSeen = false; foreach ($ticketReplies as $sr) { if ((int)$sr['is_admin'] === 1) { $initialSeen = true; break; } } ?>
            <?php $lastOwnRid = 0; foreach ($ticketReplies as $lr) { if (!(int)$lr['is_admin']) $lastOwnRid = (int)$lr['id']; } ?>
            <div class="msg-bubble mine">
                <div class="msg-text"><?= e($activeTicket['message'] ?? '') ?></div>
                <div class="msg-meta"><i class="fa-regular fa-clock"></i> <?= date('d.m.Y H:i', strtotime($activeTicket['created_at'])) ?> · Siz</div>
                <?php if ($lastOwnRid === 0): ?>
                <div class="msg-ticks<?= $initialSeen ? ' tick-seen' : '' ?>" data-tick-init="<?= $initialSeen ? 'seen' : 'sent' ?>"><?= $initialSeen ? __('support.seen') : '✓' ?></div>
                <?php endif; ?>
            </div>
            <?php foreach ($ticketReplies as $r): ?>
            <div class="msg-bubble <?= $r['is_admin']?'admin-msg':'mine' ?>" data-rid="<?= (int)$r['id'] ?>">
                <?php if ($r['is_admin']): ?>
                <div style="display:flex;align-items:center;gap:7px;margin-bottom:4px;">
                    <img src="<?= e($r['avatar']??'/images/avatars/default.svg') ?>" style="width:22px;height:22px;border-radius:50%;border:1.5px solid rgba(99,102,241,.4);image-rendering:pixelated;" width="22" height="22">
                    <span style="font-size:12px;font-weight:700;color:#a5b4fc;"><?= e($r['username']) ?>
                        <span style="background:rgba(99,102,241,.15);padding:1px 7px;border-radius:5px;font-size:10px;">DESTEK</span>
                    </span>
                </div>
                <?php endif; ?>
                <div class="msg-text"><?= e($r['message']) ?></div>
                <?php if (!empty($r['image_url'])): ?>
                <a href="<?= e($r['image_url']) ?>" target="_blank" rel="noopener"><img src="<?= e($r['image_url']) ?>" class="nx-chat-img" alt="" loading="lazy" width="560" height="315"></a>
                <?php endif; ?>
                <div class="msg-meta"><i class="fa-regular fa-clock"></i> <?= date('d.m.Y H:i', strtotime($r['created_at'])) ?><?= !$r['is_admin']?' · Siz':'' ?></div>
                <?php if (!$r['is_admin'] && (int)$r['id'] === $lastOwnRid): ?>
                <?php $seen = (int)($r['is_seen'] ?? 0) === 1; ?>
                <div class="msg-ticks<?= $seen ? ' tick-seen' : '' ?>" data-tick="<?= (int)$r['id'] ?>"><?= $seen ? __('support.seen') : '✓' ?></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>

        <?php if ($activeTicket['status'] !== 'closed'): ?>
        <div class="ticket-reply-form">
            <div class="nx-attach-preview hidden" id="nxPreview">
                <img id="nxPreviewImg" alt="">
                <button type="button" class="nx-attach-x" id="nxPreviewX" title="<?= e(__('support.remove_attach')) ?>"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <form id="replyForm" style="margin:0;" data-tid="<?= $activeTicket['id'] ?>">
                <?= csrf_field() ?>
                <div class="nx-composer">
                    <button type="button" class="nx-attach-btn" id="nxAttachBtn" title="<?= e(__('support.attach_title')) ?>"><i class="fa-solid fa-paperclip"></i></button>
                    <input type="file" id="nxAttachFile" accept=".png,.jpg,.jpeg,.webp" hidden>
                    <input type="text" class="nx-chat-input" id="nxChatInput" maxlength="500" placeholder="<?= e(__('support.type_ph')) ?>" autocomplete="off">
                    <span class="nx-count" id="nxCount">0/500</span>
                    <button type="submit" class="nx-send-btn is-idle" id="nxSendBtn" title="<?= e(__('support.send')) ?>"><i class="fa-solid fa-paper-plane"></i></button>
                </div>
            </form>
        </div>
        <?php else: ?>
        <div style="padding:14px 24px;background:rgba(100,116,139,.07);border-top:1px solid var(--border);text-align:center;font-size:13px;color:var(--muted);">
            <i class="fa-solid fa-lock" style="margin-right:6px;"></i> <?= __('support.closed_msg') ?>
        </div>
        <?php endif; ?>

        <?php endif; ?>
    </div>
</div>

<div id="ticketModal" class="hidden" style="position:fixed;inset:0;z-index:999;background:rgba(0,0,0,.7);display:flex;align-items:center;justify-content:center;padding:16px;">
    <div style="position:relative;background:var(--bg-card);border:1px solid rgba(99,102,241,.35);border-radius:20px;width:100%;max-width:580px;max-height:90vh;overflow-y:auto;padding:26px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;">
            <h2 style="font-size:16px;font-weight:800;display:flex;align-items:center;gap:8px;">
                <i class="fa-solid fa-headset" style="color:#6366f1;"></i> Yeni Destek Talebi
            </h2>
            <button onclick="closeTicketModal()" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:20px;line-height:1;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <form method="POST" action="/action.php" id="ticketForm">
            <input type="hidden" name="action" value="ticket_create">
            <?= csrf_field() ?>
            <div style="margin-bottom:14px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('support.title_label') ?></label>
                <input type="text" name="title" class="form-field" required minlength="3" maxlength="200"
                       style="background:var(--bg-surface);">
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('support.category') ?></label>
                <select name="category" class="form-field" style="background:var(--bg-surface);">
                    <?php foreach ($categories as $c): ?>
                    <option value="<?= e($c) ?>"><?= e($c) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="margin-bottom:20px;">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;"><?= __('support.message_label') ?></label>
                <textarea name="message" class="form-field" required minlength="10" maxlength="2000" rows="4" placeholder="<?= e(__('support.message_ph')) ?>" style="background:var(--bg-surface);resize:vertical;"></textarea>
            </div>
            <?php if ($nxCfCaptcha): ?><div style="margin-bottom:14px;"><div class="cf-turnstile" data-sitekey="<?= e($nxIntSettings['int_cf_captcha_site_key']) ?>" data-theme="dark"></div><script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script></div><?php elseif ($nxRecaptcha): ?><div style="margin-bottom:14px;"><div class="g-recaptcha" data-sitekey="<?= e($nxIntSettings['int_recaptcha_site_key']) ?>" data-theme="dark"></div><script src="https://www.google.com/recaptcha/api.js" async defer></script></div><?php endif; ?>
            <div style="display:flex;gap:10px;justify-content:flex-end;">
                <button type="button" onclick="closeTicketModal()"
                        style="padding:9px 18px;background:rgba(255,255,255,.05);border:1px solid var(--border);border-radius:10px;color:var(--muted);cursor:pointer;font-size:13px;font-weight:600;">
                    <?= __('support.cancel') ?>
                </button>
                <button type="submit" class="btn-send"><i class="fa-solid fa-paper-plane"></i> <?= __('support.send') ?></button>
            </div>
        </form>
    </div>
</div>

<script src="/assets/js/support-chat.js?v=2"></script>
<script>
function openTicketModal() {
    var m = document.getElementById('ticketModal');
    if (m) m.classList.remove('hidden');
}

function closeTicketModal() {
    var m = document.getElementById('ticketModal');
    if (m) m.classList.add('hidden');
}

function nxToggleTickets(force) {
    var sb = document.getElementById('nxTicketSidebar');
    if (!sb) return;
    var open = (typeof force === 'boolean') ? force : !sb.classList.contains('nx-open');
    sb.classList.toggle('nx-open', open);
    var bd = document.getElementById('nxDrawerBackdrop');
    if (open && !bd) {
        bd = document.createElement('div');
        bd.id = 'nxDrawerBackdrop';
        bd.className = 'nx-drawer-backdrop';
        bd.onclick = function(){ nxToggleTickets(false); };
        document.body.appendChild(bd);
    }
    if (bd) bd.style.display = open ? 'block' : 'none';
    try { document.body.style.overflow = open ? 'hidden' : ''; } catch(e) {}
}

window.NX_SUPPORT_LANG = <?= json_encode(['seen'=>__('support.seen'),'now'=>__('support.now'),'you'=>__('support.you'),'admin_name'=>__('support.admin_name'),'admin_badge'=>__('support.admin_badge')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
SupportChatInit({
  boxId:'msgBox', formId:'replyForm', inputId:'nxChatInput', sendBtnId:'nxSendBtn', countId:'nxCount',
  fileBtnId:'nxAttachBtn', fileInputId:'nxAttachFile', previewId:'nxPreview', previewImgId:'nxPreviewImg', previewXId:'nxPreviewX',
  tickTag:'div', tickClass:'msg-ticks', bubbleMine:'msg-bubble mine msg-in', metaSelect:'.msg-meta',
  metaDone:function(c){ var L=(window.NX_SUPPORT_LANG||{}); return '<i class="fa-regular fa-clock"></i> ' + c + ' · ' + (L.you||'Siz'); }, metaDoneHtml:true,
  optimistic:function(h, img, txt){
    var s = h.img(img);
    if (txt !== '') s += '<div class="msg-text">' + h.esc(txt) + '</div>';
    s += '<div class="msg-meta"><i class="fa-regular fa-clock"></i> ' + ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.now)||'Şimdi') + ' · ' + ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.you)||'Siz') + '</div>';
    return s;
  },
  adminHead:function(esc, m){
    var av = m.avatar || '/images/avatars/default.svg';
    return '<div style="display:flex;align-items:center;gap:7px;margin-bottom:4px;">'
      + '<img src="' + esc(av) + '" style="width:22px;height:22px;border-radius:50%;border:1.5px solid rgba(99,102,241,.4);image-rendering:pixelated;" width="22" height="22">'
      + '<span style="font-size:12px;font-weight:700;color:#a5b4fc;">' + esc(m.username || ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.admin_name)||'Destek'))
      + '<span style="background:rgba(99,102,241,.15);padding:1px 7px;border-radius:5px;font-size:10px;">' + ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.admin_badge)||'DESTEK') + '</span></span></div>';
  },
  polled:function(h, m){
    var s = h.img(m.image);
    if (m.admin) s += h.admin(m);
    if (m.message !== '') s += '<div class="msg-text">' + h.esc(m.message) + '</div>';
    s += '<div class="msg-meta"><i class="fa-regular fa-clock"></i> ' + h.esc(m.created || '') + (m.admin ? '' : ' · ' + ((window.NX_SUPPORT_LANG&&window.NX_SUPPORT_LANG.you)||'Siz')) + '</div>';
    if (!m.admin) s += '<div class="msg-ticks" data-tick="' + m.id + '">✓</div>';
    return {cls:'msg-bubble msg-in ' + (m.admin ? 'admin-msg' : 'mine'), html:s};
  },
  onError:function(msg){ if (typeof showToast === 'function') { showToast(msg, false); } }
});
</script>

<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
