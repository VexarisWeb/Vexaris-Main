<?php
/** themes/default/user/connections.php */
auth_require('/login');

$pageTitle   = __('panel.conn_title');
$activePage  = '';
$activePanel = 'connections';
$u           = auth_user();
$db          = nexus_db();

$flashType = '';
$flashText = '';
if (isset($_GET['flash'])) {
    $parts = explode(':', urldecode($_GET['flash']), 2);
    $flashType = $parts[0] === 'error' ? 'error' : 'success';
    $flashText = $parts[1] ?? '';
}

$providers = [];
try {
    $st = $db->query("SELECT `key`,`value` FROM settings WHERE `key` LIKE 'int\\_%'");
    $intSettings = [];
    while ($r = $st->fetch()) $intSettings[$r['key']] = $r['value'];

    $defs = [
        'google_auth'    => ['label'=>'Google','icon'=>'fa-google','color'=>'#4285f4','desc'=>__('panel.conn_google')],
        'discord_auth'   => ['label'=>'Discord','icon'=>'fa-discord','color'=>'#5865f2','desc'=>__('panel.conn_discord')],
        'microsoft_auth' => ['label'=>'Microsoft','icon'=>'fa-microsoft','color'=>'#00a4ef','desc'=>__('panel.conn_microsoft')],
        'github_auth'    => ['label'=>'GitHub','icon'=>'fa-github','color'=>'#181717','desc'=>__('panel.conn_github')],
    ];
    foreach ($defs as $slug => $def) {
        $enabled = ($intSettings['int_'.$slug.'_enabled'] ?? '0') === '1';
        $clientId = trim($intSettings['int_'.$slug.'_client_id'] ?? '');
        if (!$enabled || $clientId === '') continue;
        $def['slug'] = $slug;
        $providers[] = $def;
    }

    $ust = $db->prepare("SELECT oauth_google_id,oauth_discord_id,oauth_microsoft_id,oauth_github_id FROM users WHERE id=?");
    $ust->execute([$u['id']]);
    $oauthRow = $ust->fetch() ?: [];
    $linkedMap = [
        'google_auth'    => !empty($oauthRow['oauth_google_id'] ?? ''),
        'discord_auth'   => !empty($oauthRow['oauth_discord_id'] ?? ''),
        'microsoft_auth' => !empty($oauthRow['oauth_microsoft_id'] ?? ''),
        'github_auth'    => !empty($oauthRow['oauth_github_id'] ?? ''),
    ];
} catch (\PDOException $e) {
    error_log('[NS] connections: '.$e->getMessage());
    $linkedMap = [];
}

include __DIR__ . '/../includes/header.php';
?>
<div class="panel-layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="panel-content">

        <div class="panel-card">
            <h1 class="panel-card-title"><i class="fa-solid fa-link" style="color:#6366f1;margin-right:8px;"></i><?= __('panel.conn_title') ?></h1>
            <p class="panel-card-desc"><?= __('panel.conn_desc') ?></p>

            <?php if ($flashText): ?>
            <div style="border-radius:12px;padding:12px 16px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;margin-bottom:18px;
                        <?= $flashType==='success' ? 'background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.3);color:#86efac;' : 'background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#fca5a5;' ?>">
                <i class="fa-solid <?= $flashType==='success' ? 'fa-circle-check' : 'fa-circle-xmark' ?>"></i>
                <?= e($flashText) ?>
            </div>
            <?php endif; ?>

            <?php if (empty($providers)): ?>
            <div style="text-align:center;padding:40px 20px;color:var(--text-muted);">
                <i class="fa-solid fa-plug-circle-xmark" style="font-size:40px;color:var(--text-dim);margin-bottom:12px;display:block;"></i>
                <p style="font-size:14px;font-weight:600;"><?= __('panel.no_providers') ?></p>
            </div>
            <?php else: ?>
            <div style="display:flex;flex-direction:column;gap:14px;">
                <?php foreach ($providers as $p):
                    $linked = $linkedMap[$p['slug']] ?? false;
                ?>
                <div style="display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;
                            background:var(--bg-surface);border:1px solid var(--border);border-radius:16px;padding:18px 20px;">
                    <div style="display:flex;align-items:center;gap:14px;">
                        <span style="width:44px;height:44px;border-radius:12px;background:<?= $p['color'] ?>15;display:flex;align-items:center;justify-content:center;font-size:20px;color:<?= $p['color'] ?>;flex-shrink:0;">
                            <i class="fa-brands <?= $p['icon'] ?>"></i>
                        </span>
                        <div>
                            <div style="font-size:15px;font-weight:800;"><?= $p['label'] ?></div>
                            <div style="font-size:12px;color:var(--text-muted);margin-top:2px;"><?= $p['desc'] ?></div>
                            <div style="margin-top:6px;">
                                <span style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;
                                    <?= $linked ? 'background:rgba(34,197,94,.15);color:#4ade80;' : 'background:rgba(100,116,139,.15);color:var(--text-muted);' ?>">
                                    <?= $linked ? __('panel.linked') : __('panel.not_linked') ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <?php if ($linked): ?>
                    <form method="POST" action="/action.php" onsubmit="return confirm(<?= htmlspecialchars(json_encode(__('panel.unlink_confirm', ['brand' => $p['label']])), ENT_QUOTES) ?>);">
                        <input type="hidden" name="action" value="oauth_unlink">
                        <?= csrf_field() ?>
                        <input type="hidden" name="slug" value="<?= $p['slug'] ?>">
                        <button type="submit" class="btn-custom btn-red btn-sm">
                            <i class="fa-solid fa-unlink btn-icon"></i> <?= __('panel.unlink') ?>
                        </button>
                    </form>
                    <?php else: ?>
                    <a href="/api/auth/<?= $p['slug'] ?>?connect=1" class="btn-custom btn-indigo btn-sm">
                        <i class="fa-solid fa-link btn-icon"></i> <?= __('panel.link') ?>
                    </a>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

    </main>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
