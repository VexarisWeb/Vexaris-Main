<?php
auth_require('/login');

$pageTitle   = __('nav.dashboard');
$activePage  = '';
$activePanel = 'dashboard';
$u = auth_user();
$db = nexus_db();

$purchasedCount = $activeLicCount = $openTicketCount = 0;
$userCart = [];
if ($db) {
    try {
        $st = $db->prepare('SELECT COUNT(*) FROM sales WHERE user_id=?'); $st->execute([$u['id']]); $purchasedCount = (int)$st->fetchColumn();
        $st = $db->prepare('SELECT COUNT(*) FROM licenses WHERE user_id=? AND status="active"'); $st->execute([$u['id']]); $activeLicCount = (int)$st->fetchColumn();
        $st = $db->prepare('SELECT COUNT(*) FROM tickets WHERE user_id=? AND status!="closed"'); $st->execute([$u['id']]); $openTicketCount = (int)$st->fetchColumn();
        $cartStmt = $db->prepare('SELECT c.*,p.name,p.price,p.image_url FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=? ORDER BY c.added_at DESC');
        $cartStmt->execute([$u['id']]);
        $userCart = $cartStmt->fetchAll();
    } catch (\Exception $e) { error_log('[NS] dashboard: '.$e->getMessage()); }
}

$balanceLog = [];
if ($db) {
    try {
        $bl = $db->prepare('SELECT amount,type,description,created_at FROM balance_log WHERE user_id=? ORDER BY created_at DESC LIMIT 10');
        $bl->execute([$u['id']]);
        $balanceLog = $bl->fetchAll();
    } catch (\Exception $e) {}
}

include __DIR__ . '/../includes/header.php';
?>
<div class="panel-layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="panel-content">

        <div class="panel-card">
            <h1 class="panel-card-title"><?= __('panel.welcome_a') ?><?= e($u['username']) ?>!</h1>
            <p class="panel-card-desc"><?= __('panel.summary') ?></p>

            <div class="dash-stats" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:16px;">
                <?php
                $stats = [
                    ['icon'=>'fa-cubes',   'color'=>'#6366f1','label'=>__('panel.products'),'val'=>$purchasedCount],
                    ['icon'=>'fa-key',     'color'=>'#fbc853','label'=>__('panel.licenses'),      'val'=>$activeLicCount],
                    ['icon'=>'fa-headset', 'color'=>'#34d399','label'=>__('panel.open_tickets'),        'val'=>$openTicketCount],
                ];
                foreach ($stats as $s): ?>
                <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:14px;padding:20px 18px;">
                    <div style="width:40px;height:40px;border-radius:11px;background:<?= $s['color'] ?>18;display:flex;align-items:center;justify-content:center;font-size:18px;color:<?= $s['color'] ?>;margin-bottom:12px;">
                        <i class="fa-solid <?= $s['icon'] ?>"></i>
                    </div>
                    <p style="font-size:24px;font-weight:900;"><?= $s['val'] ?></p>
                    <p style="font-size:12px;color:var(--text-muted);font-weight:600;margin-top:3px;"><?= $s['label'] ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if (!empty($userCart)): ?>
        <div class="panel-card" style="margin-top:20px;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                <h2 style="font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;">
                    <i class="fa-solid fa-cart-shopping" style="color:#6366f1;"></i> <?= __('cart.title') ?>
                </h2>
                <a href="/products" style="font-size:12px;color:#6366f1;font-weight:700;text-decoration:none;">
                    <i class="fa-solid fa-store"></i> <?= __('library.go_shop') ?>
                </a>
            </div>
            <?php foreach ($userCart as $ci): ?>
            <div class="dash-row" style="display:flex;align-items:center;gap:12px;background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:8px;" id="dashCart-<?= $ci['product_id'] ?>">
                <?php if ($ci['image_url']): ?>
                <img src="<?= e($ci['image_url']) ?>" style="width:44px;height:44px;border-radius:8px;object-fit:cover;" width="44" height="44">
                <?php else: ?>
                <div style="width:44px;height:44px;border-radius:8px;background:rgba(255,255,255,.05);display:flex;align-items:center;justify-content:center;font-size:18px;color:var(--text-dim);">
                    <i class="fa-solid fa-cube"></i>
                </div>
                <?php endif; ?>
                <div style="flex:1;min-width:0;">
                    <p style="font-size:13px;font-weight:700;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e($ci['name']) ?></p>
                    <p style="font-size:12px;color:#fbc853;font-weight:700;"><?= fmt_money($ci['price']) ?></p>
                </div>
                <div style="display:flex;align-items:center;gap:6px;background:rgba(255,255,255,.06);border-radius:8px;padding:4px 6px;">
                    <button onclick="dashCartQty(<?= $ci['product_id'] ?>,-1)" style="background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:16px;font-weight:700;width:24px;height:24px;display:flex;align-items:center;justify-content:center;border-radius:4px;">−</button>
                    <span style="font-size:13px;font-weight:700;color:var(--text);min-width:22px;text-align:center;" id="dashQty-<?= $ci['product_id'] ?>"><?= $ci['quantity'] ?></span>
                    <button onclick="dashCartQty(<?= $ci['product_id'] ?>,1)" style="background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:16px;font-weight:700;width:24px;height:24px;display:flex;align-items:center;justify-content:center;border-radius:4px;">+</button>
                </div>
                <button onclick="dashCartQty(<?= $ci['product_id'] ?>,0)" style="background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:14px;padding:4px;">
                    <i class="fa-solid fa-trash"></i>
                </button>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if (!empty($balanceLog)): ?>
        <div class="panel-card" style="margin-top:20px;">
            <h2 style="font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;margin-bottom:16px;">
                <i class="fa-solid fa-coins" style="color:#fbc853;"></i> <?= __('panel.balance_history') ?>
            </h2>
            <div style="display:flex;flex-direction:column;gap:8px;">
                <?php $blTypeLabels = ['payment'=>__('panel.tx_payment'),'purchase'=>__('panel.tx_purchase'),'topup'=>__('panel.tx_topup'),'coupon'=>__('panel.tx_coupon'),'refund'=>__('panel.tx_refund'),'admin'=>__('panel.tx_admin')]; ?>
                <?php foreach ($balanceLog as $bl): ?>
                <div class="dash-row" style="display:flex;align-items:center;gap:12px;background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;padding:12px 14px;">
                    <span class="dash-amount" style="font-size:14px;font-weight:900;color:<?= $bl['amount']>=0?'#4ade80':'#f87171' ?>;min-width:80px;">
                        <?= $bl['amount']>=0?'+':'' ?><?= fmt_money((float)$bl['amount']) ?>
                    </span>
                    <div style="flex:1;min-width:0;">
                        <div style="font-size:12px;font-weight:700;color:var(--text);">
                            <?= $blTypeLabels[$bl['type']] ?? $bl['type'] ?>
                            <?php if ($bl['description']): ?>
                            <span style="font-weight:500;color:var(--text-muted);">— <?= e($bl['description']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <span class="dash-date" style="font-size:11px;color:var(--text-dim);flex-shrink:0;"><?= date('d.m.Y H:i', strtotime($bl['created_at'])) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </main>
</div>

<?php if (!empty($userCart)): ?>
<script>
const DASH_ACTIONS = '/action.php';
async function dashCartQty(pid, delta) {
    const el = document.getElementById('dashCart-'+pid);
    const qtyEl = document.getElementById('dashQty-'+pid);
    const prevQty = parseInt(qtyEl ? qtyEl.textContent : '1');
    let newQty = delta === 0 ? 0 : Math.max(1, prevQty + delta);
    if (delta !== 0 && newQty === prevQty) return;
    if (qtyEl) qtyEl.textContent = newQty;
    const fd = new FormData();
    fd.append('action','cart_update_qty');
    fd.append('product_id', pid);
    fd.append('quantity', newQty);
    const r = await fetch(DASH_ACTIONS, {method:'POST',body:fd});
    const d = await r.json();
    if (d.ok) {
        if (newQty < 1 && el) { el.style.transition = 'opacity .3s'; el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }
        if (!d.cart_count || d.cart_count < 1) setTimeout(() => location.reload(), 400);
    } else if (qtyEl) {
        qtyEl.textContent = prevQty;
    }
}
</script>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
