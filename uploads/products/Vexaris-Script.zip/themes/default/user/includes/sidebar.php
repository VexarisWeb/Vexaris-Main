<?php
$u = auth_user();
$roleNames = [
    'user'         => __('nav.role_member'),
    'destek_ekibi' => __('nav.role_support'),
    'moderator'    => __('nav.role_mod'),
    'yonetici'     => __('nav.role_manager'),
    'admin'        => __('nav.role_admin')
];
if ($u) {
    try {
        $_db = nexus_db();
        $_rs = $_db->prepare('SELECT role FROM users WHERE id=? LIMIT 1');
        $_rs->execute([$u['id']]);
        $_role = $_rs->fetchColumn();
        if ($_role !== false && $_role !== ($u['role'] ?? '')) {
            $_SESSION['user']['role'] = $_role;
            $u['role'] = $_role;
        }
    } catch (\PDOException $e) { error_log('[NS] sidebar role: '.$e->getMessage()); }
}
$uRoleName = $roleNames[$u['role'] ?? ''] ?? __('nav.role_member');
$_updTotal = 0;
try { if ($u && function_exists('product_update_total')) $_updTotal = product_update_total(null, (int)$u['id']); } catch (Throwable $e) {}
?>
<aside class="panel-sidebar">

    <div class="sidebar-user">
        <img src="<?= e($u['avatar']) ?>"
             alt="<?= e($u['username']) ?>"
             class="sidebar-user-avatar" width="64" height="64">
        <span class="sidebar-user-name"><?= e($u['username']) ?></span>
        <span class="sidebar-user-email"><?= e($u['email']) ?></span>
        <span class="sidebar-user-role"><?= e($uRoleName) ?></span>
    </div>

    <button type="button" class="panel-nav-toggle" onclick="this.closest('.panel-sidebar').classList.toggle('nav-open')">
        <span class="panel-ham"><i class="fa-solid fa-bars"></i></span> <span><?= __('nav.panel') ?></span> <i class="fa-solid fa-chevron-down panel-nav-chev"></i>
    </button>
    <ul class="sidebar-nav">
        <li><a href="/user/dashboard" class="<?= ($activePanel??'')==='dashboard' ? 'active':'' ?>">
            <i class="fa-solid fa-gauge"></i> <?= __('nav.panel') ?>
        </a></li>
        <li><a href="/user/my-products" class="<?= ($activePanel??'')==='products'  ? 'active':'' ?>">
            <i class="fa-solid fa-cubes"></i> <?= __('nav.my_products') ?>
            <?php if ($_updTotal > 0): ?><span style="margin-left:auto;display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;border-radius:999px;background:#ef4444;color:#fff;font-size:11px;font-weight:800;"><?= $_updTotal ?></span><?php endif; ?>
        </a></li>
        <li><a href="/user/my-tickets" class="<?= ($activePanel??'')==='tickets'   ? 'active':'' ?>">
            <i class="fa-solid fa-headset"></i> <?= __('nav.my_tickets') ?>
        </a></li>
        <li><a href="/user/redeem-code" class="<?= ($activePanel??'')==='redeem' ? 'active':'' ?>">
            <i class="fa-solid fa-ticket"></i> <?= __('nav.redeem') ?>
        </a></li>
        <li><a href="/user/connections" class="<?= ($activePanel??'')==='connections' ? 'active':'' ?>">
            <i class="fa-solid fa-link"></i> <?= __('nav.connections') ?>
        </a></li>
        <li><a href="/user/settings" class="<?= ($activePanel??'')==='settings'   ? 'active':'' ?>">
            <i class="fa-solid fa-gear"></i> <?= __('nav.settings') ?>
        </a></li>
        <li class="danger"><a href="/logout">
            <i class="fa-solid fa-right-from-bracket"></i> <?= __('nav.logout') ?>
        </a></li>
    </ul>

</aside>
