<?php
auth_require('/login');

$pageTitle   = __('footer.my_products');
$activePage  = '';
$activePanel = 'products';
$u  = auth_user();
$db = nexus_db();

$purchases = [];
if ($db) {
    $stmt = $db->prepare(
        'SELECT s.id AS sale_id, s.product_id, s.license_key, s.price_paid, s.purchased_at, p.name AS product_name, p.version, p.category, p.download_link, p.file_path, p.user_notice
         FROM sales s
         JOIN products p ON p.id = s.product_id
         WHERE s.user_id = ?
         ORDER BY s.purchased_at DESC'
    );
    $stmt->execute([$u['id']]);
    $purchases = $stmt->fetchAll();
}

$updInfo = function_exists('product_update_unread') ? product_update_unread($db, (int)$u['id']) : ['total' => 0, 'by_product' => []];
$unreadByProduct = $updInfo['by_product'] ?? [];
$unreadTotal = (int)($updInfo['total'] ?? 0);

include __DIR__ . '/../includes/header.php';
?>
<style>
@keyframes nxs-spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
.nxs-spinner{width:26px;height:26px;border:3px solid rgba(99,102,241,.25);border-top-color:#6366f1;border-radius:50%;animation:nxs-spin .9s linear infinite;flex-shrink:0;}
@keyframes nxs-toast-in{from{transform:translateX(120%);opacity:0}to{transform:translateX(0);opacity:1}}
@keyframes nxs-toast-out{from{transform:translateX(0);opacity:1}to{transform:translateX(120%);opacity:0}}
#nxsToast{position:fixed;right:20px;bottom:24px;z-index:9999;display:flex;align-items:center;gap:10px;background:rgba(22,101,52,.95);border:1px solid rgba(74,222,128,.5);color:#86efac;font-size:13px;font-weight:700;padding:12px 18px;border-radius:12px;box-shadow:0 12px 32px rgba(0,0,0,.35);transform:translateX(120%);opacity:0;pointer-events:none;visibility:hidden;}
#nxsToast.show{visibility:visible;animation:nxs-toast-in .35s cubic-bezier(.34,1.56,.64,1) forwards;}
#nxsToast.hide{animation:nxs-toast-out .35s ease forwards;}
@keyframes puGlow{0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,.45);}50%{box-shadow:0 0 0 6px rgba(239,68,68,0);}}
.pu-updated{border-color:rgba(239,68,68,.55)!important;animation:puGlow 2s ease-in-out infinite;}
.pu-badge{display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;border-radius:999px;background:#ef4444;color:#fff;font-size:11px;font-weight:800;}
</style>
<div class="panel-layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="panel-content">

        <div class="panel-card">
            <h1 class="panel-card-title"><i class="fa-solid fa-cubes" style="color:#6366f1;margin-right:8px;"></i><?= __('footer.my_products') ?><?php if ($unreadTotal > 0): ?> <span class="pu-badge"><?= $unreadTotal ?></span><?php endif; ?></h1>
            <p class="panel-card-desc"><?= __('panel.products_desc') ?></p>

            <?php if (empty($purchases)): ?>
            <div style="text-align:center;padding:48px 20px;color:var(--text-muted);">
                <i class="fa-solid fa-box-open" style="font-size:42px;color:var(--text-dim);margin-bottom:14px;display:block;"></i>
                <p style="font-size:15px;font-weight:600;margin-bottom:8px;"><?= __('panel.no_products') ?></p>
                <a href="/products" class="btn-custom btn-indigo btn-sm" style="margin-top:8px;">
                    <i class="fa-solid fa-store btn-icon"></i> <?= __('library.go_shop') ?>
                </a>
            </div>
            <?php else: ?>
            <div style="display:flex;flex-direction:column;gap:14px;">
                <?php foreach ($purchases as $l): $up = $unreadByProduct[(int)($l['product_id'] ?? 0)] ?? null; ?>
                <div class="<?= $up ? 'pu-updated' : '' ?>" style="background:var(--bg-surface);border:1px solid var(--border);border-radius:16px;padding:20px 22px;">
                    <?php if ($up): ?>
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:10px;padding:8px 12px;font-size:12px;font-weight:800;color:#f87171;">
                        <i class="fa-solid fa-bell"></i> <?= __('panel.updates_n', ['n' => (int)$up['count']]) ?>
                        <span style="font-weight:600;color:var(--text-muted);">v<?= e($up['latest']['version'] !== '' ? $up['latest']['version'] : '?') ?> <?= __('panel.live') ?></span>
                        <a href="/products?product=<?= (int)$l['product_id'] ?>" style="margin-left:auto;color:#f87171;font-weight:700;"><?= __('panel.detail') ?> <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                    <?php endif; ?>
                    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">
                        <div>
                            <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
                                <span style="font-size:15px;font-weight:800;"><?= e($l['product_name'] ?? __('msg.no_name')) ?></span>
                                <span style="font-size:11px;color:var(--text-muted);font-weight:600;">v<?= e($l['version'] ?? '') ?></span>
                            </div>
                            <div style="font-size:12px;color:var(--text-muted);margin-bottom:10px;">
                                <?= e($l['category'] ?? '') ?>
                            </div>
                            <?php if (!empty($l['user_notice'])): ?>
                            <div style="display:flex;align-items:flex-start;gap:10px;background:rgba(251,200,83,.07);border:1px solid rgba(251,200,83,.22);border-radius:10px;padding:11px 14px;">
                                <i class="fa-solid fa-circle-info" style="color:#fbc853;font-size:14px;margin-top:1px;"></i>
                                <div>
                                    <div style="font-size:12px;font-weight:800;color:#fbc853;"><?= __('panel.buyer_note') ?></div>
                                    <div style="font-size:12px;color:var(--text-muted);margin-top:2px;line-height:1.5;"><?= nl2br(e($l['user_notice'])) ?></div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px;">
                            <?php if ($l['download_link']): ?>
                            <a href="<?= htmlspecialchars(nx_safe_href($l['download_link'], '#')) ?>"
                               class="btn-custom btn-yellow btn-sm" style="font-size:12px;padding:8px 16px;"
                               target="_blank" rel="noopener">
                                <i class="fa-solid fa-download btn-icon"></i> <?= __('library.download') ?>
                            </a>
                            <?php elseif ($l['file_path'] && $l['sale_id']): ?>
                            <a href="/download.php?sale_id=<?= (int)$l['sale_id'] ?>"
                               class="btn-custom btn-yellow btn-sm" style="font-size:12px;padding:8px 16px;">
                                <i class="fa-solid fa-download btn-icon"></i> <?= __('library.download') ?>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($l['license_key']): ?>
                    <div style="display:flex;align-items:center;gap:10px;margin:16px 0 12px;">
                        <div style="flex:1;display:flex;align-items:center;gap:10px;background:rgba(99,102,241,.07);border:1px solid rgba(99,102,241,.22);border-radius:10px;padding:11px 14px;min-width:0;">
                            <i class="fa-solid fa-key" style="color:#a5b4fc;font-size:13px;flex-shrink:0;"></i>
                            <code id="nxsLic-<?= (int)$l['sale_id'] ?>" style="font-family:ui-monospace,Consolas,monospace;font-size:12px;font-weight:700;color:#a5b4fc;word-break:break-all;line-height:1.5;"><?= e($l['license_key']) ?></code>
                        </div>
                        <button type="button" onclick="copyNxsLic(<?= (int)$l['sale_id'] ?>)"
                                style="flex-shrink:0;display:inline-flex;align-items:center;gap:7px;background:rgba(99,102,241,.1);border:1px solid rgba(99,102,241,.28);color:#a5b4fc;cursor:pointer;border-radius:10px;padding:12px 16px;font-size:12px;font-weight:700;">
                            <i class="fa-regular fa-copy"></i> <?= __('panel.copy') ?>
                        </button>
                    </div>
                    <?php endif; ?>
                    <div style="margin-top:10px;font-size:11px;color:var(--text-dim);">
                        <?= __('panel.purchased') ?> <?= date('d.m.Y', strtotime($l['purchased_at'])) ?>
                        <?php if ((float)$l['price_paid'] > 0): ?>
                         · <?= __('panel.amount') ?> <?= fmt_money((float)$l['price_paid']) ?>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

    </main>
</div>

<div id="nxsToast"><i class="fa-solid fa-check-circle" style="font-size:16px;color:#4ade80;"></i><span id="nxsToastText"><?= __('panel.copied') ?></span></div>
<script>
window.NX_PANEL_LANG = <?= json_encode(['copied'=>__('panel.copied')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var nxsToastTimer = null;
function showNxsToast(msg) {
    var t = document.getElementById('nxsToast');
    var s = document.getElementById('nxsToastText');
    if (!t || !s) return;
    s.textContent = msg;
    t.classList.remove('hide');
    t.classList.add('show');
    clearTimeout(nxsToastTimer);
    nxsToastTimer = setTimeout(function(){ t.classList.remove('show'); t.classList.add('hide'); }, 1800);
}
function copyNxsLic(id) {
    var el = document.getElementById('nxsLic-' + id);
    if (!el) return;
    var text = el.textContent.trim();
    var done = function(){ showNxsToast(window.NX_PANEL_LANG&&window.NX_PANEL_LANG.copied||'Kopyalandı'); };
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done, function(){ fallbackCopy(text, done); });
    } else {
        fallbackCopy(text, done);
    }
}
function fallbackCopy(text, done) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch(e) {}
    document.body.removeChild(ta);
    done();
}
</script>

<?php if ($unreadTotal > 0 && function_exists('product_update_mark_seen')) product_update_mark_seen($db, (int)$u['id']); ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>