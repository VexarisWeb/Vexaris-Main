<?php
/**
 * themes/default/user/my-tickets.php
 */
auth_require('/login');

$pageTitle   = 'Destek Taleplerim';
$activePage  = '';
$activePanel = 'tickets';
$u  = auth_user();
$db = nexus_db();

$tickets = [];

if ($db) {
    $stmt = $db->prepare('SELECT * FROM tickets WHERE user_id = ? ORDER BY COALESCE(updated_at,created_at) DESC, id DESC');
    $stmt->execute([$u['id']]);
    $tickets = $stmt->fetchAll();
}

include __DIR__ . '/../includes/header.php';
?>
<div class="panel-layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="panel-content">

        <!-- Talep Listesi -->
        <div class="panel-card">
            <h2 class="panel-card-title"><i class="fa-solid fa-list" style="color:#fbc853;margin-right:8px;"></i>Taleplerim</h2>

            <?php if (empty($tickets)): ?>
            <div style="text-align:center;padding:40px;color:var(--text-muted);">
                <i class="fa-solid fa-inbox" style="font-size:38px;color:var(--text-dim);margin-bottom:12px;display:block;"></i>
                <p><?= __('ticket.empty') ?></p>
            </div>
            <?php else: ?>
            <div style="display:flex;flex-direction:column;gap:10px;">
                <?php foreach ($tickets as $t):
                    $sc = ['open'=>'badge-red','replied'=>'badge-yellow','closed'=>'badge-green'];
                    $sl = ['open'=>__('ticket.open'),'replied'=>__('ticket.replied'),'closed'=>__('ticket.closed')];
                ?>
                <a href="/support?id=<?= (int)$t['id'] ?>"
                   style="text-decoration:none;color:inherit;cursor:pointer;background:var(--bg-surface);border:1px solid var(--border);border-radius:14px;
                          padding:16px 20px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;transition:border-color .15s,background .15s;">
                    <div>
                        <p style="font-size:14px;font-weight:700;margin-bottom:4px;"><?= e($t['title']) ?></p>
                        <p style="font-size:12px;color:var(--text-dim);">
                            <i class="fa-solid fa-tag" style="margin-right:4px;"></i>
                            <?= e($t['category'] ?? __('shop.general')) ?>
                            ·
                            <i class="fa-regular fa-clock" style="margin-right:4px;"></i>
                            <?= date('d.m.Y H:i', strtotime($t['created_at'])) ?>
                            · #<?= (int)$t['id'] ?>
                        </p>
                    </div>
                    <span class="badge <?= $sc[$t['status']] ?>">
                        <?= $sl[$t['status']] ?>
                    </span>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

    </main>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
