<?php
auth_require('/login');

$pageTitle   = __('nav.redeem');
$activePage  = '';
$activePanel = 'redeem';
$u  = auth_user();
$db = nexus_db();

include __DIR__ . '/../includes/header.php';
?>
<div class="panel-layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="panel-content">

        <div class="panel-card" style="max-width:640px;">
            <h1 class="panel-card-title"><i class="fa-solid fa-ticket" style="color:#6366f1;margin-right:8px;"></i><?= __('nav.redeem') ?></h1>
            <p class="panel-card-desc"><?= __('panel.redeem_desc') ?></p>

            <div style="display:flex;gap:10px;margin-top:18px;">
                <input type="text" id="redeemCodeInput" placeholder="<?= e(__('panel.coupon_ph')) ?>" autocomplete="off" maxlength="50"
                       style="flex:1;background:var(--bg-surface);border:1px solid var(--border);border-radius:12px;padding:13px 16px;color:var(--text);font-size:14px;outline:none;font-weight:700;letter-spacing:.08em;text-transform:uppercase;font-family:monospace;">
                <button type="button" onclick="redeemCode()" id="redeemBtn" class="btn-custom btn-indigo" style="border:none;padding:0 22px;font-size:14px;">
                    <i class="fa-solid fa-wand-magic-sparkles btn-icon"></i> <?= __('panel.use') ?>
                </button>
            </div>

            <div id="redeemResult" style="display:none;"></div>
        </div>

    </main>
</div>

<script>
window.NX_REDEEM_LANG = <?= json_encode(['enter_code'=>__('panel.enter_code'),'preparing'=>__('panel.preparing'),'conn_error'=>__('panel.conn_error'),'code_invalid'=>__('panel.code_invalid')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
var _redeeming = false;
function redeemCode() {
    if (_redeeming) return;
    var code = document.getElementById('redeemCodeInput').value.trim().toUpperCase();
    if (!code) {
        showRedeem('err', window.NX_REDEEM_LANG&&window.NX_REDEEM_LANG.enter_code||'Kupon kodu girin.');
        return;
    }
    _redeeming = true;
    var btn = document.getElementById('redeemBtn');
    btn.disabled = true;
    btn.style.opacity = '.6';
    var fd = new FormData();
    fd.append('action', 'apply_coupon');
    fd.append('code', code);
    fetch('/action.php', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            _redeeming = false;
            btn.disabled = false;
            btn.style.opacity = '';
            if (!d.ok) { showRedeem('err', d.msg || ((window.NX_REDEEM_LANG&&window.NX_REDEEM_LANG.code_invalid)||'Kod kullanılamadı.')); return; }
            var h = '';
            if (d.products && d.products.length) {
                for (var i = 0; i < d.products.length; i++) {
                    h += '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;background:var(--bg-surface);border:1px solid var(--border);border-radius:10px;padding:12px 14px;">';
                    h += '<span style="font-size:13px;font-weight:700;">' + String(d.products[i].product_name).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') + '</span>';
                    var lk = d.products[i].license_key || '';
                    if (lk) {
                        var _lk = String(lk).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
                        h += '<span style="display:flex;align-items:center;gap:8px;"><code style="background:rgba(99,102,241,.1);color:#a5b4fc;padding:5px 10px;border-radius:7px;font-size:11px;letter-spacing:.05em;">' + _lk + '</code><button onclick="copyRedeemKey(this)" style="background:rgba(255,255,255,.05);border:1px solid var(--border);color:var(--text-muted);border-radius:7px;padding:4px 8px;cursor:pointer;font-size:11px;" title="Kopyala"><i class="fa-regular fa-copy"></i></button></span>';
                    } else {
                        h += '<span style="display:flex;align-items:center;gap:8px;"><span style="width:18px;height:18px;border:2px solid rgba(99,102,241,.25);border-top-color:#6366f1;border-radius:50%;display:inline-block;animation:nxsSpin .8s linear infinite;flex-shrink:0;"></span><span style="font-size:11px;font-weight:700;color:var(--text-muted);">' + ((window.NX_REDEEM_LANG&&window.NX_REDEEM_LANG.preparing)||'Lisans hazırlanıyor') + '</span></span>';
                    if (d.products[i].notice) {
                        var _nt = String(d.products[i].notice).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
                        h += '<div style="display:flex;align-items:flex-start;gap:8px;background:rgba(251,200,83,.07);border:1px solid rgba(251,200,83,.22);border-radius:8px;padding:8px 10px;margin-top:6px;width:100%;"><i class="fa-solid fa-circle-info" style="color:#fbc853;font-size:13px;margin-top:1px;"></i><span style="font-size:11px;color:var(--text-muted);line-height:1.5;">' + _nt + '</span></div>';
                    }
                    }
                    h += '</div>';
                }
            }
            showRedeem('ok', d.msg, h);
        })
        .catch(function() {
            _redeeming = false;
            btn.disabled = false;
            btn.style.opacity = '';
            showRedeem('err', window.NX_REDEEM_LANG&&window.NX_REDEEM_LANG.conn_error||'Bağlantı hatası oluştu.');
        });
}
function showRedeem(type, msg, extra) {
    var el = document.getElementById('redeemResult');
    el.style.display = 'block';
    var bg = type === 'ok' ? 'rgba(34,197,94,.1)' : 'rgba(239,68,68,.1)';
    var bd = type === 'ok' ? 'rgba(34,197,94,.3)' : 'rgba(239,68,68,.3)';
    var tx = type === 'ok' ? '#4ade80' : '#f87171';
    var icon = type === 'ok' ? 'fa-circle-check' : 'fa-circle-xmark';
    var _msg = String(msg).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    var h = '<div style="background:' + bg + ';border:1px solid ' + bd + ';border-radius:12px;padding:14px 16px;font-size:13px;font-weight:700;color:' + tx + ';display:flex;align-items:center;gap:8px;margin-top:16px;"><i class="fa-solid ' + icon + '"></i> ' + _msg + '</div>';
    if (extra) h += '<div style="display:flex;flex-direction:column;gap:8px;margin-top:10px;">' + extra + '</div>';
    el.innerHTML = h;
}
function copyRedeemKey(btn) {
    var code = btn.parentElement.querySelector('code');
    navigator.clipboard.writeText(code.textContent.trim())
        .then(function() { btn.style.color = '#4ade80'; setTimeout(function() { btn.style.color = ''; }, 1500); });
}
document.getElementById('redeemCodeInput').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') redeemCode();
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>