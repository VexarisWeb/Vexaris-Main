<?php
/** themes/default/user/settings.php */
auth_require('/login');

$pageTitle   = 'Ayarlar';
$activePage  = '';
$activePanel = 'settings';
$u           = auth_user();
$db          = nexus_db();

$flashType = '';
$flashText = '';
if (isset($_GET['flash'])) {
    $parts = explode(':', urldecode($_GET['flash']), 2);
    $flashType = $parts[0] === 'error' ? 'error' : 'success';
    $flashText = $parts[1] ?? '';
}

include __DIR__ . '/../includes/header.php';
?>
<div class="panel-layout">

    <?php include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="panel-content">

        <?php if ($flashText): ?>
        <div class="auth-alert-<?= $flashType === 'success' ? 'success' : 'error' ?>"
             style="<?= $flashType==='success' ? 'background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.3);color:#86efac;' : 'background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#fca5a5;' ?>
                    border-radius:12px;padding:12px 16px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;">
            <i class="fa-solid <?= $flashType==='success' ? 'fa-circle-check':'fa-circle-xmark' ?>"></i>
            <?= e($flashText) ?>
        </div>
        <?php endif; ?>

        <!-- ── Avatar ── -->
        <div class="panel-card">
            <h2 class="panel-card-title"><i class="fa-solid fa-image" style="color:#6366f1;margin-right:8px;"></i><?= __('panel.avatar') ?></h2>
            <p class="panel-card-desc"><?= __('panel.avatar_desc') ?></p>

            <!-- Preset seçimi -->
            <form method="POST" action="/action.php">
                <input type="hidden" name="action" value="avatar_preset">
                <?= csrf_field() ?>
                <div class="avatar-picker">
                    <?php
                    $presets = [
                        '/images/avatars/default.svg',
                        'https://minotar.net/avatar/mustafa8907.png',
                        'https://minotar.net/avatar/MHF_Alex.png',
                    ];
                    foreach ($presets as $i => $p): ?>
                    <label class="avatar-option" title="Preset <?= $i+1 ?>">
                        <input type="radio" name="preset_url" value="<?= $p ?>"
                            <?= $u['avatar'] === $p ? 'checked' : '' ?>>
                        <img src="<?= $p ?>" alt="Preset <?= $i+1 ?>" width="64" height="64">
                    </label>
                    <?php endforeach; ?>
                </div>
                <button type="submit" class="btn-custom btn-indigo btn-sm" style="margin-top:4px;">
                    <i class="fa-solid fa-check btn-icon"></i> <?= __('panel.apply_avatar') ?>
                </button>
            </form>

            <div style="height:1px;background:var(--border);margin:24px 0;"></div>

            <!-- Dosya yükleme -->
            <form method="POST" action="/action.php" enctype="multipart/form-data" onsubmit="if(!document.getElementById('avatar_file_input').files.length){alert(window.NX_SETTINGS_LANG&&window.NX_SETTINGS_LANG.pick_file||'Lütfen bir dosya seçin.');return false;}">
                <input type="hidden" name="action" value="avatar_upload">
                <?= csrf_field() ?>
                <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                    <label class="avatar-upload-label" for="avatar_file_input">
                        <i class="fa-solid fa-upload"></i>
                        <span><?= __('panel.choose_file') ?></span>
                    </label>
                    <input type="file" id="avatar_file_input" name="avatar_file"
                           accept="image/png,image/jpeg,image/webp" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;opacity:0;"
                           onchange="document.getElementById('avatar-filename').textContent=this.files[0]?.name??'';">
                    <div>
                        <p style="font-size:13px;font-weight:600;color:var(--text-muted);">
                            PNG, JPG veya WebP — maks. 1 MB
                        </p>
                        <p id="avatar-filename" style="font-size:12px;color:#818cf8;margin-top:3px;"></p>
                    </div>
                </div>
                <button type="submit" class="btn-custom btn-yellow btn-sm" style="margin-top:16px;">
                    <i class="fa-solid fa-upload btn-icon"></i> <?= __('panel.upload') ?>
                </button>
            </form>
<script>window.NX_SETTINGS_LANG = <?= json_encode(['pick_file'=>__('panel.pick_file')], JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;</script>
        </div>

        <!-- ── Şifre Değiştir ── -->
        <div class="panel-card">
            <h2 class="panel-card-title"><i class="fa-solid fa-lock" style="color:#fbc853;margin-right:8px;"></i><?= __('panel.change_password') ?></h2>
            <p class="panel-card-desc"><?= __('panel.password_desc') ?></p>

            <form method="POST" action="/action.php" novalidate>
                <input type="hidden" name="action" value="change_password">
                <?= csrf_field() ?>

                <div class="form-group">
                    <label class="form-label"><?= __('panel.current_password') ?></label>
                    <div class="input-wrapper">
                        <i class="fa-solid fa-lock input-icon"></i>
                        <input type="password" name="current_password" class="form-input" placeholder="••••••••" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label"><?= __('panel.new_password') ?></label>
                    <div class="input-wrapper">
                        <i class="fa-solid fa-key input-icon"></i>
                        <input type="password" name="new_password" class="form-input" placeholder="••••••••" required minlength="8">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label"><?= __('panel.new_password_repeat') ?></label>
                    <div class="input-wrapper">
                        <i class="fa-solid fa-key input-icon"></i>
                        <input type="password" name="confirm_password" class="form-input" placeholder="••••••••" required>
                    </div>
                </div>

                <button type="submit" class="btn-custom btn-indigo btn-sm">
                    <i class="fa-solid fa-floppy-disk btn-icon"></i> <?= __('panel.update_password') ?>
                </button>
            </form>
        </div>

        <!-- ── Mail Değiştir ── -->
        <div class="panel-card">
            <h2 class="panel-card-title"><i class="fa-solid fa-envelope" style="color:#34d399;margin-right:8px;"></i><?= __('panel.change_email') ?></h2>
            <p class="panel-card-desc">Mevcut: <strong><?= e($u['email']) ?></strong></p>

            <form method="POST" action="/action.php" novalidate>
                <input type="hidden" name="action" value="change_email">
                <?= csrf_field() ?>
                <div class="form-group">
                    <label class="form-label">Yeni E-posta Adresi</label>
                    <div class="input-wrapper">
                        <i class="fa-solid fa-envelope input-icon"></i>
                        <input type="email" name="new_email" class="form-input"
                               placeholder="yeni@mail.com" required maxlength="255">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label"><?= __('panel.email_verify_password') ?></label>
                    <div class="input-wrapper">
                        <i class="fa-solid fa-lock input-icon"></i>
                        <input type="password" name="current_password" class="form-input" placeholder="••••••••" required>
                    </div>
                </div>
                <button type="submit" class="btn-custom btn-yellow btn-sm">
                    <i class="fa-solid fa-floppy-disk btn-icon"></i> <?= __('panel.update_email') ?>
                </button>
            </form>
        </div>

    </main>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
