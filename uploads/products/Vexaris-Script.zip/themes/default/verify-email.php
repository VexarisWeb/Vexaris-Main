<?php
$pageTitle  = __('auth.verify_title');
$activePage = 'login';
$seoKey     = 'login';
$notice     = '';

$token = trim($_GET['token'] ?? '');

if ($token !== '') {
    try {
        $db = nexus_db();
        $st = $db->prepare('SELECT email FROM email_verifications WHERE token=? AND used=0 AND expires_at > NOW() LIMIT 1');
        $st->execute([$token]);
        $ver = $st->fetch();
        if (!$ver) {
            $notice = '<h1 class="auth-card-title">'.__('auth.verify_bad').'</h1><p class="auth-card-subtitle">'.__('auth.verify_bad_sub').'</p>';
        } else {
            $st2 = $db->prepare('SELECT id FROM users WHERE email=? LIMIT 1');
            $st2->execute([$ver['email']]);
            $user = $st2->fetch();
            if ($user) {
                $db->prepare('UPDATE users SET email_verified=1 WHERE id=?')->execute([$user['id']]);
                $db->prepare('UPDATE email_verifications SET used=1 WHERE token=?')->execute([$token]);
                $notice = '<h1 class="auth-card-title">'.__('auth.verify_ok').'</h1><p class="auth-card-subtitle">'.__('auth.verify_ok_sub').'</p>';
            } else {
                $db->prepare('UPDATE email_verifications SET used=1 WHERE token=?')->execute([$token]);
                $notice = '<h1 class="auth-card-title">'.__('auth.verify_nouser').'</h1><p class="auth-card-subtitle">'.__('auth.verify_nouser_sub').'</p>';
            }
        }
    } catch (\PDOException $e) {
        error_log('[NS] verify-email: '.$e->getMessage());
        $notice = '<h1 class="auth-card-title">'.__('auth.verify_err').'</h1><p class="auth-card-subtitle">'.__('auth.verify_err_sub').'</p>';
    }
} else {
    $notice = '<h1 class="auth-card-title">'.__('auth.verify_bad').'</h1><p class="auth-card-subtitle">'.__('auth.verify_needlink').'</p>';
}

include __DIR__ . '/includes/header.php';
?>
<main class="auth-wrapper">
    <div class="auth-card">
        <div class="auth-card-icon green">
            <i class="fa-solid fa-circle-check"></i>
        </div>
        <?= $notice ?>
        <p class="auth-redirect" style="margin-top:14px;">
            <a href="/login"><i class="fa-solid fa-right-to-bracket" style="font-size:11px;"></i> <?= __('auth.do_login') ?></a>
        </p>
    </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>