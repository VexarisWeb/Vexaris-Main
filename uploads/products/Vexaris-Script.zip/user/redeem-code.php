<?php
include '../core/init.php';
theme_load('user/redeem-code');